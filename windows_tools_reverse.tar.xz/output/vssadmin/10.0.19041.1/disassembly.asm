
/root/reverse/work/vssadmin/10.0.19041.1/10.0.19041.1.exe:     file format pei-x86-64


Disassembly of section .text:

0000000140001000 <.text>:
   140001000:	int3
   140001001:	int3
   140001002:	int3
   140001003:	int3
   140001004:	int3
   140001005:	int3
   140001006:	int3
   140001007:	int3
   140001008:	int3
   140001009:	int3
   14000100a:	int3
   14000100b:	int3
   14000100c:	int3
   14000100d:	int3
   14000100e:	int3
   14000100f:	int3
   140001010:	sub    rsp,0x28
   140001014:	cmp    DWORD PTR [rip+0x236e5],0x0        # 0x140024700
   14000101b:	jne    0x140001022
   14000101d:	call   0x1400127e0
   140001022:	mov    eax,DWORD PTR [rip+0x236dc]        # 0x140024704
   140001028:	mov    DWORD PTR [rip+0x236de],eax        # 0x14002470c
   14000102e:	add    rsp,0x28
   140001032:	ret
   140001033:	int3
   140001034:	int3
   140001035:	int3
   140001036:	int3
   140001037:	int3
   140001038:	int3
   140001039:	int3
   14000103a:	int3
   14000103b:	int3
   14000103c:	int3
   14000103d:	int3
   14000103e:	int3
   14000103f:	int3
   140001040:	rex push rbx
   140001042:	sub    rsp,0x20
   140001046:	lea    rax,[rip+0x16103]        # 0x140017150
   14000104d:	mov    rbx,rcx
   140001050:	mov    QWORD PTR [rcx],rax
   140001053:	test   dl,0x1
   140001056:	je     0x14000105d
   140001058:	call   0x140014084
   14000105d:	mov    rax,rbx
   140001060:	add    rsp,0x20
   140001064:	pop    rbx
   140001065:	ret
   140001066:	int3
   140001067:	int3
   140001068:	int3
   140001069:	int3
   14000106a:	int3
   14000106b:	int3
   14000106c:	int3
   14000106d:	int3
   14000106e:	int3
   14000106f:	int3
   140001070:	mov    rax,rsp
   140001073:	mov    QWORD PTR [rax+0x8],rbx
   140001077:	mov    QWORD PTR [rax+0x10],rbp
   14000107b:	mov    QWORD PTR [rax+0x18],rsi
   14000107f:	mov    QWORD PTR [rax+0x20],rdi
   140001083:	push   r14
   140001085:	sub    rsp,0x20
   140001089:	xor    r14d,r14d
   14000108c:	mov    rsi,rcx
   14000108f:	mov    ebp,r14d
   140001092:	cmp    DWORD PTR [rcx+0x20],r14d
   140001096:	jbe    0x1400010ba
   140001098:	mov    rbx,QWORD PTR [rsi+0x18]
   14000109c:	movsxd rdi,ebp
   14000109f:	mov    rcx,QWORD PTR [rbx+rdi*8]
   1400010a3:	rex.W call QWORD PTR [rip+0x16fd6]        # 0x140018080
   1400010aa:	nop    DWORD PTR [rax+rax*1+0x0]
   1400010af:	inc    ebp
   1400010b1:	mov    QWORD PTR [rbx+rdi*8],r14
   1400010b5:	cmp    ebp,DWORD PTR [rsi+0x20]
   1400010b8:	jb     0x140001098
   1400010ba:	mov    ebp,r14d
   1400010bd:	cmp    DWORD PTR [rsi+0x38],r14d
   1400010c1:	jbe    0x1400010e5
   1400010c3:	mov    rbx,QWORD PTR [rsi+0x30]
   1400010c7:	movsxd rdi,ebp
   1400010ca:	mov    rcx,QWORD PTR [rbx+rdi*8]
   1400010ce:	rex.W call QWORD PTR [rip+0x16fab]        # 0x140018080
   1400010d5:	nop    DWORD PTR [rax+rax*1+0x0]
   1400010da:	inc    ebp
   1400010dc:	mov    QWORD PTR [rbx+rdi*8],r14
   1400010e0:	cmp    ebp,DWORD PTR [rsi+0x38]
   1400010e3:	jb     0x1400010c3
   1400010e5:	mov    rbx,QWORD PTR [rsi+0x40]
   1400010e9:	test   rbx,rbx
   1400010ec:	je     0x140001181
   1400010f2:	mov    ebp,r14d
   1400010f5:	cmp    DWORD PTR [rbx+0x10],r14d
   1400010f9:	jbe    0x140001140
   1400010fb:	mov    rbx,QWORD PTR [rbx+0x8]
   1400010ff:	movsxd rdi,ebp
   140001102:	mov    rcx,QWORD PTR [rbx+rdi*8]
   140001106:	rex.W call QWORD PTR [rip+0x16f73]        # 0x140018080
   14000110d:	nop    DWORD PTR [rax+rax*1+0x0]
   140001112:	mov    QWORD PTR [rbx+rdi*8],r14
   140001116:	mov    rax,QWORD PTR [rsi+0x40]
   14000111a:	mov    rcx,QWORD PTR [rax]
   14000111d:	mov    rcx,QWORD PTR [rcx+rdi*8]
   140001121:	mov    QWORD PTR [rbx+rdi*8],rcx
   140001125:	rex.W call QWORD PTR [rip+0x16f54]        # 0x140018080
   14000112c:	nop    DWORD PTR [rax+rax*1+0x0]
   140001131:	mov    QWORD PTR [rbx+rdi*8],r14
   140001135:	inc    ebp
   140001137:	mov    rbx,QWORD PTR [rsi+0x40]
   14000113b:	cmp    ebp,DWORD PTR [rbx+0x10]
   14000113e:	jb     0x1400010fb
   140001140:	test   rbx,rbx
   140001143:	je     0x140001181
   140001145:	mov    rcx,QWORD PTR [rbx]
   140001148:	test   rcx,rcx
   14000114b:	je     0x14000115c
   14000114d:	rex.W call QWORD PTR [rip+0x170f4]        # 0x140018248
   140001154:	nop    DWORD PTR [rax+rax*1+0x0]
   140001159:	mov    QWORD PTR [rbx],r14
   14000115c:	mov    rcx,QWORD PTR [rbx+0x8]
   140001160:	test   rcx,rcx
   140001163:	je     0x140001175
   140001165:	rex.W call QWORD PTR [rip+0x170dc]        # 0x140018248
   14000116c:	nop    DWORD PTR [rax+rax*1+0x0]
   140001171:	mov    QWORD PTR [rbx+0x8],r14
   140001175:	mov    rcx,rbx
   140001178:	mov    DWORD PTR [rbx+0x10],r14d
   14000117c:	call   0x140014084
   140001181:	mov    rcx,QWORD PTR [rsi]
   140001184:	test   rcx,rcx
   140001187:	je     0x14000119a
   140001189:	mov    rax,QWORD PTR [rcx]
   14000118c:	mov    edx,0x1
   140001191:	mov    rax,QWORD PTR [rax]
   140001194:	call   QWORD PTR [rip+0x170fe]        # 0x140018298
   14000119a:	cmp    BYTE PTR [rsi+0xf0],r14b
   1400011a1:	je     0x1400011af
   1400011a3:	rex.W call QWORD PTR [rip+0x16eae]        # 0x140018058
   1400011aa:	nop    DWORD PTR [rax+rax*1+0x0]
   1400011af:	lea    rbx,[rsi+0x68]
   1400011b3:	mov    edi,0xe
   1400011b8:	mov    rcx,QWORD PTR [rbx]
   1400011bb:	rex.W call QWORD PTR [rip+0x16ebe]        # 0x140018080
   1400011c2:	nop    DWORD PTR [rax+rax*1+0x0]
   1400011c7:	mov    QWORD PTR [rbx],r14
   1400011ca:	lea    rbx,[rbx+0x8]
   1400011ce:	sub    rdi,0x1
   1400011d2:	jne    0x1400011b8
   1400011d4:	mov    rcx,QWORD PTR [rsi+0x28]
   1400011d8:	test   rcx,rcx
   1400011db:	je     0x1400011ed
   1400011dd:	rex.W call QWORD PTR [rip+0x17064]        # 0x140018248
   1400011e4:	nop    DWORD PTR [rax+rax*1+0x0]
   1400011e9:	mov    QWORD PTR [rsi+0x28],r14
   1400011ed:	mov    rcx,QWORD PTR [rsi+0x30]
   1400011f1:	test   rcx,rcx
   1400011f4:	je     0x140001206
   1400011f6:	rex.W call QWORD PTR [rip+0x1704b]        # 0x140018248
   1400011fd:	nop    DWORD PTR [rax+rax*1+0x0]
   140001202:	mov    QWORD PTR [rsi+0x30],r14
   140001206:	mov    DWORD PTR [rsi+0x38],r14d
   14000120a:	mov    rcx,QWORD PTR [rsi+0x10]
   14000120e:	test   rcx,rcx
   140001211:	je     0x140001223
   140001213:	rex.W call QWORD PTR [rip+0x1702e]        # 0x140018248
   14000121a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000121f:	mov    QWORD PTR [rsi+0x10],r14
   140001223:	mov    rcx,QWORD PTR [rsi+0x18]
   140001227:	test   rcx,rcx
   14000122a:	je     0x14000123c
   14000122c:	rex.W call QWORD PTR [rip+0x17015]        # 0x140018248
   140001233:	nop    DWORD PTR [rax+rax*1+0x0]
   140001238:	mov    QWORD PTR [rsi+0x18],r14
   14000123c:	mov    rbx,QWORD PTR [rsp+0x30]
   140001241:	mov    rbp,QWORD PTR [rsp+0x38]
   140001246:	mov    rdi,QWORD PTR [rsp+0x48]
   14000124b:	mov    DWORD PTR [rsi+0x20],r14d
   14000124f:	mov    rsi,QWORD PTR [rsp+0x40]
   140001254:	add    rsp,0x20
   140001258:	pop    r14
   14000125a:	ret
   14000125b:	int3
   14000125c:	int3
   14000125d:	int3
   14000125e:	int3
   14000125f:	int3
   140001260:	int3
   140001261:	int3
   140001262:	int3
   140001263:	int3
   140001264:	mov    rax,rsp
   140001267:	push   rbp
   140001268:	push   r12
   14000126a:	push   r13
   14000126c:	push   r14
   14000126e:	push   r15
   140001270:	lea    rbp,[rsp-0x60]
   140001275:	sub    rsp,0x160
   14000127c:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   140001285:	mov    QWORD PTR [rax+0x10],rbx
   140001289:	mov    QWORD PTR [rax+0x18],rsi
   14000128d:	mov    QWORD PTR [rax+0x20],rdi
   140001291:	mov    rbx,rdx
   140001294:	mov    rsi,rcx
   140001297:	lea    r15,[rip+0x175d2]        # 0x140018870
   14000129e:	mov    QWORD PTR [rsp+0x48],r15
   1400012a3:	lea    r12,[rip+0x1756e]        # 0x140018818
   1400012aa:	mov    QWORD PTR [rsp+0x50],r12
   1400012af:	lea    r13,[rip+0x1759a]        # 0x140018850
   1400012b6:	mov    QWORD PTR [rsp+0x58],r13
   1400012bb:	mov    DWORD PTR [rsp+0x60],0xd8
   1400012c3:	mov    DWORD PTR [rsp+0x64],0x7
   1400012cb:	mov    DWORD PTR [rsp+0x68],0xff
   1400012d3:	xor    r14d,r14d
   1400012d6:	mov    DWORD PTR [rbp-0x18],0x1000000
   1400012dd:	xor    edx,edx
   1400012df:	lea    r8d,[r14+0x78]
   1400012e3:	lea    rcx,[rsp+0x70]
   1400012e8:	call   0x140015692
   1400012ed:	lea    rdx,[rsp+0x48]
   1400012f2:	lea    rcx,[rbp-0x10]
   1400012f6:	call   0x14000f85c
   1400012fb:	nop
   1400012fc:	movsxd rax,DWORD PTR [rsi+0x60]
   140001300:	lea    rcx,[rax+rax*2]
   140001304:	shl    rcx,0x5
   140001308:	lea    rax,[rip+0x15fd5]        # 0x1400172e4
   14000130f:	cmp    DWORD PTR [rcx+rax*1],r14d
   140001313:	jne    0x14000134b
   140001315:	movups xmm0,XMMWORD PTR [rip+0x17e1c]        # 0x140019138
   14000131c:	movdqu XMMWORD PTR [rbx],xmm0
   140001320:	lea    rcx,[rbp-0x10]
   140001324:	call   0x14000f958
   140001329:	lea    r11,[rsp+0x160]
   140001331:	mov    rbx,QWORD PTR [r11+0x38]
   140001335:	mov    rsi,QWORD PTR [r11+0x40]
   140001339:	mov    rdi,QWORD PTR [r11+0x48]
   14000133d:	mov    rsp,r11
   140001340:	pop    r15
   140001342:	pop    r14
   140001344:	pop    r13
   140001346:	pop    r12
   140001348:	pop    rbp
   140001349:	ret
   14000134a:	int3
   14000134b:	movups xmm0,XMMWORD PTR [rip+0x1705e]        # 0x1400183b0
   140001352:	movdqu XMMWORD PTR [rbx],xmm0
   140001356:	mov    edx,0x8
   14000135b:	mov    rcx,rsi
   14000135e:	call   0x1400038f8
   140001363:	mov    rdi,rax
   140001366:	test   rax,rax
   140001369:	je     0x140001320
   14000136b:	mov    r8,rbx
   14000136e:	mov    rdx,rax
   140001371:	call   0x14000c630
   140001376:	test   al,al
   140001378:	jne    0x140001320
   14000137a:	mov    r8,rbx
   14000137d:	mov    rdx,rdi
   140001380:	call   0x140001908
   140001385:	test   eax,eax
   140001387:	jne    0x140001320
   140001389:	mov    r8,rdi
   14000138c:	mov    edx,0x4000274c
   140001391:	mov    rcx,rsi
   140001394:	call   0x14000d524
   140001399:	mov    DWORD PTR [rsp+0x28],0x7
   1400013a1:	mov    DWORD PTR [rsp+0x20],0xf3
   1400013a9:	mov    r9,r12
   1400013ac:	mov    r8,r13
   1400013af:	mov    rdx,r15
   1400013b2:	lea    rcx,[rsp+0x48]
   1400013b7:	call   0x14000f3ac
   1400013bc:	lea    r9,[rip+0x17505]        # 0x1400188c8
   1400013c3:	xor    r8d,r8d
   1400013c6:	mov    rdx,rax
   1400013c9:	lea    rcx,[rbp-0x10]
   1400013cd:	call   0x1400106b0
   1400013d2:	int3
   1400013d3:	int3
   1400013d4:	int3
   1400013d5:	int3
   1400013d6:	int3
   1400013d7:	int3
   1400013d8:	int3
   1400013d9:	int3
   1400013da:	int3
   1400013db:	int3
   1400013dc:	mov    rax,rsp
   1400013df:	push   rbp
   1400013e0:	push   r12
   1400013e2:	push   r13
   1400013e4:	push   r14
   1400013e6:	push   r15
   1400013e8:	lea    rbp,[rax-0x188]
   1400013ef:	sub    rsp,0x260
   1400013f6:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   140001401:	mov    QWORD PTR [rax+0x10],rbx
   140001405:	mov    QWORD PTR [rax+0x18],rsi
   140001409:	mov    QWORD PTR [rax+0x20],rdi
   14000140d:	movaps XMMWORD PTR [rax-0x38],xmm6
   140001411:	mov    rax,QWORD PTR [rip+0x22d00]        # 0x140024118
   140001418:	xor    rax,rsp
   14000141b:	mov    QWORD PTR [rbp+0x140],rax
   140001422:	mov    r14,rdx
   140001425:	mov    rbx,rcx
   140001428:	lea    r13,[rip+0x17441]        # 0x140018870
   14000142f:	mov    QWORD PTR [rbp-0x80],r13
   140001433:	lea    rsi,[rip+0x174ce]        # 0x140018908
   14000143a:	mov    QWORD PTR [rbp-0x78],rsi
   14000143e:	lea    rdi,[rip+0x1740b]        # 0x140018850
   140001445:	mov    QWORD PTR [rbp-0x70],rdi
   140001449:	mov    DWORD PTR [rbp-0x68],0xfd
   140001450:	mov    DWORD PTR [rbp-0x64],0x7
   140001457:	mov    DWORD PTR [rbp-0x60],0xff
   14000145e:	xor    r15d,r15d
   140001461:	mov    DWORD PTR [rbp+0x20],0x1000000
   140001468:	xor    edx,edx
   14000146a:	lea    r12d,[r15+0x1]
   14000146e:	lea    r8d,[r15+0x78]
   140001472:	lea    rcx,[rbp-0x58]
   140001476:	call   0x140015692
   14000147b:	lea    rdx,[rbp-0x80]
   14000147f:	lea    rcx,[rbp+0x30]
   140001483:	call   0x14000f85c
   140001488:	nop
   140001489:	movups xmm0,XMMWORD PTR [r14]
   14000148d:	movdqu XMMWORD PTR [rsp+0x40],xmm0
   140001493:	mov    eax,r15d
   140001496:	cmp    DWORD PTR [rbx+0x38],r15d
   14000149a:	jle    0x1400014c4
   14000149c:	mov    rdx,QWORD PTR [rsp+0x48]
   1400014a1:	mov    r8,QWORD PTR [rsp+0x40]
   1400014a6:	movsxd rcx,eax
   1400014a9:	shl    rcx,0x4
   1400014ad:	add    rcx,QWORD PTR [rbx+0x28]
   1400014b1:	cmp    QWORD PTR [rcx],r8
   1400014b4:	jne    0x1400014bc
   1400014b6:	cmp    QWORD PTR [rcx+0x8],rdx
   1400014ba:	je     0x1400014c7
   1400014bc:	add    eax,r12d
   1400014bf:	cmp    eax,DWORD PTR [rbx+0x38]
   1400014c2:	jl     0x1400014a6
   1400014c4:	or     eax,0xffffffff
   1400014c7:	cmp    eax,0xffffffff
   1400014ca:	je     0x1400014e7
   1400014cc:	movsxd rcx,eax
   1400014cf:	mov    rax,QWORD PTR [rbx+0x30]
   1400014d3:	mov    rdi,QWORD PTR [rax+rcx*8]
   1400014d7:	test   rdi,rdi
   1400014da:	jne    0x1400017cf
   1400014e0:	lea    rdi,[rip+0x17369]        # 0x140018850
   1400014e7:	mov    QWORD PTR [rsp+0x58],r15
   1400014ec:	movups xmm0,XMMWORD PTR [rip+0x17b7d]        # 0x140019070
   1400014f3:	movdqu XMMWORD PTR [rsp+0x40],xmm0
   1400014f9:	movups xmm1,XMMWORD PTR [rip+0x17b60]        # 0x140019060
   140001500:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   140001506:	mov    QWORD PTR [rbp-0x80],r13
   14000150a:	mov    QWORD PTR [rbp-0x78],rsi
   14000150e:	mov    QWORD PTR [rbp-0x70],rdi
   140001512:	mov    DWORD PTR [rbp-0x68],0x106
   140001519:	mov    DWORD PTR [rbp-0x64],0x7
   140001520:	mov    DWORD PTR [rbp-0x60],0xff
   140001527:	mov    DWORD PTR [rbp+0x20],0x1000000
   14000152e:	xor    edx,edx
   140001530:	lea    r8d,[rdx+0x78]
   140001534:	lea    rcx,[rbp-0x58]
   140001538:	call   0x140015692
   14000153d:	lea    rax,[rsp+0x58]
   140001542:	mov    QWORD PTR [rsp+0x30],rax
   140001547:	lea    rax,[rsp+0x40]
   14000154c:	mov    QWORD PTR [rsp+0x28],rax
   140001551:	lea    r9,[rip+0x173f0]        # 0x140018948
   140001558:	lea    r8,[rsp+0x70]
   14000155d:	lea    rdx,[rbp-0x80]
   140001561:	lea    rcx,[rbp+0x30]
   140001565:	call   0x140011460
   14000156a:	cmp    DWORD PTR [rbp+0x38],r15d
   14000156e:	jl     0x140001871
   140001574:	mov    QWORD PTR [rsp+0x50],r15
   140001579:	movups xmm0,XMMWORD PTR [rip+0x16e30]        # 0x1400183b0
   140001580:	movdqu XMMWORD PTR [rsp+0x70],xmm0
   140001586:	mov    rcx,QWORD PTR [rsp+0x58]
   14000158b:	mov    rax,QWORD PTR [rcx]
   14000158e:	lea    rdx,[rsp+0x50]
   140001593:	mov    QWORD PTR [rsp+0x20],rdx
   140001598:	mov    r9d,0x4
   14000159e:	mov    r8d,r12d
   1400015a1:	lea    rdx,[rsp+0x70]
   1400015a6:	mov    rax,QWORD PTR [rax+0x50]
   1400015aa:	call   QWORD PTR [rip+0x16ce8]        # 0x140018298
   1400015b0:	mov    DWORD PTR [rbp+0x38],eax
   1400015b3:	test   eax,eax
   1400015b5:	js     0x1400018ba
   1400015bb:	mov    rcx,QWORD PTR [rsp+0x50]
   1400015c0:	mov    rax,QWORD PTR [rcx]
   1400015c3:	lea    r9,[rsp+0x60]
   1400015c8:	lea    r8,[rbp+0xb0]
   1400015cf:	mov    edx,r12d
   1400015d2:	mov    rax,QWORD PTR [rax+0x18]
   1400015d6:	call   QWORD PTR [rip+0x16cbc]        # 0x140018298
   1400015dc:	test   eax,eax
   1400015de:	mov    DWORD PTR [rbp+0x38],eax
   1400015e1:	js     0x14000182b
   1400015e7:	cmp    eax,r12d
   1400015ea:	je     0x14000178f
   1400015f0:	mov    rcx,QWORD PTR [rbp+0xd8]
   1400015f7:	rex.W call QWORD PTR [rip+0x16a82]        # 0x140018080
   1400015fe:	nop    DWORD PTR [rax+rax*1+0x0]
   140001603:	mov    QWORD PTR [rbp+0xd8],r15
   14000160a:	mov    rax,QWORD PTR [rbp+0xb8]
   140001611:	cmp    rax,QWORD PTR [r14]
   140001614:	jne    0x140001623
   140001616:	mov    rax,QWORD PTR [rbp+0xc0]
   14000161d:	cmp    rax,QWORD PTR [r14+0x8]
   140001621:	je     0x140001642
   140001623:	mov    rcx,QWORD PTR [rbp+0xc8]
   14000162a:	rex.W call QWORD PTR [rip+0x16a4f]        # 0x140018080
   140001631:	nop    DWORD PTR [rax+rax*1+0x0]
   140001636:	mov    QWORD PTR [rbp+0xc8],r15
   14000163d:	jmp    0x1400015bb
   140001642:	mov    rdi,QWORD PTR [rbp+0xc8]
   140001649:	mov    QWORD PTR [rsp+0x78],rdi
   14000164e:	lea    rax,[rip+0x15a0b]        # 0x140017060
   140001655:	mov    QWORD PTR [rsp+0x70],rax
   14000165a:	mov    rsi,r15
   14000165d:	mov    QWORD PTR [rsp+0x40],r15
   140001662:	test   rdi,rdi
   140001665:	je     0x14000167d
   140001667:	mov    r8,rdi
   14000166a:	lea    rdx,[rsp+0x40]
   14000166f:	lea    rcx,[rbp+0x30]
   140001673:	call   0x140003688
   140001678:	mov    rsi,QWORD PTR [rsp+0x40]
   14000167d:	mov    QWORD PTR [rsp+0x40],rsi
   140001682:	movups xmm6,XMMWORD PTR [r14]
   140001686:	mov    eax,DWORD PTR [rbx+0x38]
   140001689:	add    eax,r12d
   14000168c:	movsxd rdx,eax
   14000168f:	shl    rdx,0x4
   140001693:	mov    rcx,QWORD PTR [rbx+0x28]
   140001697:	rex.W call QWORD PTR [rip+0x16bb2]        # 0x140018250
   14000169e:	nop    DWORD PTR [rax+rax*1+0x0]
   1400016a3:	test   rax,rax
   1400016a6:	je     0x1400017e0
   1400016ac:	mov    QWORD PTR [rbx+0x28],rax
   1400016b0:	mov    eax,DWORD PTR [rbx+0x38]
   1400016b3:	add    eax,r12d
   1400016b6:	movsxd rdx,eax
   1400016b9:	shl    rdx,0x3
   1400016bd:	mov    rcx,QWORD PTR [rbx+0x30]
   1400016c1:	rex.W call QWORD PTR [rip+0x16b88]        # 0x140018250
   1400016c8:	nop    DWORD PTR [rax+rax*1+0x0]
   1400016cd:	mov    rdx,rax
   1400016d0:	test   rax,rax
   1400016d3:	je     0x1400017e0
   1400016d9:	mov    QWORD PTR [rbx+0x30],rax
   1400016dd:	movsxd rcx,DWORD PTR [rbx+0x38]
   1400016e1:	lea    eax,[rcx+0x1]
   1400016e4:	mov    DWORD PTR [rbx+0x38],eax
   1400016e7:	mov    rax,rcx
   1400016ea:	shl    rcx,0x4
   1400016ee:	add    rcx,QWORD PTR [rbx+0x28]
   1400016f2:	je     0x1400016fc
   1400016f4:	movdqu XMMWORD PTR [rcx],xmm6
   1400016f8:	mov    rdx,QWORD PTR [rbx+0x30]
   1400016fc:	lea    rax,[rdx+rax*8]
   140001700:	test   rax,rax
   140001703:	je     0x140001708
   140001705:	mov    QWORD PTR [rax],rsi
   140001708:	test   rdi,rdi
   14000170b:	je     0x14000171d
   14000170d:	mov    rcx,rdi
   140001710:	rex.W call QWORD PTR [rip+0x16969]        # 0x140018080
   140001717:	nop    DWORD PTR [rax+rax*1+0x0]
   14000171c:	nop
   14000171d:	mov    rcx,QWORD PTR [rsp+0x50]
   140001722:	test   rcx,rcx
   140001725:	je     0x140001735
   140001727:	mov    rax,QWORD PTR [rcx]
   14000172a:	mov    rax,QWORD PTR [rax+0x10]
   14000172e:	call   QWORD PTR [rip+0x16b64]        # 0x140018298
   140001734:	nop
   140001735:	mov    rcx,QWORD PTR [rsp+0x58]
   14000173a:	test   rcx,rcx
   14000173d:	je     0x14000174d
   14000173f:	mov    rax,QWORD PTR [rcx]
   140001742:	mov    rax,QWORD PTR [rax+0x10]
   140001746:	call   QWORD PTR [rip+0x16b4c]        # 0x140018298
   14000174c:	nop
   14000174d:	lea    rcx,[rbp+0x30]
   140001751:	call   0x14000f958
   140001756:	mov    rax,rsi
   140001759:	mov    rcx,QWORD PTR [rbp+0x140]
   140001760:	xor    rcx,rsp
   140001763:	call   0x1400143c0
   140001768:	lea    r11,[rsp+0x260]
   140001770:	mov    rbx,QWORD PTR [r11+0x38]
   140001774:	mov    rsi,QWORD PTR [r11+0x40]
   140001778:	mov    rdi,QWORD PTR [r11+0x48]
   14000177c:	movaps xmm6,XMMWORD PTR [r11-0x10]
   140001781:	mov    rsp,r11
   140001784:	pop    r15
   140001786:	pop    r14
   140001788:	pop    r13
   14000178a:	pop    r12
   14000178c:	pop    rbp
   14000178d:	ret
   14000178e:	int3
   14000178f:	mov    edx,0x66
   140001794:	mov    rcx,rbx
   140001797:	call   0x14000c1fc
   14000179c:	mov    rdi,rax
   14000179f:	mov    rcx,QWORD PTR [rsp+0x50]
   1400017a4:	test   rcx,rcx
   1400017a7:	je     0x1400017b7
   1400017a9:	mov    rax,QWORD PTR [rcx]
   1400017ac:	mov    rax,QWORD PTR [rax+0x10]
   1400017b0:	call   QWORD PTR [rip+0x16ae2]        # 0x140018298
   1400017b6:	nop
   1400017b7:	mov    rcx,QWORD PTR [rsp+0x58]
   1400017bc:	test   rcx,rcx
   1400017bf:	je     0x1400017cf
   1400017c1:	mov    rax,QWORD PTR [rcx]
   1400017c4:	mov    rax,QWORD PTR [rax+0x10]
   1400017c8:	call   QWORD PTR [rip+0x16aca]        # 0x140018298
   1400017ce:	nop
   1400017cf:	lea    rcx,[rbp+0x30]
   1400017d3:	call   0x14000f958
   1400017d8:	mov    rax,rdi
   1400017db:	jmp    0x140001759
   1400017e0:	lea    rcx,[rsp+0x40]
   1400017e5:	call   0x1400039a4
   1400017ea:	mov    DWORD PTR [rsp+0x28],r12d
   1400017ef:	mov    DWORD PTR [rsp+0x20],0x142
   1400017f7:	lea    r9,[rip+0x1710a]        # 0x140018908
   1400017fe:	lea    r8,[rip+0x1704b]        # 0x140018850
   140001805:	mov    rdx,r13
   140001808:	lea    rcx,[rbp-0x80]
   14000180c:	call   0x14000f3ac
   140001811:	lea    r9,[rip+0x17750]        # 0x140018f68
   140001818:	mov    r8d,0x8007000e
   14000181e:	mov    rdx,rax
   140001821:	lea    rcx,[rbp+0x30]
   140001825:	call   0x1400106b0
   14000182a:	nop
   14000182b:	mov    DWORD PTR [rsp+0x28],0x7
   140001833:	mov    DWORD PTR [rsp+0x20],0x120
   14000183b:	mov    r9,rsi
   14000183e:	mov    r8,rdi
   140001841:	mov    rdx,r13
   140001844:	lea    rcx,[rbp-0x80]
   140001848:	call   0x14000f3ac
   14000184d:	mov    rdx,rax
   140001850:	lea    rcx,[rbp+0x30]
   140001854:	call   0x1400038ec
   140001859:	mov    DWORD PTR [rsp+0x20],eax
   14000185d:	lea    r9,[rip+0x17184]        # 0x1400189e8
   140001864:	mov    r8d,eax
   140001867:	lea    rcx,[rbp+0x30]
   14000186b:	call   0x1400106b0
   140001870:	nop
   140001871:	mov    DWORD PTR [rsp+0x28],0x7
   140001879:	mov    DWORD PTR [rsp+0x20],0x10d
   140001881:	mov    r9,rsi
   140001884:	mov    r8,rdi
   140001887:	mov    rdx,r13
   14000188a:	lea    rcx,[rbp-0x80]
   14000188e:	call   0x14000f3ac
   140001893:	mov    rdx,rax
   140001896:	lea    rcx,[rbp+0x30]
   14000189a:	call   0x1400038ec
   14000189f:	mov    DWORD PTR [rsp+0x20],eax
   1400018a3:	lea    r9,[rip+0x170b6]        # 0x140018960
   1400018aa:	mov    r8d,0x8000ffff
   1400018b0:	lea    rcx,[rbp+0x30]
   1400018b4:	call   0x1400106b0
   1400018b9:	nop
   1400018ba:	mov    DWORD PTR [rsp+0x28],0x7
   1400018c2:	mov    DWORD PTR [rsp+0x20],0x115
   1400018ca:	mov    r9,rsi
   1400018cd:	mov    r8,rdi
   1400018d0:	mov    rdx,r13
   1400018d3:	lea    rcx,[rbp-0x80]
   1400018d7:	call   0x14000f3ac
   1400018dc:	mov    rdx,rax
   1400018df:	lea    rcx,[rbp+0x30]
   1400018e3:	call   0x1400038ec
   1400018e8:	mov    DWORD PTR [rsp+0x20],eax
   1400018ec:	lea    r9,[rip+0x170b5]        # 0x1400189a8
   1400018f3:	mov    r8d,eax
   1400018f6:	lea    rcx,[rbp+0x30]
   1400018fa:	call   0x1400106b0
   1400018ff:	int3
   140001900:	int3
   140001901:	int3
   140001902:	int3
   140001903:	int3
   140001904:	int3
   140001905:	int3
   140001906:	int3
   140001907:	int3
   140001908:	mov    rax,rsp
   14000190b:	push   rbp
   14000190c:	push   r13
   14000190e:	push   r15
   140001910:	lea    rbp,[rax-0x168]
   140001917:	sub    rsp,0x250
   14000191e:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   140001929:	mov    QWORD PTR [rax+0x8],rbx
   14000192d:	mov    QWORD PTR [rax+0x20],rdi
   140001931:	mov    rax,QWORD PTR [rip+0x227e0]        # 0x140024118
   140001938:	xor    rax,rsp
   14000193b:	mov    QWORD PTR [rbp+0x140],rax
   140001942:	mov    rbx,r8
   140001945:	mov    rdi,rdx
   140001948:	lea    r13,[rip+0x16f21]        # 0x140018870
   14000194f:	mov    QWORD PTR [rbp-0x80],r13
   140001953:	lea    rax,[rip+0x170d6]        # 0x140018a30
   14000195a:	mov    QWORD PTR [rbp-0x78],rax
   14000195e:	lea    rax,[rip+0x16eeb]        # 0x140018850
   140001965:	mov    QWORD PTR [rbp-0x70],rax
   140001969:	mov    DWORD PTR [rbp-0x68],0x14e
   140001970:	mov    DWORD PTR [rbp-0x64],0x7
   140001977:	mov    DWORD PTR [rbp-0x60],0xff
   14000197e:	xor    r15d,r15d
   140001981:	mov    DWORD PTR [rbp+0x20],0x1000000
   140001988:	xor    edx,edx
   14000198a:	lea    r8d,[r15+0x78]
   14000198e:	lea    rcx,[rbp-0x58]
   140001992:	call   0x140015692
   140001997:	lea    rdx,[rbp-0x80]
   14000199b:	lea    rcx,[rbp+0x30]
   14000199f:	call   0x14000f85c
   1400019a4:	nop
   1400019a5:	mov    QWORD PTR [rsp+0x48],r15
   1400019aa:	movups xmm0,XMMWORD PTR [rip+0x176bf]        # 0x140019070
   1400019b1:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   1400019b7:	movups xmm1,XMMWORD PTR [rip+0x176a2]        # 0x140019060
   1400019be:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   1400019c4:	mov    QWORD PTR [rbp-0x80],r13
   1400019c8:	lea    rax,[rip+0x17061]        # 0x140018a30
   1400019cf:	mov    QWORD PTR [rbp-0x78],rax
   1400019d3:	lea    rax,[rip+0x16e76]        # 0x140018850
   1400019da:	mov    QWORD PTR [rbp-0x70],rax
   1400019de:	mov    DWORD PTR [rbp-0x68],0x153
   1400019e5:	mov    DWORD PTR [rbp-0x64],0x7
   1400019ec:	mov    DWORD PTR [rbp-0x60],0xff
   1400019f3:	mov    DWORD PTR [rbp+0x20],0x1000000
   1400019fa:	xor    edx,edx
   1400019fc:	lea    r8d,[r15+0x78]
   140001a00:	lea    rcx,[rbp-0x58]
   140001a04:	call   0x140015692
   140001a09:	lea    rax,[rsp+0x48]
   140001a0e:	mov    QWORD PTR [rsp+0x30],rax
   140001a13:	lea    rax,[rsp+0x60]
   140001a18:	mov    QWORD PTR [rsp+0x28],rax
   140001a1d:	lea    r9,[rip+0x16f24]        # 0x140018948
   140001a24:	lea    r8,[rsp+0x70]
   140001a29:	lea    rdx,[rbp-0x80]
   140001a2d:	lea    rcx,[rbp+0x30]
   140001a31:	call   0x140011460
   140001a36:	cmp    DWORD PTR [rbp+0x38],r15d
   140001a3a:	jl     0x140001bdf
   140001a40:	mov    QWORD PTR [rsp+0x40],r15
   140001a45:	movups xmm0,XMMWORD PTR [rip+0x16964]        # 0x1400183b0
   140001a4c:	movdqu XMMWORD PTR [rsp+0x70],xmm0
   140001a52:	mov    rcx,QWORD PTR [rsp+0x48]
   140001a57:	mov    rax,QWORD PTR [rcx]
   140001a5a:	lea    rdx,[rsp+0x40]
   140001a5f:	mov    QWORD PTR [rsp+0x20],rdx
   140001a64:	lea    r9d,[r15+0x4]
   140001a68:	lea    r8d,[r15+0x1]
   140001a6c:	lea    rdx,[rsp+0x70]
   140001a71:	mov    rax,QWORD PTR [rax+0x50]
   140001a75:	call   QWORD PTR [rip+0x1681d]        # 0x140018298
   140001a7b:	mov    DWORD PTR [rbp+0x38],eax
   140001a7e:	test   eax,eax
   140001a80:	js     0x140001c2d
   140001a86:	jmp    0x140001adf
   140001a88:	cmp    eax,0x1
   140001a8b:	je     0x140001b97
   140001a91:	mov    rcx,QWORD PTR [rbp+0xd8]
   140001a98:	rex.W call QWORD PTR [rip+0x165e1]        # 0x140018080
   140001a9f:	nop    DWORD PTR [rax+rax*1+0x0]
   140001aa4:	mov    QWORD PTR [rbp+0xd8],r15
   140001aab:	mov    rdx,rdi
   140001aae:	mov    rcx,QWORD PTR [rbp+0xc8]
   140001ab5:	rex.W call QWORD PTR [rip+0x167b4]        # 0x140018270
   140001abc:	nop    DWORD PTR [rax+rax*1+0x0]
   140001ac1:	mov    rcx,QWORD PTR [rbp+0xc8]
   140001ac8:	test   eax,eax
   140001aca:	je     0x140001b12
   140001acc:	rex.W call QWORD PTR [rip+0x165ad]        # 0x140018080
   140001ad3:	nop    DWORD PTR [rax+rax*1+0x0]
   140001ad8:	mov    QWORD PTR [rbp+0xc8],r15
   140001adf:	mov    rcx,QWORD PTR [rsp+0x40]
   140001ae4:	mov    rax,QWORD PTR [rcx]
   140001ae7:	lea    r9,[rsp+0x50]
   140001aec:	lea    r8,[rbp+0xb0]
   140001af3:	mov    edx,0x1
   140001af8:	mov    rax,QWORD PTR [rax+0x18]
   140001afc:	call   QWORD PTR [rip+0x16796]        # 0x140018298
   140001b02:	test   eax,eax
   140001b04:	mov    DWORD PTR [rbp+0x38],eax
   140001b07:	js     0x140001c7b
   140001b0d:	jmp    0x140001a88
   140001b12:	rex.W call QWORD PTR [rip+0x16567]        # 0x140018080
   140001b19:	nop    DWORD PTR [rax+rax*1+0x0]
   140001b1e:	mov    QWORD PTR [rbp+0xc8],r15
   140001b25:	movups xmm0,XMMWORD PTR [rbp+0xb8]
   140001b2c:	movdqu XMMWORD PTR [rbx],xmm0
   140001b30:	mov    rcx,QWORD PTR [rsp+0x40]
   140001b35:	test   rcx,rcx
   140001b38:	je     0x140001b48
   140001b3a:	mov    rax,QWORD PTR [rcx]
   140001b3d:	mov    rax,QWORD PTR [rax+0x10]
   140001b41:	call   QWORD PTR [rip+0x16751]        # 0x140018298
   140001b47:	nop
   140001b48:	mov    rcx,QWORD PTR [rsp+0x48]
   140001b4d:	test   rcx,rcx
   140001b50:	je     0x140001b60
   140001b52:	mov    rdx,QWORD PTR [rcx]
   140001b55:	mov    rax,QWORD PTR [rdx+0x10]
   140001b59:	call   QWORD PTR [rip+0x16739]        # 0x140018298
   140001b5f:	nop
   140001b60:	lea    rcx,[rbp+0x30]
   140001b64:	call   0x14000f958
   140001b69:	mov    eax,0x1
   140001b6e:	mov    rcx,QWORD PTR [rbp+0x140]
   140001b75:	xor    rcx,rsp
   140001b78:	call   0x1400143c0
   140001b7d:	lea    r11,[rsp+0x250]
   140001b85:	mov    rbx,QWORD PTR [r11+0x20]
   140001b89:	mov    rdi,QWORD PTR [r11+0x38]
   140001b8d:	mov    rsp,r11
   140001b90:	pop    r15
   140001b92:	pop    r13
   140001b94:	pop    rbp
   140001b95:	ret
   140001b96:	int3
   140001b97:	movups xmm0,XMMWORD PTR [rip+0x16812]        # 0x1400183b0
   140001b9e:	movdqu XMMWORD PTR [rbx],xmm0
   140001ba2:	mov    rcx,QWORD PTR [rsp+0x40]
   140001ba7:	test   rcx,rcx
   140001baa:	je     0x140001bba
   140001bac:	mov    rax,QWORD PTR [rcx]
   140001baf:	mov    rax,QWORD PTR [rax+0x10]
   140001bb3:	call   QWORD PTR [rip+0x166df]        # 0x140018298
   140001bb9:	nop
   140001bba:	mov    rcx,QWORD PTR [rsp+0x48]
   140001bbf:	test   rcx,rcx
   140001bc2:	je     0x140001bd2
   140001bc4:	mov    rax,QWORD PTR [rcx]
   140001bc7:	mov    rax,QWORD PTR [rax+0x10]
   140001bcb:	call   QWORD PTR [rip+0x166c7]        # 0x140018298
   140001bd1:	nop
   140001bd2:	lea    rcx,[rbp+0x30]
   140001bd6:	call   0x14000f958
   140001bdb:	xor    eax,eax
   140001bdd:	jmp    0x140001b6e
   140001bdf:	mov    DWORD PTR [rsp+0x28],0x7
   140001be7:	mov    DWORD PTR [rsp+0x20],0x15a
   140001bef:	lea    r9,[rip+0x16e3a]        # 0x140018a30
   140001bf6:	lea    r8,[rip+0x16c53]        # 0x140018850
   140001bfd:	mov    rdx,r13
   140001c00:	lea    rcx,[rbp-0x80]
   140001c04:	call   0x14000f3ac
   140001c09:	mov    rdx,rax
   140001c0c:	lea    rcx,[rbp+0x30]
   140001c10:	call   0x1400038ec
   140001c15:	mov    DWORD PTR [rsp+0x20],eax
   140001c19:	lea    r9,[rip+0x16d40]        # 0x140018960
   140001c20:	mov    r8d,eax
   140001c23:	lea    rcx,[rbp+0x30]
   140001c27:	call   0x1400106b0
   140001c2c:	nop
   140001c2d:	mov    DWORD PTR [rsp+0x28],0x7
   140001c35:	mov    DWORD PTR [rsp+0x20],0x162
   140001c3d:	lea    r9,[rip+0x16dec]        # 0x140018a30
   140001c44:	lea    r8,[rip+0x16c05]        # 0x140018850
   140001c4b:	mov    rdx,r13
   140001c4e:	lea    rcx,[rbp-0x80]
   140001c52:	call   0x14000f3ac
   140001c57:	mov    rdx,rax
   140001c5a:	lea    rcx,[rbp+0x30]
   140001c5e:	call   0x1400038ec
   140001c63:	mov    DWORD PTR [rsp+0x20],eax
   140001c67:	lea    r9,[rip+0x16d3a]        # 0x1400189a8
   140001c6e:	mov    r8d,eax
   140001c71:	lea    rcx,[rbp+0x30]
   140001c75:	call   0x1400106b0
   140001c7a:	int3
   140001c7b:	mov    DWORD PTR [rsp+0x28],0x7
   140001c83:	mov    DWORD PTR [rsp+0x20],0x16d
   140001c8b:	lea    r9,[rip+0x16d9e]        # 0x140018a30
   140001c92:	lea    r8,[rip+0x16bb7]        # 0x140018850
   140001c99:	mov    rdx,r13
   140001c9c:	lea    rcx,[rbp-0x80]
   140001ca0:	call   0x14000f3ac
   140001ca5:	mov    rdx,rax
   140001ca8:	lea    rcx,[rbp+0x30]
   140001cac:	call   0x1400038ec
   140001cb1:	mov    DWORD PTR [rsp+0x20],eax
   140001cb5:	lea    r9,[rip+0x16d2c]        # 0x1400189e8
   140001cbc:	mov    r8d,eax
   140001cbf:	lea    rcx,[rbp+0x30]
   140001cc3:	call   0x1400106b0
   140001cc8:	int3
   140001cc9:	int3
   140001cca:	int3
   140001ccb:	int3
   140001ccc:	int3
   140001ccd:	int3
   140001cce:	int3
   140001ccf:	int3
   140001cd0:	mov    rax,rsp
   140001cd3:	push   rbp
   140001cd4:	push   rdi
   140001cd5:	push   r12
   140001cd7:	push   r14
   140001cd9:	push   r15
   140001cdb:	lea    rbp,[rsp-0x70]
   140001ce0:	sub    rsp,0x170
   140001ce7:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   140001cef:	mov    QWORD PTR [rax+0x10],rbx
   140001cf3:	mov    QWORD PTR [rax+0x18],rsi
   140001cf7:	mov    rbx,rcx
   140001cfa:	lea    rdi,[rip+0x16b6f]        # 0x140018870
   140001d01:	mov    QWORD PTR [rsp+0x50],rdi
   140001d06:	lea    r14,[rip+0x16d6b]        # 0x140018a78
   140001d0d:	mov    QWORD PTR [rsp+0x58],r14
   140001d12:	lea    r15,[rip+0x16b37]        # 0x140018850
   140001d19:	mov    QWORD PTR [rsp+0x60],r15
   140001d1e:	mov    DWORD PTR [rsp+0x68],0x19b
   140001d26:	mov    r12d,0x7
   140001d2c:	mov    DWORD PTR [rsp+0x6c],r12d
   140001d31:	mov    DWORD PTR [rsp+0x70],0xff
   140001d39:	xor    esi,esi
   140001d3b:	mov    DWORD PTR [rbp-0x10],0x1000000
   140001d42:	xor    edx,edx
   140001d44:	lea    r8d,[r12+0x71]
   140001d49:	lea    rcx,[rsp+0x78]
   140001d4e:	call   0x140015692
   140001d53:	lea    rdx,[rsp+0x50]
   140001d58:	lea    rcx,[rbp+0x0]
   140001d5c:	call   0x14000f85c
   140001d61:	nop
   140001d62:	xor    ecx,ecx
   140001d64:	rex.W call QWORD PTR [rip+0x1621d]        # 0x140017f88
   140001d6b:	nop    DWORD PTR [rax+rax*1+0x0]
   140001d70:	mov    ecx,0xfffffff5
   140001d75:	rex.W call QWORD PTR [rip+0x16204]        # 0x140017f80
   140001d7c:	nop    DWORD PTR [rax+rax*1+0x0]
   140001d81:	mov    QWORD PTR [rbx+0x8],rax
   140001d85:	cmp    rax,0xffffffffffffffff
   140001d89:	je     0x140001ef5
   140001d8f:	xor    edx,edx
   140001d91:	xor    ecx,ecx
   140001d93:	rex.W call QWORD PTR [rip+0x162d6]        # 0x140018070
   140001d9a:	nop    DWORD PTR [rax+rax*1+0x0]
   140001d9f:	mov    DWORD PTR [rbp+0x8],eax
   140001da2:	test   eax,eax
   140001da4:	js     0x140001f5b
   140001daa:	mov    BYTE PTR [rbx+0xf0],0x1
   140001db1:	mov    QWORD PTR [rsp+0x40],rsi
   140001db6:	mov    DWORD PTR [rsp+0x38],esi
   140001dba:	mov    QWORD PTR [rsp+0x30],rsi
   140001dbf:	mov    DWORD PTR [rsp+0x28],0x2
   140001dc7:	mov    DWORD PTR [rsp+0x20],0x6
   140001dcf:	xor    r9d,r9d
   140001dd2:	xor    r8d,r8d
   140001dd5:	or     edx,0xffffffff
   140001dd8:	xor    ecx,ecx
   140001dda:	rex.W call QWORD PTR [rip+0x16287]        # 0x140018068
   140001de1:	nop    DWORD PTR [rax+rax*1+0x0]
   140001de6:	mov    DWORD PTR [rbp+0x8],eax
   140001de9:	test   eax,eax
   140001deb:	js     0x140001f9f
   140001df1:	mov    QWORD PTR [rsp+0x50],rdi
   140001df6:	mov    QWORD PTR [rsp+0x58],r14
   140001dfb:	mov    QWORD PTR [rsp+0x60],r15
   140001e00:	mov    DWORD PTR [rsp+0x68],0x1c6
   140001e08:	mov    DWORD PTR [rsp+0x6c],r12d
   140001e0d:	mov    DWORD PTR [rsp+0x70],0xff
   140001e15:	mov    DWORD PTR [rbp-0x10],0x1000000
   140001e1c:	xor    edx,edx
   140001e1e:	lea    r8d,[r12+0x71]
   140001e23:	lea    rcx,[rsp+0x78]
   140001e28:	call   0x140015692
   140001e2d:	lea    rdx,[rsp+0x50]
   140001e32:	lea    rcx,[rbp+0x0]
   140001e36:	call   0x1400116f0
   140001e3b:	call   0x1400032b0
   140001e40:	lea    rdx,[rip+0x16539]        # 0x140018380
   140001e47:	lea    ecx,[rsi+0x8]
   140001e4a:	cmp    DWORD PTR [rip+0x228bb],0xfffffff8        # 0x14002470c
   140001e51:	je     0x140001e66
   140001e53:	call   0x1400143f8
   140001e58:	test   rax,rax
   140001e5b:	je     0x140001e7c
   140001e5d:	lea    rcx,[rip+0x1520c]        # 0x140017070
   140001e64:	jmp    0x140001e77
   140001e66:	call   0x1400143f8
   140001e6b:	test   rax,rax
   140001e6e:	je     0x140001e7c
   140001e70:	lea    rcx,[rip+0x15269]        # 0x1400170e0
   140001e77:	mov    QWORD PTR [rax],rcx
   140001e7a:	jmp    0x140001e7f
   140001e7c:	mov    rax,rsi
   140001e7f:	mov    QWORD PTR [rbx],rax
   140001e82:	test   rax,rax
   140001e85:	je     0x140001ebb
   140001e87:	mov    edx,0x40002710
   140001e8c:	mov    rcx,rbx
   140001e8f:	call   0x14000c6f4
   140001e94:	nop
   140001e95:	lea    rcx,[rbp+0x0]
   140001e99:	call   0x14000f958
   140001e9e:	lea    r11,[rsp+0x170]
   140001ea6:	mov    rbx,QWORD PTR [r11+0x38]
   140001eaa:	mov    rsi,QWORD PTR [r11+0x40]
   140001eae:	mov    rsp,r11
   140001eb1:	pop    r15
   140001eb3:	pop    r14
   140001eb5:	pop    r12
   140001eb7:	pop    rdi
   140001eb8:	pop    rbp
   140001eb9:	ret
   140001eba:	int3
   140001ebb:	mov    DWORD PTR [rsp+0x28],r12d
   140001ec0:	mov    DWORD PTR [rsp+0x20],0x1d2
   140001ec8:	mov    r9,r14
   140001ecb:	mov    r8,r15
   140001ece:	mov    rdx,rdi
   140001ed1:	lea    rcx,[rsp+0x50]
   140001ed6:	call   0x14000f3ac
   140001edb:	lea    r9,[rip+0x16d16]        # 0x140018bf8
   140001ee2:	mov    r8d,0x8007000e
   140001ee8:	mov    rdx,rax
   140001eeb:	lea    rcx,[rbp+0x0]
   140001eef:	call   0x1400106b0
   140001ef4:	int3
   140001ef5:	mov    DWORD PTR [rsp+0x28],r12d
   140001efa:	mov    DWORD PTR [rsp+0x20],0x1a7
   140001f02:	mov    r9,r14
   140001f05:	mov    r8,r15
   140001f08:	mov    rdx,rdi
   140001f0b:	lea    rcx,[rsp+0x50]
   140001f10:	call   0x14000f3ac
   140001f15:	mov    rdi,rax
   140001f18:	rex.W call QWORD PTR [rip+0x16059]        # 0x140017f78
   140001f1f:	nop    DWORD PTR [rax+rax*1+0x0]
   140001f24:	mov    ebx,eax
   140001f26:	rex.W call QWORD PTR [rip+0x1604b]        # 0x140017f78
   140001f2d:	nop    DWORD PTR [rax+rax*1+0x0]
   140001f32:	movzx  r8d,bx
   140001f36:	or     r8d,0x80070000
   140001f3d:	test   ebx,ebx
   140001f3f:	cmovle r8d,ebx
   140001f43:	mov    DWORD PTR [rsp+0x20],eax
   140001f47:	lea    r9,[rip+0x16b62]        # 0x140018ab0
   140001f4e:	mov    rdx,rdi
   140001f51:	lea    rcx,[rbp+0x0]
   140001f55:	call   0x1400106b0
   140001f5a:	int3
   140001f5b:	mov    DWORD PTR [rsp+0x28],r12d
   140001f60:	mov    DWORD PTR [rsp+0x20],0x1af
   140001f68:	mov    r9,r14
   140001f6b:	mov    r8,r15
   140001f6e:	mov    rdx,rdi
   140001f71:	lea    rcx,[rsp+0x50]
   140001f76:	call   0x14000f3ac
   140001f7b:	mov    rdx,rax
   140001f7e:	lea    rcx,[rbp+0x0]
   140001f82:	call   0x1400038ec
   140001f87:	mov    DWORD PTR [rsp+0x20],eax
   140001f8b:	lea    r9,[rip+0x16b7e]        # 0x140018b10
   140001f92:	mov    r8d,eax
   140001f95:	lea    rcx,[rbp+0x0]
   140001f99:	call   0x1400106b0
   140001f9e:	int3
   140001f9f:	mov    DWORD PTR [rsp+0x28],r12d
   140001fa4:	mov    DWORD PTR [rsp+0x20],0x1c1
   140001fac:	mov    r9,r14
   140001faf:	mov    r8,r15
   140001fb2:	mov    rdx,rdi
   140001fb5:	lea    rcx,[rsp+0x50]
   140001fba:	call   0x14000f3ac
   140001fbf:	mov    rdx,rax
   140001fc2:	lea    rcx,[rbp+0x0]
   140001fc6:	call   0x1400038ec
   140001fcb:	mov    DWORD PTR [rsp+0x20],eax
   140001fcf:	lea    r9,[rip+0x16b9a]        # 0x140018b70
   140001fd6:	mov    r8d,eax
   140001fd9:	lea    rcx,[rbp+0x0]
   140001fdd:	call   0x1400106b0
   140001fe2:	int3
   140001fe3:	int3
   140001fe4:	int3
   140001fe5:	int3
   140001fe6:	int3
   140001fe7:	int3
   140001fe8:	int3
   140001fe9:	int3
   140001fea:	int3
   140001feb:	int3
   140001fec:	mov    rax,rsp
   140001fef:	push   rbp
   140001ff0:	push   rsi
   140001ff1:	push   rdi
   140001ff2:	push   r12
   140001ff4:	push   r13
   140001ff6:	push   r14
   140001ff8:	push   r15
   140001ffa:	lea    rbp,[rax-0x148]
   140002001:	sub    rsp,0x210
   140002008:	mov    QWORD PTR [rbp+0x60],0xfffffffffffffffe
   140002010:	mov    QWORD PTR [rax+0x8],rbx
   140002014:	mov    rsi,rcx
   140002017:	lea    r12,[rip+0x16852]        # 0x140018870
   14000201e:	mov    QWORD PTR [rsp+0x40],r12
   140002023:	lea    rdi,[rip+0x16bee]        # 0x140018c18
   14000202a:	mov    QWORD PTR [rsp+0x48],rdi
   14000202f:	lea    r14,[rip+0x1681a]        # 0x140018850
   140002036:	mov    QWORD PTR [rsp+0x50],r14
   14000203b:	mov    DWORD PTR [rsp+0x58],0x1e8
   140002043:	mov    DWORD PTR [rsp+0x5c],0x7
   14000204b:	mov    DWORD PTR [rsp+0x60],0xff
   140002053:	xor    r13d,r13d
   140002056:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000205d:	xor    edx,edx
   14000205f:	lea    r8d,[r13+0x78]
   140002063:	lea    rcx,[rsp+0x68]
   140002068:	call   0x140015692
   14000206d:	lea    rdx,[rsp+0x40]
   140002072:	lea    rcx,[rbp-0x10]
   140002076:	call   0x14000f85c
   14000207b:	nop
   14000207c:	mov    dl,0x1
   14000207e:	mov    rcx,rsi
   140002081:	call   0x14000c490
   140002086:	xor    edx,edx
   140002088:	mov    rcx,rsi
   14000208b:	call   0x14000c490
   140002090:	mov    rbx,rax
   140002093:	test   rax,rax
   140002096:	je     0x140002548
   14000209c:	cmp    WORD PTR [rax],0x2f
   1400020a0:	jne    0x1400020b4
   1400020a2:	cmp    WORD PTR [rax+0x2],0x3f
   1400020a7:	jne    0x1400020b4
   1400020a9:	cmp    WORD PTR [rax+0x4],r13w
   1400020ae:	je     0x140002275
   1400020b4:	cmp    WORD PTR [rax],0x2d
   1400020b8:	jne    0x1400020cc
   1400020ba:	cmp    WORD PTR [rax+0x2],0x3f
   1400020bf:	jne    0x1400020cc
   1400020c1:	cmp    WORD PTR [rax+0x4],r13w
   1400020c6:	je     0x140002275
   1400020cc:	xor    edx,edx
   1400020ce:	mov    rcx,rsi
   1400020d1:	call   0x14000c490
   1400020d6:	mov    r15,rax
   1400020d9:	test   rax,rax
   1400020dc:	je     0x140002548
   1400020e2:	mov    r14d,r13d
   1400020e5:	lea    rdi,[rip+0x151b4]        # 0x1400172a0
   1400020ec:	mov    eax,DWORD PTR [rdi+0x14]
   1400020ef:	test   DWORD PTR [rip+0x22617],eax        # 0x14002470c
   1400020f5:	je     0x140002116
   1400020f7:	mov    r8,QWORD PTR [rdi]
   1400020fa:	mov    rdx,rbx
   1400020fd:	call   0x14000c568
   140002102:	test   al,al
   140002104:	je     0x140002116
   140002106:	mov    r8,QWORD PTR [rdi+0x8]
   14000210a:	mov    rdx,r15
   14000210d:	call   0x14000c568
   140002112:	test   al,al
   140002114:	jne    0x140002129
   140002116:	inc    r14d
   140002119:	add    rdi,0x60
   14000211d:	lea    rax,[rip+0x159bc]        # 0x140017ae0
   140002124:	cmp    rdi,rax
   140002127:	jl     0x1400020ec
   140002129:	cmp    r14d,0x16
   14000212d:	je     0x140002584
   140002133:	mov    DWORD PTR [rsi+0x58],r14d
   140002137:	mov    DWORD PTR [rsi+0x60],r14d
   14000213b:	xor    edx,edx
   14000213d:	mov    rcx,rsi
   140002140:	call   0x14000c490
   140002145:	mov    rbx,rax
   140002148:	test   rax,rax
   14000214b:	je     0x14000229c
   140002151:	movzx  eax,WORD PTR [rbx]
   140002154:	sub    ax,0x2d
   140002158:	mov    ecx,0xfffd
   14000215d:	test   cx,ax
   140002160:	jne    0x1400026b3
   140002166:	add    rbx,0x2
   14000216a:	cmp    WORD PTR [rbx],0x3f
   14000216e:	je     0x140002275
   140002174:	mov    edx,0x3d
   140002179:	mov    rcx,rbx
   14000217c:	rex.W call QWORD PTR [rip+0x160dd]        # 0x140018260
   140002183:	nop    DWORD PTR [rax+rax*1+0x0]
   140002188:	mov    rdi,rax
   14000218b:	test   rax,rax
   14000218e:	je     0x140002198
   140002190:	mov    WORD PTR [rax],r13w
   140002194:	add    rdi,0x2
   140002198:	mov    r12d,r13d
   14000219b:	mov    r14,r13
   14000219e:	lea    r15,[rip+0x159a3]        # 0x140017b48
   1400021a5:	mov    r8,rbx
   1400021a8:	mov    rdx,QWORD PTR [r15]
   1400021ab:	call   0x14000c568
   1400021b0:	test   al,al
   1400021b2:	jne    0x1400021ca
   1400021b4:	inc    r12d
   1400021b7:	inc    r14
   1400021ba:	add    r15,0x18
   1400021be:	lea    rax,[rip+0x15ad3]        # 0x140017c98
   1400021c5:	cmp    r15,rax
   1400021c8:	jl     0x1400021a5
   1400021ca:	cmp    r12d,0xe
   1400021ce:	je     0x140002665
   1400021d4:	lea    rdx,[rsi+0x68]
   1400021d8:	lea    rdx,[rdx+r14*8]
   1400021dc:	cmp    QWORD PTR [rdx],r13
   1400021df:	jne    0x140002617
   1400021e5:	movsxd rax,DWORD PTR [rsi+0x60]
   1400021e9:	lea    rcx,[rax+rax*2]
   1400021ed:	lea    rax,[r14+rcx*8]
   1400021f1:	lea    r15,[rip+0x150a8]        # 0x1400172a0
   1400021f8:	cmp    DWORD PTR [r15+rax*4+0x24],r13d
   1400021fd:	je     0x1400025c9
   140002203:	lea    rax,[r14+r14*2]
   140002207:	lea    rcx,[rip+0x15942]        # 0x140017b50
   14000220e:	mov    ecx,DWORD PTR [rcx+rax*8]
   140002211:	test   ecx,ecx
   140002213:	jne    0x140002220
   140002215:	test   rdi,rdi
   140002218:	jne    0x1400024e7
   14000221e:	jmp    0x140002233
   140002220:	test   rdi,rdi
   140002223:	je     0x1400024e7
   140002229:	cmp    WORD PTR [rdi],r13w
   14000222d:	je     0x1400024e7
   140002233:	test   ecx,ecx
   140002235:	jne    0x140002240
   140002237:	lea    r8,[rip+0x16d1a]        # 0x140018f58
   14000223e:	jmp    0x14000224d
   140002240:	test   rdi,rdi
   140002243:	jne    0x14000224a
   140002245:	mov    QWORD PTR [rdx],r13
   140002248:	jmp    0x140002256
   14000224a:	mov    r8,rdi
   14000224d:	lea    rcx,[rbp-0x10]
   140002251:	call   0x140003688
   140002256:	xor    edx,edx
   140002258:	mov    rcx,rsi
   14000225b:	call   0x14000c490
   140002260:	mov    rbx,rax
   140002263:	test   rax,rax
   140002266:	jne    0x140002151
   14000226c:	lea    r12,[rip+0x165fd]        # 0x140018870
   140002273:	jmp    0x1400022a3
   140002275:	lea    rcx,[rbp-0x10]
   140002279:	call   0x14000f958
   14000227e:	xor    eax,eax
   140002280:	mov    rbx,QWORD PTR [rsp+0x250]
   140002288:	add    rsp,0x210
   14000228f:	pop    r15
   140002291:	pop    r14
   140002293:	pop    r13
   140002295:	pop    r12
   140002297:	pop    rdi
   140002298:	pop    rsi
   140002299:	pop    rbp
   14000229a:	ret
   14000229b:	int3
   14000229c:	lea    r15,[rip+0x14ffd]        # 0x1400172a0
   1400022a3:	mov    rdx,r13
   1400022a6:	lea    r8,[rsi+0x68]
   1400022aa:	cmp    QWORD PTR [r8],r13
   1400022ad:	jne    0x1400022c7
   1400022af:	movsxd rax,DWORD PTR [rsi+0x60]
   1400022b3:	lea    rcx,[rax+rax*2]
   1400022b7:	lea    rax,[rdx+rcx*8]
   1400022bb:	cmp    DWORD PTR [r15+rax*4+0x24],0x1
   1400022c1:	je     0x140002745
   1400022c7:	inc    rdx
   1400022ca:	add    r8,0x8
   1400022ce:	cmp    rdx,0xe
   1400022d2:	jl     0x1400022aa
   1400022d4:	mov    rcx,QWORD PTR [rsi+0x80]
   1400022db:	or     rbx,0xffffffffffffffff
   1400022df:	test   rcx,rcx
   1400022e2:	je     0x1400023c9
   1400022e8:	mov    rax,rbx
   1400022eb:	inc    rax
   1400022ee:	cmp    WORD PTR [rcx+rax*2],r13w
   1400022f3:	jne    0x1400022eb
   1400022f5:	cmp    WORD PTR [rcx+rax*2-0x2],0x5c
   1400022fb:	je     0x1400023c9
   140002301:	mov    rax,rbx
   140002304:	inc    rax
   140002307:	cmp    WORD PTR [rcx+rax*2],r13w
   14000230c:	jne    0x140002304
   14000230e:	add    eax,0x2
   140002311:	movsxd rdx,eax
   140002314:	add    rdx,rdx
   140002317:	rex.W call QWORD PTR [rip+0x15d42]        # 0x140018060
   14000231e:	nop    DWORD PTR [rax+rax*1+0x0]
   140002323:	mov    rdi,rax
   140002326:	test   rax,rax
   140002329:	je     0x1400026fc
   14000232f:	mov    rdx,rbx
   140002332:	inc    rdx
   140002335:	cmp    WORD PTR [rax+rdx*2],r13w
   14000233a:	jne    0x140002332
   14000233c:	add    rdx,0x2
   140002340:	lea    r8,[rip+0x16a91]        # 0x140018dd8
   140002347:	mov    rcx,rdi
   14000234a:	call   0x140003518
   14000234f:	mov    r14d,eax
   140002352:	mov    DWORD PTR [rbp-0x8],eax
   140002355:	mov    QWORD PTR [rsp+0x40],r12
   14000235a:	lea    r15,[rip+0x168b7]        # 0x140018c18
   140002361:	mov    QWORD PTR [rsp+0x48],r15
   140002366:	lea    rax,[rip+0x164e3]        # 0x140018850
   14000236d:	mov    QWORD PTR [rsp+0x50],rax
   140002372:	mov    DWORD PTR [rsp+0x58],0x286
   14000237a:	mov    DWORD PTR [rsp+0x5c],0x7
   140002382:	mov    DWORD PTR [rsp+0x60],0xff
   14000238a:	mov    DWORD PTR [rbp-0x20],0x1000000
   140002391:	xor    edx,edx
   140002393:	lea    r8d,[rdx+0x78]
   140002397:	lea    rcx,[rsp+0x68]
   14000239c:	call   0x140015692
   1400023a1:	lea    rax,[rsp+0x40]
   1400023a6:	mov    QWORD PTR [rbp+0x158],rax
   1400023ad:	test   r14d,r14d
   1400023b0:	js     0x14000278a
   1400023b6:	lea    rcx,[rsp+0x40]
   1400023bb:	call   0x14000f484
   1400023c0:	mov    QWORD PTR [rsi+0x80],rdi
   1400023c7:	jmp    0x1400023d0
   1400023c9:	lea    r15,[rip+0x16848]        # 0x140018c18
   1400023d0:	mov    rcx,QWORD PTR [rsi+0xa0]
   1400023d7:	test   rcx,rcx
   1400023da:	je     0x1400024af
   1400023e0:	mov    rax,rbx
   1400023e3:	inc    rax
   1400023e6:	cmp    WORD PTR [rcx+rax*2],r13w
   1400023eb:	jne    0x1400023e3
   1400023ed:	cmp    WORD PTR [rcx+rax*2-0x2],0x5c
   1400023f3:	je     0x1400024af
   1400023f9:	mov    rax,rbx
   1400023fc:	inc    rax
   1400023ff:	cmp    WORD PTR [rcx+rax*2],r13w
   140002404:	jne    0x1400023fc
   140002406:	add    eax,0x2
   140002409:	movsxd rdx,eax
   14000240c:	add    rdx,rdx
   14000240f:	rex.W call QWORD PTR [rip+0x15c4a]        # 0x140018060
   140002416:	nop    DWORD PTR [rax+rax*1+0x0]
   14000241b:	mov    rdi,rax
   14000241e:	test   rax,rax
   140002421:	je     0x1400027af
   140002427:	inc    rbx
   14000242a:	cmp    WORD PTR [rax+rbx*2],r13w
   14000242f:	jne    0x140002427
   140002431:	lea    rdx,[rbx+0x2]
   140002435:	lea    r8,[rip+0x1699c]        # 0x140018dd8
   14000243c:	mov    rcx,rdi
   14000243f:	call   0x140003518
   140002444:	mov    ebx,eax
   140002446:	mov    DWORD PTR [rbp-0x8],eax
   140002449:	mov    QWORD PTR [rsp+0x40],r12
   14000244e:	mov    QWORD PTR [rsp+0x48],r15
   140002453:	lea    rax,[rip+0x163f6]        # 0x140018850
   14000245a:	mov    QWORD PTR [rsp+0x50],rax
   14000245f:	mov    DWORD PTR [rsp+0x58],0x293
   140002467:	mov    DWORD PTR [rsp+0x5c],0x7
   14000246f:	mov    DWORD PTR [rsp+0x60],0xff
   140002477:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000247e:	xor    edx,edx
   140002480:	lea    r8d,[rdx+0x78]
   140002484:	lea    rcx,[rsp+0x68]
   140002489:	call   0x140015692
   14000248e:	lea    rax,[rsp+0x40]
   140002493:	mov    QWORD PTR [rbp+0x158],rax
   14000249a:	test   ebx,ebx
   14000249c:	js     0x1400024c2
   14000249e:	lea    rcx,[rsp+0x40]
   1400024a3:	call   0x14000f484
   1400024a8:	mov    QWORD PTR [rsi+0xa0],rdi
   1400024af:	lea    rcx,[rbp-0x10]
   1400024b3:	call   0x14000f958
   1400024b8:	mov    eax,0x1
   1400024bd:	jmp    0x140002280
   1400024c2:	lea    rdx,[rsp+0x40]
   1400024c7:	lea    rcx,[rbp+0x68]
   1400024cb:	call   0x14000f400
   1400024d0:	lea    r9,[rip+0x16909]        # 0x140018de0
   1400024d7:	mov    r8d,ebx
   1400024da:	mov    rdx,rax
   1400024dd:	lea    rcx,[rbp-0x10]
   1400024e1:	call   0x140010848
   1400024e6:	nop
   1400024e7:	mov    DWORD PTR [rsp+0x28],0x7
   1400024ef:	mov    DWORD PTR [rsp+0x20],0x259
   1400024f7:	lea    r9,[rip+0x1671a]        # 0x140018c18
   1400024fe:	lea    r8,[rip+0x1634b]        # 0x140018850
   140002505:	lea    rdx,[rip+0x16364]        # 0x140018870
   14000250c:	lea    rcx,[rsp+0x40]
   140002511:	call   0x14000f3ac
   140002516:	mov    rdx,rax
   140002519:	lea    rax,[rip+0x16830]        # 0x140018d50
   140002520:	test   rdi,rdi
   140002523:	cmovne rax,rdi
   140002527:	mov    QWORD PTR [rsp+0x28],rax
   14000252c:	mov    QWORD PTR [rsp+0x20],rbx
   140002531:	lea    r9,[rip+0x16830]        # 0x140018d68
   140002538:	mov    r8d,0x1004
   14000253e:	lea    rcx,[rbp-0x10]
   140002542:	call   0x1400106b0
   140002547:	int3
   140002548:	mov    DWORD PTR [rsp+0x28],0x7
   140002550:	mov    DWORD PTR [rsp+0x20],0x1f9
   140002558:	mov    r9,rdi
   14000255b:	mov    r8,r14
   14000255e:	mov    rdx,r12
   140002561:	lea    rcx,[rbp+0x68]
   140002565:	call   0x14000f3ac
   14000256a:	lea    r9,[rip+0x166df]        # 0x140018c50
   140002571:	mov    r8d,0x1002
   140002577:	mov    rdx,rax
   14000257a:	lea    rcx,[rbp-0x10]
   14000257e:	call   0x1400106b0
   140002583:	int3
   140002584:	mov    DWORD PTR [rsp+0x28],0x7
   14000258c:	mov    DWORD PTR [rsp+0x20],0x20e
   140002594:	lea    r9,[rip+0x1667d]        # 0x140018c18
   14000259b:	lea    r8,[rip+0x162ae]        # 0x140018850
   1400025a2:	mov    rdx,r12
   1400025a5:	lea    rcx,[rsp+0x40]
   1400025aa:	call   0x14000f3ac
   1400025af:	lea    r9,[rip+0x166c2]        # 0x140018c78
   1400025b6:	mov    r8d,0x1002
   1400025bc:	mov    rdx,rax
   1400025bf:	lea    rcx,[rbp-0x10]
   1400025c3:	call   0x1400106b0
   1400025c8:	int3
   1400025c9:	mov    DWORD PTR [rsp+0x28],0x7
   1400025d1:	mov    DWORD PTR [rsp+0x20],0x252
   1400025d9:	lea    r9,[rip+0x16638]        # 0x140018c18
   1400025e0:	lea    r8,[rip+0x16269]        # 0x140018850
   1400025e7:	lea    rdx,[rip+0x16282]        # 0x140018870
   1400025ee:	lea    rcx,[rsp+0x40]
   1400025f3:	call   0x14000f3ac
   1400025f8:	mov    QWORD PTR [rsp+0x20],rbx
   1400025fd:	lea    r9,[rip+0x166fc]        # 0x140018d00
   140002604:	mov    r8d,0x1006
   14000260a:	mov    rdx,rax
   14000260d:	lea    rcx,[rbp-0x10]
   140002611:	call   0x1400106b0
   140002616:	int3
   140002617:	mov    DWORD PTR [rsp+0x28],0x7
   14000261f:	mov    DWORD PTR [rsp+0x20],0x24c
   140002627:	lea    r9,[rip+0x165ea]        # 0x140018c18
   14000262e:	lea    r8,[rip+0x1621b]        # 0x140018850
   140002635:	lea    rdx,[rip+0x16234]        # 0x140018870
   14000263c:	lea    rcx,[rsp+0x40]
   140002641:	call   0x14000f3ac
   140002646:	mov    QWORD PTR [rsp+0x20],rbx
   14000264b:	lea    r9,[rip+0x1666e]        # 0x140018cc0
   140002652:	mov    r8d,0x1005
   140002658:	mov    rdx,rax
   14000265b:	lea    rcx,[rbp-0x10]
   14000265f:	call   0x1400106b0
   140002664:	int3
   140002665:	mov    DWORD PTR [rsp+0x28],0x7
   14000266d:	mov    DWORD PTR [rsp+0x20],0x246
   140002675:	lea    r9,[rip+0x1659c]        # 0x140018c18
   14000267c:	lea    r8,[rip+0x161cd]        # 0x140018850
   140002683:	lea    rdx,[rip+0x161e6]        # 0x140018870
   14000268a:	lea    rcx,[rsp+0x40]
   14000268f:	call   0x14000f3ac
   140002694:	mov    QWORD PTR [rsp+0x20],rbx
   140002699:	lea    r9,[rip+0x165f8]        # 0x140018c98
   1400026a0:	mov    r8d,0x1003
   1400026a6:	mov    rdx,rax
   1400026a9:	lea    rcx,[rbp-0x10]
   1400026ad:	call   0x1400106b0
   1400026b2:	int3
   1400026b3:	mov    DWORD PTR [rsp+0x28],0x7
   1400026bb:	mov    DWORD PTR [rsp+0x20],0x26a
   1400026c3:	lea    r9,[rip+0x1654e]        # 0x140018c18
   1400026ca:	lea    r8,[rip+0x1617f]        # 0x140018850
   1400026d1:	lea    rdx,[rip+0x16198]        # 0x140018870
   1400026d8:	lea    rcx,[rsp+0x40]
   1400026dd:	call   0x14000f3ac
   1400026e2:	lea    r9,[rip+0x1658f]        # 0x140018c78
   1400026e9:	mov    r8d,0x1002
   1400026ef:	mov    rdx,rax
   1400026f2:	lea    rcx,[rbp-0x10]
   1400026f6:	call   0x1400106b0
   1400026fb:	int3
   1400026fc:	mov    DWORD PTR [rsp+0x28],0xb
   140002704:	mov    DWORD PTR [rsp+0x20],0x85
   14000270c:	lea    r9,[rip+0x1681d]        # 0x140018f30
   140002713:	lea    r8,[rip+0x168f6]        # 0x140019010
   14000271a:	lea    rdx,[rip+0x168ff]        # 0x140019020
   140002721:	lea    rcx,[rsp+0x40]
   140002726:	call   0x14000f3ac
   14000272b:	lea    r9,[rip+0x16836]        # 0x140018f68
   140002732:	mov    r8d,0x8007000e
   140002738:	mov    rdx,rax
   14000273b:	lea    rcx,[rbp-0x10]
   14000273f:	call   0x1400106b0
   140002744:	int3
   140002745:	mov    DWORD PTR [rsp+0x28],0x7
   14000274d:	mov    DWORD PTR [rsp+0x20],0x275
   140002755:	lea    r9,[rip+0x164bc]        # 0x140018c18
   14000275c:	lea    r8,[rip+0x160ed]        # 0x140018850
   140002763:	mov    rdx,r12
   140002766:	lea    rcx,[rsp+0x40]
   14000276b:	call   0x14000f3ac
   140002770:	lea    r9,[rip+0x16631]        # 0x140018da8
   140002777:	mov    r8d,0x1007
   14000277d:	mov    rdx,rax
   140002780:	lea    rcx,[rbp-0x10]
   140002784:	call   0x1400106b0
   140002789:	nop
   14000278a:	lea    rdx,[rsp+0x40]
   14000278f:	lea    rcx,[rbp+0x68]
   140002793:	call   0x14000f400
   140002798:	lea    r9,[rip+0x16641]        # 0x140018de0
   14000279f:	mov    r8d,r14d
   1400027a2:	mov    rdx,rax
   1400027a5:	lea    rcx,[rbp-0x10]
   1400027a9:	call   0x140010848
   1400027ae:	nop
   1400027af:	mov    DWORD PTR [rsp+0x28],0xb
   1400027b7:	mov    DWORD PTR [rsp+0x20],0x85
   1400027bf:	lea    r9,[rip+0x1676a]        # 0x140018f30
   1400027c6:	lea    r8,[rip+0x16843]        # 0x140019010
   1400027cd:	lea    rdx,[rip+0x1684c]        # 0x140019020
   1400027d4:	lea    rcx,[rbp+0x68]
   1400027d8:	call   0x14000f3ac
   1400027dd:	lea    r9,[rip+0x16784]        # 0x140018f68
   1400027e4:	mov    r8d,0x8007000e
   1400027ea:	mov    rdx,rax
   1400027ed:	lea    rcx,[rbp-0x10]
   1400027f1:	call   0x1400106b0
   1400027f6:	int3
   1400027f7:	int3
   1400027f8:	int3
   1400027f9:	int3
   1400027fa:	int3
   1400027fb:	int3
   1400027fc:	int3
   1400027fd:	int3
   1400027fe:	int3
   1400027ff:	int3
   140002800:	mov    rax,rsp
   140002803:	push   rbp
   140002804:	push   r14
   140002806:	push   r15
   140002808:	lea    rbp,[rax-0x78]
   14000280c:	sub    rsp,0x160
   140002813:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000281c:	mov    QWORD PTR [rax+0x10],rbx
   140002820:	mov    QWORD PTR [rax+0x18],rsi
   140002824:	mov    QWORD PTR [rax+0x20],rdi
   140002828:	mov    rbx,rcx
   14000282b:	lea    rsi,[rip+0x1603e]        # 0x140018870
   140002832:	mov    QWORD PTR [rsp+0x48],rsi
   140002837:	lea    r14,[rip+0x165c2]        # 0x140018e00
   14000283e:	mov    QWORD PTR [rsp+0x50],r14
   140002843:	lea    r15,[rip+0x16006]        # 0x140018850
   14000284a:	mov    QWORD PTR [rsp+0x58],r15
   14000284f:	mov    DWORD PTR [rsp+0x60],0x29f
   140002857:	mov    DWORD PTR [rsp+0x64],0x7
   14000285f:	mov    DWORD PTR [rsp+0x68],0xff
   140002867:	mov    DWORD PTR [rbp-0x18],0x1000000
   14000286e:	xor    edx,edx
   140002870:	lea    r8d,[rdx+0x78]
   140002874:	lea    rcx,[rsp+0x70]
   140002879:	call   0x140015692
   14000287e:	lea    rdx,[rsp+0x48]
   140002883:	lea    rcx,[rbp-0x10]
   140002887:	call   0x14000f85c
   14000288c:	nop
   14000288d:	mov    ecx,DWORD PTR [rbx+0x60]
   140002890:	cmp    ecx,0xb
   140002893:	jg     0x140002913
   140002895:	cmp    ecx,0xa
   140002898:	jge    0x140002909
   14000289a:	cmp    ecx,0x7
   14000289d:	jg     0x1400028e7
   14000289f:	cmp    ecx,0x6
   1400028a2:	jge    0x1400028da
   1400028a4:	test   ecx,ecx
   1400028a6:	js     0x140002990
   1400028ac:	cmp    ecx,0x1
   1400028af:	jle    0x1400028cd
   1400028b1:	cmp    ecx,0x3
   1400028b4:	mov    rcx,rbx
   1400028b7:	jle    0x1400028c3
   1400028b9:	call   0x140009ba8
   1400028be:	jmp    0x140002969
   1400028c3:	call   0x1400057c8
   1400028c8:	jmp    0x140002969
   1400028cd:	mov    rcx,rbx
   1400028d0:	call   0x14000553c
   1400028d5:	jmp    0x140002969
   1400028da:	mov    rcx,rbx
   1400028dd:	call   0x140009744
   1400028e2:	jmp    0x140002969
   1400028e7:	sub    ecx,0x8
   1400028ea:	je     0x1400028ff
   1400028ec:	cmp    ecx,0x1
   1400028ef:	jne    0x140002990
   1400028f5:	mov    rcx,rbx
   1400028f8:	call   0x140007e44
   1400028fd:	jmp    0x140002969
   1400028ff:	mov    rcx,rbx
   140002902:	call   0x14000ab58
   140002907:	jmp    0x140002969
   140002909:	mov    rcx,rbx
   14000290c:	call   0x140006bbc
   140002911:	jmp    0x140002969
   140002913:	cmp    ecx,0x12
   140002916:	jg     0x14000294c
   140002918:	cmp    ecx,0x11
   14000291b:	jge    0x140002942
   14000291d:	cmp    ecx,0xd
   140002920:	jle    0x140002938
   140002922:	cmp    ecx,0xf
   140002925:	mov    rcx,rbx
   140002928:	jle    0x140002931
   14000292a:	call   0x140007510
   14000292f:	jmp    0x140002969
   140002931:	call   0x1400082b8
   140002936:	jmp    0x140002969
   140002938:	mov    rcx,rbx
   14000293b:	call   0x140006468
   140002940:	jmp    0x140002969
   140002942:	mov    rcx,rbx
   140002945:	call   0x1400086e4
   14000294a:	jmp    0x140002969
   14000294c:	cmp    ecx,0x14
   14000294f:	jle    0x140002960
   140002951:	cmp    ecx,0x15
   140002954:	jne    0x140002990
   140002956:	mov    rcx,rbx
   140002959:	call   0x140008f20
   14000295e:	jmp    0x140002969
   140002960:	mov    rcx,rbx
   140002963:	call   0x140008974
   140002968:	nop
   140002969:	lea    rcx,[rbp-0x10]
   14000296d:	call   0x14000f958
   140002972:	lea    r11,[rsp+0x160]
   14000297a:	mov    rbx,QWORD PTR [r11+0x28]
   14000297e:	mov    rsi,QWORD PTR [r11+0x30]
   140002982:	mov    rdi,QWORD PTR [r11+0x38]
   140002986:	mov    rsp,r11
   140002989:	pop    r15
   14000298b:	pop    r14
   14000298d:	pop    rbp
   14000298e:	ret
   14000298f:	int3
   140002990:	mov    DWORD PTR [rsp+0x28],0x1
   140002998:	mov    DWORD PTR [rsp+0x20],0x2e1
   1400029a0:	mov    r9,r14
   1400029a3:	mov    r8,r15
   1400029a6:	mov    rdx,rsi
   1400029a9:	lea    rcx,[rsp+0x48]
   1400029ae:	call   0x14000f3ac
   1400029b3:	mov    ecx,DWORD PTR [rbx+0x58]
   1400029b6:	mov    DWORD PTR [rsp+0x20],ecx
   1400029ba:	lea    r9,[rip+0x16477]        # 0x140018e38
   1400029c1:	mov    r8d,0x8000ffff
   1400029c7:	mov    rdx,rax
   1400029ca:	lea    rcx,[rbp-0x10]
   1400029ce:	call   0x1400106b0
   1400029d3:	int3
   1400029d4:	int3
   1400029d5:	int3
   1400029d6:	int3
   1400029d7:	int3
   1400029d8:	int3
   1400029d9:	int3
   1400029da:	int3
   1400029db:	int3
   1400029dc:	mov    r11,rsp
   1400029df:	push   r15
   1400029e1:	sub    rsp,0x560
   1400029e8:	mov    QWORD PTR [r11-0x3e8],0xfffffffffffffffe
   1400029f3:	mov    QWORD PTR [r11+0x8],rbx
   1400029f7:	mov    QWORD PTR [r11+0x10],rsi
   1400029fb:	mov    QWORD PTR [r11+0x18],rdi
   1400029ff:	mov    QWORD PTR [r11+0x20],r14
   140002a03:	mov    rax,QWORD PTR [rip+0x2170e]        # 0x140024118
   140002a0a:	xor    rax,rsp
   140002a0d:	mov    QWORD PTR [rsp+0x550],rax
   140002a15:	mov    rsi,rdx
   140002a18:	mov    r14d,ecx
   140002a1b:	lea    rax,[rip+0x15e4e]        # 0x140018870
   140002a22:	mov    QWORD PTR [r11-0xc8],rax
   140002a29:	lea    rax,[rip+0x16440]        # 0x140018e70
   140002a30:	mov    QWORD PTR [r11-0xc0],rax
   140002a37:	lea    rax,[rip+0x15e12]        # 0x140018850
   140002a3e:	mov    QWORD PTR [r11-0xb8],rax
   140002a45:	mov    DWORD PTR [rsp+0x4b8],0x309
   140002a50:	mov    ebx,0x7
   140002a55:	mov    DWORD PTR [rsp+0x4bc],ebx
   140002a5c:	mov    DWORD PTR [rsp+0x4c0],0xff
   140002a67:	xor    edi,edi
   140002a69:	mov    DWORD PTR [r11-0x28],0x1000000
   140002a71:	xor    edx,edx
   140002a73:	lea    r8d,[rbx+0x71]
   140002a77:	lea    rcx,[r11-0xa0]
   140002a7e:	call   0x140015692
   140002a83:	lea    rdx,[rsp+0x4a0]
   140002a8b:	lea    rcx,[rsp+0x60]
   140002a90:	call   0x14000f85c
   140002a95:	nop
   140002a96:	lea    ebx,[rdi+0x2]
   140002a99:	mov    DWORD PTR [rsp+0x48],ebx
   140002a9d:	xor    r9d,r9d
   140002aa0:	xor    r8d,r8d
   140002aa3:	lea    edx,[rdi+0x1]
   140002aa6:	xor    ecx,ecx
   140002aa8:	rex.W call QWORD PTR [rip+0x154c1]        # 0x140017f70
   140002aaf:	nop    DWORD PTR [rax+rax*1+0x0]
   140002ab4:	nop
   140002ab5:	xorps  xmm0,xmm0
   140002ab8:	movdqa XMMWORD PTR [rsp+0x3b0],xmm0
   140002ac1:	mov    DWORD PTR [rsp+0x3c0],edi
   140002ac8:	mov    QWORD PTR [rsp+0x3c8],rdi
   140002ad0:	mov    QWORD PTR [rsp+0x3d0],rdi
   140002ad8:	mov    DWORD PTR [rsp+0x3d8],edi
   140002adf:	mov    DWORD PTR [rsp+0x400],0x17
   140002aea:	xor    edx,edx
   140002aec:	lea    r8d,[rdi+0x70]
   140002af0:	lea    rcx,[rsp+0x408]
   140002af8:	call   0x140015692
   140002afd:	mov    DWORD PTR [rsp+0x3ec],r14d
   140002b05:	mov    QWORD PTR [rsp+0x3f0],rsi
   140002b0d:	mov    QWORD PTR [rsp+0x478],rdi
   140002b15:	movups xmm0,XMMWORD PTR [rip+0x15894]        # 0x1400183b0
   140002b1c:	movdqu XMMWORD PTR [rsp+0x480],xmm0
   140002b25:	mov    DWORD PTR [rsp+0x3e8],ebx
   140002b2c:	or     QWORD PTR [rsp+0x3a8],0xffffffffffffffff
   140002b35:	mov    QWORD PTR [rsp+0x3e0],rdi
   140002b3d:	mov    QWORD PTR [rsp+0x3a0],rdi
   140002b45:	mov    BYTE PTR [rsp+0x490],dil
   140002b4d:	lea    rcx,[rsp+0x3a0]
   140002b55:	call   0x140001cd0
   140002b5a:	lea    rcx,[rsp+0x3a0]
   140002b62:	call   0x140001fec
   140002b67:	lea    rcx,[rsp+0x3a0]
   140002b6f:	test   eax,eax
   140002b71:	je     0x140002b7a
   140002b73:	call   0x140002800
   140002b78:	jmp    0x140002b7f
   140002b7a:	call   0x1400051f4
   140002b7f:	mov    DWORD PTR [rsp+0x68],edi
   140002b83:	mov    eax,DWORD PTR [rsp+0x3e8]
   140002b8a:	mov    DWORD PTR [rsp+0x48],eax
   140002b8e:	jmp    0x140003194
   140002b93:	mov    eax,DWORD PTR [rsp+0x3e8]
   140002b9a:	mov    DWORD PTR [rsp+0x48],eax
   140002b9e:	mov    ecx,DWORD PTR [rsp+0x68]
   140002ba2:	xor    edi,edi
   140002ba4:	test   ecx,ecx
   140002ba6:	je     0x140003194
   140002bac:	mov    eax,DWORD PTR [rsp+0x3f8]
   140002bb3:	add    eax,0xfffffffe
   140002bb6:	cmp    eax,0x1
   140002bb9:	ja     0x14000308e
   140002bbf:	lea    eax,[rcx-0x1001]
   140002bc5:	lea    ebx,[rdi+0x7]
   140002bc8:	cmp    eax,ebx
   140002bca:	jbe    0x14000308e
   140002bd0:	mov    r14d,0x40002b63
   140002bd6:	mov    r8d,r14d
   140002bd9:	xor    edx,edx
   140002bdb:	lea    rcx,[rsp+0x3a0]
   140002be3:	call   0x14000c86c
   140002be8:	mov    rsi,rax
   140002beb:	test   rax,rax
   140002bee:	je     0x1400031e5
   140002bf4:	jmp    0x140002bfa
   140002bf6:	jmp    0x140002b93
   140002bf8:	jmp    0x140002b93
   140002bfa:	mov    QWORD PTR [rsp+0x40],rdi
   140002bff:	lea    rdx,[rsp+0x50]
   140002c04:	mov    ecx,DWORD PTR [rsp+0x68]
   140002c08:	call   0x14000ddd4
   140002c0d:	test   eax,eax
   140002c0f:	je     0x140002d2e
   140002c15:	mov    r14d,DWORD PTR [rsp+0x50]
   140002c1a:	mov    r8d,r14d
   140002c1d:	xor    edx,edx
   140002c1f:	lea    rcx,[rsp+0x3a0]
   140002c27:	call   0x14000c86c
   140002c2c:	mov    r15,rax
   140002c2f:	test   rax,rax
   140002c32:	je     0x140003245
   140002c38:	lea    rax,[rip+0x15c31]        # 0x140018870
   140002c3f:	mov    QWORD PTR [rsp+0x4a0],rax
   140002c47:	lea    rax,[rip+0x16222]        # 0x140018e70
   140002c4e:	mov    QWORD PTR [rsp+0x4a8],rax
   140002c56:	lea    rax,[rip+0x15bf3]        # 0x140018850
   140002c5d:	mov    QWORD PTR [rsp+0x4b0],rax
   140002c65:	mov    DWORD PTR [rsp+0x4b8],0x348
   140002c70:	mov    DWORD PTR [rsp+0x4bc],ebx
   140002c77:	mov    DWORD PTR [rsp+0x4c0],0xff
   140002c82:	mov    DWORD PTR [rsp+0x540],0x1000000
   140002c8d:	xor    edx,edx
   140002c8f:	lea    r8d,[rdx+0x78]
   140002c93:	lea    rcx,[rsp+0x4c8]
   140002c9b:	call   0x140015692
   140002ca0:	mov    r8,rsi
   140002ca3:	lea    rdx,[rsp+0x250]
   140002cab:	lea    rcx,[rsp+0x4a0]
   140002cb3:	call   0x14000f744
   140002cb8:	mov    r8,r15
   140002cbb:	lea    rdx,[rsp+0x1a8]
   140002cc3:	mov    rcx,rax
   140002cc6:	call   0x14000f744
   140002ccb:	mov    rbx,rax
   140002cce:	rex.W call QWORD PTR [rip+0x15293]        # 0x140017f68
   140002cd5:	nop    DWORD PTR [rax+rax*1+0x0]
   140002cda:	mov    r8,rax
   140002cdd:	lea    rdx,[rsp+0xd8]
   140002ce5:	mov    rcx,rbx
   140002ce8:	call   0x14000f744
   140002ced:	mov    r8,rax
   140002cf0:	mov    edx,0x1b59
   140002cf5:	lea    rcx,[rsp+0x60]
   140002cfa:	call   0x140011870
   140002cff:	lea    rcx,[rsp+0x1a8]
   140002d07:	call   0x14000f484
   140002d0c:	lea    rcx,[rsp+0x250]
   140002d14:	call   0x14000f484
   140002d19:	lea    rcx,[rsp+0x4a0]
   140002d21:	call   0x14000f484
   140002d26:	mov    rcx,r15
   140002d29:	jmp    0x140002f59
   140002d2e:	lea    rdx,[rsp+0x40]
   140002d33:	mov    ecx,DWORD PTR [rsp+0x68]
   140002d37:	call   0x14000e164
   140002d3c:	xor    edx,edx
   140002d3e:	test   eax,eax
   140002d40:	je     0x140002e4a
   140002d46:	lea    rax,[rip+0x15b23]        # 0x140018870
   140002d4d:	mov    QWORD PTR [rsp+0x4a0],rax
   140002d55:	lea    rax,[rip+0x16114]        # 0x140018e70
   140002d5c:	mov    QWORD PTR [rsp+0x4a8],rax
   140002d64:	lea    rax,[rip+0x15ae5]        # 0x140018850
   140002d6b:	mov    QWORD PTR [rsp+0x4b0],rax
   140002d73:	mov    DWORD PTR [rsp+0x4b8],0x34e
   140002d7e:	mov    DWORD PTR [rsp+0x4bc],ebx
   140002d85:	mov    DWORD PTR [rsp+0x4c0],0xff
   140002d90:	mov    DWORD PTR [rsp+0x540],0x1000000
   140002d9b:	lea    r8d,[rdx+0x78]
   140002d9f:	lea    rcx,[rsp+0x4c8]
   140002da7:	call   0x140015692
   140002dac:	mov    r8,rsi
   140002daf:	lea    rdx,[rsp+0xd8]
   140002db7:	lea    rcx,[rsp+0x4a0]
   140002dbf:	call   0x14000f744
   140002dc4:	mov    r8,QWORD PTR [rsp+0x40]
   140002dc9:	lea    rdx,[rsp+0x1a8]
   140002dd1:	mov    rcx,rax
   140002dd4:	call   0x14000f744
   140002dd9:	mov    rbx,rax
   140002ddc:	rex.W call QWORD PTR [rip+0x15185]        # 0x140017f68
   140002de3:	nop    DWORD PTR [rax+rax*1+0x0]
   140002de8:	mov    r8,rax
   140002deb:	lea    rdx,[rsp+0x250]
   140002df3:	mov    rcx,rbx
   140002df6:	call   0x14000f744
   140002dfb:	mov    r8,rax
   140002dfe:	mov    edx,0x1b59
   140002e03:	lea    rcx,[rsp+0x60]
   140002e08:	call   0x140011870
   140002e0d:	lea    rcx,[rsp+0x1a8]
   140002e15:	call   0x14000f484
   140002e1a:	lea    rcx,[rsp+0xd8]
   140002e22:	call   0x14000f484
   140002e27:	lea    rcx,[rsp+0x4a0]
   140002e2f:	call   0x14000f484
   140002e34:	mov    rcx,QWORD PTR [rsp+0x40]
   140002e39:	rex.W call QWORD PTR [rip+0x15120]        # 0x140017f60
   140002e40:	nop    DWORD PTR [rax+rax*1+0x0]
   140002e45:	jmp    0x14000307b
   140002e4a:	mov    r8d,DWORD PTR [rsp+0x68]
   140002e4f:	lea    rcx,[rsp+0x3a0]
   140002e57:	call   0x14000c86c
   140002e5c:	mov    r14,rax
   140002e5f:	test   rax,rax
   140002e62:	je     0x140002f6a
   140002e68:	lea    rax,[rip+0x15a01]        # 0x140018870
   140002e6f:	mov    QWORD PTR [rsp+0x4a0],rax
   140002e77:	lea    rax,[rip+0x15ff2]        # 0x140018e70
   140002e7e:	mov    QWORD PTR [rsp+0x4a8],rax
   140002e86:	lea    rax,[rip+0x159c3]        # 0x140018850
   140002e8d:	mov    QWORD PTR [rsp+0x4b0],rax
   140002e95:	mov    DWORD PTR [rsp+0x4b8],0x357
   140002ea0:	mov    DWORD PTR [rsp+0x4bc],ebx
   140002ea7:	mov    DWORD PTR [rsp+0x4c0],0xff
   140002eb2:	mov    DWORD PTR [rsp+0x540],0x1000000
   140002ebd:	xor    edx,edx
   140002ebf:	lea    r8d,[rdx+0x78]
   140002ec3:	lea    rcx,[rsp+0x4c8]
   140002ecb:	call   0x140015692
   140002ed0:	mov    r8,rsi
   140002ed3:	lea    rdx,[rsp+0xd8]
   140002edb:	lea    rcx,[rsp+0x4a0]
   140002ee3:	call   0x14000f744
   140002ee8:	mov    r8,r14
   140002eeb:	lea    rdx,[rsp+0x1a8]
   140002ef3:	mov    rcx,rax
   140002ef6:	call   0x14000f744
   140002efb:	mov    rbx,rax
   140002efe:	rex.W call QWORD PTR [rip+0x15063]        # 0x140017f68
   140002f05:	nop    DWORD PTR [rax+rax*1+0x0]
   140002f0a:	mov    r8,rax
   140002f0d:	lea    rdx,[rsp+0x250]
   140002f15:	mov    rcx,rbx
   140002f18:	call   0x14000f744
   140002f1d:	mov    r8,rax
   140002f20:	mov    edx,0x1b59
   140002f25:	lea    rcx,[rsp+0x60]
   140002f2a:	call   0x140011870
   140002f2f:	lea    rcx,[rsp+0x1a8]
   140002f37:	call   0x14000f484
   140002f3c:	lea    rcx,[rsp+0xd8]
   140002f44:	call   0x14000f484
   140002f49:	lea    rcx,[rsp+0x4a0]
   140002f51:	call   0x14000f484
   140002f56:	mov    rcx,r14
   140002f59:	rex.W call QWORD PTR [rip+0x15120]        # 0x140018080
   140002f60:	nop    DWORD PTR [rax+rax*1+0x0]
   140002f65:	jmp    0x14000307b
   140002f6a:	mov    r9d,DWORD PTR [rsp+0x68]
   140002f6f:	lea    r8,[rip+0x15f92]        # 0x140018f08
   140002f76:	mov    edx,0x40
   140002f7b:	lea    rcx,[rsp+0x4a0]
   140002f83:	call   0x140003494
   140002f88:	lea    rax,[rip+0x158e1]        # 0x140018870
   140002f8f:	mov    QWORD PTR [rsp+0xd8],rax
   140002f97:	lea    rax,[rip+0x15ed2]        # 0x140018e70
   140002f9e:	mov    QWORD PTR [rsp+0xe0],rax
   140002fa6:	lea    rax,[rip+0x158a3]        # 0x140018850
   140002fad:	mov    QWORD PTR [rsp+0xe8],rax
   140002fb5:	mov    DWORD PTR [rsp+0xf0],0x35e
   140002fc0:	mov    DWORD PTR [rsp+0xf4],ebx
   140002fc7:	mov    DWORD PTR [rsp+0xf8],0xff
   140002fd2:	mov    DWORD PTR [rsp+0x178],0x1000000
   140002fdd:	xor    edx,edx
   140002fdf:	lea    r8d,[rdx+0x78]
   140002fe3:	lea    rcx,[rsp+0x100]
   140002feb:	call   0x140015692
   140002ff0:	mov    r8,rsi
   140002ff3:	lea    rdx,[rsp+0x2f8]
   140002ffb:	lea    rcx,[rsp+0xd8]
   140003003:	call   0x14000f744
   140003008:	lea    r8,[rsp+0x4a0]
   140003010:	lea    rdx,[rsp+0x1a8]
   140003018:	mov    rcx,rax
   14000301b:	call   0x14000f744
   140003020:	mov    rbx,rax
   140003023:	rex.W call QWORD PTR [rip+0x14f3e]        # 0x140017f68
   14000302a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000302f:	mov    r8,rax
   140003032:	lea    rdx,[rsp+0x250]
   14000303a:	mov    rcx,rbx
   14000303d:	call   0x14000f744
   140003042:	mov    r8,rax
   140003045:	mov    edx,0x1b59
   14000304a:	lea    rcx,[rsp+0x60]
   14000304f:	call   0x140011870
   140003054:	lea    rcx,[rsp+0x1a8]
   14000305c:	call   0x14000f484
   140003061:	lea    rcx,[rsp+0x2f8]
   140003069:	call   0x14000f484
   14000306e:	lea    rcx,[rsp+0xd8]
   140003076:	call   0x14000f484
   14000307b:	mov    rcx,rsi
   14000307e:	rex.W call QWORD PTR [rip+0x14ffb]        # 0x140018080
   140003085:	nop    DWORD PTR [rax+rax*1+0x0]
   14000308a:	mov    ecx,DWORD PTR [rsp+0x68]
   14000308e:	test   ecx,ecx
   140003090:	je     0x140003194
   140003096:	mov    DWORD PTR [rsp+0x50],edi
   14000309a:	mov    QWORD PTR [rsp+0x40],rdi
   14000309f:	cmp    ecx,0x1
   1400030a2:	jne    0x1400030bc
   1400030a4:	mov    DWORD PTR [rsp+0x48],ecx
   1400030a8:	mov    edx,0x40002b07
   1400030ad:	lea    rcx,[rsp+0x3a0]
   1400030b5:	call   0x14000c6f4
   1400030ba:	jmp    0x1400030fa
   1400030bc:	lea    rdx,[rsp+0x50]
   1400030c1:	call   0x14000ddd4
   1400030c6:	test   eax,eax
   1400030c8:	je     0x1400030ff
   1400030ca:	mov    edx,DWORD PTR [rsp+0x50]
   1400030ce:	lea    rcx,[rsp+0x3a0]
   1400030d6:	call   0x14000d524
   1400030db:	mov    eax,DWORD PTR [rsp+0x68]
   1400030df:	add    eax,0xffffefff
   1400030e4:	cmp    eax,0x9
   1400030e7:	ja     0x140003194
   1400030ed:	lea    rcx,[rsp+0x3a0]
   1400030f5:	call   0x1400051f4
   1400030fa:	jmp    0x140003194
   1400030ff:	lea    rdx,[rsp+0x40]
   140003104:	mov    ecx,DWORD PTR [rsp+0x68]
   140003108:	call   0x14000e164
   14000310d:	lea    rcx,[rsp+0x3a0]
   140003115:	test   eax,eax
   140003117:	je     0x14000314a
   140003119:	lea    rdx,[rip+0x15e00]        # 0x140018f20
   140003120:	call   0x14000da90
   140003125:	mov    rdx,QWORD PTR [rsp+0x40]
   14000312a:	lea    rcx,[rsp+0x3a0]
   140003132:	call   0x14000da90
   140003137:	mov    rcx,QWORD PTR [rsp+0x40]
   14000313c:	rex.W call QWORD PTR [rip+0x14e1d]        # 0x140017f60
   140003143:	nop    DWORD PTR [rax+rax*1+0x0]
   140003148:	jmp    0x140003194
   14000314a:	mov    r8d,DWORD PTR [rsp+0x68]
   14000314f:	xor    edx,edx
   140003151:	call   0x14000c86c
   140003156:	mov    rbx,rax
   140003159:	lea    rcx,[rsp+0x3a0]
   140003161:	test   rax,rax
   140003164:	je     0x140003184
   140003166:	mov    r8,rax
   140003169:	mov    edx,0x40002716
   14000316e:	call   0x14000c6f4
   140003173:	mov    rcx,rbx
   140003176:	rex.W call QWORD PTR [rip+0x14f03]        # 0x140018080
   14000317d:	nop    DWORD PTR [rax+rax*1+0x0]
   140003182:	jmp    0x140003194
   140003184:	mov    r8d,DWORD PTR [rsp+0x68]
   140003189:	mov    edx,0x40002715
   14000318e:	call   0x14000c6f4
   140003193:	nop
   140003194:	lea    rcx,[rsp+0x3a0]
   14000319c:	call   0x140001070
   1400031a1:	nop
   1400031a2:	lea    rcx,[rsp+0x60]
   1400031a7:	call   0x14000f958
   1400031ac:	mov    eax,DWORD PTR [rsp+0x48]
   1400031b0:	mov    rcx,QWORD PTR [rsp+0x550]
   1400031b8:	xor    rcx,rsp
   1400031bb:	call   0x1400143c0
   1400031c0:	lea    r11,[rsp+0x560]
   1400031c8:	mov    rbx,QWORD PTR [r11+0x10]
   1400031cc:	mov    rsi,QWORD PTR [r11+0x18]
   1400031d0:	mov    rdi,QWORD PTR [r11+0x20]
   1400031d4:	mov    r14,QWORD PTR [r11+0x28]
   1400031d8:	mov    rsp,r11
   1400031db:	pop    r15
   1400031dd:	ret
   1400031de:	int3
   1400031df:	jmp    0x1400031a2
   1400031e1:	jmp    0x1400031a2
   1400031e3:	jmp    0x1400031a2
   1400031e5:	mov    DWORD PTR [rsp+0x28],ebx
   1400031e9:	mov    DWORD PTR [rsp+0x20],0x337
   1400031f1:	lea    r9,[rip+0x15c78]        # 0x140018e70
   1400031f8:	lea    r8,[rip+0x15651]        # 0x140018850
   1400031ff:	lea    rdx,[rip+0x1566a]        # 0x140018870
   140003206:	lea    rcx,[rsp+0xd8]
   14000320e:	call   0x14000f3ac
   140003213:	mov    rbx,rax
   140003216:	rex.W call QWORD PTR [rip+0x14d5b]        # 0x140017f78
   14000321d:	nop    DWORD PTR [rax+rax*1+0x0]
   140003222:	mov    DWORD PTR [rsp+0x28],eax
   140003226:	mov    DWORD PTR [rsp+0x20],r14d
   14000322b:	lea    r9,[rip+0x15c6e]        # 0x140018ea0
   140003232:	mov    r8d,0x8000ffff
   140003238:	mov    rdx,rbx
   14000323b:	lea    rcx,[rsp+0x60]
   140003240:	call   0x1400106b0
   140003245:	mov    DWORD PTR [rsp+0x28],ebx
   140003249:	mov    DWORD PTR [rsp+0x20],0x344
   140003251:	lea    r9,[rip+0x15c18]        # 0x140018e70
   140003258:	lea    r8,[rip+0x155f1]        # 0x140018850
   14000325f:	lea    rdx,[rip+0x1560a]        # 0x140018870
   140003266:	lea    rcx,[rsp+0xd8]
   14000326e:	call   0x14000f3ac
   140003273:	mov    rbx,rax
   140003276:	rex.W call QWORD PTR [rip+0x14cfb]        # 0x140017f78
   14000327d:	nop    DWORD PTR [rax+rax*1+0x0]
   140003282:	mov    DWORD PTR [rsp+0x28],eax
   140003286:	mov    DWORD PTR [rsp+0x20],r14d
   14000328b:	lea    r9,[rip+0x15c0e]        # 0x140018ea0
   140003292:	mov    r8d,0x8000ffff
   140003298:	mov    rdx,rbx
   14000329b:	lea    rcx,[rsp+0x60]
   1400032a0:	call   0x1400106b0
   1400032a5:	int3
   1400032a6:	int3
   1400032a7:	int3
   1400032a8:	int3
   1400032a9:	int3
   1400032aa:	int3
   1400032ab:	int3
   1400032ac:	int3
   1400032ad:	int3
   1400032ae:	int3
   1400032af:	int3
   1400032b0:	mov    QWORD PTR [rsp+0x8],rbx
   1400032b5:	mov    QWORD PTR [rsp+0x10],rdi
   1400032ba:	push   rbp
   1400032bb:	mov    rbp,rsp
   1400032be:	sub    rsp,0x60
   1400032c2:	mov    rax,QWORD PTR [rip+0x20e4f]        # 0x140024118
   1400032c9:	xor    rax,rsp
   1400032cc:	mov    QWORD PTR [rbp-0x8],rax
   1400032d0:	xor    ebx,ebx
   1400032d2:	rex.W call QWORD PTR [rip+0x14c7f]        # 0x140017f58
   1400032d9:	nop    DWORD PTR [rax+rax*1+0x0]
   1400032de:	mov    rcx,rax
   1400032e1:	lea    r8,[rbp-0x28]
   1400032e5:	lea    edx,[rbx+0x28]
   1400032e8:	rex.W call QWORD PTR [rip+0x14ad9]        # 0x140017dc8
   1400032ef:	nop    DWORD PTR [rax+rax*1+0x0]
   1400032f4:	test   eax,eax
   1400032f6:	je     0x1400033f6
   1400032fc:	lea    r8,[rbp-0x20]
   140003300:	xor    ecx,ecx
   140003302:	lea    rdx,[rip+0x158c7]        # 0x140018bd0
   140003309:	rex.W call QWORD PTR [rip+0x14ac0]        # 0x140017dd0
   140003310:	nop    DWORD PTR [rax+rax*1+0x0]
   140003315:	test   eax,eax
   140003317:	je     0x14000336c
   140003319:	mov    rax,QWORD PTR [rbp-0x20]
   14000331d:	xor    ecx,ecx
   14000331f:	mov    QWORD PTR [rbp-0x14],rax
   140003323:	mov    DWORD PTR [rbp-0x18],0x1
   14000332a:	mov    DWORD PTR [rbp-0xc],0x3
   140003331:	rex.W call QWORD PTR [rip+0x14c18]        # 0x140017f50
   140003338:	nop    DWORD PTR [rax+rax*1+0x0]
   14000333d:	mov    rcx,QWORD PTR [rbp-0x28]
   140003341:	lea    r8,[rbp-0x18]
   140003345:	xor    r9d,r9d
   140003348:	mov    QWORD PTR [rsp+0x28],rbx
   14000334d:	xor    edx,edx
   14000334f:	mov    QWORD PTR [rsp+0x20],rbx
   140003354:	rex.W call QWORD PTR [rip+0x14a7d]        # 0x140017dd8
   14000335b:	nop    DWORD PTR [rax+rax*1+0x0]
   140003360:	rex.W call QWORD PTR [rip+0x14c11]        # 0x140017f78
   140003367:	nop    DWORD PTR [rax+rax*1+0x0]
   14000336c:	mov    rcx,QWORD PTR [rbp-0x28]
   140003370:	lea    rax,[rbp-0x30]
   140003374:	xor    r9d,r9d
   140003377:	mov    QWORD PTR [rsp+0x20],rax
   14000337c:	xor    r8d,r8d
   14000337f:	lea    edx,[r9+0x3]
   140003383:	rex.W call QWORD PTR [rip+0x14a56]        # 0x140017de0
   14000338a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000338f:	mov    ecx,DWORD PTR [rbp-0x30]
   140003392:	lea    rdx,[rip+0x14fe7]        # 0x140018380
   140003399:	call   0x140014458
   14000339e:	mov    rdi,rax
   1400033a1:	test   rax,rax
   1400033a4:	jne    0x1400033b7
   1400033a6:	lea    ecx,[rax+0xe]
   1400033a9:	rex.W call QWORD PTR [rip+0x14ba0]        # 0x140017f50
   1400033b0:	nop    DWORD PTR [rax+rax*1+0x0]
   1400033b5:	jmp    0x1400033e6
   1400033b7:	mov    r9d,DWORD PTR [rbp-0x30]
   1400033bb:	lea    rax,[rbp-0x30]
   1400033bf:	mov    rcx,QWORD PTR [rbp-0x28]
   1400033c3:	mov    r8,rdi
   1400033c6:	mov    edx,0x3
   1400033cb:	mov    QWORD PTR [rsp+0x20],rax
   1400033d0:	rex.W call QWORD PTR [rip+0x14a09]        # 0x140017de0
   1400033d7:	nop    DWORD PTR [rax+rax*1+0x0]
   1400033dc:	mov    rcx,rdi
   1400033df:	mov    ebx,eax
   1400033e1:	call   0x140014084
   1400033e6:	mov    rcx,QWORD PTR [rbp-0x28]
   1400033ea:	rex.W call QWORD PTR [rip+0x14b57]        # 0x140017f48
   1400033f1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400033f6:	mov    eax,ebx
   1400033f8:	mov    rcx,QWORD PTR [rbp-0x8]
   1400033fc:	xor    rcx,rsp
   1400033ff:	call   0x1400143c0
   140003404:	mov    rbx,QWORD PTR [rsp+0x70]
   140003409:	mov    rdi,QWORD PTR [rsp+0x78]
   14000340e:	add    rsp,0x60
   140003412:	pop    rbp
   140003413:	ret
   140003414:	int3
   140003415:	int3
   140003416:	int3
   140003417:	int3
   140003418:	int3
   140003419:	int3
   14000341a:	int3
   14000341b:	int3
   14000341c:	mov    QWORD PTR [rsp+0x8],rbx
   140003421:	push   rdi
   140003422:	sub    rsp,0x20
   140003426:	mov    rbx,rdx
   140003429:	mov    edi,ecx
   14000342b:	rex.W call QWORD PTR [rip+0x14bb6]        # 0x140017fe8
   140003432:	nop    DWORD PTR [rax+rax*1+0x0]
   140003437:	mov    rdx,rbx
   14000343a:	mov    ecx,edi
   14000343c:	call   0x1400029dc
   140003441:	mov    ebx,eax
   140003443:	rex.W call QWORD PTR [rip+0x14bae]        # 0x140017ff8
   14000344a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000344f:	mov    eax,ebx
   140003451:	mov    rbx,QWORD PTR [rsp+0x30]
   140003456:	add    rsp,0x20
   14000345a:	pop    rdi
   14000345b:	ret
   14000345c:	int3
   14000345d:	int3
   14000345e:	int3
   14000345f:	int3
   140003460:	int3
   140003461:	int3
   140003462:	int3
   140003463:	int3
   140003464:	sub    rsp,0x38
   140003468:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140003471:	mov    rcx,QWORD PTR [rcx]
   140003474:	test   rcx,rcx
   140003477:	je     0x140003487
   140003479:	mov    rax,QWORD PTR [rcx]
   14000347c:	mov    rax,QWORD PTR [rax+0x10]
   140003480:	call   QWORD PTR [rip+0x14e12]        # 0x140018298
   140003486:	nop
   140003487:	add    rsp,0x38
   14000348b:	ret
   14000348c:	int3
   14000348d:	int3
   14000348e:	int3
   14000348f:	int3
   140003490:	int3
   140003491:	int3
   140003492:	int3
   140003493:	int3
   140003494:	mov    QWORD PTR [rsp+0x18],r8
   140003499:	mov    QWORD PTR [rsp+0x20],r9
   14000349e:	push   rbx
   14000349f:	push   rbp
   1400034a0:	push   rsi
   1400034a1:	push   rdi
   1400034a2:	sub    rsp,0x28
   1400034a6:	xor    ebp,ebp
   1400034a8:	lea    rax,[rdx-0x1]
   1400034ac:	cmp    rax,0x7ffffffe
   1400034b2:	mov    rsi,rcx
   1400034b5:	mov    edi,ebp
   1400034b7:	mov    ecx,0x80070057
   1400034bc:	cmova  edi,ecx
   1400034bf:	test   edi,edi
   1400034c1:	js     0x1400034fe
   1400034c3:	lea    rbx,[rdx-0x1]
   1400034c7:	mov    rcx,rsi
   1400034ca:	mov    rdx,rbx
   1400034cd:	lea    r9,[rsp+0x68]
   1400034d2:	mov    edi,ebp
   1400034d4:	rex.W call QWORD PTR [rip+0x14d7d]        # 0x140018258
   1400034db:	nop    DWORD PTR [rax+rax*1+0x0]
   1400034e0:	test   eax,eax
   1400034e2:	js     0x1400034f3
   1400034e4:	cdqe
   1400034e6:	cmp    rax,rbx
   1400034e9:	ja     0x1400034f3
   1400034eb:	jne    0x140003506
   1400034ed:	mov    WORD PTR [rsi+rbx*2],bp
   1400034f1:	jmp    0x140003506
   1400034f3:	mov    WORD PTR [rsi+rbx*2],bp
   1400034f7:	mov    edi,0x8007007a
   1400034fc:	jmp    0x140003506
   1400034fe:	test   rdx,rdx
   140003501:	je     0x140003506
   140003503:	mov    WORD PTR [rsi],bp
   140003506:	mov    eax,edi
   140003508:	add    rsp,0x28
   14000350c:	pop    rdi
   14000350d:	pop    rsi
   14000350e:	pop    rbp
   14000350f:	pop    rbx
   140003510:	ret
   140003511:	int3
   140003512:	int3
   140003513:	int3
   140003514:	int3
   140003515:	int3
   140003516:	int3
   140003517:	int3
   140003518:	mov    QWORD PTR [rsp+0x8],rbx
   14000351d:	xor    ebx,ebx
   14000351f:	mov    r10,rdx
   140003522:	mov    r11,r8
   140003525:	mov    r9d,ebx
   140003528:	mov    r8d,0x80070057
   14000352e:	mov    rdx,rcx
   140003531:	lea    rax,[r10-0x1]
   140003535:	cmp    rax,0x7ffffffe
   14000353b:	cmova  r9d,r8d
   14000353f:	test   r9d,r9d
   140003542:	js     0x14000357a
   140003544:	mov    rcx,r10
   140003547:	mov    rax,rdx
   14000354a:	test   r10,r10
   14000354d:	je     0x14000355e
   14000354f:	cmp    WORD PTR [rax],bx
   140003552:	je     0x14000355e
   140003554:	add    rax,0x2
   140003558:	sub    rcx,0x1
   14000355c:	jne    0x14000354f
   14000355e:	mov    rax,rcx
   140003561:	neg    rax
   140003564:	sbb    r9d,r9d
   140003567:	not    r9d
   14000356a:	and    r9d,r8d
   14000356d:	test   rcx,rcx
   140003570:	je     0x14000357a
   140003572:	mov    r8,r10
   140003575:	sub    r8,rcx
   140003578:	jmp    0x14000357d
   14000357a:	mov    r8,rbx
   14000357d:	test   r9d,r9d
   140003580:	js     0x1400035de
   140003582:	mov    rcx,r10
   140003585:	lea    rdx,[rdx+r8*2]
   140003589:	sub    rcx,r8
   14000358c:	je     0x1400035c0
   14000358e:	mov    rax,rcx
   140003591:	lea    r9,[r8+0x7ffffffe]
   140003598:	sub    rax,r10
   14000359b:	add    r9,rax
   14000359e:	sub    r11,rdx
   1400035a1:	test   r9,r9
   1400035a4:	je     0x1400035c0
   1400035a6:	movzx  eax,WORD PTR [r11+rdx*1]
   1400035ab:	test   ax,ax
   1400035ae:	je     0x1400035c0
   1400035b0:	mov    WORD PTR [rdx],ax
   1400035b3:	dec    r9
   1400035b6:	add    rdx,0x2
   1400035ba:	sub    rcx,0x1
   1400035be:	jne    0x1400035a1
   1400035c0:	test   rcx,rcx
   1400035c3:	lea    rax,[rdx-0x2]
   1400035c7:	cmovne rax,rdx
   1400035cb:	neg    rcx
   1400035ce:	sbb    r9d,r9d
   1400035d1:	not    r9d
   1400035d4:	and    r9d,0x8007007a
   1400035db:	mov    WORD PTR [rax],bx
   1400035de:	mov    rbx,QWORD PTR [rsp+0x8]
   1400035e3:	mov    eax,r9d
   1400035e6:	ret
   1400035e7:	int3
   1400035e8:	int3
   1400035e9:	int3
   1400035ea:	int3
   1400035eb:	int3
   1400035ec:	int3
   1400035ed:	int3
   1400035ee:	int3
   1400035ef:	int3
   1400035f0:	mov    rax,QWORD PTR [rcx+0x8]
   1400035f4:	ret
   1400035f5:	int3
   1400035f6:	int3
   1400035f7:	int3
   1400035f8:	int3
   1400035f9:	int3
   1400035fa:	int3
   1400035fb:	int3
   1400035fc:	mov    QWORD PTR [rsp+0x8],rbx
   140003601:	xor    ebx,ebx
   140003603:	lea    rax,[rdx-0x1]
   140003607:	mov    r10d,0x7ffffffe
   14000360d:	mov    r9d,ebx
   140003610:	cmp    rax,r10
   140003613:	mov    r11d,0x80070057
   140003619:	cmova  r9d,r11d
   14000361d:	test   r9d,r9d
   140003620:	js     0x14000366d
   140003622:	test   rdx,rdx
   140003625:	je     0x14000364d
   140003627:	sub    r10,rdx
   14000362a:	sub    r8,rcx
   14000362d:	lea    rax,[r10+rdx*1]
   140003631:	test   rax,rax
   140003634:	je     0x14000364d
   140003636:	movzx  eax,WORD PTR [r8+rcx*1]
   14000363b:	test   ax,ax
   14000363e:	je     0x14000364d
   140003640:	mov    WORD PTR [rcx],ax
   140003643:	add    rcx,0x2
   140003647:	sub    rdx,0x1
   14000364b:	jne    0x14000362d
   14000364d:	test   rdx,rdx
   140003650:	lea    rax,[rcx-0x2]
   140003654:	cmovne rax,rcx
   140003658:	neg    rdx
   14000365b:	sbb    r9d,r9d
   14000365e:	not    r9d
   140003661:	and    r9d,0x8007007a
   140003668:	mov    WORD PTR [rax],bx
   14000366b:	jmp    0x140003675
   14000366d:	test   rdx,rdx
   140003670:	je     0x140003675
   140003672:	mov    WORD PTR [rcx],bx
   140003675:	mov    rbx,QWORD PTR [rsp+0x8]
   14000367a:	mov    eax,r9d
   14000367d:	ret
   14000367e:	int3
   14000367f:	int3
   140003680:	int3
   140003681:	int3
   140003682:	int3
   140003683:	int3
   140003684:	int3
   140003685:	int3
   140003686:	int3
   140003687:	int3
   140003688:	mov    QWORD PTR [rsp+0x8],rbx
   14000368d:	mov    QWORD PTR [rsp+0x18],rbp
   140003692:	mov    QWORD PTR [rsp+0x20],rsi
   140003697:	push   rdi
   140003698:	push   r14
   14000369a:	push   r15
   14000369c:	sub    rsp,0xf0
   1400036a3:	or     rbx,0xffffffffffffffff
   1400036a7:	mov    rbp,rcx
   1400036aa:	mov    rcx,rbx
   1400036ad:	xor    r15d,r15d
   1400036b0:	mov    rdi,r8
   1400036b3:	mov    r14,rdx
   1400036b6:	inc    rcx
   1400036b9:	cmp    WORD PTR [r8+rcx*2],r15w
   1400036be:	jne    0x1400036b6
   1400036c0:	lea    rcx,[rcx*2+0x2]
   1400036c8:	rex.W call QWORD PTR [rip+0x149a9]        # 0x140018078
   1400036cf:	nop    DWORD PTR [rax+rax*1+0x0]
   1400036d4:	mov    QWORD PTR [r14],rax
   1400036d7:	test   rax,rax
   1400036da:	je     0x140003759
   1400036dc:	mov    rdx,rbx
   1400036df:	inc    rdx
   1400036e2:	cmp    WORD PTR [rdi+rdx*2],r15w
   1400036e7:	jne    0x1400036df
   1400036e9:	inc    rdx
   1400036ec:	mov    r8,rdi
   1400036ef:	mov    rcx,rax
   1400036f2:	call   0x1400035fc
   1400036f7:	mov    esi,eax
   1400036f9:	test   eax,eax
   1400036fb:	jns    0x14000373b
   1400036fd:	mov    DWORD PTR [rsp+0x28],0xb
   140003705:	lea    r9,[rip+0x158dc]        # 0x140018fe8
   14000370c:	lea    r8,[rip+0x158fd]        # 0x140019010
   140003713:	mov    DWORD PTR [rsp+0x20],0x58
   14000371b:	lea    rdx,[rip+0x158fe]        # 0x140019020
   140003722:	lea    rcx,[rsp+0x40]
   140003727:	call   0x14000f3ac
   14000372c:	mov    rdx,rax
   14000372f:	inc    rbx
   140003732:	cmp    WORD PTR [rdi+rbx*2],r15w
   140003737:	je     0x1400037a1
   140003739:	jmp    0x14000372f
   14000373b:	lea    r11,[rsp+0xf0]
   140003743:	mov    rbx,QWORD PTR [r11+0x20]
   140003747:	mov    rbp,QWORD PTR [r11+0x30]
   14000374b:	mov    rsi,QWORD PTR [r11+0x38]
   14000374f:	mov    rsp,r11
   140003752:	pop    r15
   140003754:	pop    r14
   140003756:	pop    rdi
   140003757:	ret
   140003758:	int3
   140003759:	mov    DWORD PTR [rsp+0x28],0xb
   140003761:	lea    r9,[rip+0x15880]        # 0x140018fe8
   140003768:	lea    r8,[rip+0x158a1]        # 0x140019010
   14000376f:	mov    DWORD PTR [rsp+0x20],0x54
   140003777:	lea    rdx,[rip+0x158a2]        # 0x140019020
   14000377e:	lea    rcx,[rsp+0x40]
   140003783:	call   0x14000f3ac
   140003788:	lea    r9,[rip+0x157d9]        # 0x140018f68
   14000378f:	mov    r8d,0x8007000e
   140003795:	mov    rdx,rax
   140003798:	mov    rcx,rbp
   14000379b:	call   0x1400106b0
   1400037a0:	int3
   1400037a1:	mov    rax,QWORD PTR [r14]
   1400037a4:	lea    r9,[rip+0x157f5]        # 0x140018fa0
   1400037ab:	inc    rbx
   1400037ae:	mov    QWORD PTR [rsp+0x30],rdi
   1400037b3:	mov    QWORD PTR [rsp+0x28],rbx
   1400037b8:	mov    r8d,esi
   1400037bb:	mov    rcx,rbp
   1400037be:	mov    QWORD PTR [rsp+0x20],rax
   1400037c3:	call   0x140010ee4
   1400037c8:	int3
   1400037c9:	int3
   1400037ca:	int3
   1400037cb:	int3
   1400037cc:	int3
   1400037cd:	int3
   1400037ce:	int3
   1400037cf:	int3
   1400037d0:	rex push rbx
   1400037d2:	sub    rsp,0x20
   1400037d6:	lea    rax,[rip+0x13883]        # 0x140017060
   1400037dd:	mov    rbx,rcx
   1400037e0:	mov    QWORD PTR [rcx],rax
   1400037e3:	mov    rcx,QWORD PTR [rcx+0x8]
   1400037e7:	test   rcx,rcx
   1400037ea:	je     0x1400037f8
   1400037ec:	rex.W call QWORD PTR [rip+0x1488d]        # 0x140018080
   1400037f3:	nop    DWORD PTR [rax+rax*1+0x0]
   1400037f8:	and    QWORD PTR [rbx+0x8],0x0
   1400037fd:	lea    rax,[rip+0x13864]        # 0x140017068
   140003804:	mov    QWORD PTR [rbx],rax
   140003807:	add    rsp,0x20
   14000380b:	pop    rbx
   14000380c:	ret
   14000380d:	int3
   14000380e:	int3
   14000380f:	int3
   140003810:	int3
   140003811:	int3
   140003812:	int3
   140003813:	int3
   140003814:	int3
   140003815:	int3
   140003816:	int3
   140003817:	int3
   140003818:	int3
   140003819:	int3
   14000381a:	int3
   14000381b:	int3
   14000381c:	int3
   14000381d:	int3
   14000381e:	int3
   14000381f:	int3
   140003820:	mov    QWORD PTR [rsp+0x8],rbx
   140003825:	push   rdi
   140003826:	sub    rsp,0x20
   14000382a:	lea    rax,[rip+0x1382f]        # 0x140017060
   140003831:	mov    rbx,rcx
   140003834:	mov    QWORD PTR [rcx],rax
   140003837:	mov    edi,edx
   140003839:	mov    rcx,QWORD PTR [rcx+0x8]
   14000383d:	test   rcx,rcx
   140003840:	je     0x14000384e
   140003842:	rex.W call QWORD PTR [rip+0x14837]        # 0x140018080
   140003849:	nop    DWORD PTR [rax+rax*1+0x0]
   14000384e:	and    QWORD PTR [rbx+0x8],0x0
   140003853:	lea    rax,[rip+0x1380e]        # 0x140017068
   14000385a:	mov    QWORD PTR [rbx],rax
   14000385d:	test   dil,0x1
   140003861:	je     0x14000386b
   140003863:	mov    rcx,rbx
   140003866:	call   0x140014084
   14000386b:	mov    rax,rbx
   14000386e:	mov    rbx,QWORD PTR [rsp+0x30]
   140003873:	add    rsp,0x20
   140003877:	pop    rdi
   140003878:	ret
   140003879:	int3
   14000387a:	int3
   14000387b:	int3
   14000387c:	int3
   14000387d:	int3
   14000387e:	int3
   14000387f:	int3
   140003880:	rex push rbx
   140003882:	sub    rsp,0x20
   140003886:	lea    rax,[rip+0x137db]        # 0x140017068
   14000388d:	mov    rbx,rcx
   140003890:	mov    QWORD PTR [rcx],rax
   140003893:	test   dl,0x1
   140003896:	je     0x14000389d
   140003898:	call   0x140014084
   14000389d:	mov    rax,rbx
   1400038a0:	add    rsp,0x20
   1400038a4:	pop    rbx
   1400038a5:	ret
   1400038a6:	int3
   1400038a7:	int3
   1400038a8:	int3
   1400038a9:	int3
   1400038aa:	int3
   1400038ab:	int3
   1400038ac:	int3
   1400038ad:	int3
   1400038ae:	int3
   1400038af:	int3
   1400038b0:	rex push rbx
   1400038b2:	sub    rsp,0x20
   1400038b6:	mov    rbx,rcx
   1400038b9:	mov    rcx,QWORD PTR [rcx+0x8]
   1400038bd:	test   rcx,rcx
   1400038c0:	je     0x1400038ce
   1400038c2:	rex.W call QWORD PTR [rip+0x147b7]        # 0x140018080
   1400038c9:	nop    DWORD PTR [rax+rax*1+0x0]
   1400038ce:	and    QWORD PTR [rbx+0x8],0x0
   1400038d3:	add    rsp,0x20
   1400038d7:	pop    rbx
   1400038d8:	ret
   1400038d9:	int3
   1400038da:	int3
   1400038db:	int3
   1400038dc:	int3
   1400038dd:	int3
   1400038de:	int3
   1400038df:	int3
   1400038e0:	mov    DWORD PTR [rcx+0x8],edx
   1400038e3:	ret
   1400038e4:	int3
   1400038e5:	int3
   1400038e6:	int3
   1400038e7:	int3
   1400038e8:	int3
   1400038e9:	int3
   1400038ea:	int3
   1400038eb:	int3
   1400038ec:	mov    eax,DWORD PTR [rcx+0x8]
   1400038ef:	ret
   1400038f0:	int3
   1400038f1:	int3
   1400038f2:	int3
   1400038f3:	int3
   1400038f4:	int3
   1400038f5:	int3
   1400038f6:	int3
   1400038f7:	int3
   1400038f8:	mov    QWORD PTR [rsp+0x8],rbx
   1400038fd:	mov    QWORD PTR [rsp+0x10],rdi
   140003902:	push   rbp
   140003903:	lea    rbp,[rsp-0x40]
   140003908:	sub    rsp,0x140
   14000390f:	lea    rax,[rip+0x157ca]        # 0x1400190e0
   140003916:	movsxd rbx,edx
   140003919:	mov    QWORD PTR [rsp+0x20],rax
   14000391e:	xor    edx,edx
   140003920:	lea    rax,[rip+0x15759]        # 0x140019080
   140003927:	mov    DWORD PTR [rsp+0x38],0x150
   14000392f:	mov    QWORD PTR [rsp+0x28],rax
   140003934:	mov    rdi,rcx
   140003937:	lea    rax,[rip+0x15782]        # 0x1400190c0
   14000393e:	mov    DWORD PTR [rsp+0x3c],0x7
   140003946:	lea    r8d,[rdx+0x78]
   14000394a:	mov    QWORD PTR [rsp+0x30],rax
   14000394f:	lea    rcx,[rsp+0x48]
   140003954:	mov    DWORD PTR [rsp+0x40],0xff
   14000395c:	mov    DWORD PTR [rbp-0x40],0x1000000
   140003963:	call   0x140015692
   140003968:	lea    rdx,[rsp+0x20]
   14000396d:	lea    rcx,[rbp-0x30]
   140003971:	call   0x14000f85c
   140003976:	mov    rbx,QWORD PTR [rdi+rbx*8+0x68]
   14000397b:	lea    rcx,[rbp-0x30]
   14000397f:	call   0x14000f958
   140003984:	lea    r11,[rsp+0x140]
   14000398c:	mov    rax,rbx
   14000398f:	mov    rbx,QWORD PTR [r11+0x10]
   140003993:	mov    rdi,QWORD PTR [r11+0x18]
   140003997:	mov    rsp,r11
   14000399a:	pop    rbp
   14000399b:	ret
   14000399c:	int3
   14000399d:	int3
   14000399e:	int3
   14000399f:	int3
   1400039a0:	int3
   1400039a1:	int3
   1400039a2:	int3
   1400039a3:	int3
   1400039a4:	rex push rbx
   1400039a6:	sub    rsp,0x20
   1400039aa:	mov    rbx,rcx
   1400039ad:	mov    rcx,QWORD PTR [rcx]
   1400039b0:	rex.W call QWORD PTR [rip+0x146c9]        # 0x140018080
   1400039b7:	nop    DWORD PTR [rax+rax*1+0x0]
   1400039bc:	and    QWORD PTR [rbx],0x0
   1400039c0:	add    rsp,0x20
   1400039c4:	pop    rbx
   1400039c5:	ret
   1400039c6:	int3
   1400039c7:	int3
   1400039c8:	int3
   1400039c9:	int3
   1400039ca:	int3
   1400039cb:	int3
   1400039cc:	int3
   1400039cd:	int3
   1400039ce:	int3
   1400039cf:	int3
   1400039d0:	ret    0x0
   1400039d3:	int3
   1400039d4:	int3
   1400039d5:	int3
   1400039d6:	int3
   1400039d7:	int3
   1400039d8:	int3
   1400039d9:	int3
   1400039da:	int3
   1400039db:	int3
   1400039dc:	int3
   1400039dd:	int3
   1400039de:	int3
   1400039df:	int3
   1400039e0:	rex push rbx
   1400039e2:	sub    rsp,0xf0
   1400039e9:	mov    rax,QWORD PTR [rsp+0x120]
   1400039f1:	mov    rdx,QWORD PTR [rip+0x149b8]        # 0x1400183b0
   1400039f8:	mov    rbx,QWORD PTR [rsp+0x130]
   140003a00:	mov    rcx,QWORD PTR [rip+0x149b1]        # 0x1400183b8
   140003a07:	cmp    QWORD PTR [rax],rdx
   140003a0a:	jne    0x140003a12
   140003a0c:	cmp    QWORD PTR [rax+0x8],rcx
   140003a10:	je     0x140003a25
   140003a12:	mov    rax,QWORD PTR [rsp+0x128]
   140003a1a:	cmp    QWORD PTR [rax],rdx
   140003a1d:	jne    0x140003a4a
   140003a1f:	cmp    QWORD PTR [rax+0x8],rcx
   140003a23:	jne    0x140003a4a
   140003a25:	xor    ecx,ecx
   140003a27:	test   r9,r9
   140003a2a:	je     0x140003a40
   140003a2c:	or     rax,0xffffffffffffffff
   140003a30:	inc    rax
   140003a33:	cmp    WORD PTR [r9+rax*2],cx
   140003a38:	jne    0x140003a30
   140003a3a:	cmp    rax,0x31
   140003a3e:	ja     0x140003a92
   140003a40:	add    rsp,0xf0
   140003a47:	pop    rbx
   140003a48:	ret
   140003a49:	int3
   140003a4a:	mov    DWORD PTR [rsp+0x28],0x7
   140003a52:	lea    r9,[rip+0x157b7]        # 0x140019210
   140003a59:	lea    r8,[rip+0x157f8]        # 0x140019258
   140003a60:	mov    DWORD PTR [rsp+0x20],0x43
   140003a68:	lea    rdx,[rip+0x15801]        # 0x140019270
   140003a6f:	lea    rcx,[rsp+0x48]
   140003a74:	call   0x14000f3ac
   140003a79:	lea    r9,[rip+0x156d0]        # 0x140019150
   140003a80:	mov    r8d,0x1008
   140003a86:	mov    rdx,rax
   140003a89:	mov    rcx,rbx
   140003a8c:	call   0x1400106b0
   140003a91:	int3
   140003a92:	mov    DWORD PTR [rsp+0x28],0x7
   140003a9a:	lea    r9,[rip+0x1576f]        # 0x140019210
   140003aa1:	lea    r8,[rip+0x157b0]        # 0x140019258
   140003aa8:	mov    DWORD PTR [rsp+0x20],0x48
   140003ab0:	lea    rdx,[rip+0x157b9]        # 0x140019270
   140003ab7:	lea    rcx,[rsp+0x48]
   140003abc:	call   0x14000f3ac
   140003ac1:	lea    r9,[rip+0x15818]        # 0x1400192e0
   140003ac8:	mov    r8d,0x1004
   140003ace:	mov    rdx,rax
   140003ad1:	mov    rcx,rbx
   140003ad4:	call   0x1400106b0
   140003ad9:	int3
   140003ada:	int3
   140003adb:	int3
   140003adc:	int3
   140003add:	int3
   140003ade:	int3
   140003adf:	int3
   140003ae0:	sub    rsp,0xf8
   140003ae7:	cmp    QWORD PTR [rsp+0x120],0x100000
   140003af3:	jb     0x140003afe
   140003af5:	add    rsp,0xf8
   140003afc:	ret
   140003afd:	int3
   140003afe:	mov    DWORD PTR [rsp+0x28],0x7
   140003b06:	lea    r9,[rip+0x1591b]        # 0x140019428
   140003b0d:	lea    r8,[rip+0x15744]        # 0x140019258
   140003b14:	mov    DWORD PTR [rsp+0x20],0x5d
   140003b1c:	lea    rdx,[rip+0x1574d]        # 0x140019270
   140003b23:	lea    rcx,[rsp+0x40]
   140003b28:	call   0x14000f3ac
   140003b2d:	mov    rcx,QWORD PTR [rsp+0x128]
   140003b35:	lea    r9,[rip+0x15854]        # 0x140019390
   140003b3c:	mov    r8d,0x1001
   140003b42:	mov    rdx,rax
   140003b45:	call   0x1400106b0
   140003b4a:	int3
   140003b4b:	int3
   140003b4c:	int3
   140003b4d:	int3
   140003b4e:	int3
   140003b4f:	int3
   140003b50:	int3
   140003b51:	int3
   140003b52:	int3
   140003b53:	int3
   140003b54:	int3
   140003b55:	int3
   140003b56:	int3
   140003b57:	int3
   140003b58:	int3
   140003b59:	int3
   140003b5a:	int3
   140003b5b:	int3
   140003b5c:	int3
   140003b5d:	int3
   140003b5e:	int3
   140003b5f:	int3
   140003b60:	sub    rsp,0xf8
   140003b67:	cmp    QWORD PTR [rsp+0x120],0x100000
   140003b73:	jb     0x140003b7e
   140003b75:	add    rsp,0xf8
   140003b7c:	ret
   140003b7d:	int3
   140003b7e:	mov    DWORD PTR [rsp+0x28],0x7
   140003b86:	lea    r9,[rip+0x15983]        # 0x140019510
   140003b8d:	lea    r8,[rip+0x156c4]        # 0x140019258
   140003b94:	mov    DWORD PTR [rsp+0x20],0x6d
   140003b9c:	lea    rdx,[rip+0x156cd]        # 0x140019270
   140003ba3:	lea    rcx,[rsp+0x40]
   140003ba8:	call   0x14000f3ac
   140003bad:	mov    rcx,QWORD PTR [rsp+0x128]
   140003bb5:	lea    r9,[rip+0x158b4]        # 0x140019470
   140003bbc:	mov    r8d,0x1001
   140003bc2:	mov    rdx,rax
   140003bc5:	call   0x1400106b0
   140003bca:	int3
   140003bcb:	int3
   140003bcc:	int3
   140003bcd:	int3
   140003bce:	int3
   140003bcf:	int3
   140003bd0:	int3
   140003bd1:	int3
   140003bd2:	int3
   140003bd3:	int3
   140003bd4:	int3
   140003bd5:	int3
   140003bd6:	int3
   140003bd7:	int3
   140003bd8:	int3
   140003bd9:	int3
   140003bda:	int3
   140003bdb:	int3
   140003bdc:	int3
   140003bdd:	int3
   140003bde:	int3
   140003bdf:	int3
   140003be0:	rex push rbx
   140003be2:	sub    rsp,0xf0
   140003be9:	mov    rbx,r9
   140003bec:	test   rdx,rdx
   140003bef:	je     0x140003bf8
   140003bf1:	test   r8b,r8b
   140003bf4:	jne    0x140003c4f
   140003bf6:	jmp    0x140003bfd
   140003bf8:	test   r8b,r8b
   140003bfb:	je     0x140003c07
   140003bfd:	add    rsp,0xf0
   140003c04:	pop    rbx
   140003c05:	ret
   140003c06:	int3
   140003c07:	mov    DWORD PTR [rsp+0x28],0x7
   140003c0f:	lea    r9,[rip+0x159da]        # 0x1400195f0
   140003c16:	lea    r8,[rip+0x1563b]        # 0x140019258
   140003c1d:	mov    DWORD PTR [rsp+0x20],0x80
   140003c25:	lea    rdx,[rip+0x15644]        # 0x140019270
   140003c2c:	lea    rcx,[rsp+0x40]
   140003c31:	call   0x14000f3ac
   140003c36:	lea    r9,[rip+0x159f3]        # 0x140019630
   140003c3d:	mov    r8d,0x1008
   140003c43:	mov    rdx,rax
   140003c46:	mov    rcx,rbx
   140003c49:	call   0x1400106b0
   140003c4e:	int3
   140003c4f:	mov    DWORD PTR [rsp+0x28],0x7
   140003c57:	lea    r9,[rip+0x15992]        # 0x1400195f0
   140003c5e:	lea    r8,[rip+0x155f3]        # 0x140019258
   140003c65:	mov    DWORD PTR [rsp+0x20],0x7d
   140003c6d:	lea    rdx,[rip+0x155fc]        # 0x140019270
   140003c74:	lea    rcx,[rsp+0x40]
   140003c79:	call   0x14000f3ac
   140003c7e:	lea    r9,[rip+0x158db]        # 0x140019560
   140003c85:	mov    r8d,0x1008
   140003c8b:	mov    rdx,rax
   140003c8e:	mov    rcx,rbx
   140003c91:	call   0x1400106b0
   140003c96:	int3
   140003c97:	int3
   140003c98:	int3
   140003c99:	int3
   140003c9a:	int3
   140003c9b:	int3
   140003c9c:	int3
   140003c9d:	int3
   140003c9e:	int3
   140003c9f:	int3
   140003ca0:	sub    rsp,0xf8
   140003ca7:	test   r8,r8
   140003caa:	je     0x140003cb1
   140003cac:	test   r9,r9
   140003caf:	jne    0x140003cba
   140003cb1:	add    rsp,0xf8
   140003cb8:	ret
   140003cb9:	int3
   140003cba:	mov    DWORD PTR [rsp+0x28],0x7
   140003cc2:	lea    r9,[rip+0x15a97]        # 0x140019760
   140003cc9:	lea    r8,[rip+0x15588]        # 0x140019258
   140003cd0:	mov    DWORD PTR [rsp+0x20],0x96
   140003cd8:	lea    rdx,[rip+0x15591]        # 0x140019270
   140003cdf:	lea    rcx,[rsp+0x40]
   140003ce4:	call   0x14000f3ac
   140003ce9:	mov    rcx,QWORD PTR [rsp+0x120]
   140003cf1:	lea    r9,[rip+0x159c8]        # 0x1400196c0
   140003cf8:	mov    r8d,0x1008
   140003cfe:	mov    rdx,rax
   140003d01:	call   0x1400106b0
   140003d06:	int3
   140003d07:	int3
   140003d08:	int3
   140003d09:	int3
   140003d0a:	int3
   140003d0b:	int3
   140003d0c:	int3
   140003d0d:	int3
   140003d0e:	int3
   140003d0f:	int3
   140003d10:	rex push rbx
   140003d12:	sub    rsp,0xf0
   140003d19:	mov    rcx,QWORD PTR [rsp+0x128]
   140003d21:	mov    rbx,QWORD PTR [rsp+0x138]
   140003d29:	mov    rax,QWORD PTR [rcx]
   140003d2c:	cmp    rax,QWORD PTR [rip+0x1467d]        # 0x1400183b0
   140003d33:	jne    0x140003dbc
   140003d39:	mov    rax,QWORD PTR [rcx+0x8]
   140003d3d:	cmp    rax,QWORD PTR [rip+0x14674]        # 0x1400183b8
   140003d44:	jne    0x140003dbc
   140003d46:	mov    r10b,BYTE PTR [rsp+0x120]
   140003d4e:	or     rcx,0xffffffffffffffff
   140003d52:	xor    eax,eax
   140003d54:	test   r8,r8
   140003d57:	jne    0x140003d6f
   140003d59:	cmp    edx,ecx
   140003d5b:	jne    0x140003e73
   140003d61:	test   r9b,r9b
   140003d64:	jne    0x140003d7c
   140003d66:	test   r10b,r10b
   140003d69:	je     0x140003e73
   140003d6f:	cmp    edx,ecx
   140003d71:	je     0x140003d7c
   140003d73:	test   r8,r8
   140003d76:	je     0x140003e73
   140003d7c:	test   r10b,r10b
   140003d7f:	je     0x140003d8a
   140003d81:	test   r8,r8
   140003d84:	je     0x140003e73
   140003d8a:	cmp    edx,ecx
   140003d8c:	je     0x140003d97
   140003d8e:	test   r9b,r9b
   140003d91:	jne    0x140003ebb
   140003d97:	test   r9b,r9b
   140003d9a:	je     0x140003da5
   140003d9c:	test   r10b,r10b
   140003d9f:	jne    0x140003ebb
   140003da5:	test   r8,r8
   140003da8:	je     0x140003dd9
   140003daa:	inc    rcx
   140003dad:	cmp    WORD PTR [r8+rcx*2],ax
   140003db2:	jne    0x140003daa
   140003db4:	cmp    rcx,0x31
   140003db8:	ja     0x140003e2b
   140003dba:	jmp    0x140003dd9
   140003dbc:	xor    eax,eax
   140003dbe:	test   r8,r8
   140003dc1:	jne    0x140003de3
   140003dc3:	or     rcx,0xffffffffffffffff
   140003dc7:	cmp    edx,ecx
   140003dc9:	jne    0x140003de3
   140003dcb:	cmp    BYTE PTR [rsp+0x120],al
   140003dd2:	jne    0x140003de3
   140003dd4:	test   r9b,r9b
   140003dd7:	jne    0x140003de3
   140003dd9:	add    rsp,0xf0
   140003de0:	pop    rbx
   140003de1:	ret
   140003de2:	int3
   140003de3:	mov    DWORD PTR [rsp+0x28],0x7
   140003deb:	lea    r9,[rip+0x15a2e]        # 0x140019820
   140003df2:	lea    r8,[rip+0x1545f]        # 0x140019258
   140003df9:	mov    DWORD PTR [rsp+0x20],0xa2
   140003e01:	lea    rdx,[rip+0x15468]        # 0x140019270
   140003e08:	lea    rcx,[rsp+0x48]
   140003e0d:	call   0x14000f3ac
   140003e12:	lea    r9,[rip+0x15997]        # 0x1400197b0
   140003e19:	mov    r8d,0x1008
   140003e1f:	mov    rdx,rax
   140003e22:	mov    rcx,rbx
   140003e25:	call   0x1400106b0
   140003e2a:	int3
   140003e2b:	mov    DWORD PTR [rsp+0x28],0x7
   140003e33:	lea    r9,[rip+0x159e6]        # 0x140019820
   140003e3a:	lea    r8,[rip+0x15417]        # 0x140019258
   140003e41:	mov    DWORD PTR [rsp+0x20],0xb5
   140003e49:	lea    rdx,[rip+0x15420]        # 0x140019270
   140003e50:	lea    rcx,[rsp+0x48]
   140003e55:	call   0x14000f3ac
   140003e5a:	lea    r9,[rip+0x15aef]        # 0x140019950
   140003e61:	mov    r8d,0x1004
   140003e67:	mov    rdx,rax
   140003e6a:	mov    rcx,rbx
   140003e6d:	call   0x1400106b0
   140003e72:	int3
   140003e73:	mov    DWORD PTR [rsp+0x28],0x7
   140003e7b:	lea    r9,[rip+0x1599e]        # 0x140019820
   140003e82:	lea    r8,[rip+0x153cf]        # 0x140019258
   140003e89:	mov    DWORD PTR [rsp+0x20],0xa9
   140003e91:	lea    rdx,[rip+0x153d8]        # 0x140019270
   140003e98:	lea    rcx,[rsp+0x48]
   140003e9d:	call   0x14000f3ac
   140003ea2:	lea    r9,[rip+0x159c7]        # 0x140019870
   140003ea9:	mov    r8d,0x1007
   140003eaf:	mov    rdx,rax
   140003eb2:	mov    rcx,rbx
   140003eb5:	call   0x1400106b0
   140003eba:	int3
   140003ebb:	mov    DWORD PTR [rsp+0x28],0x7
   140003ec3:	lea    r9,[rip+0x15956]        # 0x140019820
   140003eca:	lea    r8,[rip+0x15387]        # 0x140019258
   140003ed1:	mov    DWORD PTR [rsp+0x20],0xaf
   140003ed9:	lea    rdx,[rip+0x15390]        # 0x140019270
   140003ee0:	lea    rcx,[rsp+0x48]
   140003ee5:	call   0x14000f3ac
   140003eea:	lea    r9,[rip+0x159ef]        # 0x1400198e0
   140003ef1:	mov    r8d,0x1008
   140003ef7:	mov    rdx,rax
   140003efa:	mov    rcx,rbx
   140003efd:	call   0x1400106b0
   140003f02:	int3
   140003f03:	int3
   140003f04:	int3
   140003f05:	int3
   140003f06:	int3
   140003f07:	int3
   140003f08:	int3
   140003f09:	int3
   140003f0a:	int3
   140003f0b:	int3
   140003f0c:	int3
   140003f0d:	int3
   140003f0e:	int3
   140003f0f:	int3
   140003f10:	sub    rsp,0xf8
   140003f17:	test   r9,r9
   140003f1a:	je     0x140003f2d
   140003f1c:	cmp    BYTE PTR [rsp+0x120],0x0
   140003f24:	jne    0x140003f83
   140003f26:	cmp    WORD PTR [r9],0x5c
   140003f2b:	jne    0x140003f36
   140003f2d:	add    rsp,0xf8
   140003f34:	ret
   140003f35:	int3
   140003f36:	mov    DWORD PTR [rsp+0x28],0x7
   140003f3e:	lea    r9,[rip+0x15b3b]        # 0x140019a80
   140003f45:	lea    r8,[rip+0x1530c]        # 0x140019258
   140003f4c:	mov    DWORD PTR [rsp+0x20],0xc8
   140003f54:	lea    rdx,[rip+0x15315]        # 0x140019270
   140003f5b:	lea    rcx,[rsp+0x48]
   140003f60:	call   0x14000f3ac
   140003f65:	mov    rcx,QWORD PTR [rsp+0x128]
   140003f6d:	lea    r9,[rip+0x15b5c]        # 0x140019ad0
   140003f74:	mov    r8d,0x1004
   140003f7a:	mov    rdx,rax
   140003f7d:	call   0x1400106b0
   140003f82:	int3
   140003f83:	mov    DWORD PTR [rsp+0x28],0x7
   140003f8b:	lea    r9,[rip+0x15aee]        # 0x140019a80
   140003f92:	lea    r8,[rip+0x152bf]        # 0x140019258
   140003f99:	mov    DWORD PTR [rsp+0x20],0xc3
   140003fa1:	lea    rdx,[rip+0x152c8]        # 0x140019270
   140003fa8:	lea    rcx,[rsp+0x48]
   140003fad:	call   0x14000f3ac
   140003fb2:	mov    rcx,QWORD PTR [rsp+0x128]
   140003fba:	lea    r9,[rip+0x159ff]        # 0x1400199c0
   140003fc1:	mov    r8d,0x1008
   140003fc7:	mov    rdx,rax
   140003fca:	call   0x1400106b0
   140003fcf:	int3
   140003fd0:	int3
   140003fd1:	int3
   140003fd2:	int3
   140003fd3:	int3
   140003fd4:	int3
   140003fd5:	int3
   140003fd6:	int3
   140003fd7:	int3
   140003fd8:	int3
   140003fd9:	int3
   140003fda:	int3
   140003fdb:	int3
   140003fdc:	int3
   140003fdd:	int3
   140003fde:	int3
   140003fdf:	int3
   140003fe0:	rex push rbx
   140003fe2:	sub    rsp,0xf0
   140003fe9:	mov    rax,QWORD PTR [rsp+0x120]
   140003ff1:	mov    rdx,QWORD PTR [rip+0x143b8]        # 0x1400183b0
   140003ff8:	mov    rbx,QWORD PTR [rsp+0x130]
   140004000:	mov    rcx,QWORD PTR [rip+0x143b1]        # 0x1400183b8
   140004007:	cmp    QWORD PTR [rax],rdx
   14000400a:	jne    0x140004012
   14000400c:	cmp    QWORD PTR [rax+0x8],rcx
   140004010:	je     0x140004025
   140004012:	mov    rax,QWORD PTR [rsp+0x128]
   14000401a:	cmp    QWORD PTR [rax],rdx
   14000401d:	jne    0x14000404a
   14000401f:	cmp    QWORD PTR [rax+0x8],rcx
   140004023:	jne    0x14000404a
   140004025:	xor    ecx,ecx
   140004027:	test   r9,r9
   14000402a:	je     0x140004040
   14000402c:	or     rax,0xffffffffffffffff
   140004030:	inc    rax
   140004033:	cmp    WORD PTR [r9+rax*2],cx
   140004038:	jne    0x140004030
   14000403a:	cmp    rax,0x31
   14000403e:	ja     0x140004092
   140004040:	add    rsp,0xf0
   140004047:	pop    rbx
   140004048:	ret
   140004049:	int3
   14000404a:	mov    DWORD PTR [rsp+0x28],0x7
   140004052:	lea    r9,[rip+0x15b17]        # 0x140019b70
   140004059:	lea    r8,[rip+0x151f8]        # 0x140019258
   140004060:	mov    DWORD PTR [rsp+0x20],0xf5
   140004068:	lea    rdx,[rip+0x15201]        # 0x140019270
   14000406f:	lea    rcx,[rsp+0x48]
   140004074:	call   0x14000f3ac
   140004079:	lea    r9,[rip+0x150d0]        # 0x140019150
   140004080:	mov    r8d,0x1008
   140004086:	mov    rdx,rax
   140004089:	mov    rcx,rbx
   14000408c:	call   0x1400106b0
   140004091:	int3
   140004092:	mov    DWORD PTR [rsp+0x28],0x7
   14000409a:	lea    r9,[rip+0x15acf]        # 0x140019b70
   1400040a1:	lea    r8,[rip+0x151b0]        # 0x140019258
   1400040a8:	mov    DWORD PTR [rsp+0x20],0xfa
   1400040b0:	lea    rdx,[rip+0x151b9]        # 0x140019270
   1400040b7:	lea    rcx,[rsp+0x48]
   1400040bc:	call   0x14000f3ac
   1400040c1:	lea    r9,[rip+0x15218]        # 0x1400192e0
   1400040c8:	mov    r8d,0x1004
   1400040ce:	mov    rdx,rax
   1400040d1:	mov    rcx,rbx
   1400040d4:	call   0x1400106b0
   1400040d9:	int3
   1400040da:	int3
   1400040db:	int3
   1400040dc:	int3
   1400040dd:	int3
   1400040de:	int3
   1400040df:	int3
   1400040e0:	rex push rbx
   1400040e2:	sub    rsp,0xf0
   1400040e9:	mov    rcx,r9
   1400040ec:	call   0x1400134c8
   1400040f1:	mov    rbx,rax
   1400040f4:	cmp    QWORD PTR [rsp+0x120],rax
   1400040fc:	jb     0x140004108
   1400040fe:	add    rsp,0xf0
   140004105:	pop    rbx
   140004106:	ret
   140004107:	int3
   140004108:	mov    DWORD PTR [rsp+0x28],0x7
   140004110:	lea    r9,[rip+0x15b49]        # 0x140019c60
   140004117:	lea    r8,[rip+0x1513a]        # 0x140019258
   14000411e:	mov    DWORD PTR [rsp+0x20],0x113
   140004126:	lea    rdx,[rip+0x15143]        # 0x140019270
   14000412d:	lea    rcx,[rsp+0x40]
   140004132:	call   0x14000f3ac
   140004137:	mov    rcx,QWORD PTR [rsp+0x128]
   14000413f:	lea    r9,[rip+0x15a7a]        # 0x140019bc0
   140004146:	mov    r8d,0x1001
   14000414c:	mov    QWORD PTR [rsp+0x20],rbx
   140004151:	mov    rdx,rax
   140004154:	call   0x1400106b0
   140004159:	int3
   14000415a:	int3
   14000415b:	int3
   14000415c:	int3
   14000415d:	int3
   14000415e:	int3
   14000415f:	int3
   140004160:	rex push rbx
   140004162:	sub    rsp,0xf0
   140004169:	mov    rcx,r9
   14000416c:	call   0x1400134c8
   140004171:	mov    rbx,rax
   140004174:	cmp    QWORD PTR [rsp+0x120],rax
   14000417c:	jb     0x140004188
   14000417e:	add    rsp,0xf0
   140004185:	pop    rbx
   140004186:	ret
   140004187:	int3
   140004188:	mov    DWORD PTR [rsp+0x28],0x7
   140004190:	lea    r9,[rip+0x15bb9]        # 0x140019d50
   140004197:	lea    r8,[rip+0x150ba]        # 0x140019258
   14000419e:	mov    DWORD PTR [rsp+0x20],0x127
   1400041a6:	lea    rdx,[rip+0x150c3]        # 0x140019270
   1400041ad:	lea    rcx,[rsp+0x40]
   1400041b2:	call   0x14000f3ac
   1400041b7:	mov    rcx,QWORD PTR [rsp+0x128]
   1400041bf:	lea    r9,[rip+0x15ada]        # 0x140019ca0
   1400041c6:	mov    r8d,0x1001
   1400041cc:	mov    QWORD PTR [rsp+0x20],rbx
   1400041d1:	mov    rdx,rax
   1400041d4:	call   0x1400106b0
   1400041d9:	int3
   1400041da:	int3
   1400041db:	int3
   1400041dc:	int3
   1400041dd:	int3
   1400041de:	int3
   1400041df:	int3
   1400041e0:	rex push rbx
   1400041e2:	sub    rsp,0xf0
   1400041e9:	mov    rbx,r9
   1400041ec:	test   rdx,rdx
   1400041ef:	je     0x1400041f8
   1400041f1:	test   r8b,r8b
   1400041f4:	jne    0x14000424f
   1400041f6:	jmp    0x1400041fd
   1400041f8:	test   r8b,r8b
   1400041fb:	je     0x140004207
   1400041fd:	add    rsp,0xf0
   140004204:	pop    rbx
   140004205:	ret
   140004206:	int3
   140004207:	mov    DWORD PTR [rsp+0x28],0x7
   14000420f:	lea    r9,[rip+0x15b8a]        # 0x140019da0
   140004216:	lea    r8,[rip+0x1503b]        # 0x140019258
   14000421d:	mov    DWORD PTR [rsp+0x20],0x13b
   140004225:	lea    rdx,[rip+0x15044]        # 0x140019270
   14000422c:	lea    rcx,[rsp+0x40]
   140004231:	call   0x14000f3ac
   140004236:	lea    r9,[rip+0x153f3]        # 0x140019630
   14000423d:	mov    r8d,0x1008
   140004243:	mov    rdx,rax
   140004246:	mov    rcx,rbx
   140004249:	call   0x1400106b0
   14000424e:	int3
   14000424f:	mov    DWORD PTR [rsp+0x28],0x7
   140004257:	lea    r9,[rip+0x15b42]        # 0x140019da0
   14000425e:	lea    r8,[rip+0x14ff3]        # 0x140019258
   140004265:	mov    DWORD PTR [rsp+0x20],0x138
   14000426d:	lea    rdx,[rip+0x14ffc]        # 0x140019270
   140004274:	lea    rcx,[rsp+0x40]
   140004279:	call   0x14000f3ac
   14000427e:	lea    r9,[rip+0x152db]        # 0x140019560
   140004285:	mov    r8d,0x1008
   14000428b:	mov    rdx,rax
   14000428e:	mov    rcx,rbx
   140004291:	call   0x1400106b0
   140004296:	int3
   140004297:	int3
   140004298:	int3
   140004299:	int3
   14000429a:	int3
   14000429b:	int3
   14000429c:	int3
   14000429d:	int3
   14000429e:	int3
   14000429f:	int3
   1400042a0:	sub    rsp,0xf8
   1400042a7:	test   r8,r8
   1400042aa:	je     0x1400042b1
   1400042ac:	test   r9,r9
   1400042af:	jne    0x1400042ba
   1400042b1:	add    rsp,0xf8
   1400042b8:	ret
   1400042b9:	int3
   1400042ba:	mov    DWORD PTR [rsp+0x28],0x7
   1400042c2:	lea    r9,[rip+0x15b17]        # 0x140019de0
   1400042c9:	lea    r8,[rip+0x14f88]        # 0x140019258
   1400042d0:	mov    DWORD PTR [rsp+0x20],0x154
   1400042d8:	lea    rdx,[rip+0x14f91]        # 0x140019270
   1400042df:	lea    rcx,[rsp+0x40]
   1400042e4:	call   0x14000f3ac
   1400042e9:	mov    rcx,QWORD PTR [rsp+0x120]
   1400042f1:	lea    r9,[rip+0x153c8]        # 0x1400196c0
   1400042f8:	mov    r8d,0x1008
   1400042fe:	mov    rdx,rax
   140004301:	call   0x1400106b0
   140004306:	int3
   140004307:	int3
   140004308:	int3
   140004309:	int3
   14000430a:	int3
   14000430b:	int3
   14000430c:	int3
   14000430d:	int3
   14000430e:	int3
   14000430f:	int3
   140004310:	rex push rbx
   140004312:	sub    rsp,0xf0
   140004319:	mov    rcx,QWORD PTR [rsp+0x128]
   140004321:	mov    rbx,QWORD PTR [rsp+0x138]
   140004329:	mov    rax,QWORD PTR [rcx]
   14000432c:	cmp    rax,QWORD PTR [rip+0x1407d]        # 0x1400183b0
   140004333:	jne    0x140004392
   140004335:	mov    rax,QWORD PTR [rcx+0x8]
   140004339:	cmp    rax,QWORD PTR [rip+0x14078]        # 0x1400183b8
   140004340:	jne    0x140004392
   140004342:	mov    cl,BYTE PTR [rsp+0x120]
   140004349:	xor    eax,eax
   14000434b:	test   r8,r8
   14000434e:	jne    0x14000435d
   140004350:	test   r9b,r9b
   140004353:	jne    0x14000435d
   140004355:	test   cl,cl
   140004357:	je     0x140004441
   14000435d:	test   cl,cl
   14000435f:	je     0x14000436a
   140004361:	test   r8,r8
   140004364:	je     0x140004441
   14000436a:	test   r9b,r9b
   14000436d:	je     0x140004377
   14000436f:	test   cl,cl
   140004371:	jne    0x140004489
   140004377:	test   r8,r8
   14000437a:	je     0x1400043a7
   14000437c:	or     rcx,0xffffffffffffffff
   140004380:	inc    rcx
   140004383:	cmp    WORD PTR [r8+rcx*2],ax
   140004388:	jne    0x140004380
   14000438a:	cmp    rcx,0x31
   14000438e:	ja     0x1400043f9
   140004390:	jmp    0x1400043a7
   140004392:	xor    eax,eax
   140004394:	test   r8,r8
   140004397:	jne    0x1400043b1
   140004399:	test   r9b,r9b
   14000439c:	jne    0x1400043b1
   14000439e:	cmp    BYTE PTR [rsp+0x120],al
   1400043a5:	jne    0x1400043b1
   1400043a7:	add    rsp,0xf0
   1400043ae:	pop    rbx
   1400043af:	ret
   1400043b0:	int3
   1400043b1:	mov    DWORD PTR [rsp+0x28],0x7
   1400043b9:	lea    r9,[rip+0x15a70]        # 0x140019e30
   1400043c0:	lea    r8,[rip+0x14e91]        # 0x140019258
   1400043c7:	mov    DWORD PTR [rsp+0x20],0x161
   1400043cf:	lea    rdx,[rip+0x14e9a]        # 0x140019270
   1400043d6:	lea    rcx,[rsp+0x48]
   1400043db:	call   0x14000f3ac
   1400043e0:	lea    r9,[rip+0x153c9]        # 0x1400197b0
   1400043e7:	mov    r8d,0x1008
   1400043ed:	mov    rdx,rax
   1400043f0:	mov    rcx,rbx
   1400043f3:	call   0x1400106b0
   1400043f8:	int3
   1400043f9:	mov    DWORD PTR [rsp+0x28],0x7
   140004401:	lea    r9,[rip+0x15a28]        # 0x140019e30
   140004408:	lea    r8,[rip+0x14e49]        # 0x140019258
   14000440f:	mov    DWORD PTR [rsp+0x20],0x172
   140004417:	lea    rdx,[rip+0x14e52]        # 0x140019270
   14000441e:	lea    rcx,[rsp+0x48]
   140004423:	call   0x14000f3ac
   140004428:	lea    r9,[rip+0x15521]        # 0x140019950
   14000442f:	mov    r8d,0x1004
   140004435:	mov    rdx,rax
   140004438:	mov    rcx,rbx
   14000443b:	call   0x1400106b0
   140004440:	int3
   140004441:	mov    DWORD PTR [rsp+0x28],0x7
   140004449:	lea    r9,[rip+0x159e0]        # 0x140019e30
   140004450:	lea    r8,[rip+0x14e01]        # 0x140019258
   140004457:	mov    DWORD PTR [rsp+0x20],0x167
   14000445f:	lea    rdx,[rip+0x14e0a]        # 0x140019270
   140004466:	lea    rcx,[rsp+0x48]
   14000446b:	call   0x14000f3ac
   140004470:	lea    r9,[rip+0x153f9]        # 0x140019870
   140004477:	mov    r8d,0x1007
   14000447d:	mov    rdx,rax
   140004480:	mov    rcx,rbx
   140004483:	call   0x1400106b0
   140004488:	int3
   140004489:	mov    DWORD PTR [rsp+0x28],0x7
   140004491:	lea    r9,[rip+0x15998]        # 0x140019e30
   140004498:	lea    r8,[rip+0x14db9]        # 0x140019258
   14000449f:	mov    DWORD PTR [rsp+0x20],0x16c
   1400044a7:	lea    rdx,[rip+0x14dc2]        # 0x140019270
   1400044ae:	lea    rcx,[rsp+0x48]
   1400044b3:	call   0x14000f3ac
   1400044b8:	lea    r9,[rip+0x152f1]        # 0x1400197b0
   1400044bf:	mov    r8d,0x1008
   1400044c5:	mov    rdx,rax
   1400044c8:	mov    rcx,rbx
   1400044cb:	call   0x1400106b0
   1400044d0:	int3
   1400044d1:	int3
   1400044d2:	int3
   1400044d3:	int3
   1400044d4:	int3
   1400044d5:	int3
   1400044d6:	int3
   1400044d7:	int3
   1400044d8:	mov    rax,rsp
   1400044db:	push   rdi
   1400044dc:	push   r12
   1400044de:	push   r13
   1400044e0:	push   r14
   1400044e2:	push   r15
   1400044e4:	sub    rsp,0x190
   1400044eb:	mov    QWORD PTR [rsp+0x48],0xfffffffffffffffe
   1400044f4:	mov    QWORD PTR [rax+0x8],rbx
   1400044f8:	mov    QWORD PTR [rax+0x10],rsi
   1400044fc:	movaps XMMWORD PTR [rax-0x38],xmm6
   140004500:	mov    rsi,rdx
   140004503:	mov    rbx,rcx
   140004506:	lea    r15,[rip+0x159e3]        # 0x140019ef0
   14000450d:	mov    QWORD PTR [rax-0xe8],r15
   140004514:	lea    r12,[rip+0x15965]        # 0x140019e80
   14000451b:	mov    QWORD PTR [rax-0xe0],r12
   140004522:	lea    r13,[rip+0x159a7]        # 0x140019ed0
   140004529:	mov    QWORD PTR [rax-0xd8],r13
   140004530:	mov    DWORD PTR [rax-0xd0],0x52
   14000453a:	mov    DWORD PTR [rax-0xcc],0x7
   140004544:	mov    DWORD PTR [rax-0xc8],0xff
   14000454e:	mov    DWORD PTR [rax-0x48],0x1000000
   140004555:	xor    edx,edx
   140004557:	lea    r8d,[rdx+0x78]
   14000455b:	lea    rcx,[rax-0xc0]
   140004562:	call   0x140015692
   140004567:	lea    rdx,[rsp+0xd0]
   14000456f:	lea    rcx,[rsp+0x60]
   140004574:	call   0x14000f85c
   140004579:	nop
   14000457a:	lea    rdx,[rip+0x13dff]        # 0x140018380
   140004581:	mov    ecx,0x80
   140004586:	call   0x1400143f8
   14000458b:	mov    rdi,rax
   14000458e:	test   rax,rax
   140004591:	je     0x14000468e
   140004597:	movups xmm0,XMMWORD PTR [rsi]
   14000459a:	movups XMMWORD PTR [rax],xmm0
   14000459d:	movups xmm1,XMMWORD PTR [rsi+0x10]
   1400045a1:	movups XMMWORD PTR [rax+0x10],xmm1
   1400045a5:	movups xmm0,XMMWORD PTR [rsi+0x20]
   1400045a9:	movups XMMWORD PTR [rax+0x20],xmm0
   1400045ad:	movups xmm1,XMMWORD PTR [rsi+0x30]
   1400045b1:	movups XMMWORD PTR [rax+0x30],xmm1
   1400045b5:	movups xmm0,XMMWORD PTR [rsi+0x40]
   1400045b9:	movups XMMWORD PTR [rax+0x40],xmm0
   1400045bd:	movups xmm1,XMMWORD PTR [rsi+0x50]
   1400045c1:	movups XMMWORD PTR [rax+0x50],xmm1
   1400045c5:	movups xmm0,XMMWORD PTR [rsi+0x60]
   1400045c9:	movups XMMWORD PTR [rax+0x60],xmm0
   1400045cd:	movups xmm1,XMMWORD PTR [rsi+0x70]
   1400045d1:	movups XMMWORD PTR [rax+0x70],xmm1
   1400045d5:	movups xmm6,XMMWORD PTR [rax]
   1400045d8:	mov    eax,DWORD PTR [rbx+0x28]
   1400045db:	inc    eax
   1400045dd:	movsxd rdx,eax
   1400045e0:	shl    rdx,0x4
   1400045e4:	mov    rcx,QWORD PTR [rbx+0x18]
   1400045e8:	rex.W call QWORD PTR [rip+0x13c61]        # 0x140018250
   1400045ef:	nop    DWORD PTR [rax+rax*1+0x0]
   1400045f4:	test   rax,rax
   1400045f7:	je     0x1400046ce
   1400045fd:	mov    QWORD PTR [rbx+0x18],rax
   140004601:	mov    eax,DWORD PTR [rbx+0x28]
   140004604:	inc    eax
   140004606:	movsxd rdx,eax
   140004609:	shl    rdx,0x3
   14000460d:	mov    rcx,QWORD PTR [rbx+0x20]
   140004611:	rex.W call QWORD PTR [rip+0x13c38]        # 0x140018250
   140004618:	nop    DWORD PTR [rax+rax*1+0x0]
   14000461d:	test   rax,rax
   140004620:	je     0x1400046ce
   140004626:	mov    QWORD PTR [rbx+0x20],rax
   14000462a:	movsxd rdx,DWORD PTR [rbx+0x28]
   14000462e:	lea    ecx,[rdx+0x1]
   140004631:	mov    DWORD PTR [rbx+0x28],ecx
   140004634:	mov    rcx,rdx
   140004637:	shl    rcx,0x4
   14000463b:	add    rcx,QWORD PTR [rbx+0x18]
   14000463f:	je     0x140004649
   140004641:	movdqu XMMWORD PTR [rcx],xmm6
   140004645:	mov    rax,QWORD PTR [rbx+0x20]
   140004649:	lea    rcx,[rax+rdx*8]
   14000464d:	test   rcx,rcx
   140004650:	je     0x140004655
   140004652:	mov    QWORD PTR [rcx],rdi
   140004655:	mov    ebx,DWORD PTR [rsp+0x68]
   140004659:	lea    rcx,[rsp+0x60]
   14000465e:	call   0x14000f958
   140004663:	mov    eax,ebx
   140004665:	lea    r11,[rsp+0x190]
   14000466d:	mov    rbx,QWORD PTR [r11+0x30]
   140004671:	mov    rsi,QWORD PTR [r11+0x38]
   140004675:	movaps xmm6,XMMWORD PTR [r11-0x10]
   14000467a:	mov    rsp,r11
   14000467d:	pop    r15
   14000467f:	pop    r14
   140004681:	pop    r13
   140004683:	pop    r12
   140004685:	pop    rdi
   140004686:	ret
   140004687:	int3
   140004688:	jmp    0x140004655
   14000468a:	jmp    0x140004655
   14000468c:	jmp    0x140004655
   14000468e:	mov    DWORD PTR [rsp+0x28],0x7
   140004696:	mov    DWORD PTR [rsp+0x20],0x58
   14000469e:	mov    r9,r12
   1400046a1:	mov    r8,r13
   1400046a4:	mov    rdx,r15
   1400046a7:	lea    rcx,[rsp+0xd0]
   1400046af:	call   0x14000f3ac
   1400046b4:	lea    r9,[rip+0x1453d]        # 0x140018bf8
   1400046bb:	mov    r8d,0x8007000e
   1400046c1:	mov    rdx,rax
   1400046c4:	lea    rcx,[rsp+0x60]
   1400046c9:	call   0x1400106b0
   1400046ce:	mov    rcx,rdi
   1400046d1:	call   0x14000bb18
   1400046d6:	mov    rcx,rdi
   1400046d9:	call   0x140014084
   1400046de:	mov    DWORD PTR [rsp+0x28],0x7
   1400046e6:	mov    DWORD PTR [rsp+0x20],0x63
   1400046ee:	mov    r9,r12
   1400046f1:	mov    r8,r13
   1400046f4:	mov    rdx,r15
   1400046f7:	lea    rcx,[rsp+0xd0]
   1400046ff:	call   0x14000f3ac
   140004704:	lea    r9,[rip+0x144ed]        # 0x140018bf8
   14000470b:	mov    r8d,0x8007000e
   140004711:	mov    rdx,rax
   140004714:	lea    rcx,[rsp+0x60]
   140004719:	call   0x1400106b0
   14000471e:	int3
   14000471f:	int3
   140004720:	int3
   140004721:	int3
   140004722:	int3
   140004723:	int3
   140004724:	int3
   140004725:	int3
   140004726:	int3
   140004727:	int3
   140004728:	mov    rax,rsp
   14000472b:	push   rbp
   14000472c:	push   rsi
   14000472d:	push   rdi
   14000472e:	push   r12
   140004730:	push   r13
   140004732:	push   r14
   140004734:	push   r15
   140004736:	lea    rbp,[rax-0x198]
   14000473d:	sub    rsp,0x260
   140004744:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   14000474f:	mov    QWORD PTR [rax+0x18],rbx
   140004753:	movaps XMMWORD PTR [rax-0x48],xmm6
   140004757:	mov    rax,QWORD PTR [rip+0x1f9ba]        # 0x140024118
   14000475e:	xor    rax,rsp
   140004761:	mov    QWORD PTR [rbp+0x140],rax
   140004768:	mov    r14,r9
   14000476b:	mov    r15,r8
   14000476e:	mov    ebx,edx
   140004770:	mov    rdi,rcx
   140004773:	mov    r12,QWORD PTR [rbp+0x1c8]
   14000477a:	lea    rsi,[rip+0x1576f]        # 0x140019ef0
   140004781:	mov    QWORD PTR [rbp-0x80],rsi
   140004785:	lea    rax,[rip+0x157c4]        # 0x140019f50
   14000478c:	mov    QWORD PTR [rbp-0x78],rax
   140004790:	lea    rax,[rip+0x15739]        # 0x140019ed0
   140004797:	mov    QWORD PTR [rbp-0x70],rax
   14000479b:	mov    DWORD PTR [rbp-0x68],0x8f
   1400047a2:	mov    DWORD PTR [rbp-0x64],0x7
   1400047a9:	mov    DWORD PTR [rbp-0x60],0xff
   1400047b0:	xor    r13d,r13d
   1400047b3:	mov    DWORD PTR [rbp+0x20],0x1000000
   1400047ba:	xor    edx,edx
   1400047bc:	lea    r8d,[r13+0x78]
   1400047c0:	lea    rcx,[rbp-0x58]
   1400047c4:	call   0x140015692
   1400047c9:	lea    rdx,[rbp-0x80]
   1400047cd:	lea    rcx,[rbp+0x30]
   1400047d1:	call   0x14000f85c
   1400047d6:	nop
   1400047d7:	mov    QWORD PTR [rsp+0x48],r13
   1400047dc:	movups xmm0,XMMWORD PTR [rip+0x1488d]        # 0x140019070
   1400047e3:	movdqu XMMWORD PTR [rsp+0x70],xmm0
   1400047e9:	movups xmm1,XMMWORD PTR [rip+0x14870]        # 0x140019060
   1400047f0:	movdqu XMMWORD PTR [rsp+0x50],xmm1
   1400047f6:	mov    QWORD PTR [rbp-0x80],rsi
   1400047fa:	lea    rax,[rip+0x1574f]        # 0x140019f50
   140004801:	mov    QWORD PTR [rbp-0x78],rax
   140004805:	lea    rax,[rip+0x156c4]        # 0x140019ed0
   14000480c:	mov    QWORD PTR [rbp-0x70],rax
   140004810:	mov    DWORD PTR [rbp-0x68],0x95
   140004817:	mov    DWORD PTR [rbp-0x64],0x7
   14000481e:	mov    DWORD PTR [rbp-0x60],0xff
   140004825:	mov    DWORD PTR [rbp+0x20],0x1000000
   14000482c:	xor    edx,edx
   14000482e:	lea    r8d,[r13+0x78]
   140004832:	lea    rcx,[rbp-0x58]
   140004836:	call   0x140015692
   14000483b:	lea    rax,[rsp+0x48]
   140004840:	mov    QWORD PTR [rsp+0x30],rax
   140004845:	lea    rax,[rsp+0x70]
   14000484a:	mov    QWORD PTR [rsp+0x28],rax
   14000484f:	lea    r9,[rip+0x140f2]        # 0x140018948
   140004856:	lea    r8,[rsp+0x50]
   14000485b:	lea    rdx,[rbp-0x80]
   14000485f:	lea    rcx,[rbp+0x30]
   140004863:	call   0x140011460
   140004868:	cmp    DWORD PTR [rbp+0x38],r13d
   14000486c:	jl     0x140004d0a
   140004872:	mov    rcx,QWORD PTR [rsp+0x48]
   140004877:	mov    rax,QWORD PTR [rcx]
   14000487a:	mov    edx,ebx
   14000487c:	mov    rax,QWORD PTR [rax+0x18]
   140004880:	call   QWORD PTR [rip+0x13a12]        # 0x140018298
   140004886:	mov    DWORD PTR [rbp+0x38],eax
   140004889:	test   eax,eax
   14000488b:	jns    0x14000489f
   14000488d:	cmp    eax,0x80070005
   140004892:	je     0x14000489f
   140004894:	cmp    eax,0x80004001
   140004899:	jne    0x140004d58
   14000489f:	mov    QWORD PTR [rsp+0x60],r13
   1400048a4:	movups xmm0,XMMWORD PTR [rip+0x13b05]        # 0x1400183b0
   1400048ab:	movdqu XMMWORD PTR [rsp+0x70],xmm0
   1400048b1:	mov    rcx,QWORD PTR [rsp+0x48]
   1400048b6:	mov    rax,QWORD PTR [rcx]
   1400048b9:	lea    rdx,[rsp+0x60]
   1400048be:	mov    QWORD PTR [rsp+0x20],rdx
   1400048c3:	mov    r9d,0x3
   1400048c9:	lea    r8d,[r9-0x2]
   1400048cd:	lea    rdx,[rsp+0x70]
   1400048d2:	mov    rax,QWORD PTR [rax+0x50]
   1400048d6:	call   QWORD PTR [rip+0x139bc]        # 0x140018298
   1400048dc:	mov    DWORD PTR [rbp+0x38],eax
   1400048df:	test   eax,eax
   1400048e1:	js     0x140004da6
   1400048e7:	mov    rcx,QWORD PTR [rsp+0x60]
   1400048ec:	mov    rax,QWORD PTR [rcx]
   1400048ef:	lea    r9,[rsp+0x40]
   1400048f4:	lea    r8,[rbp+0xb0]
   1400048fb:	mov    edx,0x1
   140004900:	mov    rax,QWORD PTR [rax+0x18]
   140004904:	call   QWORD PTR [rip+0x1398e]        # 0x140018298
   14000490a:	mov    DWORD PTR [rbp+0x38],eax
   14000490d:	test   eax,eax
   14000490f:	js     0x140004cbc
   140004915:	lea    rbx,[rip+0x1274c]        # 0x140017068
   14000491c:	mov    rsi,QWORD PTR [rbp+0x1c0]
   140004923:	cmp    eax,0x1
   140004926:	je     0x140004c04
   14000492c:	lea    rax,[rip+0x1288d]        # 0x1400171c0
   140004933:	mov    QWORD PTR [rsp+0x70],rax
   140004938:	lea    rax,[rbp+0xb8]
   14000493f:	mov    QWORD PTR [rsp+0x78],rax
   140004944:	mov    rcx,QWORD PTR [rip+0x13a6d]        # 0x1400183b8
   14000494b:	mov    rdx,QWORD PTR [rip+0x13a5e]        # 0x1400183b0
   140004952:	cmp    QWORD PTR [r15],rdx
   140004955:	jne    0x14000495d
   140004957:	cmp    QWORD PTR [r15+0x8],rcx
   14000495b:	je     0x14000497e
   14000495d:	mov    rax,QWORD PTR [rbp+0xc8]
   140004964:	cmp    rax,QWORD PTR [r15]
   140004967:	jne    0x140004bb4
   14000496d:	mov    rax,QWORD PTR [rbp+0xd0]
   140004974:	cmp    rax,QWORD PTR [r15+0x8]
   140004978:	jne    0x140004bb4
   14000497e:	cmp    QWORD PTR [r14],rdx
   140004981:	jne    0x140004989
   140004983:	cmp    QWORD PTR [r14+0x8],rcx
   140004987:	je     0x1400049aa
   140004989:	mov    rax,QWORD PTR [rbp+0xb8]
   140004990:	cmp    rax,QWORD PTR [r14]
   140004993:	jne    0x140004bb4
   140004999:	mov    rax,QWORD PTR [rbp+0xc0]
   1400049a0:	cmp    rax,QWORD PTR [r14+0x8]
   1400049a4:	jne    0x140004bb4
   1400049aa:	cmp    QWORD PTR [rsi],rdx
   1400049ad:	jne    0x1400049b5
   1400049af:	cmp    QWORD PTR [rsi+0x8],rcx
   1400049b3:	je     0x1400049d6
   1400049b5:	mov    rax,QWORD PTR [rbp+0x110]
   1400049bc:	cmp    rax,QWORD PTR [rsi]
   1400049bf:	jne    0x140004bb4
   1400049c5:	mov    rax,QWORD PTR [rbp+0x118]
   1400049cc:	cmp    rax,QWORD PTR [rsi+0x8]
   1400049d0:	jne    0x140004bb4
   1400049d6:	test   r12,r12
   1400049d9:	je     0x140004a00
   1400049db:	cmp    WORD PTR [r12],r13w
   1400049e0:	je     0x140004a00
   1400049e2:	mov    rdx,QWORD PTR [rbp+0xe8]
   1400049e9:	mov    rcx,r12
   1400049ec:	rex.W call QWORD PTR [rip+0x1387d]        # 0x140018270
   1400049f3:	nop    DWORD PTR [rax+rax*1+0x0]
   1400049f8:	test   eax,eax
   1400049fa:	jne    0x140004bb4
   140004a00:	lea    rax,[rip+0x154e9]        # 0x140019ef0
   140004a07:	mov    QWORD PTR [rbp-0x80],rax
   140004a0b:	lea    rax,[rip+0x1553e]        # 0x140019f50
   140004a12:	mov    QWORD PTR [rbp-0x78],rax
   140004a16:	lea    rax,[rip+0x154b3]        # 0x140019ed0
   140004a1d:	mov    QWORD PTR [rbp-0x70],rax
   140004a21:	mov    DWORD PTR [rbp-0x68],0xdf
   140004a28:	mov    DWORD PTR [rbp-0x64],0x7
   140004a2f:	mov    DWORD PTR [rbp-0x60],0xff
   140004a36:	mov    DWORD PTR [rbp+0x20],0x1000000
   140004a3d:	xor    edx,edx
   140004a3f:	lea    r8d,[rdx+0x78]
   140004a43:	lea    rcx,[rbp-0x58]
   140004a47:	call   0x140015692
   140004a4c:	mov    r9,QWORD PTR [rbp+0xe8]
   140004a53:	lea    r8,[rip+0x1557e]        # 0x140019fd8
   140004a5a:	lea    rdx,[rbp-0x80]
   140004a5e:	lea    rcx,[rbp+0x30]
   140004a62:	call   0x140010510
   140004a67:	movups xmm0,XMMWORD PTR [rbp+0xc8]
   140004a6e:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   140004a74:	mov    ecx,r13d
   140004a77:	mov    rbx,r13
   140004a7a:	cmp    DWORD PTR [rdi+0x10],r13d
   140004a7e:	jle    0x140004aa9
   140004a80:	mov    rdx,QWORD PTR [rsp+0x58]
   140004a85:	mov    r8,QWORD PTR [rsp+0x50]
   140004a8a:	movsxd rax,ecx
   140004a8d:	shl    rax,0x4
   140004a91:	add    rax,QWORD PTR [rdi]
   140004a94:	cmp    QWORD PTR [rax],r8
   140004a97:	jne    0x140004a9f
   140004a99:	cmp    QWORD PTR [rax+0x8],rdx
   140004a9d:	je     0x140004aad
   140004a9f:	inc    ecx
   140004aa1:	inc    rbx
   140004aa4:	cmp    ecx,DWORD PTR [rdi+0x10]
   140004aa7:	jl     0x140004a8a
   140004aa9:	or     rbx,0xffffffffffffffff
   140004aad:	cmp    rbx,0xffffffffffffffff
   140004ab1:	je     0x140004ac4
   140004ab3:	mov    rax,QWORD PTR [rdi+0x8]
   140004ab7:	mov    rbx,QWORD PTR [rax+rbx*8]
   140004abb:	test   rbx,rbx
   140004abe:	jne    0x140004b91
   140004ac4:	lea    rdx,[rip+0x138b5]        # 0x140018380
   140004acb:	mov    ecx,0x30
   140004ad0:	call   0x1400143f8
   140004ad5:	mov    rbx,rax
   140004ad8:	mov    QWORD PTR [rsp+0x50],rax
   140004add:	test   rax,rax
   140004ae0:	je     0x140004b04
   140004ae2:	movups xmm0,XMMWORD PTR [rbp+0xc8]
   140004ae9:	mov    eax,DWORD PTR [rbp+0xd8]
   140004aef:	movdqu XMMWORD PTR [rbx],xmm0
   140004af3:	mov    DWORD PTR [rbx+0x10],eax
   140004af6:	mov    QWORD PTR [rbx+0x18],r13
   140004afa:	mov    QWORD PTR [rbx+0x20],r13
   140004afe:	mov    DWORD PTR [rbx+0x28],r13d
   140004b02:	jmp    0x140004b07
   140004b04:	mov    rbx,r13
   140004b07:	test   rbx,rbx
   140004b0a:	je     0x140004c6d
   140004b10:	movups xmm6,XMMWORD PTR [rbp+0xc8]
   140004b17:	mov    eax,DWORD PTR [rdi+0x10]
   140004b1a:	inc    eax
   140004b1c:	movsxd rdx,eax
   140004b1f:	shl    rdx,0x4
   140004b23:	mov    rcx,QWORD PTR [rdi]
   140004b26:	rex.W call QWORD PTR [rip+0x13723]        # 0x140018250
   140004b2d:	nop    DWORD PTR [rax+rax*1+0x0]
   140004b32:	test   rax,rax
   140004b35:	je     0x140004e42
   140004b3b:	mov    QWORD PTR [rdi],rax
   140004b3e:	mov    eax,DWORD PTR [rdi+0x10]
   140004b41:	inc    eax
   140004b43:	movsxd rdx,eax
   140004b46:	shl    rdx,0x3
   140004b4a:	mov    rcx,QWORD PTR [rdi+0x8]
   140004b4e:	rex.W call QWORD PTR [rip+0x136fb]        # 0x140018250
   140004b55:	nop    DWORD PTR [rax+rax*1+0x0]
   140004b5a:	test   rax,rax
   140004b5d:	je     0x140004e42
   140004b63:	mov    QWORD PTR [rdi+0x8],rax
   140004b67:	movsxd rdx,DWORD PTR [rdi+0x10]
   140004b6b:	lea    ecx,[rdx+0x1]
   140004b6e:	mov    DWORD PTR [rdi+0x10],ecx
   140004b71:	mov    rcx,rdx
   140004b74:	shl    rcx,0x4
   140004b78:	add    rcx,QWORD PTR [rdi]
   140004b7b:	je     0x140004b85
   140004b7d:	movdqu XMMWORD PTR [rcx],xmm6
   140004b81:	mov    rax,QWORD PTR [rdi+0x8]
   140004b85:	lea    rcx,[rax+rdx*8]
   140004b89:	test   rcx,rcx
   140004b8c:	je     0x140004b91
   140004b8e:	mov    QWORD PTR [rcx],rbx
   140004b91:	lea    rdx,[rbp+0xb8]
   140004b98:	mov    rcx,rbx
   140004b9b:	call   0x1400044d8
   140004ba0:	mov    DWORD PTR [rbp+0x38],eax
   140004ba3:	test   eax,eax
   140004ba5:	js     0x140004df4
   140004bab:	lea    rbx,[rip+0x124b6]        # 0x140017068
   140004bb2:	jmp    0x140004bc7
   140004bb4:	lea    rcx,[rbp+0xb8]
   140004bbb:	rex.W call QWORD PTR [rip+0x1340e]        # 0x140017fd0
   140004bc2:	nop    DWORD PTR [rax+rax*1+0x0]
   140004bc7:	mov    QWORD PTR [rsp+0x70],rbx
   140004bcc:	mov    QWORD PTR [rsp+0x78],r13
   140004bd1:	mov    rcx,QWORD PTR [rsp+0x60]
   140004bd6:	mov    rax,QWORD PTR [rcx]
   140004bd9:	lea    r9,[rsp+0x40]
   140004bde:	lea    r8,[rbp+0xb0]
   140004be5:	mov    edx,0x1
   140004bea:	mov    rax,QWORD PTR [rax+0x18]
   140004bee:	call   QWORD PTR [rip+0x136a4]        # 0x140018298
   140004bf4:	mov    DWORD PTR [rbp+0x38],eax
   140004bf7:	test   eax,eax
   140004bf9:	js     0x140004cb5
   140004bff:	jmp    0x140004923
   140004c04:	mov    rcx,QWORD PTR [rsp+0x60]
   140004c09:	test   rcx,rcx
   140004c0c:	je     0x140004c1c
   140004c0e:	mov    rax,QWORD PTR [rcx]
   140004c11:	mov    rax,QWORD PTR [rax+0x10]
   140004c15:	call   QWORD PTR [rip+0x1367d]        # 0x140018298
   140004c1b:	nop
   140004c1c:	mov    rcx,QWORD PTR [rsp+0x48]
   140004c21:	test   rcx,rcx
   140004c24:	je     0x140004c34
   140004c26:	mov    rax,QWORD PTR [rcx]
   140004c29:	mov    rax,QWORD PTR [rax+0x10]
   140004c2d:	call   QWORD PTR [rip+0x13665]        # 0x140018298
   140004c33:	nop
   140004c34:	lea    rcx,[rbp+0x30]
   140004c38:	call   0x14000f958
   140004c3d:	mov    rcx,QWORD PTR [rbp+0x140]
   140004c44:	xor    rcx,rsp
   140004c47:	call   0x1400143c0
   140004c4c:	lea    r11,[rsp+0x260]
   140004c54:	mov    rbx,QWORD PTR [r11+0x50]
   140004c58:	movaps xmm6,XMMWORD PTR [r11-0x10]
   140004c5d:	mov    rsp,r11
   140004c60:	pop    r15
   140004c62:	pop    r14
   140004c64:	pop    r13
   140004c66:	pop    r12
   140004c68:	pop    rdi
   140004c69:	pop    rsi
   140004c6a:	pop    rbp
   140004c6b:	ret
   140004c6c:	int3
   140004c6d:	mov    DWORD PTR [rsp+0x28],0x7
   140004c75:	mov    DWORD PTR [rsp+0x20],0xea
   140004c7d:	lea    r9,[rip+0x152cc]        # 0x140019f50
   140004c84:	lea    r8,[rip+0x15245]        # 0x140019ed0
   140004c8b:	lea    rdx,[rip+0x1525e]        # 0x140019ef0
   140004c92:	lea    rcx,[rbp-0x80]
   140004c96:	call   0x14000f3ac
   140004c9b:	lea    r9,[rip+0x13f56]        # 0x140018bf8
   140004ca2:	mov    r8d,0x8007000e
   140004ca8:	mov    rdx,rax
   140004cab:	lea    rcx,[rbp+0x30]
   140004caf:	call   0x1400106b0
   140004cb4:	nop
   140004cb5:	lea    rsi,[rip+0x15234]        # 0x140019ef0
   140004cbc:	mov    DWORD PTR [rsp+0x28],0x7
   140004cc4:	mov    DWORD PTR [rsp+0x20],0xb8
   140004ccc:	lea    r9,[rip+0x1527d]        # 0x140019f50
   140004cd3:	lea    r8,[rip+0x151f6]        # 0x140019ed0
   140004cda:	mov    rdx,rsi
   140004cdd:	lea    rcx,[rbp-0x80]
   140004ce1:	call   0x14000f3ac
   140004ce6:	mov    rdx,rax
   140004ce9:	lea    rcx,[rbp+0x30]
   140004ced:	call   0x1400038ec
   140004cf2:	mov    DWORD PTR [rsp+0x20],eax
   140004cf6:	lea    r9,[rip+0x13ceb]        # 0x1400189e8
   140004cfd:	mov    r8d,eax
   140004d00:	lea    rcx,[rbp+0x30]
   140004d04:	call   0x1400106b0
   140004d09:	nop
   140004d0a:	mov    DWORD PTR [rsp+0x28],0x7
   140004d12:	mov    DWORD PTR [rsp+0x20],0x9c
   140004d1a:	lea    r9,[rip+0x1522f]        # 0x140019f50
   140004d21:	lea    r8,[rip+0x151a8]        # 0x140019ed0
   140004d28:	mov    rdx,rsi
   140004d2b:	lea    rcx,[rbp-0x80]
   140004d2f:	call   0x14000f3ac
   140004d34:	mov    rdx,rax
   140004d37:	lea    rcx,[rbp+0x30]
   140004d3b:	call   0x1400038ec
   140004d40:	mov    DWORD PTR [rsp+0x20],eax
   140004d44:	lea    r9,[rip+0x13c15]        # 0x140018960
   140004d4b:	mov    r8d,eax
   140004d4e:	lea    rcx,[rbp+0x30]
   140004d52:	call   0x1400106b0
   140004d57:	int3
   140004d58:	mov    DWORD PTR [rsp+0x28],0x7
   140004d60:	mov    DWORD PTR [rsp+0x20],0xa6
   140004d68:	lea    r9,[rip+0x151e1]        # 0x140019f50
   140004d6f:	lea    r8,[rip+0x1515a]        # 0x140019ed0
   140004d76:	mov    rdx,rsi
   140004d79:	lea    rcx,[rbp-0x80]
   140004d7d:	call   0x14000f3ac
   140004d82:	mov    rdx,rax
   140004d85:	lea    rcx,[rbp+0x30]
   140004d89:	call   0x1400038ec
   140004d8e:	mov    DWORD PTR [rsp+0x20],eax
   140004d92:	lea    r9,[rip+0x151f7]        # 0x140019f90
   140004d99:	mov    r8d,eax
   140004d9c:	lea    rcx,[rbp+0x30]
   140004da0:	call   0x1400106b0
   140004da5:	nop
   140004da6:	mov    DWORD PTR [rsp+0x28],0x7
   140004dae:	mov    DWORD PTR [rsp+0x20],0xaf
   140004db6:	lea    r9,[rip+0x15193]        # 0x140019f50
   140004dbd:	lea    r8,[rip+0x1510c]        # 0x140019ed0
   140004dc4:	mov    rdx,rsi
   140004dc7:	lea    rcx,[rbp-0x80]
   140004dcb:	call   0x14000f3ac
   140004dd0:	mov    rdx,rax
   140004dd3:	lea    rcx,[rbp+0x30]
   140004dd7:	call   0x1400038ec
   140004ddc:	mov    DWORD PTR [rsp+0x20],eax
   140004de0:	lea    r9,[rip+0x13bc1]        # 0x1400189a8
   140004de7:	mov    r8d,eax
   140004dea:	lea    rcx,[rbp+0x30]
   140004dee:	call   0x1400106b0
   140004df3:	nop
   140004df4:	mov    DWORD PTR [rsp+0x28],0x7
   140004dfc:	mov    DWORD PTR [rsp+0x20],0xf7
   140004e04:	lea    r9,[rip+0x15145]        # 0x140019f50
   140004e0b:	lea    r8,[rip+0x150be]        # 0x140019ed0
   140004e12:	lea    rdx,[rip+0x150d7]        # 0x140019ef0
   140004e19:	lea    rcx,[rbp-0x80]
   140004e1d:	call   0x14000f3ac
   140004e22:	mov    rdx,rax
   140004e25:	lea    rcx,[rbp+0x30]
   140004e29:	call   0x1400038ec
   140004e2e:	mov    r8d,eax
   140004e31:	lea    r9,[rip+0x151c0]        # 0x140019ff8
   140004e38:	lea    rcx,[rbp+0x30]
   140004e3c:	call   0x1400106b0
   140004e41:	int3
   140004e42:	mov    rcx,rbx
   140004e45:	call   0x140004fa4
   140004e4a:	mov    DWORD PTR [rsp+0x28],0x7
   140004e52:	mov    DWORD PTR [rsp+0x20],0xee
   140004e5a:	lea    r9,[rip+0x150ef]        # 0x140019f50
   140004e61:	lea    r8,[rip+0x15068]        # 0x140019ed0
   140004e68:	lea    rdx,[rip+0x15081]        # 0x140019ef0
   140004e6f:	lea    rcx,[rbp-0x80]
   140004e73:	call   0x14000f3ac
   140004e78:	lea    r9,[rip+0x13d79]        # 0x140018bf8
   140004e7f:	mov    r8d,0x8007000e
   140004e85:	mov    rdx,rax
   140004e88:	lea    rcx,[rbp+0x30]
   140004e8c:	call   0x1400106b0
   140004e91:	int3
   140004e92:	int3
   140004e93:	int3
   140004e94:	int3
   140004e95:	int3
   140004e96:	int3
   140004e97:	int3
   140004e98:	mov    rax,rsp
   140004e9b:	mov    QWORD PTR [rax+0x8],rbx
   140004e9f:	mov    QWORD PTR [rax+0x10],rsi
   140004ea3:	mov    QWORD PTR [rax+0x18],rdi
   140004ea7:	mov    QWORD PTR [rax+0x20],r14
   140004eab:	push   rbp
   140004eac:	lea    rbp,[rax-0x48]
   140004eb0:	sub    rsp,0x140
   140004eb7:	lea    rax,[rip+0x15032]        # 0x140019ef0
   140004ebe:	mov    DWORD PTR [rsp+0x3c],0x7
   140004ec6:	mov    QWORD PTR [rsp+0x20],rax
   140004ecb:	mov    rbx,rcx
   140004ece:	lea    rax,[rip+0x1514b]        # 0x14001a020
   140004ed5:	mov    DWORD PTR [rbp-0x40],0x1000000
   140004edc:	mov    QWORD PTR [rsp+0x28],rax
   140004ee1:	lea    rcx,[rsp+0x48]
   140004ee6:	lea    rax,[rip+0x14fe3]        # 0x140019ed0
   140004eed:	xor    r14d,r14d
   140004ef0:	mov    QWORD PTR [rsp+0x30],rax
   140004ef5:	xor    edx,edx
   140004ef7:	mov    eax,0xff
   140004efc:	mov    DWORD PTR [rsp+0x38],eax
   140004f00:	lea    r8d,[r14+0x78]
   140004f04:	mov    DWORD PTR [rsp+0x40],eax
   140004f08:	call   0x140015692
   140004f0d:	lea    rdx,[rsp+0x20]
   140004f12:	lea    rcx,[rbp-0x30]
   140004f16:	call   0x14000f85c
   140004f1b:	cmp    DWORD PTR [rbx+0x10],r14d
   140004f1f:	jle    0x140004f43
   140004f21:	mov    esi,DWORD PTR [rbx+0x10]
   140004f24:	mov    edi,r14d
   140004f27:	mov    rax,QWORD PTR [rbx+0x8]
   140004f2b:	mov    rcx,QWORD PTR [rdi+rax*1]
   140004f2f:	test   rcx,rcx
   140004f32:	je     0x140004f39
   140004f34:	call   0x140004fa4
   140004f39:	add    rdi,0x8
   140004f3d:	sub    rsi,0x1
   140004f41:	jne    0x140004f27
   140004f43:	lea    rcx,[rbp-0x30]
   140004f47:	call   0x14000f958
   140004f4c:	mov    rcx,QWORD PTR [rbx]
   140004f4f:	test   rcx,rcx
   140004f52:	je     0x140004f63
   140004f54:	rex.W call QWORD PTR [rip+0x132ed]        # 0x140018248
   140004f5b:	nop    DWORD PTR [rax+rax*1+0x0]
   140004f60:	mov    QWORD PTR [rbx],r14
   140004f63:	mov    rcx,QWORD PTR [rbx+0x8]
   140004f67:	test   rcx,rcx
   140004f6a:	je     0x140004f7c
   140004f6c:	rex.W call QWORD PTR [rip+0x132d5]        # 0x140018248
   140004f73:	nop    DWORD PTR [rax+rax*1+0x0]
   140004f78:	mov    QWORD PTR [rbx+0x8],r14
   140004f7c:	lea    r11,[rsp+0x140]
   140004f84:	mov    DWORD PTR [rbx+0x10],r14d
   140004f88:	mov    rbx,QWORD PTR [r11+0x10]
   140004f8c:	mov    rsi,QWORD PTR [r11+0x18]
   140004f90:	mov    rdi,QWORD PTR [r11+0x20]
   140004f94:	mov    r14,QWORD PTR [r11+0x28]
   140004f98:	mov    rsp,r11
   140004f9b:	pop    rbp
   140004f9c:	ret
   140004f9d:	int3
   140004f9e:	int3
   140004f9f:	int3
   140004fa0:	int3
   140004fa1:	int3
   140004fa2:	int3
   140004fa3:	int3
   140004fa4:	mov    QWORD PTR [rsp+0x8],rbx
   140004fa9:	mov    QWORD PTR [rsp+0x10],rbp
   140004fae:	mov    QWORD PTR [rsp+0x18],rsi
   140004fb3:	push   rdi
   140004fb4:	sub    rsp,0x20
   140004fb8:	cmp    DWORD PTR [rcx+0x28],0x0
   140004fbc:	mov    rdi,rcx
   140004fbf:	jle    0x140004fef
   140004fc1:	mov    ebp,DWORD PTR [rcx+0x28]
   140004fc4:	xor    esi,esi
   140004fc6:	mov    rax,QWORD PTR [rdi+0x20]
   140004fca:	mov    rbx,QWORD PTR [rsi+rax*1]
   140004fce:	mov    rcx,rbx
   140004fd1:	rex.W call QWORD PTR [rip+0x12ff8]        # 0x140017fd0
   140004fd8:	nop    DWORD PTR [rax+rax*1+0x0]
   140004fdd:	mov    rcx,rbx
   140004fe0:	call   0x140014084
   140004fe5:	lea    rsi,[rsi+0x8]
   140004fe9:	sub    rbp,0x1
   140004fed:	jne    0x140004fc6
   140004fef:	mov    rcx,QWORD PTR [rdi+0x18]
   140004ff3:	test   rcx,rcx
   140004ff6:	je     0x140005009
   140004ff8:	rex.W call QWORD PTR [rip+0x13249]        # 0x140018248
   140004fff:	nop    DWORD PTR [rax+rax*1+0x0]
   140005004:	and    QWORD PTR [rdi+0x18],0x0
   140005009:	mov    rcx,QWORD PTR [rdi+0x20]
   14000500d:	test   rcx,rcx
   140005010:	je     0x140005023
   140005012:	rex.W call QWORD PTR [rip+0x1322f]        # 0x140018248
   140005019:	nop    DWORD PTR [rax+rax*1+0x0]
   14000501e:	and    QWORD PTR [rdi+0x20],0x0
   140005023:	and    DWORD PTR [rdi+0x28],0x0
   140005027:	mov    rcx,rdi
   14000502a:	call   0x140014084
   14000502f:	mov    rbx,QWORD PTR [rsp+0x30]
   140005034:	mov    rax,rdi
   140005037:	mov    rbp,QWORD PTR [rsp+0x38]
   14000503c:	mov    rsi,QWORD PTR [rsp+0x40]
   140005041:	add    rsp,0x20
   140005045:	pop    rdi
   140005046:	ret
   140005047:	int3
   140005048:	int3
   140005049:	int3
   14000504a:	int3
   14000504b:	int3
   14000504c:	int3
   14000504d:	int3
   14000504e:	int3
   14000504f:	int3
   140005050:	mov    rax,rsp
   140005053:	push   rbp
   140005054:	push   r12
   140005056:	push   r13
   140005058:	push   r14
   14000505a:	push   r15
   14000505c:	lea    rbp,[rax-0xb8]
   140005063:	sub    rsp,0x190
   14000506a:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   140005073:	mov    QWORD PTR [rax+0x8],rbx
   140005077:	mov    QWORD PTR [rax+0x18],rsi
   14000507b:	mov    QWORD PTR [rax+0x20],rdi
   14000507f:	mov    rdi,r8
   140005082:	mov    rbx,rdx
   140005085:	mov    rsi,rcx
   140005088:	lea    r15,[rip+0x14e61]        # 0x140019ef0
   14000508f:	mov    QWORD PTR [rsp+0x70],r15
   140005094:	lea    r12,[rip+0x14fe5]        # 0x14001a080
   14000509b:	mov    QWORD PTR [rsp+0x78],r12
   1400050a0:	lea    r13,[rip+0x14e29]        # 0x140019ed0
   1400050a7:	mov    QWORD PTR [rbp-0x80],r13
   1400050ab:	mov    DWORD PTR [rbp-0x78],0x11c
   1400050b2:	mov    DWORD PTR [rbp-0x74],0x7
   1400050b9:	mov    DWORD PTR [rbp-0x70],0xff
   1400050c0:	mov    DWORD PTR [rbp+0x10],0x1000000
   1400050c7:	xor    edx,edx
   1400050c9:	lea    r8d,[rdx+0x78]
   1400050cd:	lea    rcx,[rbp-0x68]
   1400050d1:	call   0x140015692
   1400050d6:	lea    rdx,[rsp+0x70]
   1400050db:	lea    rcx,[rbp+0x20]
   1400050df:	call   0x14000f85c
   1400050e4:	nop
   1400050e5:	movups xmm0,XMMWORD PTR [rip+0x16cdc]        # 0x14001bdc8
   1400050ec:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   1400050f2:	movaps xmm1,XMMWORD PTR [rbx]
   1400050f5:	movdqa XMMWORD PTR [rsp+0x60],xmm1
   1400050fb:	mov    r8,rdi
   1400050fe:	lea    rdx,[rsp+0x50]
   140005103:	lea    rcx,[rsp+0x60]
   140005108:	rex.W call QWORD PTR [rip+0x12eb9]        # 0x140017fc8
   14000510f:	nop    DWORD PTR [rax+rax*1+0x0]
   140005114:	mov    DWORD PTR [rbp+0x28],eax
   140005117:	test   eax,eax
   140005119:	jns    0x140005124
   14000511b:	cmp    eax,0x80004002
   140005120:	je     0x140005196
   140005122:	jmp    0x14000514f
   140005124:	lea    rcx,[rbp+0x20]
   140005128:	call   0x14000f958
   14000512d:	lea    r11,[rsp+0x190]
   140005135:	mov    rbx,QWORD PTR [r11+0x30]
   140005139:	mov    rsi,QWORD PTR [r11+0x40]
   14000513d:	mov    rdi,QWORD PTR [r11+0x48]
   140005141:	mov    rsp,r11
   140005144:	pop    r15
   140005146:	pop    r14
   140005148:	pop    r13
   14000514a:	pop    r12
   14000514c:	pop    rbp
   14000514d:	ret
   14000514e:	int3
   14000514f:	mov    DWORD PTR [rsp+0x28],0x7
   140005157:	mov    DWORD PTR [rsp+0x20],0x128
   14000515f:	mov    r9,r12
   140005162:	mov    r8,r13
   140005165:	mov    rdx,r15
   140005168:	lea    rcx,[rsp+0x70]
   14000516d:	call   0x14000f3ac
   140005172:	mov    rdx,rax
   140005175:	lea    rcx,[rbp+0x20]
   140005179:	call   0x1400038ec
   14000517e:	mov    DWORD PTR [rsp+0x20],eax
   140005182:	lea    r9,[rip+0x14fc7]        # 0x14001a150
   140005189:	mov    r8d,eax
   14000518c:	lea    rcx,[rbp+0x20]
   140005190:	call   0x1400106b0
   140005195:	int3
   140005196:	mov    edx,0x8
   14000519b:	mov    rcx,rsi
   14000519e:	call   0x1400038f8
   1400051a3:	mov    r8,rax
   1400051a6:	mov    edx,0x40002b5d
   1400051ab:	mov    rcx,rsi
   1400051ae:	call   0x14000d524
   1400051b3:	mov    DWORD PTR [rsp+0x28],0x7
   1400051bb:	mov    DWORD PTR [rsp+0x20],0x126
   1400051c3:	mov    r9,r12
   1400051c6:	mov    r8,r13
   1400051c9:	mov    rdx,r15
   1400051cc:	lea    rcx,[rsp+0x70]
   1400051d1:	call   0x14000f3ac
   1400051d6:	lea    r9,[rip+0x14f23]        # 0x14001a100
   1400051dd:	xor    r8d,r8d
   1400051e0:	mov    rdx,rax
   1400051e3:	lea    rcx,[rbp+0x20]
   1400051e7:	call   0x1400106b0
   1400051ec:	int3
   1400051ed:	int3
   1400051ee:	int3
   1400051ef:	int3
   1400051f0:	int3
   1400051f1:	int3
   1400051f2:	int3
   1400051f3:	int3
   1400051f4:	mov    rax,rsp
   1400051f7:	push   rbp
   1400051f8:	push   rsi
   1400051f9:	push   rdi
   1400051fa:	push   r12
   1400051fc:	push   r13
   1400051fe:	push   r14
   140005200:	push   r15
   140005202:	lea    rbp,[rax-0x148]
   140005209:	sub    rsp,0x210
   140005210:	mov    QWORD PTR [rbp-0x28],0xfffffffffffffffe
   140005218:	mov    QWORD PTR [rax+0x18],rbx
   14000521c:	mov    rbx,rcx
   14000521f:	lea    rax,[rip+0x14cca]        # 0x140019ef0
   140005226:	mov    QWORD PTR [rsp+0x30],rax
   14000522b:	lea    rax,[rip+0x14f86]        # 0x14001a1b8
   140005232:	mov    QWORD PTR [rsp+0x38],rax
   140005237:	lea    rax,[rip+0x14c92]        # 0x140019ed0
   14000523e:	mov    QWORD PTR [rsp+0x40],rax
   140005243:	mov    DWORD PTR [rsp+0x48],0x133
   14000524b:	mov    DWORD PTR [rsp+0x4c],0x7
   140005253:	mov    DWORD PTR [rsp+0x50],0xff
   14000525b:	xor    r12d,r12d
   14000525e:	mov    DWORD PTR [rbp-0x30],0x1000000
   140005265:	xor    edx,edx
   140005267:	lea    r8d,[r12+0x78]
   14000526c:	lea    rcx,[rsp+0x58]
   140005271:	call   0x140015692
   140005276:	lea    rdx,[rsp+0x30]
   14000527b:	lea    rcx,[rbp-0x10]
   14000527f:	call   0x14000f85c
   140005284:	nop
   140005285:	cmp    DWORD PTR [rbx+0x60],0x17
   140005289:	je     0x140005328
   14000528f:	movsxd rax,DWORD PTR [rbx+0x60]
   140005293:	lea    r8,[rax+rax*2]
   140005297:	shl    r8,0x5
   14000529b:	lea    rdi,[rip+0x11ffe]        # 0x1400172a0
   1400052a2:	mov    edx,DWORD PTR [r8+rdi*1+0x1c]
   1400052a7:	cmp    edx,0x40002766
   1400052ad:	je     0x1400052ca
   1400052af:	cmp    edx,0x4000276d
   1400052b5:	je     0x1400052ca
   1400052b7:	mov    r9,QWORD PTR [r8+rdi*1+0x8]
   1400052bc:	mov    r8,QWORD PTR [r8+rdi*1]
   1400052c0:	mov    rcx,rbx
   1400052c3:	call   0x14000c6f4
   1400052c8:	jmp    0x140005304
   1400052ca:	call   0x140013bf8
   1400052cf:	cqo
   1400052d1:	and    edx,0xfffff
   1400052d7:	add    rax,rdx
   1400052da:	sar    rax,0x14
   1400052de:	movsxd rcx,DWORD PTR [rbx+0x60]
   1400052e2:	lea    rdx,[rcx+rcx*2]
   1400052e6:	shl    rdx,0x5
   1400052ea:	mov    QWORD PTR [rsp+0x20],rax
   1400052ef:	mov    r9,QWORD PTR [rdx+rdi*1+0x8]
   1400052f4:	mov    r8,QWORD PTR [rdx+rdi*1]
   1400052f8:	mov    edx,DWORD PTR [rdx+rdi*1+0x1c]
   1400052fc:	mov    rcx,rbx
   1400052ff:	call   0x14000c6f4
   140005304:	movsxd rax,DWORD PTR [rbx+0x60]
   140005308:	lea    rcx,[rax+rax*2]
   14000530c:	shl    rcx,0x5
   140005310:	cmp    DWORD PTR [rcx+rdi*1+0x20],r12d
   140005315:	je     0x1400054cb
   14000531b:	mov    rcx,rbx
   14000531e:	call   0x140007414
   140005323:	jmp    0x1400054cb
   140005328:	mov    edx,0x40002724
   14000532d:	mov    rcx,rbx
   140005330:	call   0x14000c6f4
   140005335:	mov    r13d,r12d
   140005338:	lea    rsi,[rip+0x11f69]        # 0x1400172a8
   14000533f:	mov    rcx,rsi
   140005342:	or     r10,0xffffffffffffffff
   140005346:	lea    r11,[rip+0x1279b]        # 0x140017ae8
   14000534d:	mov    r9d,DWORD PTR [rip+0x1f3b8]        # 0x14002470c
   140005354:	test   DWORD PTR [rcx+0xc],r9d
   140005358:	je     0x140005389
   14000535a:	mov    rax,QWORD PTR [rcx-0x8]
   14000535e:	mov    rdx,r10
   140005361:	inc    rdx
   140005364:	cmp    WORD PTR [rax+rdx*2],r12w
   140005369:	jne    0x140005361
   14000536b:	mov    r8,QWORD PTR [rcx]
   14000536e:	mov    rax,r10
   140005371:	inc    rax
   140005374:	cmp    WORD PTR [r8+rax*2],r12w
   140005379:	jne    0x140005371
   14000537b:	add    rax,0x2
   14000537f:	add    rax,rdx
   140005382:	cmp    r13d,eax
   140005385:	cmovl  r13d,eax
   140005389:	add    rcx,0x60
   14000538d:	cmp    rcx,r11
   140005390:	jl     0x140005354
   140005392:	lea    rax,[rip+0x11cc7]        # 0x140017060
   140005399:	mov    QWORD PTR [rbp-0x20],rax
   14000539d:	movsxd r14,r13d
   1400053a0:	lea    rcx,[r14*2+0x2]
   1400053a8:	rex.W call QWORD PTR [rip+0x12cc9]        # 0x140018078
   1400053af:	nop    DWORD PTR [rax+rax*1+0x0]
   1400053b4:	mov    rdi,rax
   1400053b7:	mov    QWORD PTR [rbp-0x18],rax
   1400053bb:	test   rax,rax
   1400053be:	je     0x1400054f0
   1400053c4:	mov    eax,DWORD PTR [rsi+0xc]
   1400053c7:	test   DWORD PTR [rip+0x1f33f],eax        # 0x14002470c
   1400053cd:	je     0x1400054a3
   1400053d3:	lea    eax,[r13+0x1]
   1400053d7:	movsxd rdx,eax
   1400053da:	mov    rax,QWORD PTR [rsi]
   1400053dd:	mov    QWORD PTR [rsp+0x20],rax
   1400053e2:	mov    r9,QWORD PTR [rsi-0x8]
   1400053e6:	lea    r8,[rip+0x14e03]        # 0x14001a1f0
   1400053ed:	mov    rcx,rdi
   1400053f0:	call   0x140003494
   1400053f5:	mov    r15d,eax
   1400053f8:	mov    DWORD PTR [rbp-0x8],eax
   1400053fb:	lea    rax,[rip+0x14aee]        # 0x140019ef0
   140005402:	mov    QWORD PTR [rsp+0x30],rax
   140005407:	lea    rax,[rip+0x14daa]        # 0x14001a1b8
   14000540e:	mov    QWORD PTR [rsp+0x38],rax
   140005413:	lea    rax,[rip+0x14ab6]        # 0x140019ed0
   14000541a:	mov    QWORD PTR [rsp+0x40],rax
   14000541f:	mov    DWORD PTR [rsp+0x48],0x17e
   140005427:	mov    DWORD PTR [rsp+0x4c],0x7
   14000542f:	mov    DWORD PTR [rsp+0x50],0xff
   140005437:	mov    DWORD PTR [rbp-0x30],0x1000000
   14000543e:	xor    edx,edx
   140005440:	lea    r8d,[rdx+0x78]
   140005444:	lea    rcx,[rsp+0x58]
   140005449:	call   0x140015692
   14000544e:	lea    rax,[rsp+0x30]
   140005453:	mov    QWORD PTR [rbp+0x150],rax
   14000545a:	test   r15d,r15d
   14000545d:	js     0x14000550e
   140005463:	lea    rcx,[rsp+0x30]
   140005468:	call   0x14000f484
   14000546d:	or     rax,0xffffffffffffffff
   140005471:	inc    rax
   140005474:	cmp    WORD PTR [rdi+rax*2],r12w
   140005479:	jne    0x140005471
   14000547b:	cdqe
   14000547d:	jmp    0x14000548b
   14000547f:	mov    ecx,0x20
   140005484:	mov    WORD PTR [rdi+rax*2],cx
   140005488:	inc    rax
   14000548b:	cmp    rax,r14
   14000548e:	jl     0x14000547f
   140005490:	mov    WORD PTR [rdi+r14*2],r12w
   140005495:	mov    r8,rdi
   140005498:	mov    edx,DWORD PTR [rsi+0x10]
   14000549b:	mov    rcx,rbx
   14000549e:	call   0x14000c6f4
   1400054a3:	add    rsi,0x60
   1400054a7:	lea    rax,[rip+0x1263a]        # 0x140017ae8
   1400054ae:	cmp    rsi,rax
   1400054b1:	jl     0x1400053c4
   1400054b7:	mov    DWORD PTR [rbx+0x48],r12d
   1400054bb:	mov    rcx,rdi
   1400054be:	rex.W call QWORD PTR [rip+0x12bbb]        # 0x140018080
   1400054c5:	nop    DWORD PTR [rax+rax*1+0x0]
   1400054ca:	nop
   1400054cb:	lea    rcx,[rbp-0x10]
   1400054cf:	call   0x14000f958
   1400054d4:	mov    rbx,QWORD PTR [rsp+0x260]
   1400054dc:	add    rsp,0x210
   1400054e3:	pop    r15
   1400054e5:	pop    r14
   1400054e7:	pop    r13
   1400054e9:	pop    r12
   1400054eb:	pop    rdi
   1400054ec:	pop    rsi
   1400054ed:	pop    rbp
   1400054ee:	ret
   1400054ef:	int3
   1400054f0:	mov    DWORD PTR [rbp+0x150],0x8007000e
   1400054fa:	lea    rdx,[rip+0x1cb17]        # 0x140022018
   140005501:	lea    rcx,[rbp+0x150]
   140005508:	call   0x14001478c
   14000550d:	nop
   14000550e:	lea    rdx,[rsp+0x30]
   140005513:	lea    rcx,[rbp+0x60]
   140005517:	call   0x14000f400
   14000551c:	lea    r9,[rip+0x14cdd]        # 0x14001a200
   140005523:	mov    r8d,r15d
   140005526:	mov    rdx,rax
   140005529:	lea    rcx,[rbp-0x10]
   14000552d:	call   0x140010848
   140005532:	int3
   140005533:	int3
   140005534:	int3
   140005535:	int3
   140005536:	int3
   140005537:	int3
   140005538:	int3
   140005539:	int3
   14000553a:	int3
   14000553b:	int3
   14000553c:	mov    rax,rsp
   14000553f:	push   rbp
   140005540:	push   rdi
   140005541:	push   r13
   140005543:	push   r14
   140005545:	push   r15
   140005547:	lea    rbp,[rax-0xc8]
   14000554e:	sub    rsp,0x1a0
   140005555:	mov    QWORD PTR [rsp+0x60],0xfffffffffffffffe
   14000555e:	mov    QWORD PTR [rax+0x10],rbx
   140005562:	mov    QWORD PTR [rax+0x18],rsi
   140005566:	mov    rax,QWORD PTR [rip+0x1ebab]        # 0x140024118
   14000556d:	xor    rax,rsp
   140005570:	mov    QWORD PTR [rbp+0x90],rax
   140005577:	mov    rdi,rcx
   14000557a:	lea    r13,[rip+0x1496f]        # 0x140019ef0
   140005581:	mov    QWORD PTR [rsp+0x68],r13
   140005586:	lea    rax,[rip+0x14c93]        # 0x14001a220
   14000558d:	mov    QWORD PTR [rsp+0x70],rax
   140005592:	lea    rax,[rip+0x14937]        # 0x140019ed0
   140005599:	mov    QWORD PTR [rsp+0x78],rax
   14000559e:	mov    DWORD PTR [rbp-0x80],0x18e
   1400055a5:	mov    DWORD PTR [rbp-0x7c],0x7
   1400055ac:	mov    DWORD PTR [rbp-0x78],0xff
   1400055b3:	xor    r15d,r15d
   1400055b6:	mov    DWORD PTR [rbp+0x8],0x1000000
   1400055bd:	xor    edx,edx
   1400055bf:	lea    r8d,[r15+0x78]
   1400055c3:	lea    rcx,[rbp-0x70]
   1400055c7:	call   0x140015692
   1400055cc:	lea    rdx,[rsp+0x68]
   1400055d1:	lea    rcx,[rbp+0x10]
   1400055d5:	call   0x14000f85c
   1400055da:	nop
   1400055db:	movups xmm0,XMMWORD PTR [rip+0x12dce]        # 0x1400183b0
   1400055e2:	movdqu XMMWORD PTR [rbp+0x80],xmm0
   1400055ea:	lea    rdx,[rbp+0x80]
   1400055f1:	mov    rcx,rdi
   1400055f4:	call   0x140001264
   1400055f9:	lea    edx,[r15+0x3]
   1400055fd:	mov    rcx,rdi
   140005600:	call   0x1400038f8
   140005605:	mov    rsi,rax
   140005608:	lea    edx,[r15+0x7]
   14000560c:	mov    rcx,rdi
   14000560f:	call   0x1400038f8
   140005614:	mov    r14,rax
   140005617:	lea    r8,[rsp+0x50]
   14000561c:	mov    rcx,rdi
   14000561f:	call   0x14000b9d8
   140005624:	test   eax,eax
   140005626:	jne    0x14000564d
   140005628:	lea    r9d,[r15+0x1]
   14000562c:	lea    r8,[rsp+0x50]
   140005631:	lea    edx,[rax+0x5]
   140005634:	mov    rcx,rdi
   140005637:	call   0x14000b824
   14000563c:	test   eax,eax
   14000563e:	jne    0x140005646
   140005640:	or     rbx,0xffffffffffffffff
   140005644:	jmp    0x140005680
   140005646:	mov    rbx,QWORD PTR [rsp+0x50]
   14000564b:	jmp    0x140005680
   14000564d:	mov    rbx,QWORD PTR [rsp+0x50]
   140005652:	test   rbx,rbx
   140005655:	jle    0x140005680
   140005657:	mov    rdx,rsi
   14000565a:	call   0x14000c084
   14000565f:	mov    rcx,rax
   140005662:	movabs rax,0x47ae147ae147ae15
   14000566c:	mul    rcx
   14000566f:	sub    rcx,rdx
   140005672:	shr    rcx,1
   140005675:	add    rcx,rdx
   140005678:	shr    rcx,0x6
   14000567c:	imul   rbx,rcx
   140005680:	movaps xmm0,XMMWORD PTR [rbp+0x80]
   140005687:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   14000568d:	mov    rcx,QWORD PTR [rdi]
   140005690:	mov    rax,QWORD PTR [rcx]
   140005693:	lea    rdx,[rbp+0x10]
   140005697:	mov    QWORD PTR [rsp+0x28],rdx
   14000569c:	mov    QWORD PTR [rsp+0x20],rbx
   1400056a1:	mov    r9,r14
   1400056a4:	mov    r8,rsi
   1400056a7:	lea    rdx,[rsp+0x50]
   1400056ac:	mov    rax,QWORD PTR [rax+0x28]
   1400056b0:	call   QWORD PTR [rip+0x12be2]        # 0x140018298
   1400056b6:	mov    QWORD PTR [rsp+0x40],r15
   1400056bb:	movaps xmm0,XMMWORD PTR [rbp+0x80]
   1400056c2:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   1400056c8:	lea    r8,[rsp+0x40]
   1400056cd:	lea    rdx,[rsp+0x50]
   1400056d2:	mov    rcx,rdi
   1400056d5:	call   0x140005050
   1400056da:	mov    rcx,QWORD PTR [rsp+0x40]
   1400056df:	mov    rax,QWORD PTR [rcx]
   1400056e2:	mov    r9,rbx
   1400056e5:	mov    r8,r14
   1400056e8:	mov    rdx,rsi
   1400056eb:	mov    rax,QWORD PTR [rax+0x18]
   1400056ef:	call   QWORD PTR [rip+0x12ba3]        # 0x140018298
   1400056f5:	mov    DWORD PTR [rbp+0x18],eax
   1400056f8:	test   eax,eax
   1400056fa:	jns    0x140005713
   1400056fc:	cmp    eax,0x8004230d
   140005701:	jne    0x140005771
   140005703:	mov    edx,0x40002b5f
   140005708:	mov    rcx,rdi
   14000570b:	call   0x14000d524
   140005710:	nop
   140005711:	jmp    0x140005724
   140005713:	mov    edx,0x4000274f
   140005718:	mov    rcx,rdi
   14000571b:	call   0x14000c6f4
   140005720:	mov    DWORD PTR [rdi+0x48],r15d
   140005724:	mov    rcx,QWORD PTR [rsp+0x40]
   140005729:	test   rcx,rcx
   14000572c:	je     0x14000573c
   14000572e:	mov    rax,QWORD PTR [rcx]
   140005731:	mov    rax,QWORD PTR [rax+0x10]
   140005735:	call   QWORD PTR [rip+0x12b5d]        # 0x140018298
   14000573b:	nop
   14000573c:	lea    rcx,[rbp+0x10]
   140005740:	call   0x14000f958
   140005745:	mov    rcx,QWORD PTR [rbp+0x90]
   14000574c:	xor    rcx,rsp
   14000574f:	call   0x1400143c0
   140005754:	lea    r11,[rsp+0x1a0]
   14000575c:	mov    rbx,QWORD PTR [r11+0x38]
   140005760:	mov    rsi,QWORD PTR [r11+0x40]
   140005764:	mov    rsp,r11
   140005767:	pop    r15
   140005769:	pop    r14
   14000576b:	pop    r13
   14000576d:	pop    rdi
   14000576e:	pop    rbp
   14000576f:	ret
   140005770:	int3
   140005771:	mov    DWORD PTR [rsp+0x28],0x7
   140005779:	mov    DWORD PTR [rsp+0x20],0x1b4
   140005781:	lea    r9,[rip+0x14a98]        # 0x14001a220
   140005788:	lea    r8,[rip+0x14741]        # 0x140019ed0
   14000578f:	mov    rdx,r13
   140005792:	lea    rcx,[rsp+0x68]
   140005797:	call   0x14000f3ac
   14000579c:	mov    rdx,rax
   14000579f:	lea    rcx,[rbp+0x10]
   1400057a3:	call   0x1400038ec
   1400057a8:	mov    DWORD PTR [rsp+0x20],eax
   1400057ac:	lea    r9,[rip+0x14aad]        # 0x14001a260
   1400057b3:	mov    r8d,eax
   1400057b6:	lea    rcx,[rbp+0x10]
   1400057ba:	call   0x1400106b0
   1400057bf:	int3
   1400057c0:	int3
   1400057c1:	int3
   1400057c2:	int3
   1400057c3:	int3
   1400057c4:	int3
   1400057c5:	int3
   1400057c6:	int3
   1400057c7:	int3
   1400057c8:	mov    rax,rsp
   1400057cb:	push   rbp
   1400057cc:	push   r12
   1400057ce:	push   r13
   1400057d0:	push   r14
   1400057d2:	push   r15
   1400057d4:	lea    rbp,[rax-0x198]
   1400057db:	sub    rsp,0x270
   1400057e2:	mov    QWORD PTR [rbp+0xa8],0xfffffffffffffffe
   1400057ed:	mov    QWORD PTR [rax+0x10],rbx
   1400057f1:	mov    QWORD PTR [rax+0x18],rsi
   1400057f5:	mov    QWORD PTR [rax+0x20],rdi
   1400057f9:	mov    rax,QWORD PTR [rip+0x1e918]        # 0x140024118
   140005800:	xor    rax,rsp
   140005803:	mov    QWORD PTR [rbp+0x160],rax
   14000580a:	mov    rdi,rcx
   14000580d:	lea    r13,[rip+0x146dc]        # 0x140019ef0
   140005814:	mov    QWORD PTR [rbp+0x0],r13
   140005818:	lea    r14,[rip+0x14a91]        # 0x14001a2b0
   14000581f:	mov    QWORD PTR [rbp+0x8],r14
   140005823:	lea    rsi,[rip+0x146a6]        # 0x140019ed0
   14000582a:	mov    QWORD PTR [rbp+0x10],rsi
   14000582e:	mov    DWORD PTR [rbp+0x18],0x1c6
   140005835:	mov    DWORD PTR [rbp+0x1c],0x7
   14000583c:	mov    DWORD PTR [rbp+0x20],0xff
   140005843:	xor    r12d,r12d
   140005846:	mov    DWORD PTR [rbp+0xa0],0x1000000
   140005850:	xor    edx,edx
   140005852:	lea    r8d,[r12+0x78]
   140005857:	lea    rcx,[rbp+0x28]
   14000585b:	call   0x140015692
   140005860:	lea    rdx,[rbp+0x0]
   140005864:	lea    rcx,[rbp-0x70]
   140005868:	call   0x14000f85c
   14000586d:	nop
   14000586e:	test   DWORD PTR [rip+0x1ee94],0xfffffff8        # 0x14002470c
   140005878:	je     0x140005893
   14000587a:	lea    edx,[r12+0xd]
   14000587f:	mov    rcx,rdi
   140005882:	call   0x1400038f8
   140005887:	mov    rdx,rax
   14000588a:	call   0x14000b248
   14000588f:	mov    ebx,eax
   140005891:	jmp    0x140005898
   140005893:	mov    ebx,0x1d
   140005898:	mov    edx,0x3
   14000589d:	mov    rcx,rdi
   1400058a0:	call   0x1400038f8
   1400058a5:	mov    r15,rax
   1400058a8:	movups xmm0,XMMWORD PTR [rip+0x12b01]        # 0x1400183b0
   1400058af:	movdqu XMMWORD PTR [rbp+0x150],xmm0
   1400058b7:	lea    rdx,[rbp+0x150]
   1400058be:	mov    rcx,rdi
   1400058c1:	call   0x140001264
   1400058c6:	mov    QWORD PTR [rsp+0x68],r12
   1400058cb:	xor    r9d,r9d
   1400058ce:	lea    r8,[rsp+0x68]
   1400058d3:	lea    edx,[r9+0x1]
   1400058d7:	mov    rcx,rdi
   1400058da:	call   0x14000b824
   1400058df:	mov    QWORD PTR [rsp+0x40],r12
   1400058e4:	movups xmm0,XMMWORD PTR [rip+0x13785]        # 0x140019070
   1400058eb:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   1400058f1:	movups xmm1,XMMWORD PTR [rip+0x13768]        # 0x140019060
   1400058f8:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   1400058fe:	mov    QWORD PTR [rbp+0x0],r13
   140005902:	mov    QWORD PTR [rbp+0x8],r14
   140005906:	mov    QWORD PTR [rbp+0x10],rsi
   14000590a:	mov    DWORD PTR [rbp+0x18],0x1de
   140005911:	mov    DWORD PTR [rbp+0x1c],0x7
   140005918:	mov    DWORD PTR [rbp+0x20],0xff
   14000591f:	mov    DWORD PTR [rbp+0xa0],0x1000000
   140005929:	xor    edx,edx
   14000592b:	lea    r8d,[rdx+0x78]
   14000592f:	lea    rcx,[rbp+0x28]
   140005933:	call   0x140015692
   140005938:	lea    rax,[rsp+0x40]
   14000593d:	mov    QWORD PTR [rsp+0x30],rax
   140005942:	lea    rax,[rsp+0x50]
   140005947:	mov    QWORD PTR [rsp+0x28],rax
   14000594c:	lea    r9,[rip+0x12ff5]        # 0x140018948
   140005953:	lea    r8,[rsp+0x70]
   140005958:	lea    rdx,[rbp+0x0]
   14000595c:	lea    rcx,[rbp-0x70]
   140005960:	call   0x140011460
   140005965:	cmp    DWORD PTR [rbp-0x68],r12d
   140005969:	jl     0x140005d9d
   14000596f:	mov    rcx,QWORD PTR [rsp+0x40]
   140005974:	mov    rax,QWORD PTR [rcx]
   140005977:	mov    edx,ebx
   140005979:	mov    rax,QWORD PTR [rax+0x18]
   14000597d:	call   QWORD PTR [rip+0x12915]        # 0x140018298
   140005983:	mov    DWORD PTR [rbp-0x68],eax
   140005986:	test   eax,eax
   140005988:	js     0x140005de3
   14000598e:	mov    QWORD PTR [rsp+0x60],r12
   140005993:	movups xmm0,XMMWORD PTR [rip+0x12a16]        # 0x1400183b0
   14000599a:	movdqu XMMWORD PTR [rbp+0x140],xmm0
   1400059a2:	mov    rsi,QWORD PTR [rsp+0x68]
   1400059a7:	test   rsi,rsi
   1400059aa:	jle    0x140005ce4
   1400059b0:	lea    rcx,[rsp+0x68]
   1400059b5:	rex.W call QWORD PTR [rip+0x12584]        # 0x140017f40
   1400059bc:	nop    DWORD PTR [rax+rax*1+0x0]
   1400059c1:	mov    ecx,DWORD PTR [rsp+0x68]
   1400059c5:	rex.W call QWORD PTR [rip+0x1286c]        # 0x140018238
   1400059cc:	nop    DWORD PTR [rax+rax*1+0x0]
   1400059d1:	rex.W call QWORD PTR [rip+0x12560]        # 0x140017f38
   1400059d8:	nop    DWORD PTR [rax+rax*1+0x0]
   1400059dd:	mov    r14d,eax
   1400059e0:	mov    rcx,QWORD PTR [rsp+0x40]
   1400059e5:	mov    rdx,QWORD PTR [rcx]
   1400059e8:	mov    rax,QWORD PTR [rdx+0x20]
   1400059ec:	lea    rdx,[rbp+0x140]
   1400059f3:	call   QWORD PTR [rip+0x1289f]        # 0x140018298
   1400059f9:	mov    DWORD PTR [rbp-0x68],eax
   1400059fc:	test   eax,eax
   1400059fe:	jns    0x140005af2
   140005a04:	cmp    eax,0x80042316
   140005a09:	jne    0x140005e77
   140005a0f:	rex.W call QWORD PTR [rip+0x12522]        # 0x140017f38
   140005a16:	nop    DWORD PTR [rax+rax*1+0x0]
   140005a1b:	sub    eax,r14d
   140005a1e:	mov    ecx,eax
   140005a20:	imul   rax,rsi,0xea60
   140005a27:	cmp    rcx,rax
   140005a2a:	jge    0x140005e77
   140005a30:	mov    ebx,DWORD PTR [rip+0x1e6fa]        # 0x140024130
   140005a36:	cmp    ebx,0x2710
   140005a3c:	jge    0x140005a77
   140005a3e:	rex.W call QWORD PTR [rip+0x127eb]        # 0x140018230
   140005a45:	nop    DWORD PTR [rax+rax*1+0x0]
   140005a4a:	mov    r8d,eax
   140005a4d:	mov    eax,0x57619f1
   140005a52:	imul   r8d
   140005a55:	sar    edx,0x4
   140005a58:	mov    ecx,edx
   140005a5a:	shr    ecx,0x1f
   140005a5d:	add    edx,ecx
   140005a5f:	imul   ecx,edx,0x2ee
   140005a65:	sub    r8d,ecx
   140005a68:	mov    ebx,DWORD PTR [rip+0x1e6c2]        # 0x140024130
   140005a6e:	add    ebx,r8d
   140005a71:	mov    DWORD PTR [rip+0x1e6b9],ebx        # 0x140024130
   140005a77:	mov    QWORD PTR [rbp+0x0],r13
   140005a7b:	lea    rax,[rip+0x1482e]        # 0x14001a2b0
   140005a82:	mov    QWORD PTR [rbp+0x8],rax
   140005a86:	lea    rax,[rip+0x14443]        # 0x140019ed0
   140005a8d:	mov    QWORD PTR [rbp+0x10],rax
   140005a91:	mov    DWORD PTR [rbp+0x18],0x204
   140005a98:	mov    DWORD PTR [rbp+0x1c],0x7
   140005a9f:	mov    DWORD PTR [rbp+0x20],0xff
   140005aa6:	mov    DWORD PTR [rbp+0xa0],0x1000000
   140005ab0:	xor    edx,edx
   140005ab2:	lea    r8d,[rdx+0x78]
   140005ab6:	lea    rcx,[rbp+0x28]
   140005aba:	call   0x140015692
   140005abf:	mov    r9d,ebx
   140005ac2:	lea    r8,[rip+0x14887]        # 0x14001a350
   140005ac9:	lea    rdx,[rbp+0x0]
   140005acd:	lea    rcx,[rbp-0x70]
   140005ad1:	call   0x140010510
   140005ad6:	mov    ecx,DWORD PTR [rip+0x1e654]        # 0x140024130
   140005adc:	rex.W call QWORD PTR [rip+0x1244d]        # 0x140017f30
   140005ae3:	nop    DWORD PTR [rax+rax*1+0x0]
   140005ae8:	cmp    DWORD PTR [rbp-0x68],r12d
   140005aec:	jl     0x1400059e0
   140005af2:	lea    r14,[rip+0x147b7]        # 0x14001a2b0
   140005af9:	movups xmm0,XMMWORD PTR [rip+0x128b0]        # 0x1400183b0
   140005b00:	movdqu XMMWORD PTR [rbp+0x130],xmm0
   140005b08:	movaps xmm1,XMMWORD PTR [rbp+0x150]
   140005b0f:	movdqa XMMWORD PTR [rsp+0x70],xmm1
   140005b15:	mov    rcx,QWORD PTR [rsp+0x40]
   140005b1a:	mov    rax,QWORD PTR [rcx]
   140005b1d:	lea    r9,[rbp+0x130]
   140005b24:	lea    r8,[rsp+0x70]
   140005b29:	mov    rdx,r15
   140005b2c:	mov    rax,QWORD PTR [rax+0x28]
   140005b30:	call   QWORD PTR [rip+0x12762]        # 0x140018298
   140005b36:	mov    DWORD PTR [rbp-0x68],eax
   140005b39:	test   eax,eax
   140005b3b:	js     0x140005e2d
   140005b41:	mov    DWORD PTR [rbp-0x68],r12d
   140005b45:	xor    edx,edx
   140005b47:	lea    rcx,[rsp+0x60]
   140005b4c:	rex.W call QWORD PTR [rip+0x122c5]        # 0x140017e18
   140005b53:	nop    DWORD PTR [rax+rax*1+0x0]
   140005b58:	mov    rcx,QWORD PTR [rsp+0x40]
   140005b5d:	mov    rax,QWORD PTR [rcx]
   140005b60:	lea    r8,[rsp+0x60]
   140005b65:	xor    edx,edx
   140005b67:	mov    rax,QWORD PTR [rax+0x30]
   140005b6b:	call   QWORD PTR [rip+0x12727]        # 0x140018298
   140005b71:	mov    DWORD PTR [rbp-0x68],eax
   140005b74:	test   eax,eax
   140005b76:	js     0x140005ec5
   140005b7c:	mov    rcx,QWORD PTR [rsp+0x60]
   140005b81:	mov    rax,QWORD PTR [rcx]
   140005b84:	or     edx,0xffffffff
   140005b87:	mov    rax,QWORD PTR [rax+0x20]
   140005b8b:	call   QWORD PTR [rip+0x12707]        # 0x140018298
   140005b91:	mov    DWORD PTR [rbp-0x68],eax
   140005b94:	test   eax,eax
   140005b96:	js     0x140005f0f
   140005b9c:	mov    rcx,QWORD PTR [rsp+0x60]
   140005ba1:	mov    rax,QWORD PTR [rcx]
   140005ba4:	xor    r8d,r8d
   140005ba7:	lea    rdx,[rbp-0x80]
   140005bab:	mov    rax,QWORD PTR [rax+0x28]
   140005baf:	call   QWORD PTR [rip+0x126e3]        # 0x140018298
   140005bb5:	mov    DWORD PTR [rbp-0x68],eax
   140005bb8:	test   eax,eax
   140005bba:	js     0x140005f59
   140005bc0:	mov    eax,DWORD PTR [rbp-0x80]
   140005bc3:	mov    DWORD PTR [rbp-0x68],eax
   140005bc6:	test   eax,eax
   140005bc8:	js     0x140005fa3
   140005bce:	movaps xmm0,XMMWORD PTR [rbp+0x130]
   140005bd5:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   140005bdb:	mov    rcx,QWORD PTR [rsp+0x40]
   140005be0:	mov    rax,QWORD PTR [rcx]
   140005be3:	lea    r8,[rbp+0xb0]
   140005bea:	lea    rdx,[rsp+0x70]
   140005bef:	mov    rax,QWORD PTR [rax+0x38]
   140005bf3:	call   QWORD PTR [rip+0x1269f]        # 0x140018298
   140005bf9:	mov    DWORD PTR [rbp-0x68],eax
   140005bfc:	test   eax,eax
   140005bfe:	js     0x140005d09
   140005c04:	movaps xmm0,XMMWORD PTR [rbp+0x130]
   140005c0b:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   140005c11:	lea    rcx,[rsp+0x70]
   140005c16:	call   0x14000e3fc
   140005c1b:	mov    rbx,rax
   140005c1e:	mov    QWORD PTR [rsp+0x78],rax
   140005c23:	lea    rax,[rip+0x11436]        # 0x140017060
   140005c2a:	mov    QWORD PTR [rsp+0x70],rax
   140005c2f:	mov    rcx,QWORD PTR [rbp+0xd8]
   140005c36:	mov    QWORD PTR [rsp+0x20],rcx
   140005c3b:	mov    r9,rbx
   140005c3e:	mov    r8,r15
   140005c41:	mov    edx,0x4000274d
   140005c46:	mov    rcx,rdi
   140005c49:	call   0x14000c6f4
   140005c4e:	lea    rcx,[rbp+0xb0]
   140005c55:	rex.W call QWORD PTR [rip+0x12374]        # 0x140017fd0
   140005c5c:	nop    DWORD PTR [rax+rax*1+0x0]
   140005c61:	mov    DWORD PTR [rdi+0x48],r12d
   140005c65:	test   rbx,rbx
   140005c68:	je     0x140005c7a
   140005c6a:	mov    rcx,rbx
   140005c6d:	rex.W call QWORD PTR [rip+0x1240c]        # 0x140018080
   140005c74:	nop    DWORD PTR [rax+rax*1+0x0]
   140005c79:	nop
   140005c7a:	mov    rcx,QWORD PTR [rsp+0x60]
   140005c7f:	test   rcx,rcx
   140005c82:	je     0x140005c92
   140005c84:	mov    rax,QWORD PTR [rcx]
   140005c87:	mov    rax,QWORD PTR [rax+0x10]
   140005c8b:	call   QWORD PTR [rip+0x12607]        # 0x140018298
   140005c91:	nop
   140005c92:	mov    rcx,QWORD PTR [rsp+0x40]
   140005c97:	test   rcx,rcx
   140005c9a:	je     0x140005caa
   140005c9c:	mov    rax,QWORD PTR [rcx]
   140005c9f:	mov    rax,QWORD PTR [rax+0x10]
   140005ca3:	call   QWORD PTR [rip+0x125ef]        # 0x140018298
   140005ca9:	nop
   140005caa:	lea    rcx,[rbp-0x70]
   140005cae:	call   0x14000f958
   140005cb3:	mov    rcx,QWORD PTR [rbp+0x160]
   140005cba:	xor    rcx,rsp
   140005cbd:	call   0x1400143c0
   140005cc2:	lea    r11,[rsp+0x270]
   140005cca:	mov    rbx,QWORD PTR [r11+0x38]
   140005cce:	mov    rsi,QWORD PTR [r11+0x40]
   140005cd2:	mov    rdi,QWORD PTR [r11+0x48]
   140005cd6:	mov    rsp,r11
   140005cd9:	pop    r15
   140005cdb:	pop    r14
   140005cdd:	pop    r13
   140005cdf:	pop    r12
   140005ce1:	pop    rbp
   140005ce2:	ret
   140005ce3:	int3
   140005ce4:	mov    rcx,QWORD PTR [rsp+0x40]
   140005ce9:	mov    rax,QWORD PTR [rcx]
   140005cec:	lea    rdx,[rbp+0x140]
   140005cf3:	mov    rax,QWORD PTR [rax+0x20]
   140005cf7:	call   QWORD PTR [rip+0x1259b]        # 0x140018298
   140005cfd:	mov    DWORD PTR [rbp-0x68],eax
   140005d00:	test   eax,eax
   140005d02:	js     0x140005d53
   140005d04:	jmp    0x140005af9
   140005d09:	mov    DWORD PTR [rsp+0x28],0x7
   140005d11:	mov    DWORD PTR [rsp+0x20],0x244
   140005d19:	mov    r9,r14
   140005d1c:	lea    r8,[rip+0x141ad]        # 0x140019ed0
   140005d23:	mov    rdx,r13
   140005d26:	lea    rcx,[rbp+0x0]
   140005d2a:	call   0x14000f3ac
   140005d2f:	mov    rdx,rax
   140005d32:	lea    rcx,[rbp-0x70]
   140005d36:	call   0x1400038ec
   140005d3b:	mov    DWORD PTR [rsp+0x20],eax
   140005d3f:	lea    r9,[rip+0x14892]        # 0x14001a5d8
   140005d46:	mov    r8d,eax
   140005d49:	lea    rcx,[rbp-0x70]
   140005d4d:	call   0x1400106b0
   140005d52:	int3
   140005d53:	mov    DWORD PTR [rsp+0x28],0x7
   140005d5b:	mov    DWORD PTR [rsp+0x20],0x216
   140005d63:	mov    r9,r14
   140005d66:	lea    r8,[rip+0x14163]        # 0x140019ed0
   140005d6d:	mov    rdx,r13
   140005d70:	lea    rcx,[rbp+0x0]
   140005d74:	call   0x14000f3ac
   140005d79:	mov    rdx,rax
   140005d7c:	lea    rcx,[rbp-0x70]
   140005d80:	call   0x1400038ec
   140005d85:	mov    DWORD PTR [rsp+0x20],eax
   140005d89:	lea    r9,[rip+0x14630]        # 0x14001a3c0
   140005d90:	mov    r8d,eax
   140005d93:	lea    rcx,[rbp-0x70]
   140005d97:	call   0x1400106b0
   140005d9c:	nop
   140005d9d:	mov    DWORD PTR [rsp+0x28],0x7
   140005da5:	mov    DWORD PTR [rsp+0x20],0x1e5
   140005dad:	mov    r9,r14
   140005db0:	mov    r8,rsi
   140005db3:	mov    rdx,r13
   140005db6:	lea    rcx,[rbp+0x0]
   140005dba:	call   0x14000f3ac
   140005dbf:	mov    rdx,rax
   140005dc2:	lea    rcx,[rbp-0x70]
   140005dc6:	call   0x1400038ec
   140005dcb:	mov    DWORD PTR [rsp+0x20],eax
   140005dcf:	lea    r9,[rip+0x12b8a]        # 0x140018960
   140005dd6:	mov    r8d,eax
   140005dd9:	lea    rcx,[rbp-0x70]
   140005ddd:	call   0x1400106b0
   140005de2:	int3
   140005de3:	mov    DWORD PTR [rsp+0x28],0x7
   140005deb:	mov    DWORD PTR [rsp+0x20],0x1e9
   140005df3:	mov    r9,r14
   140005df6:	mov    r8,rsi
   140005df9:	mov    rdx,r13
   140005dfc:	lea    rcx,[rbp+0x0]
   140005e00:	call   0x14000f3ac
   140005e05:	mov    rdx,rax
   140005e08:	lea    rcx,[rbp-0x70]
   140005e0c:	call   0x1400038ec
   140005e11:	mov    DWORD PTR [rsp+0x28],eax
   140005e15:	mov    DWORD PTR [rsp+0x20],ebx
   140005e19:	lea    r9,[rip+0x144d0]        # 0x14001a2f0
   140005e20:	mov    r8d,eax
   140005e23:	lea    rcx,[rbp-0x70]
   140005e27:	call   0x1400106b0
   140005e2c:	nop
   140005e2d:	mov    DWORD PTR [rsp+0x28],0x7
   140005e35:	mov    DWORD PTR [rsp+0x20],0x221
   140005e3d:	mov    r9,r14
   140005e40:	lea    r8,[rip+0x14089]        # 0x140019ed0
   140005e47:	mov    rdx,r13
   140005e4a:	lea    rcx,[rbp+0x0]
   140005e4e:	call   0x14000f3ac
   140005e53:	mov    rdx,rax
   140005e56:	lea    rcx,[rbp-0x70]
   140005e5a:	call   0x1400038ec
   140005e5f:	mov    DWORD PTR [rsp+0x20],eax
   140005e63:	lea    r9,[rip+0x145b6]        # 0x14001a420
   140005e6a:	mov    r8d,eax
   140005e6d:	lea    rcx,[rbp-0x70]
   140005e71:	call   0x1400106b0
   140005e76:	int3
   140005e77:	mov    DWORD PTR [rsp+0x28],0x7
   140005e7f:	mov    DWORD PTR [rsp+0x20],0x209
   140005e87:	lea    r9,[rip+0x14422]        # 0x14001a2b0
   140005e8e:	lea    r8,[rip+0x1403b]        # 0x140019ed0
   140005e95:	mov    rdx,r13
   140005e98:	lea    rcx,[rbp+0x0]
   140005e9c:	call   0x14000f3ac
   140005ea1:	mov    rdx,rax
   140005ea4:	lea    rcx,[rbp-0x70]
   140005ea8:	call   0x1400038ec
   140005ead:	mov    DWORD PTR [rsp+0x20],eax
   140005eb1:	lea    r9,[rip+0x14508]        # 0x14001a3c0
   140005eb8:	mov    r8d,eax
   140005ebb:	lea    rcx,[rbp-0x70]
   140005ebf:	call   0x1400106b0
   140005ec4:	int3
   140005ec5:	mov    DWORD PTR [rsp+0x28],0x7
   140005ecd:	mov    DWORD PTR [rsp+0x20],0x227
   140005ed5:	mov    r9,r14
   140005ed8:	lea    r8,[rip+0x13ff1]        # 0x140019ed0
   140005edf:	mov    rdx,r13
   140005ee2:	lea    rcx,[rbp+0x0]
   140005ee6:	call   0x14000f3ac
   140005eeb:	mov    rdx,rax
   140005eee:	lea    rcx,[rbp-0x70]
   140005ef2:	call   0x1400038ec
   140005ef7:	mov    DWORD PTR [rsp+0x20],eax
   140005efb:	lea    r9,[rip+0x1457e]        # 0x14001a480
   140005f02:	mov    r8d,eax
   140005f05:	lea    rcx,[rbp-0x70]
   140005f09:	call   0x1400106b0
   140005f0e:	int3
   140005f0f:	mov    DWORD PTR [rsp+0x28],0x7
   140005f17:	mov    DWORD PTR [rsp+0x20],0x22c
   140005f1f:	mov    r9,r14
   140005f22:	lea    r8,[rip+0x13fa7]        # 0x140019ed0
   140005f29:	mov    rdx,r13
   140005f2c:	lea    rcx,[rbp+0x0]
   140005f30:	call   0x14000f3ac
   140005f35:	mov    rdx,rax
   140005f38:	lea    rcx,[rbp-0x70]
   140005f3c:	call   0x1400038ec
   140005f41:	mov    DWORD PTR [rsp+0x20],eax
   140005f45:	lea    r9,[rip+0x14584]        # 0x14001a4d0
   140005f4c:	mov    r8d,eax
   140005f4f:	lea    rcx,[rbp-0x70]
   140005f53:	call   0x1400106b0
   140005f58:	int3
   140005f59:	mov    DWORD PTR [rsp+0x28],0x7
   140005f61:	mov    DWORD PTR [rsp+0x20],0x232
   140005f69:	mov    r9,r14
   140005f6c:	lea    r8,[rip+0x13f5d]        # 0x140019ed0
   140005f73:	mov    rdx,r13
   140005f76:	lea    rcx,[rbp+0x0]
   140005f7a:	call   0x14000f3ac
   140005f7f:	mov    rdx,rax
   140005f82:	lea    rcx,[rbp-0x70]
   140005f86:	call   0x1400038ec
   140005f8b:	mov    DWORD PTR [rsp+0x20],eax
   140005f8f:	lea    r9,[rip+0x1457a]        # 0x14001a510
   140005f96:	mov    r8d,eax
   140005f99:	lea    rcx,[rbp-0x70]
   140005f9d:	call   0x1400106b0
   140005fa2:	int3
   140005fa3:	mov    DWORD PTR [rsp+0x28],0x7
   140005fab:	mov    DWORD PTR [rsp+0x20],0x23b
   140005fb3:	mov    r9,r14
   140005fb6:	lea    r8,[rip+0x13f13]        # 0x140019ed0
   140005fbd:	mov    rdx,r13
   140005fc0:	lea    rcx,[rbp+0x0]
   140005fc4:	call   0x14000f3ac
   140005fc9:	mov    rdx,rax
   140005fcc:	lea    rcx,[rbp-0x70]
   140005fd0:	call   0x1400038ec
   140005fd5:	mov    DWORD PTR [rsp+0x20],eax
   140005fd9:	lea    r9,[rip+0x14580]        # 0x14001a560
   140005fe0:	mov    r8d,eax
   140005fe3:	lea    rcx,[rbp-0x70]
   140005fe7:	call   0x1400106b0
   140005fec:	int3
   140005fed:	int3
   140005fee:	int3
   140005fef:	int3
   140005ff0:	int3
   140005ff1:	int3
   140005ff2:	int3
   140005ff3:	int3
   140005ff4:	mov    rax,rsp
   140005ff7:	mov    QWORD PTR [rax+0x10],rdx
   140005ffb:	push   rbp
   140005ffc:	push   rsi
   140005ffd:	push   rdi
   140005ffe:	push   r12
   140006000:	push   r13
   140006002:	push   r14
   140006004:	push   r15
   140006006:	lea    rbp,[rax-0x178]
   14000600d:	sub    rsp,0x240
   140006014:	mov    QWORD PTR [rbp+0x18],0xfffffffffffffffe
   14000601c:	mov    QWORD PTR [rax+0x8],rbx
   140006020:	mov    rbx,rdx
   140006023:	mov    rsi,rcx
   140006026:	lea    rax,[rip+0x13ec3]        # 0x140019ef0
   14000602d:	mov    QWORD PTR [rbp+0x20],rax
   140006031:	lea    rax,[rip+0x145e8]        # 0x14001a620
   140006038:	mov    QWORD PTR [rbp+0x28],rax
   14000603c:	lea    rax,[rip+0x13e8d]        # 0x140019ed0
   140006043:	mov    QWORD PTR [rbp+0x30],rax
   140006047:	mov    DWORD PTR [rbp+0x38],0x255
   14000604e:	mov    DWORD PTR [rbp+0x3c],0x7
   140006055:	mov    DWORD PTR [rbp+0x40],0xff
   14000605c:	xor    r14d,r14d
   14000605f:	mov    DWORD PTR [rbp+0xc0],0x1000000
   140006069:	xor    edx,edx
   14000606b:	lea    r15d,[r14+0x1]
   14000606f:	lea    r8d,[r14+0x78]
   140006073:	lea    rcx,[rbp+0x48]
   140006077:	call   0x140015692
   14000607c:	lea    rdx,[rbp+0x20]
   140006080:	lea    rcx,[rbp+0xd0]
   140006087:	call   0x14000f85c
   14000608c:	nop
   14000608d:	mov    rax,QWORD PTR [rbx]
   140006090:	lea    r9,[rbp+0x190]
   140006097:	lea    r8,[rbp-0x18]
   14000609b:	mov    edx,r15d
   14000609e:	mov    rcx,rbx
   1400060a1:	mov    rax,QWORD PTR [rax+0x18]
   1400060a5:	call   QWORD PTR [rip+0x121ed]        # 0x140018298
   1400060ab:	mov    DWORD PTR [rbp+0xd8],eax
   1400060b1:	test   eax,eax
   1400060b3:	js     0x140006409
   1400060b9:	lea    r13,[rip+0x10fa0]        # 0x140017060
   1400060c0:	cmp    eax,r15d
   1400060c3:	je     0x1400063e1
   1400060c9:	mov    rdi,QWORD PTR [rbp-0x10]
   1400060cd:	mov    QWORD PTR [rbp-0x20],rdi
   1400060d1:	mov    QWORD PTR [rbp-0x28],r13
   1400060d5:	mov    rbx,QWORD PTR [rbp-0x8]
   1400060d9:	mov    QWORD PTR [rbp-0x30],rbx
   1400060dd:	mov    QWORD PTR [rbp-0x38],r13
   1400060e1:	mov    r8d,r15d
   1400060e4:	mov    rdx,QWORD PTR [rbp+0x10]
   1400060e8:	mov    rcx,rsi
   1400060eb:	call   0x14000d2b8
   1400060f0:	mov    QWORD PTR [rbp-0x58],rax
   1400060f4:	mov    QWORD PTR [rbp-0x60],r13
   1400060f8:	mov    r8d,r15d
   1400060fb:	mov    rdx,QWORD PTR [rbp+0x8]
   1400060ff:	mov    rcx,rsi
   140006102:	call   0x14000d2b8
   140006107:	mov    QWORD PTR [rbp-0x68],rax
   14000610b:	mov    QWORD PTR [rbp-0x70],r13
   14000610f:	mov    r8d,r15d
   140006112:	mov    rdx,QWORD PTR [rbp+0x0]
   140006116:	mov    rcx,rsi
   140006119:	call   0x14000d2b8
   14000611e:	mov    r13,rax
   140006121:	mov    QWORD PTR [rbp-0x40],rax
   140006125:	lea    r15,[rip+0x10f34]        # 0x140017060
   14000612c:	mov    QWORD PTR [rbp-0x48],r15
   140006130:	mov    rdx,rdi
   140006133:	mov    rcx,rsi
   140006136:	call   0x14000bb2c
   14000613b:	mov    QWORD PTR [rbp-0x50],rax
   14000613f:	mov    rdx,rbx
   140006142:	mov    rcx,rsi
   140006145:	call   0x14000bb2c
   14000614a:	mov    QWORD PTR [rbp+0x198],rax
   140006151:	mov    rdx,rbx
   140006154:	call   0x14000c084
   140006159:	mov    r12,rax
   14000615c:	mov    QWORD PTR [rbp-0x78],r14
   140006160:	mov    QWORD PTR [rbp-0x80],r15
   140006164:	mov    QWORD PTR [rsp+0x78],r14
   140006169:	mov    QWORD PTR [rsp+0x70],r15
   14000616e:	mov    QWORD PTR [rsp+0x68],r14
   140006173:	mov    QWORD PTR [rsp+0x60],r15
   140006178:	test   rax,rax
   14000617b:	je     0x140006225
   140006181:	movabs rax,0x47ae147ae147ae15
   14000618b:	mul    r12
   14000618e:	sub    r12,rdx
   140006191:	shr    r12,1
   140006194:	add    r12,rdx
   140006197:	shr    r12,0x6
   14000619b:	xor    edx,edx
   14000619d:	mov    rax,QWORD PTR [rbp+0x10]
   1400061a1:	div    r12
   1400061a4:	mov    r14d,0x64
   1400061aa:	mov    edx,r14d
   1400061ad:	mov    ecx,0xffffffff
   1400061b2:	cmp    rax,rcx
   1400061b5:	cmovl  rdx,rax
   1400061b9:	xor    r8d,r8d
   1400061bc:	mov    rcx,rsi
   1400061bf:	call   0x14000d2b8
   1400061c4:	mov    r15,rax
   1400061c7:	mov    QWORD PTR [rbp-0x78],rax
   1400061cb:	xor    edx,edx
   1400061cd:	mov    rax,QWORD PTR [rbp+0x8]
   1400061d1:	div    r12
   1400061d4:	mov    edx,r14d
   1400061d7:	mov    ecx,0xffffffff
   1400061dc:	cmp    rax,rcx
   1400061df:	cmovl  rdx,rax
   1400061e3:	xor    r8d,r8d
   1400061e6:	mov    rcx,rsi
   1400061e9:	call   0x14000d2b8
   1400061ee:	mov    r14,rax
   1400061f1:	mov    QWORD PTR [rsp+0x78],rax
   1400061f6:	xor    edx,edx
   1400061f8:	mov    rax,QWORD PTR [rbp+0x0]
   1400061fc:	div    r12
   1400061ff:	mov    edx,0x64
   140006204:	mov    ecx,0xffffffff
   140006209:	cmp    rax,rcx
   14000620c:	cmovl  rdx,rax
   140006210:	xor    r8d,r8d
   140006213:	mov    rcx,rsi
   140006216:	call   0x14000d2b8
   14000621b:	mov    r12,rax
   14000621e:	mov    QWORD PTR [rsp+0x68],rax
   140006223:	jmp    0x140006260
   140006225:	lea    r14,[rip+0x14440]        # 0x14001a66c
   14000622c:	mov    rdx,r14
   14000622f:	lea    rcx,[rbp-0x80]
   140006233:	call   0x14000b90c
   140006238:	mov    rdx,r14
   14000623b:	lea    rcx,[rsp+0x70]
   140006240:	call   0x14000b90c
   140006245:	mov    rdx,r14
   140006248:	lea    rcx,[rsp+0x60]
   14000624d:	call   0x14000b90c
   140006252:	mov    r15,QWORD PTR [rbp-0x78]
   140006256:	mov    r14,QWORD PTR [rsp+0x78]
   14000625b:	mov    r12,QWORD PTR [rsp+0x68]
   140006260:	mov    QWORD PTR [rsp+0x58],r12
   140006265:	mov    QWORD PTR [rsp+0x50],r13
   14000626a:	mov    QWORD PTR [rsp+0x48],r14
   14000626f:	mov    rax,QWORD PTR [rbp-0x68]
   140006273:	mov    QWORD PTR [rsp+0x40],rax
   140006278:	mov    QWORD PTR [rsp+0x38],r15
   14000627d:	mov    rax,QWORD PTR [rbp-0x58]
   140006281:	mov    QWORD PTR [rsp+0x30],rax
   140006286:	mov    QWORD PTR [rsp+0x28],rbx
   14000628b:	mov    rax,QWORD PTR [rbp+0x198]
   140006292:	mov    QWORD PTR [rsp+0x20],rax
   140006297:	mov    r9,rdi
   14000629a:	mov    r8,QWORD PTR [rbp-0x50]
   14000629e:	mov    edx,0x40002758
   1400062a3:	mov    rcx,rsi
   1400062a6:	call   0x14000c6f4
   1400062ab:	nop
   1400062ac:	test   r12,r12
   1400062af:	je     0x1400062c0
   1400062b1:	mov    rcx,r12
   1400062b4:	rex.W call QWORD PTR [rip+0x11dc5]        # 0x140018080
   1400062bb:	nop    DWORD PTR [rax+rax*1+0x0]
   1400062c0:	and    QWORD PTR [rsp+0x68],0x0
   1400062c6:	lea    r12,[rip+0x10d9b]        # 0x140017068
   1400062cd:	mov    QWORD PTR [rsp+0x60],r12
   1400062d2:	test   r14,r14
   1400062d5:	je     0x1400062e6
   1400062d7:	mov    rcx,r14
   1400062da:	rex.W call QWORD PTR [rip+0x11d9f]        # 0x140018080
   1400062e1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400062e6:	xor    r14d,r14d
   1400062e9:	mov    QWORD PTR [rsp+0x78],r14
   1400062ee:	mov    QWORD PTR [rsp+0x70],r12
   1400062f3:	test   r15,r15
   1400062f6:	je     0x140006307
   1400062f8:	mov    rcx,r15
   1400062fb:	rex.W call QWORD PTR [rip+0x11d7e]        # 0x140018080
   140006302:	nop    DWORD PTR [rax+rax*1+0x0]
   140006307:	mov    QWORD PTR [rbp-0x78],r14
   14000630b:	mov    QWORD PTR [rbp-0x80],r12
   14000630f:	test   r13,r13
   140006312:	je     0x140006323
   140006314:	mov    rcx,r13
   140006317:	rex.W call QWORD PTR [rip+0x11d62]        # 0x140018080
   14000631e:	nop    DWORD PTR [rax+rax*1+0x0]
   140006323:	mov    QWORD PTR [rbp-0x40],r14
   140006327:	mov    QWORD PTR [rbp-0x48],r12
   14000632b:	mov    rax,QWORD PTR [rbp-0x68]
   14000632f:	test   rax,rax
   140006332:	je     0x140006343
   140006334:	mov    rcx,rax
   140006337:	rex.W call QWORD PTR [rip+0x11d42]        # 0x140018080
   14000633e:	nop    DWORD PTR [rax+rax*1+0x0]
   140006343:	mov    QWORD PTR [rbp-0x68],r14
   140006347:	mov    QWORD PTR [rbp-0x70],r12
   14000634b:	mov    rax,QWORD PTR [rbp-0x58]
   14000634f:	test   rax,rax
   140006352:	je     0x140006363
   140006354:	mov    rcx,rax
   140006357:	rex.W call QWORD PTR [rip+0x11d22]        # 0x140018080
   14000635e:	nop    DWORD PTR [rax+rax*1+0x0]
   140006363:	mov    QWORD PTR [rbp-0x58],r14
   140006367:	mov    QWORD PTR [rbp-0x60],r12
   14000636b:	test   rbx,rbx
   14000636e:	je     0x14000637f
   140006370:	mov    rcx,rbx
   140006373:	rex.W call QWORD PTR [rip+0x11d06]        # 0x140018080
   14000637a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000637f:	mov    QWORD PTR [rbp-0x30],r14
   140006383:	mov    QWORD PTR [rbp-0x38],r12
   140006387:	test   rdi,rdi
   14000638a:	je     0x14000639b
   14000638c:	mov    rcx,rdi
   14000638f:	rex.W call QWORD PTR [rip+0x11cea]        # 0x140018080
   140006396:	nop    DWORD PTR [rax+rax*1+0x0]
   14000639b:	mov    QWORD PTR [rbp-0x20],r14
   14000639f:	mov    QWORD PTR [rbp-0x28],r12
   1400063a3:	mov    rcx,QWORD PTR [rbp+0x188]
   1400063aa:	mov    rax,QWORD PTR [rcx]
   1400063ad:	lea    r9,[rbp+0x190]
   1400063b4:	lea    r8,[rbp-0x18]
   1400063b8:	mov    r15d,0x1
   1400063be:	mov    edx,r15d
   1400063c1:	mov    rax,QWORD PTR [rax+0x18]
   1400063c5:	call   QWORD PTR [rip+0x11ecd]        # 0x140018298
   1400063cb:	mov    DWORD PTR [rbp+0xd8],eax
   1400063d1:	test   eax,eax
   1400063d3:	lea    r13,[rip+0x10c86]        # 0x140017060
   1400063da:	js     0x140006409
   1400063dc:	jmp    0x1400060c0
   1400063e1:	lea    rcx,[rbp+0xd0]
   1400063e8:	call   0x14000f958
   1400063ed:	mov    rbx,QWORD PTR [rsp+0x280]
   1400063f5:	add    rsp,0x240
   1400063fc:	pop    r15
   1400063fe:	pop    r14
   140006400:	pop    r13
   140006402:	pop    r12
   140006404:	pop    rdi
   140006405:	pop    rsi
   140006406:	pop    rbp
   140006407:	ret
   140006408:	int3
   140006409:	mov    DWORD PTR [rsp+0x28],0x7
   140006411:	mov    DWORD PTR [rsp+0x20],0x260
   140006419:	lea    r9,[rip+0x14200]        # 0x14001a620
   140006420:	lea    r8,[rip+0x13aa9]        # 0x140019ed0
   140006427:	lea    rdx,[rip+0x13ac2]        # 0x140019ef0
   14000642e:	lea    rcx,[rbp+0x20]
   140006432:	call   0x14000f3ac
   140006437:	mov    rdx,rax
   14000643a:	lea    rcx,[rbp+0xd0]
   140006441:	call   0x1400038ec
   140006446:	mov    DWORD PTR [rsp+0x20],eax
   14000644a:	lea    r9,[rip+0x12597]        # 0x1400189e8
   140006451:	mov    r8d,eax
   140006454:	lea    rcx,[rbp+0xd0]
   14000645b:	call   0x1400106b0
   140006460:	int3
   140006461:	int3
   140006462:	int3
   140006463:	int3
   140006464:	int3
   140006465:	int3
   140006466:	int3
   140006467:	int3
   140006468:	mov    rax,rsp
   14000646b:	push   rbp
   14000646c:	push   r12
   14000646e:	push   r13
   140006470:	push   r14
   140006472:	push   r15
   140006474:	lea    rbp,[rax-0x138]
   14000647b:	sub    rsp,0x210
   140006482:	mov    QWORD PTR [rbp+0xb0],0xfffffffffffffffe
   14000648d:	mov    QWORD PTR [rax+0x10],rbx
   140006491:	mov    QWORD PTR [rax+0x18],rsi
   140006495:	mov    QWORD PTR [rax+0x20],rdi
   140006499:	mov    rax,QWORD PTR [rip+0x1dc78]        # 0x140024118
   1400064a0:	xor    rax,rsp
   1400064a3:	mov    QWORD PTR [rbp+0x100],rax
   1400064aa:	mov    rsi,rcx
   1400064ad:	lea    r14,[rip+0x13a3c]        # 0x140019ef0
   1400064b4:	mov    QWORD PTR [rbp-0x68],r14
   1400064b8:	lea    rax,[rip+0x141b1]        # 0x14001a670
   1400064bf:	mov    QWORD PTR [rbp-0x60],rax
   1400064c3:	lea    rax,[rip+0x13a06]        # 0x140019ed0
   1400064ca:	mov    QWORD PTR [rbp-0x58],rax
   1400064ce:	mov    DWORD PTR [rbp-0x50],0x299
   1400064d5:	mov    r13d,0x7
   1400064db:	mov    DWORD PTR [rbp-0x4c],r13d
   1400064df:	mov    DWORD PTR [rbp-0x48],0xff
   1400064e6:	xor    r15d,r15d
   1400064e9:	mov    DWORD PTR [rbp+0x38],0x1000000
   1400064f0:	xor    edx,edx
   1400064f2:	lea    r12d,[r13-0x6]
   1400064f6:	lea    r8d,[r13+0x71]
   1400064fa:	lea    rcx,[rbp-0x40]
   1400064fe:	call   0x140015692
   140006503:	lea    rdx,[rbp-0x68]
   140006507:	lea    rcx,[rbp+0x40]
   14000650b:	call   0x14000f85c
   140006510:	nop
   140006511:	movups xmm0,XMMWORD PTR [rip+0x11e98]        # 0x1400183b0
   140006518:	movdqu XMMWORD PTR [rbp+0xf0],xmm0
   140006520:	lea    rdx,[rbp+0xf0]
   140006527:	mov    rcx,rsi
   14000652a:	call   0x140001264
   14000652f:	lea    edx,[r13-0x4]
   140006533:	mov    rcx,rsi
   140006536:	call   0x1400038f8
   14000653b:	mov    rdi,rax
   14000653e:	mov    edx,r13d
   140006541:	mov    rcx,rsi
   140006544:	call   0x1400038f8
   140006549:	mov    rbx,rax
   14000654c:	movaps xmm0,XMMWORD PTR [rbp+0xf0]
   140006553:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   140006559:	mov    rcx,QWORD PTR [rsi]
   14000655c:	mov    rdx,QWORD PTR [rcx]
   14000655f:	mov    rax,QWORD PTR [rdx+0x50]
   140006563:	lea    rdx,[rbp+0x40]
   140006567:	mov    QWORD PTR [rsp+0x20],rdx
   14000656c:	mov    r9,rbx
   14000656f:	mov    r8,rdi
   140006572:	lea    rdx,[rsp+0x60]
   140006577:	call   QWORD PTR [rip+0x11d1b]        # 0x140018298
   14000657d:	mov    QWORD PTR [rsp+0x70],r15
   140006582:	movaps xmm0,XMMWORD PTR [rbp+0xf0]
   140006589:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   14000658f:	lea    r8,[rsp+0x70]
   140006594:	lea    rdx,[rsp+0x60]
   140006599:	mov    rcx,rsi
   14000659c:	call   0x140005050
   1400065a1:	test   rdi,rdi
   1400065a4:	je     0x1400065f1
   1400065a6:	mov    QWORD PTR [rsp+0x40],r15
   1400065ab:	mov    rcx,QWORD PTR [rsp+0x70]
   1400065b0:	mov    rax,QWORD PTR [rcx]
   1400065b3:	lea    r8,[rsp+0x40]
   1400065b8:	mov    rdx,rdi
   1400065bb:	mov    rax,QWORD PTR [rax+0x30]
   1400065bf:	call   QWORD PTR [rip+0x11cd3]        # 0x140018298
   1400065c5:	mov    DWORD PTR [rbp+0x48],eax
   1400065c8:	test   eax,eax
   1400065ca:	js     0x14000698b
   1400065d0:	cmp    eax,r12d
   1400065d3:	je     0x1400069d6
   1400065d9:	mov    rdx,QWORD PTR [rsp+0x40]
   1400065de:	mov    rcx,rsi
   1400065e1:	call   0x140005ff4
   1400065e6:	nop
   1400065e7:	mov    rcx,QWORD PTR [rsp+0x40]
   1400065ec:	jmp    0x14000688b
   1400065f1:	test   rbx,rbx
   1400065f4:	je     0x140006639
   1400065f6:	mov    QWORD PTR [rsp+0x40],r15
   1400065fb:	mov    rcx,QWORD PTR [rsp+0x70]
   140006600:	mov    rax,QWORD PTR [rcx]
   140006603:	lea    r8,[rsp+0x40]
   140006608:	mov    rdx,rbx
   14000660b:	mov    rax,QWORD PTR [rax+0x38]
   14000660f:	call   QWORD PTR [rip+0x11c83]        # 0x140018298
   140006615:	mov    DWORD PTR [rbp+0x48],eax
   140006618:	test   eax,eax
   14000661a:	js     0x140006a14
   140006620:	cmp    eax,r12d
   140006623:	je     0x140006a5f
   140006629:	mov    rdx,QWORD PTR [rsp+0x40]
   14000662e:	mov    rcx,rsi
   140006631:	call   0x140005ff4
   140006636:	nop
   140006637:	jmp    0x1400065e7
   140006639:	mov    r14d,r12d
   14000663c:	mov    QWORD PTR [rsp+0x48],r15
   140006641:	movups xmm0,XMMWORD PTR [rip+0x156e0]        # 0x14001bd28
   140006648:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   14000664e:	movups xmm1,XMMWORD PTR [rip+0x156c3]        # 0x14001bd18
   140006655:	movdqu XMMWORD PTR [rbp-0x80],xmm1
   14000665a:	lea    rbx,[rip+0x1388f]        # 0x140019ef0
   140006661:	mov    QWORD PTR [rbp-0x68],rbx
   140006665:	lea    rdi,[rip+0x14004]        # 0x14001a670
   14000666c:	mov    QWORD PTR [rbp-0x60],rdi
   140006670:	lea    rax,[rip+0x13859]        # 0x140019ed0
   140006677:	mov    QWORD PTR [rbp-0x58],rax
   14000667b:	mov    DWORD PTR [rbp-0x50],0x2d6
   140006682:	mov    DWORD PTR [rbp-0x4c],r13d
   140006686:	mov    DWORD PTR [rbp-0x48],0xff
   14000668d:	mov    DWORD PTR [rbp+0x38],0x1000000
   140006694:	xor    edx,edx
   140006696:	lea    r8d,[rdx+0x78]
   14000669a:	lea    rcx,[rbp-0x40]
   14000669e:	call   0x140015692
   1400066a3:	lea    rax,[rsp+0x48]
   1400066a8:	mov    QWORD PTR [rsp+0x30],rax
   1400066ad:	lea    rax,[rsp+0x60]
   1400066b2:	mov    QWORD PTR [rsp+0x28],rax
   1400066b7:	lea    r9,[rip+0x1413a]        # 0x14001a7f8
   1400066be:	lea    r8,[rbp-0x80]
   1400066c2:	lea    rdx,[rbp-0x68]
   1400066c6:	lea    rcx,[rbp+0x40]
   1400066ca:	call   0x140011460
   1400066cf:	cmp    DWORD PTR [rbp+0x48],r15d
   1400066d3:	jl     0x140006a9d
   1400066d9:	mov    QWORD PTR [rsp+0x40],r15
   1400066de:	movaps xmm0,XMMWORD PTR [rbp+0xf0]
   1400066e5:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   1400066eb:	mov    rcx,QWORD PTR [rsp+0x48]
   1400066f0:	mov    rax,QWORD PTR [rcx]
   1400066f3:	lea    r9,[rsp+0x40]
   1400066f8:	or     r8d,0xffffffff
   1400066fc:	lea    rdx,[rsp+0x60]
   140006701:	mov    rax,QWORD PTR [rax+0x20]
   140006705:	call   QWORD PTR [rip+0x11b8d]        # 0x140018298
   14000670b:	mov    DWORD PTR [rbp+0x48],eax
   14000670e:	test   eax,eax
   140006710:	js     0x140006ae4
   140006716:	cmp    eax,r12d
   140006719:	je     0x140006b2b
   14000671f:	mov    rcx,QWORD PTR [rsp+0x40]
   140006724:	mov    rax,QWORD PTR [rcx]
   140006727:	lea    r9,[rsp+0x78]
   14000672c:	lea    r8,[rbp+0xb8]
   140006733:	mov    edx,r12d
   140006736:	mov    rax,QWORD PTR [rax+0x18]
   14000673a:	call   QWORD PTR [rip+0x11b58]        # 0x140018298
   140006740:	mov    DWORD PTR [rbp+0x48],eax
   140006743:	test   eax,eax
   140006745:	js     0x140006944
   14000674b:	lea    rcx,[rip+0x1090e]        # 0x140017060
   140006752:	cmp    eax,r12d
   140006755:	je     0x140006865
   14000675b:	mov    rbx,QWORD PTR [rbp+0xc0]
   140006762:	mov    QWORD PTR [rsp+0x68],rbx
   140006767:	mov    QWORD PTR [rsp+0x60],rcx
   14000676c:	mov    rdi,QWORD PTR [rbp+0xc8]
   140006773:	mov    QWORD PTR [rbp-0x78],rdi
   140006777:	mov    QWORD PTR [rbp-0x80],rcx
   14000677b:	mov    QWORD PTR [rsp+0x50],r15
   140006780:	mov    rcx,QWORD PTR [rsp+0x70]
   140006785:	mov    rax,QWORD PTR [rcx]
   140006788:	lea    r8,[rsp+0x50]
   14000678d:	mov    rdx,rbx
   140006790:	mov    rax,QWORD PTR [rax+0x30]
   140006794:	call   QWORD PTR [rip+0x11afe]        # 0x140018298
   14000679a:	mov    DWORD PTR [rbp+0x48],eax
   14000679d:	test   eax,eax
   14000679f:	js     0x140006b65
   1400067a5:	cmp    eax,r12d
   1400067a8:	jne    0x1400067c4
   1400067aa:	mov    rcx,QWORD PTR [rsp+0x50]
   1400067af:	test   rcx,rcx
   1400067b2:	je     0x1400067c2
   1400067b4:	mov    rax,QWORD PTR [rcx]
   1400067b7:	mov    rax,QWORD PTR [rax+0x10]
   1400067bb:	call   QWORD PTR [rip+0x11ad7]        # 0x140018298
   1400067c1:	nop
   1400067c2:	jmp    0x1400067ec
   1400067c4:	mov    rdx,QWORD PTR [rsp+0x50]
   1400067c9:	mov    rcx,rsi
   1400067cc:	call   0x140005ff4
   1400067d1:	mov    r14d,r15d
   1400067d4:	mov    rcx,QWORD PTR [rsp+0x50]
   1400067d9:	test   rcx,rcx
   1400067dc:	je     0x1400067ec
   1400067de:	mov    rax,QWORD PTR [rcx]
   1400067e1:	mov    rax,QWORD PTR [rax+0x10]
   1400067e5:	call   QWORD PTR [rip+0x11aad]        # 0x140018298
   1400067eb:	nop
   1400067ec:	test   rdi,rdi
   1400067ef:	je     0x140006800
   1400067f1:	mov    rcx,rdi
   1400067f4:	rex.W call QWORD PTR [rip+0x11885]        # 0x140018080
   1400067fb:	nop    DWORD PTR [rax+rax*1+0x0]
   140006800:	lea    rdi,[rip+0x10861]        # 0x140017068
   140006807:	mov    QWORD PTR [rbp-0x80],rdi
   14000680b:	mov    QWORD PTR [rbp-0x78],r15
   14000680f:	test   rbx,rbx
   140006812:	je     0x140006823
   140006814:	mov    rcx,rbx
   140006817:	rex.W call QWORD PTR [rip+0x11862]        # 0x140018080
   14000681e:	nop    DWORD PTR [rax+rax*1+0x0]
   140006823:	mov    QWORD PTR [rsp+0x60],rdi
   140006828:	mov    QWORD PTR [rsp+0x68],r15
   14000682d:	mov    rcx,QWORD PTR [rsp+0x40]
   140006832:	mov    rax,QWORD PTR [rcx]
   140006835:	lea    r9,[rsp+0x78]
   14000683a:	lea    r8,[rbp+0xb8]
   140006841:	mov    edx,r12d
   140006844:	mov    rax,QWORD PTR [rax+0x18]
   140006848:	call   QWORD PTR [rip+0x11a4a]        # 0x140018298
   14000684e:	mov    DWORD PTR [rbp+0x48],eax
   140006851:	test   eax,eax
   140006853:	lea    rcx,[rip+0x10806]        # 0x140017060
   14000685a:	js     0x140006936
   140006860:	jmp    0x140006752
   140006865:	test   r14d,r14d
   140006868:	jne    0x1400068f4
   14000686e:	mov    rcx,QWORD PTR [rsp+0x40]
   140006873:	test   rcx,rcx
   140006876:	je     0x140006886
   140006878:	mov    rax,QWORD PTR [rcx]
   14000687b:	mov    rax,QWORD PTR [rax+0x10]
   14000687f:	call   QWORD PTR [rip+0x11a13]        # 0x140018298
   140006885:	nop
   140006886:	mov    rcx,QWORD PTR [rsp+0x48]
   14000688b:	test   rcx,rcx
   14000688e:	je     0x14000689e
   140006890:	mov    rax,QWORD PTR [rcx]
   140006893:	mov    rax,QWORD PTR [rax+0x10]
   140006897:	call   QWORD PTR [rip+0x119fb]        # 0x140018298
   14000689d:	nop
   14000689e:	mov    DWORD PTR [rsi+0x48],r15d
   1400068a2:	mov    rcx,QWORD PTR [rsp+0x70]
   1400068a7:	test   rcx,rcx
   1400068aa:	je     0x1400068ba
   1400068ac:	mov    rax,QWORD PTR [rcx]
   1400068af:	mov    rax,QWORD PTR [rax+0x10]
   1400068b3:	call   QWORD PTR [rip+0x119df]        # 0x140018298
   1400068b9:	nop
   1400068ba:	lea    rcx,[rbp+0x40]
   1400068be:	call   0x14000f958
   1400068c3:	mov    rcx,QWORD PTR [rbp+0x100]
   1400068ca:	xor    rcx,rsp
   1400068cd:	call   0x1400143c0
   1400068d2:	lea    r11,[rsp+0x210]
   1400068da:	mov    rbx,QWORD PTR [r11+0x38]
   1400068de:	mov    rsi,QWORD PTR [r11+0x40]
   1400068e2:	mov    rdi,QWORD PTR [r11+0x48]
   1400068e6:	mov    rsp,r11
   1400068e9:	pop    r15
   1400068eb:	pop    r14
   1400068ed:	pop    r13
   1400068ef:	pop    r12
   1400068f1:	pop    rbp
   1400068f2:	ret
   1400068f3:	int3
   1400068f4:	mov    DWORD PTR [rsp+0x28],r13d
   1400068f9:	mov    DWORD PTR [rsp+0x20],0x31a
   140006901:	lea    r9,[rip+0x13d68]        # 0x14001a670
   140006908:	lea    r8,[rip+0x135c1]        # 0x140019ed0
   14000690f:	lea    rdx,[rip+0x135da]        # 0x140019ef0
   140006916:	lea    rcx,[rbp-0x68]
   14000691a:	call   0x14000f3ac
   14000691f:	lea    r9,[rip+0x13dea]        # 0x14001a710
   140006926:	mov    r8d,r12d
   140006929:	mov    rdx,rax
   14000692c:	lea    rcx,[rbp+0x40]
   140006930:	call   0x1400106b0
   140006935:	int3
   140006936:	lea    rbx,[rip+0x135b3]        # 0x140019ef0
   14000693d:	lea    rdi,[rip+0x13d2c]        # 0x14001a670
   140006944:	mov    DWORD PTR [rsp+0x28],r13d
   140006949:	mov    DWORD PTR [rsp+0x20],0x2fa
   140006951:	mov    r9,rdi
   140006954:	lea    r8,[rip+0x13575]        # 0x140019ed0
   14000695b:	mov    rdx,rbx
   14000695e:	lea    rcx,[rbp-0x68]
   140006962:	call   0x14000f3ac
   140006967:	mov    rdx,rax
   14000696a:	lea    rcx,[rbp+0x40]
   14000696e:	call   0x1400038ec
   140006973:	mov    DWORD PTR [rsp+0x20],eax
   140006977:	lea    r9,[rip+0x1206a]        # 0x1400189e8
   14000697e:	mov    r8d,eax
   140006981:	lea    rcx,[rbp+0x40]
   140006985:	call   0x1400106b0
   14000698a:	nop
   14000698b:	mov    DWORD PTR [rsp+0x28],r13d
   140006990:	mov    DWORD PTR [rsp+0x20],0x2b2
   140006998:	lea    r9,[rip+0x13cd1]        # 0x14001a670
   14000699f:	lea    r8,[rip+0x1352a]        # 0x140019ed0
   1400069a6:	mov    rdx,r14
   1400069a9:	lea    rcx,[rbp-0x68]
   1400069ad:	call   0x14000f3ac
   1400069b2:	mov    rdx,rax
   1400069b5:	lea    rcx,[rbp+0x40]
   1400069b9:	call   0x1400038ec
   1400069be:	mov    DWORD PTR [rsp+0x20],eax
   1400069c2:	lea    r9,[rip+0x13ce7]        # 0x14001a6b0
   1400069c9:	mov    r8d,eax
   1400069cc:	lea    rcx,[rbp+0x40]
   1400069d0:	call   0x1400106b0
   1400069d5:	int3
   1400069d6:	mov    DWORD PTR [rsp+0x28],r13d
   1400069db:	mov    DWORD PTR [rsp+0x20],0x2b6
   1400069e3:	lea    r9,[rip+0x13c86]        # 0x14001a670
   1400069ea:	lea    r8,[rip+0x134df]        # 0x140019ed0
   1400069f1:	mov    rdx,r14
   1400069f4:	lea    rcx,[rbp-0x68]
   1400069f8:	call   0x14000f3ac
   1400069fd:	lea    r9,[rip+0x13d0c]        # 0x14001a710
   140006a04:	mov    r8d,r12d
   140006a07:	mov    rdx,rax
   140006a0a:	lea    rcx,[rbp+0x40]
   140006a0e:	call   0x1400106b0
   140006a13:	nop
   140006a14:	mov    DWORD PTR [rsp+0x28],r13d
   140006a19:	mov    DWORD PTR [rsp+0x20],0x2c3
   140006a21:	lea    r9,[rip+0x13c48]        # 0x14001a670
   140006a28:	lea    r8,[rip+0x134a1]        # 0x140019ed0
   140006a2f:	mov    rdx,r14
   140006a32:	lea    rcx,[rbp-0x68]
   140006a36:	call   0x14000f3ac
   140006a3b:	mov    rdx,rax
   140006a3e:	lea    rcx,[rbp+0x40]
   140006a42:	call   0x1400038ec
   140006a47:	mov    DWORD PTR [rsp+0x20],eax
   140006a4b:	lea    r9,[rip+0x13d4e]        # 0x14001a7a0
   140006a52:	mov    r8d,eax
   140006a55:	lea    rcx,[rbp+0x40]
   140006a59:	call   0x1400106b0
   140006a5e:	int3
   140006a5f:	mov    DWORD PTR [rsp+0x28],r13d
   140006a64:	mov    DWORD PTR [rsp+0x20],0x2c7
   140006a6c:	lea    r9,[rip+0x13bfd]        # 0x14001a670
   140006a73:	lea    r8,[rip+0x13456]        # 0x140019ed0
   140006a7a:	mov    rdx,r14
   140006a7d:	lea    rcx,[rbp-0x68]
   140006a81:	call   0x14000f3ac
   140006a86:	lea    r9,[rip+0x13c83]        # 0x14001a710
   140006a8d:	mov    r8d,r12d
   140006a90:	mov    rdx,rax
   140006a93:	lea    rcx,[rbp+0x40]
   140006a97:	call   0x1400106b0
   140006a9c:	nop
   140006a9d:	mov    DWORD PTR [rsp+0x28],r13d
   140006aa2:	mov    DWORD PTR [rsp+0x20],0x2dd
   140006aaa:	mov    r9,rdi
   140006aad:	lea    r8,[rip+0x1341c]        # 0x140019ed0
   140006ab4:	mov    rdx,rbx
   140006ab7:	lea    rcx,[rbp-0x68]
   140006abb:	call   0x14000f3ac
   140006ac0:	mov    rdx,rax
   140006ac3:	lea    rcx,[rbp+0x40]
   140006ac7:	call   0x1400038ec
   140006acc:	mov    DWORD PTR [rsp+0x20],eax
   140006ad0:	lea    r9,[rip+0x11e89]        # 0x140018960
   140006ad7:	mov    r8d,eax
   140006ada:	lea    rcx,[rbp+0x40]
   140006ade:	call   0x1400106b0
   140006ae3:	nop
   140006ae4:	mov    DWORD PTR [rsp+0x28],r13d
   140006ae9:	mov    DWORD PTR [rsp+0x20],0x2e8
   140006af1:	mov    r9,rdi
   140006af4:	lea    r8,[rip+0x133d5]        # 0x140019ed0
   140006afb:	mov    rdx,rbx
   140006afe:	lea    rcx,[rbp-0x68]
   140006b02:	call   0x14000f3ac
   140006b07:	mov    rdx,rax
   140006b0a:	lea    rcx,[rbp+0x40]
   140006b0e:	call   0x1400038ec
   140006b13:	mov    DWORD PTR [rsp+0x20],eax
   140006b17:	lea    r9,[rip+0x13d02]        # 0x14001a820
   140006b1e:	mov    r8d,eax
   140006b21:	lea    rcx,[rbp+0x40]
   140006b25:	call   0x1400106b0
   140006b2a:	int3
   140006b2b:	mov    DWORD PTR [rsp+0x28],r13d
   140006b30:	mov    DWORD PTR [rsp+0x20],0x2ec
   140006b38:	mov    r9,rdi
   140006b3b:	lea    r8,[rip+0x1338e]        # 0x140019ed0
   140006b42:	mov    rdx,rbx
   140006b45:	lea    rcx,[rbp-0x68]
   140006b49:	call   0x14000f3ac
   140006b4e:	lea    r9,[rip+0x13bbb]        # 0x14001a710
   140006b55:	mov    r8d,r12d
   140006b58:	mov    rdx,rax
   140006b5b:	lea    rcx,[rbp+0x40]
   140006b5f:	call   0x1400106b0
   140006b64:	nop
   140006b65:	mov    DWORD PTR [rsp+0x28],r13d
   140006b6a:	mov    DWORD PTR [rsp+0x20],0x30c
   140006b72:	lea    r9,[rip+0x13af7]        # 0x14001a670
   140006b79:	lea    r8,[rip+0x13350]        # 0x140019ed0
   140006b80:	lea    rdx,[rip+0x13369]        # 0x140019ef0
   140006b87:	lea    rcx,[rbp-0x68]
   140006b8b:	call   0x14000f3ac
   140006b90:	mov    rdx,rax
   140006b93:	lea    rcx,[rbp+0x40]
   140006b97:	call   0x1400038ec
   140006b9c:	mov    DWORD PTR [rsp+0x20],eax
   140006ba0:	lea    r9,[rip+0x13b09]        # 0x14001a6b0
   140006ba7:	mov    r8d,eax
   140006baa:	lea    rcx,[rbp+0x40]
   140006bae:	call   0x1400106b0
   140006bb3:	int3
   140006bb4:	int3
   140006bb5:	int3
   140006bb6:	int3
   140006bb7:	int3
   140006bb8:	int3
   140006bb9:	int3
   140006bba:	int3
   140006bbb:	int3
   140006bbc:	mov    rax,rsp
   140006bbf:	push   rbp
   140006bc0:	push   r12
   140006bc2:	push   r13
   140006bc4:	push   r14
   140006bc6:	push   r15
   140006bc8:	lea    rbp,[rax-0x298]
   140006bcf:	sub    rsp,0x370
   140006bd6:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   140006be1:	mov    QWORD PTR [rax+0x10],rbx
   140006be5:	mov    QWORD PTR [rax+0x18],rsi
   140006be9:	mov    QWORD PTR [rax+0x20],rdi
   140006bed:	mov    rax,QWORD PTR [rip+0x1d524]        # 0x140024118
   140006bf4:	xor    rax,rsp
   140006bf7:	mov    QWORD PTR [rbp+0x260],rax
   140006bfe:	mov    rsi,rcx
   140006c01:	lea    rbx,[rip+0x132e8]        # 0x140019ef0
   140006c08:	mov    QWORD PTR [rbp-0x10],rbx
   140006c0c:	lea    r15,[rip+0x13c7d]        # 0x14001a890
   140006c13:	mov    QWORD PTR [rbp-0x8],r15
   140006c17:	lea    rax,[rip+0x132b2]        # 0x140019ed0
   140006c1e:	mov    QWORD PTR [rbp+0x0],rax
   140006c22:	mov    DWORD PTR [rbp+0x8],0x324
   140006c29:	mov    DWORD PTR [rbp+0xc],0x7
   140006c30:	mov    DWORD PTR [rbp+0x10],0xff
   140006c37:	xor    r13d,r13d
   140006c3a:	mov    DWORD PTR [rbp+0x90],0x1000000
   140006c44:	xor    edx,edx
   140006c46:	lea    r8d,[r13+0x78]
   140006c4a:	lea    rcx,[rbp+0x18]
   140006c4e:	call   0x140015692
   140006c53:	lea    rdx,[rbp-0x10]
   140006c57:	lea    rcx,[rbp+0x150]
   140006c5e:	call   0x14000f85c
   140006c63:	nop
   140006c64:	test   DWORD PTR [rip+0x1da9e],0xfffffff8        # 0x14002470c
   140006c6e:	je     0x140006c89
   140006c70:	lea    edx,[r13+0xd]
   140006c74:	mov    rcx,rsi
   140006c77:	call   0x1400038f8
   140006c7c:	mov    rdx,rax
   140006c7f:	call   0x14000b248
   140006c84:	mov    r14d,eax
   140006c87:	jmp    0x140006c8d
   140006c89:	or     r14d,0xffffffff
   140006c8d:	movups xmm0,XMMWORD PTR [rip+0x1171c]        # 0x1400183b0
   140006c94:	movdqu XMMWORD PTR [rbp+0x1c0],xmm0
   140006c9c:	lea    rdx,[rbp+0x1c0]
   140006ca3:	mov    rcx,rsi
   140006ca6:	call   0x140001264
   140006cab:	mov    edx,0x3
   140006cb0:	mov    rcx,rsi
   140006cb3:	call   0x1400038f8
   140006cb8:	mov    rdi,rax
   140006cbb:	mov    r12b,r13b
   140006cbe:	mov    BYTE PTR [rsp+0x60],r13b
   140006cc3:	movups xmm0,XMMWORD PTR [rip+0x116e6]        # 0x1400183b0
   140006cca:	movdqu XMMWORD PTR [rbp+0x1e0],xmm0
   140006cd2:	mov    edx,0xa
   140006cd7:	mov    rcx,rsi
   140006cda:	call   0x1400038f8
   140006cdf:	test   rax,rax
   140006ce2:	je     0x140006d08
   140006ce4:	mov    edx,0xa
   140006ce9:	mov    rcx,rsi
   140006cec:	call   0x1400038f8
   140006cf1:	mov    rdx,rax
   140006cf4:	lea    r8,[rbp+0x1e0]
   140006cfb:	call   0x14000c630
   140006d00:	test   al,al
   140006d02:	je     0x1400072cf
   140006d08:	movups xmm0,XMMWORD PTR [rip+0x116a1]        # 0x1400183b0
   140006d0f:	movdqu XMMWORD PTR [rbp+0x1d0],xmm0
   140006d17:	mov    edx,0xc
   140006d1c:	mov    rcx,rsi
   140006d1f:	call   0x1400038f8
   140006d24:	test   rax,rax
   140006d27:	je     0x140006d4d
   140006d29:	mov    edx,0xc
   140006d2e:	mov    rcx,rsi
   140006d31:	call   0x1400038f8
   140006d36:	mov    rdx,rax
   140006d39:	lea    r8,[rbp+0x1d0]
   140006d40:	call   0x14000c630
   140006d45:	test   al,al
   140006d47:	je     0x14000732a
   140006d4d:	movaps xmm0,XMMWORD PTR [rbp+0x1e0]
   140006d54:	movdqa XMMWORD PTR [rbp-0x70],xmm0
   140006d59:	movaps xmm1,XMMWORD PTR [rbp+0x1d0]
   140006d60:	movdqa XMMWORD PTR [rbp-0x80],xmm1
   140006d65:	movaps xmm0,XMMWORD PTR [rbp+0x1c0]
   140006d6c:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   140006d72:	mov    rcx,QWORD PTR [rsi]
   140006d75:	mov    rax,QWORD PTR [rcx]
   140006d78:	lea    rdx,[rbp+0x150]
   140006d7f:	mov    QWORD PTR [rsp+0x30],rdx
   140006d84:	lea    rdx,[rbp-0x70]
   140006d88:	mov    QWORD PTR [rsp+0x28],rdx
   140006d8d:	lea    rdx,[rbp-0x80]
   140006d91:	mov    QWORD PTR [rsp+0x20],rdx
   140006d96:	mov    r9,rdi
   140006d99:	lea    r8,[rsp+0x70]
   140006d9e:	mov    edx,r14d
   140006da1:	mov    rax,QWORD PTR [rax+0x18]
   140006da5:	call   QWORD PTR [rip+0x114ed]        # 0x140018298
   140006dab:	xor    edx,edx
   140006dad:	lea    r8d,[rdx+0x64]
   140006db1:	lea    rcx,[rbp+0x1f0]
   140006db8:	call   0x140015692
   140006dbd:	test   rdi,rdi
   140006dc0:	je     0x140006df0
   140006dc2:	cmp    WORD PTR [rdi],0x5c
   140006dc6:	je     0x1400071fb
   140006dcc:	mov    r8d,0x32
   140006dd2:	lea    rdx,[rbp+0x1f0]
   140006dd9:	mov    rcx,rdi
   140006ddc:	rex.W call QWORD PTR [rip+0x11105]        # 0x140017ee8
   140006de3:	nop    DWORD PTR [rax+rax*1+0x0]
   140006de8:	test   eax,eax
   140006dea:	je     0x140007385
   140006df0:	lea    rdi,[rip+0x130d9]        # 0x140019ed0
   140006df7:	xorps  xmm0,xmm0
   140006dfa:	movdqu XMMWORD PTR [rbp-0x48],xmm0
   140006dff:	mov    DWORD PTR [rbp-0x38],r13d
   140006e03:	movaps xmm0,XMMWORD PTR [rbp+0x1c0]
   140006e0a:	movdqa XMMWORD PTR [rbp-0x70],xmm0
   140006e0f:	movaps xmm1,XMMWORD PTR [rbp+0x1d0]
   140006e16:	movdqa XMMWORD PTR [rbp-0x80],xmm1
   140006e1b:	movaps xmm0,XMMWORD PTR [rbp+0x1e0]
   140006e22:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   140006e28:	lea    rax,[rbp+0x1f0]
   140006e2f:	mov    QWORD PTR [rsp+0x28],rax
   140006e34:	lea    rax,[rbp-0x70]
   140006e38:	mov    QWORD PTR [rsp+0x20],rax
   140006e3d:	lea    r9,[rbp-0x80]
   140006e41:	lea    r8,[rsp+0x70]
   140006e46:	mov    edx,r14d
   140006e49:	lea    rcx,[rbp-0x48]
   140006e4d:	call   0x140004728
   140006e52:	mov    r14d,DWORD PTR [rbp-0x38]
   140006e56:	test   r14d,r14d
   140006e59:	je     0x14000728d
   140006e5f:	mov    r15,QWORD PTR [rbp-0x40]
   140006e63:	test   r14d,r14d
   140006e66:	jle    0x1400070ec
   140006e6c:	mov    rbx,r15
   140006e6f:	mov    QWORD PTR [rbp-0x60],rbx
   140006e73:	mov    edi,r14d
   140006e76:	mov    QWORD PTR [rsp+0x68],r14
   140006e7b:	lea    r12,[rip+0x101de]        # 0x140017060
   140006e82:	lea    r14,[rip+0x101df]        # 0x140017068
   140006e89:	mov    r15,QWORD PTR [rbx]
   140006e8c:	movups xmm0,XMMWORD PTR [r15]
   140006e90:	movdqu XMMWORD PTR [rbp-0x20],xmm0
   140006e95:	lea    rcx,[rbp-0x20]
   140006e99:	call   0x14000e3fc
   140006e9e:	mov    r13,rax
   140006ea1:	mov    QWORD PTR [rbp-0x68],rax
   140006ea5:	mov    QWORD PTR [rbp-0x70],r12
   140006ea9:	mov    rcx,QWORD PTR [r15+0x20]
   140006ead:	mov    rcx,QWORD PTR [rcx]
   140006eb0:	add    rcx,0x70
   140006eb4:	call   0x14000e598
   140006eb9:	mov    r12,rax
   140006ebc:	mov    QWORD PTR [rbp-0x78],rax
   140006ec0:	lea    rax,[rip+0x10199]        # 0x140017060
   140006ec7:	mov    QWORD PTR [rbp-0x80],rax
   140006ecb:	mov    QWORD PTR [rsp+0x20],r12
   140006ed0:	mov    r9d,DWORD PTR [r15+0x10]
   140006ed4:	mov    r8,r13
   140006ed7:	mov    edx,0x40002752
   140006edc:	mov    rcx,rsi
   140006edf:	call   0x14000c6f4
   140006ee4:	cmp    DWORD PTR [r15+0x28],0x0
   140006ee9:	jle    0x140007085
   140006eef:	mov    BYTE PTR [rsp+0x60],0x1
   140006ef4:	xor    r14d,r14d
   140006ef7:	mov    r13d,DWORD PTR [r15+0x28]
   140006efb:	lea    r12,[rip+0x10166]        # 0x140017068
   140006f02:	mov    rax,QWORD PTR [r15+0x20]
   140006f06:	mov    rdi,QWORD PTR [r14+rax*1]
   140006f0a:	lea    rdx,[rdi+0x58]
   140006f0e:	mov    rcx,rsi
   140006f11:	call   0x1400013dc
   140006f16:	mov    rbx,rax
   140006f19:	mov    edx,DWORD PTR [rdi+0x68]
   140006f1c:	mov    rcx,rsi
   140006f1f:	call   0x14000affc
   140006f24:	mov    QWORD PTR [rbp-0x50],rax
   140006f28:	lea    rax,[rip+0x10131]        # 0x140017060
   140006f2f:	mov    QWORD PTR [rbp-0x58],rax
   140006f33:	mov    edx,DWORD PTR [rdi+0x68]
   140006f36:	mov    rcx,rsi
   140006f39:	call   0x14000b3d4
   140006f3e:	mov    QWORD PTR [rsp+0x78],rax
   140006f43:	lea    rax,[rip+0x10116]        # 0x140017060
   140006f4a:	mov    QWORD PTR [rsp+0x70],rax
   140006f4f:	movups xmm0,XMMWORD PTR [rdi]
   140006f52:	movdqu XMMWORD PTR [rbp-0x20],xmm0
   140006f57:	lea    rcx,[rbp-0x20]
   140006f5b:	call   0x14000e3fc
   140006f60:	mov    QWORD PTR [rbp-0x28],rax
   140006f64:	lea    rax,[rip+0x100f5]        # 0x140017060
   140006f6b:	mov    QWORD PTR [rbp-0x30],rax
   140006f6f:	mov    rdx,QWORD PTR [rdi+0x30]
   140006f73:	mov    rcx,rsi
   140006f76:	call   0x14000bb2c
   140006f7b:	lea    r8,[rip+0x14d8e]        # 0x14001bd10
   140006f82:	cmp    QWORD PTR [rdi+0x40],0x0
   140006f87:	cmovne r8,QWORD PTR [rdi+0x40]
   140006f8c:	lea    rdx,[rip+0x14d7d]        # 0x14001bd10
   140006f93:	cmp    QWORD PTR [rdi+0x38],0x0
   140006f98:	cmovne rdx,QWORD PTR [rdi+0x38]
   140006f9d:	lea    rcx,[rip+0x13acc]        # 0x14001aa70
   140006fa4:	test   rbx,rbx
   140006fa7:	cmovne rcx,rbx
   140006fab:	lea    r9,[rip+0x13abe]        # 0x14001aa70
   140006fb2:	test   rax,rax
   140006fb5:	cmovne r9,rax
   140006fb9:	mov    rax,QWORD PTR [rbp-0x50]
   140006fbd:	mov    QWORD PTR [rsp+0x50],rax
   140006fc2:	mov    rbx,QWORD PTR [rsp+0x78]
   140006fc7:	mov    QWORD PTR [rsp+0x48],rbx
   140006fcc:	mov    QWORD PTR [rsp+0x40],rcx
   140006fd1:	mov    QWORD PTR [rsp+0x38],r8
   140006fd6:	mov    QWORD PTR [rsp+0x30],rdx
   140006fdb:	mov    rax,QWORD PTR [rdi+0x28]
   140006fdf:	mov    QWORD PTR [rsp+0x28],rax
   140006fe4:	mov    rax,QWORD PTR [rdi+0x30]
   140006fe8:	mov    QWORD PTR [rsp+0x20],rax
   140006fed:	mov    rdi,QWORD PTR [rbp-0x28]
   140006ff1:	mov    r8,rdi
   140006ff4:	mov    edx,0x40002753
   140006ff9:	mov    rcx,rsi
   140006ffc:	call   0x14000c6f4
   140007001:	nop
   140007002:	test   rdi,rdi
   140007005:	je     0x140007016
   140007007:	mov    rcx,rdi
   14000700a:	rex.W call QWORD PTR [rip+0x1106f]        # 0x140018080
   140007011:	nop    DWORD PTR [rax+rax*1+0x0]
   140007016:	and    QWORD PTR [rbp-0x28],0x0
   14000701b:	mov    QWORD PTR [rbp-0x30],r12
   14000701f:	test   rbx,rbx
   140007022:	je     0x140007033
   140007024:	mov    rcx,rbx
   140007027:	rex.W call QWORD PTR [rip+0x11052]        # 0x140018080
   14000702e:	nop    DWORD PTR [rax+rax*1+0x0]
   140007033:	and    QWORD PTR [rsp+0x78],0x0
   140007039:	mov    QWORD PTR [rsp+0x70],r12
   14000703e:	mov    rax,QWORD PTR [rbp-0x50]
   140007042:	test   rax,rax
   140007045:	je     0x140007056
   140007047:	mov    rcx,rax
   14000704a:	rex.W call QWORD PTR [rip+0x1102f]        # 0x140018080
   140007051:	nop    DWORD PTR [rax+rax*1+0x0]
   140007056:	and    QWORD PTR [rbp-0x50],0x0
   14000705b:	mov    QWORD PTR [rbp-0x58],r12
   14000705f:	add    r14,0x8
   140007063:	sub    r13,0x1
   140007067:	jne    0x140006f02
   14000706d:	mov    r12,QWORD PTR [rbp-0x78]
   140007071:	mov    r13,QWORD PTR [rbp-0x68]
   140007075:	mov    rbx,QWORD PTR [rbp-0x60]
   140007079:	mov    rdi,QWORD PTR [rsp+0x68]
   14000707e:	lea    r14,[rip+0xffe3]        # 0x140017068
   140007085:	test   r12,r12
   140007088:	je     0x140007099
   14000708a:	mov    rcx,r12
   14000708d:	rex.W call QWORD PTR [rip+0x10fec]        # 0x140018080
   140007094:	nop    DWORD PTR [rax+rax*1+0x0]
   140007099:	and    QWORD PTR [rbp-0x78],0x0
   14000709e:	mov    QWORD PTR [rbp-0x80],r14
   1400070a2:	test   r13,r13
   1400070a5:	je     0x1400070b6
   1400070a7:	mov    rcx,r13
   1400070aa:	rex.W call QWORD PTR [rip+0x10fcf]        # 0x140018080
   1400070b1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400070b6:	xor    r13d,r13d
   1400070b9:	mov    QWORD PTR [rbp-0x68],r13
   1400070bd:	mov    QWORD PTR [rbp-0x70],r14
   1400070c1:	add    rbx,0x8
   1400070c5:	mov    QWORD PTR [rbp-0x60],rbx
   1400070c9:	sub    rdi,0x1
   1400070cd:	mov    QWORD PTR [rsp+0x68],rdi
   1400070d2:	lea    r12,[rip+0xff87]        # 0x140017060
   1400070d9:	jne    0x140006e89
   1400070df:	mov    r14d,DWORD PTR [rbp-0x38]
   1400070e3:	mov    r15,QWORD PTR [rbp-0x40]
   1400070e7:	mov    r12b,BYTE PTR [rsp+0x60]
   1400070ec:	mov    eax,r13d
   1400070ef:	test   r12b,r12b
   1400070f2:	sete   al
   1400070f5:	mov    DWORD PTR [rsi+0x48],eax
   1400070f8:	lea    rax,[rip+0x12df1]        # 0x140019ef0
   1400070ff:	mov    QWORD PTR [rbp+0xa8],rax
   140007106:	lea    rax,[rip+0x12f13]        # 0x14001a020
   14000710d:	mov    QWORD PTR [rbp+0xb0],rax
   140007114:	lea    rax,[rip+0x12db5]        # 0x140019ed0
   14000711b:	mov    QWORD PTR [rbp+0xb8],rax
   140007122:	mov    eax,0xff
   140007127:	mov    DWORD PTR [rbp+0xc0],eax
   14000712d:	mov    DWORD PTR [rbp+0xc4],0x7
   140007137:	mov    DWORD PTR [rbp+0xc8],eax
   14000713d:	mov    DWORD PTR [rbp+0x148],0x1000000
   140007147:	xor    edx,edx
   140007149:	lea    r8d,[rdx+0x78]
   14000714d:	lea    rcx,[rbp+0xd0]
   140007154:	call   0x140015692
   140007159:	lea    rdx,[rbp+0xa8]
   140007160:	lea    rcx,[rbp-0x10]
   140007164:	call   0x14000f85c
   140007169:	test   r14d,r14d
   14000716c:	jle    0x14000718b
   14000716e:	mov    rbx,r15
   140007171:	mov    edi,r14d
   140007174:	mov    rcx,QWORD PTR [rbx]
   140007177:	test   rcx,rcx
   14000717a:	je     0x140007181
   14000717c:	call   0x140004fa4
   140007181:	add    rbx,0x8
   140007185:	sub    rdi,0x1
   140007189:	jne    0x140007174
   14000718b:	lea    rcx,[rbp-0x10]
   14000718f:	call   0x14000f958
   140007194:	mov    rcx,QWORD PTR [rbp-0x48]
   140007198:	test   rcx,rcx
   14000719b:	je     0x1400071a9
   14000719d:	rex.W call QWORD PTR [rip+0x110a4]        # 0x140018248
   1400071a4:	nop    DWORD PTR [rax+rax*1+0x0]
   1400071a9:	test   r15,r15
   1400071ac:	je     0x1400071be
   1400071ae:	mov    rcx,r15
   1400071b1:	rex.W call QWORD PTR [rip+0x11090]        # 0x140018248
   1400071b8:	nop    DWORD PTR [rax+rax*1+0x0]
   1400071bd:	nop
   1400071be:	lea    rcx,[rbp+0x150]
   1400071c5:	call   0x14000f958
   1400071ca:	mov    rcx,QWORD PTR [rbp+0x260]
   1400071d1:	xor    rcx,rsp
   1400071d4:	call   0x1400143c0
   1400071d9:	lea    r11,[rsp+0x370]
   1400071e1:	mov    rbx,QWORD PTR [r11+0x38]
   1400071e5:	mov    rsi,QWORD PTR [r11+0x40]
   1400071e9:	mov    rdi,QWORD PTR [r11+0x48]
   1400071ed:	mov    rsp,r11
   1400071f0:	pop    r15
   1400071f2:	pop    r14
   1400071f4:	pop    r13
   1400071f6:	pop    r12
   1400071f8:	pop    rbp
   1400071f9:	ret
   1400071fa:	int3
   1400071fb:	mov    r8,rdi
   1400071fe:	mov    edx,0x32
   140007203:	lea    rcx,[rbp+0x1f0]
   14000720a:	call   0x1400035fc
   14000720f:	mov    ebx,eax
   140007211:	mov    DWORD PTR [rbp+0x158],eax
   140007217:	lea    rax,[rip+0x12cd2]        # 0x140019ef0
   14000721e:	mov    QWORD PTR [rbp-0x10],rax
   140007222:	mov    QWORD PTR [rbp-0x8],r15
   140007226:	lea    rdi,[rip+0x12ca3]        # 0x140019ed0
   14000722d:	mov    QWORD PTR [rbp+0x0],rdi
   140007231:	mov    DWORD PTR [rbp+0x8],0x35b
   140007238:	mov    DWORD PTR [rbp+0xc],0x7
   14000723f:	mov    DWORD PTR [rbp+0x10],0xff
   140007246:	mov    DWORD PTR [rbp+0x90],0x1000000
   140007250:	xor    edx,edx
   140007252:	lea    r8d,[rdx+0x78]
   140007256:	lea    rcx,[rbp+0x18]
   14000725a:	call   0x140015692
   14000725f:	lea    rax,[rbp-0x10]
   140007263:	mov    QWORD PTR [rsp+0x68],rax
   140007268:	test   ebx,ebx
   14000726a:	js     0x1400073e3
   140007270:	lea    rcx,[rbp-0x10]
   140007274:	call   0x14000f484
   140007279:	mov    WORD PTR [rbp+0x252],r13w
   140007281:	lea    rbx,[rip+0x12c68]        # 0x140019ef0
   140007288:	jmp    0x140006df7
   14000728d:	mov    DWORD PTR [rsp+0x28],0x7
   140007295:	mov    DWORD PTR [rsp+0x20],0x36d
   14000729d:	mov    r9,r15
   1400072a0:	mov    r8,rdi
   1400072a3:	mov    rdx,rbx
   1400072a6:	lea    rcx,[rbp+0xa8]
   1400072ad:	call   0x14000f3ac
   1400072b2:	lea    r9,[rip+0x13727]        # 0x14001a9e0
   1400072b9:	mov    r8d,0x1
   1400072bf:	mov    rdx,rax
   1400072c2:	lea    rcx,[rbp+0x150]
   1400072c9:	call   0x1400106b0
   1400072ce:	nop
   1400072cf:	mov    DWORD PTR [rsp+0x28],0x7
   1400072d7:	mov    DWORD PTR [rsp+0x20],0x337
   1400072df:	mov    r9,r15
   1400072e2:	lea    r8,[rip+0x12be7]        # 0x140019ed0
   1400072e9:	mov    rdx,rbx
   1400072ec:	lea    rcx,[rbp+0xa8]
   1400072f3:	call   0x14000f3ac
   1400072f8:	mov    rbx,rax
   1400072fb:	mov    edx,0xa
   140007300:	mov    rcx,rsi
   140007303:	call   0x1400038f8
   140007308:	mov    QWORD PTR [rsp+0x20],rax
   14000730d:	lea    r9,[rip+0x135bc]        # 0x14001a8d0
   140007314:	mov    r8d,0x1004
   14000731a:	mov    rdx,rbx
   14000731d:	lea    rcx,[rbp+0x150]
   140007324:	call   0x1400106b0
   140007329:	int3
   14000732a:	mov    DWORD PTR [rsp+0x28],0x7
   140007332:	mov    DWORD PTR [rsp+0x20],0x341
   14000733a:	mov    r9,r15
   14000733d:	lea    r8,[rip+0x12b8c]        # 0x140019ed0
   140007344:	mov    rdx,rbx
   140007347:	lea    rcx,[rbp+0xa8]
   14000734e:	call   0x14000f3ac
   140007353:	mov    rbx,rax
   140007356:	mov    edx,0xc
   14000735b:	mov    rcx,rsi
   14000735e:	call   0x1400038f8
   140007363:	mov    QWORD PTR [rsp+0x20],rax
   140007368:	lea    r9,[rip+0x135e1]        # 0x14001a950
   14000736f:	mov    r8d,0x1004
   140007375:	mov    rdx,rbx
   140007378:	lea    rcx,[rbp+0x150]
   14000737f:	call   0x1400106b0
   140007384:	int3
   140007385:	mov    DWORD PTR [rsp+0x28],0x1
   14000738d:	mov    DWORD PTR [rsp+0x20],0x354
   140007395:	mov    r9,r15
   140007398:	lea    r8,[rip+0x12b31]        # 0x140019ed0
   14000739f:	mov    rdx,rbx
   1400073a2:	lea    rcx,[rbp+0xa8]
   1400073a9:	call   0x14000f3ac
   1400073ae:	mov    rbx,rax
   1400073b1:	rex.W call QWORD PTR [rip+0x10bc0]        # 0x140017f78
   1400073b8:	nop    DWORD PTR [rax+rax*1+0x0]
   1400073bd:	mov    DWORD PTR [rsp+0x28],eax
   1400073c1:	mov    QWORD PTR [rsp+0x20],rdi
   1400073c6:	lea    r9,[rip+0x148b3]        # 0x14001bc80
   1400073cd:	mov    r8d,0x80042308
   1400073d3:	mov    rdx,rbx
   1400073d6:	lea    rcx,[rbp+0x150]
   1400073dd:	call   0x1400106b0
   1400073e2:	nop
   1400073e3:	lea    rdx,[rbp-0x10]
   1400073e7:	lea    rcx,[rbp+0xa8]
   1400073ee:	call   0x14000f400
   1400073f3:	lea    r9,[rip+0x135c6]        # 0x14001a9c0
   1400073fa:	mov    r8d,ebx
   1400073fd:	mov    rdx,rax
   140007400:	lea    rcx,[rbp+0x150]
   140007407:	call   0x140010848
   14000740c:	int3
   14000740d:	int3
   14000740e:	int3
   14000740f:	int3
   140007410:	int3
   140007411:	int3
   140007412:	int3
   140007413:	int3
   140007414:	mov    rax,rsp
   140007417:	push   rbp
   140007418:	push   rdi
   140007419:	push   r14
   14000741b:	lea    rbp,[rax-0x58]
   14000741f:	sub    rsp,0x140
   140007426:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   14000742f:	mov    QWORD PTR [rax+0x8],rbx
   140007433:	mov    QWORD PTR [rax+0x18],rsi
   140007437:	mov    rdi,rcx
   14000743a:	lea    rax,[rip+0x12aaf]        # 0x140019ef0
   140007441:	mov    QWORD PTR [rsp+0x28],rax
   140007446:	lea    rax,[rip+0x13633]        # 0x14001aa80
   14000744d:	mov    QWORD PTR [rsp+0x30],rax
   140007452:	lea    rax,[rip+0x12a77]        # 0x140019ed0
   140007459:	mov    QWORD PTR [rsp+0x38],rax
   14000745e:	mov    DWORD PTR [rsp+0x40],0x3ab
   140007466:	mov    DWORD PTR [rsp+0x44],0x7
   14000746e:	mov    DWORD PTR [rsp+0x48],0xff
   140007476:	xor    r14d,r14d
   140007479:	mov    DWORD PTR [rbp-0x38],0x1000000
   140007480:	xor    edx,edx
   140007482:	lea    r8d,[r14+0x78]
   140007486:	lea    rcx,[rsp+0x50]
   14000748b:	call   0x140015692
   140007490:	lea    rdx,[rsp+0x28]
   140007495:	lea    rcx,[rbp-0x30]
   140007499:	call   0x14000f85c
   14000749e:	nop
   14000749f:	cmp    QWORD PTR [rip+0xfd4a],r14        # 0x1400171f0
   1400074a6:	je     0x1400074e7
   1400074a8:	mov    ebx,r14d
   1400074ab:	lea    rsi,[rip+0xfd3e]        # 0x1400171f0
   1400074b2:	mov    rdx,rsi
   1400074b5:	mov    ecx,r14d
   1400074b8:	mov    eax,DWORD PTR [rcx+rsi*1+0x8]
   1400074bc:	test   DWORD PTR [rip+0x1d24a],eax        # 0x14002470c
   1400074c2:	je     0x1400074d3
   1400074c4:	mov    r8,QWORD PTR [rdx]
   1400074c7:	mov    edx,DWORD PTR [rcx+rsi*1+0x10]
   1400074cb:	mov    rcx,rdi
   1400074ce:	call   0x14000c6f4
   1400074d3:	inc    rbx
   1400074d6:	lea    rcx,[rbx+rbx*2]
   1400074da:	shl    rcx,0x3
   1400074de:	lea    rdx,[rcx+rsi*1]
   1400074e2:	cmp    QWORD PTR [rdx],r14
   1400074e5:	jne    0x1400074b8
   1400074e7:	lea    rcx,[rbp-0x30]
   1400074eb:	call   0x14000f958
   1400074f0:	lea    r11,[rsp+0x140]
   1400074f8:	mov    rbx,QWORD PTR [r11+0x20]
   1400074fc:	mov    rsi,QWORD PTR [r11+0x30]
   140007500:	mov    rsp,r11
   140007503:	pop    r14
   140007505:	pop    rdi
   140007506:	pop    rbp
   140007507:	ret
   140007508:	int3
   140007509:	int3
   14000750a:	int3
   14000750b:	int3
   14000750c:	int3
   14000750d:	int3
   14000750e:	int3
   14000750f:	int3
   140007510:	mov    rax,rsp
   140007513:	push   rbp
   140007514:	push   r12
   140007516:	push   r13
   140007518:	push   r14
   14000751a:	push   r15
   14000751c:	lea    rbp,[rax-0x118]
   140007523:	sub    rsp,0x1f0
   14000752a:	mov    QWORD PTR [rbp+0xb8],0xfffffffffffffffe
   140007535:	mov    QWORD PTR [rax+0x10],rbx
   140007539:	mov    QWORD PTR [rax+0x18],rsi
   14000753d:	mov    QWORD PTR [rax+0x20],rdi
   140007541:	mov    rax,QWORD PTR [rip+0x1cbd0]        # 0x140024118
   140007548:	xor    rax,rsp
   14000754b:	mov    QWORD PTR [rbp+0xe0],rax
   140007552:	mov    rbx,rcx
   140007555:	lea    r15,[rip+0x12994]        # 0x140019ef0
   14000755c:	mov    QWORD PTR [rbp-0x10],r15
   140007560:	lea    r13,[rip+0x13559]        # 0x14001aac0
   140007567:	mov    QWORD PTR [rbp-0x8],r13
   14000756b:	lea    rsi,[rip+0x1295e]        # 0x140019ed0
   140007572:	mov    QWORD PTR [rbp+0x0],rsi
   140007576:	mov    DWORD PTR [rbp+0x8],0x3c0
   14000757d:	mov    edi,0x7
   140007582:	mov    DWORD PTR [rbp+0xc],edi
   140007585:	mov    DWORD PTR [rbp+0x10],0xff
   14000758c:	xor    r12d,r12d
   14000758f:	mov    DWORD PTR [rbp+0x90],0x1000000
   140007599:	xor    edx,edx
   14000759b:	lea    r14d,[rdi-0x6]
   14000759f:	lea    r8d,[rdi+0x71]
   1400075a3:	lea    rcx,[rbp+0x18]
   1400075a7:	call   0x140015692
   1400075ac:	lea    rdx,[rbp-0x10]
   1400075b0:	lea    rcx,[rbp-0x80]
   1400075b4:	call   0x14000f85c
   1400075b9:	nop
   1400075ba:	mov    QWORD PTR [rsp+0x50],r12
   1400075bf:	mov    QWORD PTR [rsp+0x58],r12
   1400075c4:	lea    rcx,[rsp+0x50]
   1400075c9:	rex.W call QWORD PTR [rip+0x109f0]        # 0x140017fc0
   1400075d0:	nop    DWORD PTR [rax+rax*1+0x0]
   1400075d5:	mov    DWORD PTR [rbp-0x78],eax
   1400075d8:	test   eax,eax
   1400075da:	js     0x140007b6b
   1400075e0:	mov    rcx,QWORD PTR [rsp+0x50]
   1400075e5:	mov    rax,QWORD PTR [rcx]
   1400075e8:	xor    edx,edx
   1400075ea:	mov    rax,QWORD PTR [rax+0x28]
   1400075ee:	call   QWORD PTR [rip+0x10ca4]        # 0x140018298
   1400075f4:	mov    DWORD PTR [rbp-0x78],eax
   1400075f7:	test   eax,eax
   1400075f9:	js     0x140007bad
   1400075ff:	mov    rcx,QWORD PTR [rsp+0x50]
   140007604:	mov    rax,QWORD PTR [rcx]
   140007607:	lea    rdx,[rsp+0x58]
   14000760c:	mov    rax,QWORD PTR [rax+0x48]
   140007610:	call   QWORD PTR [rip+0x10c82]        # 0x140018298
   140007616:	mov    DWORD PTR [rbp-0x78],eax
   140007619:	test   eax,eax
   14000761b:	js     0x140007bef
   140007621:	mov    DWORD PTR [rsp+0x60],r12d
   140007626:	mov    edi,r12d
   140007629:	mov    ecx,0x9c4
   14000762e:	rex.W call QWORD PTR [rip+0x108fb]        # 0x140017f30
   140007635:	nop    DWORD PTR [rax+rax*1+0x0]
   14000763a:	mov    DWORD PTR [rsp+0x48],r12d
   14000763f:	mov    rcx,QWORD PTR [rsp+0x58]
   140007644:	mov    rax,QWORD PTR [rcx]
   140007647:	lea    r8,[rsp+0x48]
   14000764c:	lea    rdx,[rsp+0x60]
   140007651:	mov    rax,QWORD PTR [rax+0x28]
   140007655:	call   QWORD PTR [rip+0x10c3d]        # 0x140018298
   14000765b:	mov    DWORD PTR [rbp-0x78],eax
   14000765e:	test   eax,eax
   140007660:	js     0x140007b21
   140007666:	mov    esi,DWORD PTR [rsp+0x60]
   14000766a:	cmp    esi,0x4230a
   140007670:	je     0x1400076b3
   140007672:	cmp    esi,0x42309
   140007678:	jne    0x140007c7b
   14000767e:	add    edi,r14d
   140007681:	cmp    edi,0x4
   140007684:	jl     0x140007629
   140007686:	mov    edx,0x4000275a
   14000768b:	mov    rcx,rbx
   14000768e:	call   0x14000c6f4
   140007693:	mov    rcx,QWORD PTR [rsp+0x58]
   140007698:	mov    rax,QWORD PTR [rcx]
   14000769b:	or     edx,0xffffffff
   14000769e:	mov    rax,QWORD PTR [rax+0x20]
   1400076a2:	call   QWORD PTR [rip+0x10bf0]        # 0x140018298
   1400076a8:	mov    DWORD PTR [rbp-0x78],eax
   1400076ab:	test   eax,eax
   1400076ad:	js     0x140007c31
   1400076b3:	xor    edx,edx
   1400076b5:	lea    rcx,[rsp+0x58]
   1400076ba:	rex.W call QWORD PTR [rip+0x10757]        # 0x140017e18
   1400076c1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400076c6:	mov    rcx,QWORD PTR [rsp+0x50]
   1400076cb:	mov    rax,QWORD PTR [rcx]
   1400076ce:	mov    rax,QWORD PTR [rax+0x60]
   1400076d2:	call   QWORD PTR [rip+0x10bc0]        # 0x140018298
   1400076d8:	mov    DWORD PTR [rbp-0x78],eax
   1400076db:	test   eax,eax
   1400076dd:	js     0x140007cc5
   1400076e3:	mov    rcx,QWORD PTR [rsp+0x50]
   1400076e8:	mov    rax,QWORD PTR [rcx]
   1400076eb:	lea    rdx,[rsp+0x58]
   1400076f0:	mov    rax,QWORD PTR [rax+0x80]
   1400076f7:	call   QWORD PTR [rip+0x10b9b]        # 0x140018298
   1400076fd:	mov    DWORD PTR [rbp-0x78],eax
   140007700:	test   eax,eax
   140007702:	js     0x140007d0f
   140007708:	mov    rcx,QWORD PTR [rsp+0x58]
   14000770d:	mov    rax,QWORD PTR [rcx]
   140007710:	or     edx,0xffffffff
   140007713:	mov    rax,QWORD PTR [rax+0x20]
   140007717:	call   QWORD PTR [rip+0x10b7b]        # 0x140018298
   14000771d:	mov    DWORD PTR [rbp-0x78],eax
   140007720:	test   eax,eax
   140007722:	js     0x140007d59
   140007728:	xor    edx,edx
   14000772a:	lea    rcx,[rsp+0x58]
   14000772f:	rex.W call QWORD PTR [rip+0x106e2]        # 0x140017e18
   140007736:	nop    DWORD PTR [rax+rax*1+0x0]
   14000773b:	mov    rcx,QWORD PTR [rsp+0x50]
   140007740:	mov    rax,QWORD PTR [rcx]
   140007743:	lea    rdx,[rsp+0x68]
   140007748:	mov    rax,QWORD PTR [rax+0x88]
   14000774f:	call   QWORD PTR [rip+0x10b43]        # 0x140018298
   140007755:	mov    DWORD PTR [rbp-0x78],eax
   140007758:	test   eax,eax
   14000775a:	js     0x140007da3
   140007760:	mov    r13d,r12d
   140007763:	cmp    DWORD PTR [rsp+0x68],r12d
   140007768:	jbe    0x140007a45
   14000776e:	movups xmm0,XMMWORD PTR [rip+0x10c3b]        # 0x1400183b0
   140007775:	movdqu XMMWORD PTR [rbp+0xd0],xmm0
   14000777d:	movdqu XMMWORD PTR [rbp+0xc0],xmm0
   140007785:	mov    QWORD PTR [rsp+0x40],r12
   14000778a:	mov    rcx,QWORD PTR [rsp+0x50]
   14000778f:	mov    rax,QWORD PTR [rcx]
   140007792:	lea    rdx,[rsp+0x64]
   140007797:	mov    QWORD PTR [rsp+0x30],rdx
   14000779c:	lea    rdx,[rsp+0x48]
   1400077a1:	mov    QWORD PTR [rsp+0x28],rdx
   1400077a6:	lea    rdx,[rsp+0x40]
   1400077ab:	mov    QWORD PTR [rsp+0x20],rdx
   1400077b0:	lea    r9,[rbp+0xc0]
   1400077b7:	lea    r8,[rbp+0xd0]
   1400077be:	mov    edx,r13d
   1400077c1:	mov    rax,QWORD PTR [rax+0x98]
   1400077c8:	call   QWORD PTR [rip+0x10aca]        # 0x140018298
   1400077ce:	mov    DWORD PTR [rbp-0x78],eax
   1400077d1:	test   eax,eax
   1400077d3:	js     0x140007ad3
   1400077d9:	mov    eax,DWORD PTR [rsp+0x48]
   1400077dd:	cmp    eax,r14d
   1400077e0:	je     0x14000782b
   1400077e2:	cmp    eax,0x2
   1400077e5:	je     0x140007824
   1400077e7:	cmp    eax,0x3
   1400077ea:	je     0x14000781d
   1400077ec:	cmp    eax,0x4
   1400077ef:	je     0x140007816
   1400077f1:	cmp    eax,0x5
   1400077f4:	je     0x14000780f
   1400077f6:	add    eax,0xfffffffa
   1400077f9:	mov    rcx,rbx
   1400077fc:	cmp    eax,0x8
   1400077ff:	ja     0x140007808
   140007801:	mov    edx,0x6c
   140007806:	jmp    0x140007833
   140007808:	mov    edx,0x6d
   14000780d:	jmp    0x140007833
   14000780f:	mov    edx,0x70
   140007814:	jmp    0x140007830
   140007816:	mov    edx,0x78
   14000781b:	jmp    0x140007830
   14000781d:	mov    edx,0x6f
   140007822:	jmp    0x140007830
   140007824:	mov    edx,0x6e
   140007829:	jmp    0x140007830
   14000782b:	mov    edx,0x6b
   140007830:	mov    rcx,rbx
   140007833:	call   0x14000c1fc
   140007838:	mov    rsi,rax
   14000783b:	mov    eax,DWORD PTR [rsp+0x64]
   14000783f:	cmp    eax,0x80042319
   140007844:	je     0x14000791e
   14000784a:	cmp    eax,0x800423f0
   14000784f:	je     0x140007917
   140007855:	cmp    eax,0x800423f1
   14000785a:	je     0x140007910
   140007860:	cmp    eax,0x800423f2
   140007865:	je     0x140007909
   14000786b:	cmp    eax,0x800423f3
   140007870:	je     0x140007902
   140007876:	cmp    eax,0x800423f4
   14000787b:	je     0x1400078fb
   14000787d:	mov    rcx,rbx
   140007880:	test   eax,eax
   140007882:	je     0x1400078f4
   140007884:	mov    edx,0x76
   140007889:	call   0x14000c1fc
   14000788e:	mov    rdi,rax
   140007891:	mov    QWORD PTR [rbp-0x10],r15
   140007895:	lea    rax,[rip+0x13224]        # 0x14001aac0
   14000789c:	mov    QWORD PTR [rbp-0x8],rax
   1400078a0:	lea    rax,[rip+0x12629]        # 0x140019ed0
   1400078a7:	mov    QWORD PTR [rbp+0x0],rax
   1400078ab:	mov    DWORD PTR [rbp+0x8],0x45a
   1400078b2:	mov    DWORD PTR [rbp+0xc],0x7
   1400078b9:	mov    DWORD PTR [rbp+0x10],0xff
   1400078c0:	mov    DWORD PTR [rbp+0x90],0x1000000
   1400078ca:	xor    edx,edx
   1400078cc:	lea    r8d,[rdx+0x78]
   1400078d0:	lea    rcx,[rbp+0x18]
   1400078d4:	call   0x140015692
   1400078d9:	mov    r9d,DWORD PTR [rsp+0x64]
   1400078de:	lea    r8,[rip+0x135eb]        # 0x14001aed0
   1400078e5:	lea    rdx,[rbp-0x10]
   1400078e9:	lea    rcx,[rbp-0x80]
   1400078ed:	call   0x140010510
   1400078f2:	jmp    0x14000792e
   1400078f4:	mov    edx,0x77
   1400078f9:	jmp    0x140007926
   1400078fb:	mov    edx,0x75
   140007900:	jmp    0x140007923
   140007902:	mov    edx,0x74
   140007907:	jmp    0x140007923
   140007909:	mov    edx,0x73
   14000790e:	jmp    0x140007923
   140007910:	mov    edx,0x72
   140007915:	jmp    0x140007923
   140007917:	mov    edx,0x71
   14000791c:	jmp    0x140007923
   14000791e:	mov    edx,0x79
   140007923:	mov    rcx,rbx
   140007926:	call   0x14000c1fc
   14000792b:	mov    rdi,rax
   14000792e:	movaps xmm0,XMMWORD PTR [rbp+0xc0]
   140007935:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   14000793b:	lea    rcx,[rsp+0x70]
   140007940:	call   0x14000e3fc
   140007945:	mov    r15,rax
   140007948:	mov    QWORD PTR [rbp+0xb0],rax
   14000794f:	lea    rax,[rip+0xf70a]        # 0x140017060
   140007956:	mov    QWORD PTR [rbp+0xa8],rax
   14000795d:	movaps xmm0,XMMWORD PTR [rbp+0xd0]
   140007964:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   14000796a:	lea    rcx,[rsp+0x70]
   14000796f:	call   0x14000e3fc
   140007974:	mov    r12,rax
   140007977:	mov    QWORD PTR [rbp+0xa0],rax
   14000797e:	lea    rax,[rip+0xf6db]        # 0x140017060
   140007985:	mov    QWORD PTR [rbp+0x98],rax
   14000798c:	lea    r8,[rip+0x1437d]        # 0x14001bd10
   140007993:	mov    rcx,QWORD PTR [rsp+0x40]
   140007998:	test   rcx,rcx
   14000799b:	cmovne r8,rcx
   14000799f:	mov    QWORD PTR [rsp+0x38],rdi
   1400079a4:	mov    QWORD PTR [rsp+0x30],rsi
   1400079a9:	mov    ecx,DWORD PTR [rsp+0x48]
   1400079ad:	mov    DWORD PTR [rsp+0x28],ecx
   1400079b1:	mov    QWORD PTR [rsp+0x20],r12
   1400079b6:	mov    r9,r15
   1400079b9:	mov    edx,0x40002757
   1400079be:	mov    rcx,rbx
   1400079c1:	call   0x14000c6f4
   1400079c6:	nop
   1400079c7:	test   r12,r12
   1400079ca:	je     0x1400079db
   1400079cc:	mov    rcx,r12
   1400079cf:	rex.W call QWORD PTR [rip+0x106aa]        # 0x140018080
   1400079d6:	nop    DWORD PTR [rax+rax*1+0x0]
   1400079db:	xor    r12d,r12d
   1400079de:	mov    QWORD PTR [rbp+0xa0],r12
   1400079e5:	lea    rdi,[rip+0xf67c]        # 0x140017068
   1400079ec:	mov    QWORD PTR [rbp+0x98],rdi
   1400079f3:	test   r15,r15
   1400079f6:	je     0x140007a07
   1400079f8:	mov    rcx,r15
   1400079fb:	rex.W call QWORD PTR [rip+0x1067e]        # 0x140018080
   140007a02:	nop    DWORD PTR [rax+rax*1+0x0]
   140007a07:	mov    QWORD PTR [rbp+0xb0],r12
   140007a0e:	mov    QWORD PTR [rbp+0xa8],rdi
   140007a15:	mov    rcx,QWORD PTR [rsp+0x40]
   140007a1a:	rex.W call QWORD PTR [rip+0x1058f]        # 0x140017fb0
   140007a21:	nop    DWORD PTR [rax+rax*1+0x0]
   140007a26:	add    r13d,r14d
   140007a29:	cmp    r13d,DWORD PTR [rsp+0x68]
   140007a2e:	lea    r15,[rip+0x124bb]        # 0x140019ef0
   140007a35:	jb     0x14000776e
   140007a3b:	mov    r14d,r12d
   140007a3e:	lea    r15,[rip+0x124ab]        # 0x140019ef0
   140007a45:	mov    rcx,QWORD PTR [rsp+0x50]
   140007a4a:	mov    rax,QWORD PTR [rcx]
   140007a4d:	mov    rax,QWORD PTR [rax+0x90]
   140007a54:	call   QWORD PTR [rip+0x1083e]        # 0x140018298
   140007a5a:	mov    DWORD PTR [rbp-0x78],eax
   140007a5d:	test   eax,eax
   140007a5f:	js     0x140007ded
   140007a65:	mov    DWORD PTR [rbx+0x48],r14d
   140007a69:	mov    rcx,QWORD PTR [rsp+0x58]
   140007a6e:	test   rcx,rcx
   140007a71:	je     0x140007a81
   140007a73:	mov    rax,QWORD PTR [rcx]
   140007a76:	mov    rax,QWORD PTR [rax+0x10]
   140007a7a:	call   QWORD PTR [rip+0x10818]        # 0x140018298
   140007a80:	nop
   140007a81:	mov    rcx,QWORD PTR [rsp+0x50]
   140007a86:	test   rcx,rcx
   140007a89:	je     0x140007a99
   140007a8b:	mov    rax,QWORD PTR [rcx]
   140007a8e:	mov    rax,QWORD PTR [rax+0x10]
   140007a92:	call   QWORD PTR [rip+0x10800]        # 0x140018298
   140007a98:	nop
   140007a99:	lea    rcx,[rbp-0x80]
   140007a9d:	call   0x14000f958
   140007aa2:	mov    rcx,QWORD PTR [rbp+0xe0]
   140007aa9:	xor    rcx,rsp
   140007aac:	call   0x1400143c0
   140007ab1:	lea    r11,[rsp+0x1f0]
   140007ab9:	mov    rbx,QWORD PTR [r11+0x38]
   140007abd:	mov    rsi,QWORD PTR [r11+0x40]
   140007ac1:	mov    rdi,QWORD PTR [r11+0x48]
   140007ac5:	mov    rsp,r11
   140007ac8:	pop    r15
   140007aca:	pop    r14
   140007acc:	pop    r13
   140007ace:	pop    r12
   140007ad0:	pop    rbp
   140007ad1:	ret
   140007ad2:	int3
   140007ad3:	mov    DWORD PTR [rsp+0x28],0x7
   140007adb:	mov    DWORD PTR [rsp+0x20],0x41a
   140007ae3:	lea    r9,[rip+0x12fd6]        # 0x14001aac0
   140007aea:	lea    r8,[rip+0x123df]        # 0x140019ed0
   140007af1:	mov    rdx,r15
   140007af4:	lea    rcx,[rbp-0x10]
   140007af8:	call   0x14000f3ac
   140007afd:	mov    rdx,rax
   140007b00:	lea    rcx,[rbp-0x80]
   140007b04:	call   0x1400038ec
   140007b09:	mov    DWORD PTR [rsp+0x20],eax
   140007b0d:	lea    r9,[rip+0x1335c]        # 0x14001ae70
   140007b14:	mov    r8d,eax
   140007b17:	lea    rcx,[rbp-0x80]
   140007b1b:	call   0x1400106b0
   140007b20:	nop
   140007b21:	mov    DWORD PTR [rsp+0x28],0x7
   140007b29:	mov    DWORD PTR [rsp+0x20],0x3e6
   140007b31:	mov    r9,r13
   140007b34:	lea    r8,[rip+0x12395]        # 0x140019ed0
   140007b3b:	mov    rdx,r15
   140007b3e:	lea    rcx,[rbp-0x10]
   140007b42:	call   0x14000f3ac
   140007b47:	mov    rdx,rax
   140007b4a:	lea    rcx,[rbp-0x80]
   140007b4e:	call   0x1400038ec
   140007b53:	mov    DWORD PTR [rsp+0x20],eax
   140007b57:	lea    r9,[rip+0x130d2]        # 0x14001ac30
   140007b5e:	mov    r8d,eax
   140007b61:	lea    rcx,[rbp-0x80]
   140007b65:	call   0x1400106b0
   140007b6a:	int3
   140007b6b:	mov    DWORD PTR [rsp+0x28],edi
   140007b6f:	mov    DWORD PTR [rsp+0x20],0x3cc
   140007b77:	mov    r9,r13
   140007b7a:	mov    r8,rsi
   140007b7d:	mov    rdx,r15
   140007b80:	lea    rcx,[rbp-0x10]
   140007b84:	call   0x14000f3ac
   140007b89:	mov    rdx,rax
   140007b8c:	lea    rcx,[rbp-0x80]
   140007b90:	call   0x1400038ec
   140007b95:	mov    DWORD PTR [rsp+0x20],eax
   140007b99:	lea    r9,[rip+0x12f60]        # 0x14001ab00
   140007ba0:	mov    r8d,eax
   140007ba3:	lea    rcx,[rbp-0x80]
   140007ba7:	call   0x1400106b0
   140007bac:	int3
   140007bad:	mov    DWORD PTR [rsp+0x28],edi
   140007bb1:	mov    DWORD PTR [rsp+0x20],0x3d0
   140007bb9:	mov    r9,r13
   140007bbc:	mov    r8,rsi
   140007bbf:	mov    rdx,r15
   140007bc2:	lea    rcx,[rbp-0x10]
   140007bc6:	call   0x14000f3ac
   140007bcb:	mov    rdx,rax
   140007bce:	lea    rcx,[rbp-0x80]
   140007bd2:	call   0x1400038ec
   140007bd7:	mov    DWORD PTR [rsp+0x20],eax
   140007bdb:	lea    r9,[rip+0x12f8e]        # 0x14001ab70
   140007be2:	mov    r8d,eax
   140007be5:	lea    rcx,[rbp-0x80]
   140007be9:	call   0x1400106b0
   140007bee:	int3
   140007bef:	mov    DWORD PTR [rsp+0x28],edi
   140007bf3:	mov    DWORD PTR [rsp+0x20],0x3d6
   140007bfb:	mov    r9,r13
   140007bfe:	mov    r8,rsi
   140007c01:	mov    rdx,r15
   140007c04:	lea    rcx,[rbp-0x10]
   140007c08:	call   0x14000f3ac
   140007c0d:	mov    rdx,rax
   140007c10:	lea    rcx,[rbp-0x80]
   140007c14:	call   0x1400038ec
   140007c19:	mov    DWORD PTR [rsp+0x20],eax
   140007c1d:	lea    r9,[rip+0x12fac]        # 0x14001abd0
   140007c24:	mov    r8d,eax
   140007c27:	lea    rcx,[rbp-0x80]
   140007c2b:	call   0x1400106b0
   140007c30:	int3
   140007c31:	mov    DWORD PTR [rsp+0x28],0x7
   140007c39:	mov    DWORD PTR [rsp+0x20],0x3f5
   140007c41:	mov    r9,r13
   140007c44:	lea    r8,[rip+0x12285]        # 0x140019ed0
   140007c4b:	mov    rdx,r15
   140007c4e:	lea    rcx,[rbp-0x10]
   140007c52:	call   0x14000f3ac
   140007c57:	mov    rdx,rax
   140007c5a:	lea    rcx,[rbp-0x80]
   140007c5e:	call   0x1400038ec
   140007c63:	mov    DWORD PTR [rsp+0x20],eax
   140007c67:	lea    r9,[rip+0x13082]        # 0x14001acf0
   140007c6e:	mov    r8d,eax
   140007c71:	lea    rcx,[rbp-0x80]
   140007c75:	call   0x1400106b0
   140007c7a:	int3
   140007c7b:	mov    DWORD PTR [rsp+0x28],0x7
   140007c83:	mov    DWORD PTR [rsp+0x20],0x3ec
   140007c8b:	mov    r9,r13
   140007c8e:	lea    r8,[rip+0x1223b]        # 0x140019ed0
   140007c95:	mov    rdx,r15
   140007c98:	lea    rcx,[rbp-0x10]
   140007c9c:	call   0x14000f3ac
   140007ca1:	mov    rdx,rax
   140007ca4:	lea    rcx,[rbp-0x80]
   140007ca8:	call   0x1400038ec
   140007cad:	mov    r8d,eax
   140007cb0:	mov    DWORD PTR [rsp+0x20],esi
   140007cb4:	lea    r9,[rip+0x12fd5]        # 0x14001ac90
   140007cbb:	lea    rcx,[rbp-0x80]
   140007cbf:	call   0x1400106b0
   140007cc4:	int3
   140007cc5:	mov    DWORD PTR [rsp+0x28],0x7
   140007ccd:	mov    DWORD PTR [rsp+0x20],0x3fd
   140007cd5:	mov    r9,r13
   140007cd8:	lea    r8,[rip+0x121f1]        # 0x140019ed0
   140007cdf:	mov    rdx,r15
   140007ce2:	lea    rcx,[rbp-0x10]
   140007ce6:	call   0x14000f3ac
   140007ceb:	mov    rdx,rax
   140007cee:	lea    rcx,[rbp-0x80]
   140007cf2:	call   0x1400038ec
   140007cf7:	mov    DWORD PTR [rsp+0x20],eax
   140007cfb:	lea    r9,[rip+0x1304e]        # 0x14001ad50
   140007d02:	mov    r8d,eax
   140007d05:	lea    rcx,[rbp-0x80]
   140007d09:	call   0x1400106b0
   140007d0e:	int3
   140007d0f:	mov    DWORD PTR [rsp+0x28],0x7
   140007d17:	mov    DWORD PTR [rsp+0x20],0x402
   140007d1f:	mov    r9,r13
   140007d22:	lea    r8,[rip+0x121a7]        # 0x140019ed0
   140007d29:	mov    rdx,r15
   140007d2c:	lea    rcx,[rbp-0x10]
   140007d30:	call   0x14000f3ac
   140007d35:	mov    rdx,rax
   140007d38:	lea    rcx,[rbp-0x80]
   140007d3c:	call   0x1400038ec
   140007d41:	mov    DWORD PTR [rsp+0x20],eax
   140007d45:	lea    r9,[rip+0x13064]        # 0x14001adb0
   140007d4c:	mov    r8d,eax
   140007d4f:	lea    rcx,[rbp-0x80]
   140007d53:	call   0x1400106b0
   140007d58:	int3
   140007d59:	mov    DWORD PTR [rsp+0x28],0x7
   140007d61:	mov    DWORD PTR [rsp+0x20],0x406
   140007d69:	mov    r9,r13
   140007d6c:	lea    r8,[rip+0x1215d]        # 0x140019ed0
   140007d73:	mov    rdx,r15
   140007d76:	lea    rcx,[rbp-0x10]
   140007d7a:	call   0x14000f3ac
   140007d7f:	mov    rdx,rax
   140007d82:	lea    rcx,[rbp-0x80]
   140007d86:	call   0x1400038ec
   140007d8b:	mov    DWORD PTR [rsp+0x20],eax
   140007d8f:	lea    r9,[rip+0x12f5a]        # 0x14001acf0
   140007d96:	mov    r8d,eax
   140007d99:	lea    rcx,[rbp-0x80]
   140007d9d:	call   0x1400106b0
   140007da2:	int3
   140007da3:	mov    DWORD PTR [rsp+0x28],0x7
   140007dab:	mov    DWORD PTR [rsp+0x20],0x40c
   140007db3:	mov    r9,r13
   140007db6:	lea    r8,[rip+0x12113]        # 0x140019ed0
   140007dbd:	mov    rdx,r15
   140007dc0:	lea    rcx,[rbp-0x10]
   140007dc4:	call   0x14000f3ac
   140007dc9:	mov    rdx,rax
   140007dcc:	lea    rcx,[rbp-0x80]
   140007dd0:	call   0x1400038ec
   140007dd5:	mov    DWORD PTR [rsp+0x20],eax
   140007dd9:	lea    r9,[rip+0x13030]        # 0x14001ae10
   140007de0:	mov    r8d,eax
   140007de3:	lea    rcx,[rbp-0x80]
   140007de7:	call   0x1400106b0
   140007dec:	int3
   140007ded:	mov    DWORD PTR [rsp+0x28],0x7
   140007df5:	mov    DWORD PTR [rsp+0x20],0x46f
   140007dfd:	lea    r9,[rip+0x12cbc]        # 0x14001aac0
   140007e04:	lea    r8,[rip+0x120c5]        # 0x140019ed0
   140007e0b:	mov    rdx,r15
   140007e0e:	lea    rcx,[rbp-0x10]
   140007e12:	call   0x14000f3ac
   140007e17:	mov    rdx,rax
   140007e1a:	lea    rcx,[rbp-0x80]
   140007e1e:	call   0x1400038ec
   140007e23:	mov    DWORD PTR [rsp+0x20],eax
   140007e27:	lea    r9,[rip+0x130f2]        # 0x14001af20
   140007e2e:	mov    r8d,eax
   140007e31:	lea    rcx,[rbp-0x80]
   140007e35:	call   0x1400106b0
   140007e3a:	int3
   140007e3b:	int3
   140007e3c:	int3
   140007e3d:	int3
   140007e3e:	int3
   140007e3f:	int3
   140007e40:	int3
   140007e41:	int3
   140007e42:	int3
   140007e43:	int3
   140007e44:	mov    rax,rsp
   140007e47:	push   rbp
   140007e48:	push   rdi
   140007e49:	push   r12
   140007e4b:	push   r14
   140007e4d:	push   r15
   140007e4f:	lea    rbp,[rax-0x188]
   140007e56:	sub    rsp,0x260
   140007e5d:	mov    QWORD PTR [rbp+0x38],0xfffffffffffffffe
   140007e65:	mov    QWORD PTR [rax+0x10],rbx
   140007e69:	mov    QWORD PTR [rax+0x18],rsi
   140007e6d:	mov    rax,QWORD PTR [rip+0x1c2a4]        # 0x140024118
   140007e74:	xor    rax,rsp
   140007e77:	mov    QWORD PTR [rbp+0x150],rax
   140007e7e:	mov    r15,rcx
   140007e81:	lea    rsi,[rip+0x12068]        # 0x140019ef0
   140007e88:	mov    QWORD PTR [rbp-0x70],rsi
   140007e8c:	lea    r14,[rip+0x130e5]        # 0x14001af78
   140007e93:	mov    QWORD PTR [rbp-0x68],r14
   140007e97:	lea    rax,[rip+0x12032]        # 0x140019ed0
   140007e9e:	mov    QWORD PTR [rbp-0x60],rax
   140007ea2:	mov    DWORD PTR [rbp-0x58],0x478
   140007ea9:	mov    DWORD PTR [rbp-0x54],0x7
   140007eb0:	mov    edi,0xff
   140007eb5:	mov    DWORD PTR [rbp-0x50],edi
   140007eb8:	xor    r12d,r12d
   140007ebb:	mov    DWORD PTR [rbp+0x30],0x1000000
   140007ec2:	lea    ebx,[r12+0x78]
   140007ec7:	mov    r8d,ebx
   140007eca:	xor    edx,edx
   140007ecc:	lea    rcx,[rbp-0x48]
   140007ed0:	call   0x140015692
   140007ed5:	lea    rdx,[rbp-0x70]
   140007ed9:	lea    rcx,[rbp+0x50]
   140007edd:	call   0x14000f85c
   140007ee2:	nop
   140007ee3:	mov    QWORD PTR [rsp+0x50],r12
   140007ee8:	movups xmm0,XMMWORD PTR [rip+0x11181]        # 0x140019070
   140007eef:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   140007ef5:	movups xmm1,XMMWORD PTR [rip+0x11164]        # 0x140019060
   140007efc:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   140007f02:	mov    QWORD PTR [rbp-0x70],rsi
   140007f06:	mov    QWORD PTR [rbp-0x68],r14
   140007f0a:	lea    rax,[rip+0x11fbf]        # 0x140019ed0
   140007f11:	mov    QWORD PTR [rbp-0x60],rax
   140007f15:	mov    DWORD PTR [rbp-0x58],0x483
   140007f1c:	mov    DWORD PTR [rbp-0x54],0x7
   140007f23:	mov    DWORD PTR [rbp-0x50],edi
   140007f26:	mov    DWORD PTR [rbp+0x30],0x1000000
   140007f2d:	mov    r8d,ebx
   140007f30:	xor    edx,edx
   140007f32:	lea    rcx,[rbp-0x48]
   140007f36:	call   0x140015692
   140007f3b:	lea    rax,[rsp+0x50]
   140007f40:	mov    QWORD PTR [rsp+0x30],rax
   140007f45:	lea    rax,[rsp+0x60]
   140007f4a:	mov    QWORD PTR [rsp+0x28],rax
   140007f4f:	lea    r9,[rip+0x109f2]        # 0x140018948
   140007f56:	lea    r8,[rsp+0x70]
   140007f5b:	lea    rdx,[rbp-0x70]
   140007f5f:	lea    rcx,[rbp+0x50]
   140007f63:	call   0x140011460
   140007f68:	cmp    DWORD PTR [rbp+0x58],r12d
   140007f6c:	jl     0x140008266
   140007f72:	mov    QWORD PTR [rsp+0x48],r12
   140007f77:	movups xmm0,XMMWORD PTR [rip+0x10432]        # 0x1400183b0
   140007f7e:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   140007f84:	mov    rcx,QWORD PTR [rsp+0x50]
   140007f89:	mov    rax,QWORD PTR [rcx]
   140007f8c:	lea    rdx,[rsp+0x48]
   140007f91:	mov    QWORD PTR [rsp+0x20],rdx
   140007f96:	lea    r9d,[r12+0x4]
   140007f9b:	lea    r8d,[r12+0x1]
   140007fa0:	lea    rdx,[rsp+0x60]
   140007fa5:	mov    rax,QWORD PTR [rax+0x50]
   140007fa9:	call   QWORD PTR [rip+0x102e9]        # 0x140018298
   140007faf:	mov    DWORD PTR [rbp+0x58],eax
   140007fb2:	test   eax,eax
   140007fb4:	js     0x1400081c4
   140007fba:	mov    rcx,QWORD PTR [rsp+0x48]
   140007fbf:	mov    rax,QWORD PTR [rcx]
   140007fc2:	lea    r9,[rsp+0x40]
   140007fc7:	lea    r8,[rbp+0xc0]
   140007fce:	lea    edx,[rbx-0x77]
   140007fd1:	mov    rax,QWORD PTR [rax+0x18]
   140007fd5:	call   QWORD PTR [rip+0x102bd]        # 0x140018298
   140007fdb:	mov    DWORD PTR [rbp+0x58],eax
   140007fde:	test   eax,eax
   140007fe0:	js     0x14000821c
   140007fe6:	lea    ecx,[rbx-0x77]
   140007fe9:	lea    r14,[rip+0xf070]        # 0x140017060
   140007ff0:	cmp    eax,0x1
   140007ff3:	je     0x14000815b
   140007ff9:	mov    ecx,DWORD PTR [rbp+0xe0]
   140007fff:	sub    ecx,0x1
   140008002:	je     0x14000802f
   140008004:	sub    ecx,0x1
   140008007:	je     0x140008028
   140008009:	sub    ecx,0x1
   14000800c:	je     0x140008021
   14000800e:	cmp    ecx,0x1
   140008011:	je     0x14000801a
   140008013:	mov    edx,0x6a
   140008018:	jmp    0x140008034
   14000801a:	mov    edx,0x7a
   14000801f:	jmp    0x140008034
   140008021:	mov    edx,0x69
   140008026:	jmp    0x140008034
   140008028:	mov    edx,0x68
   14000802d:	jmp    0x140008034
   14000802f:	mov    edx,0x67
   140008034:	mov    rcx,r15
   140008037:	call   0x14000c1fc
   14000803c:	mov    rbx,rax
   14000803f:	movups xmm0,XMMWORD PTR [rbp+0xc8]
   140008046:	movdqu XMMWORD PTR [rbp+0x40],xmm0
   14000804b:	lea    rcx,[rbp+0x40]
   14000804f:	call   0x14000e3fc
   140008054:	mov    rsi,rax
   140008057:	mov    QWORD PTR [rsp+0x68],rax
   14000805c:	mov    QWORD PTR [rsp+0x60],r14
   140008061:	mov    rdi,QWORD PTR [rbp+0xd8]
   140008068:	mov    QWORD PTR [rsp+0x78],rdi
   14000806d:	mov    QWORD PTR [rsp+0x70],r14
   140008072:	mov    r14,QWORD PTR [rbp+0xe8]
   140008079:	mov    QWORD PTR [rbp-0x78],r14
   14000807d:	lea    rax,[rip+0xefdc]        # 0x140017060
   140008084:	mov    QWORD PTR [rbp-0x80],rax
   140008088:	lea    rax,[rip+0x13c81]        # 0x14001bd10
   14000808f:	test   r14,r14
   140008092:	cmovne rax,r14
   140008096:	lea    r8,[rip+0x13c73]        # 0x14001bd10
   14000809d:	test   rdi,rdi
   1400080a0:	cmovne r8,rdi
   1400080a4:	mov    QWORD PTR [rsp+0x28],rax
   1400080a9:	mov    QWORD PTR [rsp+0x20],rsi
   1400080ae:	mov    r9,rbx
   1400080b1:	mov    edx,0x40002756
   1400080b6:	mov    rcx,r15
   1400080b9:	call   0x14000c6f4
   1400080be:	nop
   1400080bf:	test   r14,r14
   1400080c2:	je     0x1400080d3
   1400080c4:	mov    rcx,r14
   1400080c7:	rex.W call QWORD PTR [rip+0xffb2]        # 0x140018080
   1400080ce:	nop    DWORD PTR [rax+rax*1+0x0]
   1400080d3:	mov    QWORD PTR [rbp-0x78],r12
   1400080d7:	lea    rbx,[rip+0xef8a]        # 0x140017068
   1400080de:	mov    QWORD PTR [rbp-0x80],rbx
   1400080e2:	test   rdi,rdi
   1400080e5:	je     0x1400080f6
   1400080e7:	mov    rcx,rdi
   1400080ea:	rex.W call QWORD PTR [rip+0xff8f]        # 0x140018080
   1400080f1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400080f6:	mov    QWORD PTR [rsp+0x78],r12
   1400080fb:	mov    QWORD PTR [rsp+0x70],rbx
   140008100:	test   rsi,rsi
   140008103:	je     0x140008114
   140008105:	mov    rcx,rsi
   140008108:	rex.W call QWORD PTR [rip+0xff71]        # 0x140018080
   14000810f:	nop    DWORD PTR [rax+rax*1+0x0]
   140008114:	mov    QWORD PTR [rsp+0x68],r12
   140008119:	mov    QWORD PTR [rsp+0x60],rbx
   14000811e:	mov    rcx,QWORD PTR [rsp+0x48]
   140008123:	mov    rax,QWORD PTR [rcx]
   140008126:	lea    r9,[rsp+0x40]
   14000812b:	lea    r8,[rbp+0xc0]
   140008132:	mov    edx,0x1
   140008137:	mov    rax,QWORD PTR [rax+0x18]
   14000813b:	call   QWORD PTR [rip+0x10157]        # 0x140018298
   140008141:	mov    DWORD PTR [rbp+0x58],eax
   140008144:	mov    ecx,r12d
   140008147:	test   eax,eax
   140008149:	lea    r14,[rip+0xef10]        # 0x140017060
   140008150:	js     0x14000820e
   140008156:	jmp    0x140007ff0
   14000815b:	mov    DWORD PTR [r15+0x48],ecx
   14000815f:	mov    rcx,QWORD PTR [rsp+0x48]
   140008164:	test   rcx,rcx
   140008167:	je     0x140008177
   140008169:	mov    rax,QWORD PTR [rcx]
   14000816c:	mov    rax,QWORD PTR [rax+0x10]
   140008170:	call   QWORD PTR [rip+0x10122]        # 0x140018298
   140008176:	nop
   140008177:	mov    rcx,QWORD PTR [rsp+0x50]
   14000817c:	test   rcx,rcx
   14000817f:	je     0x14000818f
   140008181:	mov    rax,QWORD PTR [rcx]
   140008184:	mov    rax,QWORD PTR [rax+0x10]
   140008188:	call   QWORD PTR [rip+0x1010a]        # 0x140018298
   14000818e:	nop
   14000818f:	lea    rcx,[rbp+0x50]
   140008193:	call   0x14000f958
   140008198:	mov    rcx,QWORD PTR [rbp+0x150]
   14000819f:	xor    rcx,rsp
   1400081a2:	call   0x1400143c0
   1400081a7:	lea    r11,[rsp+0x260]
   1400081af:	mov    rbx,QWORD PTR [r11+0x38]
   1400081b3:	mov    rsi,QWORD PTR [r11+0x40]
   1400081b7:	mov    rsp,r11
   1400081ba:	pop    r15
   1400081bc:	pop    r14
   1400081be:	pop    r12
   1400081c0:	pop    rdi
   1400081c1:	pop    rbp
   1400081c2:	ret
   1400081c3:	int3
   1400081c4:	mov    DWORD PTR [rsp+0x28],0x7
   1400081cc:	mov    DWORD PTR [rsp+0x20],0x493
   1400081d4:	mov    r9,r14
   1400081d7:	lea    r8,[rip+0x11cf2]        # 0x140019ed0
   1400081de:	mov    rdx,rsi
   1400081e1:	lea    rcx,[rbp-0x70]
   1400081e5:	call   0x14000f3ac
   1400081ea:	mov    rdx,rax
   1400081ed:	lea    rcx,[rbp+0x50]
   1400081f1:	call   0x1400038ec
   1400081f6:	mov    DWORD PTR [rsp+0x20],eax
   1400081fa:	lea    r9,[rip+0x107a7]        # 0x1400189a8
   140008201:	mov    r8d,eax
   140008204:	lea    rcx,[rbp+0x50]
   140008208:	call   0x1400106b0
   14000820d:	int3
   14000820e:	lea    rsi,[rip+0x11cdb]        # 0x140019ef0
   140008215:	lea    r14,[rip+0x12d5c]        # 0x14001af78
   14000821c:	mov    DWORD PTR [rsp+0x28],0x7
   140008224:	mov    DWORD PTR [rsp+0x20],0x49d
   14000822c:	mov    r9,r14
   14000822f:	lea    r8,[rip+0x11c9a]        # 0x140019ed0
   140008236:	mov    rdx,rsi
   140008239:	lea    rcx,[rbp-0x70]
   14000823d:	call   0x14000f3ac
   140008242:	mov    rdx,rax
   140008245:	lea    rcx,[rbp+0x50]
   140008249:	call   0x1400038ec
   14000824e:	mov    DWORD PTR [rsp+0x20],eax
   140008252:	lea    r9,[rip+0x1078f]        # 0x1400189e8
   140008259:	mov    r8d,eax
   14000825c:	lea    rcx,[rbp+0x50]
   140008260:	call   0x1400106b0
   140008265:	nop
   140008266:	mov    DWORD PTR [rsp+0x28],0x7
   14000826e:	mov    DWORD PTR [rsp+0x20],0x48a
   140008276:	mov    r9,r14
   140008279:	lea    r8,[rip+0x11c50]        # 0x140019ed0
   140008280:	mov    rdx,rsi
   140008283:	lea    rcx,[rbp-0x70]
   140008287:	call   0x14000f3ac
   14000828c:	mov    rdx,rax
   14000828f:	lea    rcx,[rbp+0x50]
   140008293:	call   0x1400038ec
   140008298:	mov    DWORD PTR [rsp+0x20],eax
   14000829c:	lea    r9,[rip+0x106bd]        # 0x140018960
   1400082a3:	mov    r8d,eax
   1400082a6:	lea    rcx,[rbp+0x50]
   1400082aa:	call   0x1400106b0
   1400082af:	int3
   1400082b0:	int3
   1400082b1:	int3
   1400082b2:	int3
   1400082b3:	int3
   1400082b4:	int3
   1400082b5:	int3
   1400082b6:	int3
   1400082b7:	int3
   1400082b8:	mov    rax,rsp
   1400082bb:	push   rbp
   1400082bc:	push   rdi
   1400082bd:	push   r12
   1400082bf:	push   r13
   1400082c1:	push   r14
   1400082c3:	lea    rbp,[rax-0x128]
   1400082ca:	sub    rsp,0x200
   1400082d1:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   1400082dc:	mov    QWORD PTR [rax+0x10],rbx
   1400082e0:	mov    QWORD PTR [rax+0x18],rsi
   1400082e4:	mov    rax,QWORD PTR [rip+0x1be2d]        # 0x140024118
   1400082eb:	xor    rax,rsp
   1400082ee:	mov    QWORD PTR [rbp+0xf0],rax
   1400082f5:	mov    rsi,rcx
   1400082f8:	lea    r12,[rip+0x11bf1]        # 0x140019ef0
   1400082ff:	mov    QWORD PTR [rbp-0x80],r12
   140008303:	lea    r13,[rip+0x12ca6]        # 0x14001afb0
   14000830a:	mov    QWORD PTR [rbp-0x78],r13
   14000830e:	lea    rdi,[rip+0x11bbb]        # 0x140019ed0
   140008315:	mov    QWORD PTR [rbp-0x70],rdi
   140008319:	mov    DWORD PTR [rbp-0x68],0x4ce
   140008320:	mov    DWORD PTR [rbp-0x64],0x7
   140008327:	mov    DWORD PTR [rbp-0x60],0xff
   14000832e:	xor    r14d,r14d
   140008331:	mov    DWORD PTR [rbp+0x20],0x1000000
   140008338:	xor    edx,edx
   14000833a:	lea    r8d,[r14+0x78]
   14000833e:	lea    rcx,[rbp-0x58]
   140008342:	call   0x140015692
   140008347:	lea    rdx,[rbp-0x80]
   14000834b:	lea    rcx,[rbp+0x30]
   14000834f:	call   0x14000f85c
   140008354:	nop
   140008355:	test   DWORD PTR [rip+0x1c3ad],0xfffffff8        # 0x14002470c
   14000835f:	je     0x140008379
   140008361:	lea    edx,[r14+0xd]
   140008365:	mov    rcx,rsi
   140008368:	call   0x1400038f8
   14000836d:	mov    rdx,rax
   140008370:	call   0x14000b248
   140008375:	mov    ebx,eax
   140008377:	jmp    0x14000837e
   140008379:	mov    ebx,0x1d
   14000837e:	movups xmm0,XMMWORD PTR [rip+0x1002b]        # 0x1400183b0
   140008385:	movdqu XMMWORD PTR [rbp+0xe0],xmm0
   14000838d:	lea    rdx,[rbp+0xe0]
   140008394:	mov    rcx,rsi
   140008397:	call   0x140001264
   14000839c:	mov    QWORD PTR [rsp+0x50],r14
   1400083a1:	movups xmm0,XMMWORD PTR [rip+0x13980]        # 0x14001bd28
   1400083a8:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   1400083ae:	movups xmm1,XMMWORD PTR [rip+0x13963]        # 0x14001bd18
   1400083b5:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   1400083bb:	mov    QWORD PTR [rbp-0x80],r12
   1400083bf:	mov    QWORD PTR [rbp-0x78],r13
   1400083c3:	mov    QWORD PTR [rbp-0x70],rdi
   1400083c7:	mov    DWORD PTR [rbp-0x68],0x4df
   1400083ce:	mov    DWORD PTR [rbp-0x64],0x7
   1400083d5:	mov    DWORD PTR [rbp-0x60],0xff
   1400083dc:	mov    DWORD PTR [rbp+0x20],0x1000000
   1400083e3:	xor    edx,edx
   1400083e5:	lea    r8d,[rdx+0x78]
   1400083e9:	lea    rcx,[rbp-0x58]
   1400083ed:	call   0x140015692
   1400083f2:	lea    rax,[rsp+0x50]
   1400083f7:	mov    QWORD PTR [rsp+0x30],rax
   1400083fc:	lea    rax,[rsp+0x60]
   140008401:	mov    QWORD PTR [rsp+0x28],rax
   140008406:	lea    r9,[rip+0x123eb]        # 0x14001a7f8
   14000840d:	lea    r8,[rsp+0x70]
   140008412:	lea    rdx,[rbp-0x80]
   140008416:	lea    rcx,[rbp+0x30]
   14000841a:	call   0x140011460
   14000841f:	cmp    DWORD PTR [rbp+0x38],r14d
   140008423:	jl     0x140008651
   140008429:	mov    QWORD PTR [rsp+0x48],r14
   14000842e:	movaps xmm0,XMMWORD PTR [rbp+0xe0]
   140008435:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   14000843b:	mov    rcx,QWORD PTR [rsp+0x50]
   140008440:	mov    rax,QWORD PTR [rcx]
   140008443:	lea    r9,[rsp+0x48]
   140008448:	mov    r8d,ebx
   14000844b:	lea    rdx,[rsp+0x60]
   140008450:	mov    rax,QWORD PTR [rax+0x20]
   140008454:	call   QWORD PTR [rip+0xfe3e]        # 0x140018298
   14000845a:	mov    DWORD PTR [rbp+0x38],eax
   14000845d:	test   eax,eax
   14000845f:	js     0x140008697
   140008465:	cmp    eax,0x1
   140008468:	je     0x1400085c8
   14000846e:	mov    rcx,QWORD PTR [rsp+0x48]
   140008473:	mov    rax,QWORD PTR [rcx]
   140008476:	lea    r9,[rsp+0x40]
   14000847b:	lea    r8,[rbp+0xa8]
   140008482:	mov    edx,0x1
   140008487:	mov    rax,QWORD PTR [rax+0x18]
   14000848b:	call   QWORD PTR [rip+0xfe07]        # 0x140018298
   140008491:	mov    DWORD PTR [rbp+0x38],eax
   140008494:	test   eax,eax
   140008496:	js     0x14000860b
   14000849c:	lea    rcx,[rip+0xebbd]        # 0x140017060
   1400084a3:	cmp    eax,0x1
   1400084a6:	je     0x14000855f
   1400084ac:	mov    rbx,QWORD PTR [rbp+0xb0]
   1400084b3:	mov    QWORD PTR [rsp+0x68],rbx
   1400084b8:	mov    QWORD PTR [rsp+0x60],rcx
   1400084bd:	mov    rdi,QWORD PTR [rbp+0xb8]
   1400084c4:	mov    QWORD PTR [rsp+0x78],rdi
   1400084c9:	mov    QWORD PTR [rsp+0x70],rcx
   1400084ce:	mov    r9,rbx
   1400084d1:	mov    r8,rdi
   1400084d4:	mov    edx,0x40002759
   1400084d9:	mov    rcx,rsi
   1400084dc:	call   0x14000c6f4
   1400084e1:	nop
   1400084e2:	test   rdi,rdi
   1400084e5:	je     0x1400084f6
   1400084e7:	mov    rcx,rdi
   1400084ea:	rex.W call QWORD PTR [rip+0xfb8f]        # 0x140018080
   1400084f1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400084f6:	mov    QWORD PTR [rsp+0x78],r14
   1400084fb:	lea    rdi,[rip+0xeb66]        # 0x140017068
   140008502:	mov    QWORD PTR [rsp+0x70],rdi
   140008507:	test   rbx,rbx
   14000850a:	je     0x14000851b
   14000850c:	mov    rcx,rbx
   14000850f:	rex.W call QWORD PTR [rip+0xfb6a]        # 0x140018080
   140008516:	nop    DWORD PTR [rax+rax*1+0x0]
   14000851b:	mov    QWORD PTR [rsp+0x68],r14
   140008520:	mov    QWORD PTR [rsp+0x60],rdi
   140008525:	mov    rcx,QWORD PTR [rsp+0x48]
   14000852a:	mov    rax,QWORD PTR [rcx]
   14000852d:	lea    r9,[rsp+0x40]
   140008532:	lea    r8,[rbp+0xa8]
   140008539:	mov    edx,0x1
   14000853e:	mov    rax,QWORD PTR [rax+0x18]
   140008542:	call   QWORD PTR [rip+0xfd50]        # 0x140018298
   140008548:	mov    DWORD PTR [rbp+0x38],eax
   14000854b:	test   eax,eax
   14000854d:	lea    rcx,[rip+0xeb0c]        # 0x140017060
   140008554:	js     0x140008604
   14000855a:	jmp    0x1400084a3
   14000855f:	mov    DWORD PTR [rsi+0x48],r14d
   140008563:	mov    rcx,QWORD PTR [rsp+0x48]
   140008568:	test   rcx,rcx
   14000856b:	je     0x14000857b
   14000856d:	mov    rax,QWORD PTR [rcx]
   140008570:	mov    rax,QWORD PTR [rax+0x10]
   140008574:	call   QWORD PTR [rip+0xfd1e]        # 0x140018298
   14000857a:	nop
   14000857b:	mov    rcx,QWORD PTR [rsp+0x50]
   140008580:	test   rcx,rcx
   140008583:	je     0x140008593
   140008585:	mov    rax,QWORD PTR [rcx]
   140008588:	mov    rax,QWORD PTR [rax+0x10]
   14000858c:	call   QWORD PTR [rip+0xfd06]        # 0x140018298
   140008592:	nop
   140008593:	lea    rcx,[rbp+0x30]
   140008597:	call   0x14000f958
   14000859c:	mov    rcx,QWORD PTR [rbp+0xf0]
   1400085a3:	xor    rcx,rsp
   1400085a6:	call   0x1400143c0
   1400085ab:	lea    r11,[rsp+0x200]
   1400085b3:	mov    rbx,QWORD PTR [r11+0x38]
   1400085b7:	mov    rsi,QWORD PTR [r11+0x40]
   1400085bb:	mov    rsp,r11
   1400085be:	pop    r14
   1400085c0:	pop    r13
   1400085c2:	pop    r12
   1400085c4:	pop    rdi
   1400085c5:	pop    rbp
   1400085c6:	ret
   1400085c7:	int3
   1400085c8:	mov    DWORD PTR [rsp+0x28],0x7
   1400085d0:	mov    DWORD PTR [rsp+0x20],0x4f5
   1400085d8:	mov    r9,r13
   1400085db:	mov    r8,rdi
   1400085de:	mov    rdx,r12
   1400085e1:	lea    rcx,[rbp-0x80]
   1400085e5:	call   0x14000f3ac
   1400085ea:	lea    r9,[rip+0x129ff]        # 0x14001aff0
   1400085f1:	mov    r8d,0x1
   1400085f7:	mov    rdx,rax
   1400085fa:	lea    rcx,[rbp+0x30]
   1400085fe:	call   0x1400106b0
   140008603:	int3
   140008604:	lea    rdi,[rip+0x118c5]        # 0x140019ed0
   14000860b:	mov    DWORD PTR [rsp+0x28],0x7
   140008613:	mov    DWORD PTR [rsp+0x20],0x504
   14000861b:	mov    r9,r13
   14000861e:	mov    r8,rdi
   140008621:	mov    rdx,r12
   140008624:	lea    rcx,[rbp-0x80]
   140008628:	call   0x14000f3ac
   14000862d:	mov    rdx,rax
   140008630:	lea    rcx,[rbp+0x30]
   140008634:	call   0x1400038ec
   140008639:	mov    DWORD PTR [rsp+0x20],eax
   14000863d:	lea    r9,[rip+0x103a4]        # 0x1400189e8
   140008644:	mov    r8d,eax
   140008647:	lea    rcx,[rbp+0x30]
   14000864b:	call   0x1400106b0
   140008650:	nop
   140008651:	mov    DWORD PTR [rsp+0x28],0x7
   140008659:	mov    DWORD PTR [rsp+0x20],0x4e6
   140008661:	mov    r9,r13
   140008664:	mov    r8,rdi
   140008667:	mov    rdx,r12
   14000866a:	lea    rcx,[rbp-0x80]
   14000866e:	call   0x14000f3ac
   140008673:	mov    rdx,rax
   140008676:	lea    rcx,[rbp+0x30]
   14000867a:	call   0x1400038ec
   14000867f:	mov    DWORD PTR [rsp+0x20],eax
   140008683:	lea    r9,[rip+0x102d6]        # 0x140018960
   14000868a:	mov    r8d,eax
   14000868d:	lea    rcx,[rbp+0x30]
   140008691:	call   0x1400106b0
   140008696:	nop
   140008697:	mov    DWORD PTR [rsp+0x28],0x7
   14000869f:	mov    DWORD PTR [rsp+0x20],0x4f1
   1400086a7:	mov    r9,r13
   1400086aa:	mov    r8,rdi
   1400086ad:	mov    rdx,r12
   1400086b0:	lea    rcx,[rbp-0x80]
   1400086b4:	call   0x14000f3ac
   1400086b9:	mov    rdx,rax
   1400086bc:	lea    rcx,[rbp+0x30]
   1400086c0:	call   0x1400038ec
   1400086c5:	mov    DWORD PTR [rsp+0x20],eax
   1400086c9:	lea    r9,[rip+0x12150]        # 0x14001a820
   1400086d0:	mov    r8d,eax
   1400086d3:	lea    rcx,[rbp+0x30]
   1400086d7:	call   0x1400106b0
   1400086dc:	int3
   1400086dd:	int3
   1400086de:	int3
   1400086df:	int3
   1400086e0:	int3
   1400086e1:	int3
   1400086e2:	int3
   1400086e3:	int3
   1400086e4:	mov    rax,rsp
   1400086e7:	push   rbp
   1400086e8:	push   rdi
   1400086e9:	push   r13
   1400086eb:	push   r14
   1400086ed:	push   r15
   1400086ef:	lea    rbp,[rax-0xc8]
   1400086f6:	sub    rsp,0x1a0
   1400086fd:	mov    QWORD PTR [rsp+0x60],0xfffffffffffffffe
   140008706:	mov    QWORD PTR [rax+0x10],rbx
   14000870a:	mov    QWORD PTR [rax+0x18],rsi
   14000870e:	mov    rax,QWORD PTR [rip+0x1ba03]        # 0x140024118
   140008715:	xor    rax,rsp
   140008718:	mov    QWORD PTR [rbp+0x90],rax
   14000871f:	mov    rdi,rcx
   140008722:	lea    r13,[rip+0x117c7]        # 0x140019ef0
   140008729:	mov    QWORD PTR [rsp+0x68],r13
   14000872e:	lea    rax,[rip+0x12943]        # 0x14001b078
   140008735:	mov    QWORD PTR [rsp+0x70],rax
   14000873a:	lea    rax,[rip+0x1178f]        # 0x140019ed0
   140008741:	mov    QWORD PTR [rsp+0x78],rax
   140008746:	mov    DWORD PTR [rbp-0x80],0x517
   14000874d:	mov    DWORD PTR [rbp-0x7c],0x7
   140008754:	mov    DWORD PTR [rbp-0x78],0xff
   14000875b:	xor    r15d,r15d
   14000875e:	mov    DWORD PTR [rbp+0x8],0x1000000
   140008765:	xor    edx,edx
   140008767:	lea    r8d,[r15+0x78]
   14000876b:	lea    rcx,[rbp-0x70]
   14000876f:	call   0x140015692
   140008774:	lea    rdx,[rsp+0x68]
   140008779:	lea    rcx,[rbp+0x10]
   14000877d:	call   0x14000f85c
   140008782:	nop
   140008783:	mov    QWORD PTR [rsp+0x50],r15
   140008788:	movups xmm0,XMMWORD PTR [rip+0xfc21]        # 0x1400183b0
   14000878f:	movdqu XMMWORD PTR [rbp+0x80],xmm0
   140008797:	lea    rdx,[rbp+0x80]
   14000879e:	mov    rcx,rdi
   1400087a1:	call   0x140001264
   1400087a6:	lea    edx,[r15+0x3]
   1400087aa:	mov    rcx,rdi
   1400087ad:	call   0x1400038f8
   1400087b2:	mov    rsi,rax
   1400087b5:	lea    edx,[r15+0x7]
   1400087b9:	mov    rcx,rdi
   1400087bc:	call   0x1400038f8
   1400087c1:	mov    r14,rax
   1400087c4:	lea    r8,[rsp+0x50]
   1400087c9:	mov    rcx,rdi
   1400087cc:	call   0x14000b9d8
   1400087d1:	test   eax,eax
   1400087d3:	jne    0x1400087fa
   1400087d5:	lea    r9d,[r15+0x1]
   1400087d9:	lea    r8,[rsp+0x50]
   1400087de:	lea    edx,[rax+0x5]
   1400087e1:	mov    rcx,rdi
   1400087e4:	call   0x14000b824
   1400087e9:	test   eax,eax
   1400087eb:	jne    0x1400087f3
   1400087ed:	or     rbx,0xffffffffffffffff
   1400087f1:	jmp    0x14000882d
   1400087f3:	mov    rbx,QWORD PTR [rsp+0x50]
   1400087f8:	jmp    0x14000882d
   1400087fa:	mov    rbx,QWORD PTR [rsp+0x50]
   1400087ff:	test   rbx,rbx
   140008802:	jle    0x14000882d
   140008804:	mov    rdx,rsi
   140008807:	call   0x14000c084
   14000880c:	mov    rcx,rax
   14000880f:	movabs rax,0x47ae147ae147ae15
   140008819:	mul    rcx
   14000881c:	sub    rcx,rdx
   14000881f:	shr    rcx,1
   140008822:	add    rcx,rdx
   140008825:	shr    rcx,0x6
   140008829:	imul   rbx,rcx
   14000882d:	movaps xmm0,XMMWORD PTR [rbp+0x80]
   140008834:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   14000883a:	mov    rcx,QWORD PTR [rdi]
   14000883d:	mov    rax,QWORD PTR [rcx]
   140008840:	lea    rdx,[rbp+0x10]
   140008844:	mov    QWORD PTR [rsp+0x28],rdx
   140008849:	mov    QWORD PTR [rsp+0x20],rbx
   14000884e:	mov    r9,r14
   140008851:	mov    r8,rsi
   140008854:	lea    rdx,[rsp+0x50]
   140008859:	mov    rax,QWORD PTR [rax+0x30]
   14000885d:	call   QWORD PTR [rip+0xfa35]        # 0x140018298
   140008863:	mov    QWORD PTR [rsp+0x40],r15
   140008868:	movaps xmm0,XMMWORD PTR [rbp+0x80]
   14000886f:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   140008875:	lea    r8,[rsp+0x40]
   14000887a:	lea    rdx,[rsp+0x50]
   14000887f:	mov    rcx,rdi
   140008882:	call   0x140005050
   140008887:	mov    rcx,QWORD PTR [rsp+0x40]
   14000888c:	mov    rax,QWORD PTR [rcx]
   14000888f:	mov    r9,rbx
   140008892:	mov    r8,r14
   140008895:	mov    rdx,rsi
   140008898:	mov    rax,QWORD PTR [rax+0x20]
   14000889c:	call   QWORD PTR [rip+0xf9f6]        # 0x140018298
   1400088a2:	mov    DWORD PTR [rbp+0x18],eax
   1400088a5:	test   eax,eax
   1400088a7:	jns    0x1400088c0
   1400088a9:	cmp    eax,0x80042308
   1400088ae:	jne    0x14000891e
   1400088b0:	mov    edx,0x40002b5e
   1400088b5:	mov    rcx,rdi
   1400088b8:	call   0x14000d524
   1400088bd:	nop
   1400088be:	jmp    0x1400088d1
   1400088c0:	mov    edx,0x40002750
   1400088c5:	mov    rcx,rdi
   1400088c8:	call   0x14000c6f4
   1400088cd:	mov    DWORD PTR [rdi+0x48],r15d
   1400088d1:	mov    rcx,QWORD PTR [rsp+0x40]
   1400088d6:	test   rcx,rcx
   1400088d9:	je     0x1400088e9
   1400088db:	mov    rax,QWORD PTR [rcx]
   1400088de:	mov    rax,QWORD PTR [rax+0x10]
   1400088e2:	call   QWORD PTR [rip+0xf9b0]        # 0x140018298
   1400088e8:	nop
   1400088e9:	lea    rcx,[rbp+0x10]
   1400088ed:	call   0x14000f958
   1400088f2:	mov    rcx,QWORD PTR [rbp+0x90]
   1400088f9:	xor    rcx,rsp
   1400088fc:	call   0x1400143c0
   140008901:	lea    r11,[rsp+0x1a0]
   140008909:	mov    rbx,QWORD PTR [r11+0x38]
   14000890d:	mov    rsi,QWORD PTR [r11+0x40]
   140008911:	mov    rsp,r11
   140008914:	pop    r15
   140008916:	pop    r14
   140008918:	pop    r13
   14000891a:	pop    rdi
   14000891b:	pop    rbp
   14000891c:	ret
   14000891d:	int3
   14000891e:	mov    DWORD PTR [rsp+0x28],0x7
   140008926:	mov    DWORD PTR [rsp+0x20],0x53e
   14000892e:	lea    r9,[rip+0x12743]        # 0x14001b078
   140008935:	lea    r8,[rip+0x11594]        # 0x140019ed0
   14000893c:	mov    rdx,r13
   14000893f:	lea    rcx,[rsp+0x68]
   140008944:	call   0x14000f3ac
   140008949:	mov    rdx,rax
   14000894c:	lea    rcx,[rbp+0x10]
   140008950:	call   0x1400038ec
   140008955:	mov    DWORD PTR [rsp+0x20],eax
   140008959:	lea    r9,[rip+0x12760]        # 0x14001b0c0
   140008960:	mov    r8d,eax
   140008963:	lea    rcx,[rbp+0x10]
   140008967:	call   0x1400106b0
   14000896c:	int3
   14000896d:	int3
   14000896e:	int3
   14000896f:	int3
   140008970:	int3
   140008971:	int3
   140008972:	int3
   140008973:	int3
   140008974:	mov    rax,rsp
   140008977:	push   rbp
   140008978:	push   r12
   14000897a:	push   r13
   14000897c:	push   r14
   14000897e:	push   r15
   140008980:	lea    rbp,[rax-0x168]
   140008987:	sub    rsp,0x240
   14000898e:	mov    QWORD PTR [rbp+0x90],0xfffffffffffffffe
   140008999:	mov    QWORD PTR [rax+0x10],rbx
   14000899d:	mov    QWORD PTR [rax+0x18],rsi
   1400089a1:	mov    QWORD PTR [rax+0x20],rdi
   1400089a5:	mov    rax,QWORD PTR [rip+0x1b76c]        # 0x140024118
   1400089ac:	xor    rax,rsp
   1400089af:	mov    QWORD PTR [rbp+0x130],rax
   1400089b6:	mov    rbx,rcx
   1400089b9:	lea    r15,[rip+0x11530]        # 0x140019ef0
   1400089c0:	mov    QWORD PTR [rsp+0x70],r15
   1400089c5:	lea    r12,[rip+0x12744]        # 0x14001b110
   1400089cc:	mov    QWORD PTR [rsp+0x78],r12
   1400089d1:	lea    r13,[rip+0x114f8]        # 0x140019ed0
   1400089d8:	mov    QWORD PTR [rbp-0x80],r13
   1400089dc:	mov    DWORD PTR [rbp-0x78],0x54d
   1400089e3:	mov    edi,0x7
   1400089e8:	mov    DWORD PTR [rbp-0x74],edi
   1400089eb:	mov    DWORD PTR [rbp-0x70],0xff
   1400089f2:	xor    r14d,r14d
   1400089f5:	mov    DWORD PTR [rbp+0x10],0x1000000
   1400089fc:	xor    edx,edx
   1400089fe:	lea    r8d,[rdi+0x71]
   140008a02:	lea    rcx,[rbp-0x68]
   140008a06:	call   0x140015692
   140008a0b:	lea    rdx,[rsp+0x70]
   140008a10:	lea    rcx,[rbp+0x20]
   140008a14:	call   0x14000f85c
   140008a19:	nop
   140008a1a:	lea    edx,[rdi-0x3]
   140008a1d:	mov    rcx,rbx
   140008a20:	call   0x14000b754
   140008a25:	mov    esi,eax
   140008a27:	movups xmm0,XMMWORD PTR [rip+0xf982]        # 0x1400183b0
   140008a2e:	movdqu XMMWORD PTR [rbp+0xa0],xmm0
   140008a36:	lea    edx,[rdi+0x5]
   140008a39:	mov    rcx,rbx
   140008a3c:	call   0x1400038f8
   140008a41:	test   rax,rax
   140008a44:	je     0x140008a68
   140008a46:	lea    edx,[rdi+0x5]
   140008a49:	mov    rcx,rbx
   140008a4c:	call   0x1400038f8
   140008a51:	mov    rdx,rax
   140008a54:	lea    r8,[rbp+0xa0]
   140008a5b:	call   0x14000c630
   140008a60:	test   al,al
   140008a62:	je     0x140008e0b
   140008a68:	mov    eax,DWORD PTR [rip+0x1bc9e]        # 0x14002470c
   140008a6e:	and    eax,0xfffffff8
   140008a71:	neg    eax
   140008a73:	sbb    edi,edi
   140008a75:	and    edi,0xffffffe2
   140008a78:	mov    edx,0x9
   140008a7d:	mov    rcx,rbx
   140008a80:	call   0x14000b754
   140008a85:	mov    QWORD PTR [rsp+0x48],r14
   140008a8a:	movups xmm0,XMMWORD PTR [rip+0x105df]        # 0x140019070
   140008a91:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   140008a97:	movups xmm1,XMMWORD PTR [rip+0x105c2]        # 0x140019060
   140008a9e:	movdqu XMMWORD PTR [rsp+0x60],xmm1
   140008aa4:	mov    QWORD PTR [rsp+0x70],r15
   140008aa9:	mov    QWORD PTR [rsp+0x78],r12
   140008aae:	mov    QWORD PTR [rbp-0x80],r13
   140008ab2:	mov    DWORD PTR [rbp-0x78],0x565
   140008ab9:	mov    DWORD PTR [rbp-0x74],0x7
   140008ac0:	mov    DWORD PTR [rbp-0x70],0xff
   140008ac7:	mov    DWORD PTR [rbp+0x10],0x1000000
   140008ace:	xor    edx,edx
   140008ad0:	lea    r8d,[rdx+0x78]
   140008ad4:	lea    rcx,[rbp-0x68]
   140008ad8:	call   0x140015692
   140008add:	lea    rax,[rsp+0x48]
   140008ae2:	mov    QWORD PTR [rsp+0x30],rax
   140008ae7:	lea    rax,[rsp+0x50]
   140008aec:	mov    QWORD PTR [rsp+0x28],rax
   140008af1:	lea    r9,[rip+0xfe50]        # 0x140018948
   140008af8:	lea    r8,[rsp+0x60]
   140008afd:	lea    rdx,[rsp+0x70]
   140008b02:	lea    rcx,[rbp+0x20]
   140008b06:	call   0x140011460
   140008b0b:	cmp    DWORD PTR [rbp+0x28],r14d
   140008b0f:	jl     0x140008e44
   140008b15:	mov    rcx,QWORD PTR [rsp+0x48]
   140008b1a:	mov    rax,QWORD PTR [rcx]
   140008b1d:	lea    edx,[rdi+0x1d]
   140008b20:	mov    rax,QWORD PTR [rax+0x18]
   140008b24:	call   QWORD PTR [rip+0xf76e]        # 0x140018298
   140008b2a:	mov    DWORD PTR [rbp+0x28],eax
   140008b2d:	test   eax,eax
   140008b2f:	js     0x140008e8b
   140008b35:	movaps xmm0,XMMWORD PTR [rbp+0xa0]
   140008b3c:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   140008b42:	mov    rcx,QWORD PTR [rsp+0x48]
   140008b47:	mov    rax,QWORD PTR [rcx]
   140008b4a:	lea    r8,[rbp+0xb0]
   140008b51:	lea    rdx,[rsp+0x60]
   140008b56:	mov    rax,QWORD PTR [rax+0x38]
   140008b5a:	call   QWORD PTR [rip+0xf738]        # 0x140018298
   140008b60:	mov    DWORD PTR [rbp+0x28],eax
   140008b63:	lea    rcx,[rip+0xe656]        # 0x1400171c0
   140008b6a:	mov    QWORD PTR [rsp+0x60],rcx
   140008b6f:	lea    rcx,[rbp+0xb0]
   140008b76:	mov    QWORD PTR [rsp+0x68],rcx
   140008b7b:	test   eax,eax
   140008b7d:	jns    0x140008bc1
   140008b7f:	cmp    eax,0x80042308
   140008b84:	jne    0x140008ed2
   140008b8a:	mov    edx,0xc
   140008b8f:	mov    rcx,rbx
   140008b92:	call   0x1400038f8
   140008b97:	mov    r8,rax
   140008b9a:	mov    edx,0x4000275c
   140008b9f:	mov    rcx,rbx
   140008ba2:	call   0x14000d524
   140008ba7:	nop
   140008ba8:	lea    rcx,[rbp+0xb0]
   140008baf:	rex.W call QWORD PTR [rip+0xf41a]        # 0x140017fd0
   140008bb6:	nop    DWORD PTR [rax+rax*1+0x0]
   140008bbb:	nop
   140008bbc:	jmp    0x140008d72
   140008bc1:	xor    r8d,r8d
   140008bc4:	mov    edx,0x40002776
   140008bc9:	mov    rcx,rbx
   140008bcc:	call   0x14000d788
   140008bd1:	test   eax,eax
   140008bd3:	jne    0x140008bee
   140008bd5:	lea    rcx,[rbp+0xb0]
   140008bdc:	rex.W call QWORD PTR [rip+0xf3ed]        # 0x140017fd0
   140008be3:	nop    DWORD PTR [rax+rax*1+0x0]
   140008be8:	nop
   140008be9:	jmp    0x140008d72
   140008bee:	mov    BYTE PTR [rsp+0x40],r14b
   140008bf3:	lea    rdx,[rsp+0x40]
   140008bf8:	mov    rcx,QWORD PTR [rbp+0xe0]
   140008bff:	rex.W call QWORD PTR [rip+0xf3d2]        # 0x140017fd8
   140008c06:	nop    DWORD PTR [rax+rax*1+0x0]
   140008c0b:	mov    DWORD PTR [rbp+0x28],eax
   140008c0e:	test   eax,eax
   140008c10:	js     0x140008c40
   140008c12:	cmp    BYTE PTR [rsp+0x40],r14b
   140008c17:	je     0x140008c40
   140008c19:	mov    edx,0x40002774
   140008c1e:	mov    rcx,rbx
   140008c21:	call   0x14000d524
   140008c26:	nop
   140008c27:	lea    rcx,[rbp+0xb0]
   140008c2e:	rex.W call QWORD PTR [rip+0xf39b]        # 0x140017fd0
   140008c35:	nop    DWORD PTR [rax+rax*1+0x0]
   140008c3a:	nop
   140008c3b:	jmp    0x140008d72
   140008c40:	movaps xmm0,XMMWORD PTR [rbp+0xa0]
   140008c47:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   140008c4d:	mov    rcx,QWORD PTR [rsp+0x48]
   140008c52:	mov    rax,QWORD PTR [rcx]
   140008c55:	mov    r8d,esi
   140008c58:	lea    rdx,[rsp+0x50]
   140008c5d:	mov    rax,QWORD PTR [rax+0x68]
   140008c61:	call   QWORD PTR [rip+0xf631]        # 0x140018298
   140008c67:	mov    DWORD PTR [rbp+0x28],eax
   140008c6a:	test   eax,eax
   140008c6c:	jns    0x140008d3c
   140008c72:	cmp    eax,0x80042308
   140008c77:	je     0x140008d08
   140008c7d:	cmp    eax,0x8004230c
   140008c82:	je     0x140008ce4
   140008c84:	cmp    eax,0x8004231d
   140008c89:	je     0x140008cbd
   140008c8b:	cmp    eax,0x80042325
   140008c90:	jne    0x140008dc4
   140008c96:	mov    edx,0x40002773
   140008c9b:	mov    rcx,rbx
   140008c9e:	call   0x14000d524
   140008ca3:	nop
   140008ca4:	lea    rcx,[rbp+0xb0]
   140008cab:	rex.W call QWORD PTR [rip+0xf31e]        # 0x140017fd0
   140008cb2:	nop    DWORD PTR [rax+rax*1+0x0]
   140008cb7:	nop
   140008cb8:	jmp    0x140008d72
   140008cbd:	mov    edx,0x40002775
   140008cc2:	mov    rcx,rbx
   140008cc5:	call   0x14000d524
   140008cca:	nop
   140008ccb:	lea    rcx,[rbp+0xb0]
   140008cd2:	rex.W call QWORD PTR [rip+0xf2f7]        # 0x140017fd0
   140008cd9:	nop    DWORD PTR [rax+rax*1+0x0]
   140008cde:	nop
   140008cdf:	jmp    0x140008d72
   140008ce4:	mov    edx,0x40002774
   140008ce9:	mov    rcx,rbx
   140008cec:	call   0x14000d524
   140008cf1:	nop
   140008cf2:	lea    rcx,[rbp+0xb0]
   140008cf9:	rex.W call QWORD PTR [rip+0xf2d0]        # 0x140017fd0
   140008d00:	nop    DWORD PTR [rax+rax*1+0x0]
   140008d05:	nop
   140008d06:	jmp    0x140008d72
   140008d08:	mov    edx,0xc
   140008d0d:	mov    rcx,rbx
   140008d10:	call   0x1400038f8
   140008d15:	mov    r8,rax
   140008d18:	mov    edx,0x4000275c
   140008d1d:	mov    rcx,rbx
   140008d20:	call   0x14000d524
   140008d25:	nop
   140008d26:	lea    rcx,[rbp+0xb0]
   140008d2d:	rex.W call QWORD PTR [rip+0xf29c]        # 0x140017fd0
   140008d34:	nop    DWORD PTR [rax+rax*1+0x0]
   140008d39:	nop
   140008d3a:	jmp    0x140008d72
   140008d3c:	mov    r8,QWORD PTR [rsp+0x48]
   140008d41:	mov    rdx,QWORD PTR [rbp+0xe0]
   140008d48:	call   0x140009444
   140008d4d:	mov    edx,0x40002770
   140008d52:	mov    rcx,rbx
   140008d55:	call   0x14000c6f4
   140008d5a:	mov    DWORD PTR [rbx+0x48],r14d
   140008d5e:	lea    rcx,[rbp+0xb0]
   140008d65:	rex.W call QWORD PTR [rip+0xf264]        # 0x140017fd0
   140008d6c:	nop    DWORD PTR [rax+rax*1+0x0]
   140008d71:	nop
   140008d72:	mov    rcx,QWORD PTR [rsp+0x48]
   140008d77:	test   rcx,rcx
   140008d7a:	je     0x140008d8a
   140008d7c:	mov    rax,QWORD PTR [rcx]
   140008d7f:	mov    rax,QWORD PTR [rax+0x10]
   140008d83:	call   QWORD PTR [rip+0xf50f]        # 0x140018298
   140008d89:	nop
   140008d8a:	lea    rcx,[rbp+0x20]
   140008d8e:	call   0x14000f958
   140008d93:	mov    rcx,QWORD PTR [rbp+0x130]
   140008d9a:	xor    rcx,rsp
   140008d9d:	call   0x1400143c0
   140008da2:	lea    r11,[rsp+0x240]
   140008daa:	mov    rbx,QWORD PTR [r11+0x38]
   140008dae:	mov    rsi,QWORD PTR [r11+0x40]
   140008db2:	mov    rdi,QWORD PTR [r11+0x48]
   140008db6:	mov    rsp,r11
   140008db9:	pop    r15
   140008dbb:	pop    r14
   140008dbd:	pop    r13
   140008dbf:	pop    r12
   140008dc1:	pop    rbp
   140008dc2:	ret
   140008dc3:	int3
   140008dc4:	mov    DWORD PTR [rsp+0x28],0x7
   140008dcc:	mov    DWORD PTR [rsp+0x20],0x59f
   140008dd4:	mov    r9,r12
   140008dd7:	mov    r8,r13
   140008dda:	mov    rdx,r15
   140008ddd:	lea    rcx,[rsp+0x70]
   140008de2:	call   0x14000f3ac
   140008de7:	mov    rdx,rax
   140008dea:	lea    rcx,[rbp+0x20]
   140008dee:	call   0x1400038ec
   140008df3:	mov    DWORD PTR [rsp+0x20],eax
   140008df7:	lea    r9,[rip+0x12482]        # 0x14001b280
   140008dfe:	mov    r8d,eax
   140008e01:	lea    rcx,[rbp+0x20]
   140008e05:	call   0x1400106b0
   140008e0a:	nop
   140008e0b:	mov    DWORD PTR [rsp+0x28],edi
   140008e0f:	mov    DWORD PTR [rsp+0x20],0x556
   140008e17:	mov    r9,r12
   140008e1a:	mov    r8,r13
   140008e1d:	mov    rdx,r15
   140008e20:	lea    rcx,[rsp+0x70]
   140008e25:	call   0x14000f3ac
   140008e2a:	lea    r9,[rip+0x1231f]        # 0x14001b150
   140008e31:	mov    r8d,0x1004
   140008e37:	mov    rdx,rax
   140008e3a:	lea    rcx,[rbp+0x20]
   140008e3e:	call   0x1400106b0
   140008e43:	nop
   140008e44:	mov    DWORD PTR [rsp+0x28],0x7
   140008e4c:	mov    DWORD PTR [rsp+0x20],0x56c
   140008e54:	mov    r9,r12
   140008e57:	mov    r8,r13
   140008e5a:	mov    rdx,r15
   140008e5d:	lea    rcx,[rsp+0x70]
   140008e62:	call   0x14000f3ac
   140008e67:	mov    rdx,rax
   140008e6a:	lea    rcx,[rbp+0x20]
   140008e6e:	call   0x1400038ec
   140008e73:	mov    DWORD PTR [rsp+0x20],eax
   140008e77:	lea    r9,[rip+0xfae2]        # 0x140018960
   140008e7e:	mov    r8d,eax
   140008e81:	lea    rcx,[rbp+0x20]
   140008e85:	call   0x1400106b0
   140008e8a:	int3
   140008e8b:	mov    DWORD PTR [rsp+0x28],0x7
   140008e93:	mov    DWORD PTR [rsp+0x20],0x570
   140008e9b:	mov    r9,r12
   140008e9e:	mov    r8,r13
   140008ea1:	mov    rdx,r15
   140008ea4:	lea    rcx,[rsp+0x70]
   140008ea9:	call   0x14000f3ac
   140008eae:	mov    rdx,rax
   140008eb1:	lea    rcx,[rbp+0x20]
   140008eb5:	call   0x1400038ec
   140008eba:	mov    DWORD PTR [rsp+0x20],eax
   140008ebe:	lea    r9,[rip+0x122fb]        # 0x14001b1c0
   140008ec5:	mov    r8d,eax
   140008ec8:	lea    rcx,[rbp+0x20]
   140008ecc:	call   0x1400106b0
   140008ed1:	nop
   140008ed2:	mov    DWORD PTR [rsp+0x28],0x7
   140008eda:	mov    DWORD PTR [rsp+0x20],0x57e
   140008ee2:	mov    r9,r12
   140008ee5:	mov    r8,r13
   140008ee8:	mov    rdx,r15
   140008eeb:	lea    rcx,[rsp+0x70]
   140008ef0:	call   0x14000f3ac
   140008ef5:	mov    rdx,rax
   140008ef8:	lea    rcx,[rbp+0x20]
   140008efc:	call   0x1400038ec
   140008f01:	mov    DWORD PTR [rsp+0x20],eax
   140008f05:	lea    r9,[rip+0x12314]        # 0x14001b220
   140008f0c:	mov    r8d,eax
   140008f0f:	lea    rcx,[rbp+0x20]
   140008f13:	call   0x1400106b0
   140008f18:	int3
   140008f19:	int3
   140008f1a:	int3
   140008f1b:	int3
   140008f1c:	int3
   140008f1d:	int3
   140008f1e:	int3
   140008f1f:	int3
   140008f20:	mov    rax,rsp
   140008f23:	push   rbp
   140008f24:	push   rdi
   140008f25:	push   r12
   140008f27:	push   r13
   140008f29:	push   r15
   140008f2b:	lea    rbp,[rax-0x2d8]
   140008f32:	sub    rsp,0x3b0
   140008f39:	mov    QWORD PTR [rbp+0x18],0xfffffffffffffffe
   140008f41:	mov    QWORD PTR [rax+0x10],rbx
   140008f45:	mov    QWORD PTR [rax+0x18],rsi
   140008f49:	mov    rax,QWORD PTR [rip+0x1b1c8]        # 0x140024118
   140008f50:	xor    rax,rsp
   140008f53:	mov    QWORD PTR [rbp+0x2a0],rax
   140008f5a:	mov    rdi,rcx
   140008f5d:	lea    r12,[rip+0x10f8c]        # 0x140019ef0
   140008f64:	mov    QWORD PTR [rsp+0x70],r12
   140008f69:	lea    r13,[rip+0x12368]        # 0x14001b2d8
   140008f70:	mov    QWORD PTR [rsp+0x78],r13
   140008f75:	lea    rax,[rip+0x10f54]        # 0x140019ed0
   140008f7c:	mov    QWORD PTR [rbp-0x80],rax
   140008f80:	mov    DWORD PTR [rbp-0x78],0x5b1
   140008f87:	mov    DWORD PTR [rbp-0x74],0x7
   140008f8e:	mov    DWORD PTR [rbp-0x70],0xff
   140008f95:	xor    r15d,r15d
   140008f98:	mov    DWORD PTR [rbp+0x10],0x1000000
   140008f9f:	lea    esi,[r15+0x78]
   140008fa3:	mov    r8d,esi
   140008fa6:	xor    edx,edx
   140008fa8:	lea    rcx,[rbp-0x68]
   140008fac:	call   0x140015692
   140008fb1:	lea    rdx,[rsp+0x70]
   140008fb6:	lea    rcx,[rbp+0x20]
   140008fba:	call   0x14000f85c
   140008fbf:	nop
   140008fc0:	lea    edx,[rsi-0x75]
   140008fc3:	mov    rcx,rdi
   140008fc6:	call   0x1400038f8
   140008fcb:	mov    rbx,rax
   140008fce:	xor    edx,edx
   140008fd0:	mov    rcx,rdi
   140008fd3:	call   0x14000b754
   140008fd8:	mov    rcx,QWORD PTR [rdi]
   140008fdb:	mov    rdx,QWORD PTR [rcx]
   140008fde:	cmp    eax,0x1
   140008fe1:	sete   r8b
   140008fe5:	mov    rax,QWORD PTR [rdx+0x40]
   140008fe9:	lea    r9,[rbp+0x20]
   140008fed:	mov    rdx,rbx
   140008ff0:	call   QWORD PTR [rip+0xf2a2]        # 0x140018298
   140008ff6:	mov    QWORD PTR [rsp+0x40],r15
   140008ffb:	movups xmm0,XMMWORD PTR [rip+0x1006e]        # 0x140019070
   140009002:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   140009008:	movups xmm1,XMMWORD PTR [rip+0x10051]        # 0x140019060
   14000900f:	movdqu XMMWORD PTR [rsp+0x60],xmm1
   140009015:	mov    QWORD PTR [rsp+0x70],r12
   14000901a:	mov    QWORD PTR [rsp+0x78],r13
   14000901f:	lea    rax,[rip+0x10eaa]        # 0x140019ed0
   140009026:	mov    QWORD PTR [rbp-0x80],rax
   14000902a:	mov    DWORD PTR [rbp-0x78],0x5be
   140009031:	mov    DWORD PTR [rbp-0x74],0x7
   140009038:	mov    DWORD PTR [rbp-0x70],0xff
   14000903f:	mov    DWORD PTR [rbp+0x10],0x1000000
   140009046:	mov    r8d,esi
   140009049:	xor    edx,edx
   14000904b:	lea    rcx,[rbp-0x68]
   14000904f:	call   0x140015692
   140009054:	lea    rax,[rsp+0x40]
   140009059:	mov    QWORD PTR [rsp+0x30],rax
   14000905e:	lea    rax,[rsp+0x50]
   140009063:	mov    QWORD PTR [rsp+0x28],rax
   140009068:	lea    r9,[rip+0xf8d9]        # 0x140018948
   14000906f:	lea    r8,[rsp+0x60]
   140009074:	lea    rdx,[rsp+0x70]
   140009079:	lea    rcx,[rbp+0x20]
   14000907d:	call   0x140011460
   140009082:	cmp    DWORD PTR [rbp+0x28],r15d
   140009086:	jl     0x14000920b
   14000908c:	mov    rcx,QWORD PTR [rsp+0x40]
   140009091:	mov    rax,QWORD PTR [rcx]
   140009094:	or     edx,0xffffffff
   140009097:	mov    rax,QWORD PTR [rax+0x18]
   14000909b:	call   QWORD PTR [rip+0xf1f7]        # 0x140018298
   1400090a1:	mov    DWORD PTR [rbp+0x28],eax
   1400090a4:	test   eax,eax
   1400090a6:	js     0x140009256
   1400090ac:	test   rbx,rbx
   1400090af:	je     0x1400090ca
   1400090b1:	mov    r8,QWORD PTR [rsp+0x40]
   1400090b6:	mov    rdx,rbx
   1400090b9:	mov    rcx,rdi
   1400090bc:	call   0x1400092e4
   1400090c1:	mov    DWORD PTR [rdi+0x48],r15d
   1400090c5:	jmp    0x140009172
   1400090ca:	mov    esi,0x104
   1400090cf:	mov    edx,esi
   1400090d1:	lea    rcx,[rbp+0x90]
   1400090d8:	rex.W call QWORD PTR [rip+0xede1]        # 0x140017ec0
   1400090df:	nop    DWORD PTR [rax+rax*1+0x0]
   1400090e4:	mov    rbx,rax
   1400090e7:	lea    rax,[rip+0xe0da]        # 0x1400171c8
   1400090ee:	mov    QWORD PTR [rsp+0x60],rax
   1400090f3:	mov    QWORD PTR [rsp+0x68],rbx
   1400090f8:	cmp    rbx,0xffffffffffffffff
   1400090fc:	je     0x1400092a1
   140009102:	lea    rcx,[rbp+0x90]
   140009109:	rex.W call QWORD PTR [rip+0xeda8]        # 0x140017eb8
   140009110:	nop    DWORD PTR [rax+rax*1+0x0]
   140009115:	cmp    eax,0x3
   140009118:	jne    0x14000912e
   14000911a:	mov    r8,QWORD PTR [rsp+0x40]
   14000911f:	lea    rdx,[rbp+0x90]
   140009126:	mov    rcx,rdi
   140009129:	call   0x1400092e4
   14000912e:	mov    r8d,esi
   140009131:	lea    rdx,[rbp+0x90]
   140009138:	mov    rcx,rbx
   14000913b:	rex.W call QWORD PTR [rip+0xed6e]        # 0x140017eb0
   140009142:	nop    DWORD PTR [rax+rax*1+0x0]
   140009147:	test   eax,eax
   140009149:	jne    0x140009102
   14000914b:	rex.W call QWORD PTR [rip+0xee26]        # 0x140017f78
   140009152:	nop    DWORD PTR [rax+rax*1+0x0]
   140009157:	mov    esi,eax
   140009159:	cmp    eax,0x12
   14000915c:	jne    0x1400091bf
   14000915e:	mov    DWORD PTR [rdi+0x48],r15d
   140009162:	mov    rcx,rbx
   140009165:	rex.W call QWORD PTR [rip+0xed0c]        # 0x140017e78
   14000916c:	nop    DWORD PTR [rax+rax*1+0x0]
   140009171:	nop
   140009172:	mov    rcx,QWORD PTR [rsp+0x40]
   140009177:	test   rcx,rcx
   14000917a:	je     0x14000918a
   14000917c:	mov    rax,QWORD PTR [rcx]
   14000917f:	mov    rax,QWORD PTR [rax+0x10]
   140009183:	call   QWORD PTR [rip+0xf10f]        # 0x140018298
   140009189:	nop
   14000918a:	lea    rcx,[rbp+0x20]
   14000918e:	call   0x14000f958
   140009193:	mov    rcx,QWORD PTR [rbp+0x2a0]
   14000919a:	xor    rcx,rsp
   14000919d:	call   0x1400143c0
   1400091a2:	lea    r11,[rsp+0x3b0]
   1400091aa:	mov    rbx,QWORD PTR [r11+0x38]
   1400091ae:	mov    rsi,QWORD PTR [r11+0x40]
   1400091b2:	mov    rsp,r11
   1400091b5:	pop    r15
   1400091b7:	pop    r13
   1400091b9:	pop    r12
   1400091bb:	pop    rdi
   1400091bc:	pop    rbp
   1400091bd:	ret
   1400091be:	int3
   1400091bf:	mov    DWORD PTR [rsp+0x28],0x7
   1400091c7:	mov    DWORD PTR [rsp+0x20],0x5e1
   1400091cf:	mov    r9,r13
   1400091d2:	lea    r8,[rip+0x10cf7]        # 0x140019ed0
   1400091d9:	mov    rdx,r12
   1400091dc:	lea    rcx,[rsp+0x70]
   1400091e1:	call   0x14000f3ac
   1400091e6:	movzx  r8d,si
   1400091ea:	or     r8d,0x80070000
   1400091f1:	test   esi,esi
   1400091f3:	cmovle r8d,esi
   1400091f7:	lea    r9,[rip+0x12132]        # 0x14001b330
   1400091fe:	mov    rdx,rax
   140009201:	lea    rcx,[rbp+0x20]
   140009205:	call   0x140010ee4
   14000920a:	nop
   14000920b:	mov    DWORD PTR [rsp+0x28],0x7
   140009213:	mov    DWORD PTR [rsp+0x20],0x5c5
   14000921b:	mov    r9,r13
   14000921e:	lea    r8,[rip+0x10cab]        # 0x140019ed0
   140009225:	mov    rdx,r12
   140009228:	lea    rcx,[rsp+0x70]
   14000922d:	call   0x14000f3ac
   140009232:	mov    rdx,rax
   140009235:	lea    rcx,[rbp+0x20]
   140009239:	call   0x1400038ec
   14000923e:	mov    DWORD PTR [rsp+0x20],eax
   140009242:	lea    r9,[rip+0xf717]        # 0x140018960
   140009249:	mov    r8d,eax
   14000924c:	lea    rcx,[rbp+0x20]
   140009250:	call   0x1400106b0
   140009255:	int3
   140009256:	mov    DWORD PTR [rsp+0x28],0x7
   14000925e:	mov    DWORD PTR [rsp+0x20],0x5c9
   140009266:	mov    r9,r13
   140009269:	lea    r8,[rip+0x10c60]        # 0x140019ed0
   140009270:	mov    rdx,r12
   140009273:	lea    rcx,[rsp+0x70]
   140009278:	call   0x14000f3ac
   14000927d:	mov    rdx,rax
   140009280:	lea    rcx,[rbp+0x20]
   140009284:	call   0x1400038ec
   140009289:	mov    DWORD PTR [rsp+0x20],eax
   14000928d:	lea    r9,[rip+0x11f2c]        # 0x14001b1c0
   140009294:	mov    r8d,eax
   140009297:	lea    rcx,[rbp+0x20]
   14000929b:	call   0x1400106b0
   1400092a0:	nop
   1400092a1:	mov    DWORD PTR [rsp+0x28],0x7
   1400092a9:	mov    DWORD PTR [rsp+0x20],0x5d5
   1400092b1:	mov    r9,r13
   1400092b4:	lea    r8,[rip+0x10c15]        # 0x140019ed0
   1400092bb:	mov    rdx,r12
   1400092be:	lea    rcx,[rsp+0x70]
   1400092c3:	call   0x14000f3ac
   1400092c8:	lea    r8,[rip+0x12041]        # 0x14001b310
   1400092cf:	mov    rdx,rax
   1400092d2:	lea    rcx,[rbp+0x20]
   1400092d6:	call   0x140010ccc
   1400092db:	int3
   1400092dc:	int3
   1400092dd:	int3
   1400092de:	int3
   1400092df:	int3
   1400092e0:	int3
   1400092e1:	int3
   1400092e2:	int3
   1400092e3:	int3
   1400092e4:	mov    rax,rsp
   1400092e7:	push   rbp
   1400092e8:	push   rdi
   1400092e9:	push   r14
   1400092eb:	lea    rbp,[rax-0x68]
   1400092ef:	sub    rsp,0x150
   1400092f6:	mov    QWORD PTR [rsp+0x28],0xfffffffffffffffe
   1400092ff:	mov    QWORD PTR [rax+0x8],rbx
   140009303:	mov    QWORD PTR [rax+0x10],rsi
   140009307:	mov    rbx,r8
   14000930a:	mov    rdi,rdx
   14000930d:	mov    rsi,rcx
   140009310:	lea    rax,[rip+0x10bd9]        # 0x140019ef0
   140009317:	mov    QWORD PTR [rsp+0x30],rax
   14000931c:	lea    rax,[rip+0x1202d]        # 0x14001b350
   140009323:	mov    QWORD PTR [rsp+0x38],rax
   140009328:	lea    rax,[rip+0x10ba1]        # 0x140019ed0
   14000932f:	mov    QWORD PTR [rsp+0x40],rax
   140009334:	mov    DWORD PTR [rsp+0x48],0x5e8
   14000933c:	mov    DWORD PTR [rsp+0x4c],0x7
   140009344:	mov    DWORD PTR [rsp+0x50],0xff
   14000934c:	xor    r14d,r14d
   14000934f:	mov    DWORD PTR [rbp-0x30],0x1000000
   140009356:	xor    edx,edx
   140009358:	lea    r8d,[r14+0x78]
   14000935c:	lea    rcx,[rsp+0x58]
   140009361:	call   0x140015692
   140009366:	lea    rdx,[rsp+0x30]
   14000936b:	lea    rcx,[rbp-0x20]
   14000936f:	call   0x14000f85c
   140009374:	nop
   140009375:	mov    QWORD PTR [rsp+0x20],r14
   14000937a:	mov    rax,QWORD PTR [rbx]
   14000937d:	lea    r8,[rsp+0x20]
   140009382:	mov    rdx,rdi
   140009385:	mov    rcx,rbx
   140009388:	mov    rax,QWORD PTR [rax+0x70]
   14000938c:	call   QWORD PTR [rip+0xef06]        # 0x140018298
   140009392:	mov    DWORD PTR [rbp-0x18],eax
   140009395:	test   eax,eax
   140009397:	js     0x140009401
   140009399:	mov    DWORD PTR [rbp+0x80],r14d
   1400093a0:	mov    DWORD PTR [rbp+0x88],r14d
   1400093a7:	mov    rcx,QWORD PTR [rsp+0x20]
   1400093ac:	mov    rax,QWORD PTR [rcx]
   1400093af:	lea    r8,[rbp+0x88]
   1400093b6:	lea    rdx,[rbp+0x80]
   1400093bd:	mov    rax,QWORD PTR [rax+0x28]
   1400093c1:	call   QWORD PTR [rip+0xeed1]        # 0x140018298
   1400093c7:	mov    DWORD PTR [rbp-0x18],eax
   1400093ca:	test   eax,eax
   1400093cc:	js     0x1400093f0
   1400093ce:	cmp    DWORD PTR [rbp+0x80],r14d
   1400093d5:	jl     0x1400093f0
   1400093d7:	mov    r9d,DWORD PTR [rbp+0x88]
   1400093de:	mov    r8,rdi
   1400093e1:	mov    edx,0x40002771
   1400093e6:	mov    rcx,rsi
   1400093e9:	call   0x14000c6f4
   1400093ee:	jmp    0x140009401
   1400093f0:	mov    r8,rdi
   1400093f3:	mov    edx,0x40002772
   1400093f8:	mov    rcx,rsi
   1400093fb:	call   0x14000c6f4
   140009400:	nop
   140009401:	mov    rcx,QWORD PTR [rsp+0x20]
   140009406:	test   rcx,rcx
   140009409:	je     0x140009419
   14000940b:	mov    rax,QWORD PTR [rcx]
   14000940e:	mov    rax,QWORD PTR [rax+0x10]
   140009412:	call   QWORD PTR [rip+0xee80]        # 0x140018298
   140009418:	nop
   140009419:	lea    rcx,[rbp-0x20]
   14000941d:	call   0x14000f958
   140009422:	lea    r11,[rsp+0x150]
   14000942a:	mov    rbx,QWORD PTR [r11+0x20]
   14000942e:	mov    rsi,QWORD PTR [r11+0x28]
   140009432:	mov    rsp,r11
   140009435:	pop    r14
   140009437:	pop    rdi
   140009438:	pop    rbp
   140009439:	ret
   14000943a:	int3
   14000943b:	int3
   14000943c:	int3
   14000943d:	int3
   14000943e:	int3
   14000943f:	int3
   140009440:	int3
   140009441:	int3
   140009442:	int3
   140009443:	int3
   140009444:	mov    rax,rsp
   140009447:	push   rbp
   140009448:	push   rdi
   140009449:	push   r12
   14000944b:	push   r13
   14000944d:	push   r15
   14000944f:	lea    rbp,[rax-0x128]
   140009456:	sub    rsp,0x200
   14000945d:	mov    QWORD PTR [rsp+0x60],0xfffffffffffffffe
   140009466:	mov    QWORD PTR [rax+0x8],rbx
   14000946a:	mov    QWORD PTR [rax+0x20],rsi
   14000946e:	mov    rax,QWORD PTR [rip+0x1aca3]        # 0x140024118
   140009475:	xor    rax,rsp
   140009478:	mov    QWORD PTR [rbp+0xf0],rax
   14000947f:	mov    rbx,r8
   140009482:	mov    rdi,rdx
   140009485:	lea    r15,[rip+0x10a64]        # 0x140019ef0
   14000948c:	mov    QWORD PTR [rsp+0x68],r15
   140009491:	lea    r12,[rip+0x11ef8]        # 0x14001b390
   140009498:	mov    QWORD PTR [rsp+0x70],r12
   14000949d:	lea    r13,[rip+0x10a2c]        # 0x140019ed0
   1400094a4:	mov    QWORD PTR [rsp+0x78],r13
   1400094a9:	mov    DWORD PTR [rbp-0x80],0x5fa
   1400094b0:	mov    DWORD PTR [rbp-0x7c],0x7
   1400094b7:	mov    DWORD PTR [rbp-0x78],0xff
   1400094be:	xor    esi,esi
   1400094c0:	mov    DWORD PTR [rbp+0x8],0x1000000
   1400094c7:	xor    edx,edx
   1400094c9:	lea    r8d,[rsi+0x78]
   1400094cd:	lea    rcx,[rbp-0x70]
   1400094d1:	call   0x140015692
   1400094d6:	lea    rdx,[rsp+0x68]
   1400094db:	lea    rcx,[rbp+0x10]
   1400094df:	call   0x14000f85c
   1400094e4:	nop
   1400094e5:	mov    QWORD PTR [rsp+0x48],rsi
   1400094ea:	mov    rax,QWORD PTR [rbx]
   1400094ed:	lea    r8,[rsp+0x48]
   1400094f2:	mov    rdx,rdi
   1400094f5:	mov    rcx,rbx
   1400094f8:	mov    rax,QWORD PTR [rax+0x70]
   1400094fc:	call   QWORD PTR [rip+0xed96]        # 0x140018298
   140009502:	mov    DWORD PTR [rbp+0x18],eax
   140009505:	cmp    eax,0x80042308
   14000950a:	jne    0x140009511
   14000950c:	jmp    0x140009616
   140009511:	test   eax,eax
   140009513:	js     0x1400096f1
   140009519:	mov    edi,esi
   14000951b:	mov    ecx,0x12c
   140009520:	rex.W call QWORD PTR [rip+0xea09]        # 0x140017f30
   140009527:	nop    DWORD PTR [rax+rax*1+0x0]
   14000952c:	mov    DWORD PTR [rsp+0x40],esi
   140009530:	mov    DWORD PTR [rsp+0x50],esi
   140009534:	mov    rcx,QWORD PTR [rsp+0x48]
   140009539:	mov    rax,QWORD PTR [rcx]
   14000953c:	lea    r8,[rsp+0x40]
   140009541:	lea    rdx,[rsp+0x50]
   140009546:	mov    rax,QWORD PTR [rax+0x28]
   14000954a:	call   QWORD PTR [rip+0xed48]        # 0x140018298
   140009550:	mov    DWORD PTR [rbp+0x18],eax
   140009553:	test   eax,eax
   140009555:	js     0x1400096aa
   14000955b:	mov    ebx,0x64
   140009560:	cmp    DWORD PTR [rsp+0x40],ebx
   140009564:	cmovle ebx,DWORD PTR [rsp+0x40]
   140009569:	mov    DWORD PTR [rsp+0x40],ebx
   14000956d:	cmp    DWORD PTR [rsp+0x50],0x4230a
   140009575:	jne    0x140009586
   140009577:	mov    DWORD PTR [rsp+0x40],0x64
   14000957f:	mov    ebx,0x64
   140009584:	jmp    0x140009594
   140009586:	cmp    DWORD PTR [rsp+0x50],0x42309
   14000958e:	jne    0x140009663
   140009594:	sub    ebx,edi
   140009596:	cmp    ebx,0x2
   140009599:	jl     0x1400095f9
   14000959b:	mov    eax,ebx
   14000959d:	cdq
   14000959e:	sub    eax,edx
   1400095a0:	sar    eax,1
   1400095a2:	movsxd rdx,eax
   1400095a5:	je     0x1400095bc
   1400095a7:	mov    eax,0x2e
   1400095ac:	movzx  eax,ax
   1400095af:	lea    rdi,[rbp+0x80]
   1400095b6:	mov    rcx,rdx
   1400095b9:	rep stos WORD PTR es:[rdi],ax
   1400095bc:	add    rdx,rdx
   1400095bf:	cmp    rdx,0x66
   1400095c3:	jae    0x140009738
   1400095c9:	mov    WORD PTR [rbp+rdx*1+0x80],si
   1400095d1:	lea    rcx,[rbp+0x80]
   1400095d8:	rex.W call QWORD PTR [rip+0xec49]        # 0x140018228
   1400095df:	nop    DWORD PTR [rax+rax*1+0x0]
   1400095e4:	and    ebx,0x80000001
   1400095ea:	jge    0x1400095f3
   1400095ec:	dec    ebx
   1400095ee:	or     ebx,0xfffffffe
   1400095f1:	inc    ebx
   1400095f3:	mov    edi,DWORD PTR [rsp+0x40]
   1400095f7:	sub    edi,ebx
   1400095f9:	cmp    edi,0x64
   1400095fc:	jl     0x14000951b
   140009602:	lea    rcx,[rip+0x12623]        # 0x14001bc2c
   140009609:	rex.W call QWORD PTR [rip+0xec18]        # 0x140018228
   140009610:	nop    DWORD PTR [rax+rax*1+0x0]
   140009615:	nop
   140009616:	mov    rcx,QWORD PTR [rsp+0x48]
   14000961b:	test   rcx,rcx
   14000961e:	je     0x14000962e
   140009620:	mov    rax,QWORD PTR [rcx]
   140009623:	mov    rax,QWORD PTR [rax+0x10]
   140009627:	call   QWORD PTR [rip+0xec6b]        # 0x140018298
   14000962d:	nop
   14000962e:	lea    rcx,[rbp+0x10]
   140009632:	call   0x14000f958
   140009637:	mov    rcx,QWORD PTR [rbp+0xf0]
   14000963e:	xor    rcx,rsp
   140009641:	call   0x1400143c0
   140009646:	lea    r11,[rsp+0x200]
   14000964e:	mov    rbx,QWORD PTR [r11+0x30]
   140009652:	mov    rsi,QWORD PTR [r11+0x48]
   140009656:	mov    rsp,r11
   140009659:	pop    r15
   14000965b:	pop    r13
   14000965d:	pop    r12
   14000965f:	pop    rdi
   140009660:	pop    rbp
   140009661:	ret
   140009662:	int3
   140009663:	mov    DWORD PTR [rsp+0x28],0x7
   14000966b:	mov    DWORD PTR [rsp+0x20],0x616
   140009673:	mov    r9,r12
   140009676:	mov    r8,r13
   140009679:	mov    rdx,r15
   14000967c:	lea    rcx,[rsp+0x68]
   140009681:	call   0x14000f3ac
   140009686:	mov    rdx,rax
   140009689:	lea    rcx,[rbp+0x10]
   14000968d:	call   0x1400038ec
   140009692:	mov    DWORD PTR [rsp+0x20],eax
   140009696:	lea    r9,[rip+0x11e13]        # 0x14001b4b0
   14000969d:	mov    r8d,eax
   1400096a0:	lea    rcx,[rbp+0x10]
   1400096a4:	call   0x1400106b0
   1400096a9:	int3
   1400096aa:	mov    DWORD PTR [rsp+0x28],0x7
   1400096b2:	mov    DWORD PTR [rsp+0x20],0x610
   1400096ba:	mov    r9,r12
   1400096bd:	mov    r8,r13
   1400096c0:	mov    rdx,r15
   1400096c3:	lea    rcx,[rsp+0x68]
   1400096c8:	call   0x14000f3ac
   1400096cd:	mov    rdx,rax
   1400096d0:	lea    rcx,[rbp+0x10]
   1400096d4:	call   0x1400038ec
   1400096d9:	mov    DWORD PTR [rsp+0x20],eax
   1400096dd:	lea    r9,[rip+0x11d6c]        # 0x14001b450
   1400096e4:	mov    r8d,eax
   1400096e7:	lea    rcx,[rbp+0x10]
   1400096eb:	call   0x1400106b0
   1400096f0:	int3
   1400096f1:	mov    DWORD PTR [rsp+0x28],0x7
   1400096f9:	mov    DWORD PTR [rsp+0x20],0x602
   140009701:	mov    r9,r12
   140009704:	mov    r8,r13
   140009707:	mov    rdx,r15
   14000970a:	lea    rcx,[rsp+0x68]
   14000970f:	call   0x14000f3ac
   140009714:	mov    rdx,rax
   140009717:	lea    rcx,[rbp+0x10]
   14000971b:	call   0x1400038ec
   140009720:	mov    DWORD PTR [rsp+0x20],eax
   140009724:	lea    r9,[rip+0x11cb5]        # 0x14001b3e0
   14000972b:	mov    r8d,eax
   14000972e:	lea    rcx,[rbp+0x10]
   140009732:	call   0x1400106b0
   140009737:	int3
   140009738:	call   0x140014638
   14000973d:	int3
   14000973e:	int3
   14000973f:	int3
   140009740:	int3
   140009741:	int3
   140009742:	int3
   140009743:	int3
   140009744:	mov    rax,rsp
   140009747:	push   rbp
   140009748:	push   r12
   14000974a:	push   r13
   14000974c:	push   r14
   14000974e:	push   r15
   140009750:	lea    rbp,[rax-0x118]
   140009757:	sub    rsp,0x1f0
   14000975e:	mov    QWORD PTR [rsp+0x78],0xfffffffffffffffe
   140009767:	mov    QWORD PTR [rax+0x10],rbx
   14000976b:	mov    QWORD PTR [rax+0x18],rsi
   14000976f:	mov    QWORD PTR [rax+0x20],rdi
   140009773:	mov    rax,QWORD PTR [rip+0x1a99e]        # 0x140024118
   14000977a:	xor    rax,rsp
   14000977d:	mov    QWORD PTR [rbp+0xe0],rax
   140009784:	mov    rdi,rcx
   140009787:	lea    rsi,[rip+0x10762]        # 0x140019ef0
   14000978e:	mov    QWORD PTR [rbp-0x10],rsi
   140009792:	lea    rax,[rip+0x11d6f]        # 0x14001b508
   140009799:	mov    QWORD PTR [rbp-0x8],rax
   14000979d:	lea    rax,[rip+0x1072c]        # 0x140019ed0
   1400097a4:	mov    QWORD PTR [rbp+0x0],rax
   1400097a8:	mov    DWORD PTR [rbp+0x8],0x62b
   1400097af:	mov    r13d,0x7
   1400097b5:	mov    DWORD PTR [rbp+0xc],r13d
   1400097b9:	mov    DWORD PTR [rbp+0x10],0xff
   1400097c0:	xor    r12d,r12d
   1400097c3:	mov    DWORD PTR [rbp+0x90],0x1000000
   1400097cd:	xor    edx,edx
   1400097cf:	lea    r8d,[r13+0x71]
   1400097d3:	lea    rcx,[rbp+0x18]
   1400097d7:	call   0x140015692
   1400097dc:	lea    rdx,[rbp-0x10]
   1400097e0:	lea    rcx,[rbp-0x80]
   1400097e4:	call   0x14000f85c
   1400097e9:	nop
   1400097ea:	movups xmm0,XMMWORD PTR [rip+0xebbf]        # 0x1400183b0
   1400097f1:	movdqu XMMWORD PTR [rbp+0xd0],xmm0
   1400097f9:	lea    rdx,[rbp+0xd0]
   140009800:	mov    rcx,rdi
   140009803:	call   0x140001264
   140009808:	lea    edx,[r13-0x4]
   14000980c:	mov    rcx,rdi
   14000980f:	call   0x1400038f8
   140009814:	mov    r15,rax
   140009817:	mov    edx,r13d
   14000981a:	mov    rcx,rdi
   14000981d:	call   0x1400038f8
   140009822:	mov    r14,rax
   140009825:	lea    edx,[r13+0x2]
   140009829:	mov    rcx,rdi
   14000982c:	call   0x14000b754
   140009831:	mov    QWORD PTR [rsp+0x40],r12
   140009836:	movaps xmm0,XMMWORD PTR [rbp+0xd0]
   14000983d:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   140009843:	lea    r8,[rsp+0x40]
   140009848:	lea    rdx,[rsp+0x50]
   14000984d:	mov    rcx,rdi
   140009850:	call   0x140005050
   140009855:	mov    ebx,r12d
   140009858:	mov    QWORD PTR [rsp+0x58],rbx
   14000985d:	lea    rax,[rip+0xd7fc]        # 0x140017060
   140009864:	mov    QWORD PTR [rsp+0x50],rax
   140009869:	test   r14,r14
   14000986c:	jne    0x1400099ba
   140009872:	mov    QWORD PTR [rsp+0x48],r12
   140009877:	mov    rcx,QWORD PTR [rsp+0x40]
   14000987c:	mov    rax,QWORD PTR [rcx]
   14000987f:	lea    r8,[rsp+0x48]
   140009884:	mov    rdx,r15
   140009887:	mov    rax,QWORD PTR [rax+0x30]
   14000988b:	call   QWORD PTR [rip+0xea07]        # 0x140018298
   140009891:	mov    DWORD PTR [rbp-0x78],eax
   140009894:	test   eax,eax
   140009896:	js     0x140009b0c
   14000989c:	cmp    eax,0x1
   14000989f:	jne    0x1400098c9
   1400098a1:	mov    edx,0x40002b5e
   1400098a6:	mov    rcx,rdi
   1400098a9:	call   0x14000d524
   1400098ae:	nop
   1400098af:	mov    rcx,QWORD PTR [rsp+0x48]
   1400098b4:	test   rcx,rcx
   1400098b7:	je     0x1400098c7
   1400098b9:	mov    rax,QWORD PTR [rcx]
   1400098bc:	mov    rax,QWORD PTR [rax+0x10]
   1400098c0:	call   QWORD PTR [rip+0xe9d2]        # 0x140018298
   1400098c6:	nop
   1400098c7:	jmp    0x140009922
   1400098c9:	mov    rcx,QWORD PTR [rsp+0x48]
   1400098ce:	mov    rax,QWORD PTR [rcx]
   1400098d1:	lea    r9,[rsp+0x70]
   1400098d6:	lea    r8,[rbp+0x98]
   1400098dd:	mov    edx,0x1
   1400098e2:	mov    rax,QWORD PTR [rax+0x18]
   1400098e6:	call   QWORD PTR [rip+0xe9ac]        # 0x140018298
   1400098ec:	mov    DWORD PTR [rbp-0x78],eax
   1400098ef:	test   eax,eax
   1400098f1:	js     0x140009b57
   1400098f7:	cmp    eax,0x1
   1400098fa:	jne    0x14000993f
   1400098fc:	mov    edx,0x40002b5e
   140009901:	mov    rcx,rdi
   140009904:	call   0x14000d524
   140009909:	nop
   14000990a:	mov    rcx,QWORD PTR [rsp+0x48]
   14000990f:	test   rcx,rcx
   140009912:	je     0x140009922
   140009914:	mov    rax,QWORD PTR [rcx]
   140009917:	mov    rax,QWORD PTR [rax+0x10]
   14000991b:	call   QWORD PTR [rip+0xe977]        # 0x140018298
   140009921:	nop
   140009922:	mov    rcx,QWORD PTR [rsp+0x40]
   140009927:	test   rcx,rcx
   14000992a:	je     0x14000993a
   14000992c:	mov    rax,QWORD PTR [rcx]
   14000992f:	mov    rax,QWORD PTR [rax+0x10]
   140009933:	call   QWORD PTR [rip+0xe95f]        # 0x140018298
   140009939:	nop
   14000993a:	jmp    0x140009a87
   14000993f:	mov    rcx,QWORD PTR [rbp+0xa0]
   140009946:	rex.W call QWORD PTR [rip+0xe733]        # 0x140018080
   14000994d:	nop    DWORD PTR [rax+rax*1+0x0]
   140009952:	mov    QWORD PTR [rbp+0xa0],r12
   140009959:	mov    rsi,QWORD PTR [rbp+0xa8]
   140009960:	mov    QWORD PTR [rsp+0x68],rsi
   140009965:	lea    rax,[rip+0xd6f4]        # 0x140017060
   14000996c:	mov    QWORD PTR [rsp+0x60],rax
   140009971:	mov    rdx,rsi
   140009974:	lea    rcx,[rsp+0x50]
   140009979:	call   0x14000b90c
   14000997e:	mov    rbx,QWORD PTR [rsp+0x58]
   140009983:	mov    r14,rbx
   140009986:	test   rsi,rsi
   140009989:	je     0x14000999b
   14000998b:	mov    rcx,rsi
   14000998e:	rex.W call QWORD PTR [rip+0xe6eb]        # 0x140018080
   140009995:	nop    DWORD PTR [rax+rax*1+0x0]
   14000999a:	nop
   14000999b:	mov    rcx,QWORD PTR [rsp+0x48]
   1400099a0:	test   rcx,rcx
   1400099a3:	je     0x1400099b3
   1400099a5:	mov    rax,QWORD PTR [rcx]
   1400099a8:	mov    rax,QWORD PTR [rax+0x10]
   1400099ac:	call   QWORD PTR [rip+0xe8e6]        # 0x140018298
   1400099b2:	nop
   1400099b3:	lea    rsi,[rip+0x10536]        # 0x140019ef0
   1400099ba:	mov    rcx,QWORD PTR [rsp+0x40]
   1400099bf:	mov    rax,QWORD PTR [rcx]
   1400099c2:	xor    r9d,r9d
   1400099c5:	mov    r8,r14
   1400099c8:	mov    rdx,r15
   1400099cb:	mov    rax,QWORD PTR [rax+0x20]
   1400099cf:	call   QWORD PTR [rip+0xe8c3]        # 0x140018298
   1400099d5:	mov    DWORD PTR [rbp-0x78],eax
   1400099d8:	test   eax,eax
   1400099da:	jns    0x140009a38
   1400099dc:	cmp    eax,0x80042308
   1400099e1:	jne    0x140009a08
   1400099e3:	mov    edx,0x40002b5e
   1400099e8:	mov    rcx,rdi
   1400099eb:	call   0x14000d524
   1400099f0:	nop
   1400099f1:	test   rbx,rbx
   1400099f4:	je     0x140009a06
   1400099f6:	mov    rcx,rbx
   1400099f9:	rex.W call QWORD PTR [rip+0xe680]        # 0x140018080
   140009a00:	nop    DWORD PTR [rax+rax*1+0x0]
   140009a05:	nop
   140009a06:	jmp    0x140009a6f
   140009a08:	cmp    eax,0x8004231d
   140009a0d:	jne    0x140009ac1
   140009a13:	mov    edx,0x40002b60
   140009a18:	mov    rcx,rdi
   140009a1b:	call   0x14000d524
   140009a20:	nop
   140009a21:	test   rbx,rbx
   140009a24:	je     0x140009a36
   140009a26:	mov    rcx,rbx
   140009a29:	rex.W call QWORD PTR [rip+0xe650]        # 0x140018080
   140009a30:	nop    DWORD PTR [rax+rax*1+0x0]
   140009a35:	nop
   140009a36:	jmp    0x140009a6f
   140009a38:	mov    edx,0x9
   140009a3d:	mov    rcx,rdi
   140009a40:	call   0x14000b754
   140009a45:	test   eax,eax
   140009a47:	jne    0x140009a56
   140009a49:	mov    edx,0x40002751
   140009a4e:	mov    rcx,rdi
   140009a51:	call   0x14000c6f4
   140009a56:	mov    DWORD PTR [rdi+0x48],r12d
   140009a5a:	test   rbx,rbx
   140009a5d:	je     0x140009a6f
   140009a5f:	mov    rcx,rbx
   140009a62:	rex.W call QWORD PTR [rip+0xe617]        # 0x140018080
   140009a69:	nop    DWORD PTR [rax+rax*1+0x0]
   140009a6e:	nop
   140009a6f:	mov    rcx,QWORD PTR [rsp+0x40]
   140009a74:	test   rcx,rcx
   140009a77:	je     0x140009a87
   140009a79:	mov    rax,QWORD PTR [rcx]
   140009a7c:	mov    rax,QWORD PTR [rax+0x10]
   140009a80:	call   QWORD PTR [rip+0xe812]        # 0x140018298
   140009a86:	nop
   140009a87:	lea    rcx,[rbp-0x80]
   140009a8b:	call   0x14000f958
   140009a90:	mov    rcx,QWORD PTR [rbp+0xe0]
   140009a97:	xor    rcx,rsp
   140009a9a:	call   0x1400143c0
   140009a9f:	lea    r11,[rsp+0x1f0]
   140009aa7:	mov    rbx,QWORD PTR [r11+0x38]
   140009aab:	mov    rsi,QWORD PTR [r11+0x40]
   140009aaf:	mov    rdi,QWORD PTR [r11+0x48]
   140009ab3:	mov    rsp,r11
   140009ab6:	pop    r15
   140009ab8:	pop    r14
   140009aba:	pop    r13
   140009abc:	pop    r12
   140009abe:	pop    rbp
   140009abf:	ret
   140009ac0:	int3
   140009ac1:	mov    DWORD PTR [rsp+0x28],r13d
   140009ac6:	mov    DWORD PTR [rsp+0x20],0x67e
   140009ace:	lea    r9,[rip+0x11a33]        # 0x14001b508
   140009ad5:	lea    r8,[rip+0x103f4]        # 0x140019ed0
   140009adc:	mov    rdx,rsi
   140009adf:	lea    rcx,[rbp-0x10]
   140009ae3:	call   0x14000f3ac
   140009ae8:	mov    rdx,rax
   140009aeb:	lea    rcx,[rbp-0x80]
   140009aef:	call   0x1400038ec
   140009af4:	mov    DWORD PTR [rsp+0x20],eax
   140009af8:	lea    r9,[rip+0x11a51]        # 0x14001b550
   140009aff:	mov    r8d,eax
   140009b02:	lea    rcx,[rbp-0x80]
   140009b06:	call   0x1400106b0
   140009b0b:	nop
   140009b0c:	mov    DWORD PTR [rsp+0x28],r13d
   140009b11:	mov    DWORD PTR [rsp+0x20],0x648
   140009b19:	lea    r9,[rip+0x119e8]        # 0x14001b508
   140009b20:	lea    r8,[rip+0x103a9]        # 0x140019ed0
   140009b27:	mov    rdx,rsi
   140009b2a:	lea    rcx,[rbp-0x10]
   140009b2e:	call   0x14000f3ac
   140009b33:	mov    rdx,rax
   140009b36:	lea    rcx,[rbp-0x80]
   140009b3a:	call   0x1400038ec
   140009b3f:	mov    DWORD PTR [rsp+0x20],eax
   140009b43:	lea    r9,[rip+0x10b66]        # 0x14001a6b0
   140009b4a:	mov    r8d,eax
   140009b4d:	lea    rcx,[rbp-0x80]
   140009b51:	call   0x1400106b0
   140009b56:	int3
   140009b57:	mov    DWORD PTR [rsp+0x28],r13d
   140009b5c:	mov    DWORD PTR [rsp+0x20],0x658
   140009b64:	lea    r9,[rip+0x1199d]        # 0x14001b508
   140009b6b:	lea    r8,[rip+0x1035e]        # 0x140019ed0
   140009b72:	mov    rdx,rsi
   140009b75:	lea    rcx,[rbp-0x10]
   140009b79:	call   0x14000f3ac
   140009b7e:	mov    rdx,rax
   140009b81:	lea    rcx,[rbp-0x80]
   140009b85:	call   0x1400038ec
   140009b8a:	mov    DWORD PTR [rsp+0x20],eax
   140009b8e:	lea    r9,[rip+0xee53]        # 0x1400189e8
   140009b95:	mov    r8d,eax
   140009b98:	lea    rcx,[rbp-0x80]
   140009b9c:	call   0x1400106b0
   140009ba1:	int3
   140009ba2:	int3
   140009ba3:	int3
   140009ba4:	int3
   140009ba5:	int3
   140009ba6:	int3
   140009ba7:	int3
   140009ba8:	mov    rax,rsp
   140009bab:	push   rbp
   140009bac:	push   rdi
   140009bad:	push   r12
   140009baf:	push   r14
   140009bb1:	push   r15
   140009bb3:	lea    rbp,[rsp-0x70]
   140009bb8:	sub    rsp,0x170
   140009bbf:	mov    QWORD PTR [rsp+0x50],0xfffffffffffffffe
   140009bc8:	mov    QWORD PTR [rax+0x8],rbx
   140009bcc:	mov    QWORD PTR [rax+0x20],rsi
   140009bd0:	mov    rbx,rcx
   140009bd3:	lea    rsi,[rip+0x10316]        # 0x140019ef0
   140009bda:	mov    QWORD PTR [rsp+0x58],rsi
   140009bdf:	lea    r15,[rip+0x119ca]        # 0x14001b5b0
   140009be6:	mov    QWORD PTR [rsp+0x60],r15
   140009beb:	lea    r12,[rip+0x102de]        # 0x140019ed0
   140009bf2:	mov    QWORD PTR [rsp+0x68],r12
   140009bf7:	mov    DWORD PTR [rsp+0x70],0x68f
   140009bff:	mov    DWORD PTR [rsp+0x74],0x7
   140009c07:	mov    DWORD PTR [rsp+0x78],0xff
   140009c0f:	xor    r14d,r14d
   140009c12:	mov    DWORD PTR [rbp-0x8],0x1000000
   140009c19:	xor    edx,edx
   140009c1b:	lea    r8d,[r14+0x78]
   140009c1f:	lea    rcx,[rbp-0x80]
   140009c23:	call   0x140015692
   140009c28:	lea    rdx,[rsp+0x58]
   140009c2d:	lea    rcx,[rbp+0x0]
   140009c31:	call   0x14000f85c
   140009c36:	nop
   140009c37:	mov    edi,r14d
   140009c3a:	mov    DWORD PTR [rbp+0xb0],r14d
   140009c41:	mov    BYTE PTR [rbp+0xa8],r14b
   140009c48:	mov    QWORD PTR [rsp+0x40],r14
   140009c4d:	mov    QWORD PTR [rsp+0x48],r14
   140009c52:	lea    r8,[rbp+0xa8]
   140009c59:	lea    rdx,[rsp+0x40]
   140009c5e:	mov    rcx,rbx
   140009c61:	call   0x140009db8
   140009c66:	mov    r8d,DWORD PTR [rsp+0x48]
   140009c6b:	test   r8d,r8d
   140009c6e:	jne    0x140009c98
   140009c70:	mov    DWORD PTR [rsp+0x28],0x7
   140009c78:	mov    r9,r15
   140009c7b:	mov    r8,r12
   140009c7e:	mov    rdx,rsi
   140009c81:	lea    rcx,[rsp+0x58]
   140009c86:	cmp    BYTE PTR [rbp+0xa8],r14b
   140009c8d:	jne    0x140009d53
   140009c93:	jmp    0x140009d2c
   140009c98:	mov    edx,0x4000275b
   140009c9d:	mov    rcx,rbx
   140009ca0:	call   0x14000d788
   140009ca5:	mov    esi,eax
   140009ca7:	test   eax,eax
   140009ca9:	je     0x140009cc2
   140009cab:	lea    r8,[rbp+0xb0]
   140009cb2:	lea    rdx,[rsp+0x40]
   140009cb7:	call   0x14000a820
   140009cbc:	mov    edi,DWORD PTR [rbp+0xb0]
   140009cc2:	mov    edx,0x9
   140009cc7:	mov    rcx,rbx
   140009cca:	call   0x14000b754
   140009ccf:	test   eax,eax
   140009cd1:	jne    0x140009ceb
   140009cd3:	test   esi,esi
   140009cd5:	je     0x140009ceb
   140009cd7:	test   edi,edi
   140009cd9:	jle    0x140009ceb
   140009cdb:	mov    r8d,edi
   140009cde:	mov    edx,0x4000275d
   140009ce3:	mov    rcx,rbx
   140009ce6:	call   0x14000c6f4
   140009ceb:	mov    DWORD PTR [rbx+0x48],r14d
   140009cef:	mov    rcx,QWORD PTR [rsp+0x40]
   140009cf4:	test   rcx,rcx
   140009cf7:	je     0x140009d06
   140009cf9:	rex.W call QWORD PTR [rip+0xe548]        # 0x140018248
   140009d00:	nop    DWORD PTR [rax+rax*1+0x0]
   140009d05:	nop
   140009d06:	lea    rcx,[rbp+0x0]
   140009d0a:	call   0x14000f958
   140009d0f:	lea    r11,[rsp+0x170]
   140009d17:	mov    rbx,QWORD PTR [r11+0x30]
   140009d1b:	mov    rsi,QWORD PTR [r11+0x48]
   140009d1f:	mov    rsp,r11
   140009d22:	pop    r15
   140009d24:	pop    r14
   140009d26:	pop    r12
   140009d28:	pop    rdi
   140009d29:	pop    rbp
   140009d2a:	ret
   140009d2b:	int3
   140009d2c:	mov    DWORD PTR [rsp+0x20],0x69d
   140009d34:	call   0x14000f3ac
   140009d39:	lea    r9,[rip+0x11950]        # 0x14001b690
   140009d40:	mov    r8d,0x1
   140009d46:	mov    rdx,rax
   140009d49:	lea    rcx,[rbp+0x0]
   140009d4d:	call   0x1400106b0
   140009d52:	int3
   140009d53:	mov    DWORD PTR [rsp+0x20],0x69a
   140009d5b:	call   0x14000f3ac
   140009d60:	lea    r9,[rip+0x11889]        # 0x14001b5f0
   140009d67:	mov    r8d,0x100b
   140009d6d:	mov    rdx,rax
   140009d70:	lea    rcx,[rbp+0x0]
   140009d74:	call   0x1400106b0
   140009d79:	int3
   140009d7a:	int3
   140009d7b:	int3
   140009d7c:	int3
   140009d7d:	int3
   140009d7e:	int3
   140009d7f:	int3
   140009d80:	rex push rbx
   140009d82:	sub    rsp,0x20
   140009d86:	mov    rbx,rcx
   140009d89:	mov    rcx,QWORD PTR [rcx]
   140009d8c:	test   rcx,rcx
   140009d8f:	je     0x140009da1
   140009d91:	rex.W call QWORD PTR [rip+0xe4b0]        # 0x140018248
   140009d98:	nop    DWORD PTR [rax+rax*1+0x0]
   140009d9d:	and    QWORD PTR [rbx],0x0
   140009da1:	and    DWORD PTR [rbx+0x8],0x0
   140009da5:	and    DWORD PTR [rbx+0xc],0x0
   140009da9:	add    rsp,0x20
   140009dad:	pop    rbx
   140009dae:	ret
   140009daf:	int3
   140009db0:	int3
   140009db1:	int3
   140009db2:	int3
   140009db3:	int3
   140009db4:	int3
   140009db5:	int3
   140009db6:	int3
   140009db7:	int3
   140009db8:	mov    rax,rsp
   140009dbb:	push   rbp
   140009dbc:	push   rsi
   140009dbd:	push   rdi
   140009dbe:	push   r12
   140009dc0:	push   r13
   140009dc2:	push   r14
   140009dc4:	push   r15
   140009dc6:	lea    rbp,[rax-0x2f8]
   140009dcd:	sub    rsp,0x3c0
   140009dd4:	mov    QWORD PTR [rbp+0xd0],0xfffffffffffffffe
   140009ddf:	mov    QWORD PTR [rax+0x20],rbx
   140009de3:	movaps XMMWORD PTR [rax-0x48],xmm6
   140009de7:	mov    rax,QWORD PTR [rip+0x1a32a]        # 0x140024118
   140009dee:	xor    rax,rsp
   140009df1:	mov    QWORD PTR [rbp+0x2a0],rax
   140009df8:	mov    QWORD PTR [rbp+0x50],r8
   140009dfc:	mov    rbx,rdx
   140009dff:	mov    rsi,rcx
   140009e02:	lea    rax,[rip+0x100e7]        # 0x140019ef0
   140009e09:	mov    QWORD PTR [rbp-0x58],rax
   140009e0d:	lea    rax,[rip+0x118ec]        # 0x14001b700
   140009e14:	mov    QWORD PTR [rbp-0x50],rax
   140009e18:	lea    rax,[rip+0x100b1]        # 0x140019ed0
   140009e1f:	mov    QWORD PTR [rbp-0x48],rax
   140009e23:	mov    DWORD PTR [rbp-0x40],0x6b0
   140009e2a:	mov    DWORD PTR [rbp-0x3c],0x7
   140009e31:	mov    DWORD PTR [rbp-0x38],0xff
   140009e38:	xor    r15d,r15d
   140009e3b:	mov    DWORD PTR [rbp+0x48],0x1000000
   140009e42:	lea    edi,[r15+0x1]
   140009e46:	xor    edx,edx
   140009e48:	lea    r8d,[r15+0x78]
   140009e4c:	lea    rcx,[rbp-0x30]
   140009e50:	call   0x140015692
   140009e55:	lea    rdx,[rbp-0x58]
   140009e59:	lea    rcx,[rbp+0x60]
   140009e5d:	call   0x14000f85c
   140009e62:	nop
   140009e63:	lea    edx,[rdi+0x2]
   140009e66:	mov    rcx,rsi
   140009e69:	call   0x1400038f8
   140009e6e:	mov    r12,rax
   140009e71:	lea    edx,[rdi+0x5]
   140009e74:	mov    rcx,rsi
   140009e77:	call   0x14000b754
   140009e7c:	movsxd r13,eax
   140009e7f:	mov    DWORD PTR [rsp+0x50],r13d
   140009e84:	xor    edx,edx
   140009e86:	mov    rcx,rsi
   140009e89:	call   0x14000b754
   140009e8e:	movsxd r14,eax
   140009e91:	movups xmm6,XMMWORD PTR [rip+0xe518]        # 0x1400183b0
   140009e98:	movdqu XMMWORD PTR [rbp+0x180],xmm6
   140009ea0:	movabs rax,0x7fffffffffffffff
   140009eaa:	mov    QWORD PTR [rbp-0x68],rax
   140009eae:	lea    edx,[rdi+0xb]
   140009eb1:	mov    rcx,rsi
   140009eb4:	call   0x1400038f8
   140009eb9:	test   rax,rax
   140009ebc:	je     0x140009ee0
   140009ebe:	lea    edx,[rdi+0xb]
   140009ec1:	mov    rcx,rsi
   140009ec4:	call   0x1400038f8
   140009ec9:	mov    rdx,rax
   140009ecc:	lea    r8,[rbp+0x180]
   140009ed3:	call   0x14000c630
   140009ed8:	test   al,al
   140009eda:	je     0x14000a5ce
   140009ee0:	movaps xmm0,XMMWORD PTR [rbp+0x180]
   140009ee7:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   140009eed:	mov    edx,0x9
   140009ef2:	mov    rcx,rsi
   140009ef5:	call   0x14000b754
   140009efa:	mov    r10,QWORD PTR [rsi]
   140009efd:	mov    rcx,QWORD PTR [r10]
   140009f00:	cmp    eax,edi
   140009f02:	sete   dl
   140009f05:	cmp    r13d,edi
   140009f08:	sete   r8b
   140009f0c:	cmp    r14d,edi
   140009f0f:	sete   r9b
   140009f13:	mov    rax,QWORD PTR [rcx+0x58]
   140009f17:	lea    rcx,[rbp+0x60]
   140009f1b:	mov    QWORD PTR [rsp+0x38],rcx
   140009f20:	mov    BYTE PTR [rsp+0x30],dl
   140009f24:	lea    rcx,[rsp+0x60]
   140009f29:	mov    QWORD PTR [rsp+0x28],rcx
   140009f2e:	mov    BYTE PTR [rsp+0x20],r8b
   140009f33:	mov    r8,r12
   140009f36:	or     edx,0xffffffff
   140009f39:	mov    rcx,r10
   140009f3c:	call   QWORD PTR [rip+0xe356]        # 0x140018298
   140009f42:	mov    QWORD PTR [rbp-0x80],r15
   140009f46:	movups xmm0,XMMWORD PTR [rip+0xf123]        # 0x140019070
   140009f4d:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   140009f53:	movups xmm1,XMMWORD PTR [rip+0xf106]        # 0x140019060
   140009f5a:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   140009f60:	lea    rax,[rip+0xff89]        # 0x140019ef0
   140009f67:	mov    QWORD PTR [rbp-0x58],rax
   140009f6b:	lea    rax,[rip+0x1178e]        # 0x14001b700
   140009f72:	mov    QWORD PTR [rbp-0x50],rax
   140009f76:	lea    rax,[rip+0xff53]        # 0x140019ed0
   140009f7d:	mov    QWORD PTR [rbp-0x48],rax
   140009f81:	mov    DWORD PTR [rbp-0x40],0x6c9
   140009f88:	mov    DWORD PTR [rbp-0x3c],0x7
   140009f8f:	mov    DWORD PTR [rbp-0x38],0xff
   140009f96:	mov    DWORD PTR [rbp+0x48],0x1000000
   140009f9d:	xor    edx,edx
   140009f9f:	lea    r8d,[rdx+0x78]
   140009fa3:	lea    rcx,[rbp-0x30]
   140009fa7:	call   0x140015692
   140009fac:	lea    rax,[rbp-0x80]
   140009fb0:	mov    QWORD PTR [rsp+0x30],rax
   140009fb5:	lea    rax,[rsp+0x60]
   140009fba:	mov    QWORD PTR [rsp+0x28],rax
   140009fbf:	lea    r9,[rip+0xe982]        # 0x140018948
   140009fc6:	lea    r8,[rsp+0x70]
   140009fcb:	lea    rdx,[rbp-0x58]
   140009fcf:	lea    rcx,[rbp+0x60]
   140009fd3:	call   0x140011460
   140009fd8:	cmp    DWORD PTR [rbp+0x68],r15d
   140009fdc:	jl     0x14000a616
   140009fe2:	mov    rcx,QWORD PTR [rbp-0x80]
   140009fe6:	mov    rax,QWORD PTR [rcx]
   140009fe9:	or     edx,0xffffffff
   140009fec:	mov    rax,QWORD PTR [rax+0x18]
   140009ff0:	call   QWORD PTR [rip+0xe2a2]        # 0x140018298
   140009ff6:	mov    DWORD PTR [rbp+0x68],eax
   140009ff9:	test   eax,eax
   140009ffb:	js     0x14000a668
   14000a001:	mov    rax,QWORD PTR [rbp+0x180]
   14000a008:	cmp    rax,QWORD PTR [rip+0xe3a1]        # 0x1400183b0
   14000a00f:	jne    0x14000a3df
   14000a015:	mov    rax,QWORD PTR [rbp+0x188]
   14000a01c:	cmp    rax,QWORD PTR [rip+0xe395]        # 0x1400183b8
   14000a023:	jne    0x14000a3df
   14000a029:	xor    edx,edx
   14000a02b:	lea    r8d,[rdx+0x64]
   14000a02f:	lea    rcx,[rbp+0x220]
   14000a036:	call   0x140015692
   14000a03b:	test   r12,r12
   14000a03e:	je     0x14000a070
   14000a040:	cmp    WORD PTR [r12],0x5c
   14000a046:	je     0x14000a172
   14000a04c:	mov    r8d,0x32
   14000a052:	lea    rdx,[rbp+0x220]
   14000a059:	mov    rcx,r12
   14000a05c:	rex.W call QWORD PTR [rip+0xde85]        # 0x140017ee8
   14000a063:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a068:	test   eax,eax
   14000a06a:	je     0x14000a6ba
   14000a070:	lea    rsi,[rip+0xfe79]        # 0x140019ef0
   14000a077:	mov    QWORD PTR [rbp-0x78],r15
   14000a07b:	movups xmm0,XMMWORD PTR [rip+0xe32e]        # 0x1400183b0
   14000a082:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   14000a088:	mov    rcx,QWORD PTR [rbp-0x80]
   14000a08c:	mov    rax,QWORD PTR [rcx]
   14000a08f:	lea    rdx,[rbp-0x78]
   14000a093:	mov    QWORD PTR [rsp+0x20],rdx
   14000a098:	mov    r9d,0x3
   14000a09e:	mov    r8d,edi
   14000a0a1:	lea    rdx,[rsp+0x60]
   14000a0a6:	mov    rax,QWORD PTR [rax+0x50]
   14000a0aa:	call   QWORD PTR [rip+0xe1e8]        # 0x140018298
   14000a0b0:	mov    DWORD PTR [rbp+0x68],eax
   14000a0b3:	test   eax,eax
   14000a0b5:	js     0x14000a74c
   14000a0bb:	mov    rcx,QWORD PTR [rbp-0x78]
   14000a0bf:	mov    rax,QWORD PTR [rcx]
   14000a0c2:	lea    r9,[rbp-0x70]
   14000a0c6:	lea    r8,[rbp+0x190]
   14000a0cd:	mov    edx,edi
   14000a0cf:	mov    rax,QWORD PTR [rax+0x18]
   14000a0d3:	call   QWORD PTR [rip+0xe1bf]        # 0x140018298
   14000a0d9:	mov    DWORD PTR [rbp+0x68],eax
   14000a0dc:	test   eax,eax
   14000a0de:	js     0x14000a55f
   14000a0e4:	mov    rdi,r14
   14000a0e7:	mov    QWORD PTR [rsp+0x70],r14
   14000a0ec:	mov    r15,r13
   14000a0ef:	mov    QWORD PTR [rbp-0x60],r13
   14000a0f3:	mov    esi,0x3fffffff
   14000a0f8:	movabs r14,0x7ffffffffffffff
   14000a102:	xor    r13d,r13d
   14000a105:	mov    ecx,0x1
   14000a10a:	cmp    eax,ecx
   14000a10c:	je     0x14000a329
   14000a112:	lea    rax,[rip+0xd0a7]        # 0x1400171c0
   14000a119:	mov    QWORD PTR [rsp+0x60],rax
   14000a11e:	lea    rax,[rbp+0x198]
   14000a125:	mov    QWORD PTR [rsp+0x68],rax
   14000a12a:	lea    rdx,[rbp+0x220]
   14000a131:	mov    rcx,QWORD PTR [rbp+0x1c8]
   14000a138:	rex.W call QWORD PTR [rip+0xe131]        # 0x140018270
   14000a13f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a144:	test   eax,eax
   14000a146:	je     0x14000a203
   14000a14c:	test   r12,r12
   14000a14f:	jne    0x14000a15a
   14000a151:	test   rdi,rdi
   14000a154:	jne    0x14000a203
   14000a15a:	lea    rcx,[rbp+0x198]
   14000a161:	rex.W call QWORD PTR [rip+0xde68]        # 0x140017fd0
   14000a168:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a16d:	jmp    0x14000a2e7
   14000a172:	mov    r8,r12
   14000a175:	mov    edx,0x32
   14000a17a:	lea    rcx,[rbp+0x220]
   14000a181:	call   0x1400035fc
   14000a186:	mov    edi,eax
   14000a188:	mov    DWORD PTR [rbp+0x68],eax
   14000a18b:	lea    rsi,[rip+0xfd5e]        # 0x140019ef0
   14000a192:	mov    QWORD PTR [rbp-0x58],rsi
   14000a196:	lea    rax,[rip+0x11563]        # 0x14001b700
   14000a19d:	mov    QWORD PTR [rbp-0x50],rax
   14000a1a1:	lea    rax,[rip+0xfd28]        # 0x140019ed0
   14000a1a8:	mov    QWORD PTR [rbp-0x48],rax
   14000a1ac:	mov    DWORD PTR [rbp-0x40],0x701
   14000a1b3:	mov    DWORD PTR [rbp-0x3c],0x7
   14000a1ba:	mov    DWORD PTR [rbp-0x38],0xff
   14000a1c1:	mov    DWORD PTR [rbp+0x48],0x1000000
   14000a1c8:	xor    edx,edx
   14000a1ca:	lea    r8d,[rdx+0x78]
   14000a1ce:	lea    rcx,[rbp-0x30]
   14000a1d2:	call   0x140015692
   14000a1d7:	lea    rax,[rbp-0x58]
   14000a1db:	mov    QWORD PTR [rsp+0x70],rax
   14000a1e0:	test   edi,edi
   14000a1e2:	js     0x14000a725
   14000a1e8:	lea    rcx,[rbp-0x58]
   14000a1ec:	call   0x14000f484
   14000a1f1:	mov    WORD PTR [rbp+0x282],r15w
   14000a1f9:	mov    edi,0x1
   14000a1fe:	jmp    0x14000a077
   14000a203:	mov    ecx,DWORD PTR [rbp+0x200]
   14000a209:	call   0x14000ebb4
   14000a20e:	test   eax,eax
   14000a210:	jne    0x14000a222
   14000a212:	mov    rax,QWORD PTR [rbp+0x50]
   14000a216:	mov    ecx,0x1
   14000a21b:	mov    BYTE PTR [rax],cl
   14000a21d:	jmp    0x14000a15a
   14000a222:	test   r15,r15
   14000a225:	je     0x14000a24f
   14000a227:	mov    rax,QWORD PTR [rbp-0x68]
   14000a22b:	cmp    rax,QWORD PTR [rbp+0x208]
   14000a232:	jle    0x14000a15a
   14000a238:	movups xmm6,XMMWORD PTR [rbp+0x198]
   14000a23f:	mov    rax,QWORD PTR [rbp+0x208]
   14000a246:	mov    QWORD PTR [rbp-0x68],rax
   14000a24a:	jmp    0x14000a15a
   14000a24f:	movsxd rdi,DWORD PTR [rbx+0x8]
   14000a253:	lea    r13d,[rdi+0x1]
   14000a257:	test   r13d,r13d
   14000a25a:	jle    0x14000a79d
   14000a260:	cmp    edi,DWORD PTR [rbx+0xc]
   14000a263:	jne    0x14000a2b1
   14000a265:	cmp    edi,esi
   14000a267:	jg     0x14000a79d
   14000a26d:	cmp    rdi,r14
   14000a270:	ja     0x14000a79d
   14000a276:	lea    r15d,[rdi+rdi*1]
   14000a27a:	cmp    DWORD PTR [rbx+0xc],0x0
   14000a27e:	mov    eax,0x1
   14000a283:	cmove  r15d,eax
   14000a287:	movsxd rdx,r15d
   14000a28a:	shl    rdx,0x4
   14000a28e:	mov    rcx,QWORD PTR [rbx]
   14000a291:	rex.W call QWORD PTR [rip+0xdfb8]        # 0x140018250
   14000a298:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a29d:	test   rax,rax
   14000a2a0:	je     0x14000a79d
   14000a2a6:	mov    DWORD PTR [rbx+0xc],r15d
   14000a2aa:	mov    QWORD PTR [rbx],rax
   14000a2ad:	mov    r15,QWORD PTR [rbp-0x60]
   14000a2b1:	mov    DWORD PTR [rbx+0x8],r13d
   14000a2b5:	mov    rax,rdi
   14000a2b8:	shl    rax,0x4
   14000a2bc:	add    rax,QWORD PTR [rbx]
   14000a2bf:	je     0x14000a2cc
   14000a2c1:	movups xmm0,XMMWORD PTR [rbp+0x198]
   14000a2c8:	movdqu XMMWORD PTR [rax],xmm0
   14000a2cc:	lea    rcx,[rbp+0x198]
   14000a2d3:	rex.W call QWORD PTR [rip+0xdcf6]        # 0x140017fd0
   14000a2da:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a2df:	xor    r13d,r13d
   14000a2e2:	mov    rdi,QWORD PTR [rsp+0x70]
   14000a2e7:	lea    rax,[rip+0xcd7a]        # 0x140017068
   14000a2ee:	mov    QWORD PTR [rsp+0x60],rax
   14000a2f3:	mov    QWORD PTR [rsp+0x68],r13
   14000a2f8:	mov    rcx,QWORD PTR [rbp-0x78]
   14000a2fc:	mov    rax,QWORD PTR [rcx]
   14000a2ff:	lea    r9,[rbp-0x70]
   14000a303:	lea    r8,[rbp+0x190]
   14000a30a:	mov    edx,0x1
   14000a30f:	mov    rax,QWORD PTR [rax+0x18]
   14000a313:	call   QWORD PTR [rip+0xdf7f]        # 0x140018298
   14000a319:	mov    DWORD PTR [rbp+0x68],eax
   14000a31c:	test   eax,eax
   14000a31e:	js     0x14000a55f
   14000a324:	jmp    0x14000a105
   14000a329:	cmp    DWORD PTR [rsp+0x50],r13d
   14000a32e:	je     0x14000a3c3
   14000a334:	movq   rax,xmm6
   14000a339:	cmp    rax,QWORD PTR [rip+0xe070]        # 0x1400183b0
   14000a340:	jne    0x14000a359
   14000a342:	movdqa xmm0,xmm6
   14000a346:	psrldq xmm0,0x8
   14000a34b:	movq   rax,xmm0
   14000a350:	cmp    rax,QWORD PTR [rip+0xe061]        # 0x1400183b8
   14000a357:	je     0x14000a3c3
   14000a359:	movsxd rdi,DWORD PTR [rbx+0x8]
   14000a35d:	lea    r15d,[rdi+0x1]
   14000a361:	test   r15d,r15d
   14000a364:	jle    0x14000a7b7
   14000a36a:	cmp    edi,DWORD PTR [rbx+0xc]
   14000a36d:	jne    0x14000a3af
   14000a36f:	cmp    edi,esi
   14000a371:	jg     0x14000a7b7
   14000a377:	cmp    rdi,r14
   14000a37a:	ja     0x14000a7b7
   14000a380:	lea    esi,[rdi+rdi*1]
   14000a383:	cmp    DWORD PTR [rbx+0xc],r13d
   14000a387:	cmove  esi,ecx
   14000a38a:	movsxd rdx,esi
   14000a38d:	shl    rdx,0x4
   14000a391:	mov    rcx,QWORD PTR [rbx]
   14000a394:	rex.W call QWORD PTR [rip+0xdeb5]        # 0x140018250
   14000a39b:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a3a0:	test   rax,rax
   14000a3a3:	je     0x14000a7b7
   14000a3a9:	mov    DWORD PTR [rbx+0xc],esi
   14000a3ac:	mov    QWORD PTR [rbx],rax
   14000a3af:	mov    DWORD PTR [rbx+0x8],r15d
   14000a3b3:	mov    rax,rdi
   14000a3b6:	shl    rax,0x4
   14000a3ba:	add    rax,QWORD PTR [rbx]
   14000a3bd:	je     0x14000a3c3
   14000a3bf:	movdqu XMMWORD PTR [rax],xmm6
   14000a3c3:	mov    rcx,QWORD PTR [rbp-0x78]
   14000a3c7:	test   rcx,rcx
   14000a3ca:	je     0x14000a3da
   14000a3cc:	mov    rax,QWORD PTR [rcx]
   14000a3cf:	mov    rax,QWORD PTR [rax+0x10]
   14000a3d3:	call   QWORD PTR [rip+0xdebf]        # 0x140018298
   14000a3d9:	nop
   14000a3da:	jmp    0x14000a4c4
   14000a3df:	movaps xmm0,XMMWORD PTR [rbp+0x180]
   14000a3e6:	movdqa XMMWORD PTR [rsp+0x60],xmm0
   14000a3ec:	mov    rcx,QWORD PTR [rbp-0x80]
   14000a3f0:	mov    rax,QWORD PTR [rcx]
   14000a3f3:	lea    r8,[rbp+0x220]
   14000a3fa:	lea    rdx,[rsp+0x60]
   14000a3ff:	mov    rax,QWORD PTR [rax+0x38]
   14000a403:	call   QWORD PTR [rip+0xde8f]        # 0x140018298
   14000a409:	mov    DWORD PTR [rbp+0x68],eax
   14000a40c:	cmp    eax,0x80042308
   14000a411:	je     0x14000a7d1
   14000a417:	mov    ecx,DWORD PTR [rbp+0x288]
   14000a41d:	call   0x14000ebb4
   14000a422:	test   eax,eax
   14000a424:	je     0x14000a514
   14000a42a:	lea    rcx,[rbp+0x220]
   14000a431:	rex.W call QWORD PTR [rip+0xdb98]        # 0x140017fd0
   14000a438:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a43d:	movsxd rdi,DWORD PTR [rbx+0x8]
   14000a441:	lea    r15d,[rdi+0x1]
   14000a445:	xor    r13d,r13d
   14000a448:	test   r15d,r15d
   14000a44b:	jle    0x14000a5b4
   14000a451:	cmp    edi,DWORD PTR [rbx+0xc]
   14000a454:	jne    0x14000a4a9
   14000a456:	mov    esi,0x3fffffff
   14000a45b:	cmp    edi,esi
   14000a45d:	jg     0x14000a5b4
   14000a463:	movabs r14,0x7ffffffffffffff
   14000a46d:	cmp    rdi,r14
   14000a470:	ja     0x14000a5b4
   14000a476:	lea    esi,[rdi+rdi*1]
   14000a479:	cmp    DWORD PTR [rbx+0xc],r13d
   14000a47d:	lea    eax,[r13+0x1]
   14000a481:	cmove  esi,eax
   14000a484:	movsxd rdx,esi
   14000a487:	shl    rdx,0x4
   14000a48b:	mov    rcx,QWORD PTR [rbx]
   14000a48e:	rex.W call QWORD PTR [rip+0xddbb]        # 0x140018250
   14000a495:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a49a:	test   rax,rax
   14000a49d:	je     0x14000a5b4
   14000a4a3:	mov    DWORD PTR [rbx+0xc],esi
   14000a4a6:	mov    QWORD PTR [rbx],rax
   14000a4a9:	mov    DWORD PTR [rbx+0x8],r15d
   14000a4ad:	mov    rax,rdi
   14000a4b0:	shl    rax,0x4
   14000a4b4:	add    rax,QWORD PTR [rbx]
   14000a4b7:	je     0x14000a4c4
   14000a4b9:	movaps xmm0,XMMWORD PTR [rbp+0x180]
   14000a4c0:	movdqu XMMWORD PTR [rax],xmm0
   14000a4c4:	mov    rcx,QWORD PTR [rbp-0x80]
   14000a4c8:	test   rcx,rcx
   14000a4cb:	je     0x14000a4db
   14000a4cd:	mov    rax,QWORD PTR [rcx]
   14000a4d0:	mov    rax,QWORD PTR [rax+0x10]
   14000a4d4:	call   QWORD PTR [rip+0xddbe]        # 0x140018298
   14000a4da:	nop
   14000a4db:	lea    rcx,[rbp+0x60]
   14000a4df:	call   0x14000f958
   14000a4e4:	mov    rcx,QWORD PTR [rbp+0x2a0]
   14000a4eb:	xor    rcx,rsp
   14000a4ee:	call   0x1400143c0
   14000a4f3:	lea    r11,[rsp+0x3c0]
   14000a4fb:	mov    rbx,QWORD PTR [r11+0x58]
   14000a4ff:	movaps xmm6,XMMWORD PTR [r11-0x10]
   14000a504:	mov    rsp,r11
   14000a507:	pop    r15
   14000a509:	pop    r14
   14000a50b:	pop    r13
   14000a50d:	pop    r12
   14000a50f:	pop    rdi
   14000a510:	pop    rsi
   14000a511:	pop    rbp
   14000a512:	ret
   14000a513:	int3
   14000a514:	mov    DWORD PTR [rsp+0x28],0x7
   14000a51c:	mov    DWORD PTR [rsp+0x20],0x6e4
   14000a524:	lea    r9,[rip+0x111d5]        # 0x14001b700
   14000a52b:	lea    r8,[rip+0xf99e]        # 0x140019ed0
   14000a532:	lea    rdx,[rip+0xf9b7]        # 0x140019ef0
   14000a539:	lea    rcx,[rbp+0xd8]
   14000a540:	call   0x14000f3ac
   14000a545:	lea    r9,[rip+0x11254]        # 0x14001b7a0
   14000a54c:	mov    r8d,0x100b
   14000a552:	mov    rdx,rax
   14000a555:	lea    rcx,[rbp+0x60]
   14000a559:	call   0x1400106b0
   14000a55e:	nop
   14000a55f:	mov    DWORD PTR [rsp+0x28],0x7
   14000a567:	mov    DWORD PTR [rsp+0x20],0x715
   14000a56f:	lea    r9,[rip+0x1118a]        # 0x14001b700
   14000a576:	lea    r8,[rip+0xf953]        # 0x140019ed0
   14000a57d:	lea    rdx,[rip+0xf96c]        # 0x140019ef0
   14000a584:	lea    rcx,[rbp+0xd8]
   14000a58b:	call   0x14000f3ac
   14000a590:	mov    rdx,rax
   14000a593:	lea    rcx,[rbp+0x60]
   14000a597:	call   0x1400038ec
   14000a59c:	mov    DWORD PTR [rsp+0x20],eax
   14000a5a0:	lea    r9,[rip+0xe441]        # 0x1400189e8
   14000a5a7:	mov    r8d,eax
   14000a5aa:	lea    rcx,[rbp+0x60]
   14000a5ae:	call   0x1400106b0
   14000a5b3:	nop
   14000a5b4:	mov    DWORD PTR [rsp+0x50],0x8007000e
   14000a5bc:	lea    rdx,[rip+0x17a55]        # 0x140022018
   14000a5c3:	lea    rcx,[rsp+0x50]
   14000a5c8:	call   0x14001478c
   14000a5cd:	nop
   14000a5ce:	mov    DWORD PTR [rsp+0x28],0x7
   14000a5d6:	mov    DWORD PTR [rsp+0x20],0x6be
   14000a5de:	lea    r9,[rip+0x1111b]        # 0x14001b700
   14000a5e5:	lea    r8,[rip+0xf8e4]        # 0x140019ed0
   14000a5ec:	lea    rdx,[rip+0xf8fd]        # 0x140019ef0
   14000a5f3:	lea    rcx,[rbp-0x58]
   14000a5f7:	call   0x14000f3ac
   14000a5fc:	lea    r9,[rip+0x10b4d]        # 0x14001b150
   14000a603:	mov    r8d,0x1004
   14000a609:	mov    rdx,rax
   14000a60c:	lea    rcx,[rbp+0x60]
   14000a610:	call   0x1400106b0
   14000a615:	nop
   14000a616:	mov    DWORD PTR [rsp+0x28],0x7
   14000a61e:	mov    DWORD PTR [rsp+0x20],0x6d0
   14000a626:	lea    r9,[rip+0x110d3]        # 0x14001b700
   14000a62d:	lea    r8,[rip+0xf89c]        # 0x140019ed0
   14000a634:	lea    rdx,[rip+0xf8b5]        # 0x140019ef0
   14000a63b:	lea    rcx,[rbp-0x58]
   14000a63f:	call   0x14000f3ac
   14000a644:	mov    rdx,rax
   14000a647:	lea    rcx,[rbp+0x60]
   14000a64b:	call   0x1400038ec
   14000a650:	mov    DWORD PTR [rsp+0x20],eax
   14000a654:	lea    r9,[rip+0xe305]        # 0x140018960
   14000a65b:	mov    r8d,eax
   14000a65e:	lea    rcx,[rbp+0x60]
   14000a662:	call   0x1400106b0
   14000a667:	int3
   14000a668:	mov    DWORD PTR [rsp+0x28],0x7
   14000a670:	mov    DWORD PTR [rsp+0x20],0x6d5
   14000a678:	lea    r9,[rip+0x11081]        # 0x14001b700
   14000a67f:	lea    r8,[rip+0xf84a]        # 0x140019ed0
   14000a686:	lea    rdx,[rip+0xf863]        # 0x140019ef0
   14000a68d:	lea    rcx,[rbp-0x58]
   14000a691:	call   0x14000f3ac
   14000a696:	mov    rdx,rax
   14000a699:	lea    rcx,[rbp+0x60]
   14000a69d:	call   0x1400038ec
   14000a6a2:	mov    DWORD PTR [rsp+0x20],eax
   14000a6a6:	lea    r9,[rip+0xf8e3]        # 0x140019f90
   14000a6ad:	mov    r8d,eax
   14000a6b0:	lea    rcx,[rbp+0x60]
   14000a6b4:	call   0x1400106b0
   14000a6b9:	int3
   14000a6ba:	mov    DWORD PTR [rsp+0x28],edi
   14000a6be:	mov    DWORD PTR [rsp+0x20],0x6fa
   14000a6c6:	lea    r9,[rip+0x11033]        # 0x14001b700
   14000a6cd:	lea    r8,[rip+0xf7fc]        # 0x140019ed0
   14000a6d4:	lea    rdx,[rip+0xf815]        # 0x140019ef0
   14000a6db:	lea    rcx,[rbp-0x58]
   14000a6df:	call   0x14000f3ac
   14000a6e4:	mov    rdi,rax
   14000a6e7:	rex.W call QWORD PTR [rip+0xd88a]        # 0x140017f78
   14000a6ee:	nop    DWORD PTR [rax+rax*1+0x0]
   14000a6f3:	mov    ebx,eax
   14000a6f5:	mov    edx,0x3
   14000a6fa:	mov    rcx,rsi
   14000a6fd:	call   0x1400038f8
   14000a702:	mov    DWORD PTR [rsp+0x28],ebx
   14000a706:	mov    QWORD PTR [rsp+0x20],rax
   14000a70b:	lea    r9,[rip+0x1156e]        # 0x14001bc80
   14000a712:	mov    r8d,0x80042308
   14000a718:	mov    rdx,rdi
   14000a71b:	lea    rcx,[rbp+0x60]
   14000a71f:	call   0x1400106b0
   14000a724:	nop
   14000a725:	lea    rdx,[rbp-0x58]
   14000a729:	lea    rcx,[rbp+0xd8]
   14000a730:	call   0x14000f400
   14000a735:	lea    r9,[rip+0x10284]        # 0x14001a9c0
   14000a73c:	mov    r8d,edi
   14000a73f:	mov    rdx,rax
   14000a742:	lea    rcx,[rbp+0x60]
   14000a746:	call   0x140010848
   14000a74b:	nop
   14000a74c:	mov    DWORD PTR [rsp+0x28],0x7
   14000a754:	mov    DWORD PTR [rsp+0x20],0x70a
   14000a75c:	lea    r9,[rip+0x10f9d]        # 0x14001b700
   14000a763:	lea    r8,[rip+0xf766]        # 0x140019ed0
   14000a76a:	mov    rdx,rsi
   14000a76d:	lea    rcx,[rbp+0xd8]
   14000a774:	call   0x14000f3ac
   14000a779:	mov    rdx,rax
   14000a77c:	lea    rcx,[rbp+0x60]
   14000a780:	call   0x1400038ec
   14000a785:	mov    DWORD PTR [rsp+0x20],eax
   14000a789:	lea    r9,[rip+0xe218]        # 0x1400189a8
   14000a790:	mov    r8d,eax
   14000a793:	lea    rcx,[rbp+0x60]
   14000a797:	call   0x1400106b0
   14000a79c:	nop
   14000a79d:	mov    DWORD PTR [rsp+0x50],0x8007000e
   14000a7a5:	lea    rdx,[rip+0x1786c]        # 0x140022018
   14000a7ac:	lea    rcx,[rsp+0x50]
   14000a7b1:	call   0x14001478c
   14000a7b6:	nop
   14000a7b7:	mov    DWORD PTR [rsp+0x50],0x8007000e
   14000a7bf:	lea    rdx,[rip+0x17852]        # 0x140022018
   14000a7c6:	lea    rcx,[rsp+0x50]
   14000a7cb:	call   0x14001478c
   14000a7d0:	nop
   14000a7d1:	mov    DWORD PTR [rsp+0x28],0x7
   14000a7d9:	mov    DWORD PTR [rsp+0x20],0x6e0
   14000a7e1:	lea    r9,[rip+0x10f18]        # 0x14001b700
   14000a7e8:	lea    r8,[rip+0xf6e1]        # 0x140019ed0
   14000a7ef:	lea    rdx,[rip+0xf6fa]        # 0x140019ef0
   14000a7f6:	lea    rcx,[rbp+0xd8]
   14000a7fd:	call   0x14000f3ac
   14000a802:	lea    r9,[rip+0x10f47]        # 0x14001b750
   14000a809:	mov    r8d,edi
   14000a80c:	mov    rdx,rax
   14000a80f:	lea    rcx,[rbp+0x60]
   14000a813:	call   0x1400106b0
   14000a818:	int3
   14000a819:	int3
   14000a81a:	int3
   14000a81b:	int3
   14000a81c:	int3
   14000a81d:	int3
   14000a81e:	int3
   14000a81f:	int3
   14000a820:	mov    rax,rsp
   14000a823:	push   rbp
   14000a824:	push   rsi
   14000a825:	push   rdi
   14000a826:	push   r12
   14000a828:	push   r13
   14000a82a:	push   r14
   14000a82c:	push   r15
   14000a82e:	lea    rbp,[rax-0xe8]
   14000a835:	sub    rsp,0x1b0
   14000a83c:	mov    QWORD PTR [rbp+0x18],0xfffffffffffffffe
   14000a844:	mov    QWORD PTR [rax+0x8],rbx
   14000a848:	mov    rax,QWORD PTR [rip+0x198c9]        # 0x140024118
   14000a84f:	xor    rax,rsp
   14000a852:	mov    QWORD PTR [rbp+0xa0],rax
   14000a859:	mov    r15,r8
   14000a85c:	mov    r14,rdx
   14000a85f:	lea    r13,[rip+0xf68a]        # 0x140019ef0
   14000a866:	mov    QWORD PTR [rsp+0x70],r13
   14000a86b:	lea    rax,[rip+0x10fae]        # 0x14001b820
   14000a872:	mov    QWORD PTR [rsp+0x78],rax
   14000a877:	lea    rax,[rip+0xf652]        # 0x140019ed0
   14000a87e:	mov    QWORD PTR [rbp-0x80],rax
   14000a882:	mov    DWORD PTR [rbp-0x78],0x747
   14000a889:	mov    DWORD PTR [rbp-0x74],0x7
   14000a890:	mov    edi,0xff
   14000a895:	mov    DWORD PTR [rbp-0x70],edi
   14000a898:	xor    r12d,r12d
   14000a89b:	mov    DWORD PTR [rbp+0x10],0x1000000
   14000a8a2:	lea    ebx,[r12+0x78]
   14000a8a7:	mov    r8d,ebx
   14000a8aa:	xor    edx,edx
   14000a8ac:	lea    rcx,[rbp-0x68]
   14000a8b0:	call   0x140015692
   14000a8b5:	lea    rdx,[rsp+0x70]
   14000a8ba:	lea    rcx,[rbp+0x20]
   14000a8be:	call   0x14000f85c
   14000a8c3:	nop
   14000a8c4:	mov    DWORD PTR [rsp+0x40],r12d
   14000a8c9:	mov    esi,r12d
   14000a8cc:	movups xmm0,XMMWORD PTR [rip+0xdadd]        # 0x1400183b0
   14000a8d3:	movdqu XMMWORD PTR [rbp+0x90],xmm0
   14000a8db:	mov    QWORD PTR [rsp+0x48],r12
   14000a8e0:	movups xmm0,XMMWORD PTR [rip+0xe789]        # 0x140019070
   14000a8e7:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   14000a8ed:	movups xmm1,XMMWORD PTR [rip+0xe76c]        # 0x140019060
   14000a8f4:	movdqu XMMWORD PTR [rsp+0x60],xmm1
   14000a8fa:	mov    QWORD PTR [rsp+0x70],r13
   14000a8ff:	lea    rax,[rip+0x10f1a]        # 0x14001b820
   14000a906:	mov    QWORD PTR [rsp+0x78],rax
   14000a90b:	lea    rax,[rip+0xf5be]        # 0x140019ed0
   14000a912:	mov    QWORD PTR [rbp-0x80],rax
   14000a916:	mov    DWORD PTR [rbp-0x78],0x752
   14000a91d:	mov    DWORD PTR [rbp-0x74],0x7
   14000a924:	mov    DWORD PTR [rbp-0x70],edi
   14000a927:	mov    DWORD PTR [rbp+0x10],0x1000000
   14000a92e:	mov    r8d,ebx
   14000a931:	xor    edx,edx
   14000a933:	lea    rcx,[rbp-0x68]
   14000a937:	call   0x140015692
   14000a93c:	lea    rax,[rsp+0x48]
   14000a941:	mov    QWORD PTR [rsp+0x30],rax
   14000a946:	lea    rax,[rsp+0x50]
   14000a94b:	mov    QWORD PTR [rsp+0x28],rax
   14000a950:	lea    r9,[rip+0xdff1]        # 0x140018948
   14000a957:	lea    r8,[rsp+0x60]
   14000a95c:	lea    rdx,[rsp+0x70]
   14000a961:	lea    rcx,[rbp+0x20]
   14000a965:	call   0x140011460
   14000a96a:	cmp    DWORD PTR [rbp+0x28],r12d
   14000a96e:	jl     0x14000aab4
   14000a974:	mov    rcx,QWORD PTR [rsp+0x48]
   14000a979:	mov    rax,QWORD PTR [rcx]
   14000a97c:	or     edx,0xffffffff
   14000a97f:	mov    rax,QWORD PTR [rax+0x18]
   14000a983:	call   QWORD PTR [rip+0xd90f]        # 0x140018298
   14000a989:	mov    DWORD PTR [rbp+0x28],eax
   14000a98c:	test   eax,eax
   14000a98e:	js     0x14000ab03
   14000a994:	mov    ebx,r12d
   14000a997:	mov    eax,DWORD PTR [r14+0x8]
   14000a99b:	test   eax,eax
   14000a99d:	jle    0x14000aa10
   14000a99f:	mov    edi,r12d
   14000a9a2:	test   rdi,rdi
   14000a9a5:	js     0x14000aaae
   14000a9ab:	cmp    ebx,eax
   14000a9ad:	jge    0x14000aaae
   14000a9b3:	mov    rax,QWORD PTR [r14]
   14000a9b6:	movups xmm0,XMMWORD PTR [rdi+rax*1]
   14000a9ba:	movdqu XMMWORD PTR [rsp+0x60],xmm0
   14000a9c0:	mov    rcx,QWORD PTR [rsp+0x48]
   14000a9c5:	mov    rax,QWORD PTR [rcx]
   14000a9c8:	lea    rdx,[rbp+0x90]
   14000a9cf:	mov    QWORD PTR [rsp+0x28],rdx
   14000a9d4:	lea    rdx,[rsp+0x40]
   14000a9d9:	mov    QWORD PTR [rsp+0x20],rdx
   14000a9de:	mov    r9d,0x1
   14000a9e4:	lea    r8d,[r9+0x2]
   14000a9e8:	lea    rdx,[rsp+0x60]
   14000a9ed:	mov    rax,QWORD PTR [rax+0x58]
   14000a9f1:	call   QWORD PTR [rip+0xd8a1]        # 0x140018298
   14000a9f7:	mov    DWORD PTR [rbp+0x28],eax
   14000a9fa:	test   eax,eax
   14000a9fc:	js     0x14000aa5f
   14000a9fe:	add    esi,DWORD PTR [rsp+0x40]
   14000aa02:	inc    ebx
   14000aa04:	add    rdi,0x10
   14000aa08:	mov    eax,DWORD PTR [r14+0x8]
   14000aa0c:	cmp    ebx,eax
   14000aa0e:	jl     0x14000a9a2
   14000aa10:	mov    DWORD PTR [r15],esi
   14000aa13:	mov    rcx,QWORD PTR [rsp+0x48]
   14000aa18:	test   rcx,rcx
   14000aa1b:	je     0x14000aa2b
   14000aa1d:	mov    rax,QWORD PTR [rcx]
   14000aa20:	mov    rax,QWORD PTR [rax+0x10]
   14000aa24:	call   QWORD PTR [rip+0xd86e]        # 0x140018298
   14000aa2a:	nop
   14000aa2b:	lea    rcx,[rbp+0x20]
   14000aa2f:	call   0x14000f958
   14000aa34:	mov    rcx,QWORD PTR [rbp+0xa0]
   14000aa3b:	xor    rcx,rsp
   14000aa3e:	call   0x1400143c0
   14000aa43:	mov    rbx,QWORD PTR [rsp+0x1f0]
   14000aa4b:	add    rsp,0x1b0
   14000aa52:	pop    r15
   14000aa54:	pop    r14
   14000aa56:	pop    r13
   14000aa58:	pop    r12
   14000aa5a:	pop    rdi
   14000aa5b:	pop    rsi
   14000aa5c:	pop    rbp
   14000aa5d:	ret
   14000aa5e:	int3
   14000aa5f:	mov    DWORD PTR [rsp+0x28],0x7
   14000aa67:	mov    DWORD PTR [rsp+0x20],0x76a
   14000aa6f:	lea    r9,[rip+0x10daa]        # 0x14001b820
   14000aa76:	lea    r8,[rip+0xf453]        # 0x140019ed0
   14000aa7d:	mov    rdx,r13
   14000aa80:	lea    rcx,[rsp+0x70]
   14000aa85:	call   0x14000f3ac
   14000aa8a:	mov    rdx,rax
   14000aa8d:	lea    rcx,[rbp+0x20]
   14000aa91:	call   0x1400038ec
   14000aa96:	mov    DWORD PTR [rsp+0x20],eax
   14000aa9a:	lea    r9,[rip+0x10dcf]        # 0x14001b870
   14000aaa1:	mov    r8d,eax
   14000aaa4:	lea    rcx,[rbp+0x20]
   14000aaa8:	call   0x1400106b0
   14000aaad:	int3
   14000aaae:	call   0x14000b730
   14000aab3:	int3
   14000aab4:	mov    DWORD PTR [rsp+0x28],0x7
   14000aabc:	mov    DWORD PTR [rsp+0x20],0x759
   14000aac4:	lea    r9,[rip+0x10d55]        # 0x14001b820
   14000aacb:	lea    r8,[rip+0xf3fe]        # 0x140019ed0
   14000aad2:	mov    rdx,r13
   14000aad5:	lea    rcx,[rsp+0x70]
   14000aada:	call   0x14000f3ac
   14000aadf:	mov    rdx,rax
   14000aae2:	lea    rcx,[rbp+0x20]
   14000aae6:	call   0x1400038ec
   14000aaeb:	mov    DWORD PTR [rsp+0x20],eax
   14000aaef:	lea    r9,[rip+0xde6a]        # 0x140018960
   14000aaf6:	mov    r8d,eax
   14000aaf9:	lea    rcx,[rbp+0x20]
   14000aafd:	call   0x1400106b0
   14000ab02:	int3
   14000ab03:	mov    DWORD PTR [rsp+0x28],0x7
   14000ab0b:	mov    DWORD PTR [rsp+0x20],0x75e
   14000ab13:	lea    r9,[rip+0x10d06]        # 0x14001b820
   14000ab1a:	lea    r8,[rip+0xf3af]        # 0x140019ed0
   14000ab21:	mov    rdx,r13
   14000ab24:	lea    rcx,[rsp+0x70]
   14000ab29:	call   0x14000f3ac
   14000ab2e:	mov    rdx,rax
   14000ab31:	lea    rcx,[rbp+0x20]
   14000ab35:	call   0x1400038ec
   14000ab3a:	mov    DWORD PTR [rsp+0x20],eax
   14000ab3e:	lea    r9,[rip+0xf44b]        # 0x140019f90
   14000ab45:	mov    r8d,eax
   14000ab48:	lea    rcx,[rbp+0x20]
   14000ab4c:	call   0x1400106b0
   14000ab51:	int3
   14000ab52:	int3
   14000ab53:	int3
   14000ab54:	int3
   14000ab55:	int3
   14000ab56:	int3
   14000ab57:	int3
   14000ab58:	mov    rax,rsp
   14000ab5b:	push   rbp
   14000ab5c:	push   rdi
   14000ab5d:	push   r12
   14000ab5f:	push   r14
   14000ab61:	push   r15
   14000ab63:	lea    rbp,[rax-0xf8]
   14000ab6a:	sub    rsp,0x1d0
   14000ab71:	mov    QWORD PTR [rbp+0xa0],0xfffffffffffffffe
   14000ab7c:	mov    QWORD PTR [rax+0x10],rbx
   14000ab80:	mov    QWORD PTR [rax+0x18],rsi
   14000ab84:	mov    rax,QWORD PTR [rip+0x1958d]        # 0x140024118
   14000ab8b:	xor    rax,rsp
   14000ab8e:	mov    QWORD PTR [rbp+0xc0],rax
   14000ab95:	mov    rbx,rcx
   14000ab98:	lea    rax,[rip+0xf351]        # 0x140019ef0
   14000ab9f:	mov    QWORD PTR [rbp-0x80],rax
   14000aba3:	lea    rax,[rip+0x10d1e]        # 0x14001b8c8
   14000abaa:	mov    QWORD PTR [rbp-0x78],rax
   14000abae:	lea    rax,[rip+0xf31b]        # 0x140019ed0
   14000abb5:	mov    QWORD PTR [rbp-0x70],rax
   14000abb9:	mov    DWORD PTR [rbp-0x68],0x777
   14000abc0:	mov    DWORD PTR [rbp-0x64],0x7
   14000abc7:	mov    DWORD PTR [rbp-0x60],0xff
   14000abce:	xor    r12d,r12d
   14000abd1:	mov    DWORD PTR [rbp+0x20],0x1000000
   14000abd8:	xor    edx,edx
   14000abda:	lea    r8d,[r12+0x78]
   14000abdf:	lea    rcx,[rbp-0x58]
   14000abe3:	call   0x140015692
   14000abe8:	lea    rdx,[rbp-0x80]
   14000abec:	lea    rcx,[rbp+0x30]
   14000abf0:	call   0x14000f85c
   14000abf5:	nop
   14000abf6:	mov    r14d,r12d
   14000abf9:	lea    edx,[r12+0x2]
   14000abfe:	mov    rcx,rbx
   14000ac01:	call   0x1400038f8
   14000ac06:	mov    rdi,rax
   14000ac09:	lea    edx,[r12+0xb]
   14000ac0e:	mov    rcx,rbx
   14000ac11:	call   0x1400038f8
   14000ac16:	mov    r15,rax
   14000ac19:	lea    esi,[r12+0x1]
   14000ac1e:	test   rdi,rdi
   14000ac21:	je     0x14000ac44
   14000ac23:	or     rcx,0xffffffffffffffff
   14000ac27:	inc    rcx
   14000ac2a:	cmp    WORD PTR [rdi+rcx*2],r12w
   14000ac2f:	jne    0x14000ac27
   14000ac31:	cmp    rcx,0x2
   14000ac35:	jb     0x14000ac44
   14000ac37:	cmp    WORD PTR [rdi+0x2],0x3a
   14000ac3c:	jne    0x14000ac44
   14000ac3e:	mov    r14d,esi
   14000ac41:	mov    esi,r12d
   14000ac44:	movups xmm0,XMMWORD PTR [rip+0xd765]        # 0x1400183b0
   14000ac4b:	movdqu XMMWORD PTR [rbp+0xb0],xmm0
   14000ac53:	mov    edx,0xc
   14000ac58:	mov    rcx,rbx
   14000ac5b:	call   0x1400038f8
   14000ac60:	mov    rdx,rax
   14000ac63:	lea    r8,[rbp+0xb0]
   14000ac6a:	call   0x14000c630
   14000ac6f:	test   al,al
   14000ac71:	je     0x14000af11
   14000ac77:	movaps xmm0,XMMWORD PTR [rbp+0xb0]
   14000ac7e:	movdqa XMMWORD PTR [rsp+0x50],xmm0
   14000ac84:	mov    rcx,QWORD PTR [rbx]
   14000ac87:	mov    rax,QWORD PTR [rcx]
   14000ac8a:	lea    rdx,[rbp+0x30]
   14000ac8e:	mov    QWORD PTR [rsp+0x28],rdx
   14000ac93:	mov    BYTE PTR [rsp+0x20],r14b
   14000ac98:	mov    r9,r15
   14000ac9b:	mov    r8,rdi
   14000ac9e:	lea    rdx,[rsp+0x50]
   14000aca3:	mov    rax,QWORD PTR [rax+0x60]
   14000aca7:	call   QWORD PTR [rip+0xd5eb]        # 0x140018298
   14000acad:	inc    esi
   14000acaf:	shl    esi,0x14
   14000acb2:	mov    QWORD PTR [rsp+0x40],r12
   14000acb7:	movups xmm0,XMMWORD PTR [rip+0xe3b2]        # 0x140019070
   14000acbe:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   14000acc4:	movups xmm1,XMMWORD PTR [rip+0xe395]        # 0x140019060
   14000accb:	movdqu XMMWORD PTR [rsp+0x70],xmm1
   14000acd1:	lea    r14,[rip+0xf218]        # 0x140019ef0
   14000acd8:	mov    QWORD PTR [rbp-0x80],r14
   14000acdc:	lea    rax,[rip+0x10be5]        # 0x14001b8c8
   14000ace3:	mov    QWORD PTR [rbp-0x78],rax
   14000ace7:	lea    rax,[rip+0xf1e2]        # 0x140019ed0
   14000acee:	mov    QWORD PTR [rbp-0x70],rax
   14000acf2:	mov    DWORD PTR [rbp-0x68],0x799
   14000acf9:	mov    DWORD PTR [rbp-0x64],0x7
   14000ad00:	mov    DWORD PTR [rbp-0x60],0xff
   14000ad07:	mov    DWORD PTR [rbp+0x20],0x1000000
   14000ad0e:	xor    edx,edx
   14000ad10:	lea    r8d,[rdx+0x78]
   14000ad14:	lea    rcx,[rbp-0x58]
   14000ad18:	call   0x140015692
   14000ad1d:	lea    rax,[rsp+0x40]
   14000ad22:	mov    QWORD PTR [rsp+0x30],rax
   14000ad27:	lea    rax,[rsp+0x50]
   14000ad2c:	mov    QWORD PTR [rsp+0x28],rax
   14000ad31:	lea    r9,[rip+0xdc10]        # 0x140018948
   14000ad38:	lea    r8,[rsp+0x70]
   14000ad3d:	lea    rdx,[rbp-0x80]
   14000ad41:	lea    rcx,[rbp+0x30]
   14000ad45:	call   0x140011460
   14000ad4a:	cmp    DWORD PTR [rbp+0x38],r12d
   14000ad4e:	jl     0x14000af59
   14000ad54:	mov    rcx,QWORD PTR [rsp+0x40]
   14000ad59:	mov    rax,QWORD PTR [rcx]
   14000ad5c:	or     edx,0xffffffff
   14000ad5f:	mov    rax,QWORD PTR [rax+0x18]
   14000ad63:	call   QWORD PTR [rip+0xd52f]        # 0x140018298
   14000ad69:	mov    DWORD PTR [rbp+0x38],eax
   14000ad6c:	test   eax,eax
   14000ad6e:	js     0x14000afa7
   14000ad74:	mov    QWORD PTR [rsp+0x60],r12
   14000ad79:	movaps xmm0,XMMWORD PTR [rbp+0xb0]
   14000ad80:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   14000ad86:	mov    rcx,QWORD PTR [rsp+0x40]
   14000ad8b:	mov    rax,QWORD PTR [rcx]
   14000ad8e:	lea    rdx,[rsp+0x60]
   14000ad93:	mov    QWORD PTR [rsp+0x28],rdx
   14000ad98:	mov    QWORD PTR [rsp+0x20],rdi
   14000ad9d:	mov    r9d,esi
   14000ada0:	mov    r8,r15
   14000ada3:	lea    rdx,[rsp+0x70]
   14000ada8:	mov    rax,QWORD PTR [rax+0x40]
   14000adac:	call   QWORD PTR [rip+0xd4e6]        # 0x140018298
   14000adb2:	mov    DWORD PTR [rbp+0x38],eax
   14000adb5:	test   eax,eax
   14000adb7:	jns    0x14000ae2a
   14000adb9:	cmp    eax,0x80042308
   14000adbe:	je     0x14000adf2
   14000adc0:	cmp    eax,0x8004230d
   14000adc5:	je     0x14000ade2
   14000adc7:	cmp    eax,0x80070057
   14000adcc:	jne    0x14000aec3
   14000add2:	mov    edx,0x40002bc8
   14000add7:	mov    rcx,rbx
   14000adda:	call   0x14000d524
   14000addf:	nop
   14000ade0:	jmp    0x14000ae10
   14000ade2:	mov    edx,0x40002bc9
   14000ade7:	mov    rcx,rbx
   14000adea:	call   0x14000d524
   14000adef:	nop
   14000adf0:	jmp    0x14000ae10
   14000adf2:	mov    edx,0xc
   14000adf7:	mov    rcx,rbx
   14000adfa:	call   0x1400038f8
   14000adff:	mov    r8,rax
   14000ae02:	mov    edx,0x4000275c
   14000ae07:	mov    rcx,rbx
   14000ae0a:	call   0x14000d524
   14000ae0f:	nop
   14000ae10:	mov    rcx,QWORD PTR [rsp+0x40]
   14000ae15:	test   rcx,rcx
   14000ae18:	je     0x14000ae28
   14000ae1a:	mov    rax,QWORD PTR [rcx]
   14000ae1d:	mov    rax,QWORD PTR [rax+0x10]
   14000ae21:	call   QWORD PTR [rip+0xd471]        # 0x140018298
   14000ae27:	nop
   14000ae28:	jmp    0x14000ae8e
   14000ae2a:	mov    rdi,QWORD PTR [rsp+0x60]
   14000ae2f:	mov    QWORD PTR [rsp+0x58],rdi
   14000ae34:	lea    rax,[rip+0xc225]        # 0x140017060
   14000ae3b:	mov    QWORD PTR [rsp+0x50],rax
   14000ae40:	movaps xmm0,XMMWORD PTR [rsp+0x50]
   14000ae45:	movdqa XMMWORD PTR [rsp+0x70],xmm0
   14000ae4b:	lea    r8,[rsp+0x70]
   14000ae50:	mov    edx,0x4000275e
   14000ae55:	mov    rcx,rbx
   14000ae58:	call   0x14000c6f4
   14000ae5d:	mov    DWORD PTR [rbx+0x48],r12d
   14000ae61:	test   rdi,rdi
   14000ae64:	je     0x14000ae76
   14000ae66:	mov    rcx,rdi
   14000ae69:	rex.W call QWORD PTR [rip+0xd210]        # 0x140018080
   14000ae70:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ae75:	nop
   14000ae76:	mov    rcx,QWORD PTR [rsp+0x40]
   14000ae7b:	test   rcx,rcx
   14000ae7e:	je     0x14000ae8e
   14000ae80:	mov    rax,QWORD PTR [rcx]
   14000ae83:	mov    rax,QWORD PTR [rax+0x10]
   14000ae87:	call   QWORD PTR [rip+0xd40b]        # 0x140018298
   14000ae8d:	nop
   14000ae8e:	lea    rcx,[rbp+0x30]
   14000ae92:	call   0x14000f958
   14000ae97:	mov    rcx,QWORD PTR [rbp+0xc0]
   14000ae9e:	xor    rcx,rsp
   14000aea1:	call   0x1400143c0
   14000aea6:	lea    r11,[rsp+0x1d0]
   14000aeae:	mov    rbx,QWORD PTR [r11+0x38]
   14000aeb2:	mov    rsi,QWORD PTR [r11+0x40]
   14000aeb6:	mov    rsp,r11
   14000aeb9:	pop    r15
   14000aebb:	pop    r14
   14000aebd:	pop    r12
   14000aebf:	pop    rdi
   14000aec0:	pop    rbp
   14000aec1:	ret
   14000aec2:	int3
   14000aec3:	mov    DWORD PTR [rsp+0x28],0x7
   14000aecb:	mov    DWORD PTR [rsp+0x20],0x7be
   14000aed3:	lea    r9,[rip+0x109ee]        # 0x14001b8c8
   14000aeda:	lea    r8,[rip+0xefef]        # 0x140019ed0
   14000aee1:	mov    rdx,r14
   14000aee4:	lea    rcx,[rbp-0x80]
   14000aee8:	call   0x14000f3ac
   14000aeed:	mov    rdx,rax
   14000aef0:	lea    rcx,[rbp+0x30]
   14000aef4:	call   0x1400038ec
   14000aef9:	mov    DWORD PTR [rsp+0x20],eax
   14000aefd:	lea    r9,[rip+0x10b0c]        # 0x14001ba10
   14000af04:	mov    r8d,eax
   14000af07:	lea    rcx,[rbp+0x30]
   14000af0b:	call   0x1400106b0
   14000af10:	nop
   14000af11:	mov    DWORD PTR [rsp+0x28],0x7
   14000af19:	mov    DWORD PTR [rsp+0x20],0x788
   14000af21:	lea    r9,[rip+0x109a0]        # 0x14001b8c8
   14000af28:	lea    r8,[rip+0xefa1]        # 0x140019ed0
   14000af2f:	lea    rdx,[rip+0xefba]        # 0x140019ef0
   14000af36:	lea    rcx,[rbp-0x80]
   14000af3a:	call   0x14000f3ac
   14000af3f:	lea    r9,[rip+0x109ca]        # 0x14001b910
   14000af46:	mov    r8d,0x1004
   14000af4c:	mov    rdx,rax
   14000af4f:	lea    rcx,[rbp+0x30]
   14000af53:	call   0x1400106b0
   14000af58:	nop
   14000af59:	mov    DWORD PTR [rsp+0x28],0x7
   14000af61:	mov    DWORD PTR [rsp+0x20],0x7a0
   14000af69:	lea    r9,[rip+0x10958]        # 0x14001b8c8
   14000af70:	lea    r8,[rip+0xef59]        # 0x140019ed0
   14000af77:	mov    rdx,r14
   14000af7a:	lea    rcx,[rbp-0x80]
   14000af7e:	call   0x14000f3ac
   14000af83:	mov    rdx,rax
   14000af86:	lea    rcx,[rbp+0x30]
   14000af8a:	call   0x1400038ec
   14000af8f:	mov    DWORD PTR [rsp+0x20],eax
   14000af93:	lea    r9,[rip+0xd9c6]        # 0x140018960
   14000af9a:	mov    r8d,eax
   14000af9d:	lea    rcx,[rbp+0x30]
   14000afa1:	call   0x1400106b0
   14000afa6:	int3
   14000afa7:	mov    DWORD PTR [rsp+0x28],0x7
   14000afaf:	mov    DWORD PTR [rsp+0x20],0x7a7
   14000afb7:	lea    r9,[rip+0x1090a]        # 0x14001b8c8
   14000afbe:	lea    r8,[rip+0xef0b]        # 0x140019ed0
   14000afc5:	mov    rdx,r14
   14000afc8:	lea    rcx,[rbp-0x80]
   14000afcc:	call   0x14000f3ac
   14000afd1:	mov    rdx,rax
   14000afd4:	lea    rcx,[rbp+0x30]
   14000afd8:	call   0x1400038ec
   14000afdd:	mov    DWORD PTR [rsp+0x20],eax
   14000afe1:	lea    r9,[rip+0x10998]        # 0x14001b980
   14000afe8:	mov    r8d,eax
   14000afeb:	lea    rcx,[rbp+0x30]
   14000afef:	call   0x1400106b0
   14000aff4:	int3
   14000aff5:	int3
   14000aff6:	int3
   14000aff7:	int3
   14000aff8:	int3
   14000aff9:	int3
   14000affa:	int3
   14000affb:	int3
   14000affc:	mov    rax,rsp
   14000afff:	push   rbp
   14000b000:	push   rdi
   14000b001:	push   r12
   14000b003:	push   r14
   14000b005:	push   r15
   14000b007:	lea    rbp,[rax-0x898]
   14000b00e:	sub    rsp,0x970
   14000b015:	mov    QWORD PTR [rsp+0x38],0xfffffffffffffffe
   14000b01e:	mov    QWORD PTR [rax+0x10],rbx
   14000b022:	mov    QWORD PTR [rax+0x18],rsi
   14000b026:	mov    rax,QWORD PTR [rip+0x190eb]        # 0x140024118
   14000b02d:	xor    rax,rsp
   14000b030:	mov    QWORD PTR [rbp+0x860],rax
   14000b037:	mov    esi,edx
   14000b039:	mov    rbx,rcx
   14000b03c:	lea    rax,[rip+0xeead]        # 0x140019ef0
   14000b043:	mov    QWORD PTR [rsp+0x40],rax
   14000b048:	lea    rax,[rip+0x10a21]        # 0x14001ba70
   14000b04f:	mov    QWORD PTR [rsp+0x48],rax
   14000b054:	lea    rax,[rip+0xee75]        # 0x140019ed0
   14000b05b:	mov    QWORD PTR [rsp+0x50],rax
   14000b060:	mov    DWORD PTR [rsp+0x58],0x7cf
   14000b068:	mov    DWORD PTR [rsp+0x5c],0x7
   14000b070:	mov    DWORD PTR [rsp+0x60],0xff
   14000b078:	xor    r14d,r14d
   14000b07b:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000b082:	xor    edx,edx
   14000b084:	lea    r15d,[r14+0x1]
   14000b088:	lea    r8d,[r14+0x78]
   14000b08c:	lea    rcx,[rsp+0x68]
   14000b091:	call   0x140015692
   14000b096:	lea    rdx,[rsp+0x40]
   14000b09b:	lea    rcx,[rbp-0x10]
   14000b09f:	call   0x14000f85c
   14000b0a4:	nop
   14000b0a5:	xor    edx,edx
   14000b0a7:	mov    r8d,0x800
   14000b0ad:	lea    rcx,[rbp+0x60]
   14000b0b1:	call   0x140015692
   14000b0b6:	movzx  edi,r14w
   14000b0ba:	lea    r12d,[r14+0x20]
   14000b0be:	mov    cl,dil
   14000b0c1:	mov    eax,r15d
   14000b0c4:	shl    eax,cl
   14000b0c6:	and    eax,esi
   14000b0c8:	cmp    eax,0x10000
   14000b0cd:	ja     0x14000b140
   14000b0cf:	je     0x14000b138
   14000b0d1:	mov    ecx,eax
   14000b0d3:	test   eax,eax
   14000b0d5:	je     0x14000b1c1
   14000b0db:	sub    ecx,0x1
   14000b0de:	je     0x14000b130
   14000b0e0:	sub    ecx,0x3
   14000b0e3:	je     0x14000b125
   14000b0e5:	sub    ecx,0x4
   14000b0e8:	je     0x14000b11a
   14000b0ea:	sub    ecx,0x8
   14000b0ed:	je     0x14000b10f
   14000b0ef:	sub    ecx,0x10
   14000b0f2:	je     0x14000b104
   14000b0f4:	cmp    ecx,r12d
   14000b0f7:	jne    0x14000b171
   14000b0f9:	mov    r9d,0x40002a9a
   14000b0ff:	jmp    0x14000b1b0
   14000b104:	mov    r9d,0x40002a99
   14000b10a:	jmp    0x14000b1b0
   14000b10f:	mov    r9d,0x40002a98
   14000b115:	jmp    0x14000b1b0
   14000b11a:	mov    r9d,0x40002a97
   14000b120:	jmp    0x14000b1b0
   14000b125:	mov    r9d,0x40002a96
   14000b12b:	jmp    0x14000b1b0
   14000b130:	mov    r9d,0x40002a94
   14000b136:	jmp    0x14000b1b0
   14000b138:	mov    r9d,0x40002a9b
   14000b13e:	jmp    0x14000b1b0
   14000b140:	cmp    eax,0x20000
   14000b145:	je     0x14000b1aa
   14000b147:	cmp    eax,0x40000
   14000b14c:	je     0x14000b1a2
   14000b14e:	cmp    eax,0x80000
   14000b153:	je     0x14000b19a
   14000b155:	cmp    eax,0x100000
   14000b15a:	je     0x14000b192
   14000b15c:	cmp    eax,0x200000
   14000b161:	je     0x14000b18a
   14000b163:	cmp    eax,0x400000
   14000b168:	je     0x14000b182
   14000b16a:	cmp    eax,0x800000
   14000b16f:	je     0x14000b17a
   14000b171:	mov    DWORD PTR [rsp+0x20],eax
   14000b175:	xor    r9d,r9d
   14000b178:	jmp    0x14000b1b5
   14000b17a:	mov    r9d,0x40002b0b
   14000b180:	jmp    0x14000b1b0
   14000b182:	mov    r9d,0x40002b0a
   14000b188:	jmp    0x14000b1b0
   14000b18a:	mov    r9d,0x40002aa0
   14000b190:	jmp    0x14000b1b0
   14000b192:	mov    r9d,0x40002a9f
   14000b198:	jmp    0x14000b1b0
   14000b19a:	mov    r9d,0x40002a9e
   14000b1a0:	jmp    0x14000b1b0
   14000b1a2:	mov    r9d,0x40002a9d
   14000b1a8:	jmp    0x14000b1b0
   14000b1aa:	mov    r9d,0x40002a9c
   14000b1b0:	mov    DWORD PTR [rsp+0x20],r14d
   14000b1b5:	lea    rdx,[rbp+0x60]
   14000b1b9:	mov    rcx,rbx
   14000b1bc:	call   0x14000c9e4
   14000b1c1:	add    di,r15w
   14000b1c5:	cmp    di,r12w
   14000b1c9:	jb     0x14000b0be
   14000b1cf:	cmp    WORD PTR [rbp+0x60],r14w
   14000b1d4:	jne    0x14000b1ed
   14000b1d6:	mov    DWORD PTR [rsp+0x20],r14d
   14000b1db:	mov    r9d,0x40002aa1
   14000b1e1:	lea    rdx,[rbp+0x60]
   14000b1e5:	mov    rcx,rbx
   14000b1e8:	call   0x14000c9e4
   14000b1ed:	mov    QWORD PTR [rsp+0x30],r14
   14000b1f2:	lea    r8,[rbp+0x60]
   14000b1f6:	lea    rdx,[rsp+0x30]
   14000b1fb:	lea    rcx,[rbp-0x10]
   14000b1ff:	call   0x140003688
   14000b204:	nop
   14000b205:	lea    rcx,[rbp-0x10]
   14000b209:	call   0x14000f958
   14000b20e:	mov    rax,QWORD PTR [rsp+0x30]
   14000b213:	mov    rcx,QWORD PTR [rbp+0x860]
   14000b21a:	xor    rcx,rsp
   14000b21d:	call   0x1400143c0
   14000b222:	lea    r11,[rsp+0x970]
   14000b22a:	mov    rbx,QWORD PTR [r11+0x38]
   14000b22e:	mov    rsi,QWORD PTR [r11+0x40]
   14000b232:	mov    rsp,r11
   14000b235:	pop    r15
   14000b237:	pop    r14
   14000b239:	pop    r12
   14000b23b:	pop    rdi
   14000b23c:	pop    rbp
   14000b23d:	ret
   14000b23e:	int3
   14000b23f:	int3
   14000b240:	int3
   14000b241:	int3
   14000b242:	int3
   14000b243:	int3
   14000b244:	int3
   14000b245:	int3
   14000b246:	int3
   14000b247:	int3
   14000b248:	mov    rax,rsp
   14000b24b:	push   rbp
   14000b24c:	push   r12
   14000b24e:	push   r13
   14000b250:	push   r14
   14000b252:	push   r15
   14000b254:	lea    rbp,[rsp-0x60]
   14000b259:	sub    rsp,0x160
   14000b260:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000b269:	mov    QWORD PTR [rax+0x10],rbx
   14000b26d:	mov    QWORD PTR [rax+0x18],rsi
   14000b271:	mov    QWORD PTR [rax+0x20],rdi
   14000b275:	mov    rsi,rdx
   14000b278:	lea    r12,[rip+0xec71]        # 0x140019ef0
   14000b27f:	mov    QWORD PTR [rsp+0x48],r12
   14000b284:	lea    r13,[rip+0x10855]        # 0x14001bae0
   14000b28b:	mov    QWORD PTR [rsp+0x50],r13
   14000b290:	lea    rbx,[rip+0xec39]        # 0x140019ed0
   14000b297:	mov    QWORD PTR [rsp+0x58],rbx
   14000b29c:	mov    DWORD PTR [rsp+0x60],0x82c
   14000b2a4:	mov    DWORD PTR [rsp+0x64],0x7
   14000b2ac:	mov    DWORD PTR [rsp+0x68],0xff
   14000b2b4:	xor    r14d,r14d
   14000b2b7:	mov    DWORD PTR [rbp-0x18],0x1000000
   14000b2be:	xor    edx,edx
   14000b2c0:	lea    r8d,[r14+0x78]
   14000b2c4:	lea    rcx,[rsp+0x70]
   14000b2c9:	call   0x140015692
   14000b2ce:	lea    rdx,[rsp+0x48]
   14000b2d3:	lea    rcx,[rbp-0x10]
   14000b2d7:	call   0x14000f85c
   14000b2dc:	nop
   14000b2dd:	test   rsi,rsi
   14000b2e0:	je     0x14000b35e
   14000b2e2:	cmp    WORD PTR [rsi],r14w
   14000b2e6:	je     0x14000b35e
   14000b2e8:	mov    edi,r14d
   14000b2eb:	lea    r15,[rip+0xbefe]        # 0x1400171f0
   14000b2f2:	cmp    QWORD PTR [rip+0xbef7],r14        # 0x1400171f0
   14000b2f9:	je     0x14000b33f
   14000b2fb:	mov    ebx,r14d
   14000b2fe:	mov    ecx,r14d
   14000b301:	mov    eax,DWORD PTR [rcx+r15*1+0x8]
   14000b306:	test   DWORD PTR [rip+0x19400],eax        # 0x14002470c
   14000b30c:	je     0x14000b325
   14000b30e:	mov    rdx,QWORD PTR [rcx+r15*1]
   14000b312:	mov    rcx,rsi
   14000b315:	rex.W call QWORD PTR [rip+0xcf54]        # 0x140018270
   14000b31c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b321:	test   eax,eax
   14000b323:	je     0x14000b338
   14000b325:	inc    edi
   14000b327:	inc    rbx
   14000b32a:	lea    rcx,[rbx+rbx*2]
   14000b32e:	shl    rcx,0x3
   14000b332:	cmp    QWORD PTR [rcx+r15*1],r14
   14000b336:	jne    0x14000b301
   14000b338:	lea    rbx,[rip+0xeb91]        # 0x140019ed0
   14000b33f:	movsxd rax,edi
   14000b342:	lea    rcx,[rax+rax*2]
   14000b346:	cmp    QWORD PTR [r15+rcx*8],r14
   14000b34a:	je     0x14000b38c
   14000b34c:	mov    ebx,DWORD PTR [r15+rcx*8+0xc]
   14000b351:	lea    rcx,[rbp-0x10]
   14000b355:	call   0x14000f958
   14000b35a:	mov    eax,ebx
   14000b35c:	jmp    0x14000b36a
   14000b35e:	lea    rcx,[rbp-0x10]
   14000b362:	call   0x14000f958
   14000b367:	or     eax,0xffffffff
   14000b36a:	lea    r11,[rsp+0x160]
   14000b372:	mov    rbx,QWORD PTR [r11+0x38]
   14000b376:	mov    rsi,QWORD PTR [r11+0x40]
   14000b37a:	mov    rdi,QWORD PTR [r11+0x48]
   14000b37e:	mov    rsp,r11
   14000b381:	pop    r15
   14000b383:	pop    r14
   14000b385:	pop    r13
   14000b387:	pop    r12
   14000b389:	pop    rbp
   14000b38a:	ret
   14000b38b:	int3
   14000b38c:	mov    DWORD PTR [rsp+0x28],0x7
   14000b394:	mov    DWORD PTR [rsp+0x20],0x844
   14000b39c:	mov    r9,r13
   14000b39f:	mov    r8,rbx
   14000b3a2:	mov    rdx,r12
   14000b3a5:	lea    rcx,[rsp+0x48]
   14000b3aa:	call   0x14000f3ac
   14000b3af:	mov    QWORD PTR [rsp+0x20],rsi
   14000b3b4:	lea    r9,[rip+0x10775]        # 0x14001bb30
   14000b3bb:	mov    r8d,0x1004
   14000b3c1:	mov    rdx,rax
   14000b3c4:	lea    rcx,[rbp-0x10]
   14000b3c8:	call   0x1400106b0
   14000b3cd:	int3
   14000b3ce:	int3
   14000b3cf:	int3
   14000b3d0:	int3
   14000b3d1:	int3
   14000b3d2:	int3
   14000b3d3:	int3
   14000b3d4:	mov    rax,rsp
   14000b3d7:	push   rbp
   14000b3d8:	push   rdi
   14000b3d9:	push   r12
   14000b3db:	push   r14
   14000b3dd:	push   r15
   14000b3df:	lea    rbp,[rsp-0x60]
   14000b3e4:	sub    rsp,0x160
   14000b3eb:	mov    QWORD PTR [rbp-0x18],0xfffffffffffffffe
   14000b3f3:	mov    QWORD PTR [rax+0x8],rbx
   14000b3f7:	mov    QWORD PTR [rax+0x10],rsi
   14000b3fb:	mov    ebx,edx
   14000b3fd:	mov    rdi,rcx
   14000b400:	lea    r14,[rip+0xeae9]        # 0x140019ef0
   14000b407:	mov    QWORD PTR [rsp+0x40],r14
   14000b40c:	lea    r15,[rip+0x106cd]        # 0x14001bae0
   14000b413:	mov    QWORD PTR [rsp+0x48],r15
   14000b418:	lea    r12,[rip+0xeab1]        # 0x140019ed0
   14000b41f:	mov    QWORD PTR [rsp+0x50],r12
   14000b424:	mov    DWORD PTR [rsp+0x58],0x853
   14000b42c:	mov    DWORD PTR [rsp+0x5c],0x7
   14000b434:	mov    DWORD PTR [rsp+0x60],0xff
   14000b43c:	xor    esi,esi
   14000b43e:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000b445:	xor    edx,edx
   14000b447:	lea    r8d,[rsi+0x78]
   14000b44b:	lea    rcx,[rsp+0x68]
   14000b450:	call   0x140015692
   14000b455:	lea    rdx,[rsp+0x40]
   14000b45a:	lea    rcx,[rbp-0x10]
   14000b45e:	call   0x14000f85c
   14000b463:	nop
   14000b464:	mov    QWORD PTR [rbp+0xa0],rsi
   14000b46b:	mov    r8d,esi
   14000b46e:	lea    r9,[rip+0xbd7b]        # 0x1400171f0
   14000b475:	cmp    QWORD PTR [rip+0xbd74],rsi        # 0x1400171f0
   14000b47c:	je     0x14000b4a2
   14000b47e:	mov    ecx,esi
   14000b480:	mov    eax,esi
   14000b482:	mov    edx,ebx
   14000b484:	and    edx,0x1f
   14000b487:	cmp    DWORD PTR [rax+r9*1+0xc],edx
   14000b48c:	je     0x14000b4a2
   14000b48e:	inc    r8d
   14000b491:	inc    rcx
   14000b494:	lea    rax,[rcx+rcx*2]
   14000b498:	shl    rax,0x3
   14000b49c:	cmp    QWORD PTR [rax+r9*1],rsi
   14000b4a0:	jne    0x14000b487
   14000b4a2:	movsxd rax,r8d
   14000b4a5:	lea    rcx,[rax+rax*2]
   14000b4a9:	mov    r8,QWORD PTR [r9+rcx*8]
   14000b4ad:	test   r8,r8
   14000b4b0:	jne    0x14000b52e
   14000b4b2:	mov    QWORD PTR [rsp+0x40],r14
   14000b4b7:	mov    QWORD PTR [rsp+0x48],r15
   14000b4bc:	mov    QWORD PTR [rsp+0x50],r12
   14000b4c1:	mov    DWORD PTR [rsp+0x58],0x863
   14000b4c9:	mov    DWORD PTR [rsp+0x5c],0x7
   14000b4d1:	mov    DWORD PTR [rsp+0x60],0xff
   14000b4d9:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000b4e0:	xor    edx,edx
   14000b4e2:	lea    r8d,[rdx+0x78]
   14000b4e6:	lea    rcx,[rsp+0x68]
   14000b4eb:	call   0x140015692
   14000b4f0:	mov    r9d,ebx
   14000b4f3:	lea    r8,[rip+0x106a6]        # 0x14001bba0
   14000b4fa:	lea    rdx,[rsp+0x40]
   14000b4ff:	lea    rcx,[rbp-0x10]
   14000b503:	call   0x140010510
   14000b508:	xor    edx,edx
   14000b50a:	mov    r8d,0x40002713
   14000b510:	mov    rcx,rdi
   14000b513:	call   0x14000c86c
   14000b518:	mov    rbx,rax
   14000b51b:	test   rax,rax
   14000b51e:	je     0x14000b56c
   14000b520:	lea    rcx,[rbp-0x10]
   14000b524:	call   0x14000f958
   14000b529:	mov    rax,rbx
   14000b52c:	jmp    0x14000b54f
   14000b52e:	lea    rdx,[rbp+0xa0]
   14000b535:	lea    rcx,[rbp-0x10]
   14000b539:	call   0x140003688
   14000b53e:	nop
   14000b53f:	lea    rcx,[rbp-0x10]
   14000b543:	call   0x14000f958
   14000b548:	mov    rax,QWORD PTR [rbp+0xa0]
   14000b54f:	lea    r11,[rsp+0x160]
   14000b557:	mov    rbx,QWORD PTR [r11+0x30]
   14000b55b:	mov    rsi,QWORD PTR [r11+0x38]
   14000b55f:	mov    rsp,r11
   14000b562:	pop    r15
   14000b564:	pop    r14
   14000b566:	pop    r12
   14000b568:	pop    rdi
   14000b569:	pop    rbp
   14000b56a:	ret
   14000b56b:	int3
   14000b56c:	mov    DWORD PTR [rsp+0x28],0x7
   14000b574:	mov    DWORD PTR [rsp+0x20],0x868
   14000b57c:	mov    r9,r15
   14000b57f:	mov    r8,r12
   14000b582:	mov    rdx,r14
   14000b585:	lea    rcx,[rsp+0x40]
   14000b58a:	call   0x14000f3ac
   14000b58f:	mov    rbx,rax
   14000b592:	rex.W call QWORD PTR [rip+0xc9df]        # 0x140017f78
   14000b599:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b59e:	mov    DWORD PTR [rsp+0x28],eax
   14000b5a2:	mov    DWORD PTR [rsp+0x20],0x40002713
   14000b5aa:	lea    r9,[rip+0xd8ef]        # 0x140018ea0
   14000b5b1:	mov    r8d,0x8000ffff
   14000b5b7:	mov    rdx,rbx
   14000b5ba:	lea    rcx,[rbp-0x10]
   14000b5be:	call   0x1400106b0
   14000b5c3:	int3
   14000b5c4:	int3
   14000b5c5:	int3
   14000b5c6:	int3
   14000b5c7:	int3
   14000b5c8:	int3
   14000b5c9:	int3
   14000b5ca:	int3
   14000b5cb:	int3
   14000b5cc:	rex push rbx
   14000b5ce:	sub    rsp,0x20
   14000b5d2:	lea    rax,[rip+0xbbef]        # 0x1400171c8
   14000b5d9:	mov    rbx,rcx
   14000b5dc:	mov    QWORD PTR [rcx],rax
   14000b5df:	mov    rcx,QWORD PTR [rcx+0x8]
   14000b5e3:	cmp    rcx,0xffffffffffffffff
   14000b5e7:	je     0x14000b5f5
   14000b5e9:	rex.W call QWORD PTR [rip+0xc888]        # 0x140017e78
   14000b5f0:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b5f5:	or     QWORD PTR [rbx+0x8],0xffffffffffffffff
   14000b5fa:	lea    rax,[rip+0xba67]        # 0x140017068
   14000b601:	mov    QWORD PTR [rbx],rax
   14000b604:	add    rsp,0x20
   14000b608:	pop    rbx
   14000b609:	ret
   14000b60a:	int3
   14000b60b:	int3
   14000b60c:	int3
   14000b60d:	int3
   14000b60e:	int3
   14000b60f:	int3
   14000b610:	int3
   14000b611:	int3
   14000b612:	int3
   14000b613:	int3
   14000b614:	rex push rbx
   14000b616:	sub    rsp,0x20
   14000b61a:	lea    rax,[rip+0xbb9f]        # 0x1400171c0
   14000b621:	mov    rbx,rcx
   14000b624:	mov    QWORD PTR [rcx],rax
   14000b627:	mov    rcx,QWORD PTR [rcx+0x8]
   14000b62b:	test   rcx,rcx
   14000b62e:	je     0x14000b63c
   14000b630:	rex.W call QWORD PTR [rip+0xc999]        # 0x140017fd0
   14000b637:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b63c:	and    QWORD PTR [rbx+0x8],0x0
   14000b641:	lea    rax,[rip+0xba20]        # 0x140017068
   14000b648:	mov    QWORD PTR [rbx],rax
   14000b64b:	add    rsp,0x20
   14000b64f:	pop    rbx
   14000b650:	ret
   14000b651:	int3
   14000b652:	int3
   14000b653:	int3
   14000b654:	int3
   14000b655:	int3
   14000b656:	int3
   14000b657:	int3
   14000b658:	int3
   14000b659:	int3
   14000b65a:	int3
   14000b65b:	int3
   14000b65c:	int3
   14000b65d:	int3
   14000b65e:	int3
   14000b65f:	int3
   14000b660:	mov    QWORD PTR [rsp+0x8],rbx
   14000b665:	push   rdi
   14000b666:	sub    rsp,0x20
   14000b66a:	lea    rax,[rip+0xbb57]        # 0x1400171c8
   14000b671:	mov    rbx,rcx
   14000b674:	mov    QWORD PTR [rcx],rax
   14000b677:	mov    edi,edx
   14000b679:	mov    rcx,QWORD PTR [rcx+0x8]
   14000b67d:	cmp    rcx,0xffffffffffffffff
   14000b681:	je     0x14000b68f
   14000b683:	rex.W call QWORD PTR [rip+0xc7ee]        # 0x140017e78
   14000b68a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b68f:	or     QWORD PTR [rbx+0x8],0xffffffffffffffff
   14000b694:	lea    rax,[rip+0xb9cd]        # 0x140017068
   14000b69b:	mov    QWORD PTR [rbx],rax
   14000b69e:	test   dil,0x1
   14000b6a2:	je     0x14000b6ac
   14000b6a4:	mov    rcx,rbx
   14000b6a7:	call   0x140014084
   14000b6ac:	mov    rax,rbx
   14000b6af:	mov    rbx,QWORD PTR [rsp+0x30]
   14000b6b4:	add    rsp,0x20
   14000b6b8:	pop    rdi
   14000b6b9:	ret
   14000b6ba:	int3
   14000b6bb:	int3
   14000b6bc:	int3
   14000b6bd:	int3
   14000b6be:	int3
   14000b6bf:	int3
   14000b6c0:	int3
   14000b6c1:	int3
   14000b6c2:	int3
   14000b6c3:	int3
   14000b6c4:	int3
   14000b6c5:	int3
   14000b6c6:	int3
   14000b6c7:	int3
   14000b6c8:	int3
   14000b6c9:	int3
   14000b6ca:	int3
   14000b6cb:	int3
   14000b6cc:	int3
   14000b6cd:	int3
   14000b6ce:	int3
   14000b6cf:	int3
   14000b6d0:	mov    QWORD PTR [rsp+0x8],rbx
   14000b6d5:	push   rdi
   14000b6d6:	sub    rsp,0x20
   14000b6da:	lea    rax,[rip+0xbadf]        # 0x1400171c0
   14000b6e1:	mov    rbx,rcx
   14000b6e4:	mov    QWORD PTR [rcx],rax
   14000b6e7:	mov    edi,edx
   14000b6e9:	mov    rcx,QWORD PTR [rcx+0x8]
   14000b6ed:	test   rcx,rcx
   14000b6f0:	je     0x14000b6fe
   14000b6f2:	rex.W call QWORD PTR [rip+0xc8d7]        # 0x140017fd0
   14000b6f9:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b6fe:	and    QWORD PTR [rbx+0x8],0x0
   14000b703:	lea    rax,[rip+0xb95e]        # 0x140017068
   14000b70a:	mov    QWORD PTR [rbx],rax
   14000b70d:	test   dil,0x1
   14000b711:	je     0x14000b71b
   14000b713:	mov    rcx,rbx
   14000b716:	call   0x140014084
   14000b71b:	mov    rax,rbx
   14000b71e:	mov    rbx,QWORD PTR [rsp+0x30]
   14000b723:	add    rsp,0x20
   14000b727:	pop    rdi
   14000b728:	ret
   14000b729:	int3
   14000b72a:	int3
   14000b72b:	int3
   14000b72c:	int3
   14000b72d:	int3
   14000b72e:	int3
   14000b72f:	int3
   14000b730:	xor    r9d,r9d
   14000b733:	xor    r8d,r8d
   14000b736:	mov    ecx,0xc000008c
   14000b73b:	lea    edx,[r9+0x1]
   14000b73f:	rex.W jmp QWORD PTR [rip+0xc742]        # 0x140017e88
   14000b746:	int3
   14000b747:	int3
   14000b748:	int3
   14000b749:	int3
   14000b74a:	int3
   14000b74b:	int3
   14000b74c:	int3
   14000b74d:	int3
   14000b74e:	int3
   14000b74f:	int3
   14000b750:	int3
   14000b751:	int3
   14000b752:	int3
   14000b753:	int3
   14000b754:	mov    rax,rsp
   14000b757:	mov    QWORD PTR [rax+0x8],rbx
   14000b75b:	mov    QWORD PTR [rax+0x10],rsi
   14000b75f:	mov    QWORD PTR [rax+0x18],rdi
   14000b763:	push   rbp
   14000b764:	lea    rbp,[rax-0x48]
   14000b768:	sub    rsp,0x140
   14000b76f:	lea    rax,[rip+0xd96a]        # 0x1400190e0
   14000b776:	movsxd rdi,edx
   14000b779:	mov    QWORD PTR [rsp+0x20],rax
   14000b77e:	mov    rsi,rcx
   14000b781:	lea    rax,[rip+0x104a8]        # 0x14001bc30
   14000b788:	mov    DWORD PTR [rsp+0x38],0x15b
   14000b790:	mov    QWORD PTR [rsp+0x28],rax
   14000b795:	lea    rcx,[rsp+0x48]
   14000b79a:	lea    rax,[rip+0xd91f]        # 0x1400190c0
   14000b7a1:	mov    DWORD PTR [rsp+0x3c],0x7
   14000b7a9:	xor    ebx,ebx
   14000b7ab:	mov    QWORD PTR [rsp+0x30],rax
   14000b7b0:	xor    edx,edx
   14000b7b2:	mov    DWORD PTR [rsp+0x40],0xff
   14000b7ba:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000b7c1:	lea    r8d,[rbx+0x78]
   14000b7c5:	call   0x140015692
   14000b7ca:	lea    rdx,[rsp+0x20]
   14000b7cf:	lea    rcx,[rbp-0x30]
   14000b7d3:	call   0x14000f85c
   14000b7d8:	cmp    QWORD PTR [rsi+rdi*8+0x68],rbx
   14000b7dd:	lea    rcx,[rbp-0x30]
   14000b7e1:	setne  bl
   14000b7e4:	call   0x14000f958
   14000b7e9:	lea    r11,[rsp+0x140]
   14000b7f1:	mov    eax,ebx
   14000b7f3:	mov    rbx,QWORD PTR [r11+0x10]
   14000b7f7:	mov    rsi,QWORD PTR [r11+0x18]
   14000b7fb:	mov    rdi,QWORD PTR [r11+0x20]
   14000b7ff:	mov    rsp,r11
   14000b802:	pop    rbp
   14000b803:	ret
   14000b804:	int3
   14000b805:	int3
   14000b806:	int3
   14000b807:	int3
   14000b808:	int3
   14000b809:	int3
   14000b80a:	int3
   14000b80b:	int3
   14000b80c:	mov    rcx,QWORD PTR [rcx]
   14000b80f:	rex.W jmp QWORD PTR [rip+0xc79a]        # 0x140017fb0
   14000b816:	int3
   14000b817:	int3
   14000b818:	int3
   14000b819:	int3
   14000b81a:	int3
   14000b81b:	int3
   14000b81c:	int3
   14000b81d:	int3
   14000b81e:	int3
   14000b81f:	int3
   14000b820:	int3
   14000b821:	int3
   14000b822:	int3
   14000b823:	int3
   14000b824:	mov    rax,rsp
   14000b827:	push   rbp
   14000b828:	push   r14
   14000b82a:	push   r15
   14000b82c:	lea    rbp,[rax-0x58]
   14000b830:	sub    rsp,0x140
   14000b837:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   14000b840:	mov    QWORD PTR [rax+0x10],rbx
   14000b844:	mov    QWORD PTR [rax+0x18],rsi
   14000b848:	mov    QWORD PTR [rax+0x20],rdi
   14000b84c:	mov    r15d,r9d
   14000b84f:	mov    r14,r8
   14000b852:	movsxd rbx,edx
   14000b855:	mov    rdi,rcx
   14000b858:	lea    rax,[rip+0xd881]        # 0x1400190e0
   14000b85f:	mov    QWORD PTR [rsp+0x28],rax
   14000b864:	lea    rax,[rip+0x104d5]        # 0x14001bd40
   14000b86b:	mov    QWORD PTR [rsp+0x30],rax
   14000b870:	lea    rax,[rip+0xd849]        # 0x1400190c0
   14000b877:	mov    QWORD PTR [rsp+0x38],rax
   14000b87c:	mov    DWORD PTR [rsp+0x40],0x168
   14000b884:	mov    DWORD PTR [rsp+0x44],0x7
   14000b88c:	mov    DWORD PTR [rsp+0x48],0xff
   14000b894:	xor    esi,esi
   14000b896:	mov    DWORD PTR [rbp-0x38],0x1000000
   14000b89d:	xor    edx,edx
   14000b89f:	lea    r8d,[rsi+0x78]
   14000b8a3:	lea    rcx,[rsp+0x50]
   14000b8a8:	call   0x140015692
   14000b8ad:	lea    rdx,[rsp+0x28]
   14000b8b2:	lea    rcx,[rbp-0x30]
   14000b8b6:	call   0x14000f85c
   14000b8bb:	nop
   14000b8bc:	mov    rdx,QWORD PTR [rdi+rbx*8+0x68]
   14000b8c1:	test   rdx,rdx
   14000b8c4:	jne    0x14000b8ca
   14000b8c6:	mov    eax,esi
   14000b8c8:	jmp    0x14000b8d8
   14000b8ca:	mov    esi,0x1
   14000b8cf:	mov    r8d,r15d
   14000b8d2:	call   0x14000cd84
   14000b8d7:	nop
   14000b8d8:	mov    QWORD PTR [r14],rax
   14000b8db:	lea    rcx,[rbp-0x30]
   14000b8df:	call   0x14000f958
   14000b8e4:	mov    eax,esi
   14000b8e6:	lea    r11,[rsp+0x140]
   14000b8ee:	mov    rbx,QWORD PTR [r11+0x28]
   14000b8f2:	mov    rsi,QWORD PTR [r11+0x30]
   14000b8f6:	mov    rdi,QWORD PTR [r11+0x38]
   14000b8fa:	mov    rsp,r11
   14000b8fd:	pop    r15
   14000b8ff:	pop    r14
   14000b901:	pop    rbp
   14000b902:	ret
   14000b903:	int3
   14000b904:	int3
   14000b905:	int3
   14000b906:	int3
   14000b907:	int3
   14000b908:	int3
   14000b909:	int3
   14000b90a:	int3
   14000b90b:	int3
   14000b90c:	mov    QWORD PTR [rsp+0x10],rbx
   14000b911:	mov    QWORD PTR [rsp+0x18],rbp
   14000b916:	mov    QWORD PTR [rsp+0x20],rsi
   14000b91b:	push   rdi
   14000b91c:	sub    rsp,0x20
   14000b920:	or     rbx,0xffffffffffffffff
   14000b924:	mov    rsi,rdx
   14000b927:	xor    ebp,ebp
   14000b929:	mov    rdi,rcx
   14000b92c:	inc    rbx
   14000b92f:	cmp    WORD PTR [rdx+rbx*2],bp
   14000b933:	jne    0x14000b92c
   14000b935:	mov    rcx,QWORD PTR [rcx+0x8]
   14000b939:	test   rcx,rcx
   14000b93c:	je     0x14000b94a
   14000b93e:	rex.W call QWORD PTR [rip+0xc73b]        # 0x140018080
   14000b945:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b94a:	lea    rcx,[rbx*2+0x2]
   14000b952:	mov    QWORD PTR [rdi+0x8],rbp
   14000b956:	rex.W call QWORD PTR [rip+0xc71b]        # 0x140018078
   14000b95d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000b962:	mov    QWORD PTR [rdi+0x8],rax
   14000b966:	test   rax,rax
   14000b969:	je     0x14000b994
   14000b96b:	lea    rdx,[rbx+0x1]
   14000b96f:	mov    r8,rsi
   14000b972:	mov    rcx,rax
   14000b975:	call   0x1400035fc
   14000b97a:	test   eax,eax
   14000b97c:	js     0x14000b9ae
   14000b97e:	mov    rbx,QWORD PTR [rsp+0x38]
   14000b983:	mov    rbp,QWORD PTR [rsp+0x40]
   14000b988:	mov    rsi,QWORD PTR [rsp+0x48]
   14000b98d:	add    rsp,0x20
   14000b991:	pop    rdi
   14000b992:	ret
   14000b993:	int3
   14000b994:	lea    rdx,[rip+0x1667d]        # 0x140022018
   14000b99b:	mov    DWORD PTR [rsp+0x30],0x8007000e
   14000b9a3:	lea    rcx,[rsp+0x30]
   14000b9a8:	call   0x14001478c
   14000b9ad:	int3
   14000b9ae:	mov    rcx,rdi
   14000b9b1:	call   0x1400038b0
   14000b9b6:	lea    rdx,[rip+0x1665b]        # 0x140022018
   14000b9bd:	mov    DWORD PTR [rsp+0x30],0x8000ffff
   14000b9c5:	lea    rcx,[rsp+0x30]
   14000b9ca:	call   0x14001478c
   14000b9cf:	int3
   14000b9d0:	int3
   14000b9d1:	int3
   14000b9d2:	int3
   14000b9d3:	int3
   14000b9d4:	int3
   14000b9d5:	int3
   14000b9d6:	int3
   14000b9d7:	int3
   14000b9d8:	mov    rax,rsp
   14000b9db:	push   rbp
   14000b9dc:	push   rdi
   14000b9dd:	push   r14
   14000b9df:	lea    rbp,[rax-0x68]
   14000b9e3:	sub    rsp,0x150
   14000b9ea:	mov    QWORD PTR [rsp+0x30],0xfffffffffffffffe
   14000b9f3:	mov    QWORD PTR [rax+0x10],rbx
   14000b9f7:	mov    QWORD PTR [rax+0x18],rsi
   14000b9fb:	mov    rsi,r8
   14000b9fe:	mov    rbx,rcx
   14000ba01:	lea    rax,[rip+0xd6d8]        # 0x1400190e0
   14000ba08:	mov    QWORD PTR [rsp+0x38],rax
   14000ba0d:	lea    rax,[rip+0x1036c]        # 0x14001bd80
   14000ba14:	mov    QWORD PTR [rsp+0x40],rax
   14000ba19:	lea    rax,[rip+0xd6a0]        # 0x1400190c0
   14000ba20:	mov    QWORD PTR [rsp+0x48],rax
   14000ba25:	mov    DWORD PTR [rsp+0x50],0x17d
   14000ba2d:	mov    DWORD PTR [rsp+0x54],0x7
   14000ba35:	mov    DWORD PTR [rsp+0x58],0xff
   14000ba3d:	xor    r14d,r14d
   14000ba40:	mov    DWORD PTR [rbp-0x28],0x1000000
   14000ba47:	lea    edi,[r14+0x1]
   14000ba4b:	xor    edx,edx
   14000ba4d:	lea    r8d,[r14+0x78]
   14000ba51:	lea    rcx,[rsp+0x60]
   14000ba56:	call   0x140015692
   14000ba5b:	lea    rdx,[rsp+0x38]
   14000ba60:	lea    rcx,[rbp-0x20]
   14000ba64:	call   0x14000f85c
   14000ba69:	nop
   14000ba6a:	mov    rdx,QWORD PTR [rbx+0x90]
   14000ba71:	test   rdx,rdx
   14000ba74:	jne    0x14000baa0
   14000ba76:	mov    QWORD PTR [rsi],r14
   14000ba79:	mov    edi,r14d
   14000ba7c:	lea    rcx,[rbp-0x20]
   14000ba80:	call   0x14000f958
   14000ba85:	mov    eax,edi
   14000ba87:	lea    r11,[rsp+0x150]
   14000ba8f:	mov    rbx,QWORD PTR [r11+0x28]
   14000ba93:	mov    rsi,QWORD PTR [r11+0x30]
   14000ba97:	mov    rsp,r11
   14000ba9a:	pop    r14
   14000ba9c:	pop    rdi
   14000ba9d:	pop    rbp
   14000ba9e:	ret
   14000ba9f:	int3
   14000baa0:	cmp    WORD PTR [rdx],r14w
   14000baa4:	je     0x14000ba79
   14000baa6:	mov    QWORD PTR [rsp+0x28],r14
   14000baab:	lea    rax,[rip+0xb5ae]        # 0x140017060
   14000bab2:	mov    QWORD PTR [rsp+0x20],rax
   14000bab7:	lea    rcx,[rsp+0x20]
   14000babc:	call   0x14000b90c
   14000bac1:	mov    rbx,QWORD PTR [rsp+0x28]
   14000bac6:	or     rax,0xffffffffffffffff
   14000baca:	inc    rax
   14000bacd:	cmp    WORD PTR [rbx+rax*2],r14w
   14000bad2:	jne    0x14000baca
   14000bad4:	cmp    WORD PTR [rbx+rax*2-0x2],0x25
   14000bada:	je     0x14000bae1
   14000badc:	mov    edi,r14d
   14000badf:	jmp    0x14000baf5
   14000bae1:	mov    WORD PTR [rbx+rax*2-0x2],r14w
   14000bae7:	xor    r8d,r8d
   14000baea:	mov    rdx,rbx
   14000baed:	call   0x14000cd84
   14000baf2:	mov    QWORD PTR [rsi],rax
   14000baf5:	test   rbx,rbx
   14000baf8:	je     0x14000ba7c
   14000bafa:	mov    rcx,rbx
   14000bafd:	rex.W call QWORD PTR [rip+0xc57c]        # 0x140018080
   14000bb04:	nop    DWORD PTR [rax+rax*1+0x0]
   14000bb09:	jmp    0x14000ba7c
   14000bb0e:	int3
   14000bb0f:	int3
   14000bb10:	int3
   14000bb11:	int3
   14000bb12:	int3
   14000bb13:	int3
   14000bb14:	int3
   14000bb15:	int3
   14000bb16:	int3
   14000bb17:	int3
   14000bb18:	rex.W jmp QWORD PTR [rip+0xc4b1]        # 0x140017fd0
   14000bb1f:	int3
   14000bb20:	int3
   14000bb21:	int3
   14000bb22:	int3
   14000bb23:	int3
   14000bb24:	int3
   14000bb25:	int3
   14000bb26:	int3
   14000bb27:	int3
   14000bb28:	int3
   14000bb29:	int3
   14000bb2a:	int3
   14000bb2b:	int3
   14000bb2c:	mov    rax,rsp
   14000bb2f:	push   rbp
   14000bb30:	push   rsi
   14000bb31:	push   rdi
   14000bb32:	push   r12
   14000bb34:	push   r13
   14000bb36:	push   r14
   14000bb38:	push   r15
   14000bb3a:	lea    rbp,[rax-0xf8]
   14000bb41:	sub    rsp,0x1c0
   14000bb48:	mov    QWORD PTR [rbp+0xb0],0xfffffffffffffffe
   14000bb53:	mov    QWORD PTR [rax+0x10],rbx
   14000bb57:	mov    r12,rdx
   14000bb5a:	mov    r15,rcx
   14000bb5d:	lea    rdi,[rip+0x102dc]        # 0x14001be40
   14000bb64:	mov    QWORD PTR [rsp+0x60],rdi
   14000bb69:	lea    rsi,[rip+0x10270]        # 0x14001bde0
   14000bb70:	mov    QWORD PTR [rsp+0x68],rsi
   14000bb75:	lea    r14,[rip+0x102ac]        # 0x14001be28
   14000bb7c:	mov    QWORD PTR [rsp+0x70],r14
   14000bb81:	mov    DWORD PTR [rsp+0x78],0x38
   14000bb89:	mov    DWORD PTR [rsp+0x7c],0x7
   14000bb91:	mov    DWORD PTR [rbp-0x80],0xff
   14000bb98:	xor    ebx,ebx
   14000bb9a:	mov    DWORD PTR [rbp+0x0],0x1000000
   14000bba1:	xor    edx,edx
   14000bba3:	lea    r13d,[rbx+0x1]
   14000bba7:	lea    r8d,[rbx+0x78]
   14000bbab:	lea    rcx,[rbp-0x78]
   14000bbaf:	call   0x140015692
   14000bbb4:	lea    rdx,[rsp+0x60]
   14000bbb9:	lea    rcx,[rbp+0x10]
   14000bbbd:	call   0x14000f85c
   14000bbc2:	nop
   14000bbc3:	mov    rdx,QWORD PTR [r15+0x40]
   14000bbc7:	test   rdx,rdx
   14000bbca:	jne    0x14000be42
   14000bbd0:	mov    QWORD PTR [rbp+0x118],rbx
   14000bbd7:	movups xmm0,XMMWORD PTR [rip+0x1014a]        # 0x14001bd28
   14000bbde:	movdqu XMMWORD PTR [rsp+0x40],xmm0
   14000bbe4:	movups xmm1,XMMWORD PTR [rip+0x1012d]        # 0x14001bd18
   14000bbeb:	movdqu XMMWORD PTR [rsp+0x50],xmm1
   14000bbf1:	mov    QWORD PTR [rsp+0x60],rdi
   14000bbf6:	mov    QWORD PTR [rsp+0x68],rsi
   14000bbfb:	mov    QWORD PTR [rsp+0x70],r14
   14000bc00:	mov    DWORD PTR [rsp+0x78],0x40
   14000bc08:	mov    DWORD PTR [rsp+0x7c],0x7
   14000bc10:	mov    DWORD PTR [rbp-0x80],0xff
   14000bc17:	mov    DWORD PTR [rbp+0x0],0x1000000
   14000bc1e:	lea    r8d,[rbx+0x78]
   14000bc22:	lea    rcx,[rbp-0x78]
   14000bc26:	call   0x140015692
   14000bc2b:	lea    rax,[rbp+0x118]
   14000bc32:	mov    QWORD PTR [rsp+0x30],rax
   14000bc37:	lea    rax,[rsp+0x40]
   14000bc3c:	mov    QWORD PTR [rsp+0x28],rax
   14000bc41:	lea    r9,[rip+0xebb0]        # 0x14001a7f8
   14000bc48:	lea    r8,[rsp+0x50]
   14000bc4d:	lea    rdx,[rsp+0x60]
   14000bc52:	lea    rcx,[rbp+0x10]
   14000bc56:	call   0x140011460
   14000bc5b:	cmp    DWORD PTR [rbp+0x18],ebx
   14000bc5e:	jl     0x14000bf7b
   14000bc64:	mov    QWORD PTR [rbp+0x110],rbx
   14000bc6b:	movups xmm0,XMMWORD PTR [rip+0xd4c6]        # 0x140019138
   14000bc72:	movdqu XMMWORD PTR [rsp+0x50],xmm0
   14000bc78:	mov    rcx,QWORD PTR [rbp+0x118]
   14000bc7f:	mov    rax,QWORD PTR [rcx]
   14000bc82:	lea    r9,[rbp+0x110]
   14000bc89:	or     r8d,0xffffffff
   14000bc8d:	lea    rdx,[rsp+0x50]
   14000bc92:	mov    rax,QWORD PTR [rax+0x20]
   14000bc96:	call   QWORD PTR [rip+0xc5fc]        # 0x140018298
   14000bc9c:	mov    DWORD PTR [rbp+0x18],eax
   14000bc9f:	test   eax,eax
   14000bca1:	js     0x14000bfc2
   14000bca7:	cmp    eax,r13d
   14000bcaa:	je     0x14000c009
   14000bcb0:	lea    rdx,[rip+0xc6c9]        # 0x140018380
   14000bcb7:	lea    ecx,[rbx+0x18]
   14000bcba:	call   0x1400143f8
   14000bcbf:	mov    QWORD PTR [rbp+0x100],rax
   14000bcc6:	test   rax,rax
   14000bcc9:	je     0x14000bcd7
   14000bccb:	mov    QWORD PTR [rax],rbx
   14000bcce:	mov    QWORD PTR [rax+0x8],rbx
   14000bcd2:	mov    DWORD PTR [rax+0x10],ebx
   14000bcd5:	jmp    0x14000bcda
   14000bcd7:	mov    rax,rbx
   14000bcda:	mov    QWORD PTR [r15+0x40],rax
   14000bcde:	test   rax,rax
   14000bce1:	je     0x14000c043
   14000bce7:	mov    rcx,QWORD PTR [rbp+0x110]
   14000bcee:	mov    rax,QWORD PTR [rcx]
   14000bcf1:	lea    r9,[rbp+0x100]
   14000bcf8:	lea    r8,[rbp+0x80]
   14000bcff:	mov    edx,r13d
   14000bd02:	mov    rax,QWORD PTR [rax+0x18]
   14000bd06:	call   QWORD PTR [rip+0xc58c]        # 0x140018298
   14000bd0c:	mov    DWORD PTR [rbp+0x18],eax
   14000bd0f:	test   eax,eax
   14000bd11:	js     0x14000bf34
   14000bd17:	cmp    eax,r13d
   14000bd1a:	je     0x14000be0a
   14000bd20:	mov    rdi,QWORD PTR [rbp+0x90]
   14000bd27:	or     rax,0xffffffffffffffff
   14000bd2b:	inc    rax
   14000bd2e:	cmp    WORD PTR [rdi+rax*2],bx
   14000bd32:	jne    0x14000bd2b
   14000bd34:	cmp    rax,0x3
   14000bd38:	jne    0x14000bd4c
   14000bd3a:	cmp    WORD PTR [rdi+0x4],0x5c
   14000bd3f:	jne    0x14000bd4c
   14000bd41:	mov    WORD PTR [rdi+0x4],bx
   14000bd45:	mov    rdi,QWORD PTR [rbp+0x90]
   14000bd4c:	mov    r14,QWORD PTR [rbp+0x88]
   14000bd53:	mov    rsi,QWORD PTR [r15+0x40]
   14000bd57:	mov    eax,DWORD PTR [rsi+0x10]
   14000bd5a:	add    eax,r13d
   14000bd5d:	movsxd rdx,eax
   14000bd60:	shl    rdx,0x3
   14000bd64:	mov    rcx,QWORD PTR [rsi]
   14000bd67:	rex.W call QWORD PTR [rip+0xc4e2]        # 0x140018250
   14000bd6e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000bd73:	test   rax,rax
   14000bd76:	je     0x14000bec1
   14000bd7c:	mov    QWORD PTR [rsi],rax
   14000bd7f:	mov    eax,DWORD PTR [rsi+0x10]
   14000bd82:	add    eax,r13d
   14000bd85:	movsxd rdx,eax
   14000bd88:	shl    rdx,0x3
   14000bd8c:	mov    rcx,QWORD PTR [rsi+0x8]
   14000bd90:	rex.W call QWORD PTR [rip+0xc4b9]        # 0x140018250
   14000bd97:	nop    DWORD PTR [rax+rax*1+0x0]
   14000bd9c:	test   rax,rax
   14000bd9f:	je     0x14000bec1
   14000bda5:	mov    QWORD PTR [rsi+0x8],rax
   14000bda9:	movsxd rdx,DWORD PTR [rsi+0x10]
   14000bdad:	lea    ecx,[rdx+0x1]
   14000bdb0:	mov    DWORD PTR [rsi+0x10],ecx
   14000bdb3:	mov    r8,rdx
   14000bdb6:	mov    rcx,QWORD PTR [rsi]
   14000bdb9:	lea    rdx,[rcx+rdx*8]
   14000bdbd:	test   rdx,rdx
   14000bdc0:	je     0x14000bdc9
   14000bdc2:	mov    QWORD PTR [rdx],r14
   14000bdc5:	mov    rax,QWORD PTR [rsi+0x8]
   14000bdc9:	lea    rax,[rax+r8*8]
   14000bdcd:	test   rax,rax
   14000bdd0:	je     0x14000bdd5
   14000bdd2:	mov    QWORD PTR [rax],rdi
   14000bdd5:	mov    rcx,QWORD PTR [rbp+0x110]
   14000bddc:	mov    rax,QWORD PTR [rcx]
   14000bddf:	lea    r9,[rbp+0x100]
   14000bde6:	lea    r8,[rbp+0x80]
   14000bded:	mov    edx,r13d
   14000bdf0:	mov    rax,QWORD PTR [rax+0x18]
   14000bdf4:	call   QWORD PTR [rip+0xc49e]        # 0x140018298
   14000bdfa:	mov    DWORD PTR [rbp+0x18],eax
   14000bdfd:	test   eax,eax
   14000bdff:	js     0x14000bf1f
   14000be05:	jmp    0x14000bd17
   14000be0a:	mov    rcx,QWORD PTR [rbp+0x110]
   14000be11:	test   rcx,rcx
   14000be14:	je     0x14000be24
   14000be16:	mov    rax,QWORD PTR [rcx]
   14000be19:	mov    rax,QWORD PTR [rax+0x10]
   14000be1d:	call   QWORD PTR [rip+0xc475]        # 0x140018298
   14000be23:	nop
   14000be24:	mov    rcx,QWORD PTR [rbp+0x118]
   14000be2b:	test   rcx,rcx
   14000be2e:	je     0x14000be3e
   14000be30:	mov    rax,QWORD PTR [rcx]
   14000be33:	mov    rax,QWORD PTR [rax+0x10]
   14000be37:	call   QWORD PTR [rip+0xc45b]        # 0x140018298
   14000be3d:	nop
   14000be3e:	mov    rdx,QWORD PTR [r15+0x40]
   14000be42:	mov    eax,ebx
   14000be44:	cmp    DWORD PTR [rdx+0x10],ebx
   14000be47:	jle    0x14000be86
   14000be49:	movsxd rsi,DWORD PTR [rdx+0x10]
   14000be4d:	mov    r8,rbx
   14000be50:	mov    r9,QWORD PTR [rdx]
   14000be53:	mov    rcx,QWORD PTR [r9]
   14000be56:	mov    r11,r12
   14000be59:	sub    r11,rcx
   14000be5c:	movzx  r10d,WORD PTR [rcx]
   14000be60:	movzx  edi,WORD PTR [rcx+r11*1]
   14000be65:	sub    r10d,edi
   14000be68:	jne    0x14000be72
   14000be6a:	add    rcx,0x2
   14000be6e:	test   edi,edi
   14000be70:	jne    0x14000be5c
   14000be72:	test   r10d,r10d
   14000be75:	je     0x14000be89
   14000be77:	add    eax,r13d
   14000be7a:	add    r8,r13
   14000be7d:	add    r9,0x8
   14000be81:	cmp    r8,rsi
   14000be84:	jl     0x14000be53
   14000be86:	or     eax,0xffffffff
   14000be89:	cmp    eax,0xffffffff
   14000be8c:	je     0x14000be99
   14000be8e:	movsxd rcx,eax
   14000be91:	mov    rax,QWORD PTR [rdx+0x8]
   14000be95:	mov    rbx,QWORD PTR [rax+rcx*8]
   14000be99:	lea    rcx,[rbp+0x10]
   14000be9d:	call   0x14000f958
   14000bea2:	mov    rax,rbx
   14000bea5:	mov    rbx,QWORD PTR [rsp+0x208]
   14000bead:	add    rsp,0x1c0
   14000beb4:	pop    r15
   14000beb6:	pop    r14
   14000beb8:	pop    r13
   14000beba:	pop    r12
   14000bebc:	pop    rdi
   14000bebd:	pop    rsi
   14000bebe:	pop    rbp
   14000bebf:	ret
   14000bec0:	int3
   14000bec1:	lea    rcx,[rbp+0x88]
   14000bec8:	call   0x1400039a4
   14000becd:	lea    rcx,[rbp+0x90]
   14000bed4:	call   0x1400039a4
   14000bed9:	mov    DWORD PTR [rsp+0x28],r13d
   14000bede:	mov    DWORD PTR [rsp+0x20],0x7a
   14000bee6:	lea    r9,[rip+0xfef3]        # 0x14001bde0
   14000beed:	lea    r8,[rip+0xff34]        # 0x14001be28
   14000bef4:	lea    rdx,[rip+0xff45]        # 0x14001be40
   14000befb:	lea    rcx,[rsp+0x60]
   14000bf00:	call   0x14000f3ac
   14000bf05:	lea    r9,[rip+0xd05c]        # 0x140018f68
   14000bf0c:	mov    r8d,0x8007000e
   14000bf12:	mov    rdx,rax
   14000bf15:	lea    rcx,[rbp+0x10]
   14000bf19:	call   0x1400106b0
   14000bf1e:	int3
   14000bf1f:	lea    rdi,[rip+0xff1a]        # 0x14001be40
   14000bf26:	lea    rsi,[rip+0xfeb3]        # 0x14001bde0
   14000bf2d:	lea    r14,[rip+0xfef4]        # 0x14001be28
   14000bf34:	mov    DWORD PTR [rsp+0x28],0x7
   14000bf3c:	mov    DWORD PTR [rsp+0x20],0x68
   14000bf44:	mov    r9,rsi
   14000bf47:	mov    r8,r14
   14000bf4a:	mov    rdx,rdi
   14000bf4d:	lea    rcx,[rsp+0x60]
   14000bf52:	call   0x14000f3ac
   14000bf57:	mov    rdx,rax
   14000bf5a:	lea    rcx,[rbp+0x10]
   14000bf5e:	call   0x1400038ec
   14000bf63:	mov    DWORD PTR [rsp+0x20],eax
   14000bf67:	lea    r9,[rip+0xca7a]        # 0x1400189e8
   14000bf6e:	mov    r8d,eax
   14000bf71:	lea    rcx,[rbp+0x10]
   14000bf75:	call   0x1400106b0
   14000bf7a:	nop
   14000bf7b:	mov    DWORD PTR [rsp+0x28],0x7
   14000bf83:	mov    DWORD PTR [rsp+0x20],0x47
   14000bf8b:	mov    r9,rsi
   14000bf8e:	mov    r8,r14
   14000bf91:	mov    rdx,rdi
   14000bf94:	lea    rcx,[rsp+0x60]
   14000bf99:	call   0x14000f3ac
   14000bf9e:	mov    rdx,rax
   14000bfa1:	lea    rcx,[rbp+0x10]
   14000bfa5:	call   0x1400038ec
   14000bfaa:	mov    DWORD PTR [rsp+0x20],eax
   14000bfae:	lea    r9,[rip+0xc9ab]        # 0x140018960
   14000bfb5:	mov    r8d,eax
   14000bfb8:	lea    rcx,[rbp+0x10]
   14000bfbc:	call   0x1400106b0
   14000bfc1:	nop
   14000bfc2:	mov    DWORD PTR [rsp+0x28],0x7
   14000bfca:	mov    DWORD PTR [rsp+0x20],0x52
   14000bfd2:	mov    r9,rsi
   14000bfd5:	mov    r8,r14
   14000bfd8:	mov    rdx,rdi
   14000bfdb:	lea    rcx,[rsp+0x60]
   14000bfe0:	call   0x14000f3ac
   14000bfe5:	mov    rdx,rax
   14000bfe8:	lea    rcx,[rbp+0x10]
   14000bfec:	call   0x1400038ec
   14000bff1:	mov    DWORD PTR [rsp+0x20],eax
   14000bff5:	lea    r9,[rip+0xe824]        # 0x14001a820
   14000bffc:	mov    r8d,eax
   14000bfff:	lea    rcx,[rbp+0x10]
   14000c003:	call   0x1400106b0
   14000c008:	int3
   14000c009:	mov    DWORD PTR [rsp+0x28],0x7
   14000c011:	mov    DWORD PTR [rsp+0x20],0x56
   14000c019:	mov    r9,rsi
   14000c01c:	mov    r8,r14
   14000c01f:	mov    rdx,rdi
   14000c022:	lea    rcx,[rsp+0x60]
   14000c027:	call   0x14000f3ac
   14000c02c:	lea    r9,[rip+0xefbd]        # 0x14001aff0
   14000c033:	mov    r8d,r13d
   14000c036:	mov    rdx,rax
   14000c039:	lea    rcx,[rbp+0x10]
   14000c03d:	call   0x1400106b0
   14000c042:	int3
   14000c043:	mov    DWORD PTR [rsp+0x28],r13d
   14000c048:	mov    DWORD PTR [rsp+0x20],0x60
   14000c050:	mov    r9,rsi
   14000c053:	mov    r8,r14
   14000c056:	mov    rdx,rdi
   14000c059:	lea    rcx,[rsp+0x60]
   14000c05e:	call   0x14000f3ac
   14000c063:	lea    r9,[rip+0xcefe]        # 0x140018f68
   14000c06a:	mov    r8d,0x8007000e
   14000c070:	mov    rdx,rax
   14000c073:	lea    rcx,[rbp+0x10]
   14000c077:	call   0x1400106b0
   14000c07c:	int3
   14000c07d:	int3
   14000c07e:	int3
   14000c07f:	int3
   14000c080:	int3
   14000c081:	int3
   14000c082:	int3
   14000c083:	int3
   14000c084:	mov    rax,rsp
   14000c087:	mov    QWORD PTR [rax+0x8],rcx
   14000c08b:	push   rbp
   14000c08c:	push   rsi
   14000c08d:	push   rdi
   14000c08e:	push   r14
   14000c090:	push   r15
   14000c092:	lea    rbp,[rsp-0x70]
   14000c097:	sub    rsp,0x170
   14000c09e:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000c0a7:	mov    QWORD PTR [rax+0x10],rbx
   14000c0ab:	mov    rbx,rdx
   14000c0ae:	lea    rsi,[rip+0xfd8b]        # 0x14001be40
   14000c0b5:	mov    QWORD PTR [rsp+0x50],rsi
   14000c0ba:	lea    r14,[rip+0xfddf]        # 0x14001bea0
   14000c0c1:	mov    QWORD PTR [rsp+0x58],r14
   14000c0c6:	lea    r15,[rip+0xfd5b]        # 0x14001be28
   14000c0cd:	mov    QWORD PTR [rsp+0x60],r15
   14000c0d2:	mov    DWORD PTR [rsp+0x68],0x87
   14000c0da:	mov    DWORD PTR [rsp+0x6c],0x7
   14000c0e2:	mov    DWORD PTR [rsp+0x70],0xff
   14000c0ea:	xor    edi,edi
   14000c0ec:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000c0f3:	xor    edx,edx
   14000c0f5:	lea    r8d,[rdi+0x78]
   14000c0f9:	lea    rcx,[rsp+0x78]
   14000c0fe:	call   0x140015692
   14000c103:	lea    rdx,[rsp+0x50]
   14000c108:	lea    rcx,[rbp+0x0]
   14000c10c:	call   0x14000f85c
   14000c111:	nop
   14000c112:	mov    QWORD PTR [rbp+0xa0],rdi
   14000c119:	mov    QWORD PTR [rbp+0xb0],rdi
   14000c120:	mov    QWORD PTR [rbp+0xb8],rdi
   14000c127:	lea    r9,[rbp+0xb0]
   14000c12e:	lea    r8,[rbp+0xa0]
   14000c135:	lea    rdx,[rbp+0xb8]
   14000c13c:	mov    rcx,rbx
   14000c13f:	rex.W call QWORD PTR [rip+0xbe4a]        # 0x140017f90
   14000c146:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c14b:	test   eax,eax
   14000c14d:	je     0x14000c17a
   14000c14f:	mov    rbx,QWORD PTR [rbp+0xa0]
   14000c156:	lea    rcx,[rbp+0x0]
   14000c15a:	call   0x14000f958
   14000c15f:	mov    rax,rbx
   14000c162:	mov    rbx,QWORD PTR [rsp+0x1a8]
   14000c16a:	add    rsp,0x170
   14000c171:	pop    r15
   14000c173:	pop    r14
   14000c175:	pop    rdi
   14000c176:	pop    rsi
   14000c177:	pop    rbp
   14000c178:	ret
   14000c179:	int3
   14000c17a:	rex.W call QWORD PTR [rip+0xbdf7]        # 0x140017f78
   14000c181:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c186:	nop
   14000c187:	mov    ebx,eax
   14000c189:	lea    ecx,[rax-0x2]
   14000c18c:	cmp    ecx,0x1
   14000c18f:	jbe    0x14000c1a1
   14000c191:	movzx  edx,bx
   14000c194:	or     edx,0x80070000
   14000c19a:	test   eax,eax
   14000c19c:	cmovle edx,eax
   14000c19f:	jmp    0x14000c1a6
   14000c1a1:	mov    edx,0x80042308
   14000c1a6:	lea    rcx,[rbp+0x0]
   14000c1aa:	call   0x1400038e0
   14000c1af:	mov    DWORD PTR [rsp+0x28],0x7
   14000c1b7:	mov    DWORD PTR [rsp+0x20],0x9f
   14000c1bf:	mov    r9,r14
   14000c1c2:	mov    r8,r15
   14000c1c5:	mov    rdx,rsi
   14000c1c8:	lea    rcx,[rsp+0x50]
   14000c1cd:	call   0x14000f3ac
   14000c1d2:	mov    rdx,rax
   14000c1d5:	lea    rcx,[rbp+0x0]
   14000c1d9:	call   0x1400038ec
   14000c1de:	mov    r8d,eax
   14000c1e1:	mov    DWORD PTR [rsp+0x20],ebx
   14000c1e5:	lea    r9,[rip+0xfcf4]        # 0x14001bee0
   14000c1ec:	lea    rcx,[rbp+0x0]
   14000c1f0:	call   0x1400106b0
   14000c1f5:	int3
   14000c1f6:	int3
   14000c1f7:	int3
   14000c1f8:	int3
   14000c1f9:	int3
   14000c1fa:	int3
   14000c1fb:	int3
   14000c1fc:	mov    rax,rsp
   14000c1ff:	push   rbp
   14000c200:	push   rsi
   14000c201:	push   rdi
   14000c202:	push   r12
   14000c204:	push   r13
   14000c206:	push   r14
   14000c208:	push   r15
   14000c20a:	lea    rbp,[rax-0x8b8]
   14000c211:	sub    rsp,0x980
   14000c218:	mov    QWORD PTR [rsp+0x48],0xfffffffffffffffe
   14000c221:	mov    QWORD PTR [rax+0x18],rbx
   14000c225:	mov    rax,QWORD PTR [rip+0x17eec]        # 0x140024118
   14000c22c:	xor    rax,rsp
   14000c22f:	mov    QWORD PTR [rbp+0x870],rax
   14000c236:	mov    esi,edx
   14000c238:	mov    rbx,rcx
   14000c23b:	lea    r15,[rip+0xfbfe]        # 0x14001be40
   14000c242:	mov    QWORD PTR [rsp+0x50],r15
   14000c247:	lea    r12,[rip+0xfce2]        # 0x14001bf30
   14000c24e:	mov    QWORD PTR [rsp+0x58],r12
   14000c253:	lea    r13,[rip+0xfbce]        # 0x14001be28
   14000c25a:	mov    QWORD PTR [rsp+0x60],r13
   14000c25f:	mov    DWORD PTR [rsp+0x68],0xa9
   14000c267:	mov    DWORD PTR [rsp+0x6c],0x7
   14000c26f:	mov    DWORD PTR [rsp+0x70],0xff
   14000c277:	xor    r14d,r14d
   14000c27a:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000c281:	xor    edx,edx
   14000c283:	lea    r8d,[r14+0x78]
   14000c287:	lea    rcx,[rsp+0x78]
   14000c28c:	call   0x140015692
   14000c291:	lea    rdx,[rsp+0x50]
   14000c296:	lea    rcx,[rbp+0x0]
   14000c29a:	call   0x14000f85c
   14000c29f:	nop
   14000c2a0:	mov    eax,r14d
   14000c2a3:	cmp    DWORD PTR [rbx+0x20],r14d
   14000c2a7:	jle    0x14000c2c6
   14000c2a9:	movsxd r8,DWORD PTR [rbx+0x20]
   14000c2ad:	mov    edx,r14d
   14000c2b0:	mov    rcx,QWORD PTR [rbx+0x10]
   14000c2b4:	cmp    DWORD PTR [rcx],esi
   14000c2b6:	je     0x14000c2c9
   14000c2b8:	inc    eax
   14000c2ba:	inc    rdx
   14000c2bd:	add    rcx,0x4
   14000c2c1:	cmp    rdx,r8
   14000c2c4:	jl     0x14000c2b4
   14000c2c6:	or     eax,0xffffffff
   14000c2c9:	cmp    eax,0xffffffff
   14000c2cc:	je     0x14000c315
   14000c2ce:	movsxd rcx,eax
   14000c2d1:	mov    rax,QWORD PTR [rbx+0x18]
   14000c2d5:	mov    rdi,QWORD PTR [rax+rcx*8]
   14000c2d9:	test   rdi,rdi
   14000c2dc:	je     0x14000c315
   14000c2de:	lea    rcx,[rbp+0x0]
   14000c2e2:	call   0x14000f958
   14000c2e7:	mov    rax,rdi
   14000c2ea:	mov    rcx,QWORD PTR [rbp+0x870]
   14000c2f1:	xor    rcx,rsp
   14000c2f4:	call   0x1400143c0
   14000c2f9:	mov    rbx,QWORD PTR [rsp+0x9d0]
   14000c301:	add    rsp,0x980
   14000c308:	pop    r15
   14000c30a:	pop    r14
   14000c30c:	pop    r13
   14000c30e:	pop    r12
   14000c310:	pop    rdi
   14000c311:	pop    rsi
   14000c312:	pop    rbp
   14000c313:	ret
   14000c314:	int3
   14000c315:	xor    ecx,ecx
   14000c317:	rex.W call QWORD PTR [rip+0xbbd2]        # 0x140017ef0
   14000c31e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c323:	mov    rcx,rax
   14000c326:	mov    r9d,0x3ff
   14000c32c:	lea    r8,[rbp+0x70]
   14000c330:	mov    edx,esi
   14000c332:	rex.W call QWORD PTR [rip+0xbd77]        # 0x1400180b0
   14000c339:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c33e:	test   eax,eax
   14000c340:	je     0x14000c3ee
   14000c346:	mov    QWORD PTR [rsp+0x40],r14
   14000c34b:	lea    r8,[rbp+0x70]
   14000c34f:	lea    rdx,[rsp+0x40]
   14000c354:	lea    rcx,[rbp+0x0]
   14000c358:	call   0x140003688
   14000c35d:	mov    rdi,QWORD PTR [rsp+0x40]
   14000c362:	mov    QWORD PTR [rsp+0x40],rdi
   14000c367:	mov    eax,DWORD PTR [rbx+0x20]
   14000c36a:	inc    eax
   14000c36c:	movsxd rdx,eax
   14000c36f:	shl    rdx,0x2
   14000c373:	mov    rcx,QWORD PTR [rbx+0x10]
   14000c377:	rex.W call QWORD PTR [rip+0xbed2]        # 0x140018250
   14000c37e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c383:	test   rax,rax
   14000c386:	je     0x14000c442
   14000c38c:	mov    QWORD PTR [rbx+0x10],rax
   14000c390:	mov    eax,DWORD PTR [rbx+0x20]
   14000c393:	inc    eax
   14000c395:	movsxd rdx,eax
   14000c398:	shl    rdx,0x3
   14000c39c:	mov    rcx,QWORD PTR [rbx+0x18]
   14000c3a0:	rex.W call QWORD PTR [rip+0xbea9]        # 0x140018250
   14000c3a7:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c3ac:	test   rax,rax
   14000c3af:	je     0x14000c442
   14000c3b5:	mov    QWORD PTR [rbx+0x18],rax
   14000c3b9:	movsxd rdx,DWORD PTR [rbx+0x20]
   14000c3bd:	lea    ecx,[rdx+0x1]
   14000c3c0:	mov    DWORD PTR [rbx+0x20],ecx
   14000c3c3:	mov    r8,rdx
   14000c3c6:	mov    rcx,QWORD PTR [rbx+0x10]
   14000c3ca:	lea    rdx,[rcx+rdx*4]
   14000c3ce:	test   rdx,rdx
   14000c3d1:	je     0x14000c3d9
   14000c3d3:	mov    DWORD PTR [rdx],esi
   14000c3d5:	mov    rax,QWORD PTR [rbx+0x18]
   14000c3d9:	lea    rcx,[rax+r8*8]
   14000c3dd:	test   rcx,rcx
   14000c3e0:	je     0x14000c2de
   14000c3e6:	mov    QWORD PTR [rcx],rdi
   14000c3e9:	jmp    0x14000c2de
   14000c3ee:	mov    DWORD PTR [rsp+0x28],0x7
   14000c3f6:	mov    DWORD PTR [rsp+0x20],0xb8
   14000c3fe:	mov    r9,r12
   14000c401:	mov    r8,r13
   14000c404:	mov    rdx,r15
   14000c407:	lea    rcx,[rsp+0x50]
   14000c40c:	call   0x14000f3ac
   14000c411:	mov    rbx,rax
   14000c414:	rex.W call QWORD PTR [rip+0xbb5d]        # 0x140017f78
   14000c41b:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c420:	mov    DWORD PTR [rsp+0x28],eax
   14000c424:	mov    DWORD PTR [rsp+0x20],esi
   14000c428:	lea    r9,[rip+0xfb41]        # 0x14001bf70
   14000c42f:	mov    r8d,0x8000ffff
   14000c435:	mov    rdx,rbx
   14000c438:	lea    rcx,[rbp+0x0]
   14000c43c:	call   0x1400106b0
   14000c441:	int3
   14000c442:	lea    rcx,[rsp+0x40]
   14000c447:	call   0x1400039a4
   14000c44c:	mov    DWORD PTR [rsp+0x28],0x1
   14000c454:	mov    DWORD PTR [rsp+0x20],0xc4
   14000c45c:	mov    r9,r12
   14000c45f:	mov    r8,r13
   14000c462:	mov    rdx,r15
   14000c465:	lea    rcx,[rsp+0x50]
   14000c46a:	call   0x14000f3ac
   14000c46f:	lea    r9,[rip+0xcaf2]        # 0x140018f68
   14000c476:	mov    r8d,0x8007000e
   14000c47c:	mov    rdx,rax
   14000c47f:	lea    rcx,[rbp+0x0]
   14000c483:	call   0x1400106b0
   14000c488:	int3
   14000c489:	int3
   14000c48a:	int3
   14000c48b:	int3
   14000c48c:	int3
   14000c48d:	int3
   14000c48e:	int3
   14000c48f:	int3
   14000c490:	mov    rax,rsp
   14000c493:	mov    QWORD PTR [rax+0x8],rbx
   14000c497:	mov    QWORD PTR [rax+0x10],rsi
   14000c49b:	mov    QWORD PTR [rax+0x18],rdi
   14000c49f:	push   rbp
   14000c4a0:	lea    rbp,[rax-0x48]
   14000c4a4:	sub    rsp,0x140
   14000c4ab:	lea    rax,[rip+0xf98e]        # 0x14001be40
   14000c4b2:	mov    DWORD PTR [rsp+0x38],0xdf
   14000c4ba:	mov    QWORD PTR [rsp+0x20],rax
   14000c4bf:	mov    bl,dl
   14000c4c1:	lea    rax,[rip+0xfaf8]        # 0x14001bfc0
   14000c4c8:	mov    DWORD PTR [rsp+0x3c],0x7
   14000c4d0:	mov    QWORD PTR [rsp+0x28],rax
   14000c4d5:	mov    rsi,rcx
   14000c4d8:	lea    rax,[rip+0xf949]        # 0x14001be28
   14000c4df:	mov    DWORD PTR [rsp+0x40],0xff
   14000c4e7:	xor    edi,edi
   14000c4e9:	mov    QWORD PTR [rsp+0x30],rax
   14000c4ee:	xor    edx,edx
   14000c4f0:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000c4f7:	lea    rcx,[rsp+0x48]
   14000c4fc:	lea    r8d,[rdi+0x78]
   14000c500:	call   0x140015692
   14000c505:	lea    rdx,[rsp+0x20]
   14000c50a:	lea    rcx,[rbp-0x30]
   14000c50e:	call   0x14000f85c
   14000c513:	mov    edx,DWORD PTR [rip+0x181f7]        # 0x140024710
   14000c519:	test   bl,bl
   14000c51b:	cmovne edx,edi
   14000c51e:	mov    DWORD PTR [rip+0x181ec],edx        # 0x140024710
   14000c524:	cmp    edx,DWORD PTR [rsi+0x4c]
   14000c527:	jge    0x14000c53c
   14000c529:	mov    rax,QWORD PTR [rsi+0x50]
   14000c52d:	movsxd rcx,edx
   14000c530:	inc    edx
   14000c532:	mov    DWORD PTR [rip+0x181d8],edx        # 0x140024710
   14000c538:	mov    rdi,QWORD PTR [rax+rcx*8]
   14000c53c:	lea    rcx,[rbp-0x30]
   14000c540:	call   0x14000f958
   14000c545:	lea    r11,[rsp+0x140]
   14000c54d:	mov    rax,rdi
   14000c550:	mov    rbx,QWORD PTR [r11+0x10]
   14000c554:	mov    rsi,QWORD PTR [r11+0x18]
   14000c558:	mov    rdi,QWORD PTR [r11+0x20]
   14000c55c:	mov    rsp,r11
   14000c55f:	pop    rbp
   14000c560:	ret
   14000c561:	int3
   14000c562:	int3
   14000c563:	int3
   14000c564:	int3
   14000c565:	int3
   14000c566:	int3
   14000c567:	int3
   14000c568:	mov    rax,rsp
   14000c56b:	mov    QWORD PTR [rax+0x8],rbx
   14000c56f:	mov    QWORD PTR [rax+0x10],rsi
   14000c573:	mov    QWORD PTR [rax+0x18],rdi
   14000c577:	push   rbp
   14000c578:	lea    rbp,[rax-0x48]
   14000c57c:	sub    rsp,0x140
   14000c583:	lea    rax,[rip+0xf8b6]        # 0x14001be40
   14000c58a:	mov    DWORD PTR [rsp+0x3c],0x7
   14000c592:	mov    QWORD PTR [rsp+0x20],rax
   14000c597:	lea    rcx,[rsp+0x48]
   14000c59c:	lea    rax,[rip+0xfa65]        # 0x14001c008
   14000c5a3:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000c5aa:	mov    QWORD PTR [rsp+0x28],rax
   14000c5af:	mov    rsi,r8
   14000c5b2:	lea    rax,[rip+0xf86f]        # 0x14001be28
   14000c5b9:	mov    rdi,rdx
   14000c5bc:	mov    QWORD PTR [rsp+0x30],rax
   14000c5c1:	xor    ebx,ebx
   14000c5c3:	mov    eax,0xff
   14000c5c8:	xor    edx,edx
   14000c5ca:	mov    DWORD PTR [rsp+0x38],eax
   14000c5ce:	mov    DWORD PTR [rsp+0x40],eax
   14000c5d2:	lea    r8d,[rbx+0x78]
   14000c5d6:	call   0x140015692
   14000c5db:	lea    rdx,[rsp+0x20]
   14000c5e0:	lea    rcx,[rbp-0x30]
   14000c5e4:	call   0x14000f85c
   14000c5e9:	test   rdi,rdi
   14000c5ec:	je     0x14000c605
   14000c5ee:	mov    rdx,rsi
   14000c5f1:	mov    rcx,rdi
   14000c5f4:	rex.W call QWORD PTR [rip+0xbc75]        # 0x140018270
   14000c5fb:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c600:	test   eax,eax
   14000c602:	sete   bl
   14000c605:	lea    rcx,[rbp-0x30]
   14000c609:	call   0x14000f958
   14000c60e:	lea    r11,[rsp+0x140]
   14000c616:	mov    al,bl
   14000c618:	mov    rbx,QWORD PTR [r11+0x10]
   14000c61c:	mov    rsi,QWORD PTR [r11+0x18]
   14000c620:	mov    rdi,QWORD PTR [r11+0x20]
   14000c624:	mov    rsp,r11
   14000c627:	pop    rbp
   14000c628:	ret
   14000c629:	int3
   14000c62a:	int3
   14000c62b:	int3
   14000c62c:	int3
   14000c62d:	int3
   14000c62e:	int3
   14000c62f:	int3
   14000c630:	mov    rax,rsp
   14000c633:	mov    QWORD PTR [rax+0x8],rbx
   14000c637:	mov    QWORD PTR [rax+0x10],rsi
   14000c63b:	mov    QWORD PTR [rax+0x18],rdi
   14000c63f:	push   rbp
   14000c640:	lea    rbp,[rax-0x48]
   14000c644:	sub    rsp,0x140
   14000c64b:	lea    rax,[rip+0xf7ee]        # 0x14001be40
   14000c652:	mov    DWORD PTR [rsp+0x38],0x119
   14000c65a:	mov    QWORD PTR [rsp+0x20],rax
   14000c65f:	lea    rcx,[rsp+0x48]
   14000c664:	mov    rdi,rdx
   14000c667:	mov    DWORD PTR [rsp+0x3c],0x7
   14000c66f:	xor    edx,edx
   14000c671:	mov    DWORD PTR [rsp+0x40],0xff
   14000c679:	lea    rax,[rip+0xf9b0]        # 0x14001c030
   14000c680:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000c687:	mov    QWORD PTR [rsp+0x28],rax
   14000c68c:	mov    rbx,r8
   14000c68f:	lea    rax,[rip+0xf792]        # 0x14001be28
   14000c696:	lea    r8d,[rdx+0x78]
   14000c69a:	mov    QWORD PTR [rsp+0x30],rax
   14000c69f:	call   0x140015692
   14000c6a4:	lea    rdx,[rsp+0x20]
   14000c6a9:	lea    rcx,[rbp-0x30]
   14000c6ad:	call   0x14000f85c
   14000c6b2:	mov    rdx,rbx
   14000c6b5:	mov    rcx,rdi
   14000c6b8:	rex.W call QWORD PTR [rip+0xb991]        # 0x140018050
   14000c6bf:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c6c4:	test   eax,eax
   14000c6c6:	lea    rcx,[rbp-0x30]
   14000c6ca:	setns  bl
   14000c6cd:	call   0x14000f958
   14000c6d2:	lea    r11,[rsp+0x140]
   14000c6da:	mov    al,bl
   14000c6dc:	mov    rbx,QWORD PTR [r11+0x10]
   14000c6e0:	mov    rsi,QWORD PTR [r11+0x18]
   14000c6e4:	mov    rdi,QWORD PTR [r11+0x20]
   14000c6e8:	mov    rsp,r11
   14000c6eb:	pop    rbp
   14000c6ec:	ret
   14000c6ed:	int3
   14000c6ee:	int3
   14000c6ef:	int3
   14000c6f0:	int3
   14000c6f1:	int3
   14000c6f2:	int3
   14000c6f3:	int3
   14000c6f4:	mov    DWORD PTR [rsp+0x10],edx
   14000c6f8:	mov    QWORD PTR [rsp+0x18],r8
   14000c6fd:	mov    QWORD PTR [rsp+0x20],r9
   14000c702:	push   rbp
   14000c703:	push   rbx
   14000c704:	push   rdi
   14000c705:	lea    rbp,[rsp-0x70]
   14000c70a:	sub    rsp,0x170
   14000c711:	mov    QWORD PTR [rsp+0x50],0xfffffffffffffffe
   14000c71a:	mov    rbx,rcx
   14000c71d:	lea    rax,[rip+0xf71c]        # 0x14001be40
   14000c724:	mov    QWORD PTR [rsp+0x58],rax
   14000c729:	lea    rax,[rip+0xf930]        # 0x14001c060
   14000c730:	mov    QWORD PTR [rsp+0x60],rax
   14000c735:	lea    rax,[rip+0xf6ec]        # 0x14001be28
   14000c73c:	mov    QWORD PTR [rsp+0x68],rax
   14000c741:	mov    DWORD PTR [rsp+0x70],0x149
   14000c749:	mov    DWORD PTR [rsp+0x74],0x7
   14000c751:	mov    DWORD PTR [rsp+0x78],0xff
   14000c759:	xor    edi,edi
   14000c75b:	mov    DWORD PTR [rbp-0x8],0x1000000
   14000c762:	xor    edx,edx
   14000c764:	lea    r8d,[rdi+0x78]
   14000c768:	lea    rcx,[rbp-0x80]
   14000c76c:	call   0x140015692
   14000c771:	lea    rdx,[rsp+0x58]
   14000c776:	lea    rcx,[rbp+0x0]
   14000c77a:	call   0x14000f85c
   14000c77f:	nop
   14000c780:	lea    rax,[rbp+0xa0]
   14000c787:	mov    QWORD PTR [rsp+0x48],rax
   14000c78c:	lea    rax,[rsp+0x48]
   14000c791:	mov    QWORD PTR [rsp+0x30],rax
   14000c796:	mov    DWORD PTR [rsp+0x28],edi
   14000c79a:	lea    rax,[rsp+0x40]
   14000c79f:	mov    QWORD PTR [rsp+0x20],rax
   14000c7a4:	mov    r9d,0x400
   14000c7aa:	mov    r8d,DWORD PTR [rbp+0x98]
   14000c7b1:	xor    edx,edx
   14000c7b3:	mov    ecx,0x900
   14000c7b8:	rex.W call QWORD PTR [rip+0xb721]        # 0x140017ee0
   14000c7bf:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c7c4:	test   eax,eax
   14000c7c6:	jne    0x14000c804
   14000c7c8:	lea    rax,[rsp+0x48]
   14000c7cd:	mov    QWORD PTR [rsp+0x30],rax
   14000c7d2:	mov    DWORD PTR [rsp+0x28],edi
   14000c7d6:	lea    rax,[rsp+0x40]
   14000c7db:	mov    QWORD PTR [rsp+0x20],rax
   14000c7e0:	mov    r9d,0x400
   14000c7e6:	mov    r8d,DWORD PTR [rbp+0x98]
   14000c7ed:	xor    edx,edx
   14000c7ef:	mov    ecx,0x1100
   14000c7f4:	rex.W call QWORD PTR [rip+0xb6e5]        # 0x140017ee0
   14000c7fb:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c800:	test   eax,eax
   14000c802:	je     0x14000c824
   14000c804:	mov    rdx,QWORD PTR [rsp+0x40]
   14000c809:	mov    rcx,rbx
   14000c80c:	call   0x14000da90
   14000c811:	mov    rcx,QWORD PTR [rsp+0x40]
   14000c816:	rex.W call QWORD PTR [rip+0xb743]        # 0x140017f60
   14000c81d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c822:	jmp    0x14000c84c
   14000c824:	rex.W call QWORD PTR [rip+0xb74d]        # 0x140017f78
   14000c82b:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c830:	mov    r8d,eax
   14000c833:	mov    edx,DWORD PTR [rbp+0x98]
   14000c839:	lea    rcx,[rip+0xf850]        # 0x14001c090
   14000c840:	rex.W call QWORD PTR [rip+0xb9e1]        # 0x140018228
   14000c847:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c84c:	mov    QWORD PTR [rsp+0x48],rdi
   14000c851:	lea    rcx,[rbp+0x0]
   14000c855:	call   0x14000f958
   14000c85a:	add    rsp,0x170
   14000c861:	pop    rdi
   14000c862:	pop    rbx
   14000c863:	pop    rbp
   14000c864:	ret
   14000c865:	int3
   14000c866:	int3
   14000c867:	int3
   14000c868:	int3
   14000c869:	int3
   14000c86a:	int3
   14000c86b:	int3
   14000c86c:	mov    DWORD PTR [rsp+0x18],r8d
   14000c871:	mov    QWORD PTR [rsp+0x20],r9
   14000c876:	push   rbp
   14000c877:	push   rbx
   14000c878:	push   rdi
   14000c879:	lea    rbp,[rsp-0x80]
   14000c87e:	sub    rsp,0x180
   14000c885:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   14000c88e:	mov    ebx,edx
   14000c890:	lea    rax,[rip+0xf5a9]        # 0x14001be40
   14000c897:	mov    QWORD PTR [rsp+0x60],rax
   14000c89c:	lea    rax,[rip+0xf83d]        # 0x14001c0e0
   14000c8a3:	mov    QWORD PTR [rsp+0x68],rax
   14000c8a8:	lea    rax,[rip+0xf579]        # 0x14001be28
   14000c8af:	mov    QWORD PTR [rsp+0x70],rax
   14000c8b4:	mov    DWORD PTR [rsp+0x78],0x179
   14000c8bc:	mov    DWORD PTR [rsp+0x7c],0x7
   14000c8c4:	mov    DWORD PTR [rbp-0x80],0xff
   14000c8cb:	xor    edi,edi
   14000c8cd:	mov    DWORD PTR [rbp+0x0],0x1000000
   14000c8d4:	xor    edx,edx
   14000c8d6:	lea    r8d,[rdi+0x78]
   14000c8da:	lea    rcx,[rbp-0x78]
   14000c8de:	call   0x140015692
   14000c8e3:	lea    rdx,[rsp+0x60]
   14000c8e8:	lea    rcx,[rbp+0x10]
   14000c8ec:	call   0x14000f85c
   14000c8f1:	nop
   14000c8f2:	mov    QWORD PTR [rsp+0x48],rdi
   14000c8f7:	lea    rax,[rbp+0xb8]
   14000c8fe:	mov    QWORD PTR [rsp+0x50],rax
   14000c903:	mov    eax,ebx
   14000c905:	neg    eax
   14000c907:	sbb    ecx,ecx
   14000c909:	and    ecx,0xffffff50
   14000c90f:	add    ecx,0x9ff
   14000c915:	lea    rax,[rsp+0x50]
   14000c91a:	mov    QWORD PTR [rsp+0x30],rax
   14000c91f:	mov    DWORD PTR [rsp+0x28],edi
   14000c923:	lea    rax,[rsp+0x40]
   14000c928:	mov    QWORD PTR [rsp+0x20],rax
   14000c92d:	mov    r9d,0x400
   14000c933:	mov    r8d,DWORD PTR [rbp+0xb0]
   14000c93a:	xor    edx,edx
   14000c93c:	rex.W call QWORD PTR [rip+0xb59d]        # 0x140017ee0
   14000c943:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c948:	test   eax,eax
   14000c94a:	jne    0x14000c993
   14000c94c:	neg    ebx
   14000c94e:	sbb    ecx,ecx
   14000c950:	and    ecx,0xffffff50
   14000c956:	add    ecx,0x11ff
   14000c95c:	lea    rax,[rsp+0x50]
   14000c961:	mov    QWORD PTR [rsp+0x30],rax
   14000c966:	mov    DWORD PTR [rsp+0x28],edi
   14000c96a:	lea    rax,[rsp+0x40]
   14000c96f:	mov    QWORD PTR [rsp+0x20],rax
   14000c974:	mov    r9d,0x400
   14000c97a:	mov    r8d,DWORD PTR [rbp+0xb0]
   14000c981:	xor    edx,edx
   14000c983:	rex.W call QWORD PTR [rip+0xb556]        # 0x140017ee0
   14000c98a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c98f:	test   eax,eax
   14000c991:	je     0x14000c9bf
   14000c993:	mov    rcx,QWORD PTR [rsp+0x40]
   14000c998:	test   rcx,rcx
   14000c99b:	je     0x14000c9b3
   14000c99d:	mov    r8,rcx
   14000c9a0:	lea    rdx,[rsp+0x48]
   14000c9a5:	lea    rcx,[rbp+0x10]
   14000c9a9:	call   0x140003688
   14000c9ae:	mov    rcx,QWORD PTR [rsp+0x40]
   14000c9b3:	rex.W call QWORD PTR [rip+0xb5a6]        # 0x140017f60
   14000c9ba:	nop    DWORD PTR [rax+rax*1+0x0]
   14000c9bf:	mov    QWORD PTR [rsp+0x50],rdi
   14000c9c4:	lea    rcx,[rbp+0x10]
   14000c9c8:	call   0x14000f958
   14000c9cd:	mov    rax,QWORD PTR [rsp+0x48]
   14000c9d2:	add    rsp,0x180
   14000c9d9:	pop    rdi
   14000c9da:	pop    rbx
   14000c9db:	pop    rbp
   14000c9dc:	ret
   14000c9dd:	int3
   14000c9de:	int3
   14000c9df:	int3
   14000c9e0:	int3
   14000c9e1:	int3
   14000c9e2:	int3
   14000c9e3:	int3
   14000c9e4:	mov    rax,rsp
   14000c9e7:	push   rbp
   14000c9e8:	push   rsi
   14000c9e9:	push   rdi
   14000c9ea:	push   r12
   14000c9ec:	push   r13
   14000c9ee:	push   r14
   14000c9f0:	push   r15
   14000c9f2:	lea    rbp,[rax-0x218]
   14000c9f9:	sub    rsp,0x2e0
   14000ca00:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   14000ca08:	mov    QWORD PTR [rax+0x18],rbx
   14000ca0c:	mov    rax,QWORD PTR [rip+0x17705]        # 0x140024118
   14000ca13:	xor    rax,rsp
   14000ca16:	mov    QWORD PTR [rbp+0x1d0],rax
   14000ca1d:	mov    edi,r9d
   14000ca20:	mov    rsi,rdx
   14000ca23:	mov    r14,rcx
   14000ca26:	lea    r12,[rip+0xf413]        # 0x14001be40
   14000ca2d:	mov    QWORD PTR [rsp+0x50],r12
   14000ca32:	lea    r13,[rip+0xf6d7]        # 0x14001c110
   14000ca39:	mov    QWORD PTR [rsp+0x58],r13
   14000ca3e:	lea    rax,[rip+0xf3e3]        # 0x14001be28
   14000ca45:	mov    QWORD PTR [rsp+0x60],rax
   14000ca4a:	mov    DWORD PTR [rsp+0x68],0x1ab
   14000ca52:	mov    DWORD PTR [rsp+0x6c],0x7
   14000ca5a:	mov    DWORD PTR [rsp+0x70],0xff
   14000ca62:	xor    r15d,r15d
   14000ca65:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000ca6c:	xor    edx,edx
   14000ca6e:	lea    r8d,[r15+0x78]
   14000ca72:	lea    rcx,[rsp+0x78]
   14000ca77:	call   0x140015692
   14000ca7c:	lea    rdx,[rsp+0x50]
   14000ca81:	lea    rcx,[rbp+0x0]
   14000ca85:	call   0x14000f85c
   14000ca8a:	nop
   14000ca8b:	cmp    WORD PTR [rsi],r15w
   14000ca8f:	je     0x14000cb24
   14000ca95:	lea    r8,[rip+0xf038]        # 0x14001bad4
   14000ca9c:	mov    edx,0x400
   14000caa1:	mov    rcx,rsi
   14000caa4:	call   0x140003518
   14000caa9:	mov    ebx,eax
   14000caab:	mov    DWORD PTR [rbp+0x8],eax
   14000caae:	mov    QWORD PTR [rbp+0x120],r12
   14000cab5:	mov    QWORD PTR [rbp+0x128],r13
   14000cabc:	lea    rax,[rip+0xf365]        # 0x14001be28
   14000cac3:	mov    QWORD PTR [rbp+0x130],rax
   14000caca:	mov    DWORD PTR [rbp+0x138],0x1b1
   14000cad4:	mov    DWORD PTR [rbp+0x13c],0x7
   14000cade:	mov    DWORD PTR [rbp+0x140],0xff
   14000cae8:	mov    DWORD PTR [rbp+0x1c0],0x1000000
   14000caf2:	xor    edx,edx
   14000caf4:	lea    r8d,[r15+0x78]
   14000caf8:	lea    rcx,[rbp+0x148]
   14000caff:	call   0x140015692
   14000cb04:	lea    rax,[rbp+0x120]
   14000cb0b:	mov    QWORD PTR [rsp+0x48],rax
   14000cb10:	test   ebx,ebx
   14000cb12:	js     0x14000ccd3
   14000cb18:	lea    rcx,[rbp+0x120]
   14000cb1f:	call   0x14000f484
   14000cb24:	test   edi,edi
   14000cb26:	je     0x14000cbe4
   14000cb2c:	mov    r8d,edi
   14000cb2f:	xor    edx,edx
   14000cb31:	mov    rcx,r14
   14000cb34:	call   0x14000c86c
   14000cb39:	mov    rbx,rax
   14000cb3c:	test   rax,rax
   14000cb3f:	je     0x14000ccfb
   14000cb45:	mov    r8,rax
   14000cb48:	mov    edx,0x400
   14000cb4d:	mov    rcx,rsi
   14000cb50:	call   0x140003518
   14000cb55:	mov    edi,eax
   14000cb57:	mov    DWORD PTR [rbp+0x8],eax
   14000cb5a:	mov    QWORD PTR [rbp+0x120],r12
   14000cb61:	mov    QWORD PTR [rbp+0x128],r13
   14000cb68:	lea    rax,[rip+0xf2b9]        # 0x14001be28
   14000cb6f:	mov    QWORD PTR [rbp+0x130],rax
   14000cb76:	mov    DWORD PTR [rbp+0x138],0x1c1
   14000cb80:	mov    DWORD PTR [rbp+0x13c],0x7
   14000cb8a:	mov    DWORD PTR [rbp+0x140],0xff
   14000cb94:	mov    DWORD PTR [rbp+0x1c0],0x1000000
   14000cb9e:	xor    edx,edx
   14000cba0:	lea    r8d,[rdx+0x78]
   14000cba4:	lea    rcx,[rbp+0x148]
   14000cbab:	call   0x140015692
   14000cbb0:	lea    rax,[rbp+0x120]
   14000cbb7:	mov    QWORD PTR [rsp+0x40],rax
   14000cbbc:	test   edi,edi
   14000cbbe:	js     0x14000cd53
   14000cbc4:	lea    rcx,[rbp+0x120]
   14000cbcb:	call   0x14000f484
   14000cbd0:	mov    rcx,rbx
   14000cbd3:	rex.W call QWORD PTR [rip+0xb4a6]        # 0x140018080
   14000cbda:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cbdf:	jmp    0x14000cc7a
   14000cbe4:	mov    r9d,DWORD PTR [rbp+0x240]
   14000cbeb:	lea    r8,[rip+0xf566]        # 0x14001c158
   14000cbf2:	mov    edx,0x40
   14000cbf7:	lea    rcx,[rbp+0x120]
   14000cbfe:	call   0x140003494
   14000cc03:	lea    r8,[rbp+0x120]
   14000cc0a:	mov    edx,0x400
   14000cc0f:	mov    rcx,rsi
   14000cc12:	call   0x140003518
   14000cc17:	mov    ebx,eax
   14000cc19:	mov    DWORD PTR [rbp+0x8],eax
   14000cc1c:	mov    QWORD PTR [rsp+0x50],r12
   14000cc21:	mov    QWORD PTR [rsp+0x58],r13
   14000cc26:	lea    rax,[rip+0xf1fb]        # 0x14001be28
   14000cc2d:	mov    QWORD PTR [rsp+0x60],rax
   14000cc32:	mov    DWORD PTR [rsp+0x68],0x1ce
   14000cc3a:	mov    DWORD PTR [rsp+0x6c],0x7
   14000cc42:	mov    DWORD PTR [rsp+0x70],0xff
   14000cc4a:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000cc51:	xor    edx,edx
   14000cc53:	lea    r8d,[rdx+0x78]
   14000cc57:	lea    rcx,[rsp+0x78]
   14000cc5c:	call   0x140015692
   14000cc61:	lea    rax,[rsp+0x50]
   14000cc66:	mov    QWORD PTR [rsp+0x40],rax
   14000cc6b:	test   ebx,ebx
   14000cc6d:	js     0x14000ccae
   14000cc6f:	lea    rcx,[rsp+0x50]
   14000cc74:	call   0x14000f484
   14000cc79:	nop
   14000cc7a:	lea    rcx,[rbp+0x0]
   14000cc7e:	call   0x14000f958
   14000cc83:	mov    rcx,QWORD PTR [rbp+0x1d0]
   14000cc8a:	xor    rcx,rsp
   14000cc8d:	call   0x1400143c0
   14000cc92:	mov    rbx,QWORD PTR [rsp+0x330]
   14000cc9a:	add    rsp,0x2e0
   14000cca1:	pop    r15
   14000cca3:	pop    r14
   14000cca5:	pop    r13
   14000cca7:	pop    r12
   14000cca9:	pop    rdi
   14000ccaa:	pop    rsi
   14000ccab:	pop    rbp
   14000ccac:	ret
   14000ccad:	int3
   14000ccae:	lea    rdx,[rsp+0x50]
   14000ccb3:	lea    rcx,[rbp+0x70]
   14000ccb7:	call   0x14000f400
   14000ccbc:	lea    r9,[rip+0xc11d]        # 0x140018de0
   14000ccc3:	mov    r8d,ebx
   14000ccc6:	mov    rdx,rax
   14000ccc9:	lea    rcx,[rbp+0x0]
   14000cccd:	call   0x140010848
   14000ccd2:	nop
   14000ccd3:	lea    rdx,[rbp+0x120]
   14000ccda:	lea    rcx,[rsp+0x50]
   14000ccdf:	call   0x14000f400
   14000cce4:	lea    r9,[rip+0xc0f5]        # 0x140018de0
   14000cceb:	mov    r8d,ebx
   14000ccee:	mov    rdx,rax
   14000ccf1:	lea    rcx,[rbp+0x0]
   14000ccf5:	call   0x140010848
   14000ccfa:	nop
   14000ccfb:	mov    DWORD PTR [rsp+0x28],0x7
   14000cd03:	mov    DWORD PTR [rsp+0x20],0x1bb
   14000cd0b:	mov    r9,r13
   14000cd0e:	lea    r8,[rip+0xf113]        # 0x14001be28
   14000cd15:	mov    rdx,r12
   14000cd18:	lea    rcx,[rsp+0x50]
   14000cd1d:	call   0x14000f3ac
   14000cd22:	mov    rbx,rax
   14000cd25:	rex.W call QWORD PTR [rip+0xb24c]        # 0x140017f78
   14000cd2c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cd31:	mov    DWORD PTR [rsp+0x28],eax
   14000cd35:	mov    DWORD PTR [rsp+0x20],edi
   14000cd39:	lea    r9,[rip+0xc160]        # 0x140018ea0
   14000cd40:	mov    r8d,0x8000ffff
   14000cd46:	mov    rdx,rbx
   14000cd49:	lea    rcx,[rbp+0x0]
   14000cd4d:	call   0x1400106b0
   14000cd52:	nop
   14000cd53:	lea    rdx,[rbp+0x120]
   14000cd5a:	lea    rcx,[rsp+0x50]
   14000cd5f:	call   0x14000f400
   14000cd64:	lea    r9,[rip+0xc075]        # 0x140018de0
   14000cd6b:	mov    r8d,edi
   14000cd6e:	mov    rdx,rax
   14000cd71:	lea    rcx,[rbp+0x0]
   14000cd75:	call   0x140010848
   14000cd7a:	int3
   14000cd7b:	int3
   14000cd7c:	int3
   14000cd7d:	int3
   14000cd7e:	int3
   14000cd7f:	int3
   14000cd80:	int3
   14000cd81:	int3
   14000cd82:	int3
   14000cd83:	int3
   14000cd84:	mov    rax,rsp
   14000cd87:	mov    QWORD PTR [rax+0x8],rcx
   14000cd8b:	push   rbp
   14000cd8c:	push   rsi
   14000cd8d:	push   rdi
   14000cd8e:	push   r12
   14000cd90:	push   r13
   14000cd92:	push   r14
   14000cd94:	push   r15
   14000cd96:	lea    rbp,[rsp-0x70]
   14000cd9b:	sub    rsp,0x170
   14000cda2:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   14000cdaa:	mov    QWORD PTR [rax+0x10],rbx
   14000cdae:	mov    esi,r8d
   14000cdb1:	mov    r14,rdx
   14000cdb4:	lea    rax,[rip+0xf085]        # 0x14001be40
   14000cdbb:	mov    QWORD PTR [rsp+0x50],rax
   14000cdc0:	lea    rax,[rip+0xf3a1]        # 0x14001c168
   14000cdc7:	mov    QWORD PTR [rsp+0x58],rax
   14000cdcc:	lea    rax,[rip+0xf055]        # 0x14001be28
   14000cdd3:	mov    QWORD PTR [rsp+0x60],rax
   14000cdd8:	mov    DWORD PTR [rsp+0x68],0x1db
   14000cde0:	mov    DWORD PTR [rsp+0x6c],0x7
   14000cde8:	mov    DWORD PTR [rsp+0x70],0xff
   14000cdf0:	xor    r12d,r12d
   14000cdf3:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000cdfa:	xor    edx,edx
   14000cdfc:	lea    r8d,[r12+0x78]
   14000ce01:	lea    rcx,[rsp+0x78]
   14000ce06:	call   0x140015692
   14000ce0b:	lea    rdx,[rsp+0x50]
   14000ce10:	lea    rcx,[rbp+0x0]
   14000ce14:	call   0x14000f85c
   14000ce19:	nop
   14000ce1a:	lea    r15d,[r12+0x42]
   14000ce1f:	lea    rdx,[rip+0xf37a]        # 0x14001c1a0
   14000ce26:	mov    rcx,r14
   14000ce29:	rex.W call QWORD PTR [rip+0xb440]        # 0x140018270
   14000ce30:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ce35:	or     r13,0xffffffffffffffff
   14000ce39:	test   eax,eax
   14000ce3b:	je     0x14000ce9f
   14000ce3d:	mov    QWORD PTR [rsp+0x48],r12
   14000ce42:	lea    rax,[rip+0xa217]        # 0x140017060
   14000ce49:	mov    QWORD PTR [rsp+0x40],rax
   14000ce4e:	mov    rdx,r14
   14000ce51:	lea    rcx,[rsp+0x40]
   14000ce56:	call   0x14000b90c
   14000ce5b:	mov    rdi,QWORD PTR [rsp+0x48]
   14000ce60:	mov    rbx,r13
   14000ce63:	inc    rbx
   14000ce66:	cmp    WORD PTR [rdi+rbx*2],r12w
   14000ce6b:	jne    0x14000ce63
   14000ce6d:	test   rbx,rbx
   14000ce70:	je     0x14000ce8a
   14000ce72:	cmp    WORD PTR [rdi+rbx*2-0x2],0x20
   14000ce78:	jne    0x14000ce85
   14000ce7a:	sub    rbx,0x1
   14000ce7e:	mov    WORD PTR [rdi+rbx*2],r12w
   14000ce83:	jne    0x14000ce72
   14000ce85:	test   rbx,rbx
   14000ce88:	jne    0x14000cec7
   14000ce8a:	test   rdi,rdi
   14000ce8d:	je     0x14000ce9f
   14000ce8f:	mov    rcx,rdi
   14000ce92:	rex.W call QWORD PTR [rip+0xb1e7]        # 0x140018080
   14000ce99:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ce9e:	nop
   14000ce9f:	lea    rcx,[rbp+0x0]
   14000cea3:	call   0x14000f958
   14000cea8:	mov    rax,r13
   14000ceab:	mov    rbx,QWORD PTR [rsp+0x1b8]
   14000ceb3:	add    rsp,0x170
   14000ceba:	pop    r15
   14000cebc:	pop    r14
   14000cebe:	pop    r13
   14000cec0:	pop    r12
   14000cec2:	pop    rdi
   14000cec3:	pop    rsi
   14000cec4:	pop    rbp
   14000cec5:	ret
   14000cec6:	int3
   14000cec7:	test   esi,esi
   14000cec9:	je     0x14000cfa4
   14000cecf:	cmp    rbx,0x3
   14000ced3:	jbe    0x14000cf18
   14000ced5:	movzx  ecx,WORD PTR [rdi+rbx*2-0x6]
   14000ceda:	rex.W call QWORD PTR [rip+0xb33f]        # 0x140018220
   14000cee1:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cee6:	test   eax,eax
   14000cee8:	je     0x14000cf18
   14000ceea:	movzx  ecx,WORD PTR [rdi+rbx*2-0x4]
   14000ceef:	rex.W call QWORD PTR [rip+0xb32a]        # 0x140018220
   14000cef6:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cefb:	test   eax,eax
   14000cefd:	je     0x14000cf18
   14000ceff:	movzx  ecx,WORD PTR [rdi+rbx*2-0x2]
   14000cf04:	rex.W call QWORD PTR [rip+0xb315]        # 0x140018220
   14000cf0b:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cf10:	test   eax,eax
   14000cf12:	jne    0x14000d12b
   14000cf18:	cmp    rbx,0x2
   14000cf1c:	jbe    0x14000cf76
   14000cf1e:	movzx  ecx,WORD PTR [rdi+rbx*2-0x4]
   14000cf23:	rex.W call QWORD PTR [rip+0xb2f6]        # 0x140018220
   14000cf2a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cf2f:	test   eax,eax
   14000cf31:	je     0x14000cf76
   14000cf33:	movzx  ecx,WORD PTR [rdi+rbx*2-0x2]
   14000cf38:	rex.W call QWORD PTR [rip+0xb2d9]        # 0x140018218
   14000cf3f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cf44:	mov    esi,0x42
   14000cf49:	cmp    ax,si
   14000cf4c:	jne    0x14000cf7b
   14000cf4e:	movzx  ecx,WORD PTR [rdi+rbx*2-0x4]
   14000cf53:	rex.W call QWORD PTR [rip+0xb2be]        # 0x140018218
   14000cf5a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cf5f:	cmp    ax,si
   14000cf62:	je     0x14000d179
   14000cf68:	movzx  r15d,WORD PTR [rdi+rbx*2-0x4]
   14000cf6e:	mov    WORD PTR [rdi+rbx*2-0x4],r12w
   14000cf74:	jmp    0x14000cfde
   14000cf76:	mov    esi,0x42
   14000cf7b:	cmp    rbx,0x1
   14000cf7f:	jbe    0x14000cfde
   14000cf81:	movzx  ecx,WORD PTR [rdi+rbx*2-0x2]
   14000cf86:	rex.W call QWORD PTR [rip+0xb293]        # 0x140018220
   14000cf8d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cf92:	test   eax,eax
   14000cf94:	je     0x14000cfde
   14000cf96:	movzx  r15d,WORD PTR [rdi+rbx*2-0x2]
   14000cf9c:	mov    WORD PTR [rdi+rbx*2-0x2],r12w
   14000cfa2:	jmp    0x14000cfde
   14000cfa4:	mov    rbx,r13
   14000cfa7:	inc    rbx
   14000cfaa:	cmp    WORD PTR [rdi+rbx*2],r12w
   14000cfaf:	jne    0x14000cfa7
   14000cfb1:	mov    rsi,r12
   14000cfb4:	test   rbx,rbx
   14000cfb7:	je     0x14000cfd9
   14000cfb9:	movzx  ecx,WORD PTR [rdi+rsi*2]
   14000cfbd:	rex.W call QWORD PTR [rip+0xb24c]        # 0x140018210
   14000cfc4:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cfc9:	test   eax,eax
   14000cfcb:	je     0x14000d215
   14000cfd1:	inc    rsi
   14000cfd4:	cmp    rsi,rbx
   14000cfd7:	jb     0x14000cfb9
   14000cfd9:	mov    esi,0x42
   14000cfde:	lea    r8,[rbp+0xb0]
   14000cfe5:	lea    rdx,[rip+0xf334]        # 0x14001c320
   14000cfec:	mov    rcx,rdi
   14000cfef:	rex.W call QWORD PTR [rip+0xb1da]        # 0x1400181d0
   14000cff6:	nop    DWORD PTR [rax+rax*1+0x0]
   14000cffb:	cmp    eax,0x1
   14000cffe:	jne    0x14000d1c7
   14000d004:	movzx  ecx,r15w
   14000d008:	rex.W call QWORD PTR [rip+0xb209]        # 0x140018218
   14000d00f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d014:	movzx  eax,ax
   14000d017:	cmp    eax,esi
   14000d019:	je     0x14000d0a5
   14000d01f:	movsd  xmm1,QWORD PTR [rip+0x11a31]        # 0x14001ea58
   14000d027:	cmp    eax,0x45
   14000d02a:	je     0x14000d07b
   14000d02c:	cmp    eax,0x47
   14000d02f:	je     0x14000d071
   14000d031:	cmp    eax,0x4b
   14000d034:	je     0x14000d067
   14000d036:	cmp    eax,0x4d
   14000d039:	je     0x14000d05d
   14000d03b:	cmp    eax,0x50
   14000d03e:	je     0x14000d053
   14000d040:	cmp    eax,0x54
   14000d043:	jne    0x14000d263
   14000d049:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d051:	jmp    0x14000d08b
   14000d053:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d05b:	jmp    0x14000d087
   14000d05d:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d065:	jmp    0x14000d093
   14000d067:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d06f:	jmp    0x14000d097
   14000d071:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d079:	jmp    0x14000d08f
   14000d07b:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d083:	mulsd  xmm0,xmm1
   14000d087:	mulsd  xmm0,xmm1
   14000d08b:	mulsd  xmm0,xmm1
   14000d08f:	mulsd  xmm0,xmm1
   14000d093:	mulsd  xmm0,xmm1
   14000d097:	mulsd  xmm0,xmm1
   14000d09b:	movsd  QWORD PTR [rbp+0xb0],xmm0
   14000d0a3:	jmp    0x14000d0ad
   14000d0a5:	movsd  xmm0,QWORD PTR [rbp+0xb0]
   14000d0ad:	cvttsd2si rbx,xmm0
   14000d0b2:	cmp    rbx,r13
   14000d0b5:	jle    0x14000d0dd
   14000d0b7:	test   rdi,rdi
   14000d0ba:	je     0x14000d0cc
   14000d0bc:	mov    rcx,rdi
   14000d0bf:	rex.W call QWORD PTR [rip+0xafba]        # 0x140018080
   14000d0c6:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d0cb:	nop
   14000d0cc:	lea    rcx,[rbp+0x0]
   14000d0d0:	call   0x14000f958
   14000d0d5:	mov    rax,rbx
   14000d0d8:	jmp    0x14000ceab
   14000d0dd:	mov    DWORD PTR [rsp+0x28],0x7
   14000d0e5:	mov    DWORD PTR [rsp+0x20],0x240
   14000d0ed:	lea    r9,[rip+0xf074]        # 0x14001c168
   14000d0f4:	lea    r8,[rip+0xed2d]        # 0x14001be28
   14000d0fb:	lea    rdx,[rip+0xed3e]        # 0x14001be40
   14000d102:	lea    rcx,[rsp+0x50]
   14000d107:	call   0x14000f3ac
   14000d10c:	mov    QWORD PTR [rsp+0x20],r14
   14000d111:	lea    r9,[rip+0xf210]        # 0x14001c328
   14000d118:	mov    r8d,0x1001
   14000d11e:	mov    rdx,rax
   14000d121:	lea    rcx,[rbp+0x0]
   14000d125:	call   0x1400106b0
   14000d12a:	int3
   14000d12b:	mov    DWORD PTR [rsp+0x28],0x7
   14000d133:	mov    DWORD PTR [rsp+0x20],0x1fe
   14000d13b:	lea    r9,[rip+0xf026]        # 0x14001c168
   14000d142:	lea    r8,[rip+0xecdf]        # 0x14001be28
   14000d149:	lea    rdx,[rip+0xecf0]        # 0x14001be40
   14000d150:	lea    rcx,[rsp+0x50]
   14000d155:	call   0x14000f3ac
   14000d15a:	mov    QWORD PTR [rsp+0x20],r14
   14000d15f:	lea    r9,[rip+0xf05a]        # 0x14001c1c0
   14000d166:	mov    r8d,0x1001
   14000d16c:	mov    rdx,rax
   14000d16f:	lea    rcx,[rbp+0x0]
   14000d173:	call   0x1400106b0
   14000d178:	int3
   14000d179:	mov    DWORD PTR [rsp+0x28],0x7
   14000d181:	mov    DWORD PTR [rsp+0x20],0x205
   14000d189:	lea    r9,[rip+0xefd8]        # 0x14001c168
   14000d190:	lea    r8,[rip+0xec91]        # 0x14001be28
   14000d197:	lea    rdx,[rip+0xeca2]        # 0x14001be40
   14000d19e:	lea    rcx,[rsp+0x50]
   14000d1a3:	call   0x14000f3ac
   14000d1a8:	mov    QWORD PTR [rsp+0x20],r14
   14000d1ad:	lea    r9,[rip+0xf08c]        # 0x14001c240
   14000d1b4:	mov    r8d,0x1001
   14000d1ba:	mov    rdx,rax
   14000d1bd:	lea    rcx,[rbp+0x0]
   14000d1c1:	call   0x1400106b0
   14000d1c6:	int3
   14000d1c7:	mov    DWORD PTR [rsp+0x28],0x7
   14000d1cf:	mov    DWORD PTR [rsp+0x20],0x222
   14000d1d7:	lea    r9,[rip+0xef8a]        # 0x14001c168
   14000d1de:	lea    r8,[rip+0xec43]        # 0x14001be28
   14000d1e5:	lea    rdx,[rip+0xec54]        # 0x14001be40
   14000d1ec:	lea    rcx,[rsp+0x50]
   14000d1f1:	call   0x14000f3ac
   14000d1f6:	mov    QWORD PTR [rsp+0x20],r14
   14000d1fb:	lea    r9,[rip+0xf126]        # 0x14001c328
   14000d202:	mov    r8d,0x1001
   14000d208:	mov    rdx,rax
   14000d20b:	lea    rcx,[rbp+0x0]
   14000d20f:	call   0x1400106b0
   14000d214:	int3
   14000d215:	mov    DWORD PTR [rsp+0x28],0x7
   14000d21d:	mov    DWORD PTR [rsp+0x20],0x21a
   14000d225:	lea    r9,[rip+0xef3c]        # 0x14001c168
   14000d22c:	lea    r8,[rip+0xebf5]        # 0x14001be28
   14000d233:	lea    rdx,[rip+0xec06]        # 0x14001be40
   14000d23a:	lea    rcx,[rsp+0x50]
   14000d23f:	call   0x14000f3ac
   14000d244:	mov    QWORD PTR [rsp+0x20],r14
   14000d249:	lea    r9,[rip+0xf060]        # 0x14001c2b0
   14000d250:	mov    r8d,0x1001
   14000d256:	mov    rdx,rax
   14000d259:	lea    rcx,[rbp+0x0]
   14000d25d:	call   0x1400106b0
   14000d262:	int3
   14000d263:	mov    DWORD PTR [rsp+0x28],0x7
   14000d26b:	mov    DWORD PTR [rsp+0x20],0x238
   14000d273:	lea    r9,[rip+0xeeee]        # 0x14001c168
   14000d27a:	lea    r8,[rip+0xeba7]        # 0x14001be28
   14000d281:	lea    rdx,[rip+0xebb8]        # 0x14001be40
   14000d288:	lea    rcx,[rsp+0x50]
   14000d28d:	call   0x14000f3ac
   14000d292:	mov    QWORD PTR [rsp+0x20],r14
   14000d297:	lea    r9,[rip+0xf08a]        # 0x14001c328
   14000d29e:	mov    r8d,0x1001
   14000d2a4:	mov    rdx,rax
   14000d2a7:	lea    rcx,[rbp+0x0]
   14000d2ab:	call   0x1400106b0
   14000d2b0:	int3
   14000d2b1:	int3
   14000d2b2:	int3
   14000d2b3:	int3
   14000d2b4:	int3
   14000d2b5:	int3
   14000d2b6:	int3
   14000d2b7:	int3
   14000d2b8:	mov    rax,rsp
   14000d2bb:	push   rbp
   14000d2bc:	push   r12
   14000d2be:	push   r13
   14000d2c0:	push   r14
   14000d2c2:	push   r15
   14000d2c4:	lea    rbp,[rax-0x1d8]
   14000d2cb:	sub    rsp,0x2b0
   14000d2d2:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   14000d2da:	mov    QWORD PTR [rax+0x8],rbx
   14000d2de:	mov    QWORD PTR [rax+0x18],rsi
   14000d2e2:	mov    QWORD PTR [rax+0x20],rdi
   14000d2e6:	mov    rax,QWORD PTR [rip+0x16e2b]        # 0x140024118
   14000d2ed:	xor    rax,rsp
   14000d2f0:	mov    QWORD PTR [rbp+0x1a0],rax
   14000d2f7:	mov    edi,r8d
   14000d2fa:	mov    rbx,rdx
   14000d2fd:	mov    rsi,rcx
   14000d300:	lea    r15,[rip+0xeb39]        # 0x14001be40
   14000d307:	mov    QWORD PTR [rsp+0x50],r15
   14000d30c:	lea    r12,[rip+0xf04d]        # 0x14001c360
   14000d313:	mov    QWORD PTR [rsp+0x58],r12
   14000d318:	lea    r13,[rip+0xeb09]        # 0x14001be28
   14000d31f:	mov    QWORD PTR [rsp+0x60],r13
   14000d324:	mov    DWORD PTR [rsp+0x68],0x24f
   14000d32c:	mov    DWORD PTR [rsp+0x6c],0x7
   14000d334:	mov    DWORD PTR [rsp+0x70],0xff
   14000d33c:	xor    r14d,r14d
   14000d33f:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000d346:	xor    edx,edx
   14000d348:	lea    r8d,[r14+0x78]
   14000d34c:	lea    rcx,[rsp+0x78]
   14000d351:	call   0x140015692
   14000d356:	lea    rdx,[rsp+0x50]
   14000d35b:	lea    rcx,[rbp+0x0]
   14000d35f:	call   0x14000f85c
   14000d364:	nop
   14000d365:	mov    QWORD PTR [rsp+0x40],r14
   14000d36a:	xor    edx,edx
   14000d36c:	mov    r8d,0x80
   14000d372:	lea    rcx,[rbp+0x120]
   14000d379:	call   0x140015692
   14000d37e:	test   rbx,rbx
   14000d381:	jns    0x14000d3b2
   14000d383:	mov    edi,0x40002712
   14000d388:	mov    r8d,edi
   14000d38b:	xor    edx,edx
   14000d38d:	mov    rcx,rsi
   14000d390:	call   0x14000c86c
   14000d395:	mov    rbx,rax
   14000d398:	test   rax,rax
   14000d39b:	je     0x14000d4c8
   14000d3a1:	lea    rcx,[rbp+0x0]
   14000d3a5:	call   0x14000f958
   14000d3aa:	mov    rax,rbx
   14000d3ad:	jmp    0x14000d472
   14000d3b2:	test   edi,edi
   14000d3b4:	je     0x14000d433
   14000d3b6:	mov    r9d,0x40
   14000d3bc:	lea    r8,[rbp+0x120]
   14000d3c3:	lea    edx,[r9-0x3f]
   14000d3c7:	mov    rcx,rbx
   14000d3ca:	rex.W call QWORD PTR [rip+0xad4f]        # 0x140018120
   14000d3d1:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d3d6:	mov    ebx,eax
   14000d3d8:	mov    DWORD PTR [rbp+0x8],eax
   14000d3db:	mov    QWORD PTR [rsp+0x50],r15
   14000d3e0:	mov    QWORD PTR [rsp+0x58],r12
   14000d3e5:	mov    QWORD PTR [rsp+0x60],r13
   14000d3ea:	mov    DWORD PTR [rsp+0x68],0x269
   14000d3f2:	mov    DWORD PTR [rsp+0x6c],0x7
   14000d3fa:	mov    DWORD PTR [rsp+0x70],0xff
   14000d402:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000d409:	xor    edx,edx
   14000d40b:	lea    r8d,[rdx+0x78]
   14000d40f:	lea    rcx,[rsp+0x78]
   14000d414:	call   0x140015692
   14000d419:	lea    rax,[rsp+0x50]
   14000d41e:	mov    QWORD PTR [rsp+0x48],rax
   14000d423:	test   ebx,ebx
   14000d425:	js     0x14000d4a3
   14000d427:	lea    rcx,[rsp+0x50]
   14000d42c:	call   0x14000f484
   14000d431:	jmp    0x14000d44e
   14000d433:	mov    r9,rbx
   14000d436:	lea    r8,[rip+0xef83]        # 0x14001c3c0
   14000d43d:	mov    edx,0x40
   14000d442:	lea    rcx,[rbp+0x120]
   14000d449:	call   0x140003494
   14000d44e:	lea    r8,[rbp+0x120]
   14000d455:	lea    rdx,[rsp+0x40]
   14000d45a:	lea    rcx,[rbp+0x0]
   14000d45e:	call   0x140003688
   14000d463:	nop
   14000d464:	lea    rcx,[rbp+0x0]
   14000d468:	call   0x14000f958
   14000d46d:	mov    rax,QWORD PTR [rsp+0x40]
   14000d472:	mov    rcx,QWORD PTR [rbp+0x1a0]
   14000d479:	xor    rcx,rsp
   14000d47c:	call   0x1400143c0
   14000d481:	lea    r11,[rsp+0x2b0]
   14000d489:	mov    rbx,QWORD PTR [r11+0x30]
   14000d48d:	mov    rsi,QWORD PTR [r11+0x40]
   14000d491:	mov    rdi,QWORD PTR [r11+0x48]
   14000d495:	mov    rsp,r11
   14000d498:	pop    r15
   14000d49a:	pop    r14
   14000d49c:	pop    r13
   14000d49e:	pop    r12
   14000d4a0:	pop    rbp
   14000d4a1:	ret
   14000d4a2:	int3
   14000d4a3:	lea    rdx,[rsp+0x50]
   14000d4a8:	lea    rcx,[rbp+0x70]
   14000d4ac:	call   0x14000f400
   14000d4b1:	lea    r9,[rip+0xeee0]        # 0x14001c398
   14000d4b8:	mov    r8d,ebx
   14000d4bb:	mov    rdx,rax
   14000d4be:	lea    rcx,[rbp+0x0]
   14000d4c2:	call   0x140010848
   14000d4c7:	nop
   14000d4c8:	mov    DWORD PTR [rsp+0x28],0x7
   14000d4d0:	mov    DWORD PTR [rsp+0x20],0x25a
   14000d4d8:	mov    r9,r12
   14000d4db:	mov    r8,r13
   14000d4de:	mov    rdx,r15
   14000d4e1:	lea    rcx,[rsp+0x50]
   14000d4e6:	call   0x14000f3ac
   14000d4eb:	mov    rbx,rax
   14000d4ee:	rex.W call QWORD PTR [rip+0xaa83]        # 0x140017f78
   14000d4f5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d4fa:	mov    DWORD PTR [rsp+0x28],eax
   14000d4fe:	mov    DWORD PTR [rsp+0x20],edi
   14000d502:	lea    r9,[rip+0xb997]        # 0x140018ea0
   14000d509:	mov    r8d,0x8000ffff
   14000d50f:	mov    rdx,rbx
   14000d512:	lea    rcx,[rbp+0x0]
   14000d516:	call   0x1400106b0
   14000d51b:	int3
   14000d51c:	int3
   14000d51d:	int3
   14000d51e:	int3
   14000d51f:	int3
   14000d520:	int3
   14000d521:	int3
   14000d522:	int3
   14000d523:	int3
   14000d524:	mov    rax,rsp
   14000d527:	mov    DWORD PTR [rax+0x10],edx
   14000d52a:	mov    QWORD PTR [rax+0x18],r8
   14000d52e:	mov    QWORD PTR [rax+0x20],r9
   14000d532:	push   rbp
   14000d533:	push   rbx
   14000d534:	push   rdi
   14000d535:	push   r12
   14000d537:	push   r13
   14000d539:	push   r15
   14000d53b:	lea    rbp,[rax-0xb8]
   14000d542:	sub    rsp,0x188
   14000d549:	mov    QWORD PTR [rsp+0x50],0xfffffffffffffffe
   14000d552:	mov    rbx,rcx
   14000d555:	lea    r12,[rip+0xe8e4]        # 0x14001be40
   14000d55c:	mov    QWORD PTR [rsp+0x60],r12
   14000d561:	lea    r13,[rip+0xee68]        # 0x14001c3d0
   14000d568:	mov    QWORD PTR [rsp+0x68],r13
   14000d56d:	lea    rax,[rip+0xe8b4]        # 0x14001be28
   14000d574:	mov    QWORD PTR [rsp+0x70],rax
   14000d579:	mov    DWORD PTR [rsp+0x78],0x284
   14000d581:	mov    DWORD PTR [rsp+0x7c],0x7
   14000d589:	mov    DWORD PTR [rbp-0x80],0xff
   14000d590:	xor    edi,edi
   14000d592:	mov    DWORD PTR [rbp+0x0],0x1000000
   14000d599:	xor    edx,edx
   14000d59b:	lea    r8d,[rdi+0x78]
   14000d59f:	lea    rcx,[rbp-0x78]
   14000d5a3:	call   0x140015692
   14000d5a8:	lea    rdx,[rsp+0x60]
   14000d5ad:	lea    rcx,[rbp+0x10]
   14000d5b1:	call   0x14000f85c
   14000d5b6:	nop
   14000d5b7:	lea    rax,[rbp+0xd0]
   14000d5be:	mov    QWORD PTR [rsp+0x48],rax
   14000d5c3:	mov    QWORD PTR [rsp+0x30],rdi
   14000d5c8:	mov    DWORD PTR [rsp+0x28],edi
   14000d5cc:	lea    rax,[rsp+0x40]
   14000d5d1:	mov    QWORD PTR [rsp+0x20],rax
   14000d5d6:	xor    edx,edx
   14000d5d8:	mov    r9d,0x400
   14000d5de:	mov    r8d,0x40002714
   14000d5e4:	mov    r15d,0x900
   14000d5ea:	mov    ecx,r15d
   14000d5ed:	rex.W call QWORD PTR [rip+0xa8ec]        # 0x140017ee0
   14000d5f4:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d5f9:	test   eax,eax
   14000d5fb:	je     0x14000d61b
   14000d5fd:	mov    rdx,QWORD PTR [rsp+0x40]
   14000d602:	mov    rcx,rbx
   14000d605:	call   0x14000da90
   14000d60a:	mov    rcx,QWORD PTR [rsp+0x40]
   14000d60f:	rex.W call QWORD PTR [rip+0xa94a]        # 0x140017f60
   14000d616:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d61b:	mov    ecx,0x1100
   14000d620:	mov    r8d,DWORD PTR [rbp+0xc8]
   14000d627:	cmp    r8d,0x40002710
   14000d62e:	cmovge ecx,r15d
   14000d632:	lea    rax,[rsp+0x48]
   14000d637:	mov    QWORD PTR [rsp+0x30],rax
   14000d63c:	mov    DWORD PTR [rsp+0x28],edi
   14000d640:	lea    rax,[rsp+0x40]
   14000d645:	mov    QWORD PTR [rsp+0x20],rax
   14000d64a:	xor    edx,edx
   14000d64c:	mov    r9d,0x400
   14000d652:	rex.W call QWORD PTR [rip+0xa887]        # 0x140017ee0
   14000d659:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d65e:	test   eax,eax
   14000d660:	jne    0x14000d69e
   14000d662:	lea    rax,[rsp+0x48]
   14000d667:	mov    QWORD PTR [rsp+0x30],rax
   14000d66c:	mov    DWORD PTR [rsp+0x28],edi
   14000d670:	lea    rax,[rsp+0x40]
   14000d675:	mov    QWORD PTR [rsp+0x20],rax
   14000d67a:	mov    r9d,0x400
   14000d680:	mov    r8d,DWORD PTR [rbp+0xc8]
   14000d687:	xor    edx,edx
   14000d689:	mov    ecx,0x1100
   14000d68e:	rex.W call QWORD PTR [rip+0xa84b]        # 0x140017ee0
   14000d695:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d69a:	test   eax,eax
   14000d69c:	je     0x14000d6fa
   14000d69e:	lea    rdx,[rip+0xed67]        # 0x14001c40c
   14000d6a5:	mov    rcx,rbx
   14000d6a8:	call   0x14000da90
   14000d6ad:	mov    rdx,QWORD PTR [rsp+0x40]
   14000d6b2:	mov    rcx,rbx
   14000d6b5:	call   0x14000da90
   14000d6ba:	lea    rdx,[rip+0xed4f]        # 0x14001c410
   14000d6c1:	mov    rcx,rbx
   14000d6c4:	call   0x14000da90
   14000d6c9:	mov    rcx,QWORD PTR [rsp+0x40]
   14000d6ce:	rex.W call QWORD PTR [rip+0xa88b]        # 0x140017f60
   14000d6d5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d6da:	mov    QWORD PTR [rsp+0x48],rdi
   14000d6df:	lea    rcx,[rbp+0x10]
   14000d6e3:	call   0x14000f958
   14000d6e8:	add    rsp,0x188
   14000d6ef:	pop    r15
   14000d6f1:	pop    r13
   14000d6f3:	pop    r12
   14000d6f5:	pop    rdi
   14000d6f6:	pop    rbx
   14000d6f7:	pop    rbp
   14000d6f8:	ret
   14000d6f9:	int3
   14000d6fa:	rex.W call QWORD PTR [rip+0xa877]        # 0x140017f78
   14000d701:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d706:	nop
   14000d707:	mov    r8d,eax
   14000d70a:	mov    edx,DWORD PTR [rbp+0xc8]
   14000d710:	lea    rcx,[rip+0xed09]        # 0x14001c420
   14000d717:	rex.W call QWORD PTR [rip+0xab0a]        # 0x140018228
   14000d71e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d723:	mov    DWORD PTR [rsp+0x28],0x7
   14000d72b:	mov    DWORD PTR [rsp+0x20],0x2bd
   14000d733:	mov    r9,r13
   14000d736:	lea    r8,[rip+0xe6eb]        # 0x14001be28
   14000d73d:	mov    rdx,r12
   14000d740:	lea    rcx,[rsp+0x60]
   14000d745:	call   0x14000f3ac
   14000d74a:	mov    rbx,rax
   14000d74d:	rex.W call QWORD PTR [rip+0xa824]        # 0x140017f78
   14000d754:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d759:	mov    DWORD PTR [rsp+0x28],eax
   14000d75d:	mov    ecx,DWORD PTR [rbp+0xc8]
   14000d763:	mov    DWORD PTR [rsp+0x20],ecx
   14000d767:	lea    r9,[rip+0xb732]        # 0x140018ea0
   14000d76e:	mov    r8d,0x8000ffff
   14000d774:	mov    rdx,rbx
   14000d777:	lea    rcx,[rbp+0x10]
   14000d77b:	call   0x1400106b0
   14000d780:	int3
   14000d781:	int3
   14000d782:	int3
   14000d783:	int3
   14000d784:	int3
   14000d785:	int3
   14000d786:	int3
   14000d787:	int3
   14000d788:	mov    rax,rsp
   14000d78b:	push   rbp
   14000d78c:	push   rdi
   14000d78d:	push   r12
   14000d78f:	push   r14
   14000d791:	push   r15
   14000d793:	lea    rbp,[rax-0xd8]
   14000d79a:	sub    rsp,0x1b0
   14000d7a1:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   14000d7aa:	mov    QWORD PTR [rax+0x10],rbx
   14000d7ae:	mov    QWORD PTR [rax+0x20],rsi
   14000d7b2:	mov    rax,QWORD PTR [rip+0x1695f]        # 0x140024118
   14000d7b9:	xor    rax,rsp
   14000d7bc:	mov    QWORD PTR [rbp+0xa0],rax
   14000d7c3:	mov    r15d,r8d
   14000d7c6:	mov    r12d,edx
   14000d7c9:	mov    rbx,rcx
   14000d7cc:	lea    rax,[rip+0xe66d]        # 0x14001be40
   14000d7d3:	mov    QWORD PTR [rsp+0x60],rax
   14000d7d8:	lea    rax,[rip+0xeca1]        # 0x14001c480
   14000d7df:	mov    QWORD PTR [rsp+0x68],rax
   14000d7e4:	lea    rax,[rip+0xe63d]        # 0x14001be28
   14000d7eb:	mov    QWORD PTR [rsp+0x70],rax
   14000d7f0:	mov    DWORD PTR [rsp+0x78],0x2cc
   14000d7f8:	mov    DWORD PTR [rsp+0x7c],0x7
   14000d800:	mov    DWORD PTR [rbp-0x80],0xff
   14000d807:	xor    edi,edi
   14000d809:	mov    DWORD PTR [rbp+0x0],0x1000000
   14000d810:	xor    edx,edx
   14000d812:	lea    r8d,[rdi+0x78]
   14000d816:	lea    rcx,[rbp-0x78]
   14000d81a:	call   0x140015692
   14000d81f:	lea    rdx,[rsp+0x60]
   14000d824:	lea    rcx,[rbp+0x10]
   14000d828:	call   0x14000f85c
   14000d82d:	nop
   14000d82e:	mov    DWORD PTR [rsp+0x48],edi
   14000d832:	xorps  xmm0,xmm0
   14000d835:	movups XMMWORD PTR [rbp+0x80],xmm0
   14000d83c:	movups XMMWORD PTR [rbp+0x90],xmm0
   14000d843:	lea    edx,[rdi+0x9]
   14000d846:	mov    rcx,rbx
   14000d849:	call   0x14000b754
   14000d84e:	test   eax,eax
   14000d850:	je     0x14000d863
   14000d852:	lea    rcx,[rbp+0x10]
   14000d856:	call   0x14000f958
   14000d85b:	lea    eax,[rdi+0x1]
   14000d85e:	jmp    0x14000d988
   14000d863:	mov    esi,0x4000300d
   14000d868:	mov    r8d,esi
   14000d86b:	xor    edx,edx
   14000d86d:	mov    rcx,rbx
   14000d870:	call   0x14000c86c
   14000d875:	mov    r14,rax
   14000d878:	test   rax,rax
   14000d87b:	je     0x14000da27
   14000d881:	xor    edx,edx
   14000d883:	lea    r8d,[rsi+0x1]
   14000d887:	mov    rcx,rbx
   14000d88a:	call   0x14000c86c
   14000d88f:	mov    rsi,rax
   14000d892:	test   rax,rax
   14000d895:	je     0x14000d9b4
   14000d89b:	mov    edx,r12d
   14000d89e:	mov    rcx,rbx
   14000d8a1:	test   r15d,r15d
   14000d8a4:	je     0x14000d8b8
   14000d8a6:	mov    QWORD PTR [rsp+0x20],rax
   14000d8ab:	mov    r9,r14
   14000d8ae:	mov    r8d,r15d
   14000d8b1:	call   0x14000c6f4
   14000d8b6:	jmp    0x14000d8c3
   14000d8b8:	mov    r9,rsi
   14000d8bb:	mov    r8,r14
   14000d8be:	call   0x14000c6f4
   14000d8c3:	mov    rcx,QWORD PTR [rbx+0x8]
   14000d8c7:	rex.W call QWORD PTR [rip+0xa60a]        # 0x140017ed8
   14000d8ce:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d8d3:	test   al,0x2
   14000d8d5:	je     0x14000d8f7
   14000d8d7:	lea    rdx,[rsp+0x48]
   14000d8dc:	mov    rcx,QWORD PTR [rbx+0x8]
   14000d8e0:	rex.W call QWORD PTR [rip+0xa5e9]        # 0x140017ed0
   14000d8e7:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d8ec:	test   eax,eax
   14000d8ee:	je     0x14000d8f7
   14000d8f0:	call   0x14000e8bc
   14000d8f5:	jmp    0x14000d8fa
   14000d8f7:	movzx  eax,WORD PTR [rsi]
   14000d8fa:	mov    WORD PTR [rsp+0x40],ax
   14000d8ff:	movzx  r9d,ax
   14000d903:	lea    r8,[rip+0xebc6]        # 0x14001c4d0
   14000d90a:	mov    edx,0x10
   14000d90f:	lea    rcx,[rbp+0x80]
   14000d916:	call   0x140003494
   14000d91b:	lea    rdx,[rbp+0x80]
   14000d922:	mov    rcx,rbx
   14000d925:	call   0x14000da90
   14000d92a:	mov    DWORD PTR [rsp+0x28],0x1
   14000d932:	mov    QWORD PTR [rsp+0x20],r14
   14000d937:	mov    r9d,0x1
   14000d93d:	lea    r8,[rsp+0x40]
   14000d942:	mov    edx,0x10001
   14000d947:	lea    ecx,[r9+0x7e]
   14000d94b:	rex.W call QWORD PTR [rip+0xa576]        # 0x140017ec8
   14000d952:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d957:	cmp    eax,0x2
   14000d95a:	sete   dil
   14000d95e:	mov    rcx,r14
   14000d961:	rex.W call QWORD PTR [rip+0xa718]        # 0x140018080
   14000d968:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d96d:	mov    rcx,rsi
   14000d970:	rex.W call QWORD PTR [rip+0xa709]        # 0x140018080
   14000d977:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d97c:	nop
   14000d97d:	lea    rcx,[rbp+0x10]
   14000d981:	call   0x14000f958
   14000d986:	mov    eax,edi
   14000d988:	mov    rcx,QWORD PTR [rbp+0xa0]
   14000d98f:	xor    rcx,rsp
   14000d992:	call   0x1400143c0
   14000d997:	lea    r11,[rsp+0x1b0]
   14000d99f:	mov    rbx,QWORD PTR [r11+0x38]
   14000d9a3:	mov    rsi,QWORD PTR [r11+0x48]
   14000d9a7:	mov    rsp,r11
   14000d9aa:	pop    r15
   14000d9ac:	pop    r14
   14000d9ae:	pop    r12
   14000d9b0:	pop    rdi
   14000d9b1:	pop    rbp
   14000d9b2:	ret
   14000d9b3:	int3
   14000d9b4:	mov    rcx,r14
   14000d9b7:	rex.W call QWORD PTR [rip+0xa6c2]        # 0x140018080
   14000d9be:	nop    DWORD PTR [rax+rax*1+0x0]
   14000d9c3:	mov    DWORD PTR [rsp+0x28],0x7
   14000d9cb:	mov    DWORD PTR [rsp+0x20],0x2eb
   14000d9d3:	lea    r9,[rip+0xeaa6]        # 0x14001c480
   14000d9da:	lea    r8,[rip+0xe447]        # 0x14001be28
   14000d9e1:	lea    rdx,[rip+0xe458]        # 0x14001be40
   14000d9e8:	lea    rcx,[rsp+0x60]
   14000d9ed:	call   0x14000f3ac
   14000d9f2:	mov    rbx,rax
   14000d9f5:	rex.W call QWORD PTR [rip+0xa57c]        # 0x140017f78
   14000d9fc:	nop    DWORD PTR [rax+rax*1+0x0]
   14000da01:	mov    DWORD PTR [rsp+0x28],eax
   14000da05:	mov    DWORD PTR [rsp+0x20],0x4000300e
   14000da0d:	lea    r9,[rip+0xb48c]        # 0x140018ea0
   14000da14:	mov    r8d,0x8000ffff
   14000da1a:	mov    rdx,rbx
   14000da1d:	lea    rcx,[rbp+0x10]
   14000da21:	call   0x1400106b0
   14000da26:	int3
   14000da27:	mov    DWORD PTR [rsp+0x28],0x7
   14000da2f:	mov    DWORD PTR [rsp+0x20],0x2e2
   14000da37:	lea    r9,[rip+0xea42]        # 0x14001c480
   14000da3e:	lea    r8,[rip+0xe3e3]        # 0x14001be28
   14000da45:	lea    rdx,[rip+0xe3f4]        # 0x14001be40
   14000da4c:	lea    rcx,[rsp+0x60]
   14000da51:	call   0x14000f3ac
   14000da56:	mov    rbx,rax
   14000da59:	rex.W call QWORD PTR [rip+0xa518]        # 0x140017f78
   14000da60:	nop    DWORD PTR [rax+rax*1+0x0]
   14000da65:	mov    DWORD PTR [rsp+0x28],eax
   14000da69:	mov    DWORD PTR [rsp+0x20],esi
   14000da6d:	lea    r9,[rip+0xb42c]        # 0x140018ea0
   14000da74:	mov    r8d,0x8000ffff
   14000da7a:	mov    rdx,rbx
   14000da7d:	lea    rcx,[rbp+0x10]
   14000da81:	call   0x1400106b0
   14000da86:	int3
   14000da87:	int3
   14000da88:	int3
   14000da89:	int3
   14000da8a:	int3
   14000da8b:	int3
   14000da8c:	int3
   14000da8d:	int3
   14000da8e:	int3
   14000da8f:	int3
   14000da90:	rex push rbp
   14000da92:	push   rbx
   14000da93:	push   rsi
   14000da94:	push   rdi
   14000da95:	push   r12
   14000da97:	push   r14
   14000da99:	push   r15
   14000da9b:	lea    rbp,[rsp-0x60]
   14000daa0:	sub    rsp,0x160
   14000daa7:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000dab0:	mov    r14,rdx
   14000dab3:	mov    r15,rcx
   14000dab6:	lea    rax,[rip+0xe383]        # 0x14001be40
   14000dabd:	mov    QWORD PTR [rsp+0x48],rax
   14000dac2:	lea    rax,[rip+0xea17]        # 0x14001c4e0
   14000dac9:	mov    QWORD PTR [rsp+0x50],rax
   14000dace:	lea    rax,[rip+0xe353]        # 0x14001be28
   14000dad5:	mov    QWORD PTR [rsp+0x58],rax
   14000dada:	mov    DWORD PTR [rsp+0x60],0x326
   14000dae2:	mov    DWORD PTR [rsp+0x64],0x7
   14000daea:	mov    DWORD PTR [rsp+0x68],0xff
   14000daf2:	xor    r12d,r12d
   14000daf5:	mov    DWORD PTR [rbp-0x18],0x1000000
   14000dafc:	lea    ebx,[r12+0x1]
   14000db01:	xor    edx,edx
   14000db03:	lea    r8d,[r12+0x78]
   14000db08:	lea    rcx,[rsp+0x70]
   14000db0d:	call   0x140015692
   14000db12:	lea    rdx,[rsp+0x48]
   14000db17:	lea    rcx,[rbp-0x10]
   14000db1b:	call   0x14000f85c
   14000db20:	nop
   14000db21:	mov    rcx,QWORD PTR [r15+0x8]
   14000db25:	or     rdi,0xffffffffffffffff
   14000db29:	cmp    rcx,rdi
   14000db2c:	je     0x14000dd1a
   14000db32:	cmp    DWORD PTR [rip+0x165fb],r12d        # 0x140024134
   14000db39:	je     0x14000db78
   14000db3b:	rex.W call QWORD PTR [rip+0xa396]        # 0x140017ed8
   14000db42:	nop    DWORD PTR [rax+rax*1+0x0]
   14000db47:	test   al,0x2
   14000db49:	je     0x14000db66
   14000db4b:	lea    rdx,[rbp+0xb8]
   14000db52:	mov    rcx,QWORD PTR [r15+0x8]
   14000db56:	rex.W call QWORD PTR [rip+0xa373]        # 0x140017ed0
   14000db5d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000db62:	test   eax,eax
   14000db64:	jne    0x14000db69
   14000db66:	mov    ebx,r12d
   14000db69:	mov    DWORD PTR [rip+0x16ba5],ebx        # 0x140024714
   14000db6f:	mov    DWORD PTR [rip+0x165be],r12d        # 0x140024134
   14000db76:	jmp    0x14000db7e
   14000db78:	mov    ebx,DWORD PTR [rip+0x16b96]        # 0x140024714
   14000db7e:	test   ebx,ebx
   14000db80:	je     0x14000dbbb
   14000db82:	inc    rdi
   14000db85:	cmp    WORD PTR [r14+rdi*2],r12w
   14000db8a:	jne    0x14000db82
   14000db8c:	mov    r8,rdi
   14000db8f:	mov    QWORD PTR [rsp+0x20],r12
   14000db94:	lea    r9,[rbp+0xb0]
   14000db9b:	mov    rdx,r14
   14000db9e:	mov    rcx,QWORD PTR [r15+0x8]
   14000dba2:	rex.W call QWORD PTR [rip+0xa2ff]        # 0x140017ea8
   14000dba9:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dbae:	test   eax,eax
   14000dbb0:	je     0x14000dce6
   14000dbb6:	jmp    0x14000dc89
   14000dbbb:	rex.W call QWORD PTR [rip+0xa296]        # 0x140017e58
   14000dbc2:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dbc7:	mov    ecx,eax
   14000dbc9:	mov    QWORD PTR [rsp+0x38],r12
   14000dbce:	mov    QWORD PTR [rsp+0x30],r12
   14000dbd3:	mov    DWORD PTR [rsp+0x28],r12d
   14000dbd8:	mov    QWORD PTR [rsp+0x20],r12
   14000dbdd:	mov    r9d,edi
   14000dbe0:	mov    r8,r14
   14000dbe3:	xor    edx,edx
   14000dbe5:	rex.W call QWORD PTR [rip+0xa2ac]        # 0x140017e98
   14000dbec:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dbf1:	mov    esi,eax
   14000dbf3:	test   eax,eax
   14000dbf5:	je     0x14000dd38
   14000dbfb:	mov    ecx,esi
   14000dbfd:	rex.W call QWORD PTR [rip+0xa5c4]        # 0x1400181c8
   14000dc04:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dc09:	mov    rbx,rax
   14000dc0c:	test   rax,rax
   14000dc0f:	je     0x14000dd6c
   14000dc15:	rex.W call QWORD PTR [rip+0xa23c]        # 0x140017e58
   14000dc1c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dc21:	mov    ecx,eax
   14000dc23:	mov    QWORD PTR [rsp+0x38],r12
   14000dc28:	mov    QWORD PTR [rsp+0x30],r12
   14000dc2d:	mov    DWORD PTR [rsp+0x28],esi
   14000dc31:	mov    QWORD PTR [rsp+0x20],rbx
   14000dc36:	mov    r9d,edi
   14000dc39:	mov    r8,r14
   14000dc3c:	xor    edx,edx
   14000dc3e:	rex.W call QWORD PTR [rip+0xa253]        # 0x140017e98
   14000dc45:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dc4a:	test   eax,eax
   14000dc4c:	je     0x14000dd8a
   14000dc52:	lea    r8d,[rax-0x1]
   14000dc56:	mov    QWORD PTR [rsp+0x20],r12
   14000dc5b:	lea    r9,[rbp+0xb0]
   14000dc62:	mov    rdx,rbx
   14000dc65:	mov    rcx,QWORD PTR [r15+0x8]
   14000dc69:	rex.W call QWORD PTR [rip+0xa220]        # 0x140017e90
   14000dc70:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dc75:	mov    rcx,rbx
   14000dc78:	test   eax,eax
   14000dc7a:	je     0x14000dca5
   14000dc7c:	rex.W call QWORD PTR [rip+0xa5c5]        # 0x140018248
   14000dc83:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dc88:	nop
   14000dc89:	lea    rcx,[rbp-0x10]
   14000dc8d:	call   0x14000f958
   14000dc92:	add    rsp,0x160
   14000dc99:	pop    r15
   14000dc9b:	pop    r14
   14000dc9d:	pop    r12
   14000dc9f:	pop    rdi
   14000dca0:	pop    rsi
   14000dca1:	pop    rbx
   14000dca2:	pop    rbp
   14000dca3:	ret
   14000dca4:	int3
   14000dca5:	rex.W call QWORD PTR [rip+0xa59c]        # 0x140018248
   14000dcac:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dcb1:	nop
   14000dcb2:	rex.W call QWORD PTR [rip+0xa2bf]        # 0x140017f78
   14000dcb9:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dcbe:	movzx  ecx,ax
   14000dcc1:	or     ecx,0x80070000
   14000dcc7:	test   eax,eax
   14000dcc9:	cmovle ecx,eax
   14000dccc:	mov    DWORD PTR [rbp+0xa0],ecx
   14000dcd2:	lea    rdx,[rip+0x1433f]        # 0x140022018
   14000dcd9:	lea    rcx,[rbp+0xa0]
   14000dce0:	call   0x14001478c
   14000dce5:	int3
   14000dce6:	rex.W call QWORD PTR [rip+0xa28b]        # 0x140017f78
   14000dced:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dcf2:	movzx  ecx,ax
   14000dcf5:	or     ecx,0x80070000
   14000dcfb:	test   eax,eax
   14000dcfd:	cmovle ecx,eax
   14000dd00:	mov    DWORD PTR [rbp+0xa0],ecx
   14000dd06:	lea    rdx,[rip+0x1430b]        # 0x140022018
   14000dd0d:	lea    rcx,[rbp+0xa0]
   14000dd14:	call   0x14001478c
   14000dd19:	int3
   14000dd1a:	mov    DWORD PTR [rbp+0xa0],0x8000ffff
   14000dd24:	lea    rdx,[rip+0x142ed]        # 0x140022018
   14000dd2b:	lea    rcx,[rbp+0xa0]
   14000dd32:	call   0x14001478c
   14000dd37:	int3
   14000dd38:	rex.W call QWORD PTR [rip+0xa239]        # 0x140017f78
   14000dd3f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dd44:	movzx  ecx,ax
   14000dd47:	or     ecx,0x80070000
   14000dd4d:	test   eax,eax
   14000dd4f:	cmovle ecx,eax
   14000dd52:	mov    DWORD PTR [rbp+0xa0],ecx
   14000dd58:	lea    rdx,[rip+0x142b9]        # 0x140022018
   14000dd5f:	lea    rcx,[rbp+0xa0]
   14000dd66:	call   0x14001478c
   14000dd6b:	int3
   14000dd6c:	mov    DWORD PTR [rbp+0xa0],0x8007000e
   14000dd76:	lea    rdx,[rip+0x1429b]        # 0x140022018
   14000dd7d:	lea    rcx,[rbp+0xa0]
   14000dd84:	call   0x14001478c
   14000dd89:	int3
   14000dd8a:	mov    rcx,rbx
   14000dd8d:	rex.W call QWORD PTR [rip+0xa4b4]        # 0x140018248
   14000dd94:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dd99:	rex.W call QWORD PTR [rip+0xa1d8]        # 0x140017f78
   14000dda0:	nop    DWORD PTR [rax+rax*1+0x0]
   14000dda5:	movzx  ecx,ax
   14000dda8:	or     ecx,0x80070000
   14000ddae:	test   eax,eax
   14000ddb0:	cmovle ecx,eax
   14000ddb3:	mov    DWORD PTR [rbp+0xa0],ecx
   14000ddb9:	lea    rdx,[rip+0x14258]        # 0x140022018
   14000ddc0:	lea    rcx,[rbp+0xa0]
   14000ddc7:	call   0x14001478c
   14000ddcc:	int3
   14000ddcd:	int3
   14000ddce:	int3
   14000ddcf:	int3
   14000ddd0:	int3
   14000ddd1:	int3
   14000ddd2:	int3
   14000ddd3:	int3
   14000ddd4:	mov    rax,rsp
   14000ddd7:	mov    QWORD PTR [rax+0x8],rbx
   14000dddb:	mov    QWORD PTR [rax+0x10],rsi
   14000dddf:	mov    QWORD PTR [rax+0x18],rdi
   14000dde3:	mov    QWORD PTR [rax+0x20],r12
   14000dde7:	push   rbp
   14000dde8:	push   r14
   14000ddea:	push   r15
   14000ddec:	lea    rbp,[rax-0x58]
   14000ddf0:	sub    rsp,0x140
   14000ddf7:	mov    rsi,rdx
   14000ddfa:	mov    DWORD PTR [rsp+0x38],0x3a9
   14000de02:	mov    ebx,ecx
   14000de04:	mov    DWORD PTR [rsp+0x3c],0x7
   14000de0c:	xor    edi,edi
   14000de0e:	mov    DWORD PTR [rsp+0x40],0xff
   14000de16:	lea    r14,[rip+0xe023]        # 0x14001be40
   14000de1d:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000de24:	lea    r15,[rip+0xe6f5]        # 0x14001c520
   14000de2b:	mov    QWORD PTR [rsp+0x20],r14
   14000de30:	lea    r12,[rip+0xdff1]        # 0x14001be28
   14000de37:	mov    QWORD PTR [rsp+0x28],r15
   14000de3c:	lea    r8d,[rdi+0x78]
   14000de40:	mov    QWORD PTR [rsp+0x30],r12
   14000de45:	xor    edx,edx
   14000de47:	lea    rcx,[rsp+0x48]
   14000de4c:	call   0x140015692
   14000de51:	lea    rdx,[rsp+0x20]
   14000de56:	lea    rcx,[rbp-0x30]
   14000de5a:	call   0x14000f85c
   14000de5f:	xor    edx,edx
   14000de61:	mov    QWORD PTR [rsp+0x20],r14
   14000de66:	lea    r8d,[rdi+0x78]
   14000de6a:	mov    QWORD PTR [rsp+0x28],r15
   14000de6f:	lea    rcx,[rsp+0x48]
   14000de74:	mov    QWORD PTR [rsp+0x30],r12
   14000de79:	mov    DWORD PTR [rsp+0x38],0x3ab
   14000de81:	mov    DWORD PTR [rsp+0x3c],0x7
   14000de89:	mov    DWORD PTR [rsp+0x40],0xff
   14000de91:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000de98:	call   0x140015692
   14000de9d:	mov    r9d,ebx
   14000dea0:	lea    r8,[rip+0xe6a1]        # 0x14001c548
   14000dea7:	lea    rdx,[rsp+0x20]
   14000deac:	lea    rcx,[rbp-0x30]
   14000deb0:	call   0x140010510
   14000deb5:	mov    eax,0x80042326
   14000deba:	mov    DWORD PTR [rsi],edi
   14000debc:	cmp    ebx,eax
   14000debe:	jg     0x14000e000
   14000dec4:	je     0x14000dff6
   14000deca:	mov    eax,0x80042313
   14000decf:	cmp    ebx,eax
   14000ded1:	jg     0x14000df74
   14000ded7:	je     0x14000df6a
   14000dedd:	cmp    ebx,0x80042301
   14000dee3:	je     0x14000df24
   14000dee5:	cmp    ebx,0x80042304
   14000deeb:	je     0x14000df60
   14000deed:	cmp    ebx,0x80042306
   14000def3:	je     0x14000df56
   14000def5:	cmp    ebx,0x80042308
   14000defb:	je     0x14000df4c
   14000defd:	cmp    ebx,0x8004230c
   14000df03:	je     0x14000df42
   14000df05:	cmp    ebx,0x8004230e
   14000df0b:	je     0x14000df38
   14000df0d:	cmp    ebx,0x8004230f
   14000df13:	je     0x14000df2e
   14000df15:	lea    eax,[rbx+0x7ffbdcef]
   14000df1b:	cmp    eax,0x1
   14000df1e:	ja     0x14000e12e
   14000df24:	mov    ebx,0x40002b64
   14000df29:	jmp    0x14000e0d1
   14000df2e:	mov    ebx,0x40002afe
   14000df33:	jmp    0x14000e0d1
   14000df38:	mov    ebx,0x40002afd
   14000df3d:	jmp    0x14000e0d1
   14000df42:	mov    ebx,0x40002afc
   14000df47:	jmp    0x14000e0d1
   14000df4c:	mov    ebx,0x40002afb
   14000df51:	jmp    0x14000e0d1
   14000df56:	mov    ebx,0x40002afa
   14000df5b:	jmp    0x14000e0d1
   14000df60:	mov    ebx,0x40002af9
   14000df65:	jmp    0x14000e0d1
   14000df6a:	mov    ebx,0x40002aff
   14000df6f:	jmp    0x14000e0d1
   14000df74:	cmp    ebx,0x80042314
   14000df7a:	je     0x14000dfec
   14000df7c:	cmp    ebx,0x80042315
   14000df82:	je     0x14000dfe2
   14000df84:	cmp    ebx,0x80042316
   14000df8a:	je     0x14000dfd8
   14000df8c:	cmp    ebx,0x80042317
   14000df92:	je     0x14000dfce
   14000df94:	cmp    ebx,0x8004231b
   14000df9a:	je     0x14000dfc4
   14000df9c:	cmp    ebx,0x8004231e
   14000dfa2:	je     0x14000dfba
   14000dfa4:	cmp    ebx,0x8004231f
   14000dfaa:	jne    0x14000e12e
   14000dfb0:	mov    ebx,0x40002b06
   14000dfb5:	jmp    0x14000e0d1
   14000dfba:	mov    ebx,0x40002b05
   14000dfbf:	jmp    0x14000e0d1
   14000dfc4:	mov    ebx,0x40002b04
   14000dfc9:	jmp    0x14000e0d1
   14000dfce:	mov    ebx,0x40002b03
   14000dfd3:	jmp    0x14000e0d1
   14000dfd8:	mov    ebx,0x40002b02
   14000dfdd:	jmp    0x14000e0d1
   14000dfe2:	mov    ebx,0x40002b01
   14000dfe7:	jmp    0x14000e0d1
   14000dfec:	mov    ebx,0x40002b00
   14000dff1:	jmp    0x14000e0d1
   14000dff6:	mov    ebx,0x40002b0c
   14000dffb:	jmp    0x14000e0d1
   14000e000:	mov    eax,0x1004
   14000e005:	cmp    ebx,eax
   14000e007:	jg     0x14000e078
   14000e009:	je     0x14000e071
   14000e00b:	cmp    ebx,0x80070005
   14000e011:	je     0x14000e06a
   14000e013:	cmp    ebx,0x8007000e
   14000e019:	je     0x14000e063
   14000e01b:	cmp    ebx,0x80070057
   14000e021:	je     0x14000e071
   14000e023:	cmp    ebx,0x1
   14000e026:	je     0x14000e05c
   14000e028:	cmp    ebx,0x1001
   14000e02e:	je     0x14000e055
   14000e030:	cmp    ebx,0x1002
   14000e036:	je     0x14000e04e
   14000e038:	cmp    ebx,0x1003
   14000e03e:	jne    0x14000e12e
   14000e044:	mov    ebx,0x40002bc2
   14000e049:	jmp    0x14000e0d1
   14000e04e:	mov    ebx,0x40002bc1
   14000e053:	jmp    0x14000e0d1
   14000e055:	mov    ebx,0x40002bc0
   14000e05a:	jmp    0x14000e0d1
   14000e05c:	mov    ebx,0x40002b07
   14000e061:	jmp    0x14000e0d1
   14000e063:	mov    ebx,0x40002b08
   14000e068:	jmp    0x14000e0d1
   14000e06a:	mov    ebx,0x40002b09
   14000e06f:	jmp    0x14000e0d1
   14000e071:	mov    ebx,0x40002bc3
   14000e076:	jmp    0x14000e0d1
   14000e078:	sub    ebx,0x1005
   14000e07e:	je     0x14000e0cc
   14000e080:	sub    ebx,0x1
   14000e083:	je     0x14000e0c5
   14000e085:	sub    ebx,0x1
   14000e088:	je     0x14000e0be
   14000e08a:	sub    ebx,0x1
   14000e08d:	je     0x14000e0b7
   14000e08f:	sub    ebx,0x1
   14000e092:	je     0x14000e0b0
   14000e094:	sub    ebx,0x1
   14000e097:	je     0x14000e0a9
   14000e099:	cmp    ebx,0x1
   14000e09c:	jne    0x14000e12e
   14000e0a2:	mov    ebx,0x40002b0d
   14000e0a7:	jmp    0x14000e0d1
   14000e0a9:	mov    ebx,0x4000276f
   14000e0ae:	jmp    0x14000e0d1
   14000e0b0:	mov    ebx,0x4000276e
   14000e0b5:	jmp    0x14000e0d1
   14000e0b7:	mov    ebx,0x40002bc7
   14000e0bc:	jmp    0x14000e0d1
   14000e0be:	mov    ebx,0x40002bc6
   14000e0c3:	jmp    0x14000e0d1
   14000e0c5:	mov    ebx,0x40002bc5
   14000e0ca:	jmp    0x14000e0d1
   14000e0cc:	mov    ebx,0x40002bc4
   14000e0d1:	xor    edx,edx
   14000e0d3:	mov    DWORD PTR [rsi],ebx
   14000e0d5:	lea    rcx,[rsp+0x48]
   14000e0da:	mov    QWORD PTR [rsp+0x20],r14
   14000e0df:	mov    QWORD PTR [rsp+0x28],r15
   14000e0e4:	mov    QWORD PTR [rsp+0x30],r12
   14000e0e9:	lea    r8d,[rdx+0x78]
   14000e0ed:	mov    DWORD PTR [rsp+0x38],0x41a
   14000e0f5:	mov    DWORD PTR [rsp+0x3c],0x7
   14000e0fd:	mov    DWORD PTR [rsp+0x40],0xff
   14000e105:	mov    DWORD PTR [rbp-0x40],0x1000000
   14000e10c:	call   0x140015692
   14000e111:	mov    r9d,ebx
   14000e114:	lea    r8,[rip+0xe455]        # 0x14001c570
   14000e11b:	lea    rdx,[rsp+0x20]
   14000e120:	lea    rcx,[rbp-0x30]
   14000e124:	call   0x140010510
   14000e129:	mov    edi,0x1
   14000e12e:	lea    rcx,[rbp-0x30]
   14000e132:	call   0x14000f958
   14000e137:	lea    r11,[rsp+0x140]
   14000e13f:	mov    eax,edi
   14000e141:	mov    rbx,QWORD PTR [r11+0x20]
   14000e145:	mov    rsi,QWORD PTR [r11+0x28]
   14000e149:	mov    rdi,QWORD PTR [r11+0x30]
   14000e14d:	mov    r12,QWORD PTR [r11+0x38]
   14000e151:	mov    rsp,r11
   14000e154:	pop    r15
   14000e156:	pop    r14
   14000e158:	pop    rbp
   14000e159:	ret
   14000e15a:	int3
   14000e15b:	int3
   14000e15c:	int3
   14000e15d:	int3
   14000e15e:	int3
   14000e15f:	int3
   14000e160:	int3
   14000e161:	int3
   14000e162:	int3
   14000e163:	int3
   14000e164:	mov    QWORD PTR [rsp+0x8],rbx
   14000e169:	mov    QWORD PTR [rsp+0x18],rsi
   14000e16e:	mov    QWORD PTR [rsp+0x20],rdi
   14000e173:	push   rbp
   14000e174:	push   r12
   14000e176:	push   r13
   14000e178:	push   r14
   14000e17a:	push   r15
   14000e17c:	lea    rbp,[rsp-0x60]
   14000e181:	sub    rsp,0x160
   14000e188:	mov    rdi,rdx
   14000e18b:	mov    DWORD PTR [rsp+0x58],0x42a
   14000e193:	mov    r14d,ecx
   14000e196:	mov    DWORD PTR [rsp+0x5c],0x7
   14000e19e:	xor    r15d,r15d
   14000e1a1:	mov    DWORD PTR [rsp+0x60],0xff
   14000e1a9:	lea    r12,[rip+0xdc90]        # 0x14001be40
   14000e1b0:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000e1b7:	lea    r13,[rip+0xe3da]        # 0x14001c598
   14000e1be:	mov    QWORD PTR [rsp+0x40],r12
   14000e1c3:	lea    rbx,[rip+0xdc5e]        # 0x14001be28
   14000e1ca:	mov    QWORD PTR [rsp+0x48],r13
   14000e1cf:	lea    r8d,[r15+0x78]
   14000e1d3:	mov    QWORD PTR [rsp+0x50],rbx
   14000e1d8:	xor    edx,edx
   14000e1da:	lea    rcx,[rsp+0x68]
   14000e1df:	call   0x140015692
   14000e1e4:	lea    rdx,[rsp+0x40]
   14000e1e9:	lea    rcx,[rbp-0x10]
   14000e1ed:	call   0x14000f85c
   14000e1f2:	mov    QWORD PTR [rbp+0x98],r15
   14000e1f9:	mov    esi,r15d
   14000e1fc:	test   rdi,rdi
   14000e1ff:	jne    0x14000e24b
   14000e201:	xor    edx,edx
   14000e203:	mov    QWORD PTR [rsp+0x40],r12
   14000e208:	lea    r8d,[r15+0x78]
   14000e20c:	mov    QWORD PTR [rsp+0x48],r13
   14000e211:	lea    rcx,[rsp+0x68]
   14000e216:	mov    QWORD PTR [rsp+0x50],rbx
   14000e21b:	mov    DWORD PTR [rsp+0x58],0x432
   14000e223:	mov    DWORD PTR [rsp+0x5c],0x7
   14000e22b:	mov    DWORD PTR [rsp+0x60],0xff
   14000e233:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000e23a:	call   0x140015692
   14000e23f:	lea    r8,[rip+0xe382]        # 0x14001c5c8
   14000e246:	jmp    0x14000e3bb
   14000e24b:	lea    rcx,[rip+0xe39e]        # 0x14001c5f0
   14000e252:	mov    QWORD PTR [rdi],r15
   14000e255:	rex.W call QWORD PTR [rip+0x9bcc]        # 0x140017e28
   14000e25c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e261:	mov    rbx,rax
   14000e264:	test   rax,rax
   14000e267:	jne    0x14000e2ba
   14000e269:	lea    rdi,[rip+0xdbb8]        # 0x14001be28
   14000e270:	mov    QWORD PTR [rsp+0x40],r12
   14000e275:	xor    edx,edx
   14000e277:	mov    QWORD PTR [rsp+0x50],rdi
   14000e27c:	lea    r8d,[rax+0x78]
   14000e280:	mov    QWORD PTR [rsp+0x48],r13
   14000e285:	lea    rcx,[rsp+0x68]
   14000e28a:	mov    DWORD PTR [rsp+0x58],0x43c
   14000e292:	mov    DWORD PTR [rsp+0x5c],0x7
   14000e29a:	mov    DWORD PTR [rsp+0x60],0xff
   14000e2a2:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000e2a9:	call   0x140015692
   14000e2ae:	lea    r8,[rip+0xe35b]        # 0x14001c610
   14000e2b5:	jmp    0x14000e3bb
   14000e2ba:	mov    QWORD PTR [rsp+0x30],r15
   14000e2bf:	lea    rax,[rbp+0x98]
   14000e2c6:	mov    DWORD PTR [rsp+0x28],r15d
   14000e2cb:	mov    r9d,0x400
   14000e2d1:	mov    r8d,r14d
   14000e2d4:	mov    QWORD PTR [rsp+0x20],rax
   14000e2d9:	mov    rdx,rbx
   14000e2dc:	mov    ecx,0xb00
   14000e2e1:	rex.W call QWORD PTR [rip+0x9bf8]        # 0x140017ee0
   14000e2e8:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e2ed:	test   eax,eax
   14000e2ef:	jne    0x14000e34d
   14000e2f1:	lea    rdi,[rip+0xdb30]        # 0x14001be28
   14000e2f8:	mov    QWORD PTR [rsp+0x40],r12
   14000e2fd:	xor    edx,edx
   14000e2ff:	mov    QWORD PTR [rsp+0x50],rdi
   14000e304:	lea    r8d,[rax+0x78]
   14000e308:	mov    QWORD PTR [rsp+0x48],r13
   14000e30d:	lea    rcx,[rsp+0x68]
   14000e312:	mov    DWORD PTR [rsp+0x58],0x44c
   14000e31a:	mov    DWORD PTR [rsp+0x5c],0x7
   14000e322:	mov    DWORD PTR [rsp+0x60],0xff
   14000e32a:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000e331:	call   0x140015692
   14000e336:	lea    r8,[rip+0xe313]        # 0x14001c650
   14000e33d:	lea    rdx,[rsp+0x40]
   14000e342:	lea    rcx,[rbp-0x10]
   14000e346:	call   0x140010510
   14000e34b:	jmp    0x14000e363
   14000e34d:	mov    rax,QWORD PTR [rbp+0x98]
   14000e354:	mov    esi,0x1
   14000e359:	mov    QWORD PTR [rdi],rax
   14000e35c:	lea    rdi,[rip+0xdac5]        # 0x14001be28
   14000e363:	mov    rcx,rbx
   14000e366:	rex.W call QWORD PTR [rip+0x9ac3]        # 0x140017e30
   14000e36d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e372:	test   eax,eax
   14000e374:	jne    0x14000e3c9
   14000e376:	xor    edx,edx
   14000e378:	mov    QWORD PTR [rsp+0x40],r12
   14000e37d:	lea    r8d,[rax+0x78]
   14000e381:	mov    QWORD PTR [rsp+0x48],r13
   14000e386:	lea    rcx,[rsp+0x68]
   14000e38b:	mov    QWORD PTR [rsp+0x50],rdi
   14000e390:	mov    DWORD PTR [rsp+0x58],0x458
   14000e398:	mov    DWORD PTR [rsp+0x5c],0x7
   14000e3a0:	mov    DWORD PTR [rsp+0x60],0xff
   14000e3a8:	mov    DWORD PTR [rbp-0x20],0x1000000
   14000e3af:	call   0x140015692
   14000e3b4:	lea    r8,[rip+0xe2ed]        # 0x14001c6a8
   14000e3bb:	lea    rdx,[rsp+0x40]
   14000e3c0:	lea    rcx,[rbp-0x10]
   14000e3c4:	call   0x140010510
   14000e3c9:	lea    rcx,[rbp-0x10]
   14000e3cd:	call   0x14000f958
   14000e3d2:	lea    r11,[rsp+0x160]
   14000e3da:	mov    eax,esi
   14000e3dc:	mov    rbx,QWORD PTR [r11+0x30]
   14000e3e0:	mov    rsi,QWORD PTR [r11+0x40]
   14000e3e4:	mov    rdi,QWORD PTR [r11+0x48]
   14000e3e8:	mov    rsp,r11
   14000e3eb:	pop    r15
   14000e3ed:	pop    r14
   14000e3ef:	pop    r13
   14000e3f1:	pop    r12
   14000e3f3:	pop    rbp
   14000e3f4:	ret
   14000e3f5:	int3
   14000e3f6:	int3
   14000e3f7:	int3
   14000e3f8:	int3
   14000e3f9:	int3
   14000e3fa:	int3
   14000e3fb:	int3
   14000e3fc:	mov    rax,rsp
   14000e3ff:	push   rbp
   14000e400:	push   rdi
   14000e401:	push   r12
   14000e403:	push   r14
   14000e405:	push   r15
   14000e407:	lea    rbp,[rax-0xb8]
   14000e40e:	sub    rsp,0x190
   14000e415:	mov    QWORD PTR [rsp+0x70],0xfffffffffffffffe
   14000e41e:	mov    QWORD PTR [rax+0x8],rbx
   14000e422:	mov    QWORD PTR [rax+0x18],rsi
   14000e426:	mov    r14,rcx
   14000e429:	lea    rdi,[rip+0xda10]        # 0x14001be40
   14000e430:	mov    QWORD PTR [rsp+0x78],rdi
   14000e435:	lea    rsi,[rip+0xe2a4]        # 0x14001c6e0
   14000e43c:	mov    QWORD PTR [rbp-0x80],rsi
   14000e440:	lea    r12,[rip+0xd9e1]        # 0x14001be28
   14000e447:	mov    QWORD PTR [rbp-0x78],r12
   14000e44b:	mov    DWORD PTR [rbp-0x70],0x463
   14000e452:	mov    DWORD PTR [rbp-0x6c],0x7
   14000e459:	mov    DWORD PTR [rbp-0x68],0xff
   14000e460:	mov    DWORD PTR [rbp+0x18],0x1000000
   14000e467:	xor    edx,edx
   14000e469:	lea    r8d,[rdx+0x78]
   14000e46d:	lea    rcx,[rbp-0x60]
   14000e471:	call   0x140015692
   14000e476:	lea    rdx,[rsp+0x78]
   14000e47b:	lea    rcx,[rbp+0x20]
   14000e47f:	call   0x14000f85c
   14000e484:	nop
   14000e485:	mov    ecx,0x50
   14000e48a:	rex.W call QWORD PTR [rip+0x9be7]        # 0x140018078
   14000e491:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e496:	mov    r15,rax
   14000e499:	test   rax,rax
   14000e49c:	je     0x14000e541
   14000e4a2:	movzx  eax,BYTE PTR [r14+0xf]
   14000e4a7:	movzx  ecx,BYTE PTR [r14+0xe]
   14000e4ac:	movzx  edx,BYTE PTR [r14+0xd]
   14000e4b1:	movzx  r8d,BYTE PTR [r14+0xc]
   14000e4b6:	movzx  r9d,BYTE PTR [r14+0xb]
   14000e4bb:	movzx  r10d,BYTE PTR [r14+0xa]
   14000e4c0:	movzx  r11d,BYTE PTR [r14+0x9]
   14000e4c5:	movzx  ebx,BYTE PTR [r14+0x8]
   14000e4ca:	movzx  edi,WORD PTR [r14+0x6]
   14000e4cf:	movzx  esi,WORD PTR [r14+0x4]
   14000e4d4:	mov    DWORD PTR [rsp+0x68],eax
   14000e4d8:	mov    DWORD PTR [rsp+0x60],ecx
   14000e4dc:	mov    DWORD PTR [rsp+0x58],edx
   14000e4e0:	mov    DWORD PTR [rsp+0x50],r8d
   14000e4e5:	mov    DWORD PTR [rsp+0x48],r9d
   14000e4ea:	mov    DWORD PTR [rsp+0x40],r10d
   14000e4ef:	mov    DWORD PTR [rsp+0x38],r11d
   14000e4f4:	mov    DWORD PTR [rsp+0x30],ebx
   14000e4f8:	mov    DWORD PTR [rsp+0x28],edi
   14000e4fc:	mov    DWORD PTR [rsp+0x20],esi
   14000e500:	mov    r9d,DWORD PTR [r14]
   14000e503:	lea    r8,[rip+0xe246]        # 0x14001c750
   14000e50a:	mov    edx,0x28
   14000e50f:	mov    rcx,r15
   14000e512:	call   0x140003494
   14000e517:	nop
   14000e518:	lea    rcx,[rbp+0x20]
   14000e51c:	call   0x14000f958
   14000e521:	mov    rax,r15
   14000e524:	lea    r11,[rsp+0x190]
   14000e52c:	mov    rbx,QWORD PTR [r11+0x30]
   14000e530:	mov    rsi,QWORD PTR [r11+0x40]
   14000e534:	mov    rsp,r11
   14000e537:	pop    r15
   14000e539:	pop    r14
   14000e53b:	pop    r12
   14000e53d:	pop    rdi
   14000e53e:	pop    rbp
   14000e53f:	ret
   14000e540:	int3
   14000e541:	mov    DWORD PTR [rsp+0x28],0x7
   14000e549:	mov    DWORD PTR [rsp+0x20],0x46b
   14000e551:	mov    r9,rsi
   14000e554:	mov    r8,r12
   14000e557:	mov    rdx,rdi
   14000e55a:	lea    rcx,[rsp+0x78]
   14000e55f:	call   0x14000f3ac
   14000e564:	mov    rbx,rax
   14000e567:	rex.W call QWORD PTR [rip+0x9a0a]        # 0x140017f78
   14000e56e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e573:	mov    DWORD PTR [rsp+0x20],eax
   14000e577:	lea    r9,[rip+0xe182]        # 0x14001c700
   14000e57e:	mov    r8d,0x8007000e
   14000e584:	mov    rdx,rbx
   14000e587:	lea    rcx,[rbp+0x20]
   14000e58b:	call   0x1400106b0
   14000e590:	int3
   14000e591:	int3
   14000e592:	int3
   14000e593:	int3
   14000e594:	int3
   14000e595:	int3
   14000e596:	int3
   14000e597:	int3
   14000e598:	mov    rax,rsp
   14000e59b:	push   rbp
   14000e59c:	push   rdi
   14000e59d:	push   r12
   14000e59f:	push   r14
   14000e5a1:	push   r15
   14000e5a3:	lea    rbp,[rax-0x278]
   14000e5aa:	sub    rsp,0x350
   14000e5b1:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   14000e5b9:	mov    QWORD PTR [rax+0x10],rbx
   14000e5bd:	mov    QWORD PTR [rax+0x18],rsi
   14000e5c1:	mov    rax,QWORD PTR [rip+0x15b50]        # 0x140024118
   14000e5c8:	xor    rax,rsp
   14000e5cb:	mov    QWORD PTR [rbp+0x240],rax
   14000e5d2:	mov    rbx,rcx
   14000e5d5:	lea    r14,[rip+0xd864]        # 0x14001be40
   14000e5dc:	mov    QWORD PTR [rsp+0x50],r14
   14000e5e1:	lea    r15,[rip+0xe1d0]        # 0x14001c7b8
   14000e5e8:	mov    QWORD PTR [rsp+0x58],r15
   14000e5ed:	lea    r12,[rip+0xd834]        # 0x14001be28
   14000e5f4:	mov    QWORD PTR [rsp+0x60],r12
   14000e5f9:	mov    DWORD PTR [rsp+0x68],0x47b
   14000e601:	mov    DWORD PTR [rsp+0x6c],0x7
   14000e609:	mov    DWORD PTR [rsp+0x70],0xff
   14000e611:	xor    esi,esi
   14000e613:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000e61a:	xor    edx,edx
   14000e61c:	lea    r8d,[rsi+0x78]
   14000e620:	lea    rcx,[rsp+0x78]
   14000e625:	call   0x140015692
   14000e62a:	lea    rdx,[rsp+0x50]
   14000e62f:	lea    rcx,[rbp+0x0]
   14000e633:	call   0x14000f85c
   14000e638:	nop
   14000e639:	test   rbx,rbx
   14000e63c:	je     0x14000e648
   14000e63e:	cmp    QWORD PTR [rbx],rsi
   14000e641:	je     0x14000e648
   14000e643:	mov    rcx,rbx
   14000e646:	jmp    0x14000e678
   14000e648:	lea    rcx,[rbp+0x118]
   14000e64f:	rex.W call QWORD PTR [rip+0x97e2]        # 0x140017e38
   14000e656:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e65b:	lea    rdx,[rsp+0x40]
   14000e660:	lea    rcx,[rbp+0x118]
   14000e667:	rex.W call QWORD PTR [rip+0x97d2]        # 0x140017e40
   14000e66e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e673:	lea    rcx,[rsp+0x40]
   14000e678:	lea    rdx,[rsp+0x48]
   14000e67d:	rex.W call QWORD PTR [rip+0x97c4]        # 0x140017e48
   14000e684:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e689:	lea    rdx,[rbp+0x128]
   14000e690:	lea    rcx,[rsp+0x48]
   14000e695:	rex.W call QWORD PTR [rip+0x97b4]        # 0x140017e50
   14000e69c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e6a1:	rex.W call QWORD PTR [rip+0x97b8]        # 0x140017e60
   14000e6a8:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e6ad:	mov    ecx,eax
   14000e6af:	mov    ebx,0x40
   14000e6b4:	mov    DWORD PTR [rsp+0x28],ebx
   14000e6b8:	lea    rax,[rbp+0x1c0]
   14000e6bf:	mov    QWORD PTR [rsp+0x20],rax
   14000e6c4:	xor    r9d,r9d
   14000e6c7:	lea    r8,[rbp+0x128]
   14000e6ce:	lea    edx,[rbx-0x3f]
   14000e6d1:	rex.W call QWORD PTR [rip+0x97c8]        # 0x140017ea0
   14000e6d8:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e6dd:	rex.W call QWORD PTR [rip+0x977c]        # 0x140017e60
   14000e6e4:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e6e9:	mov    ecx,eax
   14000e6eb:	mov    DWORD PTR [rsp+0x28],ebx
   14000e6ef:	lea    rax,[rbp+0x140]
   14000e6f6:	mov    QWORD PTR [rsp+0x20],rax
   14000e6fb:	xor    r9d,r9d
   14000e6fe:	lea    r8,[rbp+0x128]
   14000e705:	xor    edx,edx
   14000e707:	rex.W call QWORD PTR [rip+0x975a]        # 0x140017e68
   14000e70e:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e713:	lea    rax,[rbp+0x140]
   14000e71a:	or     rbx,0xffffffffffffffff
   14000e71e:	mov    rcx,rbx
   14000e721:	inc    rcx
   14000e724:	cmp    WORD PTR [rax+rcx*2],si
   14000e728:	jne    0x14000e721
   14000e72a:	lea    rdx,[rbp+0x1c0]
   14000e731:	mov    rax,rbx
   14000e734:	inc    rax
   14000e737:	cmp    WORD PTR [rdx+rax*2],si
   14000e73b:	jne    0x14000e734
   14000e73d:	add    rcx,rax
   14000e740:	lea    rcx,[rcx*2+0x4]
   14000e748:	rex.W call QWORD PTR [rip+0x9929]        # 0x140018078
   14000e74f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e754:	mov    rdi,rax
   14000e757:	test   rax,rax
   14000e75a:	je     0x14000e865
   14000e760:	lea    rcx,[rbp+0x140]
   14000e767:	mov    rax,rbx
   14000e76a:	inc    rax
   14000e76d:	cmp    WORD PTR [rcx+rax*2],si
   14000e771:	jne    0x14000e76a
   14000e773:	lea    rcx,[rbp+0x1c0]
   14000e77a:	inc    rbx
   14000e77d:	cmp    WORD PTR [rcx+rbx*2],si
   14000e781:	jne    0x14000e77a
   14000e783:	lea    rdx,[rax+0x2]
   14000e787:	add    rdx,rbx
   14000e78a:	lea    rax,[rbp+0x140]
   14000e791:	mov    QWORD PTR [rsp+0x20],rax
   14000e796:	lea    r9,[rbp+0x1c0]
   14000e79d:	lea    r8,[rip+0xba4c]        # 0x14001a1f0
   14000e7a4:	mov    rcx,rdi
   14000e7a7:	call   0x140003494
   14000e7ac:	mov    ebx,eax
   14000e7ae:	mov    DWORD PTR [rbp+0x8],eax
   14000e7b1:	mov    QWORD PTR [rsp+0x50],r14
   14000e7b6:	mov    QWORD PTR [rsp+0x58],r15
   14000e7bb:	mov    QWORD PTR [rsp+0x60],r12
   14000e7c0:	mov    DWORD PTR [rsp+0x68],0x4b2
   14000e7c8:	mov    DWORD PTR [rsp+0x6c],0x7
   14000e7d0:	mov    DWORD PTR [rsp+0x70],0xff
   14000e7d8:	mov    DWORD PTR [rbp-0x10],0x1000000
   14000e7df:	xor    edx,edx
   14000e7e1:	lea    r8d,[rdx+0x78]
   14000e7e5:	lea    rcx,[rsp+0x78]
   14000e7ea:	call   0x140015692
   14000e7ef:	lea    rax,[rsp+0x50]
   14000e7f4:	mov    QWORD PTR [rsp+0x40],rax
   14000e7f9:	test   ebx,ebx
   14000e7fb:	js     0x14000e840
   14000e7fd:	lea    rcx,[rsp+0x50]
   14000e802:	call   0x14000f484
   14000e807:	nop
   14000e808:	lea    rcx,[rbp+0x0]
   14000e80c:	call   0x14000f958
   14000e811:	mov    rax,rdi
   14000e814:	mov    rcx,QWORD PTR [rbp+0x240]
   14000e81b:	xor    rcx,rsp
   14000e81e:	call   0x1400143c0
   14000e823:	lea    r11,[rsp+0x350]
   14000e82b:	mov    rbx,QWORD PTR [r11+0x38]
   14000e82f:	mov    rsi,QWORD PTR [r11+0x40]
   14000e833:	mov    rsp,r11
   14000e836:	pop    r15
   14000e838:	pop    r14
   14000e83a:	pop    r12
   14000e83c:	pop    rdi
   14000e83d:	pop    rbp
   14000e83e:	ret
   14000e83f:	int3
   14000e840:	lea    rdx,[rsp+0x50]
   14000e845:	lea    rcx,[rbp+0x70]
   14000e849:	call   0x14000f400
   14000e84e:	lea    r9,[rip+0xb9ab]        # 0x14001a200
   14000e855:	mov    r8d,ebx
   14000e858:	mov    rdx,rax
   14000e85b:	lea    rcx,[rbp+0x0]
   14000e85f:	call   0x140010848
   14000e864:	nop
   14000e865:	mov    DWORD PTR [rsp+0x28],0x7
   14000e86d:	mov    DWORD PTR [rsp+0x20],0x4ad
   14000e875:	mov    r9,r15
   14000e878:	mov    r8,r12
   14000e87b:	mov    rdx,r14
   14000e87e:	lea    rcx,[rsp+0x50]
   14000e883:	call   0x14000f3ac
   14000e888:	mov    rbx,rax
   14000e88b:	rex.W call QWORD PTR [rip+0x96e6]        # 0x140017f78
   14000e892:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e897:	mov    DWORD PTR [rsp+0x20],eax
   14000e89b:	lea    r9,[rip+0xdf3e]        # 0x14001c7e0
   14000e8a2:	mov    r8d,0x8007000e
   14000e8a8:	mov    rdx,rbx
   14000e8ab:	lea    rcx,[rbp+0x0]
   14000e8af:	call   0x1400106b0
   14000e8b4:	int3
   14000e8b5:	int3
   14000e8b6:	int3
   14000e8b7:	int3
   14000e8b8:	int3
   14000e8b9:	int3
   14000e8ba:	int3
   14000e8bb:	int3
   14000e8bc:	rex push rbp
   14000e8be:	push   rbx
   14000e8bf:	push   rsi
   14000e8c0:	push   rdi
   14000e8c1:	push   r12
   14000e8c3:	push   r14
   14000e8c5:	push   r15
   14000e8c7:	lea    rbp,[rsp-0x60]
   14000e8cc:	sub    rsp,0x160
   14000e8d3:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000e8dc:	lea    rdi,[rip+0xd55d]        # 0x14001be40
   14000e8e3:	mov    QWORD PTR [rsp+0x48],rdi
   14000e8e8:	lea    r14,[rip+0xdf39]        # 0x14001c828
   14000e8ef:	mov    QWORD PTR [rsp+0x50],r14
   14000e8f4:	lea    r15,[rip+0xd52d]        # 0x14001be28
   14000e8fb:	mov    QWORD PTR [rsp+0x58],r15
   14000e900:	mov    DWORD PTR [rsp+0x60],0x4d1
   14000e908:	mov    r12d,0x7
   14000e90e:	mov    DWORD PTR [rsp+0x64],r12d
   14000e913:	mov    DWORD PTR [rsp+0x68],0xff
   14000e91b:	xor    esi,esi
   14000e91d:	mov    DWORD PTR [rbp-0x18],0x1000000
   14000e924:	xor    edx,edx
   14000e926:	lea    r8d,[r12+0x71]
   14000e92b:	lea    rcx,[rsp+0x70]
   14000e930:	call   0x140015692
   14000e935:	lea    rdx,[rsp+0x48]
   14000e93a:	lea    rcx,[rbp-0x10]
   14000e93e:	call   0x14000f85c
   14000e943:	nop
   14000e944:	mov    ecx,0xfffffff6
   14000e949:	rex.W call QWORD PTR [rip+0x9630]        # 0x140017f80
   14000e950:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e955:	mov    rbx,rax
   14000e958:	cmp    rax,0xffffffffffffffff
   14000e95c:	je     0x14000ea7b
   14000e962:	lea    rdx,[rbp+0xa0]
   14000e969:	mov    rcx,rax
   14000e96c:	rex.W call QWORD PTR [rip+0x955d]        # 0x140017ed0
   14000e973:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e978:	test   eax,eax
   14000e97a:	je     0x14000eae1
   14000e980:	mov    edx,DWORD PTR [rbp+0xa0]
   14000e986:	and    edx,0xfffffff9
   14000e989:	mov    rcx,rbx
   14000e98c:	rex.W call QWORD PTR [rip+0x94dd]        # 0x140017e70
   14000e993:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e998:	test   eax,eax
   14000e99a:	je     0x14000eb47
   14000e9a0:	mov    rcx,rbx
   14000e9a3:	rex.W call QWORD PTR [rip+0x95ee]        # 0x140017f98
   14000e9aa:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e9af:	mov    QWORD PTR [rsp+0x20],rsi
   14000e9b4:	lea    r9,[rbp+0xb0]
   14000e9bb:	lea    r8d,[r12-0x6]
   14000e9c0:	lea    rdx,[rbp+0xa8]
   14000e9c7:	mov    rcx,rbx
   14000e9ca:	rex.W call QWORD PTR [rip+0x94af]        # 0x140017e80
   14000e9d1:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e9d6:	test   eax,eax
   14000e9d8:	je     0x14000ea15
   14000e9da:	mov    edx,DWORD PTR [rbp+0xa0]
   14000e9e0:	mov    rcx,rbx
   14000e9e3:	rex.W call QWORD PTR [rip+0x9486]        # 0x140017e70
   14000e9ea:	nop    DWORD PTR [rax+rax*1+0x0]
   14000e9ef:	movzx  ebx,WORD PTR [rbp+0xa8]
   14000e9f6:	lea    rcx,[rbp-0x10]
   14000e9fa:	call   0x14000f958
   14000e9ff:	movzx  eax,bx
   14000ea02:	add    rsp,0x160
   14000ea09:	pop    r15
   14000ea0b:	pop    r14
   14000ea0d:	pop    r12
   14000ea0f:	pop    rdi
   14000ea10:	pop    rsi
   14000ea11:	pop    rbx
   14000ea12:	pop    rbp
   14000ea13:	ret
   14000ea14:	int3
   14000ea15:	mov    DWORD PTR [rsp+0x28],r12d
   14000ea1a:	mov    DWORD PTR [rsp+0x20],0x4f6
   14000ea22:	mov    r9,r14
   14000ea25:	mov    r8,r15
   14000ea28:	mov    rdx,rdi
   14000ea2b:	lea    rcx,[rsp+0x48]
   14000ea30:	call   0x14000f3ac
   14000ea35:	mov    rdi,rax
   14000ea38:	rex.W call QWORD PTR [rip+0x9539]        # 0x140017f78
   14000ea3f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ea44:	mov    ebx,eax
   14000ea46:	rex.W call QWORD PTR [rip+0x952b]        # 0x140017f78
   14000ea4d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ea52:	movzx  r8d,bx
   14000ea56:	or     r8d,0x80070000
   14000ea5d:	test   ebx,ebx
   14000ea5f:	cmovle r8d,ebx
   14000ea63:	mov    DWORD PTR [rsp+0x20],eax
   14000ea67:	lea    r9,[rip+0xdef2]        # 0x14001c960
   14000ea6e:	mov    rdx,rdi
   14000ea71:	lea    rcx,[rbp-0x10]
   14000ea75:	call   0x1400106b0
   14000ea7a:	int3
   14000ea7b:	mov    DWORD PTR [rsp+0x28],r12d
   14000ea80:	mov    DWORD PTR [rsp+0x20],0x4da
   14000ea88:	mov    r9,r14
   14000ea8b:	mov    r8,r15
   14000ea8e:	mov    rdx,rdi
   14000ea91:	lea    rcx,[rsp+0x48]
   14000ea96:	call   0x14000f3ac
   14000ea9b:	mov    rdi,rax
   14000ea9e:	rex.W call QWORD PTR [rip+0x94d3]        # 0x140017f78
   14000eaa5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eaaa:	mov    ebx,eax
   14000eaac:	rex.W call QWORD PTR [rip+0x94c5]        # 0x140017f78
   14000eab3:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eab8:	movzx  r8d,bx
   14000eabc:	or     r8d,0x80070000
   14000eac3:	test   ebx,ebx
   14000eac5:	cmovle r8d,ebx
   14000eac9:	mov    DWORD PTR [rsp+0x20],eax
   14000eacd:	lea    r9,[rip+0xdd6c]        # 0x14001c840
   14000ead4:	mov    rdx,rdi
   14000ead7:	lea    rcx,[rbp-0x10]
   14000eadb:	call   0x1400106b0
   14000eae0:	int3
   14000eae1:	mov    DWORD PTR [rsp+0x28],r12d
   14000eae6:	mov    DWORD PTR [rsp+0x20],0x4e1
   14000eaee:	mov    r9,r14
   14000eaf1:	mov    r8,r15
   14000eaf4:	mov    rdx,rdi
   14000eaf7:	lea    rcx,[rsp+0x48]
   14000eafc:	call   0x14000f3ac
   14000eb01:	mov    rdi,rax
   14000eb04:	rex.W call QWORD PTR [rip+0x946d]        # 0x140017f78
   14000eb0b:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eb10:	mov    ebx,eax
   14000eb12:	rex.W call QWORD PTR [rip+0x945f]        # 0x140017f78
   14000eb19:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eb1e:	movzx  r8d,bx
   14000eb22:	or     r8d,0x80070000
   14000eb29:	test   ebx,ebx
   14000eb2b:	cmovle r8d,ebx
   14000eb2f:	mov    DWORD PTR [rsp+0x20],eax
   14000eb33:	lea    r9,[rip+0xdd66]        # 0x14001c8a0
   14000eb3a:	mov    rdx,rdi
   14000eb3d:	lea    rcx,[rbp-0x10]
   14000eb41:	call   0x1400106b0
   14000eb46:	int3
   14000eb47:	mov    DWORD PTR [rsp+0x28],r12d
   14000eb4c:	mov    DWORD PTR [rsp+0x20],0x4e9
   14000eb54:	mov    r9,r14
   14000eb57:	mov    r8,r15
   14000eb5a:	mov    rdx,rdi
   14000eb5d:	lea    rcx,[rsp+0x48]
   14000eb62:	call   0x14000f3ac
   14000eb67:	mov    rdi,rax
   14000eb6a:	rex.W call QWORD PTR [rip+0x9407]        # 0x140017f78
   14000eb71:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eb76:	mov    ebx,eax
   14000eb78:	rex.W call QWORD PTR [rip+0x93f9]        # 0x140017f78
   14000eb7f:	nop    DWORD PTR [rax+rax*1+0x0]
   14000eb84:	movzx  r8d,bx
   14000eb88:	or     r8d,0x80070000
   14000eb8f:	test   ebx,ebx
   14000eb91:	cmovle r8d,ebx
   14000eb95:	mov    DWORD PTR [rsp+0x20],eax
   14000eb99:	lea    r9,[rip+0xdd60]        # 0x14001c900
   14000eba0:	mov    rdx,rdi
   14000eba3:	lea    rcx,[rbp-0x10]
   14000eba7:	call   0x1400106b0
   14000ebac:	int3
   14000ebad:	int3
   14000ebae:	int3
   14000ebaf:	int3
   14000ebb0:	int3
   14000ebb1:	int3
   14000ebb2:	int3
   14000ebb3:	int3
   14000ebb4:	mov    QWORD PTR [rsp+0x8],rbx
   14000ebb9:	push   rdi
   14000ebba:	sub    rsp,0x20
   14000ebbe:	mov    edi,ecx
   14000ebc0:	xor    ebx,ebx
   14000ebc2:	and    edi,0x1f
   14000ebc5:	cmp    DWORD PTR [rip+0x15b35],ebx        # 0x140024700
   14000ebcb:	jne    0x14000ebd2
   14000ebcd:	call   0x1400127e0
   14000ebd2:	mov    ecx,0x1
   14000ebd7:	cmp    DWORD PTR [rip+0x15b27],ecx        # 0x140024704
   14000ebdd:	jne    0x14000ebe9
   14000ebdf:	lea    eax,[rdi-0x9]
   14000ebe2:	test   eax,0xfffffffb
   14000ebe7:	je     0x14000ebfa
   14000ebe9:	test   DWORD PTR [rip+0x15b19],0xfffffff8        # 0x14002470c
   14000ebf3:	jne    0x14000ebfa
   14000ebf5:	cmp    edi,0x1d
   14000ebf8:	jne    0x14000ebfc
   14000ebfa:	mov    ebx,ecx
   14000ebfc:	mov    eax,ebx
   14000ebfe:	mov    rbx,QWORD PTR [rsp+0x30]
   14000ec03:	add    rsp,0x20
   14000ec07:	pop    rdi
   14000ec08:	ret
   14000ec09:	int3
   14000ec0a:	int3
   14000ec0b:	int3
   14000ec0c:	int3
   14000ec0d:	int3
   14000ec0e:	int3
   14000ec0f:	int3
   14000ec10:	mov    QWORD PTR [rsp+0x18],r8
   14000ec15:	mov    QWORD PTR [rsp+0x20],r9
   14000ec1a:	push   rbx
   14000ec1b:	push   rsi
   14000ec1c:	push   rdi
   14000ec1d:	sub    rsp,0x20
   14000ec21:	xor    edi,edi
   14000ec23:	lea    rax,[rdx-0x1]
   14000ec27:	cmp    rax,0x7ffffffe
   14000ec2d:	mov    rsi,rcx
   14000ec30:	mov    ecx,0x80070057
   14000ec35:	cmova  edi,ecx
   14000ec38:	test   edi,edi
   14000ec3a:	js     0x14000ec77
   14000ec3c:	lea    rbx,[rdx-0x1]
   14000ec40:	mov    rcx,rsi
   14000ec43:	mov    rdx,rbx
   14000ec46:	lea    r9,[rsp+0x58]
   14000ec4b:	xor    edi,edi
   14000ec4d:	rex.W call QWORD PTR [rip+0x958c]        # 0x1400181e0
   14000ec54:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ec59:	test   eax,eax
   14000ec5b:	js     0x14000ec6c
   14000ec5d:	cdqe
   14000ec5f:	cmp    rax,rbx
   14000ec62:	ja     0x14000ec6c
   14000ec64:	jne    0x14000ec7f
   14000ec66:	mov    BYTE PTR [rbx+rsi*1],dil
   14000ec6a:	jmp    0x14000ec7f
   14000ec6c:	mov    BYTE PTR [rbx+rsi*1],dil
   14000ec70:	mov    edi,0x8007007a
   14000ec75:	jmp    0x14000ec7f
   14000ec77:	test   rdx,rdx
   14000ec7a:	je     0x14000ec7f
   14000ec7c:	mov    BYTE PTR [rsi],0x0
   14000ec7f:	mov    eax,edi
   14000ec81:	add    rsp,0x20
   14000ec85:	pop    rdi
   14000ec86:	pop    rsi
   14000ec87:	pop    rbx
   14000ec88:	ret
   14000ec89:	int3
   14000ec8a:	int3
   14000ec8b:	int3
   14000ec8c:	int3
   14000ec8d:	int3
   14000ec8e:	int3
   14000ec8f:	int3
   14000ec90:	mov    rax,rsp
   14000ec93:	mov    QWORD PTR [rax+0x8],rbx
   14000ec97:	mov    QWORD PTR [rax+0x10],rbp
   14000ec9b:	mov    QWORD PTR [rax+0x18],rsi
   14000ec9f:	mov    QWORD PTR [rax+0x20],rdi
   14000eca3:	push   r12
   14000eca5:	push   r14
   14000eca7:	push   r15
   14000eca9:	sub    rsp,0x20
   14000ecad:	xor    r12d,r12d
   14000ecb0:	lea    rax,[rdx-0x1]
   14000ecb4:	cmp    rax,0x7ffffffe
   14000ecba:	mov    rsi,rcx
   14000ecbd:	mov    ebx,r12d
   14000ecc0:	mov    ecx,0x80070057
   14000ecc5:	cmova  ebx,ecx
   14000ecc8:	mov    r14,r9
   14000eccb:	mov    r15,r8
   14000ecce:	mov    rbp,rdx
   14000ecd1:	test   ebx,ebx
   14000ecd3:	js     0x14000ed65
   14000ecd9:	mov    ebx,r12d
   14000ecdc:	test   rdx,rdx
   14000ecdf:	jne    0x14000ecfc
   14000ece1:	mov    rax,QWORD PTR [rsp+0x68]
   14000ece6:	cmp    WORD PTR [rax],r12w
   14000ecea:	je     0x14000ed53
   14000ecec:	test   rsi,rsi
   14000ecef:	jne    0x14000ecf5
   14000ecf1:	mov    ebx,ecx
   14000ecf3:	jmp    0x14000ed6e
   14000ecf5:	mov    ebx,0x8007007a
   14000ecfa:	jmp    0x14000ed53
   14000ecfc:	mov    r9,QWORD PTR [rsp+0x70]
   14000ed01:	lea    rdi,[rdx-0x1]
   14000ed05:	mov    r8,QWORD PTR [rsp+0x68]
   14000ed0a:	mov    rdx,rdi
   14000ed0d:	mov    rcx,rsi
   14000ed10:	rex.W call QWORD PTR [rip+0x9541]        # 0x140018258
   14000ed17:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ed1c:	test   eax,eax
   14000ed1e:	js     0x14000ed2e
   14000ed20:	cdqe
   14000ed22:	cmp    rax,rdi
   14000ed25:	ja     0x14000ed2e
   14000ed27:	je     0x14000ed33
   14000ed29:	mov    rdi,rax
   14000ed2c:	jmp    0x14000ed38
   14000ed2e:	mov    ebx,0x8007007a
   14000ed33:	mov    WORD PTR [rsi+rdi*2],r12w
   14000ed38:	mov    ecx,0x80000000
   14000ed3d:	lea    rsi,[rsi+rdi*2]
   14000ed41:	sub    rbp,rdi
   14000ed44:	lea    eax,[rbx+rcx*1]
   14000ed47:	test   ecx,eax
   14000ed49:	jne    0x14000ed53
   14000ed4b:	cmp    ebx,0x8007007a
   14000ed51:	jne    0x14000ed6e
   14000ed53:	test   r15,r15
   14000ed56:	je     0x14000ed5b
   14000ed58:	mov    QWORD PTR [r15],rsi
   14000ed5b:	test   r14,r14
   14000ed5e:	je     0x14000ed6e
   14000ed60:	mov    QWORD PTR [r14],rbp
   14000ed63:	jmp    0x14000ed6e
   14000ed65:	test   rbp,rbp
   14000ed68:	je     0x14000ed6e
   14000ed6a:	mov    WORD PTR [rsi],r12w
   14000ed6e:	mov    rbp,QWORD PTR [rsp+0x48]
   14000ed73:	mov    eax,ebx
   14000ed75:	mov    rbx,QWORD PTR [rsp+0x40]
   14000ed7a:	mov    rsi,QWORD PTR [rsp+0x50]
   14000ed7f:	mov    rdi,QWORD PTR [rsp+0x58]
   14000ed84:	add    rsp,0x20
   14000ed88:	pop    r15
   14000ed8a:	pop    r14
   14000ed8c:	pop    r12
   14000ed8e:	ret
   14000ed8f:	int3
   14000ed90:	int3
   14000ed91:	int3
   14000ed92:	int3
   14000ed93:	int3
   14000ed94:	int3
   14000ed95:	int3
   14000ed96:	int3
   14000ed97:	int3
   14000ed98:	mov    QWORD PTR [rsp+0x10],rdx
   14000ed9d:	push   rbx
   14000ed9e:	sub    rsp,0x20
   14000eda2:	lea    rdx,[rsp+0x38]
   14000eda7:	mov    rbx,rcx
   14000edaa:	rex.W call QWORD PTR [rip+0x9437]        # 0x1400181e8
   14000edb1:	nop    DWORD PTR [rax+rax*1+0x0]
   14000edb6:	lea    rax,[rip+0x8413]        # 0x1400171d0
   14000edbd:	mov    QWORD PTR [rbx],rax
   14000edc0:	mov    rax,rbx
   14000edc3:	add    rsp,0x20
   14000edc7:	pop    rbx
   14000edc8:	ret
   14000edc9:	int3
   14000edca:	int3
   14000edcb:	int3
   14000edcc:	int3
   14000edcd:	int3
   14000edce:	int3
   14000edcf:	int3
   14000edd0:	lea    rax,[rip+0x83f9]        # 0x1400171d0
   14000edd7:	mov    QWORD PTR [rcx],rax
   14000edda:	jmp    0x140014765
   14000eddf:	int3
   14000ede0:	int3
   14000ede1:	int3
   14000ede2:	int3
   14000ede3:	int3
   14000ede4:	int3
   14000ede5:	int3
   14000ede6:	int3
   14000ede7:	int3
   14000ede8:	int3
   14000ede9:	int3
   14000edea:	int3
   14000edeb:	int3
   14000edec:	int3
   14000eded:	int3
   14000edee:	int3
   14000edef:	int3
   14000edf0:	sub    rsp,0x48
   14000edf4:	mov    rdx,rcx
   14000edf7:	lea    rcx,[rsp+0x20]
   14000edfc:	call   0x14000ee60
   14000ee01:	lea    rdx,[rip+0x13298]        # 0x1400220a0
   14000ee08:	lea    rcx,[rsp+0x20]
   14000ee0d:	call   0x14001478c
   14000ee12:	int3
   14000ee13:	int3
   14000ee14:	int3
   14000ee15:	int3
   14000ee16:	int3
   14000ee17:	int3
   14000ee18:	int3
   14000ee19:	int3
   14000ee1a:	int3
   14000ee1b:	int3
   14000ee1c:	int3
   14000ee1d:	int3
   14000ee1e:	int3
   14000ee1f:	int3
   14000ee20:	mov    QWORD PTR [rsp+0x8],rbx
   14000ee25:	push   rdi
   14000ee26:	sub    rsp,0x20
   14000ee2a:	lea    rax,[rip+0x839f]        # 0x1400171d0
   14000ee31:	mov    ebx,edx
   14000ee33:	mov    QWORD PTR [rcx],rax
   14000ee36:	mov    rdi,rcx
   14000ee39:	call   0x140014765
   14000ee3e:	test   bl,0x1
   14000ee41:	je     0x14000ee4b
   14000ee43:	mov    rcx,rdi
   14000ee46:	call   0x140014084
   14000ee4b:	mov    rbx,QWORD PTR [rsp+0x30]
   14000ee50:	mov    rax,rdi
   14000ee53:	add    rsp,0x20
   14000ee57:	pop    rdi
   14000ee58:	ret
   14000ee59:	int3
   14000ee5a:	int3
   14000ee5b:	int3
   14000ee5c:	int3
   14000ee5d:	int3
   14000ee5e:	int3
   14000ee5f:	int3
   14000ee60:	rex push rbx
   14000ee62:	sub    rsp,0x20
   14000ee66:	mov    rbx,rcx
   14000ee69:	call   0x140014759
   14000ee6e:	lea    rax,[rip+0x835b]        # 0x1400171d0
   14000ee75:	mov    QWORD PTR [rbx],rax
   14000ee78:	mov    rax,rbx
   14000ee7b:	add    rsp,0x20
   14000ee7f:	pop    rbx
   14000ee80:	ret
   14000ee81:	int3
   14000ee82:	int3
   14000ee83:	int3
   14000ee84:	int3
   14000ee85:	int3
   14000ee86:	int3
   14000ee87:	int3
   14000ee88:	mov    rcx,QWORD PTR [rcx]
   14000ee8b:	jmp    0x140014084
   14000ee90:	int3
   14000ee91:	int3
   14000ee92:	int3
   14000ee93:	int3
   14000ee94:	int3
   14000ee95:	int3
   14000ee96:	int3
   14000ee97:	int3
   14000ee98:	mov    rax,QWORD PTR [rcx]
   14000ee9b:	ret
   14000ee9c:	int3
   14000ee9d:	int3
   14000ee9e:	int3
   14000ee9f:	int3
   14000eea0:	int3
   14000eea1:	int3
   14000eea2:	int3
   14000eea3:	int3
   14000eea4:	and    QWORD PTR [rcx],0x0
   14000eea8:	mov    rax,rcx
   14000eeab:	ret
   14000eeac:	int3
   14000eead:	int3
   14000eeae:	int3
   14000eeaf:	int3
   14000eeb0:	int3
   14000eeb1:	int3
   14000eeb2:	int3
   14000eeb3:	int3
   14000eeb4:	mov    rax,rsp
   14000eeb7:	push   rbp
   14000eeb8:	push   rdi
   14000eeb9:	push   r12
   14000eebb:	push   r14
   14000eebd:	push   r15
   14000eebf:	lea    rbp,[rax-0x138]
   14000eec6:	sub    rsp,0x210
   14000eecd:	mov    QWORD PTR [rsp+0x40],0xfffffffffffffffe
   14000eed6:	mov    QWORD PTR [rax+0x10],rbx
   14000eeda:	mov    QWORD PTR [rax+0x18],rsi
   14000eede:	mov    rsi,rdx
   14000eee1:	mov    rdi,rcx
   14000eee4:	lea    r15,[rip+0xa135]        # 0x140019020
   14000eeeb:	mov    QWORD PTR [rbp-0x10],r15
   14000eeef:	lea    rax,[rip+0xdb0a]        # 0x14001ca00
   14000eef6:	mov    QWORD PTR [rbp-0x8],rax
   14000eefa:	lea    r12,[rip+0xa10f]        # 0x140019010
   14000ef01:	mov    QWORD PTR [rbp+0x0],r12
   14000ef05:	mov    DWORD PTR [rbp+0x8],0x2b9
   14000ef0c:	mov    DWORD PTR [rbp+0xc],0xb
   14000ef13:	mov    DWORD PTR [rbp+0x10],0xff
   14000ef1a:	xor    r14d,r14d
   14000ef1d:	mov    DWORD PTR [rbp+0x90],0x1000000
   14000ef27:	xor    edx,edx
   14000ef29:	lea    r8d,[r14+0x78]
   14000ef2d:	lea    rcx,[rbp+0x18]
   14000ef31:	call   0x140015692
   14000ef36:	lea    rdx,[rbp-0x10]
   14000ef3a:	lea    rcx,[rbp+0xa0]
   14000ef41:	call   0x14000f85c
   14000ef46:	nop
   14000ef47:	mov    rcx,QWORD PTR [rdi]
   14000ef4a:	or     rax,0xffffffffffffffff
   14000ef4e:	mov    rbx,rax
   14000ef51:	inc    rbx
   14000ef54:	cmp    WORD PTR [rcx+rbx*2],r14w
   14000ef59:	jne    0x14000ef51
   14000ef5b:	inc    rax
   14000ef5e:	cmp    WORD PTR [rsi+rax*2],r14w
   14000ef63:	jne    0x14000ef5b
   14000ef65:	add    rbx,rax
   14000ef68:	mov    QWORD PTR [rsp+0x48],r15
   14000ef6d:	lea    rax,[rip+0xda4c]        # 0x14001c9c0
   14000ef74:	mov    QWORD PTR [rsp+0x50],rax
   14000ef79:	mov    QWORD PTR [rsp+0x58],r12
   14000ef7e:	mov    DWORD PTR [rsp+0x60],0x2b1
   14000ef86:	mov    DWORD PTR [rsp+0x64],0xb
   14000ef8e:	mov    DWORD PTR [rsp+0x68],0xff
   14000ef96:	mov    DWORD PTR [rbp-0x18],0x1000000
   14000ef9d:	xor    edx,edx
   14000ef9f:	lea    r8d,[rdx+0x78]
   14000efa3:	lea    rcx,[rsp+0x70]
   14000efa8:	call   0x140015692
   14000efad:	lea    rdx,[rsp+0x48]
   14000efb2:	lea    rcx,[rbp-0x10]
   14000efb6:	call   0x14000f85c
   14000efbb:	nop
   14000efbc:	lea    eax,[rbx+0x1]
   14000efbf:	movsxd rdx,eax
   14000efc2:	add    rdx,rdx
   14000efc5:	mov    rcx,QWORD PTR [rdi]
   14000efc8:	rex.W call QWORD PTR [rip+0x9091]        # 0x140018060
   14000efcf:	nop    DWORD PTR [rax+rax*1+0x0]
   14000efd4:	test   rax,rax
   14000efd7:	je     0x14000f088
   14000efdd:	mov    QWORD PTR [rdi],rax
   14000efe0:	lea    rcx,[rbp-0x10]
   14000efe4:	call   0x14000f958
   14000efe9:	lea    rdx,[rbx+0x1]
   14000efed:	mov    r8,rsi
   14000eff0:	mov    rcx,QWORD PTR [rdi]
   14000eff3:	call   0x140003518
   14000eff8:	mov    DWORD PTR [rbp+0xa8],eax
   14000effe:	test   eax,eax
   14000f000:	js     0x14000f02b
   14000f002:	lea    rcx,[rbp+0xa0]
   14000f009:	call   0x14000f958
   14000f00e:	lea    r11,[rsp+0x210]
   14000f016:	mov    rbx,QWORD PTR [r11+0x38]
   14000f01a:	mov    rsi,QWORD PTR [r11+0x40]
   14000f01e:	mov    rsp,r11
   14000f021:	pop    r15
   14000f023:	pop    r14
   14000f025:	pop    r12
   14000f027:	pop    rdi
   14000f028:	pop    rbp
   14000f029:	ret
   14000f02a:	int3
   14000f02b:	mov    DWORD PTR [rsp+0x28],0xb
   14000f033:	mov    DWORD PTR [rsp+0x20],0x2c1
   14000f03b:	lea    r9,[rip+0xd9be]        # 0x14001ca00
   14000f042:	mov    r8,r12
   14000f045:	mov    rdx,r15
   14000f048:	lea    rcx,[rsp+0x48]
   14000f04d:	call   0x14000f3ac
   14000f052:	mov    rdx,rax
   14000f055:	lea    rcx,[rbp+0xa0]
   14000f05c:	call   0x1400038ec
   14000f061:	mov    DWORD PTR [rsp+0x28],eax
   14000f065:	lea    rcx,[rip+0xd9cc]        # 0x14001ca38
   14000f06c:	mov    QWORD PTR [rsp+0x20],rcx
   14000f071:	lea    r9,[rip+0xd9f0]        # 0x14001ca68
   14000f078:	mov    r8d,eax
   14000f07b:	lea    rcx,[rbp+0xa0]
   14000f082:	call   0x1400106b0
   14000f087:	nop
   14000f088:	mov    DWORD PTR [rsp+0x28],0xb
   14000f090:	mov    DWORD PTR [rsp+0x20],0x85
   14000f098:	lea    r9,[rip+0x9e91]        # 0x140018f30
   14000f09f:	mov    r8,r12
   14000f0a2:	mov    rdx,r15
   14000f0a5:	lea    rcx,[rsp+0x48]
   14000f0aa:	call   0x14000f3ac
   14000f0af:	lea    r9,[rip+0x9eb2]        # 0x140018f68
   14000f0b6:	mov    r8d,0x8007000e
   14000f0bc:	mov    rdx,rax
   14000f0bf:	lea    rcx,[rbp-0x10]
   14000f0c3:	call   0x1400106b0
   14000f0c8:	int3
   14000f0c9:	int3
   14000f0ca:	int3
   14000f0cb:	int3
   14000f0cc:	int3
   14000f0cd:	int3
   14000f0ce:	int3
   14000f0cf:	int3
   14000f0d0:	mov    QWORD PTR [rsp+0x8],rbx
   14000f0d5:	mov    QWORD PTR [rsp+0x10],rbp
   14000f0da:	mov    QWORD PTR [rsp+0x18],rsi
   14000f0df:	push   rdi
   14000f0e0:	sub    rsp,0x20
   14000f0e4:	mov    rsi,rcx
   14000f0e7:	mov    rdi,rdx
   14000f0ea:	mov    rcx,QWORD PTR [rcx]
   14000f0ed:	rex.W call QWORD PTR [rip+0x8f8c]        # 0x140018080
   14000f0f4:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f0f9:	xor    ebp,ebp
   14000f0fb:	mov    QWORD PTR [rsi],rbp
   14000f0fe:	test   rdi,rdi
   14000f101:	jne    0x14000f107
   14000f103:	mov    eax,ebp
   14000f105:	jmp    0x14000f14e
   14000f107:	or     rbx,0xffffffffffffffff
   14000f10b:	mov    rcx,rbx
   14000f10e:	inc    rcx
   14000f111:	cmp    WORD PTR [rdi+rcx*2],bp
   14000f115:	jne    0x14000f10e
   14000f117:	lea    rcx,[rcx*2+0x2]
   14000f11f:	rex.W call QWORD PTR [rip+0x8f52]        # 0x140018078
   14000f126:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f12b:	mov    QWORD PTR [rsi],rax
   14000f12e:	test   rax,rax
   14000f131:	je     0x14000f151
   14000f133:	inc    rbx
   14000f136:	cmp    WORD PTR [rdi+rbx*2],bp
   14000f13a:	jne    0x14000f133
   14000f13c:	lea    rdx,[rbx+0x1]
   14000f140:	mov    r8,rdi
   14000f143:	mov    rcx,rax
   14000f146:	call   0x1400035fc
   14000f14b:	mov    rax,QWORD PTR [rsi]
   14000f14e:	test   rax,rax
   14000f151:	mov    rbx,QWORD PTR [rsp+0x30]
   14000f156:	setne  al
   14000f159:	mov    rbp,QWORD PTR [rsp+0x38]
   14000f15e:	mov    rsi,QWORD PTR [rsp+0x40]
   14000f163:	add    rsp,0x20
   14000f167:	pop    rdi
   14000f168:	ret
   14000f169:	int3
   14000f16a:	int3
   14000f16b:	int3
   14000f16c:	int3
   14000f16d:	int3
   14000f16e:	int3
   14000f16f:	int3
   14000f170:	mov    DWORD PTR [rsp+0x8],ecx
   14000f174:	sub    rsp,0x28
   14000f178:	lea    rdx,[rip+0x12e99]        # 0x140022018
   14000f17f:	mov    DWORD PTR [rsp+0x30],0x8000ffff
   14000f187:	lea    rcx,[rsp+0x30]
   14000f18c:	call   0x14001478c
   14000f191:	int3
   14000f192:	int3
   14000f193:	int3
   14000f194:	int3
   14000f195:	int3
   14000f196:	int3
   14000f197:	int3
   14000f198:	mov    rax,rsp
   14000f19b:	push   rbp
   14000f19c:	push   rsi
   14000f19d:	push   rdi
   14000f19e:	push   r14
   14000f1a0:	push   r15
   14000f1a2:	lea    rbp,[rax-0x58]
   14000f1a6:	sub    rsp,0x130
   14000f1ad:	mov    QWORD PTR [rsp+0x48],0xfffffffffffffffe
   14000f1b6:	mov    QWORD PTR [rax+0x8],rbx
   14000f1ba:	mov    rax,QWORD PTR [rip+0x14f57]        # 0x140024118
   14000f1c1:	xor    rax,rsp
   14000f1c4:	mov    QWORD PTR [rbp+0x20],rax
   14000f1c8:	mov    esi,r8d
   14000f1cb:	mov    rbx,rdx
   14000f1ce:	mov    QWORD PTR [rsp+0x40],rdx
   14000f1d3:	xor    r15d,r15d
   14000f1d6:	cmp    QWORD PTR [rip+0x1551b],r15        # 0x1400246f8
   14000f1dd:	jne    0x14000f208
   14000f1df:	xor    edx,edx
   14000f1e1:	lea    r8d,[r15+0x2]
   14000f1e5:	lea    rcx,[rip+0xe7cc]        # 0x14001d9b8
   14000f1ec:	rex.W call QWORD PTR [rip+0x8d2d]        # 0x140017f20
   14000f1f3:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f1f8:	mov    QWORD PTR [rip+0x154f9],rax        # 0x1400246f8
   14000f1ff:	test   rax,rax
   14000f202:	je     0x14000f340
   14000f208:	mov    QWORD PTR [rbp+0x18],0x7
   14000f210:	mov    QWORD PTR [rbp+0x10],r15
   14000f214:	mov    WORD PTR [rbp+0x0],r15w
   14000f219:	xor    r8d,r8d
   14000f21c:	mov    r14d,0x401
   14000f222:	mov    edx,r14d
   14000f225:	lea    rcx,[rbp-0x8]
   14000f229:	call   0x140012694
   14000f22e:	lea    rdi,[rbp+0x0]
   14000f232:	cmp    QWORD PTR [rbp+0x18],0x8
   14000f237:	cmovae rdi,QWORD PTR [rbp+0x0]
   14000f23c:	movzx  eax,r15w
   14000f240:	mov    ecx,r14d
   14000f243:	rep stos WORD PTR es:[rdi],ax
   14000f246:	mov    QWORD PTR [rbp+0x10],r14
   14000f24a:	lea    rax,[rbp+0x0]
   14000f24e:	cmp    QWORD PTR [rbp+0x18],0x8
   14000f253:	cmovae rax,QWORD PTR [rbp+0x0]
   14000f258:	mov    WORD PTR [rax+0x802],r15w
   14000f260:	lea    r8,[rbp+0x0]
   14000f264:	cmp    QWORD PTR [rbp+0x18],0x8
   14000f269:	cmovae r8,QWORD PTR [rbp+0x0]
   14000f26e:	mov    r9d,DWORD PTR [rbp+0x10]
   14000f272:	mov    edx,esi
   14000f274:	mov    rcx,QWORD PTR [rip+0x1547d]        # 0x1400246f8
   14000f27b:	rex.W call QWORD PTR [rip+0x8e2e]        # 0x1400180b0
   14000f282:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f287:	test   eax,eax
   14000f289:	je     0x14000f2d9
   14000f28b:	lea    rdx,[rbp+0x0]
   14000f28f:	cmp    QWORD PTR [rbp+0x18],0x8
   14000f294:	cmovae rdx,QWORD PTR [rbp+0x0]
   14000f299:	mov    rcx,rbx
   14000f29c:	call   0x1400121e8
   14000f2a1:	nop
   14000f2a2:	cmp    QWORD PTR [rbp+0x18],0x8
   14000f2a7:	jb     0x14000f2b2
   14000f2a9:	mov    rcx,QWORD PTR [rbp+0x0]
   14000f2ad:	call   0x140014084
   14000f2b2:	mov    rax,rbx
   14000f2b5:	mov    rcx,QWORD PTR [rbp+0x20]
   14000f2b9:	xor    rcx,rsp
   14000f2bc:	call   0x1400143c0
   14000f2c1:	mov    rbx,QWORD PTR [rsp+0x160]
   14000f2c9:	add    rsp,0x130
   14000f2d0:	pop    r15
   14000f2d2:	pop    r14
   14000f2d4:	pop    rdi
   14000f2d5:	pop    rsi
   14000f2d6:	pop    rbp
   14000f2d7:	ret
   14000f2d8:	int3
   14000f2d9:	mov    DWORD PTR [rsp+0x28],0xb
   14000f2e1:	mov    DWORD PTR [rsp+0x20],0x61
   14000f2e9:	lea    r9,[rip+0xd820]        # 0x14001cb10
   14000f2f0:	lea    r8,[rip+0xd851]        # 0x14001cb48
   14000f2f7:	lea    rdx,[rip+0xd862]        # 0x14001cb60
   14000f2fe:	lea    rcx,[rsp+0x50]
   14000f303:	call   0x14000f3ac
   14000f308:	mov    rdi,rax
   14000f30b:	rex.W call QWORD PTR [rip+0x8c66]        # 0x140017f78
   14000f312:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f317:	mov    DWORD PTR [rsp+0x28],eax
   14000f31b:	mov    DWORD PTR [rsp+0x20],esi
   14000f31f:	lea    r9,[rip+0xd89a]        # 0x14001cbc0
   14000f326:	lea    r8,[rip+0xd7c3]        # 0x14001caf0
   14000f32d:	mov    edx,0x28
   14000f332:	mov    rcx,rdi
   14000f335:	call   0x14000fc78
   14000f33a:	call   0x14000f170
   14000f33f:	nop
   14000f340:	mov    DWORD PTR [rsp+0x28],0xb
   14000f348:	mov    DWORD PTR [rsp+0x20],0x4c
   14000f350:	lea    r9,[rip+0xd7b9]        # 0x14001cb10
   14000f357:	lea    r8,[rip+0xd7ea]        # 0x14001cb48
   14000f35e:	lea    rdx,[rip+0xd7fb]        # 0x14001cb60
   14000f365:	lea    rcx,[rsp+0x50]
   14000f36a:	call   0x14000f3ac
   14000f36f:	mov    rdi,rax
   14000f372:	rex.W call QWORD PTR [rip+0x8bff]        # 0x140017f78
   14000f379:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f37e:	mov    DWORD PTR [rsp+0x20],eax
   14000f382:	lea    r9,[rip+0xd727]        # 0x14001cab0
   14000f389:	lea    r8,[rip+0xd760]        # 0x14001caf0
   14000f390:	mov    edx,0x28
   14000f395:	mov    rcx,rdi
   14000f398:	call   0x14000fc78
   14000f39d:	call   0x14000f170
   14000f3a2:	int3
   14000f3a3:	int3
   14000f3a4:	int3
   14000f3a5:	int3
   14000f3a6:	int3
   14000f3a7:	int3
   14000f3a8:	int3
   14000f3a9:	int3
   14000f3aa:	int3
   14000f3ab:	int3
   14000f3ac:	rex push rbx
   14000f3ae:	sub    rsp,0x20
   14000f3b2:	mov    eax,DWORD PTR [rsp+0x50]
   14000f3b6:	mov    rbx,rcx
   14000f3b9:	mov    QWORD PTR [rcx],rdx
   14000f3bc:	xor    edx,edx
   14000f3be:	mov    DWORD PTR [rcx+0x18],eax
   14000f3c1:	mov    eax,DWORD PTR [rsp+0x58]
   14000f3c5:	mov    QWORD PTR [rcx+0x10],r8
   14000f3c9:	mov    QWORD PTR [rcx+0x8],r9
   14000f3cd:	lea    r8d,[rdx+0x78]
   14000f3d1:	mov    DWORD PTR [rcx+0x1c],eax
   14000f3d4:	mov    DWORD PTR [rcx+0x20],0xff
   14000f3db:	mov    DWORD PTR [rcx+0xa0],0x1000000
   14000f3e5:	add    rcx,0x28
   14000f3e9:	call   0x140015692
   14000f3ee:	mov    rax,rbx
   14000f3f1:	add    rsp,0x20
   14000f3f5:	pop    rbx
   14000f3f6:	ret
   14000f3f7:	int3
   14000f3f8:	int3
   14000f3f9:	int3
   14000f3fa:	int3
   14000f3fb:	int3
   14000f3fc:	int3
   14000f3fd:	int3
   14000f3fe:	int3
   14000f3ff:	int3
   14000f400:	mov    rax,QWORD PTR [rdx]
   14000f403:	mov    r8,rcx
   14000f406:	mov    QWORD PTR [rcx],rax
   14000f409:	mov    r9d,0xf
   14000f40f:	mov    rax,QWORD PTR [rdx+0x10]
   14000f413:	mov    QWORD PTR [rcx+0x10],rax
   14000f417:	mov    rax,QWORD PTR [rdx+0x8]
   14000f41b:	mov    QWORD PTR [rcx+0x8],rax
   14000f41f:	mov    eax,DWORD PTR [rdx+0x18]
   14000f422:	mov    DWORD PTR [rcx+0x18],eax
   14000f425:	mov    eax,DWORD PTR [rdx+0x1c]
   14000f428:	mov    DWORD PTR [rcx+0x1c],eax
   14000f42b:	movzx  eax,WORD PTR [rdx+0xa0]
   14000f432:	mov    WORD PTR [rcx+0xa0],ax
   14000f439:	mov    al,BYTE PTR [rdx+0xa2]
   14000f43f:	mov    BYTE PTR [rcx+0xa2],al
   14000f445:	mov    eax,DWORD PTR [rdx+0x20]
   14000f448:	mov    DWORD PTR [rcx+0x20],eax
   14000f44b:	mov    al,BYTE PTR [rdx+0xa3]
   14000f451:	mov    BYTE PTR [rcx+0xa3],al
   14000f457:	add    rcx,0x28
   14000f45b:	mov    BYTE PTR [rdx+0xa3],0x0
   14000f462:	sub    rdx,r8
   14000f465:	mov    rax,QWORD PTR [rdx+rcx*1]
   14000f469:	mov    QWORD PTR [rcx],rax
   14000f46c:	lea    rcx,[rcx+0x8]
   14000f470:	sub    r9,0x1
   14000f474:	jne    0x14000f465
   14000f476:	mov    rax,r8
   14000f479:	ret
   14000f47a:	int3
   14000f47b:	int3
   14000f47c:	int3
   14000f47d:	int3
   14000f47e:	int3
   14000f47f:	int3
   14000f480:	int3
   14000f481:	int3
   14000f482:	int3
   14000f483:	int3
   14000f484:	mov    QWORD PTR [rsp+0x8],rbx
   14000f489:	push   rdi
   14000f48a:	sub    rsp,0x20
   14000f48e:	cmp    BYTE PTR [rcx+0xa3],0x0
   14000f495:	je     0x14000f4c2
   14000f497:	lea    rbx,[rcx+0x28]
   14000f49b:	mov    edi,0xf
   14000f4a0:	mov    rcx,QWORD PTR [rbx]
   14000f4a3:	test   rcx,rcx
   14000f4a6:	je     0x14000f4b8
   14000f4a8:	rex.W call QWORD PTR [rip+0x8bd1]        # 0x140018080
   14000f4af:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f4b4:	and    QWORD PTR [rbx],0x0
   14000f4b8:	add    rbx,0x8
   14000f4bc:	sub    rdi,0x1
   14000f4c0:	jne    0x14000f4a0
   14000f4c2:	mov    rbx,QWORD PTR [rsp+0x30]
   14000f4c7:	add    rsp,0x20
   14000f4cb:	pop    rdi
   14000f4cc:	ret
   14000f4cd:	int3
   14000f4ce:	int3
   14000f4cf:	int3
   14000f4d0:	int3
   14000f4d1:	int3
   14000f4d2:	int3
   14000f4d3:	int3
   14000f4d4:	rex push rbx
   14000f4d6:	push   rbp
   14000f4d7:	push   rsi
   14000f4d8:	push   rdi
   14000f4d9:	push   r14
   14000f4db:	sub    rsp,0x8a0
   14000f4e2:	mov    rax,QWORD PTR [rip+0x14c2f]        # 0x140024118
   14000f4e9:	xor    rax,rsp
   14000f4ec:	mov    QWORD PTR [rsp+0x890],rax
   14000f4f4:	mov    rsi,rdx
   14000f4f7:	mov    edi,r8d
   14000f4fa:	xor    edx,edx
   14000f4fc:	mov    rbp,rcx
   14000f4ff:	lea    rcx,[rip+0xe4b2]        # 0x14001d9b8
   14000f506:	lea    r8d,[rdx+0x2]
   14000f50a:	rex.W call QWORD PTR [rip+0x8a0f]        # 0x140017f20
   14000f511:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f516:	xor    r14d,r14d
   14000f519:	mov    r9d,0x400
   14000f51f:	mov    rbx,rax
   14000f522:	mov    QWORD PTR [rsp+0x30],r14
   14000f527:	lea    rax,[rsp+0x40]
   14000f52c:	mov    DWORD PTR [rsp+0x28],0x200
   14000f534:	mov    r8d,edi
   14000f537:	mov    QWORD PTR [rsp+0x20],rax
   14000f53c:	xor    edx,edx
   14000f53e:	mov    ecx,0x1200
   14000f543:	rex.W call QWORD PTR [rip+0x8996]        # 0x140017ee0
   14000f54a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f54f:	test   eax,eax
   14000f551:	jne    0x14000f591
   14000f553:	mov    QWORD PTR [rsp+0x30],r14
   14000f558:	lea    rax,[rsp+0x40]
   14000f55d:	mov    DWORD PTR [rsp+0x28],0x200
   14000f565:	mov    r9d,0x400
   14000f56b:	mov    r8d,edi
   14000f56e:	mov    QWORD PTR [rsp+0x20],rax
   14000f573:	mov    rdx,rbx
   14000f576:	mov    ecx,0xa00
   14000f57b:	rex.W call QWORD PTR [rip+0x895e]        # 0x140017ee0
   14000f582:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f587:	test   eax,eax
   14000f589:	jne    0x14000f591
   14000f58b:	mov    WORD PTR [rsp+0x40],r14w
   14000f591:	test   rbx,rbx
   14000f594:	je     0x14000f5a5
   14000f596:	mov    rcx,rbx
   14000f599:	rex.W call QWORD PTR [rip+0x8890]        # 0x140017e30
   14000f5a0:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f5a5:	lea    rcx,[rsp+0x450]
   14000f5ad:	mov    r9d,edi
   14000f5b0:	mov    edx,0x21f
   14000f5b5:	cmp    WORD PTR [rsp+0x40],r14w
   14000f5bb:	je     0x14000f5d5
   14000f5bd:	lea    rax,[rsp+0x40]
   14000f5c2:	lea    r8,[rip+0xd66f]        # 0x14001cc38
   14000f5c9:	mov    QWORD PTR [rsp+0x20],rax
   14000f5ce:	call   0x140003494
   14000f5d3:	jmp    0x14000f5e1
   14000f5d5:	lea    r8,[rip+0xd674]        # 0x14001cc50
   14000f5dc:	call   0x140003494
   14000f5e1:	lea    r8,[rsp+0x450]
   14000f5e9:	mov    rdx,rsi
   14000f5ec:	mov    rcx,rbp
   14000f5ef:	call   0x14000f744
   14000f5f4:	mov    rax,rsi
   14000f5f7:	mov    rcx,QWORD PTR [rsp+0x890]
   14000f5ff:	xor    rcx,rsp
   14000f602:	call   0x1400143c0
   14000f607:	add    rsp,0x8a0
   14000f60e:	pop    r14
   14000f610:	pop    rdi
   14000f611:	pop    rsi
   14000f612:	pop    rbp
   14000f613:	pop    rbx
   14000f614:	ret
   14000f615:	int3
   14000f616:	int3
   14000f617:	int3
   14000f618:	int3
   14000f619:	int3
   14000f61a:	int3
   14000f61b:	int3
   14000f61c:	mov    QWORD PTR [rsp+0x20],rbx
   14000f621:	push   rbp
   14000f622:	push   rsi
   14000f623:	push   rdi
   14000f624:	push   r12
   14000f626:	push   r13
   14000f628:	push   r14
   14000f62a:	push   r15
   14000f62c:	sub    rsp,0x100
   14000f633:	mov    rax,QWORD PTR [rip+0x14ade]        # 0x140024118
   14000f63a:	xor    rax,rsp
   14000f63d:	mov    QWORD PTR [rsp+0xf0],rax
   14000f645:	movups xmm1,XMMWORD PTR [r8]
   14000f649:	mov    r12,rcx
   14000f64c:	mov    r13,rdx
   14000f64f:	movdqa xmm0,xmm1
   14000f653:	movq   r9,xmm1
   14000f658:	psrldq xmm0,0x8
   14000f65d:	mov    r8,r9
   14000f660:	movq   rcx,xmm0
   14000f665:	shr    r8,0x30
   14000f669:	mov    rax,rcx
   14000f66c:	movzx  r11d,cl
   14000f670:	shr    rax,0x30
   14000f674:	mov    r15,rcx
   14000f677:	movzx  r14d,al
   14000f67b:	mov    rax,rcx
   14000f67e:	shr    rax,0x28
   14000f682:	movzx  ebp,al
   14000f685:	mov    rax,rcx
   14000f688:	shr    rax,0x20
   14000f68c:	movzx  esi,al
   14000f68f:	mov    rax,rcx
   14000f692:	shr    rax,0x18
   14000f696:	movzx  edi,al
   14000f699:	mov    rax,rcx
   14000f69c:	shr    rax,0x10
   14000f6a0:	movzx  ebx,al
   14000f6a3:	mov    rax,rcx
   14000f6a6:	shr    rax,0x8
   14000f6aa:	lea    rcx,[rsp+0x70]
   14000f6af:	movzx  r10d,al
   14000f6b3:	mov    rax,r9
   14000f6b6:	shr    rax,0x20
   14000f6ba:	movzx  edx,ax
   14000f6bd:	shr    r15,0x38
   14000f6c1:	mov    DWORD PTR [rsp+0x68],r15d
   14000f6c6:	mov    DWORD PTR [rsp+0x60],r14d
   14000f6cb:	mov    DWORD PTR [rsp+0x58],ebp
   14000f6cf:	mov    DWORD PTR [rsp+0x50],esi
   14000f6d3:	mov    DWORD PTR [rsp+0x48],edi
   14000f6d7:	mov    DWORD PTR [rsp+0x40],ebx
   14000f6db:	mov    DWORD PTR [rsp+0x38],r10d
   14000f6e0:	mov    DWORD PTR [rsp+0x30],r11d
   14000f6e5:	mov    DWORD PTR [rsp+0x28],r8d
   14000f6ea:	lea    r8,[rip+0xd05f]        # 0x14001c750
   14000f6f1:	mov    DWORD PTR [rsp+0x20],edx
   14000f6f5:	mov    edx,0x3d
   14000f6fa:	call   0x140003494
   14000f6ff:	lea    r8,[rsp+0x70]
   14000f704:	mov    rdx,r13
   14000f707:	mov    rcx,r12
   14000f70a:	call   0x14000f744
   14000f70f:	mov    rax,r13
   14000f712:	mov    rcx,QWORD PTR [rsp+0xf0]
   14000f71a:	xor    rcx,rsp
   14000f71d:	call   0x1400143c0
   14000f722:	mov    rbx,QWORD PTR [rsp+0x158]
   14000f72a:	add    rsp,0x100
   14000f731:	pop    r15
   14000f733:	pop    r14
   14000f735:	pop    r13
   14000f737:	pop    r12
   14000f739:	pop    rdi
   14000f73a:	pop    rsi
   14000f73b:	pop    rbp
   14000f73c:	ret
   14000f73d:	int3
   14000f73e:	int3
   14000f73f:	int3
   14000f740:	int3
   14000f741:	int3
   14000f742:	int3
   14000f743:	int3
   14000f744:	mov    rax,rsp
   14000f747:	mov    QWORD PTR [rax+0x8],rbx
   14000f74b:	mov    QWORD PTR [rax+0x10],rbp
   14000f74f:	mov    QWORD PTR [rax+0x18],rsi
   14000f753:	mov    QWORD PTR [rax+0x20],rdi
   14000f757:	push   r12
   14000f759:	push   r14
   14000f75b:	push   r15
   14000f75d:	sub    rsp,0x20
   14000f761:	xor    r15d,r15d
   14000f764:	mov    rbp,r8
   14000f767:	mov    rdi,rdx
   14000f76a:	mov    rbx,rcx
   14000f76d:	test   r8,r8
   14000f770:	je     0x14000f7e8
   14000f772:	cmp    BYTE PTR [rcx+0xa2],r15b
   14000f779:	jne    0x14000f7e8
   14000f77b:	cmp    BYTE PTR [rcx+0xa3],r15b
   14000f782:	je     0x14000f7e8
   14000f784:	cmp    WORD PTR [rcx+0xa0],0xf
   14000f78c:	jae    0x14000f7e8
   14000f78e:	or     rsi,0xffffffffffffffff
   14000f792:	inc    rsi
   14000f795:	cmp    WORD PTR [r8+rsi*2],r15w
   14000f79a:	jne    0x14000f792
   14000f79c:	mov    r12d,0x1
   14000f7a2:	add    rsi,r12
   14000f7a5:	lea    rcx,[rsi+rsi*1]
   14000f7a9:	rex.W call QWORD PTR [rip+0x88c8]        # 0x140018078
   14000f7b0:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f7b5:	mov    r14,rax
   14000f7b8:	test   rax,rax
   14000f7bb:	jne    0x14000f7c6
   14000f7bd:	mov    BYTE PTR [rbx+0xa2],r12b
   14000f7c4:	jmp    0x14000f7e8
   14000f7c6:	mov    r8,rbp
   14000f7c9:	mov    rdx,rsi
   14000f7cc:	mov    rcx,r14
   14000f7cf:	call   0x1400035fc
   14000f7d4:	movzx  eax,WORD PTR [rbx+0xa0]
   14000f7db:	mov    QWORD PTR [rbx+rax*8+0x28],r14
   14000f7e0:	add    WORD PTR [rbx+0xa0],r12w
   14000f7e8:	mov    rdx,rbx
   14000f7eb:	mov    rcx,rdi
   14000f7ee:	call   0x14000f400
   14000f7f3:	mov    rbx,QWORD PTR [rsp+0x40]
   14000f7f8:	mov    rax,rdi
   14000f7fb:	mov    rdi,QWORD PTR [rsp+0x58]
   14000f800:	mov    rbp,QWORD PTR [rsp+0x48]
   14000f805:	mov    rsi,QWORD PTR [rsp+0x50]
   14000f80a:	add    rsp,0x20
   14000f80e:	pop    r15
   14000f810:	pop    r14
   14000f812:	pop    r12
   14000f814:	ret
   14000f815:	int3
   14000f816:	int3
   14000f817:	int3
   14000f818:	int3
   14000f819:	int3
   14000f81a:	int3
   14000f81b:	int3
   14000f81c:	sub    rsp,0x28
   14000f820:	mov    r10,rdx
   14000f823:	mov    DWORD PTR [rcx+0x20],0x64
   14000f82a:	mov    rdx,rcx
   14000f82d:	mov    rcx,r10
   14000f830:	call   0x14000f400
   14000f835:	mov    rax,r10
   14000f838:	add    rsp,0x28
   14000f83c:	ret
   14000f83d:	int3
   14000f83e:	int3
   14000f83f:	int3
   14000f840:	int3
   14000f841:	int3
   14000f842:	int3
   14000f843:	int3
   14000f844:	cmp    DWORD PTR [rcx+0x20],0xff
   14000f84b:	cmovne edx,DWORD PTR [rcx+0x20]
   14000f84f:	mov    eax,edx
   14000f851:	ret
   14000f852:	int3
   14000f853:	int3
   14000f854:	int3
   14000f855:	int3
   14000f856:	int3
   14000f857:	int3
   14000f858:	int3
   14000f859:	int3
   14000f85a:	int3
   14000f85b:	int3
   14000f85c:	mov    QWORD PTR [rsp+0x8],rbx
   14000f861:	mov    QWORD PTR [rsp+0x10],rsi
   14000f866:	mov    QWORD PTR [rsp+0x18],r8
   14000f86b:	push   rdi
   14000f86c:	sub    rsp,0x20
   14000f870:	xor    edi,edi
   14000f872:	mov    rsi,rdx
   14000f875:	mov    DWORD PTR [rcx+0x8],edi
   14000f878:	mov    rbx,rcx
   14000f87b:	mov    rax,QWORD PTR [rdx+0x8]
   14000f87f:	mov    QWORD PTR [rcx+0x28],rax
   14000f883:	mov    rax,QWORD PTR [rdx]
   14000f886:	mov    QWORD PTR [rcx+0x10],rax
   14000f88a:	mov    rax,QWORD PTR [rdx+0x10]
   14000f88e:	mov    QWORD PTR [rcx+0x18],rax
   14000f892:	mov    eax,DWORD PTR [rdx+0x18]
   14000f895:	mov    DWORD PTR [rcx+0x20],eax
   14000f898:	mov    eax,DWORD PTR [rdx+0x1c]
   14000f89b:	mov    DWORD PTR [rcx+0x24],eax
   14000f89e:	rex.W call QWORD PTR [rip+0x8693]        # 0x140017f38
   14000f8a5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f8aa:	or     DWORD PTR [rbx+0x4],0xffffffff
   14000f8ae:	lea    rcx,[rsp+0x40]
   14000f8b3:	mov    DWORD PTR [rbx+0x34],eax
   14000f8b6:	xorps  xmm0,xmm0
   14000f8b9:	mov    eax,DWORD PTR [rsi+0x20]
   14000f8bc:	mov    DWORD PTR [rbx+0x38],eax
   14000f8bf:	mov    DWORD PTR [rbx],edi
   14000f8c1:	mov    QWORD PTR [rbx+0x60],rdi
   14000f8c5:	movups XMMWORD PTR [rbx+0x40],xmm0
   14000f8c9:	mov    QWORD PTR [rsp+0x40],rdi
   14000f8ce:	movups XMMWORD PTR [rbx+0x50],xmm0
   14000f8d2:	rex.W call QWORD PTR [rip+0x8747]        # 0x140018020
   14000f8d9:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f8de:	test   eax,eax
   14000f8e0:	js     0x14000f8fe
   14000f8e2:	mov    rcx,rbx
   14000f8e5:	rex.W call QWORD PTR [rip+0x8704]        # 0x140017ff0
   14000f8ec:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f8f1:	test   eax,eax
   14000f8f3:	js     0x14000f8fe
   14000f8f5:	mov    rax,QWORD PTR [rsp+0x40]
   14000f8fa:	mov    QWORD PTR [rbx+0x60],rax
   14000f8fe:	mov    rax,QWORD PTR [rbx+0x60]
   14000f902:	test   rax,rax
   14000f905:	je     0x14000f90c
   14000f907:	mov    edi,DWORD PTR [rax+0x30]
   14000f90a:	inc    edi
   14000f90c:	mov    DWORD PTR [rbx+0x30],edi
   14000f90f:	lea    rdx,[rip+0xd34a]        # 0x14001cc60
   14000f916:	cmp    DWORD PTR [rbx+0x38],0xff
   14000f91d:	mov    r8d,0xa0
   14000f923:	mov    rcx,rbx
   14000f926:	cmovne r8d,DWORD PTR [rbx+0x38]
   14000f92b:	xor    r9d,r9d
   14000f92e:	call   0x14000fdbc
   14000f933:	mov    rcx,rsi
   14000f936:	call   0x14000f484
   14000f93b:	mov    rsi,QWORD PTR [rsp+0x38]
   14000f940:	mov    rax,rbx
   14000f943:	mov    rbx,QWORD PTR [rsp+0x30]
   14000f948:	add    rsp,0x20
   14000f94c:	pop    rdi
   14000f94d:	ret
   14000f94e:	int3
   14000f94f:	int3
   14000f950:	int3
   14000f951:	int3
   14000f952:	int3
   14000f953:	int3
   14000f954:	int3
   14000f955:	int3
   14000f956:	int3
   14000f957:	int3
   14000f958:	mov    QWORD PTR [rsp+0x8],rbx
   14000f95d:	mov    QWORD PTR [rsp+0x10],rsi
   14000f962:	push   rdi
   14000f963:	sub    rsp,0x50
   14000f967:	mov    rsi,rcx
   14000f96a:	lea    rbx,[rcx+0x40]
   14000f96e:	mov    edi,0x4
   14000f973:	mov    rcx,QWORD PTR [rbx]
   14000f976:	rex.W call QWORD PTR [rip+0x8703]        # 0x140018080
   14000f97d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f982:	and    QWORD PTR [rbx],0x0
   14000f986:	lea    rbx,[rbx+0x8]
   14000f98a:	sub    rdi,0x1
   14000f98e:	jne    0x14000f973
   14000f990:	rex.W call QWORD PTR [rip+0x85a1]        # 0x140017f38
   14000f997:	nop    DWORD PTR [rax+rax*1+0x0]
   14000f99c:	mov    ebx,eax
   14000f99e:	mov    r8d,0x88888889
   14000f9a4:	sub    ebx,DWORD PTR [rsi+0x34]
   14000f9a7:	mov    eax,0x10624dd3
   14000f9ac:	mul    ebx
   14000f9ae:	mov    eax,r8d
   14000f9b1:	mov    r10d,ebx
   14000f9b4:	mov    r11d,edx
   14000f9b7:	shr    r11d,0x6
   14000f9bb:	mul    r11d
   14000f9be:	imul   ecx,r11d,0x3e8
   14000f9c5:	shr    edx,0x5
   14000f9c8:	imul   eax,edx,0x3c
   14000f9cb:	sub    r10d,ecx
   14000f9ce:	sub    r11d,eax
   14000f9d1:	mov    eax,0x45e7b273
   14000f9d6:	mul    ebx
   14000f9d8:	mov    eax,r8d
   14000f9db:	mov    r9d,edx
   14000f9de:	shr    r9d,0xe
   14000f9e2:	mul    r9d
   14000f9e5:	mov    eax,0x95217cb1
   14000f9ea:	shr    edx,0x5
   14000f9ed:	imul   ecx,edx,0x3c
   14000f9f0:	mul    ebx
   14000f9f2:	sub    r9d,ecx
   14000f9f5:	mov    eax,r8d
   14000f9f8:	mov    ecx,edx
   14000f9fa:	mov    r8d,0xa0
   14000fa00:	shr    ecx,0x15
   14000fa03:	mul    ecx
   14000fa05:	shr    edx,0x5
   14000fa08:	imul   eax,edx,0x3c
   14000fa0b:	lea    rdx,[rip+0xd2de]        # 0x14001ccf0
   14000fa12:	sub    ecx,eax
   14000fa14:	mov    eax,DWORD PTR [rsi+0x8]
   14000fa17:	cmp    DWORD PTR [rsi+0x38],0xff
   14000fa1e:	mov    DWORD PTR [rsp+0x48],eax
   14000fa22:	cmovne r8d,DWORD PTR [rsi+0x38]
   14000fa27:	mov    DWORD PTR [rsp+0x40],ebx
   14000fa2b:	mov    DWORD PTR [rsp+0x38],r10d
   14000fa30:	mov    DWORD PTR [rsp+0x30],r11d
   14000fa35:	mov    DWORD PTR [rsp+0x28],r9d
   14000fa3a:	lea    r9,[rip+0xd22f]        # 0x14001cc70
   14000fa41:	mov    DWORD PTR [rsp+0x20],ecx
   14000fa45:	mov    rcx,rsi
   14000fa48:	call   0x14000fecc
   14000fa4d:	mov    rcx,QWORD PTR [rsi+0x60]
   14000fa51:	mov    rbx,QWORD PTR [rsp+0x60]
   14000fa56:	mov    rsi,QWORD PTR [rsp+0x68]
   14000fa5b:	add    rsp,0x50
   14000fa5f:	pop    rdi
   14000fa60:	rex.W jmp QWORD PTR [rip+0x8589]        # 0x140017ff0
   14000fa67:	int3
   14000fa68:	int3
   14000fa69:	int3
   14000fa6a:	int3
   14000fa6b:	int3
   14000fa6c:	int3
   14000fa6d:	int3
   14000fa6e:	int3
   14000fa6f:	int3
   14000fa70:	int3
   14000fa71:	int3
   14000fa72:	int3
   14000fa73:	int3
   14000fa74:	mov    QWORD PTR [rsp+0x8],rbx
   14000fa79:	push   rdi
   14000fa7a:	sub    rsp,0x20
   14000fa7e:	mov    edi,edx
   14000fa80:	mov    rbx,rcx
   14000fa83:	rex.W call QWORD PTR [rip+0x8576]        # 0x140018000
   14000fa8a:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fa8f:	test   eax,eax
   14000fa91:	je     0x14000fab1
   14000fa93:	mov    ecx,edi
   14000fa95:	rex.W call QWORD PTR [rip+0x856c]        # 0x140018008
   14000fa9c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000faa1:	test   eax,eax
   14000faa3:	je     0x14000fab1
   14000faa5:	mov    rcx,rbx
   14000faa8:	call   0x14000fad8
   14000faad:	mov    eax,DWORD PTR [rbx]
   14000faaf:	jmp    0x14000fab3
   14000fab1:	xor    eax,eax
   14000fab3:	mov    rbx,QWORD PTR [rsp+0x30]
   14000fab8:	add    rsp,0x20
   14000fabc:	pop    rdi
   14000fabd:	ret
   14000fabe:	int3
   14000fabf:	int3
   14000fac0:	int3
   14000fac1:	int3
   14000fac2:	int3
   14000fac3:	int3
   14000fac4:	int3
   14000fac5:	int3
   14000fac6:	int3
   14000fac7:	int3
   14000fac8:	mov    edx,DWORD PTR [rcx+0x24]
   14000facb:	jmp    0x14000fa74
   14000fad0:	int3
   14000fad1:	int3
   14000fad2:	int3
   14000fad3:	int3
   14000fad4:	int3
   14000fad5:	int3
   14000fad6:	int3
   14000fad7:	int3
   14000fad8:	mov    QWORD PTR [rsp+0x10],rbx
   14000fadd:	mov    QWORD PTR [rsp+0x18],rdi
   14000fae2:	push   rbp
   14000fae3:	lea    rbp,[rsp-0x810]
   14000faeb:	sub    rsp,0x910
   14000faf2:	mov    rax,QWORD PTR [rip+0x1461f]        # 0x140024118
   14000faf9:	xor    rax,rsp
   14000fafc:	mov    QWORD PTR [rbp+0x800],rax
   14000fb03:	mov    rdi,rcx
   14000fb06:	rex.W call QWORD PTR [rip+0x850b]        # 0x140018018
   14000fb0d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fb12:	cmp    eax,DWORD PTR [rdi+0x4]
   14000fb15:	je     0x14000fc4c
   14000fb1b:	mov    rdx,QWORD PTR [rdi+0x28]
   14000fb1f:	lea    r8,[rsp+0x50]
   14000fb24:	mov    ecx,DWORD PTR [rdi+0x24]
   14000fb27:	xor    ebx,ebx
   14000fb29:	mov    DWORD PTR [rsp+0x50],ebx
   14000fb2d:	mov    DWORD PTR [rdi+0x4],eax
   14000fb30:	rex.W call QWORD PTR [rip+0x8501]        # 0x140018038
   14000fb37:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fb3c:	test   eax,eax
   14000fb3e:	je     0x14000fb46
   14000fb40:	mov    eax,DWORD PTR [rsp+0x50]
   14000fb44:	jmp    0x14000fb62
   14000fb46:	mov    rcx,QWORD PTR [rdi+0x60]
   14000fb4a:	test   rcx,rcx
   14000fb4d:	je     0x14000fb56
   14000fb4f:	call   0x14000fac8
   14000fb54:	jmp    0x14000fb62
   14000fb56:	rex.W call QWORD PTR [rip+0x84d3]        # 0x140018030
   14000fb5d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fb62:	mov    DWORD PTR [rdi],eax
   14000fb64:	mov    eax,DWORD PTR [rdi+0x4]
   14000fb67:	cmp    DWORD PTR [rip+0x145cb],eax        # 0x140024138
   14000fb6d:	je     0x14000fc4c
   14000fb73:	xor    edx,edx
   14000fb75:	lea    rcx,[rbp+0x0]
   14000fb79:	mov    r8d,0x800
   14000fb7f:	call   0x140015692
   14000fb84:	lea    rdx,[rbp+0x0]
   14000fb88:	call   0x140010318
   14000fb8d:	lea    rax,[rip+0xcfcc]        # 0x14001cb60
   14000fb94:	mov    DWORD PTR [rsp+0x70],0x24f
   14000fb9c:	mov    QWORD PTR [rsp+0x58],rax
   14000fba1:	lea    rcx,[rbp-0x80]
   14000fba5:	xor    edx,edx
   14000fba7:	mov    DWORD PTR [rsp+0x74],0xb
   14000fbaf:	lea    rax,[rip+0xd21a]        # 0x14001cdd0
   14000fbb6:	mov    DWORD PTR [rsp+0x78],0xff
   14000fbbe:	mov    QWORD PTR [rsp+0x60],rax
   14000fbc3:	lea    rax,[rip+0xcf7e]        # 0x14001cb48
   14000fbca:	mov    QWORD PTR [rsp+0x68],rax
   14000fbcf:	lea    r8d,[rdx+0x78]
   14000fbd3:	mov    DWORD PTR [rbp-0x8],0x1000000
   14000fbda:	call   0x140015692
   14000fbdf:	rex.W call QWORD PTR [rip+0x8382]        # 0x140017f68
   14000fbe6:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fbeb:	mov    rbx,rax
   14000fbee:	rex.W call QWORD PTR [rip+0x84d3]        # 0x1400180c8
   14000fbf5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fbfa:	mov    ecx,DWORD PTR [rdi+0x4]
   14000fbfd:	lea    r8,[rip+0xd1a4]        # 0x14001cda8
   14000fc04:	mov    DWORD PTR [rsp+0x48],ecx
   14000fc08:	lea    rdx,[rsp+0x58]
   14000fc0d:	mov    ecx,DWORD PTR [rip+0x14525]        # 0x140024138
   14000fc13:	mov    r9d,0x78
   14000fc19:	mov    DWORD PTR [rsp+0x40],ecx
   14000fc1d:	lea    rcx,[rbp+0x0]
   14000fc21:	mov    QWORD PTR [rsp+0x38],rcx
   14000fc26:	mov    rcx,rdi
   14000fc29:	mov    QWORD PTR [rsp+0x30],rbx
   14000fc2e:	mov    DWORD PTR [rsp+0x28],eax
   14000fc32:	lea    rax,[rip+0xd0c7]        # 0x14001cd00
   14000fc39:	mov    QWORD PTR [rsp+0x20],rax
   14000fc3e:	call   0x14000ff98
   14000fc43:	mov    eax,DWORD PTR [rdi+0x4]
   14000fc46:	mov    DWORD PTR [rip+0x144ec],eax        # 0x140024138
   14000fc4c:	mov    rcx,QWORD PTR [rbp+0x800]
   14000fc53:	xor    rcx,rsp
   14000fc56:	call   0x1400143c0
   14000fc5b:	lea    r11,[rsp+0x910]
   14000fc63:	mov    rbx,QWORD PTR [r11+0x18]
   14000fc67:	mov    rdi,QWORD PTR [r11+0x20]
   14000fc6b:	mov    rsp,r11
   14000fc6e:	pop    rbp
   14000fc6f:	ret
   14000fc70:	int3
   14000fc71:	int3
   14000fc72:	int3
   14000fc73:	int3
   14000fc74:	int3
   14000fc75:	int3
   14000fc76:	int3
   14000fc77:	int3
   14000fc78:	mov    QWORD PTR [rsp+0x20],r9
   14000fc7d:	push   rbp
   14000fc7e:	push   rbx
   14000fc7f:	push   rsi
   14000fc80:	push   rdi
   14000fc81:	push   r14
   14000fc83:	push   r15
   14000fc85:	mov    rbp,rsp
   14000fc88:	sub    rsp,0x78
   14000fc8c:	mov    r14,r8
   14000fc8f:	mov    r15d,edx
   14000fc92:	mov    rdi,rcx
   14000fc95:	rex.W call QWORD PTR [rip+0x8364]        # 0x140018000
   14000fc9c:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fca1:	test   eax,eax
   14000fca3:	je     0x14000fd9f
   14000fca9:	and    QWORD PTR [rbp-0x28],0x0
   14000fcae:	lea    rcx,[rbp-0x28]
   14000fcb2:	rex.W call QWORD PTR [rip+0x8367]        # 0x140018020
   14000fcb9:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fcbe:	test   eax,eax
   14000fcc0:	js     0x14000fd9f
   14000fcc6:	mov    rcx,QWORD PTR [rbp-0x28]
   14000fcca:	xor    esi,esi
   14000fccc:	test   rcx,rcx
   14000fccf:	je     0x14000fce8
   14000fcd1:	mov    edx,DWORD PTR [rdi+0x1c]
   14000fcd4:	call   0x14000fa74
   14000fcd9:	test   eax,eax
   14000fcdb:	je     0x14000fd9f
   14000fce1:	mov    rax,QWORD PTR [rbp-0x28]
   14000fce5:	mov    esi,DWORD PTR [rax+0x30]
   14000fce8:	lea    rdx,[rip+0x8691]        # 0x140018380
   14000fcef:	mov    ecx,0x3ea
   14000fcf4:	call   0x140014458
   14000fcf9:	mov    rbx,rax
   14000fcfc:	test   rax,rax
   14000fcff:	jne    0x14000fd0f
   14000fd01:	lea    rax,[rip+0xd138]        # 0x14001ce40
   14000fd08:	mov    QWORD PTR [rsp+0x40],rax
   14000fd0d:	jmp    0x14000fd60
   14000fd0f:	and    QWORD PTR [rbp-0x20],0x0
   14000fd14:	lea    rax,[rbp+0x58]
   14000fd18:	and    QWORD PTR [rbp-0x18],0x0
   14000fd1d:	lea    r9,[rbp-0x20]
   14000fd21:	mov    QWORD PTR [rsp+0x30],rax
   14000fd26:	lea    r8,[rbp-0x18]
   14000fd2a:	mov    rax,QWORD PTR [rbp+0x50]
   14000fd2e:	mov    edx,0x1f4
   14000fd33:	mov    rcx,rbx
   14000fd36:	mov    QWORD PTR [rsp+0x28],rax
   14000fd3b:	call   0x14000ec90
   14000fd40:	cmp    QWORD PTR [rbp-0x20],0x1
   14000fd45:	jne    0x14000fd5b
   14000fd47:	mov    rax,QWORD PTR [rbp-0x18]
   14000fd4b:	mov    ecx,0x2e
   14000fd50:	mov    DWORD PTR [rax-0x4],0x2e002e
   14000fd57:	mov    WORD PTR [rax-0x6],cx
   14000fd5b:	mov    QWORD PTR [rsp+0x40],rbx
   14000fd60:	mov    r8d,DWORD PTR [rdi+0x18]
   14000fd64:	lea    rax,[rip+0xd13d]        # 0x14001cea8
   14000fd6b:	mov    rdx,QWORD PTR [rdi+0x10]
   14000fd6f:	mov    r9d,esi
   14000fd72:	mov    rcx,QWORD PTR [rdi]
   14000fd75:	mov    DWORD PTR [rsp+0x38],r15d
   14000fd7a:	mov    QWORD PTR [rsp+0x30],rax
   14000fd7f:	mov    eax,DWORD PTR [rdi+0x1c]
   14000fd82:	mov    QWORD PTR [rsp+0x28],r14
   14000fd87:	mov    DWORD PTR [rsp+0x20],eax
   14000fd8b:	rex.W call QWORD PTR [rip+0x8296]        # 0x140018028
   14000fd92:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fd97:	mov    rcx,rbx
   14000fd9a:	call   0x140014084
   14000fd9f:	mov    rcx,rdi
   14000fda2:	call   0x14000f484
   14000fda7:	add    rsp,0x78
   14000fdab:	pop    r15
   14000fdad:	pop    r14
   14000fdaf:	pop    rdi
   14000fdb0:	pop    rsi
   14000fdb1:	pop    rbx
   14000fdb2:	pop    rbp
   14000fdb3:	ret
   14000fdb4:	int3
   14000fdb5:	int3
   14000fdb6:	int3
   14000fdb7:	int3
   14000fdb8:	int3
   14000fdb9:	int3
   14000fdba:	int3
   14000fdbb:	int3
   14000fdbc:	mov    QWORD PTR [rsp+0x8],rbx
   14000fdc1:	mov    QWORD PTR [rsp+0x10],rbp
   14000fdc6:	mov    QWORD PTR [rsp+0x18],rsi
   14000fdcb:	push   rdi
   14000fdcc:	sub    rsp,0x50
   14000fdd0:	mov    rbp,rdx
   14000fdd3:	mov    rdi,r9
   14000fdd6:	mov    edx,DWORD PTR [rcx+0x24]
   14000fdd9:	mov    esi,r8d
   14000fddc:	mov    rbx,rcx
   14000fddf:	call   0x14000fa74
   14000fde4:	test   eax,eax
   14000fde6:	je     0x14000fe22
   14000fde8:	mov    rax,QWORD PTR [rbx+0x28]
   14000fdec:	mov    r9d,DWORD PTR [rbx+0x30]
   14000fdf0:	mov    r8d,DWORD PTR [rbx+0x20]
   14000fdf4:	mov    rdx,QWORD PTR [rbx+0x18]
   14000fdf8:	mov    rcx,QWORD PTR [rbx+0x10]
   14000fdfc:	mov    QWORD PTR [rsp+0x40],rdi
   14000fe01:	mov    DWORD PTR [rsp+0x38],esi
   14000fe05:	mov    QWORD PTR [rsp+0x30],rbp
   14000fe0a:	mov    QWORD PTR [rsp+0x28],rax
   14000fe0f:	mov    eax,DWORD PTR [rbx+0x24]
   14000fe12:	mov    DWORD PTR [rsp+0x20],eax
   14000fe16:	rex.W call QWORD PTR [rip+0x820b]        # 0x140018028
   14000fe1d:	nop    DWORD PTR [rax+rax*1+0x0]
   14000fe22:	mov    rbx,QWORD PTR [rsp+0x60]
   14000fe27:	mov    rbp,QWORD PTR [rsp+0x68]
   14000fe2c:	mov    rsi,QWORD PTR [rsp+0x70]
   14000fe31:	add    rsp,0x50
   14000fe35:	pop    rdi
   14000fe36:	ret
   14000fe37:	int3
   14000fe38:	int3
   14000fe39:	int3
   14000fe3a:	int3
   14000fe3b:	int3
   14000fe3c:	int3
   14000fe3d:	int3
   14000fe3e:	int3
   14000fe3f:	int3
   14000fe40:	mov    QWORD PTR [rsp+0x8],rbx
   14000fe45:	mov    QWORD PTR [rsp+0x10],rbp
   14000fe4a:	mov    QWORD PTR [rsp+0x18],rsi
   14000fe4f:	push   rdi
   14000fe50:	sub    rsp,0x50
   14000fe54:	mov    esi,r9d
   14000fe57:	mov    rbp,r8
   14000fe5a:	mov    rbx,rdx
   14000fe5d:	mov    rdi,rcx
   14000fe60:	call   0x14000fac8
   14000fe65:	test   eax,eax
   14000fe67:	je     0x14000feaa
   14000fe69:	mov    rax,QWORD PTR [rsp+0x80]
   14000fe71:	mov    r9d,DWORD PTR [rdi+0x30]
   14000fe75:	mov    r8d,DWORD PTR [rbx+0x18]
   14000fe79:	mov    rdx,QWORD PTR [rbx+0x10]
   14000fe7d:	mov    rcx,QWORD PTR [rbx]
   14000fe80:	mov    QWORD PTR [rsp+0x40],rax
   14000fe85:	mov    rax,QWORD PTR [rdi+0x28]
   14000fe89:	mov    DWORD PTR [rsp+0x38],esi
   14000fe8d:	mov    QWORD PTR [rsp+0x30],rbp
   14000fe92:	mov    QWORD PTR [rsp+0x28],rax
   14000fe97:	mov    eax,DWORD PTR [rbx+0x1c]
   14000fe9a:	mov    DWORD PTR [rsp+0x20],eax
   14000fe9e:	rex.W call QWORD PTR [rip+0x8183]        # 0x140018028
   14000fea5:	nop    DWORD PTR [rax+rax*1+0x0]
   14000feaa:	mov    rcx,rbx
   14000fead:	mov    rbx,QWORD PTR [rsp+0x60]
   14000feb2:	mov    rbp,QWORD PTR [rsp+0x68]
   14000feb7:	mov    rsi,QWORD PTR [rsp+0x70]
   14000febc:	add    rsp,0x50
   14000fec0:	pop    rdi
   14000fec1:	jmp    0x14000f484
   14000fec6:	int3
   14000fec7:	int3
   14000fec8:	int3
   14000fec9:	int3
   14000feca:	int3
   14000fecb:	int3
   14000fecc:	mov    QWORD PTR [rsp+0x20],r9
   14000fed1:	push   rbx
   14000fed2:	push   rbp
   14000fed3:	push   rsi
   14000fed4:	push   rdi
   14000fed5:	sub    rsp,0x58
   14000fed9:	mov    rbp,rdx
   14000fedc:	mov    esi,r8d
   14000fedf:	mov    edx,DWORD PTR [rcx+0x24]
   14000fee2:	mov    rdi,rcx
   14000fee5:	call   0x14000fa74
   14000feea:	test   eax,eax
   14000feec:	je     0x14000ff87
   14000fef2:	lea    rdx,[rip+0x8487]        # 0x140018380
   14000fef9:	mov    ecx,0x3ea
   14000fefe:	call   0x140014458
   14000ff03:	mov    rbx,rax
   14000ff06:	test   rax,rax
   14000ff09:	jne    0x14000ff14
   14000ff0b:	lea    r9,[rip+0xcfae]        # 0x14001cec0
   14000ff12:	jmp    0x14000ff71
   14000ff14:	and    QWORD PTR [rsp+0x40],0x0
   14000ff1a:	lea    rax,[rsp+0xa0]
   14000ff22:	and    QWORD PTR [rsp+0x48],0x0
   14000ff28:	lea    r9,[rsp+0x40]
   14000ff2d:	mov    QWORD PTR [rsp+0x30],rax
   14000ff32:	lea    r8,[rsp+0x48]
   14000ff37:	mov    rax,QWORD PTR [rsp+0x98]
   14000ff3f:	mov    edx,0x1f4
   14000ff44:	mov    rcx,rbx
   14000ff47:	mov    QWORD PTR [rsp+0x28],rax
   14000ff4c:	call   0x14000ec90
   14000ff51:	cmp    QWORD PTR [rsp+0x40],0x1
   14000ff57:	jne    0x14000ff6e
   14000ff59:	mov    rax,QWORD PTR [rsp+0x48]
   14000ff5e:	mov    ecx,0x2e
   14000ff63:	mov    DWORD PTR [rax-0x4],0x2e002e
   14000ff6a:	mov    WORD PTR [rax-0x6],cx
   14000ff6e:	mov    r9,rbx
   14000ff71:	mov    r8d,esi
   14000ff74:	mov    rdx,rbp
   14000ff77:	mov    rcx,rdi
   14000ff7a:	call   0x14000fdbc
   14000ff7f:	mov    rcx,rbx
   14000ff82:	call   0x140014084
   14000ff87:	add    rsp,0x58
   14000ff8b:	pop    rdi
   14000ff8c:	pop    rsi
   14000ff8d:	pop    rbp
   14000ff8e:	pop    rbx
   14000ff8f:	ret
   14000ff90:	int3
   14000ff91:	int3
   14000ff92:	int3
   14000ff93:	int3
   14000ff94:	int3
   14000ff95:	int3
   14000ff96:	int3
   14000ff97:	int3
   14000ff98:	rex push rbx
   14000ff9a:	push   rbp
   14000ff9b:	push   rsi
   14000ff9c:	push   rdi
   14000ff9d:	push   r14
   14000ff9f:	sub    rsp,0x100
   14000ffa6:	mov    ebx,DWORD PTR [rdx+0x1c]
   14000ffa9:	mov    ebp,r9d
   14000ffac:	mov    r14,r8
   14000ffaf:	mov    rsi,rdx
   14000ffb2:	mov    rdi,rcx
   14000ffb5:	rex.W call QWORD PTR [rip+0x8044]        # 0x140018000
   14000ffbc:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ffc1:	test   eax,eax
   14000ffc3:	je     0x1400100ac
   14000ffc9:	mov    ecx,ebx
   14000ffcb:	rex.W call QWORD PTR [rip+0x8036]        # 0x140018008
   14000ffd2:	nop    DWORD PTR [rax+rax*1+0x0]
   14000ffd7:	test   eax,eax
   14000ffd9:	je     0x1400100ac
   14000ffdf:	mov    rcx,rdi
   14000ffe2:	call   0x14000fad8
   14000ffe7:	cmp    DWORD PTR [rdi],0x0
   14000ffea:	je     0x1400100ac
   14000fff0:	lea    rdx,[rip+0x8389]        # 0x140018380
   14000fff7:	mov    ecx,0x3ea
   14000fffc:	call   0x140014458
   140010001:	mov    rbx,rax
   140010004:	test   rax,rax
   140010007:	jne    0x140010027
   140010009:	mov    rdx,rsi
   14001000c:	lea    rcx,[rsp+0x50]
   140010011:	call   0x14000f400
   140010016:	mov    rdx,rax
   140010019:	lea    rax,[rip+0xcea0]        # 0x14001cec0
   140010020:	mov    QWORD PTR [rsp+0x20],rax
   140010025:	jmp    0x140010096
   140010027:	and    QWORD PTR [rsp+0x40],0x0
   14001002d:	lea    rax,[rsp+0x158]
   140010035:	and    QWORD PTR [rsp+0x48],0x0
   14001003b:	lea    r9,[rsp+0x40]
   140010040:	mov    QWORD PTR [rsp+0x30],rax
   140010045:	lea    r8,[rsp+0x48]
   14001004a:	mov    rax,QWORD PTR [rsp+0x150]
   140010052:	mov    edx,0x1f4
   140010057:	mov    rcx,rbx
   14001005a:	mov    QWORD PTR [rsp+0x28],rax
   14001005f:	call   0x14000ec90
   140010064:	cmp    QWORD PTR [rsp+0x40],0x1
   14001006a:	jne    0x140010081
   14001006c:	mov    rax,QWORD PTR [rsp+0x48]
   140010071:	mov    ecx,0x2e
   140010076:	mov    DWORD PTR [rax-0x4],0x2e002e
   14001007d:	mov    WORD PTR [rax-0x6],cx
   140010081:	mov    rdx,rsi
   140010084:	lea    rcx,[rsp+0x50]
   140010089:	call   0x14000f400
   14001008e:	mov    rdx,rax
   140010091:	mov    QWORD PTR [rsp+0x20],rbx
   140010096:	mov    r9d,ebp
   140010099:	mov    r8,r14
   14001009c:	mov    rcx,rdi
   14001009f:	call   0x14000fe40
   1400100a4:	mov    rcx,rbx
   1400100a7:	call   0x140014084
   1400100ac:	mov    rcx,rsi
   1400100af:	call   0x14000f484
   1400100b4:	add    rsp,0x100
   1400100bb:	pop    r14
   1400100bd:	pop    rdi
   1400100be:	pop    rsi
   1400100bf:	pop    rbp
   1400100c0:	pop    rbx
   1400100c1:	ret
   1400100c2:	int3
   1400100c3:	int3
   1400100c4:	int3
   1400100c5:	int3
   1400100c6:	int3
   1400100c7:	int3
   1400100c8:	int3
   1400100c9:	int3
   1400100ca:	int3
   1400100cb:	int3
   1400100cc:	mov    rax,rsp
   1400100cf:	push   rdi
   1400100d0:	push   r12
   1400100d2:	push   r14
   1400100d4:	sub    rsp,0x150
   1400100db:	mov    QWORD PTR [rsp+0x50],0xfffffffffffffffe
   1400100e4:	mov    QWORD PTR [rax+0x10],rbx
   1400100e8:	mov    QWORD PTR [rax+0x18],rsi
   1400100ec:	mov    rax,QWORD PTR [rip+0x14025]        # 0x140024118
   1400100f3:	xor    rax,rsp
   1400100f6:	mov    QWORD PTR [rsp+0x140],rax
   1400100fe:	mov    r14,rcx
   140010101:	and    QWORD PTR [rsp+0x40],0x0
   140010107:	lea    rdx,[rip+0xbc02]        # 0x14001bd10
   14001010e:	lea    rcx,[rsp+0x40]
   140010113:	call   0x14000f0d0
   140010118:	test   al,al
   14001011a:	je     0x1400102c4
   140010120:	lea    r12,[rip+0x2089]        # 0x1400121b0
   140010127:	mov    QWORD PTR [rsp+0x20],r12
   14001012c:	lea    r9,[rip+0x21bd]        # 0x1400122f0
   140010133:	mov    edx,0x28
   140010138:	lea    r8d,[rdx-0x24]
   14001013c:	lea    rcx,[rsp+0x90]
   140010144:	call   0x1400154e4
   140010149:	nop
   14001014a:	xor    ebx,ebx
   14001014c:	cmp    ebx,0x4
   14001014f:	jge    0x1400101a9
   140010151:	mov    rdi,r14
   140010154:	test   rdi,rdi
   140010157:	je     0x1400101a5
   140010159:	movsxd rsi,ebx
   14001015c:	mov    rdx,QWORD PTR [rdi+rsi*8+0x40]
   140010161:	test   rdx,rdx
   140010164:	je     0x14001019f
   140010166:	lea    rcx,[rsp+0x60]
   14001016b:	call   0x1400121e8
   140010170:	nop
   140010171:	lea    rcx,[rsi+rsi*4]
   140010175:	lea    rdx,[rsp+0x90]
   14001017d:	lea    rcx,[rdx+rcx*8]
   140010181:	mov    rdx,rax
   140010184:	call   0x1400125bc
   140010189:	nop
   14001018a:	cmp    QWORD PTR [rsp+0x80],0x8
   140010193:	jb     0x14001019f
   140010195:	mov    rcx,QWORD PTR [rsp+0x68]
   14001019a:	call   0x140014084
   14001019f:	mov    rdi,QWORD PTR [rdi+0x60]
   1400101a3:	jmp    0x140010154
   1400101a5:	inc    ebx
   1400101a7:	jmp    0x14001014c
   1400101a9:	xor    ebx,ebx
   1400101ab:	lea    esi,[rbx+0x66]
   1400101ae:	cmp    ebx,0x4
   1400101b1:	jge    0x14001026d
   1400101b7:	movsxd rax,ebx
   1400101ba:	lea    rdi,[rax+rax*4]
   1400101be:	cmp    QWORD PTR [rsp+rdi*8+0xa8],0x0
   1400101c7:	jbe    0x140010266
   1400101cd:	lea    rdx,[rip+0xce1c]        # 0x14001cff0
   1400101d4:	lea    rcx,[rsp+0x40]
   1400101d9:	call   0x14000eeb4
   1400101de:	mov    ecx,ebx
   1400101e0:	test   ebx,ebx
   1400101e2:	je     0x140010203
   1400101e4:	sub    ecx,0x1
   1400101e7:	je     0x1400101fb
   1400101e9:	sub    ecx,0x1
   1400101ec:	je     0x1400101f3
   1400101ee:	mov    r8d,esi
   1400101f1:	jmp    0x140010209
   1400101f3:	mov    r8d,0x65
   1400101f9:	jmp    0x140010209
   1400101fb:	mov    r8d,0x67
   140010201:	jmp    0x140010209
   140010203:	mov    r8d,0x64
   140010209:	lea    rdx,[rsp+0x60]
   14001020e:	call   0x14000f198
   140010213:	nop
   140010214:	lea    rdx,[rax+0x8]
   140010218:	cmp    QWORD PTR [rax+0x20],0x8
   14001021d:	jb     0x140010222
   14001021f:	mov    rdx,QWORD PTR [rdx]
   140010222:	lea    rcx,[rsp+0x40]
   140010227:	call   0x14000eeb4
   14001022c:	nop
   14001022d:	cmp    QWORD PTR [rsp+0x80],0x8
   140010236:	jb     0x140010242
   140010238:	mov    rcx,QWORD PTR [rsp+0x68]
   14001023d:	call   0x140014084
   140010242:	lea    rdx,[rsp+0x98]
   14001024a:	lea    rdx,[rdx+rdi*8]
   14001024e:	cmp    QWORD PTR [rsp+rdi*8+0xb0],0x8
   140010257:	jb     0x14001025c
   140010259:	mov    rdx,QWORD PTR [rdx]
   14001025c:	lea    rcx,[rsp+0x40]
   140010261:	call   0x14000eeb4
   140010266:	inc    ebx
   140010268:	jmp    0x1400101ae
   14001026d:	mov    r9,r12
   140010270:	mov    edx,0x28
   140010275:	lea    r8d,[rdx-0x24]
   140010279:	lea    rcx,[rsp+0x90]
   140010281:	call   0x140015404
   140010286:	nop
   140010287:	xor    ecx,ecx
   140010289:	rex.W call QWORD PTR [rip+0x7df0]        # 0x140018080
   140010290:	nop    DWORD PTR [rax+rax*1+0x0]
   140010295:	mov    rax,QWORD PTR [rsp+0x40]
   14001029a:	mov    rcx,QWORD PTR [rsp+0x140]
   1400102a2:	xor    rcx,rsp
   1400102a5:	call   0x1400143c0
   1400102aa:	lea    r11,[rsp+0x150]
   1400102b2:	mov    rbx,QWORD PTR [r11+0x28]
   1400102b6:	mov    rsi,QWORD PTR [r11+0x30]
   1400102ba:	mov    rsp,r11
   1400102bd:	pop    r14
   1400102bf:	pop    r12
   1400102c1:	pop    rdi
   1400102c2:	ret
   1400102c3:	int3
   1400102c4:	mov    DWORD PTR [rsp+0x28],0xb
   1400102cc:	mov    DWORD PTR [rsp+0x20],0x37b
   1400102d4:	lea    r9,[rip+0xccc5]        # 0x14001cfa0
   1400102db:	lea    r8,[rip+0xc866]        # 0x14001cb48
   1400102e2:	lea    rdx,[rip+0xc877]        # 0x14001cb60
   1400102e9:	lea    rcx,[rsp+0x90]
   1400102f1:	call   0x14000f3ac
   1400102f6:	lea    r9,[rip+0xcc53]        # 0x14001cf50
   1400102fd:	mov    r8d,0x8007000e
   140010303:	mov    rdx,rax
   140010306:	mov    rcx,r14
   140010309:	call   0x1400106b0
   14001030e:	int3
   14001030f:	int3
   140010310:	int3
   140010311:	int3
   140010312:	int3
   140010313:	int3
   140010314:	int3
   140010315:	int3
   140010316:	int3
   140010317:	int3
   140010318:	mov    rax,rsp
   14001031b:	mov    QWORD PTR [rax+0x8],rbx
   14001031f:	mov    QWORD PTR [rax+0x18],rsi
   140010323:	push   rbp
   140010324:	lea    rbp,[rax-0x488]
   14001032b:	sub    rsp,0x580
   140010332:	movaps XMMWORD PTR [rax-0x18],xmm6
   140010336:	mov    rax,QWORD PTR [rip+0x13ddb]        # 0x140024118
   14001033d:	xor    rax,rsp
   140010340:	mov    QWORD PTR [rbp+0x460],rax
   140010347:	xor    esi,esi
   140010349:	mov    rbx,rdx
   14001034c:	mov    WORD PTR [rdx],si
   14001034f:	mov    QWORD PTR [rsp+0x30],rsi
   140010354:	rex.W call QWORD PTR [rip+0x7bcd]        # 0x140017f28
   14001035b:	nop    DWORD PTR [rax+rax*1+0x0]
   140010360:	mov    rcx,rax
   140010363:	lea    r9,[rsp+0x30]
   140010368:	lea    edx,[rsi+0x8]
   14001036b:	lea    r8d,[rsi+0x1]
   14001036f:	rex.W call QWORD PTR [rip+0x7a82]        # 0x140017df8
   140010376:	nop    DWORD PTR [rax+rax*1+0x0]
   14001037b:	test   eax,eax
   14001037d:	jne    0x1400103aa
   14001037f:	rex.W call QWORD PTR [rip+0x7bd2]        # 0x140017f58
   140010386:	nop    DWORD PTR [rax+rax*1+0x0]
   14001038b:	mov    rcx,rax
   14001038e:	lea    r8,[rsp+0x30]
   140010393:	lea    edx,[rsi+0x8]
   140010396:	rex.W call QWORD PTR [rip+0x7a2b]        # 0x140017dc8
   14001039d:	nop    DWORD PTR [rax+rax*1+0x0]
   1400103a2:	test   eax,eax
   1400103a4:	je     0x1400104df
   1400103aa:	mov    rcx,QWORD PTR [rsp+0x30]
   1400103af:	lea    rax,[rsp+0x38]
   1400103b4:	mov    r9d,0x100
   1400103ba:	mov    QWORD PTR [rsp+0x20],rax
   1400103bf:	lea    r8,[rsp+0x60]
   1400103c4:	mov    DWORD PTR [rsp+0x38],esi
   1400103c8:	mov    edx,0x1
   1400103cd:	rex.W call QWORD PTR [rip+0x7a0c]        # 0x140017de0
   1400103d4:	nop    DWORD PTR [rax+rax*1+0x0]
   1400103d9:	mov    rcx,QWORD PTR [rsp+0x30]
   1400103de:	test   eax,eax
   1400103e0:	jne    0x1400103f3
   1400103e2:	rex.W call QWORD PTR [rip+0x7b5f]        # 0x140017f48
   1400103e9:	nop    DWORD PTR [rax+rax*1+0x0]
   1400103ee:	jmp    0x1400104df
   1400103f3:	rex.W call QWORD PTR [rip+0x7b4e]        # 0x140017f48
   1400103fa:	nop    DWORD PTR [rax+rax*1+0x0]
   1400103ff:	movups xmm6,XMMWORD PTR [rip+0xcbf2]        # 0x14001cff8
   140010406:	xor    edx,edx
   140010408:	lea    rcx,[rbp+0x270]
   14001040f:	mov    r8d,0x1f0
   140010415:	movdqu XMMWORD PTR [rbp+0x260],xmm6
   14001041d:	call   0x140015692
   140010422:	xor    edx,edx
   140010424:	lea    rcx,[rbp+0x70]
   140010428:	mov    r8d,0x1f0
   14001042e:	movdqu XMMWORD PTR [rbp+0x60],xmm6
   140010433:	call   0x140015692
   140010438:	mov    rcx,QWORD PTR [rsp+0x60]
   14001043d:	lea    rax,[rsp+0x50]
   140010442:	mov    QWORD PTR [rsp+0x28],rax
   140010447:	lea    r9,[rbp+0x260]
   14001044e:	lea    rax,[rsp+0x3c]
   140010453:	mov    DWORD PTR [rsp+0x40],0x100
   14001045b:	lea    r8,[rsp+0x40]
   140010460:	mov    QWORD PTR [rsp+0x20],rax
   140010465:	lea    rdx,[rbp+0x60]
   140010469:	mov    DWORD PTR [rsp+0x3c],0x100
   140010471:	rex.W call QWORD PTR [rip+0x7c98]        # 0x140018110
   140010478:	nop    DWORD PTR [rax+rax*1+0x0]
   14001047d:	test   eax,eax
   14001047f:	je     0x1400104df
   140010481:	mov    rcx,QWORD PTR [rsp+0x60]
   140010486:	lea    rdx,[rsp+0x48]
   14001048b:	mov    QWORD PTR [rsp+0x48],rsi
   140010490:	rex.W call QWORD PTR [rip+0x7959]        # 0x140017df0
   140010497:	nop    DWORD PTR [rax+rax*1+0x0]
   14001049c:	test   eax,eax
   14001049e:	je     0x1400104df
   1400104a0:	mov    rax,QWORD PTR [rsp+0x48]
   1400104a5:	lea    r9,[rbp+0x260]
   1400104ac:	mov    QWORD PTR [rsp+0x28],rax
   1400104b1:	lea    r8,[rip+0xcb50]        # 0x14001d008
   1400104b8:	lea    rax,[rbp+0x60]
   1400104bc:	mov    edx,0x400
   1400104c1:	mov    rcx,rbx
   1400104c4:	mov    QWORD PTR [rsp+0x20],rax
   1400104c9:	call   0x140003494
   1400104ce:	mov    rcx,QWORD PTR [rsp+0x48]
   1400104d3:	rex.W call QWORD PTR [rip+0x7a86]        # 0x140017f60
   1400104da:	nop    DWORD PTR [rax+rax*1+0x0]
   1400104df:	mov    rcx,QWORD PTR [rbp+0x460]
   1400104e6:	xor    rcx,rsp
   1400104e9:	call   0x1400143c0
   1400104ee:	lea    r11,[rsp+0x580]
   1400104f6:	mov    rbx,QWORD PTR [r11+0x10]
   1400104fa:	mov    rsi,QWORD PTR [r11+0x20]
   1400104fe:	movaps xmm6,XMMWORD PTR [r11-0x10]
   140010503:	mov    rsp,r11
   140010506:	pop    rbp
   140010507:	ret
   140010508:	int3
   140010509:	int3
   14001050a:	int3
   14001050b:	int3
   14001050c:	int3
   14001050d:	int3
   14001050e:	int3
   14001050f:	int3
   140010510:	mov    QWORD PTR [rsp+0x18],r8
   140010515:	mov    QWORD PTR [rsp+0x20],r9
   14001051a:	push   rbx
   14001051b:	push   rsi
   14001051c:	push   rdi
   14001051d:	sub    rsp,0x100
   140010524:	mov    rdi,rdx
   140010527:	mov    rsi,rcx
   14001052a:	mov    edx,DWORD PTR [rcx+0x24]
   14001052d:	call   0x14000fa74
   140010532:	test   eax,eax
   140010534:	je     0x1400105f2
   14001053a:	lea    rdx,[rip+0x7e3f]        # 0x140018380
   140010541:	mov    ecx,0x3ea
   140010546:	call   0x140014458
   14001054b:	mov    rbx,rax
   14001054e:	test   rax,rax
   140010551:	je     0x1400105ea
   140010557:	and    QWORD PTR [rsp+0x40],0x0
   14001055d:	lea    rax,[rsp+0x138]
   140010565:	and    QWORD PTR [rsp+0x48],0x0
   14001056b:	lea    r9,[rsp+0x40]
   140010570:	mov    QWORD PTR [rsp+0x30],rax
   140010575:	lea    r8,[rsp+0x48]
   14001057a:	mov    rax,QWORD PTR [rsp+0x130]
   140010582:	mov    edx,0x1f4
   140010587:	mov    rcx,rbx
   14001058a:	mov    QWORD PTR [rsp+0x28],rax
   14001058f:	call   0x14000ec90
   140010594:	cmp    QWORD PTR [rsp+0x40],0x1
   14001059a:	jne    0x1400105b1
   14001059c:	mov    rax,QWORD PTR [rsp+0x48]
   1400105a1:	mov    ecx,0x2e
   1400105a6:	mov    DWORD PTR [rax-0x4],0x2e002e
   1400105ad:	mov    WORD PTR [rax-0x6],cx
   1400105b1:	cmp    DWORD PTR [rdi+0x20],0xff
   1400105b8:	lea    rcx,[rsp+0x50]
   1400105bd:	mov    r10d,0x8c
   1400105c3:	mov    rdx,rdi
   1400105c6:	cmovne r10d,DWORD PTR [rdi+0x20]
   1400105cb:	call   0x14000f400
   1400105d0:	mov    rdx,rax
   1400105d3:	mov    QWORD PTR [rsp+0x20],rbx
   1400105d8:	mov    r9d,r10d
   1400105db:	lea    r8,[rip+0xca4e]        # 0x14001d030
   1400105e2:	mov    rcx,rsi
   1400105e5:	call   0x14000fe40
   1400105ea:	mov    rcx,rbx
   1400105ed:	call   0x140014084
   1400105f2:	mov    rcx,rdi
   1400105f5:	call   0x14000f484
   1400105fa:	add    rsp,0x100
   140010601:	pop    rdi
   140010602:	pop    rsi
   140010603:	pop    rbx
   140010604:	ret
   140010605:	int3
   140010606:	int3
   140010607:	int3
   140010608:	int3
   140010609:	int3
   14001060a:	int3
   14001060b:	int3
   14001060c:	mov    QWORD PTR [rsp+0x8],rbx
   140010611:	mov    QWORD PTR [rsp+0x10],rbp
   140010616:	mov    QWORD PTR [rsp+0x18],rsi
   14001061b:	push   rdi
   14001061c:	sub    rsp,0x50
   140010620:	mov    rbx,rdx
   140010623:	mov    rsi,r9
   140010626:	mov    edx,DWORD PTR [rcx+0x24]
   140010629:	mov    ebp,r8d
   14001062c:	mov    rdi,rcx
   14001062f:	call   0x14000fa74
   140010634:	test   eax,eax
   140010636:	je     0x14001068c
   140010638:	cmp    DWORD PTR [rbx+0x20],0xff
   14001063f:	mov    eax,0xbe
   140010644:	mov    r9d,DWORD PTR [rdi+0x30]
   140010648:	cmovne eax,DWORD PTR [rbx+0x20]
   14001064c:	mov    r8d,DWORD PTR [rbx+0x18]
   140010650:	mov    rdx,QWORD PTR [rbx+0x10]
   140010654:	mov    rcx,QWORD PTR [rbx]
   140010657:	mov    DWORD PTR [rsp+0x48],ebp
   14001065b:	mov    QWORD PTR [rsp+0x40],rsi
   140010660:	mov    DWORD PTR [rsp+0x38],eax
   140010664:	lea    rax,[rip+0xc9d5]        # 0x14001d040
   14001066b:	mov    QWORD PTR [rsp+0x30],rax
   140010670:	mov    rax,QWORD PTR [rdi+0x28]
   140010674:	mov    QWORD PTR [rsp+0x28],rax
   140010679:	mov    eax,DWORD PTR [rdi+0x24]
   14001067c:	mov    DWORD PTR [rsp+0x20],eax
   140010680:	rex.W call QWORD PTR [rip+0x7989]        # 0x140018010
   140010687:	nop    DWORD PTR [rax+rax*1+0x0]
   14001068c:	mov    rcx,rbx
   14001068f:	mov    rbx,QWORD PTR [rsp+0x60]
   140010694:	mov    rbp,QWORD PTR [rsp+0x68]
   140010699:	mov    rsi,QWORD PTR [rsp+0x70]
   14001069e:	add    rsp,0x50
   1400106a2:	pop    rdi
   1400106a3:	jmp    0x14000f484
   1400106a8:	int3
   1400106a9:	int3
   1400106aa:	int3
   1400106ab:	int3
   1400106ac:	int3
   1400106ad:	int3
   1400106ae:	int3
   1400106af:	int3
   1400106b0:	mov    QWORD PTR [rsp+0x20],r9
   1400106b5:	mov    QWORD PTR [rsp+0x10],rdx
   1400106ba:	push   rbp
   1400106bb:	push   rbx
   1400106bc:	push   rsi
   1400106bd:	push   rdi
   1400106be:	lea    rbp,[rsp-0x18]
   1400106c3:	sub    rsp,0x118
   1400106ca:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   1400106d3:	mov    esi,r8d
   1400106d6:	mov    rdi,rdx
   1400106d9:	mov    rbx,rcx
   1400106dc:	mov    edx,DWORD PTR [rcx+0x24]
   1400106df:	call   0x14000fa74
   1400106e4:	test   eax,eax
   1400106e6:	je     0x140010826
   1400106ec:	cmp    QWORD PTR [rbp+0x58],0x0
   1400106f1:	je     0x140010826
   1400106f7:	lea    rdx,[rip+0x7c82]        # 0x140018380
   1400106fe:	mov    ecx,0x3ea
   140010703:	call   0x140014458
   140010708:	mov    QWORD PTR [rsp+0x50],rax
   14001070d:	test   rax,rax
   140010710:	je     0x1400107ac
   140010716:	and    QWORD PTR [rsp+0x40],0x0
   14001071c:	and    QWORD PTR [rsp+0x48],0x0
   140010722:	lea    rcx,[rbp+0x60]
   140010726:	mov    QWORD PTR [rsp+0x30],rcx
   14001072b:	mov    rcx,QWORD PTR [rbp+0x58]
   14001072f:	mov    QWORD PTR [rsp+0x28],rcx
   140010734:	lea    r9,[rsp+0x40]
   140010739:	lea    r8,[rsp+0x48]
   14001073e:	mov    edx,0x1f4
   140010743:	mov    rcx,rax
   140010746:	call   0x14000ec90
   14001074b:	cmp    QWORD PTR [rsp+0x40],0x1
   140010751:	jne    0x140010768
   140010753:	mov    ecx,0x2e
   140010758:	mov    rax,QWORD PTR [rsp+0x48]
   14001075d:	mov    DWORD PTR [rax-0x4],0x2e002e
   140010764:	mov    WORD PTR [rax-0x6],cx
   140010768:	mov    rdx,rdi
   14001076b:	lea    rcx,[rsp+0x60]
   140010770:	call   0x14000f400
   140010775:	mov    r10,rax
   140010778:	lea    rcx,[rsp+0x50]
   14001077d:	call   0x14000ee98
   140010782:	mov    r8,rax
   140010785:	mov    edx,0x50
   14001078a:	mov    rcx,rdi
   14001078d:	call   0x14000f844
   140010792:	mov    r9d,eax
   140010795:	mov    QWORD PTR [rsp+0x20],r8
   14001079a:	lea    r8,[rip+0xc8bf]        # 0x14001d060
   1400107a1:	mov    rdx,r10
   1400107a4:	mov    rcx,rbx
   1400107a7:	call   0x14000fe40
   1400107ac:	lea    rcx,[rsp+0x40]
   1400107b1:	call   0x14000eea4
   1400107b6:	nop
   1400107b7:	mov    rcx,rbx
   1400107ba:	call   0x1400100cc
   1400107bf:	mov    rdx,rax
   1400107c2:	lea    rcx,[rsp+0x40]
   1400107c7:	call   0x14000f0d0
   1400107cc:	mov    rdx,rdi
   1400107cf:	lea    rcx,[rsp+0x60]
   1400107d4:	call   0x14000f400
   1400107d9:	mov    r11,rax
   1400107dc:	lea    rcx,[rsp+0x40]
   1400107e1:	call   0x14000ee98
   1400107e6:	mov    r10,rax
   1400107e9:	mov    edx,0xc8
   1400107ee:	mov    rcx,rdi
   1400107f1:	call   0x14000f844
   1400107f6:	mov    r9d,eax
   1400107f9:	mov    QWORD PTR [rsp+0x20],r10
   1400107fe:	lea    r8,[rip+0xc85b]        # 0x14001d060
   140010805:	mov    rdx,r11
   140010808:	mov    rcx,rbx
   14001080b:	call   0x14000fe40
   140010810:	nop
   140010811:	lea    rcx,[rsp+0x40]
   140010816:	call   0x1400039a4
   14001081b:	nop
   14001081c:	lea    rcx,[rsp+0x50]
   140010821:	call   0x14000ee88
   140010826:	mov    DWORD PTR [rbx+0x8],esi
   140010829:	mov    DWORD PTR [rsp+0x40],esi
   14001082d:	lea    rdx,[rip+0x117e4]        # 0x140022018
   140010834:	lea    rcx,[rsp+0x40]
   140010839:	call   0x14001478c
   14001083e:	int3
   14001083f:	int3
   140010840:	int3
   140010841:	int3
   140010842:	int3
   140010843:	int3
   140010844:	int3
   140010845:	int3
   140010846:	int3
   140010847:	int3
   140010848:	mov    rax,rsp
   14001084b:	mov    QWORD PTR [rax+0x10],rdx
   14001084f:	push   rbp
   140010850:	push   rdi
   140010851:	push   r14
   140010853:	lea    rbp,[rax-0xa8]
   14001085a:	sub    rsp,0x190
   140010861:	mov    QWORD PTR [rsp+0x38],0xfffffffffffffffe
   14001086a:	mov    QWORD PTR [rax+0x8],rbx
   14001086e:	mov    QWORD PTR [rax+0x18],rsi
   140010872:	mov    rsi,r9
   140010875:	mov    ebx,r8d
   140010878:	mov    rdi,rdx
   14001087b:	mov    r14,rcx
   14001087e:	mov    r10d,0x8007000e
   140010884:	cmp    r8d,r10d
   140010887:	je     0x14001098f
   14001088d:	cmp    ebx,0x80070008
   140010893:	je     0x14001098f
   140010899:	cmp    ebx,0x80070071
   14001089f:	je     0x14001098f
   1400108a5:	cmp    ebx,0x800703fb
   1400108ab:	je     0x14001098f
   1400108b1:	cmp    ebx,0x800705aa
   1400108b7:	je     0x14001098f
   1400108bd:	cmp    ebx,0x80070486
   1400108c3:	je     0x14001098f
   1400108c9:	cmp    ebx,0x80070070
   1400108cf:	jne    0x1400108f9
   1400108d1:	lea    rcx,[rsp+0x40]
   1400108d6:	call   0x14000f400
   1400108db:	mov    QWORD PTR [rsp+0x20],rsi
   1400108e0:	lea    r9,[rip+0xc7d9]        # 0x14001d0c0
   1400108e7:	mov    r8d,0x8004231f
   1400108ed:	mov    rdx,rax
   1400108f0:	mov    rcx,r14
   1400108f3:	call   0x1400106b0
   1400108f8:	int3
   1400108f9:	mov    r10d,0x80042316
   1400108ff:	cmp    ebx,r10d
   140010902:	jne    0x140010929
   140010904:	lea    rcx,[rsp+0x40]
   140010909:	call   0x14000f400
   14001090e:	mov    QWORD PTR [rsp+0x20],rsi
   140010913:	lea    r9,[rip+0xc7f6]        # 0x14001d110
   14001091a:	mov    r8d,r10d
   14001091d:	mov    rdx,rax
   140010920:	mov    rcx,r14
   140010923:	call   0x1400106b0
   140010928:	int3
   140010929:	mov    r8,rsi
   14001092c:	lea    rdx,[rbp-0x18]
   140010930:	mov    rcx,rdi
   140010933:	call   0x14000f744
   140010938:	mov    r8d,ebx
   14001093b:	lea    rdx,[rsp+0x40]
   140010940:	mov    rcx,rax
   140010943:	call   0x14000f4d4
   140010948:	mov    r8,rax
   14001094b:	mov    edx,0x2001
   140010950:	mov    rcx,r14
   140010953:	call   0x140011870
   140010958:	lea    rcx,[rbp-0x18]
   14001095c:	call   0x14000f484
   140010961:	mov    rdx,rdi
   140010964:	lea    rcx,[rbp-0x18]
   140010968:	call   0x14000f400
   14001096d:	mov    DWORD PTR [rsp+0x28],ebx
   140010971:	mov    QWORD PTR [rsp+0x20],rsi
   140010976:	lea    r9,[rip+0xc803]        # 0x14001d180
   14001097d:	mov    r8d,0x80042302
   140010983:	mov    rdx,rax
   140010986:	mov    rcx,r14
   140010989:	call   0x1400106b0
   14001098e:	int3
   14001098f:	lea    rcx,[rbp-0x18]
   140010993:	call   0x14000f400
   140010998:	mov    QWORD PTR [rsp+0x20],rsi
   14001099d:	lea    r9,[rip+0xc6cc]        # 0x14001d070
   1400109a4:	mov    r8d,r10d
   1400109a7:	mov    rdx,rax
   1400109aa:	mov    rcx,r14
   1400109ad:	call   0x1400106b0
   1400109b2:	int3
   1400109b3:	int3
   1400109b4:	int3
   1400109b5:	int3
   1400109b6:	int3
   1400109b7:	int3
   1400109b8:	int3
   1400109b9:	int3
   1400109ba:	int3
   1400109bb:	int3
   1400109bc:	mov    rax,rsp
   1400109bf:	mov    QWORD PTR [rax+0x18],r8
   1400109c3:	mov    QWORD PTR [rax+0x10],rdx
   1400109c7:	mov    QWORD PTR [rax+0x20],r9
   1400109cb:	push   rbp
   1400109cc:	push   rbx
   1400109cd:	push   rsi
   1400109ce:	push   rdi
   1400109cf:	push   r14
   1400109d1:	push   r15
   1400109d3:	lea    rbp,[rax-0x1a8]
   1400109da:	sub    rsp,0x278
   1400109e1:	mov    QWORD PTR [rsp+0x68],0xfffffffffffffffe
   1400109ea:	mov    rsi,rdx
   1400109ed:	mov    r14,rcx
   1400109f0:	lea    rdx,[rip+0x7989]        # 0x140018380
   1400109f7:	mov    ecx,0x3ea
   1400109fc:	call   0x140014458
   140010a01:	mov    QWORD PTR [rsp+0x60],rax
   140010a06:	xor    r15d,r15d
   140010a09:	test   rax,rax
   140010a0c:	jne    0x140010a34
   140010a0e:	mov    rdx,rsi
   140010a11:	lea    rcx,[rsp+0x70]
   140010a16:	call   0x14000f400
   140010a1b:	lea    r9,[rip+0xc52e]        # 0x14001cf50
   140010a22:	mov    r8d,0x8007000e
   140010a28:	mov    rdx,rax
   140010a2b:	mov    rcx,r14
   140010a2e:	call   0x1400106b0
   140010a33:	int3
   140010a34:	mov    QWORD PTR [rsp+0x48],r15
   140010a39:	mov    QWORD PTR [rsp+0x40],r15
   140010a3e:	lea    rcx,[rbp+0x1c8]
   140010a45:	mov    QWORD PTR [rsp+0x30],rcx
   140010a4a:	mov    rcx,QWORD PTR [rbp+0x1c0]
   140010a51:	mov    QWORD PTR [rsp+0x28],rcx
   140010a56:	lea    r9,[rsp+0x48]
   140010a5b:	lea    r8,[rsp+0x40]
   140010a60:	mov    edx,0x1f4
   140010a65:	mov    rcx,rax
   140010a68:	call   0x14000ec90
   140010a6d:	cmp    QWORD PTR [rsp+0x48],0x1
   140010a73:	jne    0x140010a8a
   140010a75:	mov    ecx,0x2e
   140010a7a:	mov    rax,QWORD PTR [rsp+0x40]
   140010a7f:	mov    DWORD PTR [rax-0x4],0x2e002e
   140010a86:	mov    WORD PTR [rax-0x6],cx
   140010a8a:	mov    ebx,DWORD PTR [r14+0x8]
   140010a8e:	mov    eax,0x8000ffff
   140010a93:	test   ebx,ebx
   140010a95:	cmove  ebx,eax
   140010a98:	mov    QWORD PTR [rsp+0x50],r15
   140010a9d:	mov    QWORD PTR [rsp+0x58],r15
   140010aa2:	lea    rdx,[rsp+0x50]
   140010aa7:	xor    ecx,ecx
   140010aa9:	rex.W call QWORD PTR [rip+0x74f8]        # 0x140017fa8
   140010ab0:	nop    DWORD PTR [rax+rax*1+0x0]
   140010ab5:	test   eax,eax
   140010ab7:	js     0x140010ad5
   140010ab9:	mov    rcx,QWORD PTR [rsp+0x50]
   140010abe:	test   rcx,rcx
   140010ac1:	je     0x140010ad5
   140010ac3:	mov    rax,QWORD PTR [rcx]
   140010ac6:	lea    rdx,[rsp+0x58]
   140010acb:	mov    rax,QWORD PTR [rax+0x28]
   140010acf:	call   QWORD PTR [rip+0x77c3]        # 0x140018298
   140010ad5:	mov    rax,QWORD PTR [rsp+0x58]
   140010ada:	lea    rdi,[rip+0xb22f]        # 0x14001bd10
   140010ae1:	test   rax,rax
   140010ae4:	cmovne rdi,rax
   140010ae8:	cmp    ebx,0x8007000e
   140010aee:	je     0x140010c04
   140010af4:	cmp    ebx,0x80070008
   140010afa:	je     0x140010c04
   140010b00:	cmp    ebx,0x80070071
   140010b06:	je     0x140010c04
   140010b0c:	cmp    ebx,0x800703fb
   140010b12:	je     0x140010c04
   140010b18:	cmp    ebx,0x800705aa
   140010b1e:	je     0x140010c04
   140010b24:	cmp    ebx,0x80070486
   140010b2a:	je     0x140010c04
   140010b30:	lea    rcx,[rsp+0x60]
   140010b35:	call   0x14000ee98
   140010b3a:	mov    r15,rax
   140010b3d:	cmp    ebx,0x80070070
   140010b43:	jne    0x140010b75
   140010b45:	mov    rdx,rsi
   140010b48:	lea    rcx,[rsp+0x70]
   140010b4d:	call   0x14000f400
   140010b52:	mov    QWORD PTR [rsp+0x28],rdi
   140010b57:	mov    QWORD PTR [rsp+0x20],r15
   140010b5c:	lea    r9,[rip+0xc6dd]        # 0x14001d240
   140010b63:	mov    r8d,0x8004231f
   140010b69:	mov    rdx,rax
   140010b6c:	mov    rcx,r14
   140010b6f:	call   0x1400106b0
   140010b74:	int3
   140010b75:	mov    r8,r15
   140010b78:	lea    rdx,[rbp+0x18]
   140010b7c:	mov    rcx,rsi
   140010b7f:	call   0x14000f744
   140010b84:	mov    r8,rdi
   140010b87:	lea    rdx,[rbp+0xc0]
   140010b8e:	mov    rcx,rax
   140010b91:	call   0x14000f744
   140010b96:	mov    r8d,ebx
   140010b99:	lea    rdx,[rsp+0x70]
   140010b9e:	mov    rcx,rax
   140010ba1:	call   0x14000f4d4
   140010ba6:	mov    r9d,0x1
   140010bac:	mov    r8,rax
   140010baf:	mov    edx,0x2001
   140010bb4:	mov    rcx,r14
   140010bb7:	call   0x140011870
   140010bbc:	lea    rcx,[rbp+0xc0]
   140010bc3:	call   0x14000f484
   140010bc8:	lea    rcx,[rbp+0x18]
   140010bcc:	call   0x14000f484
   140010bd1:	mov    rdx,rsi
   140010bd4:	lea    rcx,[rbp+0x18]
   140010bd8:	call   0x14000f400
   140010bdd:	mov    DWORD PTR [rsp+0x30],ebx
   140010be1:	mov    QWORD PTR [rsp+0x28],rdi
   140010be6:	mov    QWORD PTR [rsp+0x20],r15
   140010beb:	lea    r9,[rip+0xc6ae]        # 0x14001d2a0
   140010bf2:	mov    r8d,0x80042302
   140010bf8:	mov    rdx,rax
   140010bfb:	mov    rcx,r14
   140010bfe:	call   0x1400106b0
   140010c03:	int3
   140010c04:	mov    rdx,rsi
   140010c07:	lea    rcx,[rbp+0x18]
   140010c0b:	call   0x14000f400
   140010c10:	mov    rdx,rax
   140010c13:	lea    rcx,[rsp+0x60]
   140010c18:	call   0x14000ee98
   140010c1d:	mov    QWORD PTR [rsp+0x28],rdi
   140010c22:	mov    QWORD PTR [rsp+0x20],rax
   140010c27:	lea    r9,[rip+0xc5b2]        # 0x14001d1e0
   140010c2e:	mov    r8d,0x8007000e
   140010c34:	mov    rcx,r14
   140010c37:	call   0x1400106b0
   140010c3c:	int3
   140010c3d:	int3
   140010c3e:	int3
   140010c3f:	int3
   140010c40:	int3
   140010c41:	int3
   140010c42:	int3
   140010c43:	int3
   140010c44:	mov    rax,rsp
   140010c47:	mov    QWORD PTR [rax+0x18],r8
   140010c4b:	mov    QWORD PTR [rax+0x10],rdx
   140010c4f:	mov    QWORD PTR [rax+0x20],r9
   140010c53:	push   rbx
   140010c54:	sub    rsp,0xe0
   140010c5b:	mov    QWORD PTR [rsp+0x28],0xfffffffffffffffe
   140010c64:	mov    r10,rcx
   140010c67:	lea    r11,[rax+0x20]
   140010c6b:	lea    rcx,[rsp+0x38]
   140010c70:	call   0x14000f400
   140010c75:	mov    r9,r11
   140010c78:	mov    r8,QWORD PTR [rsp+0x100]
   140010c80:	mov    rdx,rax
   140010c83:	mov    rcx,r10
   140010c86:	call   0x1400109bc
   140010c8b:	nop
   140010c8c:	mov    ebx,DWORD PTR [rsp+0x20]
   140010c90:	jmp    0x140010c97
   140010c92:	mov    ebx,0x8007000e
   140010c97:	mov    rcx,QWORD PTR [rsp+0xf8]
   140010c9f:	call   0x14000f484
   140010ca4:	mov    eax,ebx
   140010ca6:	jmp    0x140010cba
   140010ca8:	mov    rcx,QWORD PTR [rsp+0xf8]
   140010cb0:	call   0x14000f484
   140010cb5:	mov    eax,0x80042302
   140010cba:	add    rsp,0xe0
   140010cc1:	pop    rbx
   140010cc2:	ret
   140010cc3:	int3
   140010cc4:	int3
   140010cc5:	int3
   140010cc6:	int3
   140010cc7:	int3
   140010cc8:	int3
   140010cc9:	int3
   140010cca:	int3
   140010ccb:	int3
   140010ccc:	mov    rax,rsp
   140010ccf:	mov    QWORD PTR [rax+0x18],r8
   140010cd3:	mov    QWORD PTR [rax+0x10],rdx
   140010cd7:	mov    QWORD PTR [rax+0x20],r9
   140010cdb:	push   rbp
   140010cdc:	push   rbx
   140010cdd:	push   rsi
   140010cde:	push   rdi
   140010cdf:	push   r14
   140010ce1:	lea    rbp,[rax-0xd8]
   140010ce8:	sub    rsp,0x1b0
   140010cef:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   140010cf8:	mov    rdi,rdx
   140010cfb:	mov    rsi,rcx
   140010cfe:	lea    rdx,[rip+0x767b]        # 0x140018380
   140010d05:	mov    ecx,0x3ea
   140010d0a:	call   0x140014458
   140010d0f:	mov    QWORD PTR [rsp+0x50],rax
   140010d14:	test   rax,rax
   140010d17:	jne    0x140010d3f
   140010d19:	mov    rdx,rdi
   140010d1c:	lea    rcx,[rsp+0x60]
   140010d21:	call   0x14000f400
   140010d26:	lea    r9,[rip+0xc223]        # 0x14001cf50
   140010d2d:	mov    r8d,0x8007000e
   140010d33:	mov    rdx,rax
   140010d36:	mov    rcx,rsi
   140010d39:	call   0x1400106b0
   140010d3e:	int3
   140010d3f:	and    QWORD PTR [rsp+0x48],0x0
   140010d45:	and    QWORD PTR [rsp+0x40],0x0
   140010d4b:	lea    rcx,[rbp+0xf8]
   140010d52:	mov    QWORD PTR [rsp+0x30],rcx
   140010d57:	mov    rcx,QWORD PTR [rbp+0xf0]
   140010d5e:	mov    QWORD PTR [rsp+0x28],rcx
   140010d63:	lea    r9,[rsp+0x48]
   140010d68:	lea    r8,[rsp+0x40]
   140010d6d:	mov    edx,0x1f4
   140010d72:	mov    rcx,rax
   140010d75:	call   0x14000ec90
   140010d7a:	cmp    QWORD PTR [rsp+0x48],0x1
   140010d80:	jne    0x140010d97
   140010d82:	mov    ecx,0x2e
   140010d87:	mov    rax,QWORD PTR [rsp+0x40]
   140010d8c:	mov    DWORD PTR [rax-0x4],0x2e002e
   140010d93:	mov    WORD PTR [rax-0x6],cx
   140010d97:	rex.W call QWORD PTR [rip+0x71da]        # 0x140017f78
   140010d9e:	nop    DWORD PTR [rax+rax*1+0x0]
   140010da3:	movzx  ebx,ax
   140010da6:	or     ebx,0x80070000
   140010dac:	test   eax,eax
   140010dae:	cmovle ebx,eax
   140010db1:	mov    eax,0x8000ffff
   140010db6:	test   ebx,ebx
   140010db8:	cmove  ebx,eax
   140010dbb:	cmp    ebx,0x8007000e
   140010dc1:	je     0x140010ea9
   140010dc7:	cmp    ebx,0x80070008
   140010dcd:	je     0x140010ea9
   140010dd3:	cmp    ebx,0x80070071
   140010dd9:	je     0x140010ea9
   140010ddf:	cmp    ebx,0x800703fb
   140010de5:	je     0x140010ea9
   140010deb:	cmp    ebx,0x800705aa
   140010df1:	je     0x140010ea9
   140010df7:	cmp    ebx,0x80070486
   140010dfd:	je     0x140010ea9
   140010e03:	lea    rcx,[rsp+0x50]
   140010e08:	call   0x14000ee98
   140010e0d:	mov    r14,rax
   140010e10:	cmp    ebx,0x80070070
   140010e16:	jne    0x140010e43
   140010e18:	mov    rdx,rdi
   140010e1b:	lea    rcx,[rsp+0x60]
   140010e20:	call   0x14000f400
   140010e25:	mov    QWORD PTR [rsp+0x20],r14
   140010e2a:	lea    r9,[rip+0xc28f]        # 0x14001d0c0
   140010e31:	mov    r8d,0x8004231f
   140010e37:	mov    rdx,rax
   140010e3a:	mov    rcx,rsi
   140010e3d:	call   0x1400106b0
   140010e42:	int3
   140010e43:	mov    r8,r14
   140010e46:	lea    rdx,[rbp+0x8]
   140010e4a:	mov    rcx,rdi
   140010e4d:	call   0x14000f744
   140010e52:	mov    r8d,ebx
   140010e55:	lea    rdx,[rsp+0x60]
   140010e5a:	mov    rcx,rax
   140010e5d:	call   0x14000f4d4
   140010e62:	mov    r8,rax
   140010e65:	mov    edx,0x2001
   140010e6a:	mov    rcx,rsi
   140010e6d:	call   0x140011870
   140010e72:	lea    rcx,[rbp+0x8]
   140010e76:	call   0x14000f484
   140010e7b:	mov    rdx,rdi
   140010e7e:	lea    rcx,[rbp+0x8]
   140010e82:	call   0x14000f400
   140010e87:	mov    DWORD PTR [rsp+0x28],ebx
   140010e8b:	mov    QWORD PTR [rsp+0x20],r14
   140010e90:	lea    r9,[rip+0xc479]        # 0x14001d310
   140010e97:	mov    r8d,0x80042302
   140010e9d:	mov    rdx,rax
   140010ea0:	mov    rcx,rsi
   140010ea3:	call   0x1400106b0
   140010ea8:	int3
   140010ea9:	mov    rdx,rdi
   140010eac:	lea    rcx,[rbp+0x8]
   140010eb0:	call   0x14000f400
   140010eb5:	mov    rdx,rax
   140010eb8:	lea    rcx,[rsp+0x50]
   140010ebd:	call   0x14000ee98
   140010ec2:	mov    QWORD PTR [rsp+0x20],rax
   140010ec7:	lea    r9,[rip+0xc1a2]        # 0x14001d070
   140010ece:	mov    r8d,0x8007000e
   140010ed4:	mov    rcx,rsi
   140010ed7:	call   0x1400106b0
   140010edc:	int3
   140010edd:	int3
   140010ede:	int3
   140010edf:	int3
   140010ee0:	int3
   140010ee1:	int3
   140010ee2:	int3
   140010ee3:	int3
   140010ee4:	mov    QWORD PTR [rsp+0x20],r9
   140010ee9:	mov    QWORD PTR [rsp+0x10],rdx
   140010eee:	push   rbp
   140010eef:	push   rbx
   140010ef0:	push   rsi
   140010ef1:	push   rdi
   140010ef2:	push   r14
   140010ef4:	lea    rbp,[rsp-0xb0]
   140010efc:	sub    rsp,0x1b0
   140010f03:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   140010f0c:	mov    ebx,r8d
   140010f0f:	mov    rdi,rdx
   140010f12:	mov    rsi,rcx
   140010f15:	lea    rdx,[rip+0x7464]        # 0x140018380
   140010f1c:	mov    ecx,0x3ea
   140010f21:	call   0x140014458
   140010f26:	mov    QWORD PTR [rsp+0x50],rax
   140010f2b:	test   rax,rax
   140010f2e:	jne    0x140010f56
   140010f30:	mov    rdx,rdi
   140010f33:	lea    rcx,[rsp+0x60]
   140010f38:	call   0x14000f400
   140010f3d:	lea    r9,[rip+0xc00c]        # 0x14001cf50
   140010f44:	mov    r8d,0x8007000e
   140010f4a:	mov    rdx,rax
   140010f4d:	mov    rcx,rsi
   140010f50:	call   0x1400106b0
   140010f55:	int3
   140010f56:	and    QWORD PTR [rsp+0x48],0x0
   140010f5c:	and    QWORD PTR [rsp+0x40],0x0
   140010f62:	lea    rcx,[rbp+0x100]
   140010f69:	mov    QWORD PTR [rsp+0x30],rcx
   140010f6e:	mov    rcx,QWORD PTR [rbp+0xf8]
   140010f75:	mov    QWORD PTR [rsp+0x28],rcx
   140010f7a:	lea    r9,[rsp+0x48]
   140010f7f:	lea    r8,[rsp+0x40]
   140010f84:	mov    edx,0x1f4
   140010f89:	mov    rcx,rax
   140010f8c:	call   0x14000ec90
   140010f91:	cmp    QWORD PTR [rsp+0x48],0x1
   140010f97:	jne    0x140010fae
   140010f99:	mov    ecx,0x2e
   140010f9e:	mov    rax,QWORD PTR [rsp+0x40]
   140010fa3:	mov    DWORD PTR [rax-0x4],0x2e002e
   140010faa:	mov    WORD PTR [rax-0x6],cx
   140010fae:	cmp    ebx,0x8007000e
   140010fb4:	je     0x14001109c
   140010fba:	cmp    ebx,0x80070008
   140010fc0:	je     0x14001109c
   140010fc6:	cmp    ebx,0x80070071
   140010fcc:	je     0x14001109c
   140010fd2:	cmp    ebx,0x800703fb
   140010fd8:	je     0x14001109c
   140010fde:	cmp    ebx,0x800705aa
   140010fe4:	je     0x14001109c
   140010fea:	cmp    ebx,0x80070486
   140010ff0:	je     0x14001109c
   140010ff6:	lea    rcx,[rsp+0x50]
   140010ffb:	call   0x14000ee98
   140011000:	mov    r14,rax
   140011003:	cmp    ebx,0x80070070
   140011009:	jne    0x140011036
   14001100b:	mov    rdx,rdi
   14001100e:	lea    rcx,[rsp+0x60]
   140011013:	call   0x14000f400
   140011018:	mov    QWORD PTR [rsp+0x20],r14
   14001101d:	lea    r9,[rip+0xc09c]        # 0x14001d0c0
   140011024:	mov    r8d,0x8004231f
   14001102a:	mov    rdx,rax
   14001102d:	mov    rcx,rsi
   140011030:	call   0x1400106b0
   140011035:	int3
   140011036:	mov    r8,r14
   140011039:	lea    rdx,[rbp+0x8]
   14001103d:	mov    rcx,rdi
   140011040:	call   0x14000f744
   140011045:	mov    r8d,ebx
   140011048:	lea    rdx,[rsp+0x60]
   14001104d:	mov    rcx,rax
   140011050:	call   0x14000f4d4
   140011055:	mov    r8,rax
   140011058:	mov    edx,0x2001
   14001105d:	mov    rcx,rsi
   140011060:	call   0x140011870
   140011065:	lea    rcx,[rbp+0x8]
   140011069:	call   0x14000f484
   14001106e:	mov    rdx,rdi
   140011071:	lea    rcx,[rbp+0x8]
   140011075:	call   0x14000f400
   14001107a:	mov    DWORD PTR [rsp+0x28],ebx
   14001107e:	mov    QWORD PTR [rsp+0x20],r14
   140011083:	lea    r9,[rip+0xc286]        # 0x14001d310
   14001108a:	mov    r8d,0x80042302
   140011090:	mov    rdx,rax
   140011093:	mov    rcx,rsi
   140011096:	call   0x1400106b0
   14001109b:	int3
   14001109c:	mov    rdx,rdi
   14001109f:	lea    rcx,[rbp+0x8]
   1400110a3:	call   0x14000f400
   1400110a8:	mov    rdx,rax
   1400110ab:	lea    rcx,[rsp+0x50]
   1400110b0:	call   0x14000ee98
   1400110b5:	mov    QWORD PTR [rsp+0x20],rax
   1400110ba:	lea    r9,[rip+0xbfaf]        # 0x14001d070
   1400110c1:	mov    r8d,0x8007000e
   1400110c7:	mov    rcx,rsi
   1400110ca:	call   0x1400106b0
   1400110cf:	int3
   1400110d0:	int3
   1400110d1:	int3
   1400110d2:	int3
   1400110d3:	int3
   1400110d4:	int3
   1400110d5:	int3
   1400110d6:	int3
   1400110d7:	int3
   1400110d8:	mov    rax,rsp
   1400110db:	mov    QWORD PTR [rax+0x20],r9
   1400110df:	mov    QWORD PTR [rax+0x10],rdx
   1400110e3:	push   rbx
   1400110e4:	sub    rsp,0xf0
   1400110eb:	mov    QWORD PTR [rsp+0x38],0xfffffffffffffffe
   1400110f4:	mov    r10d,r8d
   1400110f7:	mov    r11,rcx
   1400110fa:	lea    rbx,[rax+0x28]
   1400110fe:	lea    rcx,[rsp+0x48]
   140011103:	call   0x14000f400
   140011108:	mov    QWORD PTR [rsp+0x20],rbx
   14001110d:	mov    r9,QWORD PTR [rsp+0x118]
   140011115:	mov    r8d,r10d
   140011118:	mov    rdx,rax
   14001111b:	mov    rcx,r11
   14001111e:	call   0x140010ee4
   140011123:	nop
   140011124:	mov    ebx,DWORD PTR [rsp+0x30]
   140011128:	jmp    0x14001112f
   14001112a:	mov    ebx,0x8007000e
   14001112f:	mov    rcx,QWORD PTR [rsp+0x108]
   140011137:	call   0x14000f484
   14001113c:	mov    eax,ebx
   14001113e:	jmp    0x140011152
   140011140:	mov    rcx,QWORD PTR [rsp+0x108]
   140011148:	call   0x14000f484
   14001114d:	mov    eax,0x80042302
   140011152:	add    rsp,0xf0
   140011159:	pop    rbx
   14001115a:	ret
   14001115b:	int3
   14001115c:	int3
   14001115d:	int3
   14001115e:	int3
   14001115f:	int3
   140011160:	int3
   140011161:	int3
   140011162:	int3
   140011163:	int3
   140011164:	mov    QWORD PTR [rsp+0x10],rdx
   140011169:	push   rbp
   14001116a:	push   rbx
   14001116b:	push   rsi
   14001116c:	push   rdi
   14001116d:	push   r14
   14001116f:	lea    rbp,[rsp-0xb0]
   140011177:	sub    rsp,0x1b0
   14001117e:	mov    QWORD PTR [rsp+0x58],0xfffffffffffffffe
   140011187:	mov    r14d,r9d
   14001118a:	mov    ebx,r8d
   14001118d:	mov    rsi,rdx
   140011190:	mov    rdi,rcx
   140011193:	lea    rdx,[rip+0x71e6]        # 0x140018380
   14001119a:	mov    ecx,0x3ea
   14001119f:	call   0x140014458
   1400111a4:	mov    QWORD PTR [rsp+0x48],rax
   1400111a9:	test   rax,rax
   1400111ac:	jne    0x1400111d4
   1400111ae:	mov    rdx,rsi
   1400111b1:	lea    rcx,[rsp+0x60]
   1400111b6:	call   0x14000f400
   1400111bb:	lea    r9,[rip+0xbd8e]        # 0x14001cf50
   1400111c2:	mov    r8d,0x8007000e
   1400111c8:	mov    rdx,rax
   1400111cb:	mov    rcx,rdi
   1400111ce:	call   0x1400106b0
   1400111d3:	int3
   1400111d4:	and    QWORD PTR [rsp+0x50],0x0
   1400111da:	and    QWORD PTR [rsp+0x40],0x0
   1400111e0:	lea    rcx,[rbp+0x108]
   1400111e7:	mov    QWORD PTR [rsp+0x30],rcx
   1400111ec:	mov    rcx,QWORD PTR [rbp+0x100]
   1400111f3:	mov    QWORD PTR [rsp+0x28],rcx
   1400111f8:	lea    r9,[rsp+0x50]
   1400111fd:	lea    r8,[rsp+0x40]
   140011202:	mov    edx,0x1f4
   140011207:	mov    rcx,rax
   14001120a:	call   0x14000ec90
   14001120f:	cmp    QWORD PTR [rsp+0x50],0x1
   140011215:	jne    0x14001122c
   140011217:	mov    ecx,0x2e
   14001121c:	mov    rax,QWORD PTR [rsp+0x40]
   140011221:	mov    DWORD PTR [rax-0x4],0x2e002e
   140011228:	mov    WORD PTR [rax-0x6],cx
   14001122c:	mov    DWORD PTR [rdi+0x8],ebx
   14001122f:	cmp    ebx,0x8007000e
   140011235:	je     0x140011426
   14001123b:	cmp    ebx,0x80070008
   140011241:	je     0x140011426
   140011247:	cmp    ebx,0x80070071
   14001124d:	je     0x140011426
   140011253:	cmp    ebx,0x800703fb
   140011259:	je     0x140011426
   14001125f:	cmp    ebx,0x800705aa
   140011265:	je     0x140011426
   14001126b:	cmp    ebx,0x80070486
   140011271:	je     0x140011426
   140011277:	cmp    ebx,0x80070070
   14001127d:	jne    0x1400112b4
   14001127f:	mov    rdx,rsi
   140011282:	lea    rcx,[rsp+0x60]
   140011287:	call   0x14000f400
   14001128c:	mov    rdx,rax
   14001128f:	lea    rcx,[rsp+0x48]
   140011294:	call   0x14000ee98
   140011299:	mov    QWORD PTR [rsp+0x20],rax
   14001129e:	lea    r9,[rip+0xc0cb]        # 0x14001d370
   1400112a5:	mov    r8d,0x8004231f
   1400112ab:	mov    rcx,rdi
   1400112ae:	call   0x1400106b0
   1400112b3:	int3
   1400112b4:	lea    eax,[rbx+0x7ff8fffe]
   1400112ba:	cmp    eax,0x1
   1400112bd:	jbe    0x1400113d0
   1400112c3:	cmp    ebx,0x8007048f
   1400112c9:	je     0x1400113d0
   1400112cf:	cmp    ebx,0x80070015
   1400112d5:	je     0x1400113d0
   1400112db:	cmp    ebx,0x800705b4
   1400112e1:	jne    0x140011338
   1400112e3:	lea    rcx,[rsp+0x48]
   1400112e8:	call   0x14000ee98
   1400112ed:	mov    rbx,rax
   1400112f0:	mov    r8,rax
   1400112f3:	lea    rdx,[rsp+0x60]
   1400112f8:	mov    rcx,rsi
   1400112fb:	call   0x14000f744
   140011300:	mov    r8,rax
   140011303:	mov    edx,0x3016
   140011308:	mov    rcx,rdi
   14001130b:	call   0x140011870
   140011310:	mov    rdx,rsi
   140011313:	lea    rcx,[rsp+0x60]
   140011318:	call   0x14000f400
   14001131d:	mov    QWORD PTR [rsp+0x20],rbx
   140011322:	lea    r9,[rip+0xc137]        # 0x14001d460
   140011329:	mov    r8d,r14d
   14001132c:	mov    rdx,rax
   14001132f:	mov    rcx,rdi
   140011332:	call   0x1400106b0
   140011337:	int3
   140011338:	cmp    r14d,0x80042308
   14001133f:	je     0x14001138e
   140011341:	lea    rcx,[rsp+0x48]
   140011346:	call   0x14000ee98
   14001134b:	mov    r8,rax
   14001134e:	lea    rdx,[rbp+0x8]
   140011352:	mov    rcx,rsi
   140011355:	call   0x14000f744
   14001135a:	mov    r9,rax
   14001135d:	mov    rcx,rdi
   140011360:	call   0x1400038ec
   140011365:	mov    r8d,eax
   140011368:	lea    rdx,[rsp+0x60]
   14001136d:	mov    rcx,r9
   140011370:	call   0x14000f4d4
   140011375:	mov    r8,rax
   140011378:	mov    edx,0x3001
   14001137d:	mov    rcx,rdi
   140011380:	call   0x140011870
   140011385:	lea    rcx,[rbp+0x8]
   140011389:	call   0x14000f484
   14001138e:	mov    rdx,rsi
   140011391:	lea    rcx,[rbp+0x8]
   140011395:	call   0x14000f400
   14001139a:	mov    r10,rax
   14001139d:	mov    rcx,rdi
   1400113a0:	call   0x1400038ec
   1400113a5:	mov    edx,eax
   1400113a7:	lea    rcx,[rsp+0x48]
   1400113ac:	call   0x14000ee98
   1400113b1:	mov    DWORD PTR [rsp+0x28],edx
   1400113b5:	mov    QWORD PTR [rsp+0x20],rax
   1400113ba:	lea    r9,[rip+0xc0ff]        # 0x14001d4c0
   1400113c1:	mov    r8d,r14d
   1400113c4:	mov    rdx,r10
   1400113c7:	mov    rcx,rdi
   1400113ca:	call   0x1400106b0
   1400113cf:	int3
   1400113d0:	lea    rcx,[rsp+0x48]
   1400113d5:	call   0x14000ee98
   1400113da:	mov    rbx,rax
   1400113dd:	mov    r8,rax
   1400113e0:	lea    rdx,[rbp+0x8]
   1400113e4:	mov    rcx,rsi
   1400113e7:	call   0x14000f744
   1400113ec:	mov    r8,rax
   1400113ef:	mov    edx,0x3011
   1400113f4:	mov    rcx,rdi
   1400113f7:	call   0x140011870
   1400113fc:	mov    rdx,rsi
   1400113ff:	lea    rcx,[rbp+0x8]
   140011403:	call   0x14000f400
   140011408:	mov    QWORD PTR [rsp+0x20],rbx
   14001140d:	lea    r9,[rip+0xbfdc]        # 0x14001d3f0
   140011414:	mov    r8d,0x80042308
   14001141a:	mov    rdx,rax
   14001141d:	mov    rcx,rdi
   140011420:	call   0x1400106b0
   140011425:	int3
   140011426:	mov    rdx,rsi
   140011429:	lea    rcx,[rbp+0x8]
   14001142d:	call   0x14000f400
   140011432:	mov    rdx,rax
   140011435:	lea    rcx,[rsp+0x48]
   14001143a:	call   0x14000ee98
   14001143f:	mov    QWORD PTR [rsp+0x20],rax
   140011444:	lea    r9,[rip+0xbf65]        # 0x14001d3b0
   14001144b:	mov    r8d,0x8007000e
   140011451:	mov    rcx,rdi
   140011454:	call   0x1400106b0
   140011459:	int3
   14001145a:	int3
   14001145b:	int3
   14001145c:	int3
   14001145d:	int3
   14001145e:	int3
   14001145f:	int3
   140011460:	rex push rbp
   140011462:	push   rbx
   140011463:	push   rsi
   140011464:	push   rdi
   140011465:	push   r12
   140011467:	push   r13
   140011469:	push   r14
   14001146b:	push   r15
   14001146d:	lea    rbp,[rsp-0x148]
   140011475:	sub    rsp,0x248
   14001147c:	mov    r12,QWORD PTR [rbp+0x1b8]
   140011483:	mov    r15,r9
   140011486:	mov    r13,QWORD PTR [rbp+0x1c0]
   14001148d:	mov    r14,r8
   140011490:	mov    rsi,rdx
   140011493:	mov    rdi,rcx
   140011496:	mov    ebx,0x3e8
   14001149b:	xor    edx,edx
   14001149d:	mov    QWORD PTR [rsp+0x20],r13
   1400114a2:	mov    r9,r12
   1400114a5:	mov    rcx,r14
   1400114a8:	lea    r8d,[rdx+0x17]
   1400114ac:	rex.W call QWORD PTR [rip+0x6bd5]        # 0x140018088
   1400114b3:	nop    DWORD PTR [rax+rax*1+0x0]
   1400114b8:	mov    DWORD PTR [rdi+0x8],eax
   1400114bb:	cmp    eax,0x80080005
   1400114c0:	je     0x1400114d0
   1400114c2:	cmp    eax,0x8007000e
   1400114c7:	je     0x1400114d0
   1400114c9:	cmp    eax,0x8007041d
   1400114ce:	jne    0x1400114ec
   1400114d0:	mov    ecx,ebx
   1400114d2:	rex.W call QWORD PTR [rip+0x6a57]        # 0x140017f30
   1400114d9:	nop    DWORD PTR [rax+rax*1+0x0]
   1400114de:	add    ebx,0x7d0
   1400114e4:	cmp    ebx,0x5208
   1400114ea:	jl     0x14001149b
   1400114ec:	mov    ebx,DWORD PTR [rdi+0x8]
   1400114ef:	cmp    ebx,0x80004002
   1400114f5:	je     0x14001166d
   1400114fb:	cmp    ebx,0x80040154
   140011501:	je     0x14001166d
   140011507:	cmp    ebx,0x8007000e
   14001150d:	je     0x140011629
   140011513:	cmp    ebx,0x8007041d
   140011519:	je     0x140011629
   14001151f:	cmp    ebx,0x8007043c
   140011525:	je     0x1400115e2
   14001152b:	cmp    ebx,0x80080005
   140011531:	je     0x14001159b
   140011533:	test   ebx,ebx
   140011535:	je     0x1400116cd
   14001153b:	movaps xmm0,XMMWORD PTR [r14]
   14001153f:	lea    r8,[rsp+0x30]
   140011544:	lea    rdx,[rbp-0x18]
   140011548:	movdqa XMMWORD PTR [rsp+0x30],xmm0
   14001154e:	mov    rcx,rsi
   140011551:	call   0x14000f61c
   140011556:	mov    rcx,rax
   140011559:	lea    rdx,[rsp+0x40]
   14001155e:	mov    r8,r15
   140011561:	call   0x14000f744
   140011566:	mov    rcx,rax
   140011569:	lea    rdx,[rbp+0x90]
   140011570:	mov    r8d,ebx
   140011573:	call   0x14000f4d4
   140011578:	mov    r8,rax
   14001157b:	mov    edx,0xd
   140011580:	mov    rcx,rdi
   140011583:	call   0x140011870
   140011588:	lea    rcx,[rsp+0x40]
   14001158d:	call   0x14000f484
   140011592:	lea    rcx,[rbp-0x18]
   140011596:	jmp    0x1400116c8
   14001159b:	movaps xmm0,XMMWORD PTR [r14]
   14001159f:	lea    r8,[rsp+0x30]
   1400115a4:	lea    rdx,[rsp+0x40]
   1400115a9:	movdqa XMMWORD PTR [rsp+0x30],xmm0
   1400115af:	mov    rcx,rsi
   1400115b2:	call   0x14000f61c
   1400115b7:	mov    rcx,rax
   1400115ba:	lea    rdx,[rbp-0x18]
   1400115be:	mov    r8,r15
   1400115c1:	call   0x14000f744
   1400115c6:	mov    rcx,rax
   1400115c9:	lea    rdx,[rbp+0x90]
   1400115d0:	mov    r8d,ebx
   1400115d3:	call   0x14000f4d4
   1400115d8:	mov    edx,0xb
   1400115dd:	jmp    0x1400116af
   1400115e2:	movaps xmm0,XMMWORD PTR [r14]
   1400115e6:	lea    r8,[rsp+0x30]
   1400115eb:	lea    rdx,[rsp+0x40]
   1400115f0:	movdqa XMMWORD PTR [rsp+0x30],xmm0
   1400115f6:	mov    rcx,rsi
   1400115f9:	call   0x14000f61c
   1400115fe:	mov    rcx,rax
   140011601:	lea    rdx,[rbp-0x18]
   140011605:	mov    r8,r15
   140011608:	call   0x14000f744
   14001160d:	mov    rcx,rax
   140011610:	lea    rdx,[rbp+0x90]
   140011617:	mov    r8d,ebx
   14001161a:	call   0x14000f4d4
   14001161f:	mov    edx,0x12
   140011624:	jmp    0x1400116af
   140011629:	movaps xmm0,XMMWORD PTR [r14]
   14001162d:	lea    r8,[rsp+0x30]
   140011632:	lea    rdx,[rsp+0x40]
   140011637:	movdqa XMMWORD PTR [rsp+0x30],xmm0
   14001163d:	mov    rcx,rsi
   140011640:	call   0x14000f61c
   140011645:	mov    rcx,rax
   140011648:	lea    rdx,[rbp-0x18]
   14001164c:	mov    r8,r15
   14001164f:	call   0x14000f744
   140011654:	mov    rcx,rax
   140011657:	lea    rdx,[rbp+0x90]
   14001165e:	mov    r8d,ebx
   140011661:	call   0x14000f4d4
   140011666:	mov    edx,0xd
   14001166b:	jmp    0x1400116af
   14001166d:	movaps xmm0,XMMWORD PTR [r14]
   140011671:	lea    r8,[rsp+0x30]
   140011676:	lea    rdx,[rsp+0x40]
   14001167b:	movdqa XMMWORD PTR [rsp+0x30],xmm0
   140011681:	mov    rcx,rsi
   140011684:	call   0x14000f61c
   140011689:	mov    rcx,rax
   14001168c:	lea    rdx,[rbp-0x18]
   140011690:	mov    r8,r15
   140011693:	call   0x14000f744
   140011698:	mov    rcx,rax
   14001169b:	lea    rdx,[rbp+0x90]
   1400116a2:	mov    r8d,ebx
   1400116a5:	call   0x14000f4d4
   1400116aa:	mov    edx,0x16
   1400116af:	mov    r8,rax
   1400116b2:	mov    rcx,rdi
   1400116b5:	call   0x140011870
   1400116ba:	lea    rcx,[rbp-0x18]
   1400116be:	call   0x14000f484
   1400116c3:	lea    rcx,[rsp+0x40]
   1400116c8:	call   0x14000f484
   1400116cd:	mov    rcx,rsi
   1400116d0:	call   0x14000f484
   1400116d5:	add    rsp,0x248
   1400116dc:	pop    r15
   1400116de:	pop    r14
   1400116e0:	pop    r13
   1400116e2:	pop    r12
   1400116e4:	pop    rdi
   1400116e5:	pop    rsi
   1400116e6:	pop    rbx
   1400116e7:	pop    rbp
   1400116e8:	ret
   1400116e9:	int3
   1400116ea:	int3
   1400116eb:	int3
   1400116ec:	int3
   1400116ed:	int3
   1400116ee:	int3
   1400116ef:	int3
   1400116f0:	mov    QWORD PTR [rsp+0x10],rdx
   1400116f5:	push   rbp
   1400116f6:	push   rbx
   1400116f7:	push   rdi
   1400116f8:	lea    rbp,[rsp-0x150]
   140011700:	sub    rsp,0x250
   140011707:	mov    QWORD PTR [rsp+0x30],0xfffffffffffffffe
   140011710:	mov    rdi,rdx
   140011713:	mov    rbx,rcx
   140011716:	and    QWORD PTR [rbp+0x170],0x0
   14001171e:	lea    rax,[rbp+0x170]
   140011725:	mov    QWORD PTR [rsp+0x20],rax
   14001172a:	lea    r9,[rip+0xc277]        # 0x14001d9a8
   140011731:	xor    edx,edx
   140011733:	lea    r8d,[rdx+0x1]
   140011737:	lea    rcx,[rip+0x6c82]        # 0x1400183c0
   14001173e:	rex.W call QWORD PTR [rip+0x6943]        # 0x140018088
   140011745:	nop    DWORD PTR [rax+rax*1+0x0]
   14001174a:	mov    DWORD PTR [rbx+0x8],eax
   14001174d:	test   eax,eax
   14001174f:	js     0x1400117ca
   140011751:	mov    rcx,QWORD PTR [rbp+0x170]
   140011758:	mov    rax,QWORD PTR [rcx]
   14001175b:	mov    edx,0x1
   140011760:	mov    r8d,edx
   140011763:	mov    rax,QWORD PTR [rax+0x18]
   140011767:	call   QWORD PTR [rip+0x6b2b]        # 0x140018298
   14001176d:	mov    DWORD PTR [rbx+0x8],eax
   140011770:	test   eax,eax
   140011772:	js     0x1400117a2
   140011774:	mov    rcx,QWORD PTR [rbp+0x170]
   14001177b:	test   rcx,rcx
   14001177e:	je     0x14001178e
   140011780:	mov    rax,QWORD PTR [rcx]
   140011783:	mov    rax,QWORD PTR [rax+0x10]
   140011787:	call   QWORD PTR [rip+0x6b0b]        # 0x140018298
   14001178d:	nop
   14001178e:	mov    rcx,rdi
   140011791:	call   0x14000f484
   140011796:	add    rsp,0x250
   14001179d:	pop    rdi
   14001179e:	pop    rbx
   14001179f:	pop    rbp
   1400117a0:	ret
   1400117a1:	int3
   1400117a2:	mov    rdx,rdi
   1400117a5:	lea    rcx,[rsp+0x50]
   1400117aa:	call   0x14000f400
   1400117af:	mov    rdx,rax
   1400117b2:	mov    rcx,rbx
   1400117b5:	call   0x1400038ec
   1400117ba:	mov    r8d,eax
   1400117bd:	lea    r9,[rip+0xbe1c]        # 0x14001d5e0
   1400117c4:	call   0x140010ee4
   1400117c9:	int3
   1400117ca:	movups xmm0,XMMWORD PTR [rip+0x6bef]        # 0x1400183c0
   1400117d1:	movdqu XMMWORD PTR [rsp+0x40],xmm0
   1400117d7:	lea    r8,[rsp+0x40]
   1400117dc:	lea    rdx,[rsp+0x50]
   1400117e1:	mov    rcx,rdi
   1400117e4:	call   0x14000f61c
   1400117e9:	lea    r8,[rip+0xbd58]        # 0x14001d548
   1400117f0:	lea    rdx,[rbp+0xa0]
   1400117f7:	mov    rcx,rax
   1400117fa:	call   0x14000f744
   1400117ff:	mov    r9,rax
   140011802:	mov    rcx,rbx
   140011805:	call   0x1400038ec
   14001180a:	mov    r8d,eax
   14001180d:	lea    rdx,[rbp-0x8]
   140011811:	mov    rcx,r9
   140011814:	call   0x14000f4d4
   140011819:	mov    r8,rax
   14001181c:	mov    edx,0xd
   140011821:	mov    rcx,rbx
   140011824:	call   0x140011870
   140011829:	lea    rcx,[rbp+0xa0]
   140011830:	call   0x14000f484
   140011835:	lea    rcx,[rsp+0x50]
   14001183a:	call   0x14000f484
   14001183f:	mov    rdx,rdi
   140011842:	lea    rcx,[rsp+0x50]
   140011847:	call   0x14000f400
   14001184c:	mov    rdx,rax
   14001184f:	mov    rcx,rbx
   140011852:	call   0x1400038ec
   140011857:	mov    r8d,eax
   14001185a:	lea    r9,[rip+0xbd0f]        # 0x14001d570
   140011861:	call   0x1400106b0
   140011866:	int3
   140011867:	int3
   140011868:	int3
   140011869:	int3
   14001186a:	int3
   14001186b:	int3
   14001186c:	int3
   14001186d:	int3
   14001186e:	int3
   14001186f:	int3
   140011870:	rex push rbx
   140011872:	push   rsi
   140011873:	push   rdi
   140011874:	push   r12
   140011876:	push   r13
   140011878:	push   r14
   14001187a:	push   r15
   14001187c:	mov    eax,0x1b40
   140011881:	call   0x1400156d0
   140011886:	sub    rsp,rax
   140011889:	mov    QWORD PTR [rsp+0x1b0],0xfffffffffffffffe
   140011895:	mov    rax,QWORD PTR [rip+0x1287c]        # 0x140024118
   14001189c:	xor    rax,rsp
   14001189f:	mov    QWORD PTR [rsp+0x1b30],rax
   1400118a7:	mov    r13,r8
   1400118aa:	mov    DWORD PTR [rsp+0x88],edx
   1400118b1:	mov    rdi,rcx
   1400118b4:	mov    QWORD PTR [rsp+0x70],rcx
   1400118b9:	mov    QWORD PTR [rsp+0x80],r8
   1400118c1:	lea    rax,[rip+0xb298]        # 0x14001cb60
   1400118c8:	mov    QWORD PTR [rsp+0x270],rax
   1400118d0:	lea    rax,[rip+0xbd99]        # 0x14001d670
   1400118d7:	mov    QWORD PTR [rsp+0x278],rax
   1400118df:	lea    rax,[rip+0xb262]        # 0x14001cb48
   1400118e6:	mov    QWORD PTR [rsp+0x280],rax
   1400118ee:	mov    DWORD PTR [rsp+0x288],0x8c1
   1400118f9:	mov    DWORD PTR [rsp+0x28c],0xb
   140011904:	mov    DWORD PTR [rsp+0x290],0xff
   14001190f:	xor    esi,esi
   140011911:	mov    DWORD PTR [rsp+0x310],0x1000000
   14001191c:	lea    ebx,[rsi+0x1]
   14001191f:	xor    edx,edx
   140011921:	lea    r8d,[rsi+0x78]
   140011925:	lea    rcx,[rsp+0x298]
   14001192d:	call   0x140015692
   140011932:	lea    rdx,[rsp+0x270]
   14001193a:	lea    rcx,[rsp+0x140]
   140011942:	call   0x14000f85c
   140011947:	nop
   140011948:	xor    edx,edx
   14001194a:	lea    r8d,[rbx+0x7f]
   14001194e:	lea    rcx,[rsp+0x270]
   140011956:	call   0x140015692
   14001195b:	xor    edx,edx
   14001195d:	mov    r8d,0x1001
   140011963:	lea    rcx,[rsp+0xb20]
   14001196b:	call   0x140015692
   140011970:	movzx  eax,WORD PTR [r13+0xa0]
   140011978:	add    eax,ebx
   14001197a:	cmp    eax,0xf
   14001197d:	jb     0x14001199a
   14001197f:	lea    rcx,[rsp+0x140]
   140011987:	call   0x14000f958
   14001198c:	nop
   14001198d:	mov    rcx,r13
   140011990:	call   0x14000f484
   140011995:	jmp    0x140011d44
   14001199a:	xor    edx,edx
   14001199c:	mov    r8d,0x800
   1400119a2:	lea    rcx,[rsp+0x320]
   1400119aa:	call   0x140015692
   1400119af:	lea    rdx,[rsp+0x320]
   1400119b7:	call   0x140010318
   1400119bc:	lea    rcx,[rsp+0x320]
   1400119c4:	or     r12,0xffffffffffffffff
   1400119c8:	mov    rax,r12
   1400119cb:	inc    rax
   1400119ce:	cmp    WORD PTR [rcx+rax*2],si
   1400119d2:	jne    0x1400119cb
   1400119d4:	add    eax,0x7
   1400119d7:	cdq
   1400119d8:	and    edx,0x7
   1400119db:	add    eax,edx
   1400119dd:	and    eax,0xfffffff8
   1400119e0:	mov    DWORD PTR [rsp+0x78],eax
   1400119e4:	rex.W call QWORD PTR [rip+0x657d]        # 0x140017f68
   1400119eb:	nop    DWORD PTR [rax+rax*1+0x0]
   1400119f0:	mov    rbx,r12
   1400119f3:	inc    rbx
   1400119f6:	cmp    WORD PTR [rax+rbx*2],si
   1400119fa:	jne    0x1400119f3
   1400119fc:	mov    r14d,DWORD PTR [rdi+0x20]
   140011a00:	mov    r15,QWORD PTR [rdi+0x18]
   140011a04:	rex.W call QWORD PTR [rip+0x655d]        # 0x140017f68
   140011a0b:	nop    DWORD PTR [rax+rax*1+0x0]
   140011a10:	mov    rsi,rax
   140011a13:	lea    eax,[rbx+0x7]
   140011a16:	cdq
   140011a17:	and    edx,0x7
   140011a1a:	lea    edi,[rdx+rax*1]
   140011a1d:	and    edi,0xfffffff8
   140011a20:	rex.W call QWORD PTR [rip+0x66a9]        # 0x1400180d0
   140011a27:	nop    DWORD PTR [rax+rax*1+0x0]
   140011a2c:	mov    ebx,eax
   140011a2e:	rex.W call QWORD PTR [rip+0x6693]        # 0x1400180c8
   140011a35:	nop    DWORD PTR [rax+rax*1+0x0]
   140011a3a:	lea    rcx,[rsp+0x320]
   140011a42:	mov    QWORD PTR [rsp+0x60],rcx
   140011a47:	mov    ecx,DWORD PTR [rsp+0x78]
   140011a4b:	mov    DWORD PTR [rsp+0x58],ecx
   140011a4f:	mov    QWORD PTR [rsp+0x50],rsi
   140011a54:	mov    DWORD PTR [rsp+0x48],edi
   140011a58:	mov    DWORD PTR [rsp+0x40],ebx
   140011a5c:	mov    DWORD PTR [rsp+0x38],eax
   140011a60:	mov    DWORD PTR [rsp+0x30],r14d
   140011a65:	mov    QWORD PTR [rsp+0x28],r15
   140011a6a:	mov    eax,DWORD PTR [r13+0x18]
   140011a6e:	mov    DWORD PTR [rsp+0x20],eax
   140011a72:	mov    r9,QWORD PTR [r13+0x10]
   140011a76:	lea    r8,[rip+0xbc33]        # 0x14001d6b0
   140011a7d:	mov    edx,0x1000
   140011a82:	lea    rcx,[rsp+0xb20]
   140011a8a:	call   0x14000ec10
   140011a8f:	lea    rax,[rsp+0xb20]
   140011a97:	xor    edi,edi
   140011a99:	inc    r12
   140011a9c:	cmp    BYTE PTR [rax+r12*1],dil
   140011aa0:	jne    0x140011a99
   140011aa2:	movzx  ebx,WORD PTR [r13+0xa0]
   140011aaa:	mov    esi,0x1
   140011aaf:	add    esi,ebx
   140011ab1:	movzx  r14d,di
   140011ab5:	cmp    di,bx
   140011ab8:	jae    0x140011ad6
   140011aba:	lea    rdx,[r13+0x28]
   140011abe:	mov    r8d,ebx
   140011ac1:	shl    r8,0x3
   140011ac5:	lea    rcx,[rsp+0x270]
   140011acd:	call   0x140015686
   140011ad2:	movzx  r14d,bx
   140011ad6:	mov    QWORD PTR [rsp+0x78],rdi
   140011adb:	mov    r15,QWORD PTR [rsp+0x70]
   140011ae0:	mov    rcx,r15
   140011ae3:	call   0x1400100cc
   140011ae8:	mov    rbx,rax
   140011aeb:	mov    QWORD PTR [rsp+0x78],rax
   140011af0:	lea    rdi,[rip+0xa219]        # 0x14001bd10
   140011af7:	test   rax,rax
   140011afa:	cmovne rdi,rax
   140011afe:	movzx  eax,r14w
   140011b02:	mov    QWORD PTR [rsp+rax*8+0x270],rdi
   140011b0a:	lea    rax,[rip+0xb04f]        # 0x14001cb60
   140011b11:	mov    QWORD PTR [rsp+0x90],rax
   140011b19:	lea    rax,[rip+0xbb50]        # 0x14001d670
   140011b20:	mov    QWORD PTR [rsp+0x98],rax
   140011b28:	lea    rax,[rip+0xb019]        # 0x14001cb48
   140011b2f:	mov    QWORD PTR [rsp+0xa0],rax
   140011b37:	mov    DWORD PTR [rsp+0xa8],0x902
   140011b42:	mov    DWORD PTR [rsp+0xac],0xb
   140011b4d:	xor    r14d,r14d
   140011b50:	mov    DWORD PTR [rsp+0x130],0x1000000
   140011b5b:	xor    edx,edx
   140011b5d:	lea    r8d,[r14+0x78]
   140011b61:	lea    rcx,[rsp+0xb8]
   140011b69:	call   0x140015692
   140011b6e:	lea    r10d,[r14+0x64]
   140011b72:	mov    DWORD PTR [rsp+0xb0],r10d
   140011b7a:	lea    rdx,[rsp+0x90]
   140011b82:	lea    rcx,[rsp+0x1c8]
   140011b8a:	call   0x14000f400
   140011b8f:	mov    r9d,r10d
   140011b92:	cmp    DWORD PTR [r13+0x20],0xff
   140011b9a:	cmovne r9d,DWORD PTR [r13+0x20]
   140011b9f:	mov    QWORD PTR [rsp+0x28],rdi
   140011ba4:	lea    rax,[rip+0xbb5d]        # 0x14001d708
   140011bab:	mov    QWORD PTR [rsp+0x20],rax
   140011bb0:	lea    r8,[rip+0xb389]        # 0x14001cf40
   140011bb7:	lea    rdx,[rsp+0x1c8]
   140011bbf:	mov    rcx,r15
   140011bc2:	call   0x14000ff98
   140011bc7:	lea    rcx,[rsp+0x90]
   140011bcf:	call   0x14000f484
   140011bd4:	lea    rdx,[rip+0xbdfd]        # 0x14001d9d8
   140011bdb:	xor    ecx,ecx
   140011bdd:	rex.W call QWORD PTR [rip+0x621c]        # 0x140017e00
   140011be4:	nop    DWORD PTR [rax+rax*1+0x0]
   140011be9:	mov    rdi,rax
   140011bec:	test   rax,rax
   140011bef:	je     0x140011d6c
   140011bf5:	xor    r8d,r8d
   140011bf8:	lea    edx,[r8+0x1]
   140011bfc:	lea    rax,[rsp+0xb20]
   140011c04:	mov    QWORD PTR [rsp+0x40],rax
   140011c09:	lea    rax,[rsp+0x270]
   140011c11:	mov    QWORD PTR [rsp+0x38],rax
   140011c16:	mov    DWORD PTR [rsp+0x30],r12d
   140011c1b:	mov    WORD PTR [rsp+0x28],si
   140011c20:	mov    QWORD PTR [rsp+0x20],r14
   140011c25:	mov    r9d,DWORD PTR [rsp+0x88]
   140011c2d:	mov    rcx,rdi
   140011c30:	rex.W call QWORD PTR [rip+0x61d1]        # 0x140017e08
   140011c37:	nop    DWORD PTR [rax+rax*1+0x0]
   140011c3c:	lea    rsi,[rip+0xaf1d]        # 0x14001cb60
   140011c43:	lea    r12,[rip+0xba26]        # 0x14001d670
   140011c4a:	test   eax,eax
   140011c4c:	jne    0x140011cfd
   140011c52:	mov    QWORD PTR [rsp+0x90],rsi
   140011c5a:	mov    QWORD PTR [rsp+0x98],r12
   140011c62:	lea    rax,[rip+0xaedf]        # 0x14001cb48
   140011c69:	mov    QWORD PTR [rsp+0xa0],rax
   140011c71:	mov    DWORD PTR [rsp+0xa8],0x923
   140011c7c:	mov    DWORD PTR [rsp+0xac],0xb
   140011c87:	mov    DWORD PTR [rsp+0x130],0x1000000
   140011c92:	xor    edx,edx
   140011c94:	lea    r8d,[rdx+0x78]
   140011c98:	lea    rcx,[rsp+0xb8]
   140011ca0:	call   0x140015692
   140011ca5:	mov    DWORD PTR [rsp+0xb0],0x64
   140011cb0:	lea    rdx,[rsp+0x90]
   140011cb8:	lea    rcx,[rsp+0x1c8]
   140011cc0:	call   0x14000f400
   140011cc5:	rex.W call QWORD PTR [rip+0x62ac]        # 0x140017f78
   140011ccc:	nop    DWORD PTR [rax+rax*1+0x0]
   140011cd1:	mov    r9d,eax
   140011cd4:	lea    r8,[rip+0xbab5]        # 0x14001d790
   140011cdb:	lea    rdx,[rsp+0x1c8]
   140011ce3:	lea    rcx,[rsp+0x140]
   140011ceb:	call   0x140010510
   140011cf0:	lea    rcx,[rsp+0x90]
   140011cf8:	call   0x14000f484
   140011cfd:	mov    rcx,rdi
   140011d00:	rex.W call QWORD PTR [rip+0x60e1]        # 0x140017de8
   140011d07:	nop    DWORD PTR [rax+rax*1+0x0]
   140011d0c:	test   eax,eax
   140011d0e:	je     0x140011de9
   140011d14:	mov    rcx,rbx
   140011d17:	rex.W call QWORD PTR [rip+0x6362]        # 0x140018080
   140011d1e:	nop    DWORD PTR [rax+rax*1+0x0]
   140011d23:	nop
   140011d24:	jmp    0x140011d2e
   140011d26:	mov    r13,QWORD PTR [rsp+0x80]
   140011d2e:	lea    rcx,[rsp+0x140]
   140011d36:	call   0x14000f958
   140011d3b:	nop
   140011d3c:	mov    rcx,r13
   140011d3f:	call   0x14000f484
   140011d44:	mov    rcx,QWORD PTR [rsp+0x1b30]
   140011d4c:	xor    rcx,rsp
   140011d4f:	call   0x1400143c0
   140011d54:	add    rsp,0x1b40
   140011d5b:	pop    r15
   140011d5d:	pop    r14
   140011d5f:	pop    r13
   140011d61:	pop    r12
   140011d63:	pop    rdi
   140011d64:	pop    rsi
   140011d65:	pop    rbx
   140011d66:	ret
   140011d67:	int3
   140011d68:	jmp    0x140011d26
   140011d6a:	jmp    0x140011d26
   140011d6c:	mov    DWORD PTR [rsp+0x28],0xb
   140011d74:	mov    DWORD PTR [rsp+0x20],0x912
   140011d7c:	lea    r9,[rip+0xb8ed]        # 0x14001d670
   140011d83:	lea    r8,[rip+0xadbe]        # 0x14001cb48
   140011d8a:	lea    rdx,[rip+0xadcf]        # 0x14001cb60
   140011d91:	lea    rcx,[rsp+0x90]
   140011d99:	call   0x14000f3ac
   140011d9e:	lea    rdx,[rsp+0x1c8]
   140011da6:	mov    rcx,rax
   140011da9:	call   0x14000f81c
   140011dae:	mov    rbx,rax
   140011db1:	rex.W call QWORD PTR [rip+0x61c0]        # 0x140017f78
   140011db8:	nop    DWORD PTR [rax+rax*1+0x0]
   140011dbd:	mov    r9d,eax
   140011dc0:	lea    r8,[rip+0xb979]        # 0x14001d740
   140011dc7:	mov    rdx,rbx
   140011dca:	lea    rcx,[rsp+0x140]
   140011dd2:	call   0x140010510
   140011dd7:	lea    rcx,[rsp+0x90]
   140011ddf:	call   0x14000f484
   140011de4:	call   0x14000f170
   140011de9:	mov    DWORD PTR [rsp+0x28],0xb
   140011df1:	mov    DWORD PTR [rsp+0x20],0x92a
   140011df9:	mov    r9,r12
   140011dfc:	lea    r8,[rip+0xad45]        # 0x14001cb48
   140011e03:	mov    rdx,rsi
   140011e06:	lea    rcx,[rsp+0x90]
   140011e0e:	call   0x14000f3ac
   140011e13:	lea    rdx,[rsp+0x1c8]
   140011e1b:	mov    rcx,rax
   140011e1e:	call   0x14000f81c
   140011e23:	mov    rbx,rax
   140011e26:	rex.W call QWORD PTR [rip+0x614b]        # 0x140017f78
   140011e2d:	nop    DWORD PTR [rax+rax*1+0x0]
   140011e32:	mov    r9d,eax
   140011e35:	lea    r8,[rip+0xb994]        # 0x14001d7d0
   140011e3c:	mov    rdx,rbx
   140011e3f:	lea    rcx,[rsp+0x140]
   140011e47:	call   0x140010510
   140011e4c:	lea    rcx,[rsp+0x90]
   140011e54:	call   0x14000f484
   140011e59:	call   0x14000f170
   140011e5e:	int3
   140011e5f:	int3
   140011e60:	int3
   140011e61:	int3
   140011e62:	int3
   140011e63:	int3
   140011e64:	int3
   140011e65:	int3
   140011e66:	int3
   140011e67:	int3
   140011e68:	mov    r11,rsp
   140011e6b:	mov    QWORD PTR [r11+0x8],rbx
   140011e6f:	push   rdi
   140011e70:	sub    rsp,0xd0
   140011e77:	mov    rax,QWORD PTR [rsp+0x100]
   140011e7f:	mov    ebx,edx
   140011e81:	mov    QWORD PTR [rsp+0x28],rax
   140011e86:	mov    rdi,rcx
   140011e89:	mov    eax,DWORD PTR [rsp+0x108]
   140011e90:	mov    DWORD PTR [rcx+0x8],edx
   140011e93:	xor    edx,edx
   140011e95:	mov    DWORD PTR [rsp+0x38],eax
   140011e99:	lea    rcx,[rsp+0x48]
   140011e9e:	mov    eax,DWORD PTR [rsp+0x110]
   140011ea5:	mov    QWORD PTR [rsp+0x20],r8
   140011eaa:	mov    DWORD PTR [rsp+0x3c],eax
   140011eae:	lea    r8d,[rdx+0x78]
   140011eb2:	mov    QWORD PTR [rsp+0x30],r9
   140011eb7:	mov    DWORD PTR [rsp+0x40],0xff
   140011ebf:	mov    DWORD PTR [r11-0x18],0x1000000
   140011ec7:	call   0x140015692
   140011ecc:	mov    r9d,ebx
   140011ecf:	lea    r8,[rip+0xb94a]        # 0x14001d820
   140011ed6:	lea    rdx,[rsp+0x20]
   140011edb:	mov    rcx,rdi
   140011ede:	call   0x140010510
   140011ee3:	mov    rbx,QWORD PTR [rsp+0xe0]
   140011eeb:	add    rsp,0xd0
   140011ef2:	pop    rdi
   140011ef3:	ret
   140011ef4:	int3
   140011ef5:	int3
   140011ef6:	int3
   140011ef7:	int3
   140011ef8:	int3
   140011ef9:	int3
   140011efa:	int3
   140011efb:	int3
   140011efc:	mov    rax,rsp
   140011eff:	mov    QWORD PTR [rax+0x8],rbx
   140011f03:	mov    QWORD PTR [rax+0x10],rsi
   140011f07:	mov    QWORD PTR [rax+0x18],rdi
   140011f0b:	push   rbp
   140011f0c:	push   r12
   140011f0e:	push   r13
   140011f10:	push   r14
   140011f12:	push   r15
   140011f14:	lea    rbp,[rax-0x47]
   140011f18:	sub    rsp,0xd0
   140011f1f:	mov    ebx,DWORD PTR [rdx+0x8]
   140011f22:	mov    r15,r8
   140011f25:	mov    r14,QWORD PTR [rbp+0x6f]
   140011f29:	xor    edx,edx
   140011f2b:	mov    esi,DWORD PTR [rbp+0x77]
   140011f2e:	mov    r13,rcx
   140011f31:	mov    edi,DWORD PTR [rbp+0x7f]
   140011f34:	mov    r12,r9
   140011f37:	mov    DWORD PTR [rcx+0x8],ebx
   140011f3a:	lea    rcx,[rbp-0x69]
   140011f3e:	mov    QWORD PTR [rsp+0x20],r8
   140011f43:	lea    r8d,[rdx+0x78]
   140011f47:	mov    QWORD PTR [rsp+0x28],r14
   140011f4c:	mov    QWORD PTR [rsp+0x30],r9
   140011f51:	mov    DWORD PTR [rbp-0x79],esi
   140011f54:	mov    DWORD PTR [rbp-0x75],edi
   140011f57:	mov    DWORD PTR [rbp-0x71],0xff
   140011f5e:	mov    DWORD PTR [rbp+0xf],0x1000000
   140011f65:	call   0x140015692
   140011f6a:	mov    r9d,ebx
   140011f6d:	lea    r8,[rip+0xb8fc]        # 0x14001d870
   140011f74:	lea    rdx,[rsp+0x20]
   140011f79:	mov    rcx,r13
   140011f7c:	call   0x140010c44
   140011f81:	xor    edx,edx
   140011f83:	mov    DWORD PTR [r13+0x8],eax
   140011f87:	lea    rcx,[rbp-0x69]
   140011f8b:	mov    QWORD PTR [rsp+0x20],r15
   140011f90:	mov    ebx,eax
   140011f92:	mov    QWORD PTR [rsp+0x28],r14
   140011f97:	mov    QWORD PTR [rsp+0x30],r12
   140011f9c:	lea    r8d,[rdx+0x78]
   140011fa0:	mov    DWORD PTR [rbp-0x79],esi
   140011fa3:	mov    DWORD PTR [rbp-0x75],edi
   140011fa6:	mov    DWORD PTR [rbp-0x71],0xff
   140011fad:	mov    DWORD PTR [rbp+0xf],0x1000000
   140011fb4:	call   0x140015692
   140011fb9:	mov    r9d,ebx
   140011fbc:	lea    r8,[rip+0xb905]        # 0x14001d8c8
   140011fc3:	lea    rdx,[rsp+0x20]
   140011fc8:	mov    rcx,r13
   140011fcb:	call   0x140010510
   140011fd0:	lea    r11,[rsp+0xd0]
   140011fd8:	mov    rbx,QWORD PTR [r11+0x30]
   140011fdc:	mov    rsi,QWORD PTR [r11+0x38]
   140011fe0:	mov    rdi,QWORD PTR [r11+0x40]
   140011fe4:	mov    rsp,r11
   140011fe7:	pop    r15
   140011fe9:	pop    r14
   140011feb:	pop    r13
   140011fed:	pop    r12
   140011fef:	pop    rbp
   140011ff0:	ret
   140011ff1:	int3
   140011ff2:	int3
   140011ff3:	int3
   140011ff4:	int3
   140011ff5:	int3
   140011ff6:	int3
   140011ff7:	int3
   140011ff8:	rex push rbx
   140011ffa:	sub    rsp,0xd0
   140012001:	mov    eax,DWORD PTR [rsp+0x100]
   140012008:	mov    rbx,rcx
   14001200b:	mov    QWORD PTR [rsp+0x20],rdx
   140012010:	xor    edx,edx
   140012012:	mov    DWORD PTR [rcx+0x8],0x8007000e
   140012019:	lea    rcx,[rsp+0x48]
   14001201e:	mov    QWORD PTR [rsp+0x30],r8
   140012023:	mov    DWORD PTR [rsp+0x38],eax
   140012027:	mov    eax,DWORD PTR [rsp+0x108]
   14001202e:	lea    r8d,[rdx+0x78]
   140012032:	mov    QWORD PTR [rsp+0x28],r9
   140012037:	mov    DWORD PTR [rsp+0x3c],eax
   14001203b:	mov    DWORD PTR [rsp+0x40],0xff
   140012043:	mov    DWORD PTR [rsp+0xc0],0x1000000
   14001204e:	call   0x140015692
   140012053:	mov    r9d,0x8007000e
   140012059:	lea    r8,[rip+0xb8a0]        # 0x14001d900
   140012060:	lea    rdx,[rsp+0x20]
   140012065:	mov    rcx,rbx
   140012068:	call   0x140010510
   14001206d:	add    rsp,0xd0
   140012074:	pop    rbx
   140012075:	ret
   140012076:	int3
   140012077:	int3
   140012078:	int3
   140012079:	int3
   14001207a:	int3
   14001207b:	int3
   14001207c:	int3
   14001207d:	int3
   14001207e:	int3
   14001207f:	int3
   140012080:	mov    rax,rsp
   140012083:	mov    QWORD PTR [rax+0x8],rbx
   140012087:	mov    QWORD PTR [rax+0x10],rsi
   14001208b:	mov    QWORD PTR [rax+0x18],rdi
   14001208f:	push   rbp
   140012090:	push   r12
   140012092:	push   r13
   140012094:	push   r14
   140012096:	push   r15
   140012098:	lea    rbp,[rax-0x47]
   14001209c:	sub    rsp,0xe0
   1400120a3:	mov    rsi,QWORD PTR [rbp+0x6f]
   1400120a7:	mov    r12,rdx
   1400120aa:	mov    edi,DWORD PTR [rbp+0x77]
   1400120ad:	xor    edx,edx
   1400120af:	mov    ebx,DWORD PTR [rbp+0x7f]
   1400120b2:	mov    r14,r8
   1400120b5:	mov    r13,rcx
   1400120b8:	mov    QWORD PTR [rsp+0x30],r8
   1400120bd:	lea    rcx,[rbp-0x69]
   1400120c1:	mov    QWORD PTR [rsp+0x38],rsi
   1400120c6:	lea    r8d,[rdx+0x78]
   1400120ca:	mov    QWORD PTR [rsp+0x40],r9
   1400120cf:	mov    r15,r9
   1400120d2:	mov    DWORD PTR [rbp-0x79],edi
   1400120d5:	mov    DWORD PTR [rbp-0x75],ebx
   1400120d8:	mov    DWORD PTR [rbp-0x71],0xff
   1400120df:	mov    DWORD PTR [rbp+0xf],0x1000000
   1400120e6:	call   0x140015692
   1400120eb:	mov    rax,QWORD PTR [r12]
   1400120ef:	mov    rcx,r12
   1400120f2:	mov    rax,QWORD PTR [rax+0x8]
   1400120f6:	call   QWORD PTR [rip+0x619c]        # 0x140018298
   1400120fc:	lea    r9,[rip+0xb85d]        # 0x14001d960
   140012103:	mov    r8d,0x80042302
   140012109:	lea    rdx,[rsp+0x30]
   14001210e:	mov    QWORD PTR [rsp+0x20],rax
   140012113:	mov    rcx,r13
   140012116:	call   0x1400110d8
   14001211b:	xor    edx,edx
   14001211d:	mov    DWORD PTR [r13+0x8],eax
   140012121:	lea    rcx,[rbp-0x69]
   140012125:	mov    QWORD PTR [rsp+0x30],r14
   14001212a:	mov    QWORD PTR [rsp+0x38],rsi
   14001212f:	mov    QWORD PTR [rsp+0x40],r15
   140012134:	lea    r8d,[rdx+0x78]
   140012138:	mov    DWORD PTR [rbp-0x79],edi
   14001213b:	mov    DWORD PTR [rbp-0x75],ebx
   14001213e:	mov    DWORD PTR [rbp-0x71],0xff
   140012145:	mov    DWORD PTR [rbp+0xf],0x1000000
   14001214c:	call   0x140015692
   140012151:	mov    rax,QWORD PTR [r12]
   140012155:	mov    rcx,r12
   140012158:	mov    rax,QWORD PTR [rax+0x8]
   14001215c:	call   QWORD PTR [rip+0x6136]        # 0x140018298
   140012162:	lea    r8,[rip+0xb7f7]        # 0x14001d960
   140012169:	mov    rcx,r13
   14001216c:	mov    r9,rax
   14001216f:	lea    rdx,[rsp+0x30]
   140012174:	call   0x140010510
   140012179:	lea    r11,[rsp+0xe0]
   140012181:	mov    rbx,QWORD PTR [r11+0x30]
   140012185:	mov    rsi,QWORD PTR [r11+0x38]
   140012189:	mov    rdi,QWORD PTR [r11+0x40]
   14001218d:	mov    rsp,r11
   140012190:	pop    r15
   140012192:	pop    r14
   140012194:	pop    r13
   140012196:	pop    r12
   140012198:	pop    rbp
   140012199:	ret
   14001219a:	int3
   14001219b:	int3
   14001219c:	int3
   14001219d:	int3
   14001219e:	int3
   14001219f:	int3
   1400121a0:	int3
   1400121a1:	int3
   1400121a2:	int3
   1400121a3:	int3
   1400121a4:	int3
   1400121a5:	int3
   1400121a6:	int3
   1400121a7:	int3
   1400121a8:	int3
   1400121a9:	int3
   1400121aa:	int3
   1400121ab:	int3
   1400121ac:	int3
   1400121ad:	int3
   1400121ae:	int3
   1400121af:	int3
   1400121b0:	rex push rbx
   1400121b2:	sub    rsp,0x20
   1400121b6:	cmp    QWORD PTR [rcx+0x20],0x8
   1400121bb:	mov    rbx,rcx
   1400121be:	jb     0x1400121c9
   1400121c0:	mov    rcx,QWORD PTR [rcx+0x8]
   1400121c4:	call   0x140014084
   1400121c9:	xor    eax,eax
   1400121cb:	mov    QWORD PTR [rbx+0x20],0x7
   1400121d3:	mov    QWORD PTR [rbx+0x18],rax
   1400121d7:	mov    WORD PTR [rbx+0x8],ax
   1400121db:	add    rsp,0x20
   1400121df:	pop    rbx
   1400121e0:	ret
   1400121e1:	int3
   1400121e2:	int3
   1400121e3:	int3
   1400121e4:	int3
   1400121e5:	int3
   1400121e6:	int3
   1400121e7:	int3
   1400121e8:	mov    QWORD PTR [rsp+0x8],rbx
   1400121ed:	mov    QWORD PTR [rsp+0x10],rbp
   1400121f2:	mov    QWORD PTR [rsp+0x18],rsi
   1400121f7:	push   rdi
   1400121f8:	push   r14
   1400121fa:	push   r15
   1400121fc:	sub    rsp,0x20
   140012200:	xor    ebp,ebp
   140012202:	mov    QWORD PTR [rcx+0x20],0x7
   14001220a:	lea    rbx,[rcx+0x8]
   14001220e:	mov    QWORD PTR [rcx+0x18],rbp
   140012212:	mov    WORD PTR [rbx],bp
   140012215:	mov    rsi,rdx
   140012218:	mov    rdi,rcx
   14001221b:	or     r14,0xffffffffffffffff
   14001221f:	inc    r14
   140012222:	cmp    WORD PTR [rdx+r14*2],bp
   140012227:	jne    0x14001221f
   140012229:	cmp    QWORD PTR [rcx+0x20],0x8
   14001222e:	jb     0x140012235
   140012230:	mov    rax,QWORD PTR [rbx]
   140012233:	jmp    0x140012238
   140012235:	mov    rax,rbx
   140012238:	cmp    rsi,rax
   14001223b:	jb     0x14001227c
   14001223d:	cmp    QWORD PTR [rcx+0x20],0x8
   140012242:	jb     0x140012249
   140012244:	mov    rcx,QWORD PTR [rbx]
   140012247:	jmp    0x14001224c
   140012249:	mov    rcx,rbx
   14001224c:	mov    rax,QWORD PTR [rdi+0x18]
   140012250:	lea    rcx,[rcx+rax*2]
   140012254:	cmp    rcx,rsi
   140012257:	jbe    0x14001227c
   140012259:	cmp    QWORD PTR [rdi+0x20],0x8
   14001225e:	jb     0x140012263
   140012260:	mov    rbx,QWORD PTR [rbx]
   140012263:	sub    rsi,rbx
   140012266:	mov    r9,r14
   140012269:	sar    rsi,1
   14001226c:	mov    rdx,rdi
   14001226f:	mov    r8,rsi
   140012272:	mov    rcx,rdi
   140012275:	call   0x140012390
   14001227a:	jmp    0x1400122c9
   14001227c:	mov    rdx,r14
   14001227f:	mov    rcx,rdi
   140012282:	call   0x140012478
   140012287:	test   al,al
   140012289:	je     0x1400122c9
   14001228b:	mov    rdx,QWORD PTR [rdi+0x20]
   14001228f:	cmp    rdx,0x8
   140012293:	jb     0x14001229a
   140012295:	mov    rcx,QWORD PTR [rbx]
   140012298:	jmp    0x14001229d
   14001229a:	mov    rcx,rbx
   14001229d:	lea    r15,[r14+r14*1]
   1400122a1:	add    rdx,rdx
   1400122a4:	mov    r9,r15
   1400122a7:	mov    r8,rsi
   1400122aa:	rex.W call QWORD PTR [rip+0x5f27]        # 0x1400181d8
   1400122b1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400122b6:	cmp    QWORD PTR [rdi+0x20],0x8
   1400122bb:	mov    QWORD PTR [rdi+0x18],r14
   1400122bf:	jb     0x1400122c4
   1400122c1:	mov    rbx,QWORD PTR [rbx]
   1400122c4:	mov    WORD PTR [r15+rbx*1],bp
   1400122c9:	mov    rbx,QWORD PTR [rsp+0x40]
   1400122ce:	mov    rax,rdi
   1400122d1:	mov    rbp,QWORD PTR [rsp+0x48]
   1400122d6:	mov    rsi,QWORD PTR [rsp+0x50]
   1400122db:	add    rsp,0x20
   1400122df:	pop    r15
   1400122e1:	pop    r14
   1400122e3:	pop    rdi
   1400122e4:	ret
   1400122e5:	int3
   1400122e6:	int3
   1400122e7:	int3
   1400122e8:	int3
   1400122e9:	int3
   1400122ea:	int3
   1400122eb:	int3
   1400122ec:	int3
   1400122ed:	int3
   1400122ee:	int3
   1400122ef:	int3
   1400122f0:	xor    eax,eax
   1400122f2:	mov    QWORD PTR [rcx+0x20],0x7
   1400122fa:	mov    QWORD PTR [rcx+0x18],rax
   1400122fe:	mov    WORD PTR [rcx+0x8],ax
   140012302:	mov    rax,rcx
   140012305:	ret
   140012306:	int3
   140012307:	int3
   140012308:	int3
   140012309:	int3
   14001230a:	int3
   14001230b:	int3
   14001230c:	int3
   14001230d:	int3
   14001230e:	int3
   14001230f:	int3
   140012310:	mov    QWORD PTR [rsp+0x8],rbx
   140012315:	mov    QWORD PTR [rsp+0x10],rbp
   14001231a:	mov    QWORD PTR [rsp+0x18],rsi
   14001231f:	push   rdi
   140012320:	sub    rsp,0x20
   140012324:	xor    ebp,ebp
   140012326:	mov    rdi,r8
   140012329:	mov    rbx,rcx
   14001232c:	test   dl,dl
   14001232e:	je     0x140012361
   140012330:	cmp    QWORD PTR [rcx+0x20],0x8
   140012335:	jb     0x140012361
   140012337:	add    rcx,0x8
   14001233b:	mov    rsi,QWORD PTR [rcx]
   14001233e:	test   r8,r8
   140012341:	je     0x140012359
   140012343:	lea    r9,[r8+r8*1]
   140012347:	mov    r8,rsi
   14001234a:	lea    edx,[rbp+0x10]
   14001234d:	rex.W call QWORD PTR [rip+0x5e84]        # 0x1400181d8
   140012354:	nop    DWORD PTR [rax+rax*1+0x0]
   140012359:	mov    rcx,rsi
   14001235c:	call   0x140014084
   140012361:	mov    rsi,QWORD PTR [rsp+0x40]
   140012366:	mov    QWORD PTR [rbx+0x20],0x7
   14001236e:	mov    QWORD PTR [rbx+0x18],rdi
   140012372:	mov    WORD PTR [rbx+rdi*2+0x8],bp
   140012377:	mov    rbx,QWORD PTR [rsp+0x30]
   14001237c:	mov    rbp,QWORD PTR [rsp+0x38]
   140012381:	add    rsp,0x20
   140012385:	pop    rdi
   140012386:	ret
   140012387:	int3
   140012388:	int3
   140012389:	int3
   14001238a:	int3
   14001238b:	int3
   14001238c:	int3
   14001238d:	int3
   14001238e:	int3
   14001238f:	int3
   140012390:	mov    QWORD PTR [rsp+0x8],rbx
   140012395:	mov    QWORD PTR [rsp+0x10],rbp
   14001239a:	mov    QWORD PTR [rsp+0x18],rsi
   14001239f:	push   rdi
   1400123a0:	push   r14
   1400123a2:	push   r15
   1400123a4:	sub    rsp,0x20
   1400123a8:	mov    rbx,QWORD PTR [rdx+0x18]
   1400123ac:	mov    r14,r9
   1400123af:	mov    rbp,r8
   1400123b2:	mov    rsi,rdx
   1400123b5:	mov    rdi,rcx
   1400123b8:	cmp    rbx,r8
   1400123bb:	jae    0x1400123c6
   1400123bd:	call   0x1400150e0
   1400123c2:	mov    rbx,QWORD PTR [rsi+0x18]
   1400123c6:	sub    rbx,rbp
   1400123c9:	mov    rcx,rdi
   1400123cc:	cmp    r14,rbx
   1400123cf:	cmovb  rbx,r14
   1400123d3:	cmp    rdi,rsi
   1400123d6:	jne    0x1400123f4
   1400123d8:	lea    rdx,[rbx+rbp*1]
   1400123dc:	or     r8,0xffffffffffffffff
   1400123e0:	call   0x1400124f4
   1400123e5:	mov    r8,rbp
   1400123e8:	xor    edx,edx
   1400123ea:	mov    rcx,rdi
   1400123ed:	call   0x1400124f4
   1400123f2:	jmp    0x140012454
   1400123f4:	mov    rdx,rbx
   1400123f7:	call   0x140012478
   1400123fc:	xor    r15d,r15d
   1400123ff:	test   al,al
   140012401:	je     0x140012454
   140012403:	cmp    QWORD PTR [rsi+0x20],0x8
   140012408:	lea    rax,[rsi+0x8]
   14001240c:	jb     0x140012411
   14001240e:	mov    rax,QWORD PTR [rax]
   140012411:	mov    rdx,QWORD PTR [rdi+0x20]
   140012415:	lea    rsi,[rdi+0x8]
   140012419:	cmp    rdx,0x8
   14001241d:	jb     0x140012424
   14001241f:	mov    rcx,QWORD PTR [rsi]
   140012422:	jmp    0x140012427
   140012424:	mov    rcx,rsi
   140012427:	lea    r14,[rbx+rbx*1]
   14001242b:	add    rdx,rdx
   14001242e:	mov    r9,r14
   140012431:	lea    r8,[rax+rbp*2]
   140012435:	rex.W call QWORD PTR [rip+0x5d9c]        # 0x1400181d8
   14001243c:	nop    DWORD PTR [rax+rax*1+0x0]
   140012441:	cmp    QWORD PTR [rdi+0x20],0x8
   140012446:	mov    QWORD PTR [rdi+0x18],rbx
   14001244a:	jb     0x14001244f
   14001244c:	mov    rsi,QWORD PTR [rsi]
   14001244f:	mov    WORD PTR [r14+rsi*1],r15w
   140012454:	mov    rbx,QWORD PTR [rsp+0x40]
   140012459:	mov    rax,rdi
   14001245c:	mov    rbp,QWORD PTR [rsp+0x48]
   140012461:	mov    rsi,QWORD PTR [rsp+0x50]
   140012466:	add    rsp,0x20
   14001246a:	pop    r15
   14001246c:	pop    r14
   14001246e:	pop    rdi
   14001246f:	ret
   140012470:	int3
   140012471:	int3
   140012472:	int3
   140012473:	int3
   140012474:	int3
   140012475:	int3
   140012476:	int3
   140012477:	int3
   140012478:	mov    QWORD PTR [rsp+0x8],rbx
   14001247d:	mov    QWORD PTR [rsp+0x10],rsi
   140012482:	push   rdi
   140012483:	sub    rsp,0x20
   140012487:	movabs rax,0x7ffffffffffffffe
   140012491:	mov    rbx,rdx
   140012494:	mov    rdi,rcx
   140012497:	cmp    rdx,rax
   14001249a:	jbe    0x1400124a1
   14001249c:	call   0x140015084
   1400124a1:	mov    rax,QWORD PTR [rdi+0x20]
   1400124a5:	xor    esi,esi
   1400124a7:	cmp    rax,rbx
   1400124aa:	jae    0x1400124bd
   1400124ac:	mov    r8,QWORD PTR [rdi+0x18]
   1400124b0:	mov    rdx,rbx
   1400124b3:	mov    rcx,rdi
   1400124b6:	call   0x140012694
   1400124bb:	jmp    0x1400124d6
   1400124bd:	test   rbx,rbx
   1400124c0:	jne    0x1400124d9
   1400124c2:	mov    QWORD PTR [rdi+0x18],rsi
   1400124c6:	add    rdi,0x8
   1400124ca:	cmp    rax,0x8
   1400124ce:	jb     0x1400124d3
   1400124d0:	mov    rdi,QWORD PTR [rdi]
   1400124d3:	mov    WORD PTR [rdi],si
   1400124d6:	test   rbx,rbx
   1400124d9:	mov    rbx,QWORD PTR [rsp+0x30]
   1400124de:	setne  al
   1400124e1:	mov    rsi,QWORD PTR [rsp+0x38]
   1400124e6:	add    rsp,0x20
   1400124ea:	pop    rdi
   1400124eb:	ret
   1400124ec:	int3
   1400124ed:	int3
   1400124ee:	int3
   1400124ef:	int3
   1400124f0:	int3
   1400124f1:	int3
   1400124f2:	int3
   1400124f3:	int3
   1400124f4:	mov    rax,rsp
   1400124f7:	mov    QWORD PTR [rax+0x8],rbx
   1400124fb:	mov    QWORD PTR [rax+0x10],rbp
   1400124ff:	mov    QWORD PTR [rax+0x18],rsi
   140012503:	mov    QWORD PTR [rax+0x20],rdi
   140012507:	push   r14
   140012509:	sub    rsp,0x20
   14001250d:	mov    r9,QWORD PTR [rcx+0x18]
   140012511:	mov    rsi,r8
   140012514:	mov    r14,rdx
   140012517:	mov    rdi,rcx
   14001251a:	cmp    r9,rdx
   14001251d:	jae    0x140012528
   14001251f:	call   0x1400150e0
   140012524:	mov    r9,QWORD PTR [rdi+0x18]
   140012528:	sub    r9,r14
   14001252b:	cmp    r9,rsi
   14001252e:	cmovb  rsi,r9
   140012532:	xor    ebp,ebp
   140012534:	test   rsi,rsi
   140012537:	je     0x140012596
   140012539:	mov    rdx,QWORD PTR [rdi+0x20]
   14001253d:	lea    rbx,[rdi+0x8]
   140012541:	cmp    rdx,0x8
   140012545:	jb     0x14001254c
   140012547:	mov    r8,QWORD PTR [rbx]
   14001254a:	jmp    0x14001254f
   14001254c:	mov    r8,rbx
   14001254f:	jb     0x140012556
   140012551:	mov    rcx,QWORD PTR [rbx]
   140012554:	jmp    0x140012559
   140012556:	mov    rcx,rbx
   140012559:	sub    r9,rsi
   14001255c:	lea    rax,[r14+rsi*1]
   140012560:	sub    rdx,r14
   140012563:	lea    r8,[r8+rax*2]
   140012567:	add    r9,r9
   14001256a:	lea    rcx,[rcx+r14*2]
   14001256e:	add    rdx,rdx
   140012571:	rex.W call QWORD PTR [rip+0x5c78]        # 0x1400181f0
   140012578:	nop    DWORD PTR [rax+rax*1+0x0]
   14001257d:	mov    rax,QWORD PTR [rdi+0x18]
   140012581:	sub    rax,rsi
   140012584:	cmp    QWORD PTR [rdi+0x20],0x8
   140012589:	mov    QWORD PTR [rdi+0x18],rax
   14001258d:	jb     0x140012592
   14001258f:	mov    rbx,QWORD PTR [rbx]
   140012592:	mov    WORD PTR [rbx+rax*2],bp
   140012596:	mov    rbx,QWORD PTR [rsp+0x30]
   14001259b:	mov    rax,rdi
   14001259e:	mov    rdi,QWORD PTR [rsp+0x48]
   1400125a3:	mov    rbp,QWORD PTR [rsp+0x38]
   1400125a8:	mov    rsi,QWORD PTR [rsp+0x40]
   1400125ad:	add    rsp,0x20
   1400125b1:	pop    r14
   1400125b3:	ret
   1400125b4:	int3
   1400125b5:	int3
   1400125b6:	int3
   1400125b7:	int3
   1400125b8:	int3
   1400125b9:	int3
   1400125ba:	int3
   1400125bb:	int3
   1400125bc:	mov    rax,rsp
   1400125bf:	mov    QWORD PTR [rax+0x8],rbx
   1400125c3:	mov    QWORD PTR [rax+0x10],rbp
   1400125c7:	mov    QWORD PTR [rax+0x18],rsi
   1400125cb:	mov    QWORD PTR [rax+0x20],rdi
   1400125cf:	push   r14
   1400125d1:	sub    rsp,0x20
   1400125d5:	mov    rax,QWORD PTR [rcx+0x18]
   1400125d9:	or     rsi,0xffffffffffffffff
   1400125dd:	cmp    QWORD PTR [rdx+0x18],rsi
   1400125e1:	not    rax
   1400125e4:	mov    rdi,rdx
   1400125e7:	mov    rbx,rcx
   1400125ea:	cmovb  rsi,QWORD PTR [rdx+0x18]
   1400125ef:	cmp    rax,rsi
   1400125f2:	ja     0x1400125f9
   1400125f4:	call   0x140015084
   1400125f9:	xor    r14d,r14d
   1400125fc:	test   rsi,rsi
   1400125ff:	je     0x14001266c
   140012601:	mov    rbp,QWORD PTR [rbx+0x18]
   140012605:	mov    rcx,rbx
   140012608:	add    rbp,rsi
   14001260b:	mov    rdx,rbp
   14001260e:	call   0x140012478
   140012613:	test   al,al
   140012615:	je     0x14001266c
   140012617:	cmp    QWORD PTR [rdi+0x20],0x8
   14001261c:	lea    r8,[rdi+0x8]
   140012620:	jb     0x140012625
   140012622:	mov    r8,QWORD PTR [r8]
   140012625:	mov    rdx,QWORD PTR [rbx+0x20]
   140012629:	lea    rdi,[rbx+0x8]
   14001262d:	cmp    rdx,0x8
   140012631:	jb     0x140012638
   140012633:	mov    rcx,QWORD PTR [rdi]
   140012636:	jmp    0x14001263b
   140012638:	mov    rcx,rdi
   14001263b:	mov    rax,QWORD PTR [rbx+0x18]
   14001263f:	lea    r9,[rsi+rsi*1]
   140012643:	sub    rdx,rax
   140012646:	add    rdx,rdx
   140012649:	lea    rcx,[rcx+rax*2]
   14001264d:	rex.W call QWORD PTR [rip+0x5b84]        # 0x1400181d8
   140012654:	nop    DWORD PTR [rax+rax*1+0x0]
   140012659:	cmp    QWORD PTR [rbx+0x20],0x8
   14001265e:	mov    QWORD PTR [rbx+0x18],rbp
   140012662:	jb     0x140012667
   140012664:	mov    rdi,QWORD PTR [rdi]
   140012667:	mov    WORD PTR [rdi+rbp*2],r14w
   14001266c:	mov    rbp,QWORD PTR [rsp+0x38]
   140012671:	mov    rax,rbx
   140012674:	mov    rbx,QWORD PTR [rsp+0x30]
   140012679:	mov    rsi,QWORD PTR [rsp+0x40]
   14001267e:	mov    rdi,QWORD PTR [rsp+0x48]
   140012683:	add    rsp,0x20
   140012687:	pop    r14
   140012689:	ret
   14001268a:	int3
   14001268b:	int3
   14001268c:	int3
   14001268d:	int3
   14001268e:	int3
   14001268f:	int3
   140012690:	int3
   140012691:	int3
   140012692:	int3
   140012693:	int3
   140012694:	mov    rax,rsp
   140012697:	mov    QWORD PTR [rax+0x18],r8
   14001269b:	mov    QWORD PTR [rax+0x10],rdx
   14001269f:	mov    QWORD PTR [rax+0x8],rcx
   1400126a3:	push   rbx
   1400126a4:	push   rsi
   1400126a5:	push   rdi
   1400126a6:	push   r14
   1400126a8:	push   r15
   1400126aa:	sub    rsp,0x60
   1400126ae:	mov    QWORD PTR [rax-0x68],0xfffffffffffffffe
   1400126b6:	mov    r14,r8
   1400126b9:	mov    rdi,rcx
   1400126bc:	mov    rbx,rdx
   1400126bf:	or     rbx,0x7
   1400126c3:	movabs r9,0x7ffffffffffffffe
   1400126cd:	cmp    rbx,r9
   1400126d0:	jbe    0x1400126d7
   1400126d2:	mov    rbx,rdx
   1400126d5:	jmp    0x140012702
   1400126d7:	mov    r8,QWORD PTR [rcx+0x20]
   1400126db:	mov    rcx,r8
   1400126de:	shr    rcx,1
   1400126e1:	movabs rax,0xaaaaaaaaaaaaaaab
   1400126eb:	mul    rbx
   1400126ee:	shr    rdx,1
   1400126f1:	cmp    rdx,rcx
   1400126f4:	jae    0x140012702
   1400126f6:	sub    r9,rcx
   1400126f9:	cmp    r8,r9
   1400126fc:	ja     0x140012702
   1400126fe:	lea    rbx,[rcx+r8*1]
   140012702:	lea    rcx,[rbx+0x1]
   140012706:	xor    esi,esi
   140012708:	test   rcx,rcx
   14001270b:	jne    0x14001271c
   14001270d:	mov    ecx,esi
   14001270f:	add    rcx,rcx
   140012712:	call   0x140014038
   140012717:	mov    r15,rax
   14001271a:	jmp    0x140012753
   14001271c:	xor    edx,edx
   14001271e:	or     rax,0xffffffffffffffff
   140012722:	div    rcx
   140012725:	cmp    rax,0x2
   140012729:	jb     0x1400127ba
   14001272f:	jmp    0x14001270f
   140012731:	xor    esi,esi
   140012733:	mov    rdi,QWORD PTR [rsp+0x90]
   14001273b:	mov    r14,QWORD PTR [rsp+0xa0]
   140012743:	mov    rbx,QWORD PTR [rsp+0x98]
   14001274b:	mov    r15,QWORD PTR [rsp+0xa8]
   140012753:	test   r14,r14
   140012756:	je     0x140012781
   140012758:	lea    r8,[rdi+0x8]
   14001275c:	cmp    QWORD PTR [rdi+0x20],0x8
   140012761:	jb     0x140012766
   140012763:	mov    r8,QWORD PTR [r8]
   140012766:	lea    r9,[r14+r14*1]
   14001276a:	lea    rdx,[rbx*2+0x2]
   140012772:	mov    rcx,r15
   140012775:	rex.W call QWORD PTR [rip+0x5a5c]        # 0x1400181d8
   14001277c:	nop    DWORD PTR [rax+rax*1+0x0]
   140012781:	cmp    QWORD PTR [rdi+0x20],0x8
   140012786:	jb     0x140012791
   140012788:	mov    rcx,QWORD PTR [rdi+0x8]
   14001278c:	call   0x140014084
   140012791:	lea    rax,[rdi+0x8]
   140012795:	mov    QWORD PTR [rax],r15
   140012798:	mov    QWORD PTR [rdi+0x20],rbx
   14001279c:	mov    QWORD PTR [rdi+0x18],r14
   1400127a0:	cmp    rbx,0x8
   1400127a4:	cmovae rax,r15
   1400127a8:	mov    WORD PTR [rax+r14*2],si
   1400127ad:	add    rsp,0x60
   1400127b1:	pop    r15
   1400127b3:	pop    r14
   1400127b5:	pop    rdi
   1400127b6:	pop    rsi
   1400127b7:	pop    rbx
   1400127b8:	ret
   1400127b9:	int3
   1400127ba:	xor    edx,edx
   1400127bc:	lea    rcx,[rsp+0x28]
   1400127c1:	call   0x14000ed98
   1400127c6:	lea    rdx,[rip+0xf8d3]        # 0x1400220a0
   1400127cd:	lea    rcx,[rsp+0x28]
   1400127d2:	call   0x14001478c
   1400127d7:	int3
   1400127d8:	int3
   1400127d9:	int3
   1400127da:	int3
   1400127db:	int3
   1400127dc:	int3
   1400127dd:	int3
   1400127de:	int3
   1400127df:	int3
   1400127e0:	rex push rbx
   1400127e2:	sub    rsp,0x170
   1400127e9:	mov    rax,QWORD PTR [rip+0x11928]        # 0x140024118
   1400127f0:	xor    rax,rsp
   1400127f3:	mov    QWORD PTR [rsp+0x160],rax
   1400127fb:	cmp    DWORD PTR [rip+0x11efe],0x0        # 0x140024700
   140012802:	jne    0x1400128bf
   140012808:	lea    rcx,[rsp+0x40]
   14001280d:	mov    DWORD PTR [rsp+0x40],0x11c
   140012815:	rex.W call QWORD PTR [rip+0x56fc]        # 0x140017f18
   14001281c:	nop    DWORD PTR [rax+rax*1+0x0]
   140012821:	mov    ecx,DWORD PTR [rip+0x11ed9]        # 0x140024700
   140012827:	mov    ebx,0x1
   14001282c:	test   eax,eax
   14001282e:	mov    al,BYTE PTR [rsp+0x15a]
   140012835:	cmove  ecx,ebx
   140012838:	sub    al,0x2
   14001283a:	mov    DWORD PTR [rip+0x11ec0],ecx        # 0x140024700
   140012840:	cmp    al,bl
   140012842:	jbe    0x140012858
   140012844:	xor    eax,eax
   140012846:	cmp    BYTE PTR [rsp+0x15a],bl
   14001284d:	sete   al
   140012850:	mov    DWORD PTR [rip+0x11eae],eax        # 0x140024704
   140012856:	jmp    0x140012871
   140012858:	mov    al,BYTE PTR [rsp+0x158]
   14001285f:	and    al,0x40
   140012861:	neg    al
   140012863:	sbb    ecx,ecx
   140012865:	and    ecx,0x2
   140012868:	add    ecx,0x2
   14001286b:	mov    DWORD PTR [rip+0x11e93],ecx        # 0x140024704
   140012871:	and    QWORD PTR [rsp+0x30],0x0
   140012877:	lea    rax,[rsp+0x30]
   14001287c:	xor    r8d,r8d
   14001287f:	mov    QWORD PTR [rsp+0x20],rax
   140012884:	lea    r9,[rip+0x5cad]        # 0x140018538
   14001288b:	lea    rcx,[rip+0xc1b6]        # 0x14001ea48
   140012892:	lea    edx,[r8+0x15]
   140012896:	rex.W call QWORD PTR [rip+0x57ab]        # 0x140018048
   14001289d:	nop    DWORD PTR [rax+rax*1+0x0]
   1400128a2:	mov    rcx,QWORD PTR [rsp+0x30]
   1400128a7:	test   rcx,rcx
   1400128aa:	je     0x1400128b9
   1400128ac:	mov    rax,QWORD PTR [rcx]
   1400128af:	mov    rax,QWORD PTR [rax+0x10]
   1400128b3:	call   QWORD PTR [rip+0x59df]        # 0x140018298
   1400128b9:	mov    DWORD PTR [rip+0x11e41],ebx        # 0x140024700
   1400128bf:	mov    rcx,QWORD PTR [rsp+0x160]
   1400128c7:	xor    rcx,rsp
   1400128ca:	call   0x1400143c0
   1400128cf:	add    rsp,0x170
   1400128d6:	pop    rbx
   1400128d7:	ret
   1400128d8:	int3
   1400128d9:	int3
   1400128da:	int3
   1400128db:	int3
   1400128dc:	int3
   1400128dd:	int3
   1400128de:	int3
   1400128df:	int3
   1400128e0:	rex push rbx
   1400128e2:	sub    rsp,0x20
   1400128e6:	mov    rbx,rcx
   1400128e9:	mov    rcx,QWORD PTR [rcx]
   1400128ec:	test   rcx,rcx
   1400128ef:	je     0x1400128fd
   1400128f1:	rex.W call QWORD PTR [rip+0x5650]        # 0x140017f48
   1400128f8:	nop    DWORD PTR [rax+rax*1+0x0]
   1400128fd:	and    QWORD PTR [rbx],0x0
   140012901:	and    DWORD PTR [rbx+0x2c],0x0
   140012905:	and    DWORD PTR [rbx+0x40],0x0
   140012909:	and    DWORD PTR [rbx+0x48],0x0
   14001290d:	mov    rcx,QWORD PTR [rbx+0x38]
   140012911:	test   rcx,rcx
   140012914:	je     0x140012922
   140012916:	rex.W call QWORD PTR [rip+0x592b]        # 0x140018248
   14001291d:	nop    DWORD PTR [rax+rax*1+0x0]
   140012922:	and    QWORD PTR [rbx+0x38],0x0
   140012927:	and    DWORD PTR [rbx+0x30],0x0
   14001292b:	mov    rcx,QWORD PTR [rbx+0x50]
   14001292f:	test   rcx,rcx
   140012932:	je     0x140012940
   140012934:	rex.W call QWORD PTR [rip+0x590d]        # 0x140018248
   14001293b:	nop    DWORD PTR [rax+rax*1+0x0]
   140012940:	and    QWORD PTR [rbx+0x50],0x0
   140012945:	and    DWORD PTR [rbx+0x44],0x0
   140012949:	mov    rcx,QWORD PTR [rbx+0x20]
   14001294d:	test   rcx,rcx
   140012950:	je     0x140012964
   140012952:	cmp    BYTE PTR [rbx+0x28],0x0
   140012956:	je     0x140012964
   140012958:	rex.W call QWORD PTR [rip+0x55e9]        # 0x140017f48
   14001295f:	nop    DWORD PTR [rax+rax*1+0x0]
   140012964:	mov    rcx,QWORD PTR [rbx+0x68]
   140012968:	lea    rax,[rip+0x46f1]        # 0x140017060
   14001296f:	mov    QWORD PTR [rbx+0x60],rax
   140012973:	test   rcx,rcx
   140012976:	je     0x140012984
   140012978:	rex.W call QWORD PTR [rip+0x5701]        # 0x140018080
   14001297f:	nop    DWORD PTR [rax+rax*1+0x0]
   140012984:	and    QWORD PTR [rbx+0x68],0x0
   140012989:	lea    rax,[rip+0x46d8]        # 0x140017068
   140012990:	mov    QWORD PTR [rbx+0x60],rax
   140012994:	add    rsp,0x20
   140012998:	pop    rbx
   140012999:	ret
   14001299a:	int3
   14001299b:	int3
   14001299c:	int3
   14001299d:	int3
   14001299e:	int3
   14001299f:	int3
   1400129a0:	int3
   1400129a1:	int3
   1400129a2:	int3
   1400129a3:	int3
   1400129a4:	mov    QWORD PTR [rsp+0x10],rbx
   1400129a9:	mov    QWORD PTR [rsp+0x18],rsi
   1400129ae:	push   rdi
   1400129af:	sub    rsp,0xf0
   1400129b6:	mov    r10d,DWORD PTR [r8]
   1400129b9:	mov    rsi,rdx
   1400129bc:	movzx  r9d,WORD PTR [rcx+0x58]
   1400129c1:	xor    edx,edx
   1400129c3:	mov    eax,r10d
   1400129c6:	mov    rdi,rcx
   1400129c9:	div    r9d
   1400129cc:	test   dx,dx
   1400129cf:	je     0x1400129e8
   1400129d1:	movzx  ebx,dx
   1400129d4:	cmp    r9d,ebx
   1400129d7:	jb     0x140012a4e
   1400129d9:	sub    r9d,ebx
   1400129dc:	lea    eax,[r10+r9*1]
   1400129e0:	cmp    eax,r10d
   1400129e3:	jb     0x1400129fe
   1400129e5:	mov    DWORD PTR [r8],eax
   1400129e8:	lea    r11,[rsp+0xf0]
   1400129f0:	mov    rbx,QWORD PTR [r11+0x18]
   1400129f4:	mov    rsi,QWORD PTR [r11+0x20]
   1400129f8:	mov    rsp,r11
   1400129fb:	pop    rdi
   1400129fc:	ret
   1400129fd:	int3
   1400129fe:	mov    DWORD PTR [rsp+0x28],0xa
   140012a06:	lea    r9,[rip+0xb083]        # 0x14001da90
   140012a0d:	lea    r8,[rip+0xb0c4]        # 0x14001dad8
   140012a14:	mov    DWORD PTR [rsp+0x20],0x8a
   140012a1c:	lea    rdx,[rip+0xb0cd]        # 0x14001daf0
   140012a23:	lea    rcx,[rsp+0x40]
   140012a28:	call   0x14000f3ac
   140012a2d:	movzx  ecx,WORD PTR [rdi+0x58]
   140012a31:	lea    r9,[rip+0xb0f8]        # 0x14001db30
   140012a38:	mov    DWORD PTR [rsp+0x20],ecx
   140012a3c:	mov    r8d,0x8007000e
   140012a42:	mov    rcx,rsi
   140012a45:	mov    rdx,rax
   140012a48:	call   0x1400106b0
   140012a4d:	int3
   140012a4e:	mov    DWORD PTR [rsp+0x28],0xa
   140012a56:	lea    r9,[rip+0xb033]        # 0x14001da90
   140012a5d:	lea    r8,[rip+0xb074]        # 0x14001dad8
   140012a64:	mov    DWORD PTR [rsp+0x20],0x83
   140012a6c:	lea    rdx,[rip+0xb07d]        # 0x14001daf0
   140012a73:	lea    rcx,[rsp+0x40]
   140012a78:	call   0x14000f3ac
   140012a7d:	movzx  ecx,WORD PTR [rdi+0x58]
   140012a81:	lea    r9,[rip+0xaf58]        # 0x14001d9e0
   140012a88:	mov    DWORD PTR [rsp+0x28],ecx
   140012a8c:	mov    r8d,0x8007000e
   140012a92:	mov    rcx,rsi
   140012a95:	mov    DWORD PTR [rsp+0x20],ebx
   140012a99:	mov    rdx,rax
   140012a9c:	call   0x1400106b0
   140012aa1:	int3
   140012aa2:	int3
   140012aa3:	int3
   140012aa4:	int3
   140012aa5:	int3
   140012aa6:	int3
   140012aa7:	int3
   140012aa8:	mov    rax,rsp
   140012aab:	push   rbp
   140012aac:	push   rsi
   140012aad:	push   rdi
   140012aae:	push   r12
   140012ab0:	push   r13
   140012ab2:	push   r14
   140012ab4:	push   r15
   140012ab6:	lea    rbp,[rax-0x308]
   140012abd:	sub    rsp,0x3d0
   140012ac4:	mov    QWORD PTR [rbp-0x8],0xfffffffffffffffe
   140012acc:	mov    QWORD PTR [rax+0x20],rbx
   140012ad0:	mov    rax,QWORD PTR [rip+0x11641]        # 0x140024118
   140012ad7:	xor    rax,rsp
   140012ada:	mov    QWORD PTR [rbp+0x2c0],rax
   140012ae1:	mov    rdi,r8
   140012ae4:	mov    r14,rdx
   140012ae7:	mov    rsi,rcx
   140012aea:	lea    r13,[rip+0xafff]        # 0x14001daf0
   140012af1:	mov    QWORD PTR [rsp+0x50],r13
   140012af6:	lea    r15,[rip+0xb11b]        # 0x14001dc18
   140012afd:	mov    QWORD PTR [rsp+0x58],r15
   140012b02:	lea    rax,[rip+0xafcf]        # 0x14001dad8
   140012b09:	mov    QWORD PTR [rsp+0x60],rax
   140012b0e:	mov    DWORD PTR [rsp+0x68],0xc8
   140012b16:	mov    DWORD PTR [rsp+0x6c],0xa
   140012b1e:	mov    DWORD PTR [rsp+0x70],0xff
   140012b26:	xor    r12d,r12d
   140012b29:	mov    DWORD PTR [rbp-0x10],0x1000000
   140012b30:	xor    edx,edx
   140012b32:	lea    r8d,[r12+0x78]
   140012b37:	lea    rcx,[rsp+0x78]
   140012b3c:	call   0x140015692
   140012b41:	mov    DWORD PTR [rsp+0x28],0x3
   140012b49:	mov    DWORD PTR [rsp+0x20],0x80000000
   140012b51:	mov    r9,rdi
   140012b54:	lea    r8,[rip+0xb045]        # 0x14001dba0
   140012b5b:	lea    rdx,[rsp+0x50]
   140012b60:	mov    rcx,r14
   140012b63:	call   0x140010510
   140012b68:	mov    DWORD PTR [r14+0x8],r12d
   140012b6c:	mov    rcx,QWORD PTR [rsi]
   140012b6f:	test   rcx,rcx
   140012b72:	je     0x140012b80
   140012b74:	rex.W call QWORD PTR [rip+0x53cd]        # 0x140017f48
   140012b7b:	nop    DWORD PTR [rax+rax*1+0x0]
   140012b80:	mov    QWORD PTR [rsi],r12
   140012b83:	mov    DWORD PTR [rsi+0x2c],r12d
   140012b87:	mov    DWORD PTR [rsi+0x40],r12d
   140012b8b:	mov    DWORD PTR [rsi+0x48],r12d
   140012b8f:	or     rbx,0xffffffffffffffff
   140012b93:	inc    rbx
   140012b96:	cmp    WORD PTR [rdi+rbx*2],r12w
   140012b9b:	jne    0x140012b93
   140012b9d:	lea    rax,[rbx-0x1]
   140012ba1:	cmp    rax,0x103
   140012ba7:	ja     0x140012d9f
   140012bad:	cmp    WORD PTR [rdi+rbx*2-0x2],0x5c
   140012bb3:	jne    0x140012df1
   140012bb9:	lea    r15,[rbx-0x1]
   140012bbd:	cmp    r15,0x7ffffffe
   140012bc4:	jbe    0x140012bd5
   140012bc6:	mov    ebx,0x80070057
   140012bcb:	mov    WORD PTR [rbp+0xb0],r12w
   140012bd3:	jmp    0x140012c29
   140012bd5:	mov    ecx,0x104
   140012bda:	lea    rdx,[rbp+0xb0]
   140012be1:	lea    rax,[rbp+0xb0]
   140012be8:	sub    rdi,rax
   140012beb:	lea    rax,[r15-0x104]
   140012bf2:	add    rax,rcx
   140012bf5:	je     0x140012c0d
   140012bf7:	movzx  eax,WORD PTR [rdx+rdi*1]
   140012bfb:	test   ax,ax
   140012bfe:	je     0x140012c0d
   140012c00:	mov    WORD PTR [rdx],ax
   140012c03:	add    rdx,0x2
   140012c07:	sub    rcx,0x1
   140012c0b:	jne    0x140012beb
   140012c0d:	lea    rax,[rdx-0x2]
   140012c11:	test   rcx,rcx
   140012c14:	cmovne rax,rdx
   140012c18:	mov    WORD PTR [rax],r12w
   140012c1c:	neg    rcx
   140012c1f:	sbb    ebx,ebx
   140012c21:	not    ebx
   140012c23:	and    ebx,0x8007007a
   140012c29:	mov    DWORD PTR [r14+0x8],ebx
   140012c2d:	mov    QWORD PTR [rsp+0x50],r13
   140012c32:	lea    rdi,[rip+0xafdf]        # 0x14001dc18
   140012c39:	mov    QWORD PTR [rsp+0x58],rdi
   140012c3e:	lea    rax,[rip+0xae93]        # 0x14001dad8
   140012c45:	mov    QWORD PTR [rsp+0x60],rax
   140012c4a:	mov    DWORD PTR [rsp+0x68],0xe9
   140012c52:	mov    DWORD PTR [rsp+0x6c],0xa
   140012c5a:	mov    DWORD PTR [rsp+0x70],0xff
   140012c62:	mov    DWORD PTR [rbp-0x10],0x1000000
   140012c69:	xor    edx,edx
   140012c6b:	lea    r8d,[rdx+0x78]
   140012c6f:	lea    rcx,[rsp+0x78]
   140012c74:	call   0x140015692
   140012c79:	lea    rax,[rsp+0x50]
   140012c7e:	mov    QWORD PTR [rsp+0x40],rax
   140012c83:	test   ebx,ebx
   140012c85:	js     0x140012e36
   140012c8b:	lea    rcx,[rsp+0x50]
   140012c90:	call   0x14000f484
   140012c95:	lea    rax,[r15+r15*1]
   140012c99:	cmp    rax,0x208
   140012c9f:	jae    0x140012d99
   140012ca5:	mov    WORD PTR [rbp+rax*1+0xb0],r12w
   140012cae:	or     QWORD PTR [rsp+0x30],0xffffffffffffffff
   140012cb4:	mov    DWORD PTR [rsp+0x28],0x80
   140012cbc:	mov    r15d,0x3
   140012cc2:	mov    DWORD PTR [rsp+0x20],r15d
   140012cc7:	xor    r9d,r9d
   140012cca:	mov    r8d,r15d
   140012ccd:	mov    edx,0x80000000
   140012cd2:	lea    rcx,[rbp+0xb0]
   140012cd9:	rex.W call QWORD PTR [rip+0x5230]        # 0x140017f10
   140012ce0:	nop    DWORD PTR [rax+rax*1+0x0]
   140012ce5:	mov    QWORD PTR [rsi],rax
   140012ce8:	cmp    rax,0xffffffffffffffff
   140012cec:	je     0x140012e5a
   140012cf2:	mov    QWORD PTR [rsp+0x50],r13
   140012cf7:	mov    QWORD PTR [rsp+0x58],rdi
   140012cfc:	lea    rax,[rip+0xadd5]        # 0x14001dad8
   140012d03:	mov    QWORD PTR [rsp+0x60],rax
   140012d08:	mov    DWORD PTR [rsp+0x68],0x12c
   140012d10:	mov    DWORD PTR [rsp+0x6c],0xa
   140012d18:	mov    DWORD PTR [rsp+0x70],0xff
   140012d20:	mov    DWORD PTR [rbp-0x10],0x1000000
   140012d27:	xor    edx,edx
   140012d29:	lea    r8d,[r15+0x75]
   140012d2d:	lea    rcx,[rsp+0x78]
   140012d32:	call   0x140015692
   140012d37:	mov    rax,QWORD PTR [rsi]
   140012d3a:	mov    QWORD PTR [rsp+0x20],rax
   140012d3f:	lea    r9,[rbp+0xb0]
   140012d46:	lea    r8,[rip+0xb063]        # 0x14001ddb0
   140012d4d:	lea    rdx,[rsp+0x50]
   140012d52:	mov    rcx,r14
   140012d55:	call   0x140010510
   140012d5a:	lea    rcx,[rsi+0x60]
   140012d5e:	lea    rdx,[rbp+0xb0]
   140012d65:	call   0x14000b90c
   140012d6a:	mov    eax,DWORD PTR [r14+0x8]
   140012d6e:	mov    rcx,QWORD PTR [rbp+0x2c0]
   140012d75:	xor    rcx,rsp
   140012d78:	call   0x1400143c0
   140012d7d:	mov    rbx,QWORD PTR [rsp+0x428]
   140012d85:	add    rsp,0x3d0
   140012d8c:	pop    r15
   140012d8e:	pop    r14
   140012d90:	pop    r13
   140012d92:	pop    r12
   140012d94:	pop    rdi
   140012d95:	pop    rsi
   140012d96:	pop    rbp
   140012d97:	ret
   140012d98:	int3
   140012d99:	call   0x140014638
   140012d9e:	int3
   140012d9f:	mov    DWORD PTR [rsp+0x28],0xa
   140012da7:	mov    DWORD PTR [rsp+0x20],0xda
   140012daf:	mov    r9,r15
   140012db2:	lea    r8,[rip+0xad1f]        # 0x14001dad8
   140012db9:	mov    rdx,r13
   140012dbc:	lea    rcx,[rbp+0x0]
   140012dc0:	call   0x14000f3ac
   140012dc5:	mov    QWORD PTR [rsp+0x30],rbx
   140012dca:	mov    ecx,0x104
   140012dcf:	mov    DWORD PTR [rsp+0x28],ecx
   140012dd3:	mov    QWORD PTR [rsp+0x20],rdi
   140012dd8:	lea    r9,[rip+0xae71]        # 0x14001dc50
   140012ddf:	mov    r8d,0x8000ffff
   140012de5:	mov    rdx,rax
   140012de8:	mov    rcx,r14
   140012deb:	call   0x140010ee4
   140012df0:	int3
   140012df1:	mov    DWORD PTR [rsp+0x28],0xa
   140012df9:	mov    DWORD PTR [rsp+0x20],0xe2
   140012e01:	mov    r9,r15
   140012e04:	lea    r8,[rip+0xaccd]        # 0x14001dad8
   140012e0b:	mov    rdx,r13
   140012e0e:	lea    rcx,[rsp+0x50]
   140012e13:	call   0x14000f3ac
   140012e18:	mov    QWORD PTR [rsp+0x20],rdi
   140012e1d:	lea    r9,[rip+0xae9c]        # 0x14001dcc0
   140012e24:	mov    r8d,0x8000ffff
   140012e2a:	mov    rdx,rax
   140012e2d:	mov    rcx,r14
   140012e30:	call   0x140010ee4
   140012e35:	nop
   140012e36:	lea    rdx,[rsp+0x50]
   140012e3b:	lea    rcx,[rbp+0x0]
   140012e3f:	call   0x14000f400
   140012e44:	lea    r9,[rip+0xaeed]        # 0x14001dd38
   140012e4b:	mov    r8d,ebx
   140012e4e:	mov    rdx,rax
   140012e51:	mov    rcx,r14
   140012e54:	call   0x140010848
   140012e59:	nop
   140012e5a:	mov    QWORD PTR [rsi],r12
   140012e5d:	rex.W call QWORD PTR [rip+0x5114]        # 0x140017f78
   140012e64:	nop    DWORD PTR [rax+rax*1+0x0]
   140012e69:	mov    ebx,eax
   140012e6b:	mov    DWORD PTR [rsp+0x28],0x2
   140012e73:	mov    DWORD PTR [rsp+0x20],0x10e
   140012e7b:	mov    r9,rdi
   140012e7e:	lea    r8,[rip+0xac53]        # 0x14001dad8
   140012e85:	mov    rdx,r13
   140012e88:	lea    rcx,[rbp+0x0]
   140012e8c:	call   0x14000f3ac
   140012e91:	movzx  r8d,bx
   140012e95:	or     r8d,0x80070000
   140012e9c:	test   ebx,ebx
   140012e9e:	cmovle r8d,ebx
   140012ea2:	mov    DWORD PTR [rsp+0x38],r15d
   140012ea7:	mov    DWORD PTR [rsp+0x30],0x80000000
   140012eaf:	lea    rcx,[rbp+0xb0]
   140012eb6:	mov    QWORD PTR [rsp+0x28],rcx
   140012ebb:	lea    rcx,[rip+0xae9e]        # 0x14001dd60
   140012ec2:	mov    QWORD PTR [rsp+0x20],rcx
   140012ec7:	mov    r9d,0x80042306
   140012ecd:	mov    rdx,rax
   140012ed0:	mov    rcx,r14
   140012ed3:	call   0x140011164
   140012ed8:	int3
   140012ed9:	int3
   140012eda:	int3
   140012edb:	int3
   140012edc:	int3
   140012edd:	int3
   140012ede:	int3
   140012edf:	int3
   140012ee0:	mov    QWORD PTR [rsp+0x10],rbx
   140012ee5:	mov    BYTE PTR [rsp+0x20],r9b
   140012eea:	push   rbp
   140012eeb:	push   rsi
   140012eec:	push   rdi
   140012eed:	push   r12
   140012eef:	push   r13
   140012ef1:	push   r14
   140012ef3:	push   r15
   140012ef5:	lea    rbp,[rsp-0xf]
   140012efa:	sub    rsp,0xf0
   140012f01:	mov    r13,rdx
   140012f04:	mov    rbx,rcx
   140012f07:	xor    edx,edx
   140012f09:	mov    edi,edx
   140012f0b:	mov    DWORD PTR [r13+0x8],edx
   140012f0f:	cmp    QWORD PTR [rcx],rdx
   140012f12:	je     0x140013202
   140012f18:	lea    esi,[rdx+0xa]
   140012f1b:	cmp    BYTE PTR [rcx+0x29],dl
   140012f1e:	jne    0x140013250
   140012f24:	mov    eax,DWORD PTR [rcx+0x44]
   140012f27:	lea    r14,[rip+0xaf22]        # 0x14001de50
   140012f2e:	mov    DWORD PTR [rcx+0x40],edx
   140012f31:	lea    r15,[rip+0xaba0]        # 0x14001dad8
   140012f38:	mov    DWORD PTR [rcx+0x48],edx
   140012f3b:	lea    r12,[rip+0xabae]        # 0x14001daf0
   140012f42:	mov    DWORD PTR [rbp+0x67],eax
   140012f45:	mov    ecx,eax
   140012f47:	test   edi,edi
   140012f49:	jne    0x140012f54
   140012f4b:	test   eax,eax
   140012f4d:	jne    0x140012f7c
   140012f4f:	mov    edi,0x1000
   140012f54:	cmp    edi,eax
   140012f56:	jbe    0x140012f81
   140012f58:	mov    rcx,QWORD PTR [rbx+0x50]
   140012f5c:	mov    edx,edi
   140012f5e:	rex.W call QWORD PTR [rip+0x52eb]        # 0x140018250
   140012f65:	nop    DWORD PTR [rax+rax*1+0x0]
   140012f6a:	test   rax,rax
   140012f6d:	je     0x140013294
   140012f73:	mov    QWORD PTR [rbx+0x50],rax
   140012f77:	mov    DWORD PTR [rbx+0x44],edi
   140012f7a:	jmp    0x140012f83
   140012f7c:	mov    edi,DWORD PTR [rbp+0x67]
   140012f7f:	jmp    0x140012f83
   140012f81:	mov    edi,ecx
   140012f83:	xor    edx,edx
   140012f85:	mov    QWORD PTR [rsp+0x40],r12
   140012f8a:	lea    rcx,[rbp-0x79]
   140012f8e:	mov    QWORD PTR [rsp+0x48],r14
   140012f93:	mov    QWORD PTR [rsp+0x50],r15
   140012f98:	mov    DWORD PTR [rsp+0x58],0x1c3
   140012fa0:	lea    r8d,[rdx+0x78]
   140012fa4:	mov    DWORD PTR [rsp+0x5c],esi
   140012fa8:	mov    DWORD PTR [rsp+0x60],0xff
   140012fb0:	mov    DWORD PTR [rbp-0x1],0x1000000
   140012fb7:	call   0x140015692
   140012fbc:	mov    eax,DWORD PTR [rbx+0x2c]
   140012fbf:	lea    r8,[rip+0xaf5a]        # 0x14001df20
   140012fc6:	mov    DWORD PTR [rsp+0x30],edi
   140012fca:	lea    rdx,[rsp+0x40]
   140012fcf:	mov    DWORD PTR [rsp+0x28],eax
   140012fd3:	mov    r9d,0x534058
   140012fd9:	mov    rax,QWORD PTR [rbx+0x68]
   140012fdd:	mov    rcx,r13
   140012fe0:	mov    QWORD PTR [rsp+0x20],rax
   140012fe5:	call   0x140010510
   140012fea:	xor    edi,edi
   140012fec:	mov    QWORD PTR [rsp+0x40],r12
   140012ff1:	xor    edx,edx
   140012ff3:	mov    QWORD PTR [rsp+0x48],r14
   140012ff8:	lea    rcx,[rbp-0x79]
   140012ffc:	mov    QWORD PTR [rsp+0x50],r15
   140013001:	mov    DWORD PTR [rsp+0x58],0x1c5
   140013009:	lea    r8d,[rdi+0x78]
   14001300d:	mov    DWORD PTR [rsp+0x5c],esi
   140013011:	mov    DWORD PTR [rsp+0x60],0xff
   140013019:	mov    DWORD PTR [rbp-0x1],0x1000000
   140013020:	call   0x140015692
   140013025:	mov    r9,QWORD PTR [rbx+0x38]
   140013029:	lea    rdx,[rsp+0x40]
   14001302e:	mov    r8d,DWORD PTR [rbx+0x2c]
   140013032:	mov    rcx,r13
   140013035:	call   0x14001060c
   14001303a:	mov    eax,DWORD PTR [rbx+0x44]
   14001303d:	mov    edx,0x534058
   140013042:	mov    r9d,DWORD PTR [rbx+0x2c]
   140013046:	mov    r8,QWORD PTR [rbx+0x38]
   14001304a:	mov    rcx,QWORD PTR [rbx]
   14001304d:	mov    QWORD PTR [rsp+0x38],rdi
   140013052:	lea    rdi,[rbx+0x48]
   140013056:	mov    QWORD PTR [rsp+0x30],rdi
   14001305b:	mov    DWORD PTR [rsp+0x28],eax
   14001305f:	mov    rax,QWORD PTR [rbx+0x50]
   140013063:	mov    QWORD PTR [rsp+0x20],rax
   140013068:	rex.W call QWORD PTR [rip+0x4e99]        # 0x140017f08
   14001306f:	nop    DWORD PTR [rax+rax*1+0x0]
   140013074:	mov    DWORD PTR [rbp+0x67],eax
   140013077:	test   eax,eax
   140013079:	jne    0x1400130aa
   14001307b:	rex.W call QWORD PTR [rip+0x4ef6]        # 0x140017f78
   140013082:	nop    DWORD PTR [rax+rax*1+0x0]
   140013087:	cmp    eax,0x7a
   14001308a:	je     0x14001309f
   14001308c:	rex.W call QWORD PTR [rip+0x4ee5]        # 0x140017f78
   140013093:	nop    DWORD PTR [rax+rax*1+0x0]
   140013098:	cmp    eax,0xea
   14001309d:	jne    0x1400130aa
   14001309f:	mov    eax,DWORD PTR [rbx+0x44]
   1400130a2:	lea    edi,[rax+rax*1]
   1400130a5:	jmp    0x140012f42
   1400130aa:	rex.W call QWORD PTR [rip+0x4ec7]        # 0x140017f78
   1400130b1:	nop    DWORD PTR [rax+rax*1+0x0]
   1400130b6:	xor    ecx,ecx
   1400130b8:	mov    DWORD PTR [rbp+0x77],eax
   1400130bb:	mov    DWORD PTR [rbx+0x2c],ecx
   1400130be:	mov    DWORD PTR [rbx+0x40],ecx
   1400130c1:	cmp    DWORD PTR [rbp+0x67],ecx
   1400130c4:	je     0x1400131a5
   1400130ca:	lea    r8d,[rcx+0x78]
   1400130ce:	mov    QWORD PTR [rsp+0x40],r12
   1400130d3:	lea    rcx,[rbp-0x79]
   1400130d7:	mov    QWORD PTR [rsp+0x48],r14
   1400130dc:	xor    edx,edx
   1400130de:	mov    QWORD PTR [rsp+0x50],r15
   1400130e3:	mov    DWORD PTR [rsp+0x58],0x225
   1400130eb:	mov    DWORD PTR [rsp+0x5c],esi
   1400130ef:	mov    DWORD PTR [rsp+0x60],0xff
   1400130f7:	mov    DWORD PTR [rbp-0x1],0x1000000
   1400130fe:	call   0x140015692
   140013103:	mov    eax,DWORD PTR [rdi]
   140013105:	lea    r8,[rip+0xaf44]        # 0x14001e050
   14001310c:	mov    DWORD PTR [rsp+0x30],eax
   140013110:	lea    rdx,[rsp+0x40]
   140013115:	mov    rax,QWORD PTR [rbx]
   140013118:	mov    r9d,0x534058
   14001311e:	mov    QWORD PTR [rsp+0x28],rax
   140013123:	mov    rcx,r13
   140013126:	mov    rax,QWORD PTR [rbx+0x68]
   14001312a:	mov    QWORD PTR [rsp+0x20],rax
   14001312f:	call   0x140010510
   140013134:	mov    DWORD PTR [rsp+0x5c],esi
   140013138:	lea    rcx,[rbp-0x79]
   14001313c:	xor    esi,esi
   14001313e:	mov    QWORD PTR [rsp+0x40],r12
   140013143:	xor    edx,edx
   140013145:	mov    QWORD PTR [rsp+0x48],r14
   14001314a:	mov    QWORD PTR [rsp+0x50],r15
   14001314f:	mov    DWORD PTR [rsp+0x58],0x227
   140013157:	lea    r8d,[rsi+0x78]
   14001315b:	mov    DWORD PTR [rsp+0x60],0xff
   140013163:	mov    DWORD PTR [rbp-0x1],0x1000000
   14001316a:	call   0x140015692
   14001316f:	mov    r9,QWORD PTR [rbx+0x50]
   140013173:	lea    rdx,[rsp+0x40]
   140013178:	mov    r8d,DWORD PTR [rdi]
   14001317b:	mov    rcx,r13
   14001317e:	call   0x14001060c
   140013183:	mov    DWORD PTR [r13+0x8],esi
   140013187:	xor    eax,eax
   140013189:	mov    rbx,QWORD PTR [rsp+0x138]
   140013191:	add    rsp,0xf0
   140013198:	pop    r15
   14001319a:	pop    r14
   14001319c:	pop    r13
   14001319e:	pop    r12
   1400131a0:	pop    rdi
   1400131a1:	pop    rsi
   1400131a2:	pop    rbp
   1400131a3:	ret
   1400131a4:	int3
   1400131a5:	mov    DWORD PTR [rsp+0x28],esi
   1400131a9:	lea    rcx,[rsp+0x40]
   1400131ae:	mov    r9,r14
   1400131b1:	mov    DWORD PTR [rsp+0x20],0x1ea
   1400131b9:	mov    r8,r15
   1400131bc:	mov    rdx,r12
   1400131bf:	call   0x14000f3ac
   1400131c4:	lea    rcx,[rbx+0x60]
   1400131c8:	mov    rdx,rax
   1400131cb:	call   0x1400035f0
   1400131d0:	mov    ecx,DWORD PTR [rbp+0x77]
   1400131d3:	lea    r9,[rip+0xade6]        # 0x14001dfc0
   1400131da:	mov    DWORD PTR [rsp+0x38],ecx
   1400131de:	mov    r8d,0x8000ffff
   1400131e4:	mov    rcx,QWORD PTR [rbx]
   1400131e7:	mov    QWORD PTR [rsp+0x30],rcx
   1400131ec:	mov    rcx,r13
   1400131ef:	mov    QWORD PTR [rsp+0x28],rax
   1400131f4:	mov    DWORD PTR [rsp+0x20],0x534058
   1400131fc:	call   0x1400106b0
   140013201:	int3
   140013202:	call   0x1400132dc
   140013207:	mov    esi,0xa
   14001320c:	lea    r9,[rip+0xac3d]        # 0x14001de50
   140013213:	mov    DWORD PTR [rsp+0x28],esi
   140013217:	lea    r8,[rip+0xa8ba]        # 0x14001dad8
   14001321e:	lea    rdx,[rip+0xa8cb]        # 0x14001daf0
   140013225:	mov    DWORD PTR [rsp+0x20],0x17d
   14001322d:	lea    rcx,[rsp+0x40]
   140013232:	call   0x14000f3ac
   140013237:	lea    r9,[rip+0xabea]        # 0x14001de28
   14001323e:	mov    r8d,0x8000ffff
   140013244:	mov    rdx,rax
   140013247:	mov    rcx,r13
   14001324a:	call   0x140010ee4
   14001324f:	int3
   140013250:	mov    DWORD PTR [rsp+0x28],esi
   140013254:	lea    r9,[rip+0xabf5]        # 0x14001de50
   14001325b:	lea    r8,[rip+0xa876]        # 0x14001dad8
   140013262:	mov    DWORD PTR [rsp+0x20],0x182
   14001326a:	lea    rdx,[rip+0xa87f]        # 0x14001daf0
   140013271:	lea    rcx,[rsp+0x40]
   140013276:	call   0x14000f3ac
   14001327b:	lea    r9,[rip+0xabfe]        # 0x14001de80
   140013282:	mov    r8d,0x80070057
   140013288:	mov    rdx,rax
   14001328b:	mov    rcx,r13
   14001328e:	call   0x1400106b0
   140013293:	int3
   140013294:	mov    rcx,rbx
   140013297:	call   0x1400132dc
   14001329c:	mov    DWORD PTR [rsp+0x28],esi
   1400132a0:	lea    rcx,[rsp+0x40]
   1400132a5:	mov    r9,r14
   1400132a8:	mov    DWORD PTR [rsp+0x20],0x1ba
   1400132b0:	mov    r8,r15
   1400132b3:	mov    rdx,r12
   1400132b6:	call   0x14000f3ac
   1400132bb:	lea    r9,[rip+0xac0e]        # 0x14001ded0
   1400132c2:	mov    r8d,0x8007000e
   1400132c8:	mov    rdx,rax
   1400132cb:	mov    rcx,r13
   1400132ce:	call   0x1400106b0
   1400132d3:	int3
   1400132d4:	int3
   1400132d5:	int3
   1400132d6:	int3
   1400132d7:	int3
   1400132d8:	int3
   1400132d9:	int3
   1400132da:	int3
   1400132db:	int3
   1400132dc:	and    DWORD PTR [rcx+0x2c],0x0
   1400132e0:	and    DWORD PTR [rcx+0x40],0x0
   1400132e4:	ret
   1400132e5:	int3
   1400132e6:	int3
   1400132e7:	int3
   1400132e8:	int3
   1400132e9:	int3
   1400132ea:	int3
   1400132eb:	int3
   1400132ec:	mov    rax,rsp
   1400132ef:	mov    QWORD PTR [rax+0x8],rcx
   1400132f3:	push   rbp
   1400132f4:	push   rsi
   1400132f5:	push   rdi
   1400132f6:	push   r12
   1400132f8:	push   r13
   1400132fa:	push   r14
   1400132fc:	push   r15
   1400132fe:	lea    rbp,[rsp-0x50]
   140013303:	sub    rsp,0x150
   14001330a:	mov    QWORD PTR [rbp-0x28],0xfffffffffffffffe
   140013312:	mov    QWORD PTR [rax+0x10],rbx
   140013316:	mov    rsi,r9
   140013319:	mov    rdi,r8
   14001331c:	mov    rbx,rcx
   14001331f:	lea    r15,[rip+0xade2]        # 0x14001e108
   140013326:	mov    QWORD PTR [rsp+0x30],r15
   14001332b:	lea    r12,[rip+0xae16]        # 0x14001e148
   140013332:	mov    QWORD PTR [rsp+0x38],r12
   140013337:	lea    r13,[rip+0xadba]        # 0x14001e0f8
   14001333e:	mov    QWORD PTR [rsp+0x40],r13
   140013343:	mov    DWORD PTR [rsp+0x48],0x15b
   14001334b:	mov    DWORD PTR [rsp+0x4c],0xb
   140013353:	mov    DWORD PTR [rsp+0x50],0xff
   14001335b:	xor    r14d,r14d
   14001335e:	mov    DWORD PTR [rbp-0x30],0x1000000
   140013365:	xor    edx,edx
   140013367:	lea    r8d,[r14+0x78]
   14001336b:	lea    rcx,[rsp+0x58]
   140013370:	call   0x140015692
   140013375:	lea    rdx,[rsp+0x30]
   14001337a:	lea    rcx,[rbp-0x20]
   14001337e:	call   0x14000f85c
   140013383:	nop
   140013384:	mov    WORD PTR [rsi],r14w
   140013388:	mov    QWORD PTR [rsp+0x30],r15
   14001338d:	mov    QWORD PTR [rsp+0x38],r12
   140013392:	mov    QWORD PTR [rsp+0x40],r13
   140013397:	mov    DWORD PTR [rsp+0x48],0x163
   14001339f:	mov    DWORD PTR [rsp+0x4c],0xb
   1400133a7:	mov    DWORD PTR [rsp+0x50],0xff
   1400133af:	mov    DWORD PTR [rbp-0x30],0x1000000
   1400133b6:	xor    edx,edx
   1400133b8:	lea    r8d,[r14+0x78]
   1400133bc:	lea    rcx,[rsp+0x58]
   1400133c1:	call   0x140015692
   1400133c6:	mov    r9,rdi
   1400133c9:	lea    r8,[rip+0xadb0]        # 0x14001e180
   1400133d0:	lea    rdx,[rsp+0x30]
   1400133d5:	lea    rcx,[rbp-0x20]
   1400133d9:	call   0x140010510
   1400133de:	lea    r8d,[r14+0x32]
   1400133e2:	mov    rdx,rsi
   1400133e5:	mov    rcx,rdi
   1400133e8:	rex.W call QWORD PTR [rip+0x4af9]        # 0x140017ee8
   1400133ef:	nop    DWORD PTR [rax+rax*1+0x0]
   1400133f4:	test   eax,eax
   1400133f6:	je     0x140013481
   1400133fc:	mov    QWORD PTR [rsp+0x30],r15
   140013401:	mov    QWORD PTR [rsp+0x38],r12
   140013406:	mov    QWORD PTR [rsp+0x40],r13
   14001340b:	mov    DWORD PTR [rsp+0x48],0x16b
   140013413:	mov    DWORD PTR [rsp+0x4c],0xb
   14001341b:	mov    DWORD PTR [rsp+0x50],0xff
   140013423:	mov    DWORD PTR [rbp-0x30],0x1000000
   14001342a:	xor    edx,edx
   14001342c:	lea    r8d,[r14+0x78]
   140013430:	lea    rcx,[rsp+0x58]
   140013435:	call   0x140015692
   14001343a:	mov    r9,rsi
   14001343d:	lea    r8,[rip+0xadac]        # 0x14001e1f0
   140013444:	lea    rdx,[rsp+0x30]
   140013449:	lea    rcx,[rbp-0x20]
   14001344d:	call   0x140010510
   140013452:	nop
   140013453:	lea    rcx,[rbp-0x20]
   140013457:	call   0x14000f958
   14001345c:	nop
   14001345d:	mov    rcx,rbx
   140013460:	call   0x14000f484
   140013465:	mov    rbx,QWORD PTR [rsp+0x198]
   14001346d:	add    rsp,0x150
   140013474:	pop    r15
   140013476:	pop    r14
   140013478:	pop    r13
   14001347a:	pop    r12
   14001347c:	pop    rdi
   14001347d:	pop    rsi
   14001347e:	pop    rbp
   14001347f:	ret
   140013480:	int3
   140013481:	mov    rdx,rbx
   140013484:	lea    rcx,[rsp+0x30]
   140013489:	call   0x14000f400
   14001348e:	mov    rbx,rax
   140013491:	rex.W call QWORD PTR [rip+0x4ae0]        # 0x140017f78
   140013498:	nop    DWORD PTR [rax+rax*1+0x0]
   14001349d:	mov    DWORD PTR [rsp+0x28],eax
   1400134a1:	mov    QWORD PTR [rsp+0x20],rdi
   1400134a6:	lea    r9,[rip+0x87d3]        # 0x14001bc80
   1400134ad:	mov    r8d,0x80070057
   1400134b3:	mov    rdx,rbx
   1400134b6:	lea    rcx,[rbp-0x20]
   1400134ba:	call   0x1400106b0
   1400134bf:	int3
   1400134c0:	int3
   1400134c1:	int3
   1400134c2:	int3
   1400134c3:	int3
   1400134c4:	int3
   1400134c5:	int3
   1400134c6:	int3
   1400134c7:	int3
   1400134c8:	mov    rax,rsp
   1400134cb:	push   r12
   1400134cd:	push   r14
   1400134cf:	push   r15
   1400134d1:	sub    rsp,0x330
   1400134d8:	mov    QWORD PTR [rax-0x118],0xfffffffffffffffe
   1400134e3:	mov    QWORD PTR [rax+0x10],rbx
   1400134e7:	mov    QWORD PTR [rax+0x18],rsi
   1400134eb:	mov    QWORD PTR [rax+0x20],rdi
   1400134ef:	mov    rax,QWORD PTR [rip+0x10c22]        # 0x140024118
   1400134f6:	xor    rax,rsp
   1400134f9:	mov    QWORD PTR [rsp+0x320],rax
   140013501:	mov    rsi,rcx
   140013504:	mov    QWORD PTR [rsp+0x1b0],rcx
   14001350c:	lea    rax,[rip+0xad7d]        # 0x14001e290
   140013513:	mov    QWORD PTR [rsp+0x50],rax
   140013518:	lea    rax,[rip+0xadd1]        # 0x14001e2f0
   14001351f:	mov    QWORD PTR [rsp+0x58],rax
   140013524:	lea    rax,[rip+0xad4d]        # 0x14001e278
   14001352b:	mov    QWORD PTR [rsp+0x60],rax
   140013530:	mov    DWORD PTR [rsp+0x68],0x698
   140013538:	mov    DWORD PTR [rsp+0x6c],0xb
   140013540:	mov    r15d,0xff
   140013546:	mov    DWORD PTR [rsp+0x70],r15d
   14001354b:	xor    edi,edi
   14001354d:	mov    DWORD PTR [rsp+0xf0],0x1000000
   140013558:	lea    r12d,[rdi+0x78]
   14001355c:	mov    r8d,r12d
   14001355f:	xor    edx,edx
   140013561:	lea    rcx,[rsp+0x78]
   140013566:	call   0x140015692
   14001356b:	lea    rdx,[rsp+0x50]
   140013570:	lea    rcx,[rsp+0x1c0]
   140013578:	call   0x14000f85c
   14001357d:	nop
   14001357e:	mov    r14,rsi
   140013581:	or     rax,0xffffffffffffffff
   140013585:	inc    rax
   140013588:	cmp    WORD PTR [rsi+rax*2],di
   14001358c:	jne    0x140013585
   14001358e:	cmp    rax,0x31
   140013592:	jne    0x14001364c
   140013598:	lea    r8d,[rax-0x27]
   14001359c:	lea    rdx,[rip+0xb48d]        # 0x14001ea30
   1400135a3:	mov    rcx,rsi
   1400135a6:	rex.W call QWORD PTR [rip+0x4c4b]        # 0x1400181f8
   1400135ad:	nop    DWORD PTR [rax+rax*1+0x0]
   1400135b2:	test   eax,eax
   1400135b4:	jne    0x14001364c
   1400135ba:	lea    rbx,[rsi+0x14]
   1400135be:	lea    rcx,[rbx+0x4c]
   1400135c2:	lea    r8d,[rax+0x2]
   1400135c6:	lea    rdx,[rip+0xb45f]        # 0x14001ea2c
   1400135cd:	rex.W call QWORD PTR [rip+0x4c24]        # 0x1400181f8
   1400135d4:	nop    DWORD PTR [rax+rax*1+0x0]
   1400135d9:	test   eax,eax
   1400135db:	jne    0x14001364c
   1400135dd:	mov    eax,0x27
   1400135e2:	lea    rcx,[rsp+0x260]
   1400135ea:	lea    rdx,[rsp+0x260]
   1400135f2:	sub    rbx,rdx
   1400135f5:	mov    r8,rax
   1400135f8:	sub    rax,0x1
   1400135fc:	je     0x140013610
   1400135fe:	movzx  edx,WORD PTR [rbx+rcx*1]
   140013602:	test   dx,dx
   140013605:	je     0x140013610
   140013607:	mov    WORD PTR [rcx],dx
   14001360a:	add    rcx,0x2
   14001360e:	jmp    0x1400135f5
   140013610:	lea    rax,[rcx-0x2]
   140013614:	test   r8,r8
   140013617:	cmovne rax,rcx
   14001361b:	mov    WORD PTR [rax],di
   14001361e:	je     0x14001364c
   140013620:	mov    WORD PTR [rsp+0x2ac],di
   140013628:	lea    rdx,[rsp+0x248]
   140013630:	lea    rcx,[rsp+0x260]
   140013638:	rex.W call QWORD PTR [rip+0x4a11]        # 0x140018050
   14001363f:	nop    DWORD PTR [rax+rax*1+0x0]
   140013644:	test   eax,eax
   140013646:	je     0x1400136d4
   14001364c:	lea    rax,[rip+0xac3d]        # 0x14001e290
   140013653:	mov    QWORD PTR [rsp+0x100],rax
   14001365b:	lea    rax,[rip+0xac8e]        # 0x14001e2f0
   140013662:	mov    QWORD PTR [rsp+0x108],rax
   14001366a:	lea    rax,[rip+0xac07]        # 0x14001e278
   140013671:	mov    QWORD PTR [rsp+0x110],rax
   140013679:	mov    DWORD PTR [rsp+0x118],0x6a4
   140013684:	mov    DWORD PTR [rsp+0x11c],0xb
   14001368f:	mov    DWORD PTR [rsp+0x120],r15d
   140013697:	mov    DWORD PTR [rsp+0x1a0],0x1000000
   1400136a2:	mov    r8,r12
   1400136a5:	xor    edx,edx
   1400136a7:	lea    rcx,[rsp+0x128]
   1400136af:	call   0x140015692
   1400136b4:	lea    r9,[rsp+0x2b0]
   1400136bc:	mov    r8,rsi
   1400136bf:	lea    rcx,[rsp+0x100]
   1400136c7:	call   0x1400132ec
   1400136cc:	lea    r14,[rsp+0x2b0]
   1400136d4:	mov    QWORD PTR [rsp+0x50],rdi
   1400136d9:	mov    WORD PTR [rsp+0x78],di
   1400136de:	mov    QWORD PTR [rsp+0x7c],rdi
   1400136e3:	mov    QWORD PTR [rsp+0x88],rdi
   1400136eb:	mov    QWORD PTR [rsp+0x90],rdi
   1400136f3:	mov    DWORD PTR [rsp+0x98],edi
   1400136fa:	mov    QWORD PTR [rsp+0xa0],rdi
   140013702:	mov    WORD PTR [rsp+0xa8],di
   14001370a:	mov    QWORD PTR [rsp+0xb8],rdi
   140013712:	lea    rax,[rip+0x3947]        # 0x140017060
   140013719:	mov    QWORD PTR [rsp+0xb0],rax
   140013721:	xorps  xmm0,xmm0
   140013724:	movups XMMWORD PTR [rsp+0x58],xmm0
   140013729:	movups XMMWORD PTR [rsp+0x68],xmm0
   14001372e:	mov    r8,r14
   140013731:	lea    rdx,[rsp+0x1c0]
   140013739:	lea    rcx,[rsp+0x50]
   14001373e:	call   0x140012aa8
   140013743:	mov    QWORD PTR [rsp+0x30],rdi
   140013748:	mov    BYTE PTR [rsp+0x28],dil
   14001374d:	mov    DWORD PTR [rsp+0x20],edi
   140013751:	mov    r9b,0x1
   140013754:	mov    r8d,0x534058
   14001375a:	lea    rdx,[rsp+0x1c0]
   140013762:	lea    rcx,[rsp+0x50]
   140013767:	call   0x140012ee0
   14001376c:	mov    r12,QWORD PTR [rsp+0xa0]
   140013774:	test   r12,r12
   140013777:	je     0x140013954
   14001377d:	mov    ebx,DWORD PTR [rsp+0x90]
   140013784:	lea    eax,[rbx+0x8]
   140013787:	cmp    eax,ebx
   140013789:	jb     0x14001395b
   14001378f:	cmp    eax,DWORD PTR [rsp+0x98]
   140013796:	ja     0x14001395b
   14001379c:	cmp    eax,DWORD PTR [rsp+0x94]
   1400137a3:	ja     0x140013b1b
   1400137a9:	mov    rbx,QWORD PTR [rbx+r12*1]
   1400137ad:	mov    DWORD PTR [rsp+0x90],eax
   1400137b4:	cmp    WORD PTR [rsp+0xa8],di
   1400137bc:	je     0x1400137d8
   1400137be:	lea    r8,[rsp+0x90]
   1400137c6:	lea    rdx,[rsp+0x1c0]
   1400137ce:	lea    rcx,[rsp+0x50]
   1400137d3:	call   0x1400129a4
   1400137d8:	lea    rax,[rip+0xaab1]        # 0x14001e290
   1400137df:	mov    QWORD PTR [rsp+0x100],rax
   1400137e7:	lea    rax,[rip+0xab02]        # 0x14001e2f0
   1400137ee:	mov    QWORD PTR [rsp+0x108],rax
   1400137f6:	lea    rax,[rip+0xaa7b]        # 0x14001e278
   1400137fd:	mov    QWORD PTR [rsp+0x110],rax
   140013805:	mov    DWORD PTR [rsp+0x118],0x6b9
   140013810:	mov    DWORD PTR [rsp+0x11c],0xb
   14001381b:	mov    DWORD PTR [rsp+0x120],r15d
   140013823:	mov    DWORD PTR [rsp+0x1a0],0x1000000
   14001382e:	xor    edx,edx
   140013830:	lea    r8d,[rdx+0x78]
   140013834:	lea    rcx,[rsp+0x128]
   14001383c:	call   0x140015692
   140013841:	mov    QWORD PTR [rsp+0x20],rbx
   140013846:	mov    r9,rsi
   140013849:	lea    r8,[rip+0xab00]        # 0x14001e350
   140013850:	lea    rdx,[rsp+0x100]
   140013858:	lea    rcx,[rsp+0x1c0]
   140013860:	call   0x140010510
   140013865:	nop
   140013866:	mov    rcx,QWORD PTR [rsp+0x50]
   14001386b:	test   rcx,rcx
   14001386e:	je     0x14001387c
   140013870:	rex.W call QWORD PTR [rip+0x46d1]        # 0x140017f48
   140013877:	nop    DWORD PTR [rax+rax*1+0x0]
   14001387c:	mov    QWORD PTR [rsp+0x50],rdi
   140013881:	mov    DWORD PTR [rsp+0x7c],edi
   140013885:	mov    DWORD PTR [rsp+0x90],edi
   14001388c:	mov    DWORD PTR [rsp+0x98],edi
   140013893:	mov    rcx,QWORD PTR [rsp+0x88]
   14001389b:	test   rcx,rcx
   14001389e:	je     0x1400138ac
   1400138a0:	rex.W call QWORD PTR [rip+0x49a1]        # 0x140018248
   1400138a7:	nop    DWORD PTR [rax+rax*1+0x0]
   1400138ac:	mov    QWORD PTR [rsp+0x88],rdi
   1400138b4:	mov    DWORD PTR [rsp+0x80],edi
   1400138bb:	mov    rcx,QWORD PTR [rsp+0xa0]
   1400138c3:	test   rcx,rcx
   1400138c6:	je     0x1400138d4
   1400138c8:	rex.W call QWORD PTR [rip+0x4979]        # 0x140018248
   1400138cf:	nop    DWORD PTR [rax+rax*1+0x0]
   1400138d4:	mov    QWORD PTR [rsp+0xa0],rdi
   1400138dc:	mov    DWORD PTR [rsp+0x94],edi
   1400138e3:	mov    rcx,QWORD PTR [rsp+0x70]
   1400138e8:	test   rcx,rcx
   1400138eb:	je     0x140013900
   1400138ed:	cmp    BYTE PTR [rsp+0x78],dil
   1400138f2:	je     0x140013900
   1400138f4:	rex.W call QWORD PTR [rip+0x464d]        # 0x140017f48
   1400138fb:	nop    DWORD PTR [rax+rax*1+0x0]
   140013900:	lea    rax,[rip+0x3759]        # 0x140017060
   140013907:	mov    QWORD PTR [rsp+0xb0],rax
   14001390f:	mov    rcx,QWORD PTR [rsp+0xb8]
   140013917:	test   rcx,rcx
   14001391a:	je     0x140013928
   14001391c:	rex.W call QWORD PTR [rip+0x475d]        # 0x140018080
   140013923:	nop    DWORD PTR [rax+rax*1+0x0]
   140013928:	mov    QWORD PTR [rsp+0xb8],rdi
   140013930:	lea    rax,[rip+0x3731]        # 0x140017068
   140013937:	mov    QWORD PTR [rsp+0xb0],rax
   14001393f:	lea    rcx,[rsp+0x1c0]
   140013947:	call   0x14000f958
   14001394c:	mov    rax,rbx
   14001394f:	jmp    0x140013ae2
   140013954:	mov    ebx,DWORD PTR [rsp+0x90]
   14001395b:	lea    r15,[rip+0xa18e]        # 0x14001daf0
   140013962:	mov    QWORD PTR [rsp+0x100],r15
   14001396a:	lea    rsi,[rip+0xade7]        # 0x14001e758
   140013971:	mov    QWORD PTR [rsp+0x108],rsi
   140013979:	lea    r14,[rip+0xa158]        # 0x14001dad8
   140013980:	mov    QWORD PTR [rsp+0x110],r14
   140013988:	mov    DWORD PTR [rsp+0x118],0x2e7
   140013993:	mov    DWORD PTR [rsp+0x11c],0xa
   14001399e:	mov    DWORD PTR [rsp+0x120],0xff
   1400139a9:	mov    DWORD PTR [rsp+0x1a0],0x1000000
   1400139b4:	xor    edx,edx
   1400139b6:	lea    r8d,[rdx+0x78]
   1400139ba:	lea    rcx,[rsp+0x128]
   1400139c2:	call   0x140015692
   1400139c7:	mov    DWORD PTR [rsp+0x30],ebx
   1400139cb:	mov    DWORD PTR [rsp+0x28],0x8
   1400139d3:	mov    DWORD PTR [rsp+0x20],ebx
   1400139d7:	mov    r9,r12
   1400139da:	lea    r8,[rip+0xadaf]        # 0x14001e790
   1400139e1:	lea    rdx,[rsp+0x100]
   1400139e9:	lea    rcx,[rsp+0x1c0]
   1400139f1:	call   0x140010510
   1400139f6:	mov    DWORD PTR [rsp+0x7c],edi
   1400139fa:	mov    DWORD PTR [rsp+0x90],edi
   140013a01:	mov    DWORD PTR [rsp+0x28],0xa
   140013a09:	mov    r9,rsi
   140013a0c:	mov    r8,r14
   140013a0f:	mov    rdx,r15
   140013a12:	lea    rcx,[rsp+0x100]
   140013a1a:	cmp    DWORD PTR [rsp+0x1e4],0x2
   140013a22:	jne    0x140013bbc
   140013a28:	jmp    0x140013b87
   140013a2d:	lea    rax,[rip+0xa85c]        # 0x14001e290
   140013a34:	mov    QWORD PTR [rsp+0x100],rax
   140013a3c:	lea    rax,[rip+0xa8ad]        # 0x14001e2f0
   140013a43:	mov    QWORD PTR [rsp+0x108],rax
   140013a4b:	lea    rax,[rip+0xa826]        # 0x14001e278
   140013a52:	mov    QWORD PTR [rsp+0x110],rax
   140013a5a:	mov    DWORD PTR [rsp+0x118],0x6c0
   140013a65:	mov    DWORD PTR [rsp+0x11c],0xb
   140013a70:	mov    DWORD PTR [rsp+0x120],0xff
   140013a7b:	mov    DWORD PTR [rsp+0x1a0],0x1000000
   140013a86:	xor    edx,edx
   140013a88:	lea    r8d,[rdx+0x78]
   140013a8c:	lea    rcx,[rsp+0x128]
   140013a94:	call   0x140015692
   140013a99:	mov    ebx,0x14000000
   140013a9e:	mov    QWORD PTR [rsp+0x28],rbx
   140013aa3:	mov    ecx,DWORD PTR [rsp+0x1c8]
   140013aaa:	mov    DWORD PTR [rsp+0x20],ecx
   140013aae:	mov    r9,QWORD PTR [rsp+0x1b0]
   140013ab6:	lea    r8,[rip+0xa8f3]        # 0x14001e3b0
   140013abd:	lea    rdx,[rsp+0x100]
   140013ac5:	lea    rcx,[rsp+0x1c0]
   140013acd:	call   0x140010510
   140013ad2:	nop
   140013ad3:	lea    rcx,[rsp+0x1c0]
   140013adb:	call   0x14000f958
   140013ae0:	mov    eax,ebx
   140013ae2:	mov    rcx,QWORD PTR [rsp+0x320]
   140013aea:	xor    rcx,rsp
   140013aed:	call   0x1400143c0
   140013af2:	lea    r11,[rsp+0x330]
   140013afa:	mov    rbx,QWORD PTR [r11+0x28]
   140013afe:	mov    rsi,QWORD PTR [r11+0x30]
   140013b02:	mov    rdi,QWORD PTR [r11+0x38]
   140013b06:	mov    rsp,r11
   140013b09:	pop    r15
   140013b0b:	pop    r14
   140013b0d:	pop    r12
   140013b0f:	ret
   140013b10:	int3
   140013b11:	jmp    0x140013a2d
   140013b16:	jmp    0x140013a2d
   140013b1b:	lea    rcx,[rsp+0x50]
   140013b20:	call   0x1400132dc
   140013b25:	mov    DWORD PTR [rsp+0x28],0xa
   140013b2d:	mov    DWORD PTR [rsp+0x20],0x300
   140013b35:	lea    r9,[rip+0xac1c]        # 0x14001e758
   140013b3c:	lea    r8,[rip+0x9f95]        # 0x14001dad8
   140013b43:	lea    rdx,[rip+0x9fa6]        # 0x14001daf0
   140013b4a:	lea    rcx,[rsp+0x100]
   140013b52:	call   0x14000f3ac
   140013b57:	mov    DWORD PTR [rsp+0x28],0x8
   140013b5f:	mov    ecx,DWORD PTR [rsp+0x90]
   140013b66:	mov    DWORD PTR [rsp+0x20],ecx
   140013b6a:	lea    r9,[rip+0xae1f]        # 0x14001e990
   140013b71:	mov    r8d,0x8007000e
   140013b77:	mov    rdx,rax
   140013b7a:	lea    rcx,[rsp+0x1c0]
   140013b82:	call   0x1400106b0
   140013b87:	mov    DWORD PTR [rsp+0x20],0x2f2
   140013b8f:	call   0x14000f3ac
   140013b94:	lea    rcx,[rip+0xad3d]        # 0x14001e8d8
   140013b9b:	mov    QWORD PTR [rsp+0x20],rcx
   140013ba0:	mov    r9d,0x80042306
   140013ba6:	mov    r8d,0x8000ffff
   140013bac:	mov    rdx,rax
   140013baf:	lea    rcx,[rsp+0x1c0]
   140013bb7:	call   0x140011164
   140013bbc:	mov    DWORD PTR [rsp+0x20],0x2f4
   140013bc4:	call   0x14000f3ac
   140013bc9:	mov    DWORD PTR [rsp+0x20],0x8
   140013bd1:	lea    r9,[rip+0xad38]        # 0x14001e910
   140013bd8:	mov    r8d,0x8000ffff
   140013bde:	mov    rdx,rax
   140013be1:	lea    rcx,[rsp+0x1c0]
   140013be9:	call   0x140010ee4
   140013bee:	int3
   140013bef:	int3
   140013bf0:	int3
   140013bf1:	int3
   140013bf2:	int3
   140013bf3:	int3
   140013bf4:	int3
   140013bf5:	int3
   140013bf6:	int3
   140013bf7:	int3
   140013bf8:	mov    r11,rsp
   140013bfb:	push   r13
   140013bfd:	push   r14
   140013bff:	push   r15
   140013c01:	sub    rsp,0x670
   140013c08:	mov    QWORD PTR [r11-0x518],0xfffffffffffffffe
   140013c13:	mov    QWORD PTR [r11+0x8],rbx
   140013c17:	mov    QWORD PTR [r11+0x10],rsi
   140013c1b:	mov    QWORD PTR [r11+0x18],rdi
   140013c1f:	mov    rax,QWORD PTR [rip+0x104f2]        # 0x140024118
   140013c26:	xor    rax,rsp
   140013c29:	mov    QWORD PTR [rsp+0x660],rax
   140013c31:	lea    rdi,[rip+0xa658]        # 0x14001e290
   140013c38:	mov    QWORD PTR [r11-0x4f8],rdi
   140013c3f:	lea    rsi,[rip+0xa82a]        # 0x14001e470
   140013c46:	mov    QWORD PTR [r11-0x4f0],rsi
   140013c4d:	lea    r14,[rip+0xa624]        # 0x14001e278
   140013c54:	mov    QWORD PTR [r11-0x4e8],r14
   140013c5b:	mov    DWORD PTR [rsp+0x1a8],0x6c7
   140013c66:	mov    r15d,0xb
   140013c6c:	mov    DWORD PTR [r11-0x4dc],r15d
   140013c73:	mov    DWORD PTR [rsp+0x1b0],0xff
   140013c7e:	xor    ebx,ebx
   140013c80:	mov    DWORD PTR [rsp+0x230],0x1000000
   140013c8b:	lea    r13d,[r15+0x6d]
   140013c8f:	mov    r8d,r13d
   140013c92:	xor    edx,edx
   140013c94:	lea    rcx,[r11-0x4d0]
   140013c9b:	call   0x140015692
   140013ca0:	lea    rdx,[rsp+0x190]
   140013ca8:	lea    rcx,[rsp+0x100]
   140013cb0:	call   0x14000f85c
   140013cb5:	nop
   140013cb6:	mov    edx,0x105
   140013cbb:	lea    rcx,[rsp+0x240]
   140013cc3:	rex.W call QWORD PTR [rip+0x4236]        # 0x140017f00
   140013cca:	nop    DWORD PTR [rax+rax*1+0x0]
   140013ccf:	mov    DWORD PTR [rsp+0x48],eax
   140013cd3:	test   eax,eax
   140013cd5:	je     0x140013f1e
   140013cdb:	mov    QWORD PTR [rsp+0x58],rdi
   140013ce0:	mov    QWORD PTR [rsp+0x60],rsi
   140013ce5:	mov    QWORD PTR [rsp+0x68],r14
   140013cea:	mov    DWORD PTR [rsp+0x70],0x6d2
   140013cf2:	mov    DWORD PTR [rsp+0x74],r15d
   140013cf7:	mov    DWORD PTR [rsp+0x78],0xff
   140013cff:	mov    DWORD PTR [rsp+0xf8],0x1000000
   140013d0a:	mov    r8,r13
   140013d0d:	xor    edx,edx
   140013d0f:	lea    rcx,[rsp+0x80]
   140013d17:	call   0x140015692
   140013d1c:	rex.W call QWORD PTR [rip+0x4255]        # 0x140017f78
   140013d23:	nop    DWORD PTR [rax+rax*1+0x0]
   140013d28:	mov    DWORD PTR [rsp+0x30],eax
   140013d2c:	mov    eax,DWORD PTR [rsp+0x48]
   140013d30:	mov    DWORD PTR [rsp+0x28],eax
   140013d34:	mov    DWORD PTR [rsp+0x20],0x105
   140013d3c:	lea    r9,[rsp+0x240]
   140013d44:	lea    r8,[rip+0xa7d5]        # 0x14001e520
   140013d4b:	lea    rdx,[rsp+0x58]
   140013d50:	lea    rcx,[rsp+0x100]
   140013d58:	call   0x140010510
   140013d5d:	xor    edx,edx
   140013d5f:	mov    r8d,0x20a
   140013d65:	lea    rcx,[rsp+0x450]
   140013d6d:	call   0x140015692
   140013d72:	mov    r8d,0x105
   140013d78:	lea    rdx,[rsp+0x450]
   140013d80:	lea    rcx,[rsp+0x240]
   140013d88:	rex.W call QWORD PTR [rip+0x4169]        # 0x140017ef8
   140013d8f:	nop    DWORD PTR [rax+rax*1+0x0]
   140013d94:	test   eax,eax
   140013d96:	je     0x140013f69
   140013d9c:	mov    r8d,0x32
   140013da2:	lea    rdx,[rsp+0x190]
   140013daa:	lea    rcx,[rsp+0x450]
   140013db2:	rex.W call QWORD PTR [rip+0x412f]        # 0x140017ee8
   140013db9:	nop    DWORD PTR [rax+rax*1+0x0]
   140013dbe:	test   eax,eax
   140013dc0:	je     0x140013fbd
   140013dc6:	mov    QWORD PTR [rsp+0x58],rdi
   140013dcb:	mov    QWORD PTR [rsp+0x60],rsi
   140013dd0:	mov    QWORD PTR [rsp+0x68],r14
   140013dd5:	mov    DWORD PTR [rsp+0x70],0x6e3
   140013ddd:	mov    DWORD PTR [rsp+0x74],r15d
   140013de2:	mov    DWORD PTR [rsp+0x78],0xff
   140013dea:	mov    DWORD PTR [rsp+0xf8],0x1000000
   140013df5:	mov    r8,r13
   140013df8:	xor    edx,edx
   140013dfa:	lea    rcx,[rsp+0x80]
   140013e02:	call   0x140015692
   140013e07:	lea    r9,[rsp+0x190]
   140013e0f:	lea    r8,[rip+0xa85a]        # 0x14001e670
   140013e16:	lea    rdx,[rsp+0x58]
   140013e1b:	lea    rcx,[rsp+0x100]
   140013e23:	call   0x140010510
   140013e28:	lea    rcx,[rsp+0x190]
   140013e30:	call   0x1400134c8
   140013e35:	mov    rbx,rax
   140013e38:	lea    rcx,[rsp+0x100]
   140013e40:	call   0x14000f958
   140013e45:	mov    rax,rbx
   140013e48:	jmp    0x140013ee5
   140013e4d:	lea    rdi,[rip+0xa43c]        # 0x14001e290
   140013e54:	mov    QWORD PTR [rsp+0x58],rdi
   140013e59:	lea    rsi,[rip+0xa610]        # 0x14001e470
   140013e60:	mov    QWORD PTR [rsp+0x60],rsi
   140013e65:	lea    r14,[rip+0xa40c]        # 0x14001e278
   140013e6c:	mov    QWORD PTR [rsp+0x68],r14
   140013e71:	mov    DWORD PTR [rsp+0x70],0x6e9
   140013e79:	mov    r15d,0xb
   140013e7f:	mov    DWORD PTR [rsp+0x74],r15d
   140013e84:	mov    DWORD PTR [rsp+0x78],0xff
   140013e8c:	mov    DWORD PTR [rsp+0xf8],0x1000000
   140013e97:	xor    edx,edx
   140013e99:	lea    r8d,[r15+0x6d]
   140013e9d:	lea    rcx,[rsp+0x80]
   140013ea5:	call   0x140015692
   140013eaa:	mov    ebx,0x14000000
   140013eaf:	mov    QWORD PTR [rsp+0x20],rbx
   140013eb4:	mov    r9d,DWORD PTR [rsp+0x108]
   140013ebc:	lea    r8,[rip+0xa7dd]        # 0x14001e6a0
   140013ec3:	lea    rdx,[rsp+0x58]
   140013ec8:	lea    rcx,[rsp+0x100]
   140013ed0:	call   0x140010510
   140013ed5:	nop
   140013ed6:	lea    rcx,[rsp+0x100]
   140013ede:	call   0x14000f958
   140013ee3:	mov    eax,ebx
   140013ee5:	mov    rcx,QWORD PTR [rsp+0x660]
   140013eed:	xor    rcx,rsp
   140013ef0:	call   0x1400143c0
   140013ef5:	lea    r11,[rsp+0x670]
   140013efd:	mov    rbx,QWORD PTR [r11+0x20]
   140013f01:	mov    rsi,QWORD PTR [r11+0x28]
   140013f05:	mov    rdi,QWORD PTR [r11+0x30]
   140013f09:	mov    rsp,r11
   140013f0c:	pop    r15
   140013f0e:	pop    r14
   140013f10:	pop    r13
   140013f12:	ret
   140013f13:	int3
   140013f14:	jmp    0x140013e4d
   140013f19:	jmp    0x140013e4d
   140013f1e:	mov    DWORD PTR [rsp+0x28],r15d
   140013f23:	mov    DWORD PTR [rsp+0x20],0x6d0
   140013f2b:	mov    r9,rsi
   140013f2e:	mov    r8,r14
   140013f31:	mov    rdx,rdi
   140013f34:	lea    rcx,[rsp+0x58]
   140013f39:	call   0x14000f3ac
   140013f3e:	mov    DWORD PTR [rsp+0x28],ebx
   140013f42:	mov    DWORD PTR [rsp+0x20],0x105
   140013f4a:	lea    r9,[rsp+0x240]
   140013f52:	lea    r8,[rip+0xa577]        # 0x14001e4d0
   140013f59:	mov    rdx,rax
   140013f5c:	lea    rcx,[rsp+0x100]
   140013f64:	call   0x140010ccc
   140013f69:	mov    DWORD PTR [rsp+0x28],r15d
   140013f6e:	mov    DWORD PTR [rsp+0x20],0x6db
   140013f76:	mov    r9,rsi
   140013f79:	mov    r8,r14
   140013f7c:	mov    rdx,rdi
   140013f7f:	lea    rcx,[rsp+0x58]
   140013f84:	call   0x14000f3ac
   140013f89:	mov    DWORD PTR [rsp+0x28],0x105
   140013f91:	lea    rcx,[rsp+0x450]
   140013f99:	mov    QWORD PTR [rsp+0x20],rcx
   140013f9e:	lea    r9,[rsp+0x240]
   140013fa6:	lea    r8,[rip+0xa5db]        # 0x14001e588
   140013fad:	mov    rdx,rax
   140013fb0:	lea    rcx,[rsp+0x100]
   140013fb8:	call   0x140010ccc
   140013fbd:	mov    DWORD PTR [rsp+0x28],r15d
   140013fc2:	mov    DWORD PTR [rsp+0x20],0x6e1
   140013fca:	mov    r9,rsi
   140013fcd:	mov    r8,r14
   140013fd0:	mov    rdx,rdi
   140013fd3:	lea    rcx,[rsp+0x58]
   140013fd8:	call   0x14000f3ac
   140013fdd:	lea    r9,[rsp+0x450]
   140013fe5:	lea    r8,[rip+0xa5e4]        # 0x14001e5d0
   140013fec:	mov    rdx,rax
   140013fef:	lea    rcx,[rsp+0x100]
   140013ff7:	call   0x140010ccc
   140013ffc:	int3
   140013ffd:	int3
   140013ffe:	int3
   140013fff:	int3
   140014000:	int3
   140014001:	int3
   140014002:	int3
   140014003:	int3
   140014004:	rex push rbx
   140014006:	sub    rsp,0x20
   14001400a:	mov    r8d,0x1
   140014010:	lea    rdx,[rip+0xffe9]        # 0x140024000
   140014017:	mov    rbx,rcx
   14001401a:	call   0x14001474d
   14001401f:	lea    rax,[rip+0x31aa]        # 0x1400171d0
   140014026:	mov    QWORD PTR [rbx],rax
   140014029:	mov    rax,rbx
   14001402c:	add    rsp,0x20
   140014030:	pop    rbx
   140014031:	ret
   140014032:	int3
   140014033:	int3
   140014034:	int3
   140014035:	int3
   140014036:	int3
   140014037:	int3
   140014038:	rex push rbx
   14001403a:	sub    rsp,0x40
   14001403e:	mov    rbx,rcx
   140014041:	jmp    0x140014052
   140014043:	mov    rcx,rbx
   140014046:	call   0x140014741
   14001404b:	test   eax,eax
   14001404d:	je     0x140014062
   14001404f:	mov    rcx,rbx
   140014052:	call   0x140014735
   140014057:	test   rax,rax
   14001405a:	je     0x140014043
   14001405c:	add    rsp,0x40
   140014060:	pop    rbx
   140014061:	ret
   140014062:	lea    rcx,[rsp+0x20]
   140014067:	call   0x140014004
   14001406c:	lea    rdx,[rip+0xe02d]        # 0x1400220a0
   140014073:	lea    rcx,[rsp+0x20]
   140014078:	call   0x14001478c
   14001407d:	int3
   14001407e:	int3
   14001407f:	int3
   140014080:	int3
   140014081:	int3
   140014082:	int3
   140014083:	int3
   140014084:	jmp    0x140014463
   140014089:	int3
   14001408a:	int3
   14001408b:	int3
   14001408c:	int3
   14001408d:	int3
   14001408e:	int3
   14001408f:	int3
   140014090:	sub    rsp,0x28
   140014094:	mov    eax,0x5a4d
   140014099:	cmp    WORD PTR [rip+0xfffffffffffebf60],ax        # 0x140000000
   1400140a0:	je     0x1400140a6
   1400140a2:	xor    eax,eax
   1400140a4:	jmp    0x1400140f9
   1400140a6:	movsxd rcx,DWORD PTR [rip+0xfffffffffffebf8f]        # 0x14000003c
   1400140ad:	lea    rax,[rip+0xfffffffffffebf4c]        # 0x140000000
   1400140b4:	add    rcx,rax
   1400140b7:	cmp    DWORD PTR [rcx],0x4550
   1400140bd:	jne    0x1400140a2
   1400140bf:	mov    eax,0x10b
   1400140c4:	cmp    WORD PTR [rcx+0x18],ax
   1400140c8:	je     0x1400140e8
   1400140ca:	mov    eax,0x20b
   1400140cf:	cmp    WORD PTR [rcx+0x18],ax
   1400140d3:	jne    0x1400140a2
   1400140d5:	xor    eax,eax
   1400140d7:	cmp    DWORD PTR [rcx+0x84],0xe
   1400140de:	jbe    0x1400140f9
   1400140e0:	cmp    DWORD PTR [rcx+0xf8],eax
   1400140e6:	jmp    0x1400140f6
   1400140e8:	xor    eax,eax
   1400140ea:	cmp    DWORD PTR [rcx+0x74],0xe
   1400140ee:	jbe    0x1400140f9
   1400140f0:	cmp    DWORD PTR [rcx+0xe8],eax
   1400140f6:	setne  al
   1400140f9:	mov    ecx,0x1
   1400140fe:	mov    DWORD PTR [rip+0x1005c],eax        # 0x140024160
   140014104:	call   0x140014868
   140014109:	mov    ecx,eax
   14001410b:	call   QWORD PTR [rip+0x4157]        # 0x140018268
   140014111:	mov    rcx,QWORD PTR [rip+0x4060]        # 0x140018178
   140014118:	or     rax,0xffffffffffffffff
   14001411c:	mov    QWORD PTR [rip+0x105f5],rax        # 0x140024718
   140014123:	mov    QWORD PTR [rip+0x105f6],rax        # 0x140024720
   14001412a:	mov    eax,DWORD PTR [rip+0x105bc]        # 0x1400246ec
   140014130:	mov    DWORD PTR [rcx],eax
   140014132:	mov    rcx,QWORD PTR [rip+0x4007]        # 0x140018140
   140014139:	mov    eax,DWORD PTR [rip+0x105a1]        # 0x1400246e0
   14001413f:	mov    DWORD PTR [rcx],eax
   140014141:	call   0x1400148c0
   140014146:	cmp    DWORD PTR [rip+0xffc3],0x0        # 0x140024110
   14001414d:	jne    0x14001415c
   14001414f:	lea    rcx,[rip+0x76a]        # 0x1400148c0
   140014156:	call   QWORD PTR [rip+0x3ffc]        # 0x140018158
   14001415c:	xor    eax,eax
   14001415e:	add    rsp,0x28
   140014162:	ret
   140014163:	int3
   140014164:	int3
   140014165:	int3
   140014166:	int3
   140014167:	int3
   140014168:	int3
   140014169:	int3
   14001416a:	int3
   14001416b:	int3
   14001416c:	int3
   14001416d:	int3
   14001416e:	int3
   14001416f:	int3
   140014170:	sub    rsp,0x38
   140014174:	mov    eax,DWORD PTR [rip+0x1056e]        # 0x1400246e8
   14001417a:	lea    r8,[rip+0xffd7]        # 0x140024158
   140014181:	mov    r9d,DWORD PTR [rip+0x1055c]        # 0x1400246e4
   140014188:	lea    rdx,[rip+0xffc1]        # 0x140024150
   14001418f:	mov    DWORD PTR [rip+0xffcf],eax        # 0x140024164
   140014195:	lea    rcx,[rip+0xffac]        # 0x140024148
   14001419c:	lea    rax,[rip+0xffc1]        # 0x140024164
   1400141a3:	mov    QWORD PTR [rsp+0x20],rax
   1400141a8:	call   QWORD PTR [rip+0x3fd2]        # 0x140018180
   1400141ae:	mov    DWORD PTR [rip+0xff98],eax        # 0x14002414c
   1400141b4:	add    rsp,0x38
   1400141b8:	ret
   1400141b9:	int3
   1400141ba:	int3
   1400141bb:	int3
   1400141bc:	int3
   1400141bd:	int3
   1400141be:	int3
   1400141bf:	int3
   1400141c0:	mov    QWORD PTR [rsp+0x8],rbx
   1400141c5:	mov    QWORD PTR [rsp+0x10],rsi
   1400141ca:	mov    QWORD PTR [rsp+0x18],rdi
   1400141cf:	push   r15
   1400141d1:	sub    rsp,0x30
   1400141d5:	mov    rax,QWORD PTR gs:0x30
   1400141de:	mov    rbx,QWORD PTR [rax+0x8]
   1400141e2:	xor    esi,esi
   1400141e4:	xor    eax,eax
   1400141e6:	lock cmpxchg QWORD PTR [rip+0x10539],rbx        # 0x140024728
   1400141ef:	je     0x14001420c
   1400141f1:	cmp    rax,rbx
   1400141f4:	jne    0x1400141ff
   1400141f6:	mov    ebx,0x1
   1400141fb:	mov    esi,ebx
   1400141fd:	jmp    0x140014211
   1400141ff:	mov    ecx,0x3e8
   140014204:	call   QWORD PTR [rip+0x3d26]        # 0x140017f30
   14001420a:	jmp    0x1400141e4
   14001420c:	mov    ebx,0x1
   140014211:	mov    eax,DWORD PTR [rip+0x10519]        # 0x140024730
   140014217:	cmp    eax,ebx
   140014219:	jne    0x140014227
   14001421b:	mov    ecx,0x1f
   140014220:	call   0x1400148b3
   140014225:	jmp    0x14001428c
   140014227:	mov    eax,DWORD PTR [rip+0x10503]        # 0x140024730
   14001422d:	test   eax,eax
   14001422f:	jne    0x140014286
   140014231:	mov    DWORD PTR [rip+0x104f9],ebx        # 0x140024730
   140014237:	lea    r15,[rip+0x409a]        # 0x1400182d8
   14001423e:	lea    rdi,[rip+0x407b]        # 0x1400182c0
   140014245:	mov    QWORD PTR [rsp+0x28],rdi
   14001424a:	mov    DWORD PTR [rsp+0x20],eax
   14001424e:	cmp    rdi,r15
   140014251:	jae    0x140014278
   140014253:	test   eax,eax
   140014255:	jne    0x14001427c
   140014257:	cmp    QWORD PTR [rdi],0x0
   14001425b:	je     0x14001426d
   14001425d:	mov    rax,QWORD PTR [rdi]
   140014260:	mov    rcx,QWORD PTR [rip+0x4031]        # 0x140018298
   140014267:	call   rcx
   140014269:	mov    DWORD PTR [rsp+0x20],eax
   14001426d:	add    rdi,0x8
   140014271:	mov    QWORD PTR [rsp+0x28],rdi
   140014276:	jmp    0x14001424e
   140014278:	test   eax,eax
   14001427a:	je     0x14001428c
   14001427c:	mov    eax,0xff
   140014281:	jmp    0x140014368
   140014286:	mov    DWORD PTR [rip+0xfeb8],ebx        # 0x140024144
   14001428c:	mov    eax,DWORD PTR [rip+0x1049e]        # 0x140024730
   140014292:	cmp    eax,ebx
   140014294:	jne    0x1400142b3
   140014296:	lea    rdx,[rip+0x401b]        # 0x1400182b8
   14001429d:	lea    rcx,[rip+0x3ffc]        # 0x1400182a0
   1400142a4:	call   0x140014a8e
   1400142a9:	mov    DWORD PTR [rip+0x1047d],0x2        # 0x140024730
   1400142b3:	test   esi,esi
   1400142b5:	jne    0x1400142c0
   1400142b7:	xor    eax,eax
   1400142b9:	xchg   QWORD PTR [rip+0x10468],rax        # 0x140024728
   1400142c0:	cmp    QWORD PTR [rip+0x10470],0x0        # 0x140024738
   1400142c8:	je     0x1400142f4
   1400142ca:	lea    rcx,[rip+0x10467]        # 0x140024738
   1400142d1:	call   0x140014920
   1400142d6:	test   eax,eax
   1400142d8:	je     0x1400142f4
   1400142da:	xor    r8d,r8d
   1400142dd:	lea    edx,[r8+0x2]
   1400142e1:	xor    ecx,ecx
   1400142e3:	mov    rax,QWORD PTR [rip+0x1044e]        # 0x140024738
   1400142ea:	mov    r9,QWORD PTR [rip+0x3fa7]        # 0x140018298
   1400142f1:	call   r9
   1400142f4:	mov    r8,QWORD PTR [rip+0xfe5d]        # 0x140024158
   1400142fb:	mov    rdx,QWORD PTR [rip+0xfe4e]        # 0x140024150
   140014302:	mov    ecx,DWORD PTR [rip+0xfe40]        # 0x140024148
   140014308:	call   0x14000341c
   14001430d:	mov    DWORD PTR [rip+0xfe2d],eax        # 0x140024140
   140014313:	cmp    DWORD PTR [rip+0xfe46],0x0        # 0x140024160
   14001431a:	jne    0x140014324
   14001431c:	mov    ecx,eax
   14001431e:	call   QWORD PTR [rip+0x3e4c]        # 0x140018170
   140014324:	cmp    DWORD PTR [rip+0xfe19],0x0        # 0x140024144
   14001432b:	jne    0x140014339
   14001432d:	call   QWORD PTR [rip+0x3e2d]        # 0x140018160
   140014333:	mov    eax,DWORD PTR [rip+0xfe07]        # 0x140024140
   140014339:	jmp    0x140014368
   14001433b:	mov    DWORD PTR [rip+0xfdff],eax        # 0x140024140
   140014341:	cmp    DWORD PTR [rip+0xfe18],0x0        # 0x140024160
   140014348:	jne    0x140014353
   14001434a:	mov    ecx,eax
   14001434c:	call   QWORD PTR [rip+0x3e16]        # 0x140018168
   140014352:	int3
   140014353:	cmp    DWORD PTR [rip+0xfdea],0x0        # 0x140024144
   14001435a:	jne    0x140014368
   14001435c:	call   QWORD PTR [rip+0x3dfe]        # 0x140018160
   140014362:	mov    eax,DWORD PTR [rip+0xfdd8]        # 0x140024140
   140014368:	mov    rbx,QWORD PTR [rsp+0x40]
   14001436d:	mov    rsi,QWORD PTR [rsp+0x48]
   140014372:	mov    rdi,QWORD PTR [rsp+0x50]
   140014377:	add    rsp,0x30
   14001437b:	pop    r15
   14001437d:	ret
   14001437e:	int3
   14001437f:	int3
   140014380:	int3
   140014381:	int3
   140014382:	int3
   140014383:	int3
   140014384:	int3
   140014385:	int3
   140014386:	int3
   140014387:	int3
   140014388:	int3
   140014389:	int3
   14001438a:	int3
   14001438b:	int3
   14001438c:	int3
   14001438d:	int3
   14001438e:	int3
   14001438f:	int3
   140014390:	sub    rsp,0x28
   140014394:	call   0x1400149b4
   140014399:	add    rsp,0x28
   14001439d:	jmp    0x1400141c0
   1400143a2:	int3
   1400143a3:	int3
   1400143a4:	int3
   1400143a5:	int3
   1400143a6:	int3
   1400143a7:	int3
   1400143a8:	jmp    QWORD PTR [rip+0x3eca]        # 0x140018278
   1400143ae:	int3
   1400143af:	int3
   1400143b0:	int3
   1400143b1:	int3
   1400143b2:	int3
   1400143b3:	int3
   1400143b4:	int3
   1400143b5:	int3
   1400143b6:	data16 nop WORD PTR [rax+rax*1+0x0]
   1400143c0:	cmp    rcx,QWORD PTR [rip+0xfd51]        # 0x140024118
   1400143c7:	jne    0x1400143d9
   1400143c9:	rol    rcx,0x10
   1400143cd:	test   cx,0xffff
   1400143d2:	jne    0x1400143d5
   1400143d4:	ret
   1400143d5:	ror    rcx,0x10
   1400143d9:	jmp    0x1400144c0
   1400143de:	int3
   1400143df:	int3
   1400143e0:	int3
   1400143e1:	int3
   1400143e2:	int3
   1400143e3:	int3
   1400143e4:	sub    rsp,0x28
   1400143e8:	call   QWORD PTR [rip+0x3d4a]        # 0x140018138
   1400143ee:	int3
   1400143ef:	int3
   1400143f0:	int3
   1400143f1:	int3
   1400143f2:	int3
   1400143f3:	int3
   1400143f4:	int3
   1400143f5:	int3
   1400143f6:	int3
   1400143f7:	int3
   1400143f8:	sub    rsp,0x38
   1400143fc:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140014405:	call   0x140014038
   14001440a:	nop
   14001440b:	jmp    0x140014412
   14001440d:	mov    rax,QWORD PTR [rsp+0x50]
   140014412:	add    rsp,0x38
   140014416:	ret
   140014417:	int3
   140014418:	int3
   140014419:	int3
   14001441a:	int3
   14001441b:	int3
   14001441c:	int3
   14001441d:	int3
   14001441e:	int3
   14001441f:	int3
   140014420:	mov    QWORD PTR [rsp+0x8],rbx
   140014425:	push   rdi
   140014426:	sub    rsp,0x20
   14001442a:	mov    ebx,edx
   14001442c:	mov    rdi,rcx
   14001442f:	call   QWORD PTR [rip+0x3cfb]        # 0x140018130
   140014435:	test   bl,0x1
   140014438:	je     0x140014442
   14001443a:	mov    rcx,rdi
   14001443d:	call   0x140014084
   140014442:	mov    rbx,QWORD PTR [rsp+0x30]
   140014447:	mov    rax,rdi
   14001444a:	add    rsp,0x20
   14001444e:	pop    rdi
   14001444f:	ret
   140014450:	int3
   140014451:	int3
   140014452:	int3
   140014453:	int3
   140014454:	int3
   140014455:	int3
   140014456:	int3
   140014457:	int3
   140014458:	jmp    0x1400143f8
   14001445d:	int3
   14001445e:	int3
   14001445f:	int3
   140014460:	int3
   140014461:	int3
   140014462:	int3
   140014463:	jmp    QWORD PTR [rip+0x3ddf]        # 0x140018248
   140014469:	int3
   14001446a:	int3
   14001446b:	int3
   14001446c:	int3
   14001446d:	int3
   14001446e:	int3
   14001446f:	int3
   140014470:	jmp    QWORD PTR [rip+0x3dca]        # 0x140018240
   140014476:	int3
   140014477:	int3
   140014478:	int3
   140014479:	int3
   14001447a:	int3
   14001447b:	int3
   14001447c:	rex push rbx
   14001447e:	sub    rsp,0x20
   140014482:	mov    rbx,rcx
   140014485:	xor    ecx,ecx
   140014487:	call   QWORD PTR [rip+0x3c0b]        # 0x140018098
   14001448d:	mov    rcx,rbx
   140014490:	call   QWORD PTR [rip+0x3c0a]        # 0x1400180a0
   140014496:	call   QWORD PTR [rip+0x3abc]        # 0x140017f58
   14001449c:	mov    rcx,rax
   14001449f:	mov    edx,0xc0000409
   1400144a4:	add    rsp,0x20
   1400144a8:	pop    rbx
   1400144a9:	rex.W jmp QWORD PTR [rip+0x3c10]        # 0x1400180c0
   1400144b0:	int3
   1400144b1:	int3
   1400144b2:	int3
   1400144b3:	int3
   1400144b4:	int3
   1400144b5:	int3
   1400144b6:	int3
   1400144b7:	int3
   1400144b8:	int3
   1400144b9:	int3
   1400144ba:	int3
   1400144bb:	int3
   1400144bc:	int3
   1400144bd:	int3
   1400144be:	int3
   1400144bf:	int3
   1400144c0:	mov    QWORD PTR [rsp+0x8],rcx
   1400144c5:	sub    rsp,0x88
   1400144cc:	lea    rcx,[rip+0xfd3d]        # 0x140024210
   1400144d3:	call   QWORD PTR [rip+0x3c0f]        # 0x1400180e8
   1400144d9:	mov    rax,QWORD PTR [rip+0xfe28]        # 0x140024308
   1400144e0:	mov    QWORD PTR [rsp+0x48],rax
   1400144e5:	xor    r8d,r8d
   1400144e8:	lea    rdx,[rsp+0x50]
   1400144ed:	mov    rcx,QWORD PTR [rsp+0x48]
   1400144f2:	call   QWORD PTR [rip+0x3be8]        # 0x1400180e0
   1400144f8:	mov    QWORD PTR [rsp+0x40],rax
   1400144fd:	cmp    QWORD PTR [rsp+0x40],0x0
   140014503:	je     0x140014547
   140014505:	mov    QWORD PTR [rsp+0x38],0x0
   14001450e:	lea    rax,[rsp+0x58]
   140014513:	mov    QWORD PTR [rsp+0x30],rax
   140014518:	lea    rax,[rsp+0x60]
   14001451d:	mov    QWORD PTR [rsp+0x28],rax
   140014522:	lea    rax,[rip+0xfce7]        # 0x140024210
   140014529:	mov    QWORD PTR [rsp+0x20],rax
   14001452e:	mov    r9,QWORD PTR [rsp+0x40]
   140014533:	mov    r8,QWORD PTR [rsp+0x48]
   140014538:	mov    rdx,QWORD PTR [rsp+0x50]
   14001453d:	xor    ecx,ecx
   14001453f:	call   QWORD PTR [rip+0x3bab]        # 0x1400180f0
   140014545:	jmp    0x14001456a
   140014547:	mov    rax,QWORD PTR [rip+0xfd5a]        # 0x1400242a8
   14001454e:	mov    rax,QWORD PTR [rax]
   140014551:	mov    QWORD PTR [rip+0xfdb0],rax        # 0x140024308
   140014558:	mov    rax,QWORD PTR [rip+0xfd49]        # 0x1400242a8
   14001455f:	add    rax,0x8
   140014563:	mov    QWORD PTR [rip+0xfd3e],rax        # 0x1400242a8
   14001456a:	mov    rax,QWORD PTR [rip+0xfd97]        # 0x140024308
   140014571:	mov    QWORD PTR [rip+0xfc08],rax        # 0x140024180
   140014578:	mov    rax,QWORD PTR [rsp+0x90]
   140014580:	mov    QWORD PTR [rip+0xfd09],rax        # 0x140024290
   140014587:	mov    DWORD PTR [rip+0xfbdf],0xc0000409        # 0x140024170
   140014591:	mov    DWORD PTR [rip+0xfbd9],0x1        # 0x140024174
   14001459b:	mov    DWORD PTR [rip+0xfbe3],0x3        # 0x140024188
   1400145a5:	mov    eax,0x8
   1400145aa:	imul   rax,rax,0x0
   1400145ae:	lea    rcx,[rip+0xfbdb]        # 0x140024190
   1400145b5:	mov    QWORD PTR [rcx+rax*1],0x2
   1400145bd:	mov    eax,0x8
   1400145c2:	imul   rax,rax,0x1
   1400145c6:	lea    rcx,[rip+0xfbc3]        # 0x140024190
   1400145cd:	mov    rdx,QWORD PTR [rip+0xfb44]        # 0x140024118
   1400145d4:	mov    QWORD PTR [rcx+rax*1],rdx
   1400145d8:	mov    eax,0x8
   1400145dd:	imul   rax,rax,0x2
   1400145e1:	lea    rcx,[rip+0xfba8]        # 0x140024190
   1400145e8:	mov    rdx,QWORD PTR [rip+0xfb31]        # 0x140024120
   1400145ef:	mov    QWORD PTR [rcx+rax*1],rdx
   1400145f3:	mov    eax,0x8
   1400145f8:	imul   rax,rax,0x0
   1400145fc:	mov    rcx,QWORD PTR [rip+0xfb15]        # 0x140024118
   140014603:	mov    QWORD PTR [rsp+rax*1+0x68],rcx
   140014608:	mov    eax,0x8
   14001460d:	imul   rax,rax,0x1
   140014611:	mov    rcx,QWORD PTR [rip+0xfb08]        # 0x140024120
   140014618:	mov    QWORD PTR [rsp+rax*1+0x68],rcx
   14001461d:	lea    rcx,[rip+0x29e4]        # 0x140017008
   140014624:	call   0x14001447c
   140014629:	add    rsp,0x88
   140014630:	ret
   140014631:	int3
   140014632:	int3
   140014633:	int3
   140014634:	int3
   140014635:	int3
   140014636:	int3
   140014637:	int3
   140014638:	sub    rsp,0x78
   14001463c:	lea    rcx,[rip+0xfbcd]        # 0x140024210
   140014643:	call   QWORD PTR [rip+0x3a9f]        # 0x1400180e8
   140014649:	mov    rax,QWORD PTR [rip+0xfcb8]        # 0x140024308
   140014650:	mov    QWORD PTR [rsp+0x48],rax
   140014655:	xor    r8d,r8d
   140014658:	lea    rdx,[rsp+0x50]
   14001465d:	mov    rcx,QWORD PTR [rsp+0x48]
   140014662:	call   QWORD PTR [rip+0x3a78]        # 0x1400180e0
   140014668:	mov    QWORD PTR [rsp+0x40],rax
   14001466d:	cmp    QWORD PTR [rsp+0x40],0x0
   140014673:	je     0x1400146b7
   140014675:	mov    QWORD PTR [rsp+0x38],0x0
   14001467e:	lea    rax,[rsp+0x58]
   140014683:	mov    QWORD PTR [rsp+0x30],rax
   140014688:	lea    rax,[rsp+0x60]
   14001468d:	mov    QWORD PTR [rsp+0x28],rax
   140014692:	lea    rax,[rip+0xfb77]        # 0x140024210
   140014699:	mov    QWORD PTR [rsp+0x20],rax
   14001469e:	mov    r9,QWORD PTR [rsp+0x40]
   1400146a3:	mov    r8,QWORD PTR [rsp+0x48]
   1400146a8:	mov    rdx,QWORD PTR [rsp+0x50]
   1400146ad:	xor    ecx,ecx
   1400146af:	call   QWORD PTR [rip+0x3a3b]        # 0x1400180f0
   1400146b5:	jmp    0x1400146da
   1400146b7:	mov    rax,QWORD PTR [rip+0xfbea]        # 0x1400242a8
   1400146be:	mov    rax,QWORD PTR [rax]
   1400146c1:	mov    QWORD PTR [rip+0xfc40],rax        # 0x140024308
   1400146c8:	mov    rax,QWORD PTR [rip+0xfbd9]        # 0x1400242a8
   1400146cf:	add    rax,0x8
   1400146d3:	mov    QWORD PTR [rip+0xfbce],rax        # 0x1400242a8
   1400146da:	mov    rax,QWORD PTR [rip+0xfc27]        # 0x140024308
   1400146e1:	mov    QWORD PTR [rip+0xfa98],rax        # 0x140024180
   1400146e8:	mov    DWORD PTR [rip+0xfa7e],0xc0000409        # 0x140024170
   1400146f2:	mov    DWORD PTR [rip+0xfa78],0x1        # 0x140024174
   1400146fc:	mov    DWORD PTR [rip+0xfa82],0x1        # 0x140024188
   140014706:	mov    eax,0x8
   14001470b:	imul   rax,rax,0x0
   14001470f:	lea    rcx,[rip+0xfa7a]        # 0x140024190
   140014716:	mov    QWORD PTR [rcx+rax*1],0x8
   14001471e:	lea    rcx,[rip+0x28e3]        # 0x140017008
   140014725:	call   0x14001447c
   14001472a:	add    rsp,0x78
   14001472e:	ret
   14001472f:	int3
   140014730:	int3
   140014731:	int3
   140014732:	int3
   140014733:	int3
   140014734:	int3
   140014735:	jmp    QWORD PTR [rip+0x3a8d]        # 0x1400181c8
   14001473b:	int3
   14001473c:	int3
   14001473d:	int3
   14001473e:	int3
   14001473f:	int3
   140014740:	int3
   140014741:	jmp    QWORD PTR [rip+0x3a79]        # 0x1400181c0
   140014747:	int3
   140014748:	int3
   140014749:	int3
   14001474a:	int3
   14001474b:	int3
   14001474c:	int3
   14001474d:	jmp    QWORD PTR [rip+0x3a65]        # 0x1400181b8
   140014753:	int3
   140014754:	int3
   140014755:	int3
   140014756:	int3
   140014757:	int3
   140014758:	int3
   140014759:	jmp    QWORD PTR [rip+0x3a51]        # 0x1400181b0
   14001475f:	int3
   140014760:	int3
   140014761:	int3
   140014762:	int3
   140014763:	int3
   140014764:	int3
   140014765:	jmp    QWORD PTR [rip+0x3a3d]        # 0x1400181a8
   14001476b:	int3
   14001476c:	int3
   14001476d:	int3
   14001476e:	int3
   14001476f:	int3
   140014770:	int3
   140014771:	int3
   140014772:	int3
   140014773:	int3
   140014774:	int3
   140014775:	int3
   140014776:	int3
   140014777:	int3
   140014778:	int3
   140014779:	int3
   14001477a:	int3
   14001477b:	int3
   14001477c:	int3
   14001477d:	int3
   14001477e:	int3
   14001477f:	int3
   140014780:	jmp    QWORD PTR [rip+0x3a1a]        # 0x1400181a0
   140014786:	int3
   140014787:	int3
   140014788:	int3
   140014789:	int3
   14001478a:	int3
   14001478b:	int3
   14001478c:	jmp    QWORD PTR [rip+0x3a06]        # 0x140018198
   140014792:	int3
   140014793:	int3
   140014794:	int3
   140014795:	int3
   140014796:	int3
   140014797:	int3
   140014798:	int3
   140014799:	int3
   14001479a:	int3
   14001479b:	int3
   14001479c:	int3
   14001479d:	int3
   14001479e:	int3
   14001479f:	int3
   1400147a0:	sub    rsp,0x28
   1400147a4:	mov    rax,QWORD PTR [rcx]
   1400147a7:	cmp    DWORD PTR [rax],0xe06d7363
   1400147ad:	jne    0x1400147d2
   1400147af:	cmp    DWORD PTR [rax+0x18],0x4
   1400147b3:	jne    0x1400147d2
   1400147b5:	mov    ecx,DWORD PTR [rax+0x20]
   1400147b8:	lea    eax,[rcx-0x19930520]
   1400147be:	cmp    eax,0x2
   1400147c1:	jbe    0x1400147cb
   1400147c3:	cmp    ecx,0x1994000
   1400147c9:	jne    0x1400147d2
   1400147cb:	call   QWORD PTR [rip+0x3967]        # 0x140018138
   1400147d1:	int3
   1400147d2:	xor    eax,eax
   1400147d4:	add    rsp,0x28
   1400147d8:	ret
   1400147d9:	int3
   1400147da:	int3
   1400147db:	int3
   1400147dc:	int3
   1400147dd:	int3
   1400147de:	int3
   1400147df:	int3
   1400147e0:	sub    rsp,0x28
   1400147e4:	lea    rcx,[rip+0xffffffffffffffb5]        # 0x1400147a0
   1400147eb:	call   QWORD PTR [rip+0x38a7]        # 0x140018098
   1400147f1:	xor    eax,eax
   1400147f3:	add    rsp,0x28
   1400147f7:	ret
   1400147f8:	int3
   1400147f9:	int3
   1400147fa:	int3
   1400147fb:	int3
   1400147fc:	int3
   1400147fd:	int3
   1400147fe:	jmp    QWORD PTR [rip+0x398c]        # 0x140018190
   140014804:	int3
   140014805:	int3
   140014806:	int3
   140014807:	int3
   140014808:	int3
   140014809:	int3
   14001480a:	int3
   14001480b:	int3
   14001480c:	sub    rsp,0x18
   140014810:	xor    edx,edx
   140014812:	lea    rax,[rcx-0x1]
   140014816:	cmp    rax,0xfffffffffffffffd
   14001481a:	ja     0x140014858
   14001481c:	mov    eax,0x5a4d
   140014821:	cmp    WORD PTR [rcx],ax
   140014824:	jne    0x140014850
   140014826:	cmp    DWORD PTR [rcx+0x3c],edx
   140014829:	jl     0x140014850
   14001482b:	cmp    DWORD PTR [rcx+0x3c],0x10000000
   140014832:	jae    0x140014850
   140014834:	movsxd rax,DWORD PTR [rcx+0x3c]
   140014838:	add    rax,rcx
   14001483b:	mov    QWORD PTR [rsp],rax
   14001483f:	cmp    DWORD PTR [rax],0x4550
   140014845:	cmovne rax,rdx
   140014849:	mov    rdx,rax
   14001484c:	mov    QWORD PTR [rsp],rax
   140014850:	jmp    0x140014858
   140014852:	xor    edx,edx
   140014854:	mov    QWORD PTR [rsp],rdx
   140014858:	mov    rax,rdx
   14001485b:	add    rsp,0x18
   14001485f:	ret
   140014860:	int3
   140014861:	int3
   140014862:	int3
   140014863:	int3
   140014864:	int3
   140014865:	int3
   140014866:	int3
   140014867:	int3
   140014868:	rex push rbx
   14001486a:	sub    rsp,0x20
   14001486e:	mov    ebx,ecx
   140014870:	xor    ecx,ecx
   140014872:	call   QWORD PTR [rip+0x3678]        # 0x140017ef0
   140014878:	test   rax,rax
   14001487b:	je     0x1400148a5
   14001487d:	mov    rcx,rax
   140014880:	call   0x14001480c
   140014885:	test   rax,rax
   140014888:	je     0x1400148a5
   14001488a:	mov    ecx,0x2
   14001488f:	cmp    WORD PTR [rax+0x5c],cx
   140014893:	jne    0x140014899
   140014895:	mov    eax,ecx
   140014897:	jmp    0x1400148a7
   140014899:	cmp    WORD PTR [rax+0x5c],0x3
   14001489e:	mov    eax,0x1
   1400148a3:	je     0x1400148a7
   1400148a5:	mov    eax,ebx
   1400148a7:	add    rsp,0x20
   1400148ab:	pop    rbx
   1400148ac:	ret
   1400148ad:	int3
   1400148ae:	int3
   1400148af:	int3
   1400148b0:	int3
   1400148b1:	int3
   1400148b2:	int3
   1400148b3:	jmp    QWORD PTR [rip+0x38cf]        # 0x140018188
   1400148b9:	int3
   1400148ba:	int3
   1400148bb:	int3
   1400148bc:	int3
   1400148bd:	int3
   1400148be:	int3
   1400148bf:	int3
   1400148c0:	xor    eax,eax
   1400148c2:	ret
   1400148c3:	int3
   1400148c4:	int3
   1400148c5:	int3
   1400148c6:	int3
   1400148c7:	int3
   1400148c8:	int3
   1400148c9:	int3
   1400148ca:	int3
   1400148cb:	int3
   1400148cc:	int3
   1400148cd:	int3
   1400148ce:	int3
   1400148cf:	int3
   1400148d0:	movsxd r8,DWORD PTR [rcx+0x3c]
   1400148d4:	xor    r9d,r9d
   1400148d7:	add    r8,rcx
   1400148da:	mov    r10,rdx
   1400148dd:	movzx  eax,WORD PTR [r8+0x14]
   1400148e2:	movzx  r11d,WORD PTR [r8+0x6]
   1400148e7:	add    rax,0x18
   1400148eb:	add    rax,r8
   1400148ee:	test   r11d,r11d
   1400148f1:	je     0x140014911
   1400148f3:	mov    edx,DWORD PTR [rax+0xc]
   1400148f6:	cmp    r10,rdx
   1400148f9:	jb     0x140014905
   1400148fb:	mov    ecx,DWORD PTR [rax+0x8]
   1400148fe:	add    ecx,edx
   140014900:	cmp    r10,rcx
   140014903:	jb     0x140014913
   140014905:	inc    r9d
   140014908:	add    rax,0x28
   14001490c:	cmp    r9d,r11d
   14001490f:	jb     0x1400148f3
   140014911:	xor    eax,eax
   140014913:	ret
   140014914:	int3
   140014915:	int3
   140014916:	int3
   140014917:	int3
   140014918:	int3
   140014919:	int3
   14001491a:	int3
   14001491b:	int3
   14001491c:	int3
   14001491d:	int3
   14001491e:	int3
   14001491f:	int3
   140014920:	mov    QWORD PTR [rsp+0x8],rbx
   140014925:	push   rdi
   140014926:	sub    rsp,0x20
   14001492a:	mov    rbx,rcx
   14001492d:	lea    rdi,[rip+0xfffffffffffeb6cc]        # 0x140000000
   140014934:	mov    rcx,rdi
   140014937:	call   0x140014980
   14001493c:	test   eax,eax
   14001493e:	je     0x140014962
   140014940:	sub    rbx,rdi
   140014943:	mov    rdx,rbx
   140014946:	mov    rcx,rdi
   140014949:	call   0x1400148d0
   14001494e:	test   rax,rax
   140014951:	je     0x140014962
   140014953:	mov    eax,DWORD PTR [rax+0x24]
   140014956:	shr    eax,0x1f
   140014959:	not    eax
   14001495b:	and    eax,0x1
   14001495e:	jmp    0x140014962
   140014960:	xor    eax,eax
   140014962:	mov    rbx,QWORD PTR [rsp+0x30]
   140014967:	add    rsp,0x20
   14001496b:	pop    rdi
   14001496c:	ret
   14001496d:	int3
   14001496e:	int3
   14001496f:	int3
   140014970:	int3
   140014971:	int3
   140014972:	int3
   140014973:	int3
   140014974:	int3
   140014975:	int3
   140014976:	int3
   140014977:	int3
   140014978:	int3
   140014979:	int3
   14001497a:	int3
   14001497b:	int3
   14001497c:	int3
   14001497d:	int3
   14001497e:	int3
   14001497f:	int3
   140014980:	mov    eax,0x5a4d
   140014985:	cmp    WORD PTR [rcx],ax
   140014988:	jne    0x1400149aa
   14001498a:	movsxd rax,DWORD PTR [rcx+0x3c]
   14001498e:	add    rax,rcx
   140014991:	cmp    DWORD PTR [rax],0x4550
   140014997:	jne    0x1400149aa
   140014999:	mov    ecx,0x20b
   14001499e:	cmp    WORD PTR [rax+0x18],cx
   1400149a2:	jne    0x1400149aa
   1400149a4:	mov    eax,0x1
   1400149a9:	ret
   1400149aa:	xor    eax,eax
   1400149ac:	ret
   1400149ad:	int3
   1400149ae:	int3
   1400149af:	int3
   1400149b0:	int3
   1400149b1:	int3
   1400149b2:	int3
   1400149b3:	int3
   1400149b4:	mov    QWORD PTR [rsp+0x20],rbx
   1400149b9:	push   rbp
   1400149ba:	mov    rbp,rsp
   1400149bd:	sub    rsp,0x20
   1400149c1:	and    QWORD PTR [rbp+0x18],0x0
   1400149c6:	movabs rbx,0x2b992ddfa232
   1400149d0:	mov    rax,QWORD PTR [rip+0xf741]        # 0x140024118
   1400149d7:	cmp    rax,rbx
   1400149da:	jne    0x140014a73
   1400149e0:	lea    rcx,[rbp+0x18]
   1400149e4:	call   QWORD PTR [rip+0x3716]        # 0x140018100
   1400149ea:	mov    rax,QWORD PTR [rbp+0x18]
   1400149ee:	mov    QWORD PTR [rbp+0x10],rax
   1400149f2:	call   QWORD PTR [rip+0x36d0]        # 0x1400180c8
   1400149f8:	mov    eax,eax
   1400149fa:	xor    QWORD PTR [rbp+0x10],rax
   1400149fe:	call   QWORD PTR [rip+0x36cc]        # 0x1400180d0
   140014a04:	mov    eax,eax
   140014a06:	xor    QWORD PTR [rbp+0x10],rax
   140014a0a:	call   QWORD PTR [rip+0x3528]        # 0x140017f38
   140014a10:	mov    eax,eax
   140014a12:	shl    rax,0x18
   140014a16:	xor    QWORD PTR [rbp+0x10],rax
   140014a1a:	call   QWORD PTR [rip+0x3518]        # 0x140017f38
   140014a20:	mov    eax,eax
   140014a22:	lea    rcx,[rbp+0x10]
   140014a26:	xor    rax,QWORD PTR [rbp+0x10]
   140014a2a:	xor    rax,rcx
   140014a2d:	lea    rcx,[rbp+0x20]
   140014a31:	mov    QWORD PTR [rbp+0x10],rax
   140014a35:	call   QWORD PTR [rip+0x3505]        # 0x140017f40
   140014a3b:	mov    eax,DWORD PTR [rbp+0x20]
   140014a3e:	movabs rcx,0xffffffffffff
   140014a48:	shl    rax,0x20
   140014a4c:	xor    rax,QWORD PTR [rbp+0x20]
   140014a50:	xor    rax,QWORD PTR [rbp+0x10]
   140014a54:	and    rax,rcx
   140014a57:	mov    rcx,rax
   140014a5a:	cmp    rax,rbx
   140014a5d:	jne    0x140014a6c
   140014a5f:	movabs rax,0x2b992ddfa233
   140014a69:	mov    rcx,rax
   140014a6c:	mov    QWORD PTR [rip+0xf6a5],rcx        # 0x140024118
   140014a73:	mov    rbx,QWORD PTR [rsp+0x48]
   140014a78:	not    rax
   140014a7b:	mov    QWORD PTR [rip+0xf69e],rax        # 0x140024120
   140014a82:	add    rsp,0x20
   140014a86:	pop    rbp
   140014a87:	ret
   140014a88:	int3
   140014a89:	int3
   140014a8a:	int3
   140014a8b:	int3
   140014a8c:	int3
   140014a8d:	int3
   140014a8e:	jmp    QWORD PTR [rip+0x36bc]        # 0x140018150
   140014a94:	int3
   140014a95:	int3
   140014a96:	int3
   140014a97:	int3
   140014a98:	int3
   140014a99:	int3
   140014a9a:	jmp    QWORD PTR [rip+0x36a8]        # 0x140018148
   140014aa0:	int3
   140014aa1:	int3
   140014aa2:	int3
   140014aa3:	int3
   140014aa4:	int3
   140014aa5:	int3
   140014aa6:	int3
   140014aa7:	int3
   140014aa8:	int3
   140014aa9:	int3
   140014aaa:	int3
   140014aab:	int3
   140014aac:	int3
   140014aad:	int3
   140014aae:	int3
   140014aaf:	int3
   140014ab0:	ret    0x0
   140014ab3:	int3
   140014ab4:	int3
   140014ab5:	int3
   140014ab6:	int3
   140014ab7:	int3
   140014ab8:	int3
   140014ab9:	int3
   140014aba:	int3
   140014abb:	int3
   140014abc:	int3
   140014abd:	int3
   140014abe:	int3
   140014abf:	int3
   140014ac0:	int3
   140014ac1:	int3
   140014ac2:	int3
   140014ac3:	int3
   140014ac4:	int3
   140014ac5:	int3
   140014ac6:	int3
   140014ac7:	int3
   140014ac8:	rex push rbx
   140014aca:	sub    rsp,0x20
   140014ace:	xor    eax,eax
   140014ad0:	mov    QWORD PTR [rcx+0x20],0xf
   140014ad8:	mov    QWORD PTR [rcx+0x18],rax
   140014adc:	mov    rbx,rcx
   140014adf:	mov    BYTE PTR [rcx+0x8],al
   140014ae2:	or     r8,0xffffffffffffffff
   140014ae6:	inc    r8
   140014ae9:	cmp    BYTE PTR [rdx+r8*1],al
   140014aed:	jne    0x140014ae6
   140014aef:	call   0x140015240
   140014af4:	mov    rax,rbx
   140014af7:	add    rsp,0x20
   140014afb:	pop    rbx
   140014afc:	ret
   140014afd:	int3
   140014afe:	int3
   140014aff:	int3
   140014b00:	int3
   140014b01:	int3
   140014b02:	int3
   140014b03:	int3
   140014b04:	mov    QWORD PTR [rsp+0x8],rcx
   140014b09:	push   rdi
   140014b0a:	sub    rsp,0x30
   140014b0e:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140014b17:	mov    QWORD PTR [rsp+0x48],rbx
   140014b1c:	mov    rbx,rdx
   140014b1f:	mov    rdi,rcx
   140014b22:	call   0x140014759
   140014b27:	nop
   140014b28:	lea    rax,[rip+0x24e9]        # 0x140017018
   140014b2f:	mov    QWORD PTR [rdi],rax
   140014b32:	lea    rcx,[rdi+0x18]
   140014b36:	mov    QWORD PTR [rcx+0x20],0xf
   140014b3e:	and    QWORD PTR [rcx+0x18],0x0
   140014b43:	mov    BYTE PTR [rcx+0x8],0x0
   140014b47:	lea    rdx,[rbx+0x18]
   140014b4b:	or     r9,0xffffffffffffffff
   140014b4f:	xor    r8d,r8d
   140014b52:	call   0x140015140
   140014b57:	nop
   140014b58:	lea    rax,[rip+0x24d1]        # 0x140017030
   140014b5f:	mov    QWORD PTR [rdi],rax
   140014b62:	mov    rax,rdi
   140014b65:	mov    rbx,QWORD PTR [rsp+0x48]
   140014b6a:	add    rsp,0x30
   140014b6e:	pop    rdi
   140014b6f:	ret
   140014b70:	int3
   140014b71:	int3
   140014b72:	int3
   140014b73:	int3
   140014b74:	int3
   140014b75:	int3
   140014b76:	int3
   140014b77:	int3
   140014b78:	mov    rax,rsp
   140014b7b:	mov    QWORD PTR [rax+0x8],rcx
   140014b7f:	push   rdi
   140014b80:	sub    rsp,0x30
   140014b84:	mov    QWORD PTR [rax-0x18],0xfffffffffffffffe
   140014b8c:	mov    QWORD PTR [rax+0x10],rbx
   140014b90:	mov    QWORD PTR [rax+0x18],rsi
   140014b94:	mov    rdi,rdx
   140014b97:	mov    rsi,rcx
   140014b9a:	call   0x140015563
   140014b9f:	nop
   140014ba0:	lea    rax,[rip+0x2471]        # 0x140017018
   140014ba7:	mov    QWORD PTR [rsi],rax
   140014baa:	xor    r8d,r8d
   140014bad:	xor    edx,edx
   140014baf:	lea    rcx,[rsi+0x18]
   140014bb3:	call   0x140015018
   140014bb8:	or     r9,0xffffffffffffffff
   140014bbc:	xor    r8d,r8d
   140014bbf:	mov    rdx,rdi
   140014bc2:	lea    rcx,[rsi+0x18]
   140014bc6:	call   0x140015140
   140014bcb:	nop
   140014bcc:	lea    rax,[rip+0x245d]        # 0x140017030
   140014bd3:	mov    QWORD PTR [rsi],rax
   140014bd6:	mov    rax,rsi
   140014bd9:	mov    rbx,QWORD PTR [rsp+0x48]
   140014bde:	mov    rsi,QWORD PTR [rsp+0x50]
   140014be3:	add    rsp,0x30
   140014be7:	pop    rdi
   140014be8:	ret
   140014be9:	int3
   140014bea:	int3
   140014beb:	int3
   140014bec:	int3
   140014bed:	int3
   140014bee:	int3
   140014bef:	int3
   140014bf0:	mov    QWORD PTR [rsp+0x8],rcx
   140014bf5:	push   rdi
   140014bf6:	sub    rsp,0x30
   140014bfa:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140014c03:	mov    QWORD PTR [rsp+0x48],rbx
   140014c08:	mov    rbx,rdx
   140014c0b:	mov    rdi,rcx
   140014c0e:	call   0x140014759
   140014c13:	nop
   140014c14:	lea    rax,[rip+0x23fd]        # 0x140017018
   140014c1b:	mov    QWORD PTR [rdi],rax
   140014c1e:	lea    rcx,[rdi+0x18]
   140014c22:	mov    QWORD PTR [rcx+0x20],0xf
   140014c2a:	and    QWORD PTR [rcx+0x18],0x0
   140014c2f:	mov    BYTE PTR [rcx+0x8],0x0
   140014c33:	lea    rdx,[rbx+0x18]
   140014c37:	or     r9,0xffffffffffffffff
   140014c3b:	xor    r8d,r8d
   140014c3e:	call   0x140015140
   140014c43:	nop
   140014c44:	mov    rax,rdi
   140014c47:	mov    rbx,QWORD PTR [rsp+0x48]
   140014c4c:	add    rsp,0x30
   140014c50:	pop    rdi
   140014c51:	ret
   140014c52:	int3
   140014c53:	int3
   140014c54:	int3
   140014c55:	int3
   140014c56:	int3
   140014c57:	int3
   140014c58:	mov    QWORD PTR [rsp+0x8],rcx
   140014c5d:	push   rdi
   140014c5e:	sub    rsp,0x30
   140014c62:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140014c6b:	mov    QWORD PTR [rsp+0x48],rbx
   140014c70:	mov    rbx,rdx
   140014c73:	mov    rdi,rcx
   140014c76:	call   0x140014759
   140014c7b:	nop
   140014c7c:	lea    rax,[rip+0x2395]        # 0x140017018
   140014c83:	mov    QWORD PTR [rdi],rax
   140014c86:	lea    rcx,[rdi+0x18]
   140014c8a:	mov    QWORD PTR [rcx+0x20],0xf
   140014c92:	and    QWORD PTR [rcx+0x18],0x0
   140014c97:	mov    BYTE PTR [rcx+0x8],0x0
   140014c9b:	lea    rdx,[rbx+0x18]
   140014c9f:	or     r9,0xffffffffffffffff
   140014ca3:	xor    r8d,r8d
   140014ca6:	call   0x140015140
   140014cab:	nop
   140014cac:	lea    rax,[rip+0x2395]        # 0x140017048
   140014cb3:	mov    QWORD PTR [rdi],rax
   140014cb6:	mov    rax,rdi
   140014cb9:	mov    rbx,QWORD PTR [rsp+0x48]
   140014cbe:	add    rsp,0x30
   140014cc2:	pop    rdi
   140014cc3:	ret
   140014cc4:	int3
   140014cc5:	int3
   140014cc6:	int3
   140014cc7:	int3
   140014cc8:	int3
   140014cc9:	int3
   140014cca:	int3
   140014ccb:	int3
   140014ccc:	mov    rax,rsp
   140014ccf:	mov    QWORD PTR [rax+0x8],rcx
   140014cd3:	push   rdi
   140014cd4:	sub    rsp,0x30
   140014cd8:	mov    QWORD PTR [rax-0x18],0xfffffffffffffffe
   140014ce0:	mov    QWORD PTR [rax+0x10],rbx
   140014ce4:	mov    QWORD PTR [rax+0x18],rsi
   140014ce8:	mov    rdi,rdx
   140014ceb:	mov    rsi,rcx
   140014cee:	call   0x140015563
   140014cf3:	nop
   140014cf4:	lea    rax,[rip+0x231d]        # 0x140017018
   140014cfb:	mov    QWORD PTR [rsi],rax
   140014cfe:	xor    r8d,r8d
   140014d01:	xor    edx,edx
   140014d03:	lea    rcx,[rsi+0x18]
   140014d07:	call   0x140015018
   140014d0c:	or     r9,0xffffffffffffffff
   140014d10:	xor    r8d,r8d
   140014d13:	mov    rdx,rdi
   140014d16:	lea    rcx,[rsi+0x18]
   140014d1a:	call   0x140015140
   140014d1f:	nop
   140014d20:	lea    rax,[rip+0x2321]        # 0x140017048
   140014d27:	mov    QWORD PTR [rsi],rax
   140014d2a:	mov    rax,rsi
   140014d2d:	mov    rbx,QWORD PTR [rsp+0x48]
   140014d32:	mov    rsi,QWORD PTR [rsp+0x50]
   140014d37:	add    rsp,0x30
   140014d3b:	pop    rdi
   140014d3c:	ret
   140014d3d:	int3
   140014d3e:	int3
   140014d3f:	int3
   140014d40:	int3
   140014d41:	int3
   140014d42:	int3
   140014d43:	int3
   140014d44:	rex push rbx
   140014d46:	sub    rsp,0x20
   140014d4a:	cmp    QWORD PTR [rcx+0x20],0x10
   140014d4f:	mov    rbx,rcx
   140014d52:	jb     0x140014d5d
   140014d54:	mov    rcx,QWORD PTR [rcx+0x8]
   140014d58:	call   0x140014084
   140014d5d:	and    QWORD PTR [rbx+0x18],0x0
   140014d62:	mov    QWORD PTR [rbx+0x20],0xf
   140014d6a:	mov    BYTE PTR [rbx+0x8],0x0
   140014d6e:	add    rsp,0x20
   140014d72:	pop    rbx
   140014d73:	ret
   140014d74:	int3
   140014d75:	int3
   140014d76:	int3
   140014d77:	int3
   140014d78:	int3
   140014d79:	int3
   140014d7a:	int3
   140014d7b:	int3
   140014d7c:	rex push rbx
   140014d7e:	sub    rsp,0x20
   140014d82:	lea    rax,[rip+0x228f]        # 0x140017018
   140014d89:	mov    rbx,rcx
   140014d8c:	mov    QWORD PTR [rcx],rax
   140014d8f:	cmp    QWORD PTR [rcx+0x38],0x10
   140014d94:	jb     0x140014d9f
   140014d96:	mov    rcx,QWORD PTR [rcx+0x20]
   140014d9a:	call   0x140014084
   140014d9f:	and    QWORD PTR [rbx+0x30],0x0
   140014da4:	mov    rcx,rbx
   140014da7:	mov    QWORD PTR [rbx+0x38],0xf
   140014daf:	mov    BYTE PTR [rbx+0x20],0x0
   140014db3:	add    rsp,0x20
   140014db7:	pop    rbx
   140014db8:	jmp    0x140014765
   140014dbd:	int3
   140014dbe:	int3
   140014dbf:	int3
   140014dc0:	int3
   140014dc1:	int3
   140014dc2:	int3
   140014dc3:	int3
   140014dc4:	int3
   140014dc5:	int3
   140014dc6:	int3
   140014dc7:	int3
   140014dc8:	int3
   140014dc9:	int3
   140014dca:	int3
   140014dcb:	int3
   140014dcc:	int3
   140014dcd:	int3
   140014dce:	int3
   140014dcf:	int3
   140014dd0:	mov    QWORD PTR [rsp+0x8],rbx
   140014dd5:	push   rdi
   140014dd6:	sub    rsp,0x20
   140014dda:	lea    rax,[rip+0x2237]        # 0x140017018
   140014de1:	mov    edi,edx
   140014de3:	mov    QWORD PTR [rcx],rax
   140014de6:	mov    rbx,rcx
   140014de9:	cmp    QWORD PTR [rcx+0x38],0x10
   140014dee:	jb     0x140014df9
   140014df0:	mov    rcx,QWORD PTR [rcx+0x20]
   140014df4:	call   0x140014084
   140014df9:	and    QWORD PTR [rbx+0x30],0x0
   140014dfe:	mov    rcx,rbx
   140014e01:	mov    QWORD PTR [rbx+0x38],0xf
   140014e09:	mov    BYTE PTR [rbx+0x20],0x0
   140014e0d:	call   0x140014765
   140014e12:	test   dil,0x1
   140014e16:	je     0x140014e20
   140014e18:	mov    rcx,rbx
   140014e1b:	call   0x140014084
   140014e20:	mov    rax,rbx
   140014e23:	mov    rbx,QWORD PTR [rsp+0x30]
   140014e28:	add    rsp,0x20
   140014e2c:	pop    rdi
   140014e2d:	ret
   140014e2e:	int3
   140014e2f:	int3
   140014e30:	int3
   140014e31:	int3
   140014e32:	int3
   140014e33:	int3
   140014e34:	mov    rax,rsp
   140014e37:	mov    QWORD PTR [rax+0x18],r8
   140014e3b:	mov    QWORD PTR [rax+0x10],rdx
   140014e3f:	mov    QWORD PTR [rax+0x8],rcx
   140014e43:	push   rbx
   140014e44:	push   rsi
   140014e45:	push   rdi
   140014e46:	push   r14
   140014e48:	sub    rsp,0x68
   140014e4c:	mov    QWORD PTR [rax-0x68],0xfffffffffffffffe
   140014e54:	mov    rsi,r8
   140014e57:	mov    rdi,rcx
   140014e5a:	mov    rbx,rdx
   140014e5d:	or     rbx,0xf
   140014e61:	mov    rcx,0xfffffffffffffffe
   140014e68:	cmp    rbx,rcx
   140014e6b:	jbe    0x140014e72
   140014e6d:	mov    rbx,rdx
   140014e70:	jmp    0x140014e9d
   140014e72:	mov    r9,QWORD PTR [rdi+0x20]
   140014e76:	mov    r8,r9
   140014e79:	shr    r8,1
   140014e7c:	movabs rax,0xaaaaaaaaaaaaaaab
   140014e86:	mul    rbx
   140014e89:	shr    rdx,1
   140014e8c:	cmp    rdx,r8
   140014e8f:	jae    0x140014e9d
   140014e91:	sub    rcx,r8
   140014e94:	cmp    r9,rcx
   140014e97:	ja     0x140014e9d
   140014e99:	lea    rbx,[r8+r9*1]
   140014e9d:	lea    rcx,[rbx+0x1]
   140014ea1:	test   rcx,rcx
   140014ea4:	jne    0x140014eb0
   140014ea6:	call   0x140014038
   140014eab:	mov    r14,rax
   140014eae:	jmp    0x140014ee1
   140014eb0:	xor    edx,edx
   140014eb2:	or     rax,0xffffffffffffffff
   140014eb6:	div    rcx
   140014eb9:	cmp    rax,0x1
   140014ebd:	jb     0x140014f38
   140014ebf:	jmp    0x140014ea6
   140014ec1:	mov    rdi,QWORD PTR [rsp+0x90]
   140014ec9:	mov    rsi,QWORD PTR [rsp+0xa0]
   140014ed1:	mov    rbx,QWORD PTR [rsp+0x98]
   140014ed9:	mov    r14,QWORD PTR [rsp+0xa8]
   140014ee1:	test   rsi,rsi
   140014ee4:	je     0x140014f03
   140014ee6:	lea    r8,[rdi+0x8]
   140014eea:	cmp    QWORD PTR [rdi+0x20],0x10
   140014eef:	jb     0x140014ef4
   140014ef1:	mov    r8,QWORD PTR [r8]
   140014ef4:	lea    rdx,[rbx+0x1]
   140014ef8:	mov    r9,rsi
   140014efb:	mov    rcx,r14
   140014efe:	call   0x1400153f5
   140014f03:	cmp    QWORD PTR [rdi+0x20],0x10
   140014f08:	jb     0x140014f13
   140014f0a:	mov    rcx,QWORD PTR [rdi+0x8]
   140014f0e:	call   0x140014084
   140014f13:	lea    rax,[rdi+0x8]
   140014f17:	mov    QWORD PTR [rax],r14
   140014f1a:	mov    QWORD PTR [rdi+0x20],rbx
   140014f1e:	mov    QWORD PTR [rdi+0x18],rsi
   140014f22:	cmp    rbx,0x10
   140014f26:	cmovae rax,r14
   140014f2a:	mov    BYTE PTR [rax+rsi*1],0x0
   140014f2e:	add    rsp,0x68
   140014f32:	pop    r14
   140014f34:	pop    rdi
   140014f35:	pop    rsi
   140014f36:	pop    rbx
   140014f37:	ret
   140014f38:	xor    edx,edx
   140014f3a:	lea    rcx,[rsp+0x28]
   140014f3f:	call   0x14000ed98
   140014f44:	lea    rdx,[rip+0xd155]        # 0x1400220a0
   140014f4b:	lea    rcx,[rsp+0x28]
   140014f50:	call   0x14001478c
   140014f55:	int3
   140014f56:	int3
   140014f57:	int3
   140014f58:	int3
   140014f59:	int3
   140014f5a:	int3
   140014f5b:	int3
   140014f5c:	int3
   140014f5d:	int3
   140014f5e:	int3
   140014f5f:	int3
   140014f60:	sub    rsp,0x78
   140014f64:	mov    rax,QWORD PTR [rip+0xf1ad]        # 0x140024118
   140014f6b:	xor    rax,rsp
   140014f6e:	mov    QWORD PTR [rsp+0x60],rax
   140014f73:	mov    rdx,rcx
   140014f76:	lea    rcx,[rsp+0x20]
   140014f7b:	call   0x140014b04
   140014f80:	lea    rdx,[rip+0xcf89]        # 0x140021f10
   140014f87:	lea    rcx,[rsp+0x20]
   140014f8c:	call   0x14001478c
   140014f91:	int3
   140014f92:	int3
   140014f93:	int3
   140014f94:	int3
   140014f95:	int3
   140014f96:	int3
   140014f97:	int3
   140014f98:	int3
   140014f99:	int3
   140014f9a:	int3
   140014f9b:	int3
   140014f9c:	int3
   140014f9d:	int3
   140014f9e:	int3
   140014f9f:	int3
   140014fa0:	sub    rsp,0x78
   140014fa4:	mov    rax,QWORD PTR [rip+0xf16d]        # 0x140024118
   140014fab:	xor    rax,rsp
   140014fae:	mov    QWORD PTR [rsp+0x60],rax
   140014fb3:	mov    rdx,rcx
   140014fb6:	lea    rcx,[rsp+0x20]
   140014fbb:	call   0x140014bf0
   140014fc0:	lea    rdx,[rip+0xcee9]        # 0x140021eb0
   140014fc7:	lea    rcx,[rsp+0x20]
   140014fcc:	call   0x14001478c
   140014fd1:	int3
   140014fd2:	int3
   140014fd3:	int3
   140014fd4:	int3
   140014fd5:	int3
   140014fd6:	int3
   140014fd7:	int3
   140014fd8:	int3
   140014fd9:	int3
   140014fda:	int3
   140014fdb:	int3
   140014fdc:	int3
   140014fdd:	int3
   140014fde:	int3
   140014fdf:	int3
   140014fe0:	sub    rsp,0x78
   140014fe4:	mov    rax,QWORD PTR [rip+0xf12d]        # 0x140024118
   140014feb:	xor    rax,rsp
   140014fee:	mov    QWORD PTR [rsp+0x60],rax
   140014ff3:	mov    rdx,rcx
   140014ff6:	lea    rcx,[rsp+0x20]
   140014ffb:	call   0x140014c58
   140015000:	lea    rdx,[rip+0xcf71]        # 0x140021f78
   140015007:	lea    rcx,[rsp+0x20]
   14001500c:	call   0x14001478c
   140015011:	int3
   140015012:	int3
   140015013:	int3
   140015014:	int3
   140015015:	int3
   140015016:	int3
   140015017:	int3
   140015018:	mov    QWORD PTR [rsp+0x8],rbx
   14001501d:	mov    QWORD PTR [rsp+0x10],rsi
   140015022:	push   rdi
   140015023:	sub    rsp,0x20
   140015027:	mov    rdi,r8
   14001502a:	mov    rbx,rcx
   14001502d:	test   dl,dl
   14001502f:	je     0x14001505b
   140015031:	mov    edx,0x10
   140015036:	cmp    QWORD PTR [rcx+0x20],rdx
   14001503a:	jb     0x14001505b
   14001503c:	add    rcx,0x8
   140015040:	mov    rsi,QWORD PTR [rcx]
   140015043:	test   r8,r8
   140015046:	je     0x140015053
   140015048:	mov    r9,r8
   14001504b:	mov    r8,rsi
   14001504e:	call   0x1400153f5
   140015053:	mov    rcx,rsi
   140015056:	call   0x140014084
   14001505b:	mov    rsi,QWORD PTR [rsp+0x38]
   140015060:	mov    QWORD PTR [rbx+0x20],0xf
   140015068:	mov    QWORD PTR [rbx+0x18],rdi
   14001506c:	mov    BYTE PTR [rdi+rbx*1+0x8],0x0
   140015071:	mov    rbx,QWORD PTR [rsp+0x30]
   140015076:	add    rsp,0x20
   14001507a:	pop    rdi
   14001507b:	ret
   14001507c:	int3
   14001507d:	int3
   14001507e:	int3
   14001507f:	int3
   140015080:	int3
   140015081:	int3
   140015082:	int3
   140015083:	int3
   140015084:	sub    rsp,0xa8
   14001508b:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   140015094:	mov    rax,QWORD PTR [rip+0xf07d]        # 0x140024118
   14001509b:	xor    rax,rsp
   14001509e:	mov    QWORD PTR [rsp+0x90],rax
   1400150a6:	lea    rdx,[rip+0x3463]        # 0x140018510
   1400150ad:	lea    rcx,[rsp+0x28]
   1400150b2:	call   0x140014ac8
   1400150b7:	nop
   1400150b8:	lea    rdx,[rsp+0x28]
   1400150bd:	lea    rcx,[rsp+0x50]
   1400150c2:	call   0x140014b78
   1400150c7:	lea    rdx,[rip+0xce42]        # 0x140021f10
   1400150ce:	lea    rcx,[rsp+0x50]
   1400150d3:	call   0x14001478c
   1400150d8:	int3
   1400150d9:	int3
   1400150da:	int3
   1400150db:	int3
   1400150dc:	int3
   1400150dd:	int3
   1400150de:	int3
   1400150df:	int3
   1400150e0:	sub    rsp,0xa8
   1400150e7:	mov    QWORD PTR [rsp+0x20],0xfffffffffffffffe
   1400150f0:	mov    rax,QWORD PTR [rip+0xf021]        # 0x140024118
   1400150f7:	xor    rax,rsp
   1400150fa:	mov    QWORD PTR [rsp+0x90],rax
   140015102:	lea    rdx,[rip+0x3417]        # 0x140018520
   140015109:	lea    rcx,[rsp+0x28]
   14001510e:	call   0x140014ac8
   140015113:	nop
   140015114:	xor    r8d,r8d
   140015117:	lea    rdx,[rsp+0x28]
   14001511c:	lea    rcx,[rsp+0x50]
   140015121:	call   0x140014ccc
   140015126:	lea    rdx,[rip+0xce4b]        # 0x140021f78
   14001512d:	lea    rcx,[rsp+0x50]
   140015132:	call   0x14001478c
   140015137:	int3
   140015138:	int3
   140015139:	int3
   14001513a:	int3
   14001513b:	int3
   14001513c:	int3
   14001513d:	int3
   14001513e:	int3
   14001513f:	int3
   140015140:	mov    QWORD PTR [rsp+0x8],rbx
   140015145:	mov    QWORD PTR [rsp+0x10],rbp
   14001514a:	mov    QWORD PTR [rsp+0x18],rsi
   14001514f:	push   rdi
   140015150:	sub    rsp,0x20
   140015154:	mov    rbx,QWORD PTR [rdx+0x18]
   140015158:	mov    rbp,r8
   14001515b:	mov    rsi,rdx
   14001515e:	mov    rdi,rcx
   140015161:	cmp    rbx,r8
   140015164:	jb     0x14001522c
   14001516a:	sub    rbx,r8
   14001516d:	cmp    r9,rbx
   140015170:	cmovb  rbx,r9
   140015174:	cmp    rcx,rdx
   140015177:	jne    0x140015195
   140015179:	lea    rdx,[rbx+r8*1]
   14001517d:	or     r8,0xffffffffffffffff
   140015181:	call   0x14001533c
   140015186:	mov    r8,rbp
   140015189:	xor    edx,edx
   14001518b:	mov    rcx,rdi
   14001518e:	call   0x14001533c
   140015193:	jmp    0x140015214
   140015195:	cmp    rbx,0xfffffffffffffffe
   140015199:	ja     0x140015232
   14001519f:	cmp    QWORD PTR [rcx+0x20],rbx
   1400151a3:	jae    0x1400151b3
   1400151a5:	mov    r8,QWORD PTR [rcx+0x18]
   1400151a9:	mov    rdx,rbx
   1400151ac:	call   0x140014e34
   1400151b1:	jmp    0x1400151cd
   1400151b3:	test   rbx,rbx
   1400151b6:	jne    0x1400151d2
   1400151b8:	and    QWORD PTR [rcx+0x18],rbx
   1400151bc:	lea    rax,[rcx+0x8]
   1400151c0:	cmp    QWORD PTR [rcx+0x20],0x10
   1400151c5:	jb     0x1400151ca
   1400151c7:	mov    rax,QWORD PTR [rax]
   1400151ca:	mov    BYTE PTR [rax],0x0
   1400151cd:	test   rbx,rbx
   1400151d0:	je     0x140015214
   1400151d2:	cmp    QWORD PTR [rsi+0x20],0x10
   1400151d7:	lea    rax,[rsi+0x8]
   1400151db:	jb     0x1400151e0
   1400151dd:	mov    rax,QWORD PTR [rax]
   1400151e0:	mov    rdx,QWORD PTR [rdi+0x20]
   1400151e4:	lea    rsi,[rdi+0x8]
   1400151e8:	cmp    rdx,0x10
   1400151ec:	jb     0x1400151f3
   1400151ee:	mov    rcx,QWORD PTR [rsi]
   1400151f1:	jmp    0x1400151f6
   1400151f3:	mov    rcx,rsi
   1400151f6:	lea    r8,[rax+rbp*1]
   1400151fa:	mov    r9,rbx
   1400151fd:	call   0x1400153f5
   140015202:	cmp    QWORD PTR [rdi+0x20],0x10
   140015207:	mov    QWORD PTR [rdi+0x18],rbx
   14001520b:	jb     0x140015210
   14001520d:	mov    rsi,QWORD PTR [rsi]
   140015210:	mov    BYTE PTR [rsi+rbx*1],0x0
   140015214:	mov    rbx,QWORD PTR [rsp+0x30]
   140015219:	mov    rax,rdi
   14001521c:	mov    rbp,QWORD PTR [rsp+0x38]
   140015221:	mov    rsi,QWORD PTR [rsp+0x40]
   140015226:	add    rsp,0x20
   14001522a:	pop    rdi
   14001522b:	ret
   14001522c:	call   0x1400150e0
   140015231:	int3
   140015232:	call   0x140015084
   140015237:	int3
   140015238:	int3
   140015239:	int3
   14001523a:	int3
   14001523b:	int3
   14001523c:	int3
   14001523d:	int3
   14001523e:	int3
   14001523f:	int3
   140015240:	mov    QWORD PTR [rsp+0x8],rbx
   140015245:	mov    QWORD PTR [rsp+0x10],rbp
   14001524a:	mov    QWORD PTR [rsp+0x18],rsi
   14001524f:	push   rdi
   140015250:	sub    rsp,0x20
   140015254:	mov    rsi,r8
   140015257:	lea    rbx,[rcx+0x8]
   14001525b:	mov    r8,QWORD PTR [rcx+0x20]
   14001525f:	mov    rbp,rdx
   140015262:	mov    rdi,rcx
   140015265:	cmp    r8,0x10
   140015269:	jb     0x140015270
   14001526b:	mov    rax,QWORD PTR [rbx]
   14001526e:	jmp    0x140015273
   140015270:	mov    rax,rbx
   140015273:	cmp    rbp,rax
   140015276:	jb     0x1400152ae
   140015278:	cmp    r8,0x10
   14001527c:	jb     0x140015283
   14001527e:	mov    rcx,QWORD PTR [rbx]
   140015281:	jmp    0x140015286
   140015283:	mov    rcx,rbx
   140015286:	add    rcx,QWORD PTR [rdi+0x18]
   14001528a:	cmp    rcx,rbp
   14001528d:	jbe    0x1400152ae
   14001528f:	cmp    r8,0x10
   140015293:	jb     0x140015298
   140015295:	mov    rbx,QWORD PTR [rbx]
   140015298:	sub    rbp,rbx
   14001529b:	mov    r9,rsi
   14001529e:	mov    r8,rbp
   1400152a1:	mov    rdx,rdi
   1400152a4:	mov    rcx,rdi
   1400152a7:	call   0x140015140
   1400152ac:	jmp    0x14001531b
   1400152ae:	cmp    rsi,0xfffffffffffffffe
   1400152b2:	ja     0x140015330
   1400152b4:	cmp    r8,rsi
   1400152b7:	jae    0x1400152ca
   1400152b9:	mov    r8,QWORD PTR [rdi+0x18]
   1400152bd:	mov    rdx,rsi
   1400152c0:	mov    rcx,rdi
   1400152c3:	call   0x140014e34
   1400152c8:	jmp    0x1400152e4
   1400152ca:	test   rsi,rsi
   1400152cd:	jne    0x1400152e9
   1400152cf:	and    QWORD PTR [rdi+0x18],rsi
   1400152d3:	cmp    r8,0x10
   1400152d7:	jb     0x1400152de
   1400152d9:	mov    rax,QWORD PTR [rbx]
   1400152dc:	jmp    0x1400152e1
   1400152de:	mov    rax,rbx
   1400152e1:	mov    BYTE PTR [rax],0x0
   1400152e4:	test   rsi,rsi
   1400152e7:	je     0x140015318
   1400152e9:	mov    rdx,QWORD PTR [rdi+0x20]
   1400152ed:	cmp    rdx,0x10
   1400152f1:	jb     0x1400152f8
   1400152f3:	mov    rcx,QWORD PTR [rbx]
   1400152f6:	jmp    0x1400152fb
   1400152f8:	mov    rcx,rbx
   1400152fb:	mov    r9,rsi
   1400152fe:	mov    r8,rbp
   140015301:	call   0x1400153f5
   140015306:	cmp    QWORD PTR [rdi+0x20],0x10
   14001530b:	mov    QWORD PTR [rdi+0x18],rsi
   14001530f:	jb     0x140015314
   140015311:	mov    rbx,QWORD PTR [rbx]
   140015314:	mov    BYTE PTR [rbx+rsi*1],0x0
   140015318:	mov    rax,rdi
   14001531b:	mov    rbx,QWORD PTR [rsp+0x30]
   140015320:	mov    rbp,QWORD PTR [rsp+0x38]
   140015325:	mov    rsi,QWORD PTR [rsp+0x40]
   14001532a:	add    rsp,0x20
   14001532e:	pop    rdi
   14001532f:	ret
   140015330:	call   0x140015084
   140015335:	int3
   140015336:	int3
   140015337:	int3
   140015338:	int3
   140015339:	int3
   14001533a:	int3
   14001533b:	int3
   14001533c:	mov    QWORD PTR [rsp+0x8],rbx
   140015341:	mov    QWORD PTR [rsp+0x10],rsi
   140015346:	push   rdi
   140015347:	sub    rsp,0x20
   14001534b:	mov    r9,QWORD PTR [rcx+0x18]
   14001534f:	mov    rsi,r8
   140015352:	mov    rdi,rcx
   140015355:	cmp    r9,rdx
   140015358:	jb     0x1400153cc
   14001535a:	sub    r9,rdx
   14001535d:	cmp    r9,r8
   140015360:	cmovb  rsi,r9
   140015364:	test   rsi,rsi
   140015367:	je     0x1400153b9
   140015369:	mov    rax,QWORD PTR [rcx+0x20]
   14001536d:	lea    rbx,[rcx+0x8]
   140015371:	cmp    rax,0x10
   140015375:	jb     0x14001537c
   140015377:	mov    r8,QWORD PTR [rbx]
   14001537a:	jmp    0x14001537f
   14001537c:	mov    r8,rbx
   14001537f:	jb     0x140015386
   140015381:	mov    rcx,QWORD PTR [rbx]
   140015384:	jmp    0x140015389
   140015386:	mov    rcx,rbx
   140015389:	add    r8,rdx
   14001538c:	sub    rax,rdx
   14001538f:	add    rcx,rdx
   140015392:	add    r8,rsi
   140015395:	mov    rdx,rax
   140015398:	sub    r9,rsi
   14001539b:	call   0x1400154d8
   1400153a0:	mov    rax,QWORD PTR [rdi+0x18]
   1400153a4:	sub    rax,rsi
   1400153a7:	cmp    QWORD PTR [rdi+0x20],0x10
   1400153ac:	mov    QWORD PTR [rdi+0x18],rax
   1400153b0:	jb     0x1400153b5
   1400153b2:	mov    rbx,QWORD PTR [rbx]
   1400153b5:	mov    BYTE PTR [rbx+rax*1],0x0
   1400153b9:	mov    rbx,QWORD PTR [rsp+0x30]
   1400153be:	mov    rax,rdi
   1400153c1:	mov    rsi,QWORD PTR [rsp+0x38]
   1400153c6:	add    rsp,0x20
   1400153ca:	pop    rdi
   1400153cb:	ret
   1400153cc:	call   0x1400150e0
   1400153d1:	int3
   1400153d2:	int3
   1400153d3:	int3
   1400153d4:	int3
   1400153d5:	int3
   1400153d6:	int3
   1400153d7:	int3
   1400153d8:	int3
   1400153d9:	int3
   1400153da:	int3
   1400153db:	int3
   1400153dc:	int3
   1400153dd:	int3
   1400153de:	int3
   1400153df:	int3
   1400153e0:	cmp    QWORD PTR [rcx+0x38],0x10
   1400153e5:	lea    rax,[rcx+0x20]
   1400153e9:	jb     0x1400153ee
   1400153eb:	mov    rax,QWORD PTR [rax]
   1400153ee:	ret
   1400153ef:	int3
   1400153f0:	int3
   1400153f1:	int3
   1400153f2:	int3
   1400153f3:	int3
   1400153f4:	int3
   1400153f5:	jmp    QWORD PTR [rip+0x2ddd]        # 0x1400181d8
   1400153fb:	int3
   1400153fc:	int3
   1400153fd:	int3
   1400153fe:	int3
   1400153ff:	int3
   140015400:	int3
   140015401:	int3
   140015402:	int3
   140015403:	int3
   140015404:	jmp    0x140015410
   140015409:	int3
   14001540a:	int3
   14001540b:	int3
   14001540c:	int3
   14001540d:	int3
   14001540e:	int3
   14001540f:	int3
   140015410:	mov    rax,rsp
   140015413:	mov    QWORD PTR [rax+0x20],r9
   140015417:	mov    DWORD PTR [rax+0x18],r8d
   14001541b:	mov    QWORD PTR [rax+0x10],rdx
   14001541f:	push   rbx
   140015420:	push   rsi
   140015421:	push   rdi
   140015422:	push   r14
   140015424:	sub    rsp,0x38
   140015428:	mov    r14,r9
   14001542b:	movsxd rbx,r8d
   14001542e:	mov    rsi,rdx
   140015431:	and    DWORD PTR [rax-0x38],0x0
   140015435:	mov    rdi,rbx
   140015438:	imul   rdi,rdx
   14001543c:	add    rdi,rcx
   14001543f:	mov    QWORD PTR [rax+0x8],rdi
   140015443:	sub    ebx,0x1
   140015446:	mov    DWORD PTR [rsp+0x70],ebx
   14001544a:	js     0x140015465
   14001544c:	sub    rdi,rsi
   14001544f:	mov    QWORD PTR [rsp+0x60],rdi
   140015454:	mov    rcx,rdi
   140015457:	mov    rax,r14
   14001545a:	mov    rdx,QWORD PTR [rip+0x2e37]        # 0x140018298
   140015461:	call   rdx
   140015463:	jmp    0x140015443
   140015465:	mov    DWORD PTR [rsp+0x20],0x1
   14001546d:	add    rsp,0x38
   140015471:	pop    r14
   140015473:	pop    rdi
   140015474:	pop    rsi
   140015475:	pop    rbx
   140015476:	ret
   140015477:	int3
   140015478:	int3
   140015479:	int3
   14001547a:	int3
   14001547b:	int3
   14001547c:	int3
   14001547d:	int3
   14001547e:	int3
   14001547f:	int3
   140015480:	mov    QWORD PTR [rsp+0x10],rbx
   140015485:	mov    DWORD PTR [rsp+0x18],r8d
   14001548a:	mov    QWORD PTR [rsp+0x8],rcx
   14001548f:	push   rsi
   140015490:	push   rdi
   140015491:	push   r14
   140015493:	sub    rsp,0x40
   140015497:	mov    rsi,r9
   14001549a:	mov    ebx,r8d
   14001549d:	mov    r14,rdx
   1400154a0:	mov    rdi,rcx
   1400154a3:	sub    ebx,0x1
   1400154a6:	mov    DWORD PTR [rsp+0x70],ebx
   1400154aa:	js     0x1400154c2
   1400154ac:	sub    rdi,r14
   1400154af:	mov    QWORD PTR [rsp+0x60],rdi
   1400154b4:	mov    rcx,rdi
   1400154b7:	mov    rax,rsi
   1400154ba:	call   QWORD PTR [rip+0x2dd8]        # 0x140018298
   1400154c0:	jmp    0x1400154a3
   1400154c2:	jmp    0x1400154c4
   1400154c4:	mov    rbx,QWORD PTR [rsp+0x68]
   1400154c9:	add    rsp,0x40
   1400154cd:	pop    r14
   1400154cf:	pop    rdi
   1400154d0:	pop    rsi
   1400154d1:	ret
   1400154d2:	int3
   1400154d3:	int3
   1400154d4:	int3
   1400154d5:	int3
   1400154d6:	int3
   1400154d7:	int3
   1400154d8:	jmp    QWORD PTR [rip+0x2d12]        # 0x1400181f0
   1400154de:	int3
   1400154df:	int3
   1400154e0:	int3
   1400154e1:	int3
   1400154e2:	int3
   1400154e3:	int3
   1400154e4:	jmp    0x1400154f0
   1400154e9:	int3
   1400154ea:	int3
   1400154eb:	int3
   1400154ec:	int3
   1400154ed:	int3
   1400154ee:	int3
   1400154ef:	int3
   1400154f0:	mov    rax,rsp
   1400154f3:	mov    QWORD PTR [rax+0x18],rbx
   1400154f7:	mov    QWORD PTR [rax+0x20],rsi
   1400154fb:	mov    QWORD PTR [rax+0x10],rdx
   1400154ff:	mov    QWORD PTR [rax+0x8],rcx
   140015503:	push   rdi
   140015504:	push   r14
   140015506:	push   r15
   140015508:	sub    rsp,0x30
   14001550c:	mov    r15,r9
   14001550f:	mov    r14d,r8d
   140015512:	mov    rsi,rdx
   140015515:	mov    rdi,rcx
   140015518:	xor    ebx,ebx
   14001551a:	mov    DWORD PTR [rax-0x28],ebx
   14001551d:	mov    DWORD PTR [rax-0x24],ebx
   140015520:	mov    DWORD PTR [rsp+0x20],ebx
   140015524:	cmp    ebx,r14d
   140015527:	jge    0x140015541
   140015529:	mov    rcx,rdi
   14001552c:	mov    rax,r15
   14001552f:	call   QWORD PTR [rip+0x2d63]        # 0x140018298
   140015535:	add    rdi,rsi
   140015538:	mov    QWORD PTR [rsp+0x50],rdi
   14001553d:	inc    ebx
   14001553f:	jmp    0x140015520
   140015541:	mov    DWORD PTR [rsp+0x24],0x1
   140015549:	mov    rbx,QWORD PTR [rsp+0x60]
   14001554e:	mov    rsi,QWORD PTR [rsp+0x68]
   140015553:	add    rsp,0x30
   140015557:	pop    r15
   140015559:	pop    r14
   14001555b:	pop    rdi
   14001555c:	ret
   14001555d:	int3
   14001555e:	int3
   14001555f:	int3
   140015560:	int3
   140015561:	int3
   140015562:	int3
   140015563:	jmp    QWORD PTR [rip+0x2c97]        # 0x140018200
   140015569:	int3
   14001556a:	int3
   14001556b:	int3
   14001556c:	int3
   14001556d:	int3
   14001556e:	int3
   14001556f:	int3
   140015570:	sub    rsp,0x28
   140015574:	mov    r8,QWORD PTR [r9+0x38]
   140015578:	mov    rcx,rdx
   14001557b:	mov    rdx,r9
   14001557e:	call   0x140015594
   140015583:	mov    eax,0x1
   140015588:	add    rsp,0x28
   14001558c:	ret
   14001558d:	int3
   14001558e:	int3
   14001558f:	int3
   140015590:	int3
   140015591:	int3
   140015592:	int3
   140015593:	int3
   140015594:	rex push rbx
   140015596:	mov    r11d,DWORD PTR [r8]
   140015599:	mov    rbx,rdx
   14001559c:	and    r11d,0xfffffff8
   1400155a0:	mov    r9,rcx
   1400155a3:	test   BYTE PTR [r8],0x4
   1400155a7:	mov    r10,rcx
   1400155aa:	je     0x1400155bf
   1400155ac:	mov    eax,DWORD PTR [r8+0x8]
   1400155b0:	movsxd r10,DWORD PTR [r8+0x4]
   1400155b4:	neg    eax
   1400155b6:	add    r10,rcx
   1400155b9:	movsxd rcx,eax
   1400155bc:	and    r10,rcx
   1400155bf:	movsxd rax,r11d
   1400155c2:	mov    rdx,QWORD PTR [rax+r10*1]
   1400155c6:	mov    rax,QWORD PTR [rbx+0x10]
   1400155ca:	mov    ecx,DWORD PTR [rax+0x8]
   1400155cd:	mov    rax,QWORD PTR [rbx+0x8]
   1400155d1:	test   BYTE PTR [rcx+rax*1+0x3],0xf
   1400155d6:	je     0x1400155e3
   1400155d8:	movzx  eax,BYTE PTR [rcx+rax*1+0x3]
   1400155dd:	and    eax,0xfffffff0
   1400155e0:	add    r9,rax
   1400155e3:	xor    r9,rdx
   1400155e6:	mov    rcx,r9
   1400155e9:	pop    rbx
   1400155ea:	jmp    0x1400143c0
   1400155ef:	int3
   1400155f0:	int3
   1400155f1:	int3
   1400155f2:	int3
   1400155f3:	int3
   1400155f4:	int3
   1400155f5:	int3
   1400155f6:	int3
   1400155f7:	int3
   1400155f8:	mov    rax,rsp
   1400155fb:	mov    QWORD PTR [rax+0x8],rbx
   1400155ff:	mov    QWORD PTR [rax+0x10],rbp
   140015603:	mov    QWORD PTR [rax+0x18],rsi
   140015607:	mov    QWORD PTR [rax+0x20],rdi
   14001560b:	push   r14
   14001560d:	sub    rsp,0x20
   140015611:	mov    rbx,QWORD PTR [r9+0x38]
   140015615:	mov    rsi,rdx
   140015618:	mov    r14,r8
   14001561b:	mov    rbp,rcx
   14001561e:	mov    rdx,r9
   140015621:	mov    rcx,rsi
   140015624:	mov    rdi,r9
   140015627:	lea    r8,[rbx+0x4]
   14001562b:	call   0x140015594
   140015630:	mov    eax,DWORD PTR [rbp+0x4]
   140015633:	and    al,0x66
   140015635:	neg    al
   140015637:	mov    eax,0x1
   14001563c:	sbb    r8d,r8d
   14001563f:	neg    r8d
   140015642:	add    r8d,eax
   140015645:	test   DWORD PTR [rbx+0x4],r8d
   140015649:	je     0x14001565c
   14001564b:	mov    r9,rdi
   14001564e:	mov    r8,r14
   140015651:	mov    rdx,rsi
   140015654:	mov    rcx,rbp
   140015657:	call   0x1400143a8
   14001565c:	mov    rbx,QWORD PTR [rsp+0x30]
   140015661:	mov    rbp,QWORD PTR [rsp+0x38]
   140015666:	mov    rsi,QWORD PTR [rsp+0x40]
   14001566b:	mov    rdi,QWORD PTR [rsp+0x48]
   140015670:	add    rsp,0x20
   140015674:	pop    r14
   140015676:	ret
   140015677:	int3
   140015678:	int3
   140015679:	int3
   14001567a:	int3
   14001567b:	int3
   14001567c:	int3
   14001567d:	int3
   14001567e:	int3
   14001567f:	int3
   140015680:	int3
   140015681:	int3
   140015682:	int3
   140015683:	int3
   140015684:	int3
   140015685:	int3
   140015686:	jmp    QWORD PTR [rip+0x2b7c]        # 0x140018208
   14001568c:	int3
   14001568d:	int3
   14001568e:	int3
   14001568f:	int3
   140015690:	int3
   140015691:	int3
   140015692:	jmp    QWORD PTR [rip+0x2be8]        # 0x140018280
   140015698:	int3
   140015699:	int3
   14001569a:	int3
   14001569b:	int3
   14001569c:	int3
   14001569d:	int3
   14001569e:	int3
   14001569f:	int3
   1400156a0:	int3
   1400156a1:	int3
   1400156a2:	int3
   1400156a3:	int3
   1400156a4:	int3
   1400156a5:	int3
   1400156a6:	data16 nop WORD PTR [rax+rax*1+0x0]
   1400156b0:	jmp    rax
   1400156b2:	int3
   1400156b3:	int3
   1400156b4:	int3
   1400156b5:	int3
   1400156b6:	int3
   1400156b7:	int3
   1400156b8:	int3
   1400156b9:	int3
   1400156ba:	int3
   1400156bb:	int3
   1400156bc:	int3
   1400156bd:	int3
   1400156be:	int3
   1400156bf:	int3
   1400156c0:	int3
   1400156c1:	int3
   1400156c2:	int3
   1400156c3:	int3
   1400156c4:	int3
   1400156c5:	int3
   1400156c6:	data16 nop WORD PTR [rax+rax*1+0x0]
   1400156d0:	sub    rsp,0x10
   1400156d4:	mov    QWORD PTR [rsp],r10
   1400156d8:	mov    QWORD PTR [rsp+0x8],r11
   1400156dd:	xor    r11,r11
   1400156e0:	lea    r10,[rsp+0x18]
   1400156e5:	sub    r10,rax
   1400156e8:	cmovb  r10,r11
   1400156ec:	mov    r11,QWORD PTR gs:0x10
   1400156f5:	cmp    r10,r11
   1400156f8:	jae    0x14001570f
   1400156fa:	and    r10w,0xf000
   140015700:	lea    r11,[r11-0x1000]
   140015707:	test   BYTE PTR [r11],r11b
   14001570a:	cmp    r10,r11
   14001570d:	jb     0x140015700
   14001570f:	mov    r10,QWORD PTR [rsp]
   140015713:	mov    r11,QWORD PTR [rsp+0x8]
   140015718:	add    rsp,0x10
   14001571c:	ret
   14001571d:	int3
   14001571e:	int3
   14001571f:	int3
   140015720:	int3
   140015721:	int3
   140015722:	int3
   140015723:	lea    rcx,[rdx+0xf0]
   14001572a:	jmp    0x14000f958
   14001572f:	int3
   140015730:	int3
   140015731:	int3
   140015732:	int3
   140015733:	int3
   140015734:	int3
   140015735:	lea    rcx,[rdx+0x130]
   14001573c:	jmp    0x14000f958
   140015741:	int3
   140015742:	int3
   140015743:	int3
   140015744:	int3
   140015745:	int3
   140015746:	int3
   140015747:	lea    rcx,[rdx+0x58]
   14001574e:	jmp    0x140003464
   140015753:	int3
   140015754:	int3
   140015755:	int3
   140015756:	int3
   140015757:	int3
   140015758:	int3
   140015759:	lea    rcx,[rdx+0x50]
   140015760:	jmp    0x140003464
   140015765:	int3
   140015766:	int3
   140015767:	int3
   140015768:	int3
   140015769:	int3
   14001576a:	int3
   14001576b:	lea    rcx,[rdx+0x70]
   140015772:	jmp    0x1400037d0
   140015777:	int3
   140015778:	int3
   140015779:	int3
   14001577a:	int3
   14001577b:	int3
   14001577c:	int3
   14001577d:	lea    rcx,[rdx+0x48]
   140015784:	jmp    0x140003464
   140015789:	int3
   14001578a:	int3
   14001578b:	int3
   14001578c:	int3
   14001578d:	int3
   14001578e:	int3
   14001578f:	lea    rcx,[rdx+0x40]
   140015796:	jmp    0x140003464
   14001579b:	int3
   14001579c:	int3
   14001579d:	int3
   14001579e:	int3
   14001579f:	int3
   1400157a0:	int3
   1400157a1:	lea    rcx,[rdx+0x100]
   1400157a8:	jmp    0x14000f958
   1400157ad:	int3
   1400157ae:	int3
   1400157af:	int3
   1400157b0:	int3
   1400157b1:	int3
   1400157b2:	int3
   1400157b3:	mov    rcx,QWORD PTR [rdx+0x258]
   1400157ba:	jmp    0x14000f484
   1400157bf:	int3
   1400157c0:	int3
   1400157c1:	int3
   1400157c2:	int3
   1400157c3:	int3
   1400157c4:	int3
   1400157c5:	mov    QWORD PTR [rsp+0x10],rdx
   1400157ca:	push   rbp
   1400157cb:	sub    rsp,0x40
   1400157cf:	mov    rbp,rdx
   1400157d2:	mov    eax,DWORD PTR [rbp+0x84]
   1400157d8:	mov    DWORD PTR [rsp+0x30],eax
   1400157dc:	mov    DWORD PTR [rsp+0x28],0x325
   1400157e4:	lea    rax,[rip+0x3685]        # 0x140018e70
   1400157eb:	mov    QWORD PTR [rsp+0x20],rax
   1400157f0:	lea    r9,[rip+0x3059]        # 0x140018850
   1400157f7:	lea    r8,[rip+0x3072]        # 0x140018870
   1400157fe:	mov    edx,DWORD PTR [rbp+0xd0]
   140015804:	lea    rcx,[rbp+0x60]
   140015808:	call   0x140011e68
   14001580d:	nop
   14001580e:	lea    rax,[rip+0xfffffffffffed37e]        # 0x140002b93
   140015815:	add    rsp,0x40
   140015819:	pop    rbp
   14001581a:	ret
   14001581b:	int3
   14001581c:	mov    QWORD PTR [rsp+0x10],rdx
   140015821:	push   rbp
   140015822:	sub    rsp,0x40
   140015826:	mov    rbp,rdx
   140015829:	mov    eax,DWORD PTR [rbp+0x84]
   14001582f:	mov    DWORD PTR [rsp+0x30],eax
   140015833:	mov    DWORD PTR [rsp+0x28],0x325
   14001583b:	lea    rax,[rip+0x362e]        # 0x140018e70
   140015842:	mov    QWORD PTR [rsp+0x20],rax
   140015847:	lea    r9,[rip+0x3002]        # 0x140018850
   14001584e:	lea    r8,[rip+0x301b]        # 0x140018870
   140015855:	mov    rdx,QWORD PTR [rbp+0x188]
   14001585c:	lea    rcx,[rbp+0x60]
   140015860:	call   0x140011efc
   140015865:	nop
   140015866:	lea    rax,[rip+0xfffffffffffed389]        # 0x140002bf6
   14001586d:	add    rsp,0x40
   140015871:	pop    rbp
   140015872:	ret
   140015873:	int3
   140015874:	mov    QWORD PTR [rsp+0x10],rdx
   140015879:	push   rbp
   14001587a:	sub    rsp,0x40
   14001587e:	mov    rbp,rdx
   140015881:	mov    eax,DWORD PTR [rbp+0x84]
   140015887:	mov    DWORD PTR [rsp+0x28],eax
   14001588b:	mov    DWORD PTR [rsp+0x20],0x325
   140015893:	lea    r9,[rip+0x35d6]        # 0x140018e70
   14001589a:	lea    r8,[rip+0x2faf]        # 0x140018850
   1400158a1:	lea    rdx,[rip+0x2fc8]        # 0x140018870
   1400158a8:	lea    rcx,[rbp+0x60]
   1400158ac:	call   0x140011ff8
   1400158b1:	nop
   1400158b2:	lea    rax,[rip+0xfffffffffffed33f]        # 0x140002bf8
   1400158b9:	add    rsp,0x40
   1400158bd:	pop    rbp
   1400158be:	ret
   1400158bf:	int3
   1400158c0:	mov    QWORD PTR [rsp+0x10],rdx
   1400158c5:	push   rbp
   1400158c6:	sub    rsp,0x40
   1400158ca:	mov    rbp,rdx
   1400158cd:	mov    eax,DWORD PTR [rbp+0x84]
   1400158d3:	mov    DWORD PTR [rsp+0x30],eax
   1400158d7:	mov    DWORD PTR [rsp+0x28],0x325
   1400158df:	lea    rax,[rip+0x358a]        # 0x140018e70
   1400158e6:	mov    QWORD PTR [rsp+0x20],rax
   1400158eb:	lea    r9,[rip+0x2f5e]        # 0x140018850
   1400158f2:	lea    r8,[rip+0x2f77]        # 0x140018870
   1400158f9:	mov    rdx,QWORD PTR [rbp+0x190]
   140015900:	lea    rcx,[rbp+0x60]
   140015904:	call   0x140012080
   140015909:	nop
   14001590a:	lea    rax,[rip+0xfffffffffffed282]        # 0x140002b93
   140015911:	add    rsp,0x40
   140015915:	pop    rbp
   140015916:	ret
   140015917:	int3
   140015918:	mov    QWORD PTR [rsp+0x10],rdx
   14001591d:	push   rbp
   14001591e:	sub    rsp,0x40
   140015922:	mov    rbp,rdx
   140015925:	mov    eax,DWORD PTR [rbp+0x84]
   14001592b:	mov    DWORD PTR [rsp+0x30],eax
   14001592f:	mov    DWORD PTR [rsp+0x28],0x394
   140015937:	lea    rax,[rip+0x3532]        # 0x140018e70
   14001593e:	mov    QWORD PTR [rsp+0x20],rax
   140015943:	lea    r9,[rip+0x2f06]        # 0x140018850
   14001594a:	lea    r8,[rip+0x2f1f]        # 0x140018870
   140015951:	mov    edx,DWORD PTR [rbp+0xd4]
   140015957:	lea    rcx,[rbp+0x60]
   14001595b:	call   0x140011e68
   140015960:	nop
   140015961:	lea    rax,[rip+0xfffffffffffed877]        # 0x1400031df
   140015968:	add    rsp,0x40
   14001596c:	pop    rbp
   14001596d:	ret
   14001596e:	int3
   14001596f:	mov    QWORD PTR [rsp+0x10],rdx
   140015974:	push   rbp
   140015975:	sub    rsp,0x40
   140015979:	mov    rbp,rdx
   14001597c:	mov    eax,DWORD PTR [rbp+0x84]
   140015982:	mov    DWORD PTR [rsp+0x30],eax
   140015986:	mov    DWORD PTR [rsp+0x28],0x394
   14001598e:	lea    rax,[rip+0x34db]        # 0x140018e70
   140015995:	mov    QWORD PTR [rsp+0x20],rax
   14001599a:	lea    r9,[rip+0x2eaf]        # 0x140018850
   1400159a1:	lea    r8,[rip+0x2ec8]        # 0x140018870
   1400159a8:	mov    rdx,QWORD PTR [rbp+0x198]
   1400159af:	lea    rcx,[rbp+0x60]
   1400159b3:	call   0x140011efc
   1400159b8:	nop
   1400159b9:	lea    rax,[rip+0xfffffffffffed821]        # 0x1400031e1
   1400159c0:	add    rsp,0x40
   1400159c4:	pop    rbp
   1400159c5:	ret
   1400159c6:	int3
   1400159c7:	mov    QWORD PTR [rsp+0x10],rdx
   1400159cc:	push   rbp
   1400159cd:	sub    rsp,0x40
   1400159d1:	mov    rbp,rdx
   1400159d4:	mov    eax,DWORD PTR [rbp+0x84]
   1400159da:	mov    DWORD PTR [rsp+0x28],eax
   1400159de:	mov    DWORD PTR [rsp+0x20],0x394
   1400159e6:	lea    r9,[rip+0x3483]        # 0x140018e70
   1400159ed:	lea    r8,[rip+0x2e5c]        # 0x140018850
   1400159f4:	lea    rdx,[rip+0x2e75]        # 0x140018870
   1400159fb:	lea    rcx,[rbp+0x60]
   1400159ff:	call   0x140011ff8
   140015a04:	nop
   140015a05:	lea    rax,[rip+0xfffffffffffed7d7]        # 0x1400031e3
   140015a0c:	add    rsp,0x40
   140015a10:	pop    rbp
   140015a11:	ret
   140015a12:	int3
   140015a13:	mov    QWORD PTR [rsp+0x10],rdx
   140015a18:	push   rbp
   140015a19:	sub    rsp,0x40
   140015a1d:	mov    rbp,rdx
   140015a20:	mov    eax,DWORD PTR [rbp+0x84]
   140015a26:	mov    DWORD PTR [rsp+0x30],eax
   140015a2a:	mov    DWORD PTR [rsp+0x28],0x394
   140015a32:	lea    rax,[rip+0x3437]        # 0x140018e70
   140015a39:	mov    QWORD PTR [rsp+0x20],rax
   140015a3e:	lea    r9,[rip+0x2e0b]        # 0x140018850
   140015a45:	lea    r8,[rip+0x2e24]        # 0x140018870
   140015a4c:	mov    rdx,QWORD PTR [rbp+0x1a0]
   140015a53:	lea    rcx,[rbp+0x60]
   140015a57:	call   0x140012080
   140015a5c:	nop
   140015a5d:	lea    rax,[rip+0xfffffffffffed73e]        # 0x1400031a2
   140015a64:	add    rsp,0x40
   140015a68:	pop    rbp
   140015a69:	ret
   140015a6a:	int3
   140015a6b:	int3
   140015a6c:	int3
   140015a6d:	int3
   140015a6e:	int3
   140015a6f:	int3
   140015a70:	int3
   140015a71:	lea    rcx,[rdx+0x60]
   140015a78:	jmp    0x14000f958
   140015a7d:	int3
   140015a7e:	int3
   140015a7f:	int3
   140015a80:	int3
   140015a81:	int3
   140015a82:	int3
   140015a83:	lea    rcx,[rdx+0x3a0]
   140015a8a:	jmp    0x140001070
   140015a8f:	int3
   140015a90:	int3
   140015a91:	int3
   140015a92:	int3
   140015a93:	int3
   140015a94:	int3
   140015a95:	mov    QWORD PTR [rsp+0x10],rdx
   140015a9a:	push   rbp
   140015a9b:	sub    rsp,0x40
   140015a9f:	mov    rbp,rdx
   140015aa2:	mov    eax,DWORD PTR [rbp+0x84]
   140015aa8:	mov    DWORD PTR [rsp+0x30],eax
   140015aac:	mov    DWORD PTR [rsp+0x28],0x66
   140015ab4:	lea    rax,[rip+0x43c5]        # 0x140019e80
   140015abb:	mov    QWORD PTR [rsp+0x20],rax
   140015ac0:	lea    r9,[rip+0x4409]        # 0x140019ed0
   140015ac7:	lea    r8,[rip+0x4422]        # 0x140019ef0
   140015ace:	mov    edx,DWORD PTR [rbp+0x40]
   140015ad1:	lea    rcx,[rbp+0x60]
   140015ad5:	call   0x140011e68
   140015ada:	nop
   140015adb:	lea    rax,[rip+0xfffffffffffeeba6]        # 0x140004688
   140015ae2:	add    rsp,0x40
   140015ae6:	pop    rbp
   140015ae7:	ret
   140015ae8:	int3
   140015ae9:	mov    QWORD PTR [rsp+0x10],rdx
   140015aee:	push   rbp
   140015aef:	sub    rsp,0x40
   140015af3:	mov    rbp,rdx
   140015af6:	mov    eax,DWORD PTR [rbp+0x84]
   140015afc:	mov    DWORD PTR [rsp+0x30],eax
   140015b00:	mov    DWORD PTR [rsp+0x28],0x66
   140015b08:	lea    rax,[rip+0x4371]        # 0x140019e80
   140015b0f:	mov    QWORD PTR [rsp+0x20],rax
   140015b14:	lea    r9,[rip+0x43b5]        # 0x140019ed0
   140015b1b:	lea    r8,[rip+0x43ce]        # 0x140019ef0
   140015b22:	mov    rdx,QWORD PTR [rbp+0x50]
   140015b26:	lea    rcx,[rbp+0x60]
   140015b2a:	call   0x140011efc
   140015b2f:	nop
   140015b30:	lea    rax,[rip+0xfffffffffffeeb53]        # 0x14000468a
   140015b37:	add    rsp,0x40
   140015b3b:	pop    rbp
   140015b3c:	ret
   140015b3d:	int3
   140015b3e:	mov    QWORD PTR [rsp+0x10],rdx
   140015b43:	push   rbp
   140015b44:	sub    rsp,0x40
   140015b48:	mov    rbp,rdx
   140015b4b:	mov    eax,DWORD PTR [rbp+0x84]
   140015b51:	mov    DWORD PTR [rsp+0x28],eax
   140015b55:	mov    DWORD PTR [rsp+0x20],0x66
   140015b5d:	lea    r9,[rip+0x431c]        # 0x140019e80
   140015b64:	lea    r8,[rip+0x4365]        # 0x140019ed0
   140015b6b:	lea    rdx,[rip+0x437e]        # 0x140019ef0
   140015b72:	lea    rcx,[rbp+0x60]
   140015b76:	call   0x140011ff8
   140015b7b:	nop
   140015b7c:	lea    rax,[rip+0xfffffffffffeeb09]        # 0x14000468c
   140015b83:	add    rsp,0x40
   140015b87:	pop    rbp
   140015b88:	ret
   140015b89:	int3
   140015b8a:	mov    QWORD PTR [rsp+0x10],rdx
   140015b8f:	push   rbp
   140015b90:	sub    rsp,0x40
   140015b94:	mov    rbp,rdx
   140015b97:	mov    eax,DWORD PTR [rbp+0x84]
   140015b9d:	mov    DWORD PTR [rsp+0x30],eax
   140015ba1:	mov    DWORD PTR [rsp+0x28],0x66
   140015ba9:	lea    rax,[rip+0x42d0]        # 0x140019e80
   140015bb0:	mov    QWORD PTR [rsp+0x20],rax
   140015bb5:	lea    r9,[rip+0x4314]        # 0x140019ed0
   140015bbc:	lea    r8,[rip+0x432d]        # 0x140019ef0
   140015bc3:	mov    rdx,QWORD PTR [rbp+0x58]
   140015bc7:	lea    rcx,[rbp+0x60]
   140015bcb:	call   0x140012080
   140015bd0:	nop
   140015bd1:	lea    rax,[rip+0xfffffffffffeea7d]        # 0x140004655
   140015bd8:	add    rsp,0x40
   140015bdc:	pop    rbp
   140015bdd:	ret
   140015bde:	int3
   140015bdf:	int3
   140015be0:	int3
   140015be1:	int3
   140015be2:	int3
   140015be3:	int3
   140015be4:	int3
   140015be5:	lea    rcx,[rdx+0x60]
   140015bec:	jmp    0x140003464
   140015bf1:	int3
   140015bf2:	int3
   140015bf3:	int3
   140015bf4:	int3
   140015bf5:	int3
   140015bf6:	int3
   140015bf7:	lea    rcx,[rdx+0x70]
   140015bfe:	jmp    0x14000b614
   140015c03:	int3
   140015c04:	int3
   140015c05:	int3
   140015c06:	int3
   140015c07:	int3
   140015c08:	int3
   140015c09:	lea    rcx,[rdx+0x120]
   140015c10:	jmp    0x14000f958
   140015c15:	int3
   140015c16:	int3
   140015c17:	int3
   140015c18:	int3
   140015c19:	int3
   140015c1a:	int3
   140015c1b:	lea    rcx,[rdx+0xe0]
   140015c22:	jmp    0x1400037d0
   140015c27:	int3
   140015c28:	int3
   140015c29:	int3
   140015c2a:	int3
   140015c2b:	int3
   140015c2c:	int3
   140015c2d:	mov    rcx,QWORD PTR [rdx+0x250]
   140015c34:	jmp    0x14000f484
   140015c39:	int3
   140015c3a:	int3
   140015c3b:	int3
   140015c3c:	int3
   140015c3d:	int3
   140015c3e:	int3
   140015c3f:	lea    rcx,[rdx+0x110]
   140015c46:	jmp    0x14000f958
   140015c4b:	int3
   140015c4c:	int3
   140015c4d:	int3
   140015c4e:	int3
   140015c4f:	int3
   140015c50:	int3
   140015c51:	lea    rcx,[rdx+0x90]
   140015c58:	jmp    0x14000f958
   140015c5d:	int3
   140015c5e:	int3
   140015c5f:	int3
   140015c60:	int3
   140015c61:	int3
   140015c62:	int3
   140015c63:	lea    rcx,[rdx+0x1d0]
   140015c6a:	jmp    0x14000f958
   140015c6f:	int3
   140015c70:	int3
   140015c71:	int3
   140015c72:	int3
   140015c73:	int3
   140015c74:	int3
   140015c75:	lea    rcx,[rdx+0xd8]
   140015c7c:	jmp    0x1400037d0
   140015c81:	int3
   140015c82:	int3
   140015c83:	int3
   140015c84:	int3
   140015c85:	int3
   140015c86:	int3
   140015c87:	lea    rcx,[rdx+0xc8]
   140015c8e:	jmp    0x1400037d0
   140015c93:	int3
   140015c94:	int3
   140015c95:	int3
   140015c96:	int3
   140015c97:	int3
   140015c98:	int3
   140015c99:	lea    rcx,[rdx+0xa0]
   140015ca0:	jmp    0x1400037d0
   140015ca5:	int3
   140015ca6:	int3
   140015ca7:	int3
   140015ca8:	int3
   140015ca9:	int3
   140015caa:	int3
   140015cab:	lea    rcx,[rdx+0x90]
   140015cb2:	jmp    0x1400037d0
   140015cb7:	int3
   140015cb8:	int3
   140015cb9:	int3
   140015cba:	int3
   140015cbb:	int3
   140015cbc:	int3
   140015cbd:	lea    rcx,[rdx+0xb8]
   140015cc4:	jmp    0x1400037d0
   140015cc9:	int3
   140015cca:	int3
   140015ccb:	int3
   140015ccc:	int3
   140015ccd:	int3
   140015cce:	int3
   140015ccf:	lea    rcx,[rdx+0x80]
   140015cd6:	jmp    0x1400037d0
   140015cdb:	int3
   140015cdc:	int3
   140015cdd:	int3
   140015cde:	int3
   140015cdf:	int3
   140015ce0:	int3
   140015ce1:	lea    rcx,[rdx+0x60]
   140015ce8:	jmp    0x1400037d0
   140015ced:	int3
   140015cee:	int3
   140015cef:	int3
   140015cf0:	int3
   140015cf1:	int3
   140015cf2:	int3
   140015cf3:	lea    rcx,[rdx+0x140]
   140015cfa:	jmp    0x14000f958
   140015cff:	int3
   140015d00:	int3
   140015d01:	int3
   140015d02:	int3
   140015d03:	int3
   140015d04:	int3
   140015d05:	lea    rcx,[rdx+0x70]
   140015d0c:	jmp    0x140003464
   140015d11:	int3
   140015d12:	int3
   140015d13:	int3
   140015d14:	int3
   140015d15:	int3
   140015d16:	int3
   140015d17:	lea    rcx,[rdx+0x250]
   140015d1e:	jmp    0x14000f958
   140015d23:	int3
   140015d24:	int3
   140015d25:	int3
   140015d26:	int3
   140015d27:	int3
   140015d28:	int3
   140015d29:	lea    rcx,[rdx+0xb8]
   140015d30:	jmp    0x140004e98
   140015d35:	int3
   140015d36:	int3
   140015d37:	int3
   140015d38:	int3
   140015d39:	int3
   140015d3a:	int3
   140015d3b:	lea    rcx,[rdx+0xa8]
   140015d42:	jmp    0x1400037d0
   140015d47:	int3
   140015d48:	int3
   140015d49:	int3
   140015d4a:	int3
   140015d4b:	int3
   140015d4c:	int3
   140015d4d:	lea    rcx,[rdx+0xd0]
   140015d54:	jmp    0x1400037d0
   140015d59:	int3
   140015d5a:	int3
   140015d5b:	int3
   140015d5c:	int3
   140015d5d:	int3
   140015d5e:	int3
   140015d5f:	mov    rcx,QWORD PTR [rdx+0x68]
   140015d66:	jmp    0x14000f484
   140015d6b:	int3
   140015d6c:	int3
   140015d6d:	int3
   140015d6e:	int3
   140015d6f:	int3
   140015d70:	int3
   140015d71:	lea    rcx,[rdx+0xd0]
   140015d78:	jmp    0x14000f958
   140015d7d:	int3
   140015d7e:	int3
   140015d7f:	int3
   140015d80:	int3
   140015d81:	int3
   140015d82:	int3
   140015d83:	lea    rcx,[rdx+0x80]
   140015d8a:	jmp    0x14000f958
   140015d8f:	int3
   140015d90:	int3
   140015d91:	int3
   140015d92:	int3
   140015d93:	int3
   140015d94:	int3
   140015d95:	lea    rcx,[rdx+0x40]
   140015d9c:	jmp    0x14000b80c
   140015da1:	int3
   140015da2:	int3
   140015da3:	int3
   140015da4:	int3
   140015da5:	int3
   140015da6:	int3
   140015da7:	lea    rcx,[rdx+0x1a8]
   140015dae:	jmp    0x1400037d0
   140015db3:	int3
   140015db4:	int3
   140015db5:	int3
   140015db6:	int3
   140015db7:	int3
   140015db8:	int3
   140015db9:	lea    rcx,[rdx+0x198]
   140015dc0:	jmp    0x1400037d0
   140015dc5:	int3
   140015dc6:	int3
   140015dc7:	int3
   140015dc8:	int3
   140015dc9:	int3
   140015dca:	int3
   140015dcb:	lea    rcx,[rdx+0x150]
   140015dd2:	jmp    0x14000f958
   140015dd7:	int3
   140015dd8:	int3
   140015dd9:	int3
   140015dda:	int3
   140015ddb:	int3
   140015ddc:	int3
   140015ddd:	lea    rcx,[rdx+0x60]
   140015de4:	jmp    0x14000b614
   140015de9:	int3
   140015dea:	int3
   140015deb:	int3
   140015dec:	int3
   140015ded:	int3
   140015dee:	int3
   140015def:	lea    rcx,[rdx+0x60]
   140015df6:	jmp    0x14000b5cc
   140015dfb:	int3
   140015dfc:	int3
   140015dfd:	int3
   140015dfe:	int3
   140015dff:	int3
   140015e00:	int3
   140015e01:	lea    rcx,[rdx+0xe0]
   140015e08:	jmp    0x14000f958
   140015e0d:	int3
   140015e0e:	int3
   140015e0f:	int3
   140015e10:	int3
   140015e11:	int3
   140015e12:	int3
   140015e13:	lea    rcx,[rdx+0x20]
   140015e1a:	jmp    0x140003464
   140015e1f:	int3
   140015e20:	int3
   140015e21:	int3
   140015e22:	int3
   140015e23:	int3
   140015e24:	int3
   140015e25:	lea    rcx,[rdx+0x50]
   140015e2c:	jmp    0x1400037d0
   140015e31:	int3
   140015e32:	int3
   140015e33:	int3
   140015e34:	int3
   140015e35:	int3
   140015e36:	int3
   140015e37:	lea    rcx,[rdx+0x40]
   140015e3e:	jmp    0x140009d80
   140015e43:	int3
   140015e44:	int3
   140015e45:	int3
   140015e46:	int3
   140015e47:	int3
   140015e48:	int3
   140015e49:	lea    rcx,[rdx+0x160]
   140015e50:	jmp    0x14000f958
   140015e55:	int3
   140015e56:	int3
   140015e57:	int3
   140015e58:	int3
   140015e59:	int3
   140015e5a:	int3
   140015e5b:	lea    rcx,[rdx+0x80]
   140015e62:	jmp    0x140003464
   140015e67:	int3
   140015e68:	int3
   140015e69:	int3
   140015e6a:	int3
   140015e6b:	int3
   140015e6c:	int3
   140015e6d:	lea    rcx,[rdx+0x88]
   140015e74:	jmp    0x140003464
   140015e79:	int3
   140015e7a:	int3
   140015e7b:	int3
   140015e7c:	int3
   140015e7d:	int3
   140015e7e:	int3
   140015e7f:	mov    rcx,QWORD PTR [rdx+0x70]
   140015e86:	jmp    0x14000f484
   140015e8b:	int3
   140015e8c:	int3
   140015e8d:	int3
   140015e8e:	int3
   140015e8f:	int3
   140015e90:	int3
   140015e91:	lea    rcx,[rdx+0x20]
   140015e98:	jmp    0x1400037d0
   140015e9d:	int3
   140015e9e:	int3
   140015e9f:	int3
   140015ea0:	int3
   140015ea1:	int3
   140015ea2:	int3
   140015ea3:	lea    rcx,[rdx+0x218]
   140015eaa:	jmp    0x140003464
   140015eaf:	int3
   140015eb0:	int3
   140015eb1:	int3
   140015eb2:	int3
   140015eb3:	int3
   140015eb4:	int3
   140015eb5:	lea    rcx,[rdx+0x210]
   140015ebc:	jmp    0x140003464
   140015ec1:	int3
   140015ec2:	int3
   140015ec3:	int3
   140015ec4:	int3
   140015ec5:	int3
   140015ec6:	int3
   140015ec7:	mov    rcx,QWORD PTR [rdx+0x48]
   140015ece:	jmp    0x14000f484
   140015ed3:	int3
   140015ed4:	int3
   140015ed5:	int3
   140015ed6:	int3
   140015ed7:	int3
   140015ed8:	int3
   140015ed9:	mov    rcx,QWORD PTR [rdx+0x40]
   140015ee0:	jmp    0x14000f484
   140015ee5:	int3
   140015ee6:	int3
   140015ee7:	int3
   140015ee8:	int3
   140015ee9:	int3
   140015eea:	int3
   140015eeb:	lea    rcx,[rdx+0x40]
   140015ef2:	jmp    0x1400037d0
   140015ef7:	int3
   140015ef8:	int3
   140015ef9:	int3
   140015efa:	int3
   140015efb:	int3
   140015efc:	int3
   140015efd:	lea    rcx,[rdx+0x1a0]
   140015f04:	jmp    0x14000f958
   140015f09:	int3
   140015f0a:	int3
   140015f0b:	int3
   140015f0c:	int3
   140015f0d:	int3
   140015f0e:	int3
   140015f0f:	lea    rcx,[rdx+0xf8]
   140015f16:	jmp    0x1400121b0
   140015f1b:	int3
   140015f1c:	int3
   140015f1d:	int3
   140015f1e:	int3
   140015f1f:	int3
   140015f20:	int3
   140015f21:	mov    QWORD PTR [rsp+0x10],rdx
   140015f26:	push   rbp
   140015f27:	sub    rsp,0x40
   140015f2b:	mov    rbp,rdx
   140015f2e:	mov    DWORD PTR [rbp+0x48],0x8007000e
   140015f35:	lea    rdx,[rip+0xc0dc]        # 0x140022018
   140015f3c:	lea    rcx,[rbp+0x48]
   140015f40:	call   0x14001478c
   140015f45:	nop
   140015f46:	int3
   140015f47:	int3
   140015f48:	int3
   140015f49:	int3
   140015f4a:	int3
   140015f4b:	int3
   140015f4c:	lea    rcx,[rdx+0x40]
   140015f53:	jmp    0x1400039a4
   140015f58:	int3
   140015f59:	int3
   140015f5a:	int3
   140015f5b:	int3
   140015f5c:	int3
   140015f5d:	int3
   140015f5e:	rex push rbp
   140015f60:	sub    rsp,0x20
   140015f64:	mov    rbp,rdx
   140015f67:	lea    r9,[rip+0xffffffffffffc242]        # 0x1400121b0
   140015f6e:	mov    r8d,0x4
   140015f74:	mov    edx,0x28
   140015f79:	lea    rcx,[rbp+0x90]
   140015f80:	call   0x140015404
   140015f85:	add    rsp,0x20
   140015f89:	pop    rbp
   140015f8a:	ret
   140015f8b:	int3
   140015f8c:	int3
   140015f8d:	int3
   140015f8e:	int3
   140015f8f:	int3
   140015f90:	int3
   140015f91:	int3
   140015f92:	lea    rcx,[rdx+0x60]
   140015f99:	jmp    0x1400121b0
   140015f9e:	int3
   140015f9f:	int3
   140015fa0:	int3
   140015fa1:	int3
   140015fa2:	int3
   140015fa3:	int3
   140015fa4:	mov    rcx,QWORD PTR [rdx+0x148]
   140015fab:	jmp    0x14000f484
   140015fb0:	int3
   140015fb1:	int3
   140015fb2:	int3
   140015fb3:	int3
   140015fb4:	int3
   140015fb5:	int3
   140015fb6:	lea    rcx,[rdx+0x50]
   140015fbd:	jmp    0x14000ee88
   140015fc2:	int3
   140015fc3:	int3
   140015fc4:	int3
   140015fc5:	int3
   140015fc6:	int3
   140015fc7:	int3
   140015fc8:	mov    rcx,QWORD PTR [rdx+0x1b8]
   140015fcf:	jmp    0x14000f484
   140015fd4:	int3
   140015fd5:	int3
   140015fd6:	int3
   140015fd7:	int3
   140015fd8:	int3
   140015fd9:	int3
   140015fda:	mov    rcx,QWORD PTR [rdx+0x2b8]
   140015fe1:	jmp    0x14000f484
   140015fe6:	int3
   140015fe7:	int3
   140015fe8:	int3
   140015fe9:	int3
   140015fea:	int3
   140015feb:	int3
   140015fec:	lea    rcx,[rdx+0x60]
   140015ff3:	jmp    0x14000ee88
   140015ff8:	int3
   140015ff9:	int3
   140015ffa:	int3
   140015ffb:	int3
   140015ffc:	int3
   140015ffd:	int3
   140015ffe:	lea    rcx,[rdx+0x58]
   140016005:	jmp    0x14000b80c
   14001600a:	int3
   14001600b:	int3
   14001600c:	int3
   14001600d:	int3
   14001600e:	int3
   14001600f:	int3
   140016010:	mov    QWORD PTR [rsp+0x10],rdx
   140016015:	push   rbp
   140016016:	sub    rsp,0x20
   14001601a:	mov    rbp,rdx
   14001601d:	lea    rax,[rip+0xffffffffffffac68]        # 0x140010c8c
   140016024:	add    rsp,0x20
   140016028:	pop    rbp
   140016029:	ret
   14001602a:	int3
   14001602b:	mov    QWORD PTR [rsp+0x10],rdx
   140016030:	push   rbp
   140016031:	sub    rsp,0x20
   140016035:	mov    rbp,rdx
   140016038:	lea    rax,[rip+0xffffffffffffac53]        # 0x140010c92
   14001603f:	add    rsp,0x20
   140016043:	pop    rbp
   140016044:	ret
   140016045:	int3
   140016046:	mov    QWORD PTR [rsp+0x10],rdx
   14001604b:	push   rbp
   14001604c:	sub    rsp,0x20
   140016050:	mov    rbp,rdx
   140016053:	lea    rax,[rip+0xffffffffffffac4e]        # 0x140010ca8
   14001605a:	add    rsp,0x20
   14001605e:	pop    rbp
   14001605f:	ret
   140016060:	int3
   140016061:	int3
   140016062:	int3
   140016063:	int3
   140016064:	int3
   140016065:	int3
   140016066:	int3
   140016067:	mov    rcx,QWORD PTR [rdx+0xf8]
   14001606e:	jmp    0x14000f484
   140016073:	int3
   140016074:	int3
   140016075:	int3
   140016076:	int3
   140016077:	int3
   140016078:	int3
   140016079:	mov    rcx,QWORD PTR [rdx+0x1e8]
   140016080:	jmp    0x14000f484
   140016085:	int3
   140016086:	int3
   140016087:	int3
   140016088:	int3
   140016089:	int3
   14001608a:	int3
   14001608b:	mov    QWORD PTR [rsp+0x10],rdx
   140016090:	push   rbp
   140016091:	sub    rsp,0x30
   140016095:	mov    rbp,rdx
   140016098:	lea    rax,[rip+0xffffffffffffb085]        # 0x140011124
   14001609f:	add    rsp,0x30
   1400160a3:	pop    rbp
   1400160a4:	ret
   1400160a5:	int3
   1400160a6:	mov    QWORD PTR [rsp+0x10],rdx
   1400160ab:	push   rbp
   1400160ac:	sub    rsp,0x30
   1400160b0:	mov    rbp,rdx
   1400160b3:	lea    rax,[rip+0xffffffffffffb070]        # 0x14001112a
   1400160ba:	add    rsp,0x30
   1400160be:	pop    rbp
   1400160bf:	ret
   1400160c0:	int3
   1400160c1:	mov    QWORD PTR [rsp+0x10],rdx
   1400160c6:	push   rbp
   1400160c7:	sub    rsp,0x30
   1400160cb:	mov    rbp,rdx
   1400160ce:	lea    rax,[rip+0xffffffffffffb06b]        # 0x140011140
   1400160d5:	add    rsp,0x30
   1400160d9:	pop    rbp
   1400160da:	ret
   1400160db:	int3
   1400160dc:	int3
   1400160dd:	int3
   1400160de:	int3
   1400160df:	int3
   1400160e0:	int3
   1400160e1:	int3
   1400160e2:	mov    rcx,QWORD PTR [rdx+0x108]
   1400160e9:	jmp    0x14000f484
   1400160ee:	int3
   1400160ef:	int3
   1400160f0:	int3
   1400160f1:	int3
   1400160f2:	int3
   1400160f3:	int3
   1400160f4:	lea    rcx,[rdx+0x48]
   1400160fb:	jmp    0x14000ee88
   140016100:	int3
   140016101:	int3
   140016102:	int3
   140016103:	int3
   140016104:	int3
   140016105:	int3
   140016106:	mov    rcx,QWORD PTR [rdx+0x278]
   14001610d:	jmp    0x14000f484
   140016112:	int3
   140016113:	int3
   140016114:	int3
   140016115:	int3
   140016116:	int3
   140016117:	int3
   140016118:	lea    rcx,[rdx+0x270]
   14001611f:	jmp    0x140003464
   140016124:	int3
   140016125:	int3
   140016126:	int3
   140016127:	int3
   140016128:	int3
   140016129:	int3
   14001612a:	mov    QWORD PTR [rsp+0x10],rdx
   14001612f:	push   rbp
   140016130:	sub    rsp,0x70
   140016134:	mov    rbp,rdx
   140016137:	mov    eax,DWORD PTR [rbp+0x164]
   14001613d:	mov    DWORD PTR [rsp+0x30],eax
   140016141:	mov    DWORD PTR [rsp+0x28],0x92e
   140016149:	lea    rax,[rip+0x7520]        # 0x14001d670
   140016150:	mov    QWORD PTR [rsp+0x20],rax
   140016155:	lea    r9,[rip+0x69ec]        # 0x14001cb48
   14001615c:	lea    r8,[rip+0x69fd]        # 0x14001cb60
   140016163:	mov    edx,DWORD PTR [rbp+0x8c]
   140016169:	lea    rcx,[rbp+0x140]
   140016170:	call   0x140011e68
   140016175:	nop
   140016176:	lea    rax,[rip+0xffffffffffffbba9]        # 0x140011d26
   14001617d:	add    rsp,0x70
   140016181:	pop    rbp
   140016182:	ret
   140016183:	int3
   140016184:	mov    QWORD PTR [rsp+0x10],rdx
   140016189:	push   rbp
   14001618a:	sub    rsp,0x70
   14001618e:	mov    rbp,rdx
   140016191:	mov    eax,DWORD PTR [rbp+0x164]
   140016197:	mov    DWORD PTR [rsp+0x30],eax
   14001619b:	mov    DWORD PTR [rsp+0x28],0x92e
   1400161a3:	lea    rax,[rip+0x74c6]        # 0x14001d670
   1400161aa:	mov    QWORD PTR [rsp+0x20],rax
   1400161af:	lea    r9,[rip+0x6992]        # 0x14001cb48
   1400161b6:	lea    r8,[rip+0x69a3]        # 0x14001cb60
   1400161bd:	mov    rdx,QWORD PTR [rbp+0x1b8]
   1400161c4:	lea    rcx,[rbp+0x140]
   1400161cb:	call   0x140011efc
   1400161d0:	nop
   1400161d1:	lea    rax,[rip+0xffffffffffffbb90]        # 0x140011d68
   1400161d8:	add    rsp,0x70
   1400161dc:	pop    rbp
   1400161dd:	ret
   1400161de:	int3
   1400161df:	mov    QWORD PTR [rsp+0x10],rdx
   1400161e4:	push   rbp
   1400161e5:	sub    rsp,0x70
   1400161e9:	mov    rbp,rdx
   1400161ec:	mov    eax,DWORD PTR [rbp+0x164]
   1400161f2:	mov    DWORD PTR [rsp+0x28],eax
   1400161f6:	mov    DWORD PTR [rsp+0x20],0x92e
   1400161fe:	lea    r9,[rip+0x746b]        # 0x14001d670
   140016205:	lea    r8,[rip+0x693c]        # 0x14001cb48
   14001620c:	lea    rdx,[rip+0x694d]        # 0x14001cb60
   140016213:	lea    rcx,[rbp+0x140]
   14001621a:	call   0x140011ff8
   14001621f:	nop
   140016220:	lea    rax,[rip+0xffffffffffffbb43]        # 0x140011d6a
   140016227:	add    rsp,0x70
   14001622b:	pop    rbp
   14001622c:	ret
   14001622d:	int3
   14001622e:	mov    QWORD PTR [rsp+0x10],rdx
   140016233:	push   rbp
   140016234:	sub    rsp,0x70
   140016238:	mov    rbp,rdx
   14001623b:	mov    eax,DWORD PTR [rbp+0x164]
   140016241:	mov    DWORD PTR [rsp+0x30],eax
   140016245:	mov    DWORD PTR [rsp+0x28],0x92e
   14001624d:	lea    rax,[rip+0x741c]        # 0x14001d670
   140016254:	mov    QWORD PTR [rsp+0x20],rax
   140016259:	lea    r9,[rip+0x68e8]        # 0x14001cb48
   140016260:	lea    r8,[rip+0x68f9]        # 0x14001cb60
   140016267:	mov    rdx,QWORD PTR [rbp+0x1c0]
   14001626e:	lea    rcx,[rbp+0x140]
   140016275:	call   0x140012080
   14001627a:	nop
   14001627b:	lea    rax,[rip+0xffffffffffffbaa4]        # 0x140011d26
   140016282:	add    rsp,0x70
   140016286:	pop    rbp
   140016287:	ret
   140016288:	int3
   140016289:	int3
   14001628a:	int3
   14001628b:	int3
   14001628c:	int3
   14001628d:	int3
   14001628e:	int3
   14001628f:	mov    rcx,QWORD PTR [rdx+0x80]
   140016296:	jmp    0x14000f484
   14001629b:	int3
   14001629c:	int3
   14001629d:	int3
   14001629e:	int3
   14001629f:	int3
   1400162a0:	int3
   1400162a1:	lea    rcx,[rdx+0x78]
   1400162a8:	jmp    0x1400039a4
   1400162ad:	int3
   1400162ae:	int3
   1400162af:	int3
   1400162b0:	int3
   1400162b1:	int3
   1400162b2:	int3
   1400162b3:	mov    QWORD PTR [rsp+0x10],rdx
   1400162b8:	push   rbp
   1400162b9:	sub    rsp,0x20
   1400162bd:	mov    rbp,rdx
   1400162c0:	mov    rcx,QWORD PTR [rbp+0x98]
   1400162c7:	mov    QWORD PTR [rbp+0x98],rcx
   1400162ce:	add    rcx,0x1
   1400162d2:	je     0x1400162fe
   1400162d4:	xor    edx,edx
   1400162d6:	or     rax,0xffffffffffffffff
   1400162da:	div    rcx
   1400162dd:	cmp    rax,0x2
   1400162e1:	jae    0x1400162fe
   1400162e3:	xor    edx,edx
   1400162e5:	lea    rcx,[rbp+0x40]
   1400162e9:	call   0x14000ed98
   1400162ee:	lea    rdx,[rip+0xbdab]        # 0x1400220a0
   1400162f5:	lea    rcx,[rbp+0x40]
   1400162f9:	call   0x14001478c
   1400162fe:	add    rcx,rcx
   140016301:	call   0x140014038
   140016306:	mov    QWORD PTR [rbp+0xa8],rax
   14001630d:	lea    rax,[rip+0xffffffffffffc41d]        # 0x140012731
   140016314:	add    rsp,0x20
   140016318:	pop    rbp
   140016319:	ret
   14001631a:	int3
   14001631b:	mov    QWORD PTR [rsp+0x10],rdx
   140016320:	push   rbp
   140016321:	sub    rsp,0x20
   140016325:	mov    rbp,rdx
   140016328:	xor    r8d,r8d
   14001632b:	mov    dl,0x1
   14001632d:	mov    rcx,QWORD PTR [rbp+0x90]
   140016334:	call   0x140012310
   140016339:	xor    edx,edx
   14001633b:	xor    ecx,ecx
   14001633d:	call   0x14001478c
   140016342:	nop
   140016343:	int3
   140016344:	int3
   140016345:	int3
   140016346:	int3
   140016347:	int3
   140016348:	int3
   140016349:	mov    rcx,QWORD PTR [rdx+0x190]
   140016350:	jmp    0x14000f484
   140016355:	int3
   140016356:	int3
   140016357:	int3
   140016358:	int3
   140016359:	int3
   14001635a:	int3
   14001635b:	mov    QWORD PTR [rsp+0x10],rdx
   140016360:	push   rbp
   140016361:	sub    rsp,0x50
   140016365:	mov    rbp,rdx
   140016368:	mov    eax,DWORD PTR [rbp+0x1e4]
   14001636e:	mov    DWORD PTR [rsp+0x30],eax
   140016372:	mov    DWORD PTR [rsp+0x28],0x6be
   14001637a:	lea    rax,[rip+0x7f6f]        # 0x14001e2f0
   140016381:	mov    QWORD PTR [rsp+0x20],rax
   140016386:	lea    r9,[rip+0x7eeb]        # 0x14001e278
   14001638d:	lea    r8,[rip+0x7efc]        # 0x14001e290
   140016394:	mov    edx,DWORD PTR [rbp+0x1a8]
   14001639a:	lea    rcx,[rbp+0x1c0]
   1400163a1:	call   0x140011e68
   1400163a6:	nop
   1400163a7:	lea    rax,[rip+0xffffffffffffd67f]        # 0x140013a2d
   1400163ae:	add    rsp,0x50
   1400163b2:	pop    rbp
   1400163b3:	ret
   1400163b4:	int3
   1400163b5:	mov    QWORD PTR [rsp+0x10],rdx
   1400163ba:	push   rbp
   1400163bb:	sub    rsp,0x50
   1400163bf:	mov    rbp,rdx
   1400163c2:	mov    eax,DWORD PTR [rbp+0x1e4]
   1400163c8:	mov    DWORD PTR [rsp+0x30],eax
   1400163cc:	mov    DWORD PTR [rsp+0x28],0x6be
   1400163d4:	lea    rax,[rip+0x7f15]        # 0x14001e2f0
   1400163db:	mov    QWORD PTR [rsp+0x20],rax
   1400163e0:	lea    r9,[rip+0x7e91]        # 0x14001e278
   1400163e7:	lea    r8,[rip+0x7ea2]        # 0x14001e290
   1400163ee:	mov    rdx,QWORD PTR [rbp+0x238]
   1400163f5:	lea    rcx,[rbp+0x1c0]
   1400163fc:	call   0x140011efc
   140016401:	nop
   140016402:	lea    rax,[rip+0xffffffffffffd708]        # 0x140013b11
   140016409:	add    rsp,0x50
   14001640d:	pop    rbp
   14001640e:	ret
   14001640f:	int3
   140016410:	mov    QWORD PTR [rsp+0x10],rdx
   140016415:	push   rbp
   140016416:	sub    rsp,0x50
   14001641a:	mov    rbp,rdx
   14001641d:	mov    eax,DWORD PTR [rbp+0x1e4]
   140016423:	mov    DWORD PTR [rsp+0x28],eax
   140016427:	mov    DWORD PTR [rsp+0x20],0x6be
   14001642f:	lea    r9,[rip+0x7eba]        # 0x14001e2f0
   140016436:	lea    r8,[rip+0x7e3b]        # 0x14001e278
   14001643d:	lea    rdx,[rip+0x7e4c]        # 0x14001e290
   140016444:	lea    rcx,[rbp+0x1c0]
   14001644b:	call   0x140011ff8
   140016450:	nop
   140016451:	lea    rax,[rip+0xffffffffffffd6be]        # 0x140013b16
   140016458:	add    rsp,0x50
   14001645c:	pop    rbp
   14001645d:	ret
   14001645e:	int3
   14001645f:	mov    QWORD PTR [rsp+0x10],rdx
   140016464:	push   rbp
   140016465:	sub    rsp,0x50
   140016469:	mov    rbp,rdx
   14001646c:	mov    eax,DWORD PTR [rbp+0x1e4]
   140016472:	mov    DWORD PTR [rsp+0x30],eax
   140016476:	mov    DWORD PTR [rsp+0x28],0x6be
   14001647e:	lea    rax,[rip+0x7e6b]        # 0x14001e2f0
   140016485:	mov    QWORD PTR [rsp+0x20],rax
   14001648a:	lea    r9,[rip+0x7de7]        # 0x14001e278
   140016491:	lea    r8,[rip+0x7df8]        # 0x14001e290
   140016498:	mov    rdx,QWORD PTR [rbp+0x240]
   14001649f:	lea    rcx,[rbp+0x1c0]
   1400164a6:	call   0x140012080
   1400164ab:	nop
   1400164ac:	lea    rax,[rip+0xffffffffffffd57a]        # 0x140013a2d
   1400164b3:	add    rsp,0x50
   1400164b7:	pop    rbp
   1400164b8:	ret
   1400164b9:	int3
   1400164ba:	int3
   1400164bb:	int3
   1400164bc:	int3
   1400164bd:	int3
   1400164be:	int3
   1400164bf:	int3
   1400164c0:	lea    rcx,[rdx+0x1c0]
   1400164c7:	jmp    0x14000f958
   1400164cc:	int3
   1400164cd:	int3
   1400164ce:	int3
   1400164cf:	int3
   1400164d0:	int3
   1400164d1:	int3
   1400164d2:	lea    rcx,[rdx+0x50]
   1400164d9:	jmp    0x1400128e0
   1400164de:	int3
   1400164df:	int3
   1400164e0:	int3
   1400164e1:	int3
   1400164e2:	int3
   1400164e3:	int3
   1400164e4:	mov    QWORD PTR [rsp+0x10],rdx
   1400164e9:	push   rbp
   1400164ea:	sub    rsp,0x40
   1400164ee:	mov    rbp,rdx
   1400164f1:	mov    eax,DWORD PTR [rbp+0x124]
   1400164f7:	mov    DWORD PTR [rsp+0x30],eax
   1400164fb:	mov    DWORD PTR [rsp+0x28],0x6e7
   140016503:	lea    rax,[rip+0x7f66]        # 0x14001e470
   14001650a:	mov    QWORD PTR [rsp+0x20],rax
   14001650f:	lea    r9,[rip+0x7d62]        # 0x14001e278
   140016516:	lea    r8,[rip+0x7d73]        # 0x14001e290
   14001651d:	mov    edx,DWORD PTR [rbp+0x50]
   140016520:	lea    rcx,[rbp+0x100]
   140016527:	call   0x140011e68
   14001652c:	nop
   14001652d:	lea    rax,[rip+0xffffffffffffd919]        # 0x140013e4d
   140016534:	add    rsp,0x40
   140016538:	pop    rbp
   140016539:	ret
   14001653a:	int3
   14001653b:	mov    QWORD PTR [rsp+0x10],rdx
   140016540:	push   rbp
   140016541:	sub    rsp,0x40
   140016545:	mov    rbp,rdx
   140016548:	mov    eax,DWORD PTR [rbp+0x124]
   14001654e:	mov    DWORD PTR [rsp+0x30],eax
   140016552:	mov    DWORD PTR [rsp+0x28],0x6e7
   14001655a:	lea    rax,[rip+0x7f0f]        # 0x14001e470
   140016561:	mov    QWORD PTR [rsp+0x20],rax
   140016566:	lea    r9,[rip+0x7d0b]        # 0x14001e278
   14001656d:	lea    r8,[rip+0x7d1c]        # 0x14001e290
   140016574:	mov    rdx,QWORD PTR [rbp+0x178]
   14001657b:	lea    rcx,[rbp+0x100]
   140016582:	call   0x140011efc
   140016587:	nop
   140016588:	lea    rax,[rip+0xffffffffffffd985]        # 0x140013f14
   14001658f:	add    rsp,0x40
   140016593:	pop    rbp
   140016594:	ret
   140016595:	int3
   140016596:	mov    QWORD PTR [rsp+0x10],rdx
   14001659b:	push   rbp
   14001659c:	sub    rsp,0x40
   1400165a0:	mov    rbp,rdx
   1400165a3:	mov    eax,DWORD PTR [rbp+0x124]
   1400165a9:	mov    DWORD PTR [rsp+0x28],eax
   1400165ad:	mov    DWORD PTR [rsp+0x20],0x6e7
   1400165b5:	lea    r9,[rip+0x7eb4]        # 0x14001e470
   1400165bc:	lea    r8,[rip+0x7cb5]        # 0x14001e278
   1400165c3:	lea    rdx,[rip+0x7cc6]        # 0x14001e290
   1400165ca:	lea    rcx,[rbp+0x100]
   1400165d1:	call   0x140011ff8
   1400165d6:	nop
   1400165d7:	lea    rax,[rip+0xffffffffffffd93b]        # 0x140013f19
   1400165de:	add    rsp,0x40
   1400165e2:	pop    rbp
   1400165e3:	ret
   1400165e4:	int3
   1400165e5:	mov    QWORD PTR [rsp+0x10],rdx
   1400165ea:	push   rbp
   1400165eb:	sub    rsp,0x40
   1400165ef:	mov    rbp,rdx
   1400165f2:	mov    eax,DWORD PTR [rbp+0x124]
   1400165f8:	mov    DWORD PTR [rsp+0x30],eax
   1400165fc:	mov    DWORD PTR [rsp+0x28],0x6e7
   140016604:	lea    rax,[rip+0x7e65]        # 0x14001e470
   14001660b:	mov    QWORD PTR [rsp+0x20],rax
   140016610:	lea    r9,[rip+0x7c61]        # 0x14001e278
   140016617:	lea    r8,[rip+0x7c72]        # 0x14001e290
   14001661e:	mov    rdx,QWORD PTR [rbp+0x180]
   140016625:	lea    rcx,[rbp+0x100]
   14001662c:	call   0x140012080
   140016631:	nop
   140016632:	lea    rax,[rip+0xffffffffffffd814]        # 0x140013e4d
   140016639:	add    rsp,0x40
   14001663d:	pop    rbp
   14001663e:	ret
   14001663f:	int3
   140016640:	int3
   140016641:	int3
   140016642:	int3
   140016643:	int3
   140016644:	int3
   140016645:	int3
   140016646:	rex push rbp
   140016648:	sub    rsp,0x20
   14001664c:	mov    rbp,rdx
   14001664f:	mov    rax,QWORD PTR [rcx]
   140016652:	mov    rdx,rcx
   140016655:	mov    ecx,DWORD PTR [rax]
   140016657:	call   0x1400147fe
   14001665c:	nop
   14001665d:	add    rsp,0x20
   140016661:	pop    rbp
   140016662:	ret
   140016663:	int3
   140016664:	int3
   140016665:	int3
   140016666:	int3
   140016667:	int3
   140016668:	int3
   140016669:	int3
   14001666a:	mov    QWORD PTR [rsp+0x10],rdx
   14001666f:	push   rbp
   140016670:	sub    rsp,0x20
   140016674:	mov    rbp,rdx
   140016677:	and    QWORD PTR [rbp+0x50],0x0
   14001667c:	lea    rax,[rip+0xffffffffffffdd8a]        # 0x14001440d
   140016683:	add    rsp,0x20
   140016687:	pop    rbp
   140016688:	ret
   140016689:	int3
   14001668a:	int3
   14001668b:	int3
   14001668c:	int3
   14001668d:	int3
   14001668e:	int3
   14001668f:	int3
   140016690:	rex push rbp
   140016692:	sub    rsp,0x20
   140016696:	mov    rbp,rdx
   140016699:	mov    rax,QWORD PTR [rcx]
   14001669c:	xor    ecx,ecx
   14001669e:	cmp    DWORD PTR [rax],0xc0000005
   1400166a4:	sete   cl
   1400166a7:	mov    eax,ecx
   1400166a9:	add    rsp,0x20
   1400166ad:	pop    rbp
   1400166ae:	ret
   1400166af:	int3
   1400166b0:	int3
   1400166b1:	int3
   1400166b2:	int3
   1400166b3:	int3
   1400166b4:	int3
   1400166b5:	int3
   1400166b6:	mov    rcx,QWORD PTR [rdx+0x40]
   1400166bd:	jmp    0x140014765
   1400166c2:	int3
   1400166c3:	int3
   1400166c4:	int3
   1400166c5:	int3
   1400166c6:	int3
   1400166c7:	int3
   1400166c8:	mov    QWORD PTR [rsp+0x10],rdx
   1400166cd:	push   rbp
   1400166ce:	sub    rsp,0x20
   1400166d2:	mov    rbp,rdx
   1400166d5:	mov    rcx,QWORD PTR [rbp+0x98]
   1400166dc:	mov    QWORD PTR [rbp+0x98],rcx
   1400166e3:	add    rcx,0x1
   1400166e7:	je     0x140016713
   1400166e9:	xor    edx,edx
   1400166eb:	or     rax,0xffffffffffffffff
   1400166ef:	div    rcx
   1400166f2:	cmp    rax,0x1
   1400166f6:	jae    0x140016713
   1400166f8:	xor    edx,edx
   1400166fa:	lea    rcx,[rbp+0x40]
   1400166fe:	call   0x14000ed98
   140016703:	lea    rdx,[rip+0xb996]        # 0x1400220a0
   14001670a:	lea    rcx,[rbp+0x40]
   14001670e:	call   0x14001478c
   140016713:	call   0x140014038
   140016718:	mov    QWORD PTR [rbp+0xa8],rax
   14001671f:	lea    rax,[rip+0xffffffffffffe79b]        # 0x140014ec1
   140016726:	add    rsp,0x20
   14001672a:	pop    rbp
   14001672b:	ret
   14001672c:	int3
   14001672d:	mov    QWORD PTR [rsp+0x10],rdx
   140016732:	push   rbp
   140016733:	sub    rsp,0x20
   140016737:	mov    rbp,rdx
   14001673a:	xor    r8d,r8d
   14001673d:	mov    dl,0x1
   14001673f:	mov    rcx,QWORD PTR [rbp+0x90]
   140016746:	call   0x140015018
   14001674b:	xor    edx,edx
   14001674d:	xor    ecx,ecx
   14001674f:	call   0x14001478c
   140016754:	nop
   140016755:	int3
   140016756:	int3
   140016757:	int3
   140016758:	int3
   140016759:	int3
   14001675a:	int3
   14001675b:	lea    rcx,[rdx+0x28]
   140016762:	jmp    0x140014d44
   140016767:	int3
   140016768:	int3
   140016769:	int3
   14001676a:	int3
   14001676b:	int3
   14001676c:	int3
   14001676d:	rex push rbp
   14001676f:	sub    rsp,0x20
   140016773:	mov    rbp,rdx
   140016776:	cmp    DWORD PTR [rbp+0x20],0x0
   14001677a:	jne    0x140016792
   14001677c:	mov    r9,QWORD PTR [rbp+0x78]
   140016780:	mov    r8d,DWORD PTR [rbp+0x70]
   140016784:	mov    rdx,QWORD PTR [rbp+0x68]
   140016788:	mov    rcx,QWORD PTR [rbp+0x60]
   14001678c:	call   0x140015480
   140016791:	nop
   140016792:	add    rsp,0x20
   140016796:	pop    rbp
   140016797:	ret
   140016798:	int3
   140016799:	int3
   14001679a:	int3
   14001679b:	int3
   14001679c:	int3
   14001679d:	int3
   14001679e:	int3
   14001679f:	rex push rbp
   1400167a1:	sub    rsp,0x20
   1400167a5:	mov    rbp,rdx
   1400167a8:	mov    QWORD PTR [rbp+0x38],rcx
   1400167ac:	mov    QWORD PTR [rbp+0x28],rcx
   1400167b0:	mov    rax,QWORD PTR [rbp+0x28]
   1400167b4:	mov    rcx,QWORD PTR [rax]
   1400167b7:	mov    QWORD PTR [rbp+0x30],rcx
   1400167bb:	mov    rax,QWORD PTR [rbp+0x30]
   1400167bf:	cmp    DWORD PTR [rax],0xe06d7363
   1400167c5:	je     0x1400167d3
   1400167c7:	mov    DWORD PTR [rbp+0x20],0x0
   1400167ce:	mov    eax,DWORD PTR [rbp+0x20]
   1400167d1:	jmp    0x1400167da
   1400167d3:	call   QWORD PTR [rip+0x195f]        # 0x140018138
   1400167d9:	nop
   1400167da:	add    rsp,0x20
   1400167de:	pop    rbp
   1400167df:	ret
   1400167e0:	int3
   1400167e1:	int3
   1400167e2:	int3
   1400167e3:	int3
   1400167e4:	int3
   1400167e5:	int3
   1400167e6:	int3
   1400167e7:	rex push rbp
   1400167e9:	sub    rsp,0x20
   1400167ed:	mov    rbp,rdx
   1400167f0:	cmp    DWORD PTR [rbp+0x24],0x0
   1400167f4:	jne    0x14001680c
   1400167f6:	mov    r9,QWORD PTR [rbp+0x70]
   1400167fa:	mov    r8d,DWORD PTR [rbp+0x20]
   1400167fe:	mov    rdx,QWORD PTR [rbp+0x58]
   140016802:	mov    rcx,QWORD PTR [rbp+0x50]
   140016806:	call   0x140015480
   14001680b:	nop
   14001680c:	add    rsp,0x20
   140016810:	pop    rbp
   140016811:	ret
   140016812:	int3
