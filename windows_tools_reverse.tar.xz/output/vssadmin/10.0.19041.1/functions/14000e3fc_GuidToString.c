/*
 * Function : GuidToString
 * Address  : 0x14000e3fc
 * Size     : 403 bytes (91 instructions)
 * Prototype: ushort * GuidToString(_GUID * param_1)
 * CC       : __cdecl
 * Comment  : unsigned short * __ptr64 __cdecl GuidToString(struct _GUID)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* unsigned short * __ptr64 __cdecl GuidToString(struct _GUID) */

ushort * __cdecl GuidToString(_GUID *param_1)

{
  DWORD DVar1;
  ushort *puVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe78;
  undefined8 uVar3;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  uVar3 = 0xfffffffffffffffe;
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_138 = L"GuidToString";
  local_130 = L"ADMUTILC";
  local_128 = 0x463;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  puVar2 = CoTaskMemAlloc(0x50);
  if (puVar2 != (ushort *)0x0) {
    StringCchPrintfW(puVar2,0x28,(ushort *)L"{%.8x-%.4x-%.4x-%.2x%.2x-%.2x%.2x%.2x%.2x%.2x%.2x}",
                     (ulonglong)param_1->Data1,(uint)param_1->Data2,(uint)param_1->Data3,
                     (uint)param_1->Data4[0],(uint)param_1->Data4[1],(uint)param_1->Data4[2],
                     (uint)param_1->Data4[3],(uint)param_1->Data4[4],(uint)param_1->Data4[5],
                     (uint)param_1->Data4[6],(uint)param_1->Data4[7],uVar3);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return puVar2;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_140,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"GuidToString",0x46b,7,
                     in_stack_fffffffffffffe78);
  DVar1 = GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar3,0x8007000e,L"Error from CoTaskMemAlloc: 0x%08lx",DVar1);
}


