/*
 * Function : ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z
 * Address  : 0x1400092e4
 * Size     : 342 bytes (82 instructions)
 * Prototype: void ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::QueryRevert(unsigned short * __ptr64,struct IVssCoordinator * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: void __cdecl CVssAdminCLI::QueryRevert(unsigned short * __ptr64,struct IVssCoordinator *
   __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
          (CVssAdminCLI *this,ushort *param_1,IVssCoordinator *param_2)

{
  int local_res18 [2];
  uint local_res20 [2];
  longlong *local_148;
  undefined8 local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [8];
  int local_80;
  
  local_140 = 0xfffffffffffffffe;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_130 = L"CVssAdminCLI::QueryRevert";
  local_128 = L"ADMPROCC";
  local_120 = 0x5e8;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_138);
  local_148 = (longlong *)0x0;
  local_80 = (**(code **)(*(longlong *)param_2 + 0x70))(param_2,param_1,&local_148);
  if (-1 < local_80) {
    local_res18[0] = 0;
    local_res20[0] = 0;
    local_80 = (**(code **)(*local_148 + 0x28))(local_148,local_res18,local_res20);
    if ((local_80 < 0) || (local_res18[0] < 0)) {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002772,param_1);
    }
    else {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002771,param_1,(ulonglong)local_res20[0]);
    }
  }
  if (local_148 != (longlong *)0x0) {
    (**(code **)(*local_148 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}


