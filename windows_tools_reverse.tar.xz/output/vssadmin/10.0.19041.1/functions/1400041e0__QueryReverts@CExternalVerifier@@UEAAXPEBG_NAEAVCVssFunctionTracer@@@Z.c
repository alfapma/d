/*
 * Function : ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z
 * Address  : 0x1400041e0
 * Size     : 180 bytes (37 instructions)
 * Prototype: void ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CExternalVerifier::QueryReverts(unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CExternalVerifier::QueryReverts(unsigned short const *
   __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::_QueryReverts_CExternalVerifier__UEAAXPEBG_NAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,ushort *param_1,bool param_2,CVssFunctionTracer *param_3)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  if (param_1 == (ushort *)0x0) {
    if (!param_2) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::QueryReverts",0x13b,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_3,uVar1,0x1008,
                 L"CVssAdminCLI::QueryReverts: must specify either For or All parameter");
    }
  }
  else if (param_2) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::QueryReverts",0x138,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_3,uVar1,0x1008,
               L"CVssAdminCLI::QueryReverts: Can\'t specify both For and All options");
  }
  return;
}


