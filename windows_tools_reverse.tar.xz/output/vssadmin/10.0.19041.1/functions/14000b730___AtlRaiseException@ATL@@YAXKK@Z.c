/*
 * Function : ?_AtlRaiseException@ATL@@YAXKK@Z
 * Address  : 0x14000b730
 * Size     : 22 bytes (5 instructions)
 * Prototype: void ?_AtlRaiseException@ATL@@YAXKK@Z(ulong param_1, ulong param_2)
 * CC       : __cdecl
 * Comment  : void __cdecl ATL::_AtlRaiseException(unsigned long,unsigned long)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl ATL::_AtlRaiseException(unsigned long,unsigned long) */

void __cdecl ATL::__AtlRaiseException_ATL__YAXKK_Z(ulong param_1,ulong param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00014000b73f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  RaiseException(0xc000008c,1,0);
  return;
}


