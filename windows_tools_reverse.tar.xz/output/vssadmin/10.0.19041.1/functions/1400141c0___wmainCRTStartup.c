/*
 * Function : __wmainCRTStartup
 * Address  : 0x1400141c0
 * Size     : 446 bytes (105 instructions)
 * Prototype: int __wmainCRTStartup(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

int __wmainCRTStartup(void)

{
  void *pvVar1;
  bool bVar2;
  void *pvVar3;
  int iVar4;
  BOOL BVar5;
  void *pvVar6;
  longlong *plVar7;
  bool bVar8;
  
  pvVar1 = StackBase;
  bVar2 = false;
  while( true ) {
    pvVar6 = (void *)0x0;
    LOCK();
    bVar8 = __native_startup_lock == (void *)0x0;
    pvVar3 = pvVar1;
    if (!bVar8) {
      pvVar6 = __native_startup_lock;
      pvVar3 = __native_startup_lock;
    }
    __native_startup_lock = pvVar3;
    UNLOCK();
    if (bVar8) goto LAB_140014211;
    if (pvVar6 == pvVar1) break;
    Sleep(1000);
  }
  bVar2 = true;
LAB_140014211:
  if (__native_startup_state == 1) {
    _amsg_exit(0x1f);
  }
  else if (__native_startup_state == 0) {
    __native_startup_state = 1;
    iVar4 = 0;
    for (plVar7 = &__xi_a; plVar7 < &__xi_z; plVar7 = plVar7 + 1) {
      if (iVar4 != 0) {
        return 0xff;
      }
      if (*plVar7 != 0) {
        iVar4 = (*(code *)*plVar7)(_guard_dispatch_icall);
      }
    }
    if (iVar4 != 0) {
      return 0xff;
    }
  }
  else {
    DAT_140024144 = 1;
  }
  if (__native_startup_state == 1) {
    _initterm(&__xc_a,&__xc_z);
    __native_startup_state = 2;
  }
  if (!bVar2) {
    LOCK();
    __native_startup_lock = (void *)0x0;
    UNLOCK();
  }
  if ((__dyn_tls_init_callback != 0) &&
     (BVar5 = _IsNonwritableInCurrentImage((PBYTE)&__dyn_tls_init_callback), BVar5 != 0)) {
    (*(code *)__dyn_tls_init_callback)(0,2,0,_guard_dispatch_icall);
  }
  DAT_140024140 = wmain(DAT_140024148,DAT_140024150,DAT_140024158);
  if (DAT_140024160 == 0) {
                    /* WARNING: Subroutine does not return */
    exit(DAT_140024140);
  }
  if (DAT_140024144 == 0) {
    _cexit();
  }
  return DAT_140024140;
}


