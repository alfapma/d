/*
 * Function : ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z
 * Address  : 0x14000c9e4
 * Size     : 914 bytes (186 instructions)
 * Prototype: void ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z(CVssAdminCLI * this, ushort * param_1, __uint64 param_2, long param_3, ulong param_4, ushort * param_5)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::AppendMessageToStr(unsigned short * __ptr64,unsigned __int64,long,unsigned long,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::AppendMessageToStr(unsigned short * __ptr64,unsigned
   __int64,long,unsigned long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
          (CVssAdminCLI *this,ushort *param_1,__uint64 param_2,long param_3,ulong param_4,
          ushort *param_5)

{
  long lVar1;
  ushort *pv;
  undefined8 uVar2;
  undefined1 auStackY_318 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffd18;
  wchar_t *local_2c8;
  wchar_t *local_2c0;
  wchar_t *local_2b8;
  undefined4 local_2b0;
  undefined4 local_2ac;
  undefined4 local_2a8;
  undefined1 local_2a0 [120];
  undefined4 local_228;
  undefined8 local_220;
  CVssFunctionTracer local_218 [8];
  long local_210;
  CVssDebugInfo local_1a8 [176];
  wchar_t *local_f8;
  wchar_t *local_f0;
  wchar_t *local_e8;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined4 local_d8;
  undefined1 local_d0 [120];
  undefined4 local_58;
  ulonglong local_48;
  
  local_220 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_318;
  local_2c8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_2c0 = L"CVssAdminCLI::AppendMessageToStr";
  local_2b8 = L"ADMUTILC";
  local_2b0 = 0x1ab;
  local_2ac = 7;
  local_2a8 = 0xff;
  local_228 = 0x1000000;
  memset(local_2a0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_218);
  if (*param_1 != 0) {
    lVar1 = StringCchCatW(param_1,0x400,(ushort *)L", ");
    local_f8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_f0 = L"CVssAdminCLI::AppendMessageToStr";
    local_e8 = L"ADMUTILC";
    local_e0 = 0x1b1;
    local_dc = 7;
    local_d8 = 0xff;
    local_58 = 0x1000000;
    local_210 = lVar1;
    memset(local_d0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                        ((CVssDebugInfo *)&local_2c8,(CVssDebugInfo *)&local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_f8);
  }
  if (param_3 == 0) {
    StringCchPrintfW((ushort *)&local_f8,0x40,(ushort *)L"0x%x",(ulonglong)param_4);
    lVar1 = StringCchCatW(param_1,0x400,(ushort *)&local_f8);
    local_2c8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_2c0 = L"CVssAdminCLI::AppendMessageToStr";
    local_2b8 = L"ADMUTILC";
    local_2b0 = 0x1ce;
    local_2ac = 7;
    local_2a8 = 0xff;
    local_228 = 0x1000000;
    local_210 = lVar1;
    memset(local_2a0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_1a8,(CVssDebugInfo *)&local_2c8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_2c8);
  }
  else {
    pv = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,param_3);
    if (pv == (ushort *)0x0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_2c8,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::AppendMessageToStr",0x1bb,7
                         ,in_stack_fffffffffffffd18);
      GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_218,uVar2,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
    }
    lVar1 = StringCchCatW(param_1,0x400,pv);
    local_f8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_f0 = L"CVssAdminCLI::AppendMessageToStr";
    local_e8 = L"ADMUTILC";
    local_e0 = 0x1c1;
    local_dc = 7;
    local_d8 = 0xff;
    local_58 = 0x1000000;
    local_210 = lVar1;
    memset(local_d0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                        ((CVssDebugInfo *)&local_2c8,(CVssDebugInfo *)&local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_f8);
    CoTaskMemFree(pv);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_218);
  return;
}


