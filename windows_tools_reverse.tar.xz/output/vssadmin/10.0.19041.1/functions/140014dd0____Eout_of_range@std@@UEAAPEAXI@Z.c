/*
 * Function : ??_Eout_of_range@std@@UEAAPEAXI@Z
 * Address  : 0x140014dd0
 * Size     : 94 bytes (25 instructions)
 * Prototype: void * ??_Eout_of_range@std@@UEAAPEAXI@Z(out_of_range * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
std::out_of_range::___Eout_of_range_std__UEAAPEAXI_Z(out_of_range *this,uint param_1)

{
  *(undefined ***)this = &logic_error::_vftable_;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    operator_delete__(*(void **)(this + 0x20));
  }
  *(undefined8 *)(this + 0x30) = 0;
  *(undefined8 *)(this + 0x38) = 0xf;
  this[0x20] = (out_of_range)0x0;
  exception::__1exception__UEAA_XZ((exception *)this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


