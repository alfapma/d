/*
 * Function : _CxxThrowException
 * Address  : 0x14001478c
 * Size     : 6 bytes (1 instructions)
 * Prototype: void _CxxThrowException(void * pExceptionObject, ThrowInfo * pThrowInfo)
 * CC       : __stdcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void __stdcall _CxxThrowException(void *pExceptionObject,ThrowInfo *pThrowInfo)

{
                    /* WARNING: Could not recover jumptable at 0x00014001478c. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  _CxxThrowException(pExceptionObject,pThrowInfo);
  return;
}


