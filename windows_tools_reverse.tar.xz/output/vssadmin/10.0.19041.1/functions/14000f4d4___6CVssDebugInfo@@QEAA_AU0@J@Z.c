/*
 * Function : ??6CVssDebugInfo@@QEAA?AU0@J@Z
 * Address  : 0x14000f4d4
 * Size     : 321 bytes (76 instructions)
 * Prototype: CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@J@Z(CVssDebugInfo * this, long param_1)
 * CC       : __thiscall
 * Comment  : public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(long) __ptr64 */

ushort * __thiscall CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(CVssDebugInfo *this,long param_1)

{
  DWORD DVar1;
  HMODULE hLibModule;
  undefined4 in_register_00000014;
  DWORD in_R8D;
  undefined1 auStackY_8c8 [32];
  WCHAR local_888 [520];
  ushort local_478 [544];
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_8c8;
  hLibModule = LoadLibraryExW(L"vsstrace.dll",(HANDLE)0x0,2);
  DVar1 = FormatMessageW(0x1200,(LPCVOID)0x0,in_R8D,0x400,local_888,0x200,(va_list *)0x0);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW(0xa00,hLibModule,in_R8D,0x400,local_888,0x200,(va_list *)0x0);
    if (DVar1 == 0) {
      local_888[0] = L'\0';
    }
  }
  if (hLibModule != (HMODULE)0x0) {
    FreeLibrary(hLibModule);
  }
  if (local_888[0] == L'\0') {
    StringCchPrintfW(local_478,0x21f,(ushort *)L"0x%08lx",(ulonglong)in_R8D);
  }
  else {
    StringCchPrintfW(local_478,0x21f,(ushort *)L"0x%08lx, %s",(ulonglong)in_R8D);
  }
  __6CVssDebugInfo__QEAA_AU0_PEBG_Z(this,(ushort *)CONCAT44(in_register_00000014,param_1));
  return (ushort *)CONCAT44(in_register_00000014,param_1);
}


