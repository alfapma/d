/*
 * Function : _amsg_exit
 * Address  : 0x1400148b3
 * Size     : 6 bytes (1 instructions)
 * Prototype: void _amsg_exit(int param_1)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void __cdecl _amsg_exit(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001400148b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _amsg_exit(param_1);
  return;
}


