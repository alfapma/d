/*
 * Function : ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ
 * Address  : 0x14000ff98
 * Size     : 298 bytes (74 instructions)
 * Prototype: void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(struct CVssDebugInfo,unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(struct CVssDebugInfo,unsigned
   short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined4 param_4,
          ushort *param_5,...)

{
  undefined4 uVar1;
  int iVar2;
  wchar_t *pwVar3;
  undefined8 uVar4;
  ulong in_stack_fffffffffffffef8;
  wchar_t *pwVar5;
  __uint64 local_e8;
  ushort *local_e0;
  CVssDebugInfo local_d8 [176];
  
  uVar1 = *(undefined4 *)(param_2 + 0x1c);
  iVar2 = Ordinal_5();
  if (iVar2 != 0) {
    iVar2 = Ordinal_7(uVar1);
    if (iVar2 != 0) {
      _UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ(this);
      if (*(int *)this != 0) {
        pwVar3 = operator_new__(0x3ea,&std::nothrow);
        if (pwVar3 == (wchar_t *)0x0) {
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
          pwVar5 = L"TraceInternalWithFormat failed due to out of memory condition";
        }
        else {
          local_e8 = 0;
          local_e0 = (ushort *)0x0;
          StringCchVPrintfExW((ushort *)pwVar3,500,&local_e0,&local_e8,in_stack_fffffffffffffef8,
                              param_5,&stack0x00000030);
          if (local_e8 == 1) {
            local_e0[-2] = 0x2e;
            local_e0[-1] = 0x2e;
            local_e0[-3] = 0x2e;
          }
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
          pwVar5 = pwVar3;
        }
        _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                  (this,uVar4,param_3,param_4,pwVar5);
        operator_delete__(pwVar3);
      }
    }
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}


