/*
 * Function : ?ListProviders@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140007e44
 * Size     : 1128 bytes (253 instructions)
 * Prototype: void ?ListProviders@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ListProviders(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListProviders(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListProviders_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  wchar_t *pv;
  LPVOID pv_00;
  ushort *puVar1;
  ushort *pv_01;
  undefined4 uVar2;
  uint uVar3;
  wchar_t *pwVar4;
  undefined1 auStackY_288 [32];
  _VSSDBG_SEV_ENUM _Var5;
  longlong **pplVar6;
  undefined1 local_248 [8];
  longlong *local_240;
  longlong *local_238 [2];
  undefined1 local_228 [16];
  undefined1 local_218 [16];
  undefined **local_208;
  LPVOID local_200;
  wchar_t *local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  undefined4 local_1e0;
  undefined4 local_1dc;
  undefined4 local_1d8;
  undefined1 local_1d0 [120];
  undefined4 local_158;
  undefined8 local_150;
  _GUID local_148;
  CVssFunctionTracer local_138 [8];
  int local_130;
  undefined1 local_c8 [8];
  _GUID local_c0;
  wchar_t *local_b0;
  int local_a8;
  LPVOID local_a0;
  ulonglong local_38;
  
  local_150 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_288;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::ListProviders";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x478;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_138);
  local_238[0] = (longlong *)0x0;
  local_228 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_218 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::ListProviders";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x483;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  pplVar6 = local_238;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_138,&local_1f8,local_218,L"Coordinator");
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListProviders",0x48a,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_240 = (longlong *)0x0;
  local_228 = ZEXT816(0);
  local_130 = (**(code **)(*local_238[0] + 0x50))(local_238[0],local_228,1,4);
  if (-1 < local_130) {
    local_130 = (**(code **)(*local_240 + 0x18))(local_240,1,local_c8,local_248);
    _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
    if (-1 < local_130) {
      uVar2 = 1;
      do {
        if (local_130 == 1) {
          *(undefined4 *)(this + 0x48) = uVar2;
          if (local_240 != (longlong *)0x0) {
            (**(code **)(*local_240 + 0x10))();
          }
          if (local_238[0] != (longlong *)0x0) {
            (**(code **)(*local_238[0] + 0x10))();
          }
          CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
          return;
        }
        if (local_a8 == 1) {
          uVar3 = 0x67;
        }
        else if (local_a8 == 2) {
          uVar3 = 0x68;
        }
        else if (local_a8 == 3) {
          uVar3 = 0x69;
        }
        else if (local_a8 == 4) {
          uVar3 = 0x7a;
        }
        else {
          uVar3 = 0x6a;
        }
        puVar1 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar3);
        local_148.Data1 = local_c0.Data1;
        local_148.Data2 = local_c0.Data2;
        local_148.Data3 = local_c0.Data3;
        local_148.Data4[0] = local_c0.Data4[0];
        local_148.Data4[1] = local_c0.Data4[1];
        local_148.Data4[2] = local_c0.Data4[2];
        local_148.Data4[3] = local_c0.Data4[3];
        local_148.Data4[4] = local_c0.Data4[4];
        local_148.Data4[5] = local_c0.Data4[5];
        local_148.Data4[6] = local_c0.Data4[6];
        local_148.Data4[7] = local_c0.Data4[7];
        pv_01 = GuidToString(&local_148);
        pv_00 = local_a0;
        pv = local_b0;
        local_228._8_8_ = pv_01;
        local_228._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_218._8_8_ = local_b0;
        local_218._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_200 = local_a0;
        local_208 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        pwVar4 = L"";
        if (local_b0 != (wchar_t *)0x0) {
          pwVar4 = local_b0;
        }
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002756,pwVar4,puVar1);
        if (pv_00 != (LPVOID)0x0) {
          CoTaskMemFree(pv_00);
        }
        local_200 = (LPVOID)0x0;
        local_208 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        if (pv != (wchar_t *)0x0) {
          CoTaskMemFree(pv);
        }
        local_218 = ZEXT816(0x140017068);
        if (pv_01 != (ushort *)0x0) {
          CoTaskMemFree(pv_01);
        }
        local_228 = ZEXT816(0x140017068);
        local_130 = (**(code **)(*local_240 + 0x18))(local_240,1,local_c8,local_248);
        _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
        uVar2 = 0;
      } while (-1 < local_130);
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListProviders",0x49d,7,_Var5);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1f8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdminCLI::ListProviders",0x493,7,(_VSSDBG_SEV_ENUM)pplVar6);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
}


