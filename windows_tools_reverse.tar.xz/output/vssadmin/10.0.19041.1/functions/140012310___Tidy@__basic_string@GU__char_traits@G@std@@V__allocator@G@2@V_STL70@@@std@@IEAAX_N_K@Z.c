/*
 * Function : ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_N_K@Z
 * Address  : 0x140012310
 * Size     : 119 bytes (32 instructions)
 * Prototype: void ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, bool param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
    */

void __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Tidy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_N_K_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,bool param_1,__uint64 param_2)

{
  void *_Src;
  
  if ((param_1) && (7 < *(ulonglong *)(this + 0x20))) {
    _Src = *(void **)(this + 8);
    if (param_2 != 0) {
      memcpy_s(this + 8,0x10,_Src,param_2 * 2);
    }
    operator_delete__(_Src);
  }
  *(undefined8 *)(this + 0x20) = 7;
  *(__uint64 *)(this + 0x18) = param_2;
  *(undefined2 *)(this + param_2 * 2 + 8) = 0;
  return;
}


