/*
 * Function : __std_terminate
 * Address  : 0x1400143e4
 * Size     : 10 bytes (2 instructions)
 * Prototype: undefined __std_terminate(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void __std_terminate(void)

{
                    /* WARNING: Subroutine does not return */
  terminate();
}


