/*
 * Function : ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ
 * Address  : 0x1400037d0
 * Size     : 61 bytes (16 instructions)
 * Prototype: void ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >::~CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64>
   >::~CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >(void) __ptr64 */

void __thiscall
CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
__1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
          (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}


