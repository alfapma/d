/*
 * Function : ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z
 * Address  : 0x14000f744
 * Size     : 209 bytes (55 instructions)
 * Prototype: CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z(CVssDebugInfo * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(unsigned short const * __ptr64)
   __ptr64 */

ushort * __thiscall
CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(CVssDebugInfo *this,ushort *param_1)

{
  ushort *puVar1;
  longlong lVar2;
  __uint64 _Var4;
  ushort *in_R8;
  longlong lVar3;
  
  if ((((in_R8 != (ushort *)0x0) && (this[0xa2] == (CVssDebugInfo)0x0)) &&
      (this[0xa3] != (CVssDebugInfo)0x0)) && (*(ushort *)(this + 0xa0) < 0xf)) {
    lVar2 = -1;
    do {
      lVar3 = lVar2;
      lVar2 = lVar3 + 1;
    } while (in_R8[lVar2] != 0);
    _Var4 = lVar3 + 2;
    puVar1 = CoTaskMemAlloc(_Var4 * 2);
    if (puVar1 == (ushort *)0x0) {
      this[0xa2] = (CVssDebugInfo)0x1;
    }
    else {
      StringCchCopyW(puVar1,_Var4,in_R8);
      *(ushort **)(this + (ulonglong)*(ushort *)(this + 0xa0) * 8 + 0x28) = puVar1;
      *(short *)(this + 0xa0) = *(short *)(this + 0xa0) + 1;
    }
  }
  __0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)param_1,this);
  return param_1;
}


