/*
 * Function : catch$24
 * Address  : 0x1400158c0
 * Size     : 87 bytes (19 instructions)
 * Prototype: undefined * catch$24(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssAdminCLI::Main'::__l1::catch_24(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(exception **)(param_2 + 400),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002b93;
}


