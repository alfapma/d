/*
 * Function : ?PrintUsage@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x1400051f4
 * Size     : 828 bytes (190 instructions)
 * Prototype: void ?PrintUsage@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::PrintUsage(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::PrintUsage(void) __ptr64 */

void __thiscall CVssAdminCLI::_PrintUsage_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  long lVar2;
  longlong lVar3;
  __int64 _Var4;
  longlong lVar5;
  ushort *pv;
  undefined8 uVar7;
  undefined **ppuVar8;
  undefined **ppuVar9;
  int iVar10;
  wchar_t **local_res8 [2];
  wchar_t *local_218;
  wchar_t *local_210;
  wchar_t *local_208;
  undefined4 local_200;
  undefined4 local_1fc;
  undefined4 local_1f8;
  undefined1 local_1f0 [120];
  undefined4 local_178;
  undefined8 local_170;
  undefined **local_168;
  ushort *local_160;
  CVssFunctionTracer local_158 [8];
  long local_150;
  CVssDebugInfo local_e8 [176];
  longlong lVar6;
  
  local_170 = 0xfffffffffffffffe;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdminCLI::PrintUsage";
  local_208 = L"ADMPROCC";
  local_200 = 0x133;
  local_1fc = 7;
  local_1f8 = 0xff;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_218);
  if (*(int *)(this + 0x60) == 0x17) {
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002724);
    iVar10 = 0;
    ppuVar9 = &PTR_u_ShadowStorage_1400172a8;
    ppuVar8 = &PTR_u_ShadowStorage_1400172a8;
    do {
      if ((*(uint *)((longlong)ppuVar8 + 0xc) & dCurrentSKU) != 0) {
        lVar3 = -1;
        do {
          lVar3 = lVar3 + 1;
        } while (*(short *)(ppuVar8[-1] + lVar3 * 2) != 0);
        lVar5 = -1;
        do {
          lVar6 = lVar5;
          lVar5 = lVar6 + 1;
        } while (*(short *)(*ppuVar8 + lVar5 * 2) != 0);
        iVar1 = (int)lVar6 + 3 + (int)lVar3;
        if (iVar10 < iVar1) {
          iVar10 = iVar1;
        }
      }
      ppuVar8 = ppuVar8 + 0xc;
    } while ((longlong)ppuVar8 < 0x140017ae8);
    local_168 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    lVar3 = (longlong)iVar10;
    pv = CoTaskMemAlloc(lVar3 * 2 + 2);
    local_160 = pv;
    if (pv == (ushort *)0x0) {
      local_res8[0] = (wchar_t **)CONCAT44(local_res8[0]._4_4_,0x8007000e);
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    do {
      if ((dCurrentSKU & *(uint *)((longlong)ppuVar9 + 0xc)) != 0) {
        lVar2 = StringCchPrintfW(pv,(longlong)(iVar10 + 1),(ushort *)L"%s %s",ppuVar9[-1],*ppuVar9);
        local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_210 = L"CVssAdminCLI::PrintUsage";
        local_208 = L"ADMPROCC";
        local_200 = 0x17e;
        local_1fc = 7;
        local_1f8 = 0xff;
        local_178 = 0x1000000;
        local_150 = lVar2;
        memset(local_1f0,0,0x78);
        local_res8[0] = &local_218;
        if (lVar2 < 0) {
          uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e8,(CVssDebugInfo *)&local_218);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar7,lVar2,L"StringCchPrintf");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_218);
        lVar5 = -1;
        do {
          lVar5 = lVar5 + 1;
        } while (pv[lVar5] != 0);
        for (lVar5 = (longlong)(int)lVar5; lVar5 < lVar3; lVar5 = lVar5 + 1) {
          pv[lVar5] = 0x20;
        }
        pv[lVar3] = 0;
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,*(long *)(ppuVar9 + 2),pv);
      }
      ppuVar9 = ppuVar9 + 0xc;
    } while ((longlong)ppuVar9 < 0x140017ae8);
    *(undefined4 *)(this + 0x48) = 0;
    CoTaskMemFree(pv);
  }
  else {
    lVar3 = (longlong)*(int *)(this + 0x60);
    iVar10 = *(int *)(&DAT_1400172bc + lVar3 * 0x60);
    if ((iVar10 == 0x40002766) || (iVar10 == 0x4000276d)) {
      _Var4 = CVssMachineInformation::_GetMinDiffAreaForSystem_CVssMachineInformation__SA_JXZ();
      lVar3 = (longlong)*(int *)(this + 0x60);
      _OutputMsg_CVssAdminCLI__AEAAXJZZ
                (this,*(long *)(&DAT_1400172bc + lVar3 * 0x60),(&g_asAdmCommands)[lVar3 * 0xc],
                 (&PTR_u_ShadowStorage_1400172a8)[lVar3 * 0xc],
                 (longlong)(_Var4 + (ulonglong)((uint)(_Var4 >> 0x3f) & 0xfffff)) >> 0x14);
    }
    else {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ
                (this,iVar10,(&g_asAdmCommands)[lVar3 * 0xc],
                 (&PTR_u_ShadowStorage_1400172a8)[lVar3 * 0xc]);
    }
    if (*(int *)(&DAT_1400172c0 + (longlong)*(int *)(this + 0x60) * 0x60) != 0) {
      _DumpSnapshotTypes_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
  return;
}


