/*
 * Function : ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z
 * Address  : 0x1400038f8
 * Size     : 164 bytes (34 instructions)
 * Prototype: ushort * ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetOptionValueStr(enum EVssAdmOption) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetOptionValueStr(enum EVssAdmOption)
   __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z
          (CVssAdminCLI *this,EVssAdmOption param_1)

{
  ushort *puVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_110 = 0x150;
  local_120 = L"CVssAdminCLI::GetOptionValueStr";
  local_10c = 7;
  local_118 = L"INCPNTRH";
  local_108 = 0xff;
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  puVar1 = *(ushort **)(this + (longlong)(int)param_1 * 8 + 0x68);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return puVar1;
}


