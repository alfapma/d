/*
 * Function : ??1CVssAutoCoString@@QEAA@XZ
 * Address  : 0x1400039a4
 * Size     : 34 bytes (10 instructions)
 * Prototype: void ??1CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAutoCoString::~CVssAutoCoString(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssAutoCoString::~CVssAutoCoString(void) __ptr64 */

void __thiscall CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ(CVssAutoCoString *this)

{
  CoTaskMemFree(*(LPVOID *)this);
  *(undefined8 *)this = 0;
  return;
}


