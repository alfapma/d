/*
 * Function : ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z
 * Address  : 0x140010848
 * Size     : 359 bytes (80 instructions)
 * Prototype: void ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TranslateError(struct CVssDebugInfo,long,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TranslateError(struct CVssDebugInfo,long,unsigned short
   const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,undefined8 param_4)

{
  undefined8 uVar1;
  CVssDebugInfo *this_00;
  ulonglong uVar2;
  CVssDebugInfo local_168 [168];
  CVssDebugInfo local_c0 [168];
  
  uVar2 = 0x8007000e;
  if ((((param_3 == -0x7ff8fff2) || (param_3 == -0x7ff8fff8)) || (param_3 == -0x7ff8ff8f)) ||
     (((param_3 == -0x7ff8fc05 || (param_3 == -0x7ff8fa56)) || (param_3 == -0x7ff8fb7a)))) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,uVar2 & 0xffffffff,L"Out of memory detected in function %s",param_4);
  }
  if (param_3 == -0x7ff8ff90) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_168,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x8004231f,L"ERROR_DISK_FULL detected in function %s",param_4);
  }
  uVar2 = 0x80042316;
  if (param_3 == -0x7ffbdcea) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_168,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,uVar2 & 0xffffffff,
               L"VSS_E_SNAPSHOT_SET_IN_PROGRESS detected in function %s",param_4);
  }
  this_00 = (CVssDebugInfo *)
            CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_c0);
  uVar1 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_168);
  _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar1);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_c0);
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c0,param_2);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (this,uVar1,0x80042302,L"Unexpected error in routine %s.  hr = 0x%08lx",param_4,param_3)
  ;
}


