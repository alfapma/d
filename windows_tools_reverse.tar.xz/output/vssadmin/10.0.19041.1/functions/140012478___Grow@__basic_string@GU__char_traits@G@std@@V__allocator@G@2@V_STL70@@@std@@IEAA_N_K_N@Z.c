/*
 * Function : ?_Grow@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAA_N_K_N@Z
 * Address  : 0x140012478
 * Size     : 116 bytes (34 instructions)
 * Prototype: bool ?_Grow@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAA_N_K_N@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, bool param_2)
 * CC       : __thiscall
 * Comment  : protected: bool __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Grow(unsigned __int64,bool) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: bool __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Grow(unsigned __int64,bool) __ptr64
    */

bool __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,bool param_2)

{
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar1;
  
  if (param_1 < 0x7fffffffffffffff) {
    if (*(ulonglong *)(this + 0x20) < param_1) {
      __Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
                (this,param_1,*(__uint64 *)(this + 0x18));
    }
    else if (param_1 == 0) {
      *(undefined8 *)(this + 0x18) = 0;
      pbVar1 = this + 8;
      if (7 < *(ulonglong *)(this + 0x20)) {
        pbVar1 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar1;
      }
      *(undefined2 *)pbVar1 = 0;
    }
    return param_1 != 0;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xlen__String_base_std__SAXXZ();
}


