/*
 * Function : catch$23
 * Address  : 0x140015874
 * Size     : 75 bytes (17 instructions)
 * Prototype: undefined * catch$23(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssAdminCLI::Main'::__l1::catch_23(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002bf8;
}


