/*
 * Function : ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ
 * Address  : 0x1400109bc
 * Size     : 637 bytes (141 instructions)
 * Prototype: void ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TranslateComError(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::TranslateComError(struct CVssDebugInfo,unsigned short
   const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateComError_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  ushort *puVar4;
  CVssDebugInfo *pCVar5;
  wchar_t *pwVar6;
  undefined8 local_res20;
  ulong in_stack_fffffffffffffd78;
  char *pcVar7;
  undefined4 uVar8;
  ushort *local_268;
  __uint64 local_260;
  longlong *local_258;
  wchar_t *local_250;
  ushort *local_248;
  undefined8 local_240;
  CVssDebugInfo local_238 [168];
  CVssDebugInfo local_190 [168];
  CVssDebugInfo local_e8 [184];
  
  local_240 = 0xfffffffffffffffe;
  local_res20 = param_4;
  local_248 = operator_new__(0x3ea,&std::nothrow);
  if (local_248 == (ushort *)0x0) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_238,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar3,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_260 = 0;
  local_268 = (ushort *)0x0;
  pcVar7 = (char *)&local_res20;
  StringCchVPrintfExW(local_248,500,&local_268,&local_260,in_stack_fffffffffffffd78,param_3,pcVar7);
  uVar8 = (undefined4)((ulonglong)pcVar7 >> 0x20);
  if (local_260 == 1) {
    local_268[-2] = 0x2e;
    local_268[-1] = 0x2e;
    local_268[-3] = 0x2e;
  }
  iVar1 = *(int *)(this + 8);
  if (*(int *)(this + 8) == 0) {
    iVar1 = -0x7fff0001;
  }
  local_258 = (longlong *)0x0;
  local_250 = (wchar_t *)0x0;
  iVar2 = Ordinal_200(0,&local_258);
  if ((-1 < iVar2) && (local_258 != (longlong *)0x0)) {
    (**(code **)(*local_258 + 0x28))(local_258,&local_250);
  }
  pwVar6 = L"";
  if (local_250 != (wchar_t *)0x0) {
    pwVar6 = local_250;
  }
  if ((((iVar1 != -0x7ff8fff2) && (iVar1 != -0x7ff8fff8)) && (iVar1 != -0x7ff8ff8f)) &&
     (((iVar1 != -0x7ff8fc05 && (iVar1 != -0x7ff8fa56)) && (iVar1 != -0x7ff8fb7a)))) {
    puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_248);
    if (iVar1 == -0x7ff8ff90) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_238,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar3,0x8004231f,L"ERROR_DISK_FULL detected in function %s - %s",puVar4,pwVar6
                );
    }
    pCVar5 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_190);
    pCVar5 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar5,(ushort *)local_e8);
    uVar3 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar5,(long)local_238);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar3,1);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_e8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_190);
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_190,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar3,0x80042302,L"Unexpected error in routine %s - %s. hr = 0x%08lx",puVar4,
               pwVar6,CONCAT44(uVar8,iVar1));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_190,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_248);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}


