/*
 * Function : ?erase@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z
 * Address  : 0x1400124f4
 * Size     : 188 bytes (55 instructions)
 * Prototype: basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?erase@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::_erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,__uint64 param_2)

{
  longlong lVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar3;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar4;
  ulonglong uVar5;
  
  if (*(ulonglong *)(this + 0x18) < param_1) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xran__String_base_std__SAXXZ();
  }
  uVar5 = *(ulonglong *)(this + 0x18) - param_1;
  if (uVar5 < param_2) {
    param_2 = uVar5;
  }
  if (param_2 != 0) {
    pbVar4 = this + 8;
    pbVar3 = pbVar4;
    pbVar2 = pbVar4;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
    }
    memmove_s(pbVar3 + param_1 * 2,(*(ulonglong *)(this + 0x20) - param_1) * 2,
              pbVar2 + (param_1 + param_2) * 2,(uVar5 - param_2) * 2);
    lVar1 = *(longlong *)(this + 0x18);
    *(__uint64 *)(this + 0x18) = lVar1 - param_2;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar4 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
    }
    *(undefined2 *)(pbVar4 + (lVar1 - param_2) * 2) = 0;
  }
  return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
          *)this;
}


