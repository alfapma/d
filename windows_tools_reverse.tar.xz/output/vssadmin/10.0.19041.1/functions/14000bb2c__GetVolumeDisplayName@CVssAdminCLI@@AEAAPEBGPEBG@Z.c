/*
 * Function : ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z
 * Address  : 0x14000bb2c
 * Size     : 1354 bytes (307 instructions)
 * Prototype: ushort * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short
   const * __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  short sVar1;
  short sVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  void *pvVar6;
  ushort *puVar7;
  undefined8 uVar8;
  short *psVar9;
  undefined8 *puVar10;
  ushort *puVar11;
  ushort *puVar12;
  undefined8 *puVar13;
  longlong lVar14;
  ushort *local_res8;
  longlong *local_res18;
  longlong *local_res20;
  _VSSDBG_SEV_ENUM _Var15;
  longlong **pplVar16;
  GUID local_1a8;
  wchar_t *local_198;
  wchar_t *local_190;
  wchar_t *local_188;
  undefined4 local_180;
  undefined4 local_17c;
  undefined4 local_178;
  undefined1 local_170 [120];
  undefined4 local_f8;
  CVssFunctionTracer local_e8 [8];
  int local_e0;
  undefined1 local_78 [8];
  undefined8 local_70;
  longlong local_68 [4];
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_190 = L"CVssAdminCLI::GetVolumeDisplayName";
  local_188 = L"ADMUTILC";
  local_180 = 0x38;
  local_17c = 7;
  local_178 = 0xff;
  puVar11 = (ushort *)0x0;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_e8,&local_198);
  puVar10 = *(undefined8 **)(this + 0x40);
  if (puVar10 == (undefined8 *)0x0) {
    local_res20 = (longlong *)0x0;
    local_1a8 = _GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
    local_198 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_190 = L"CVssAdminCLI::GetVolumeDisplayName";
    local_188 = L"ADMUTILC";
    local_180 = 0x40;
    local_17c = 7;
    local_178 = 0xff;
    local_f8 = 0x1000000;
    memset(local_170,0,0x78);
    pplVar16 = &local_res20;
    CVssFunctionTracer::
    _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
              (local_e8,&local_198,&local_1a8,L"VssSnapshotMgmt");
    if (local_e0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x47,7,(_VSSDBG_SEV_ENUM)pplVar16);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
    }
    local_res18 = (longlong *)0x0;
    local_1a8._8_4_ = 0xab5180af;
    local_1a8._0_8_ = 0x49257b9fb5946137;
    local_1a8._12_4_ = 0xd5200bd6;
    local_e0 = (**(code **)(*local_res20 + 0x20))(local_res20,&local_1a8,0xffffffff,&local_res18);
    if (local_e0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x52,7,(_VSSDBG_SEV_ENUM)pplVar16);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
    }
    if (local_e0 == 1) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_198,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x56,
                         7,(_VSSDBG_SEV_ENUM)pplVar16);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_e8,uVar8,1,
                 L"CVssAdminCLI::ListVolumes: No volumes found that satisfy the query");
    }
    local_res8 = operator_new(0x18,&std::nothrow);
    puVar7 = puVar11;
    if (local_res8 != (ushort *)0x0) {
      local_res8[0] = 0;
      local_res8[1] = 0;
      local_res8[2] = 0;
      local_res8[3] = 0;
      local_res8[4] = 0;
      local_res8[5] = 0;
      local_res8[6] = 0;
      local_res8[7] = 0;
      local_res8[8] = 0;
      local_res8[9] = 0;
      puVar7 = local_res8;
    }
    *(ushort **)(this + 0x40) = puVar7;
    if (puVar7 == (ushort *)0x0) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_198,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x60,
                         1,(_VSSDBG_SEV_ENUM)pplVar16);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_e8,uVar8,0x8007000e,L"Memory allocation error");
    }
    local_e0 = (**(code **)(*local_res18 + 0x18))(local_res18,1,local_78,&local_res8);
    _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
    uVar8 = local_70;
    lVar14 = local_68[0];
    while( true ) {
      if (local_e0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_198,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                   (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x68,7,
                   _Var15);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
      }
      if (local_e0 == 1) break;
      lVar5 = -1;
      do {
        lVar5 = lVar5 + 1;
      } while (*(short *)(lVar14 + lVar5 * 2) != 0);
      if ((lVar5 == 3) && (*(short *)(lVar14 + 4) == 0x5c)) {
        *(undefined2 *)(lVar14 + 4) = 0;
      }
      plVar3 = *(longlong **)(this + 0x40);
      local_70 = uVar8;
      local_68[0] = lVar14;
      pvVar6 = realloc((void *)*plVar3,(longlong)((int)plVar3[2] + 1) << 3);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      if (pvVar6 == (void *)0x0) {
LAB_14000bec1:
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_70);
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)local_68);
        uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_198,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                           (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",
                           0x7a,1,_Var15);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_e8,uVar8,0x8007000e,L"Memory allocation error");
      }
      *plVar3 = (longlong)pvVar6;
      pvVar6 = realloc((void *)plVar3[1],(longlong)((int)plVar3[2] + 1) << 3);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      if (pvVar6 == (void *)0x0) goto LAB_14000bec1;
      plVar3[1] = (longlong)pvVar6;
      iVar4 = (int)plVar3[2];
      *(int *)(plVar3 + 2) = iVar4 + 1;
      puVar10 = (undefined8 *)(*plVar3 + (longlong)iVar4 * 8);
      if (puVar10 != (undefined8 *)0x0) {
        *puVar10 = uVar8;
        pvVar6 = (void *)plVar3[1];
      }
      plVar3 = (longlong *)((longlong)pvVar6 + (longlong)iVar4 * 8);
      if (plVar3 != (longlong *)0x0) {
        *plVar3 = lVar14;
      }
      local_e0 = (**(code **)(*local_res18 + 0x18))(local_res18,1,local_78,&local_res8);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      uVar8 = local_70;
      lVar14 = local_68[0];
    }
    if (local_res18 != (longlong *)0x0) {
      (**(code **)(*local_res18 + 0x10))();
    }
    if (local_res20 != (longlong *)0x0) {
      (**(code **)(*local_res20 + 0x10))();
    }
    puVar10 = *(undefined8 **)(this + 0x40);
  }
  if (0 < *(int *)(puVar10 + 2)) {
    puVar13 = (undefined8 *)*puVar10;
    puVar7 = puVar11;
    puVar12 = puVar11;
    do {
      iVar4 = (int)puVar7;
      psVar9 = (short *)*puVar13;
      lVar14 = (longlong)param_1 - (longlong)psVar9;
      do {
        sVar1 = *psVar9;
        sVar2 = *(short *)((longlong)psVar9 + lVar14);
        if (sVar1 != sVar2) break;
        psVar9 = psVar9 + 1;
      } while (sVar2 != 0);
      if (sVar1 == sVar2) goto LAB_14000be89;
      puVar7 = (ushort *)(ulonglong)(iVar4 + 1);
      puVar12 = (ushort *)((longlong)puVar12 + 1);
      puVar13 = puVar13 + 1;
    } while ((longlong)puVar12 < (longlong)*(int *)(puVar10 + 2));
  }
  iVar4 = -1;
LAB_14000be89:
  if (iVar4 != -1) {
    puVar11 = *(ushort **)(puVar10[1] + (longlong)iVar4 * 8);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_e8);
  return puVar11;
}


