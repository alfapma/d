/*
 * Function : ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z
 * Address  : 0x14000da90
 * Size     : 822 bytes (181 instructions)
 * Prototype: void ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::OutputOnConsole(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::OutputOnConsole(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  DWORD DVar1;
  BOOL BVar2;
  UINT UVar3;
  uint cbMultiByte;
  int iVar4;
  LPSTR lpMultiByteStr;
  longlong lVar5;
  DWORD local_res8 [4];
  DWORD local_res18 [2];
  DWORD local_res20 [2];
  wchar_t *local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined1 local_128 [120];
  undefined4 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  local_150 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_148 = L"CVssAdminCLI::OutputOnConsole";
  local_140 = L"ADMUTILC";
  local_138 = 0x326;
  local_134 = 7;
  local_130 = 0xff;
  local_b0 = 0x1000000;
  memset(local_128,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_150);
  lVar5 = -1;
  if (*(HANDLE *)(this + 8) == (HANDLE)0xffffffffffffffff) {
    local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
  }
  if (DAT_140024134 != 0) {
    DVar1 = GetFileType(*(HANDLE *)(this + 8));
    if (((DVar1 & 2) == 0) ||
       (BVar2 = GetConsoleMode(*(HANDLE *)(this + 8),local_res20), DAT_140024714 = 1, BVar2 == 0)) {
      DAT_140024714 = 0;
    }
    DAT_140024134 = 0;
  }
  if (DAT_140024714 == 0) {
    UVar3 = GetConsoleOutputCP();
    cbMultiByte = WideCharToMultiByte(UVar3,0,(LPCWSTR)param_1,-1,(LPSTR)0x0,0,(LPCSTR)0x0,
                                      (LPBOOL)0x0);
    if (cbMultiByte == 0) {
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    lpMultiByteStr = malloc((ulonglong)cbMultiByte);
    if (lpMultiByteStr == (LPSTR)0x0) {
      local_res8[0] = 0x8007000e;
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    UVar3 = GetConsoleOutputCP();
    iVar4 = WideCharToMultiByte(UVar3,0,(LPCWSTR)param_1,-1,lpMultiByteStr,cbMultiByte,(LPCSTR)0x0,
                                (LPBOOL)0x0);
    if (iVar4 == 0) {
      free(lpMultiByteStr);
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    BVar2 = WriteFile(*(HANDLE *)(this + 8),lpMultiByteStr,iVar4 - 1,local_res18,(LPOVERLAPPED)0x0);
    if (BVar2 == 0) {
      free(lpMultiByteStr);
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    free(lpMultiByteStr);
  }
  else {
    do {
      lVar5 = lVar5 + 1;
    } while (param_1[lVar5] != 0);
    BVar2 = WriteConsoleW(*(HANDLE *)(this + 8),param_1,(DWORD)lVar5,local_res18,(LPVOID)0x0);
    if (BVar2 == 0) {
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}


