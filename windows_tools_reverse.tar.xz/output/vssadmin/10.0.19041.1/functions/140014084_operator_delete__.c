/*
 * Function : operator_delete[]
 * Address  : 0x140014084
 * Size     : 5 bytes (1 instructions)
 * Prototype: void operator_delete[](void * param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl operator delete[](void * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl operator delete[](void * __ptr64) */

void __cdecl operator_delete__(void *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140014463. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  free(param_1);
  return;
}


