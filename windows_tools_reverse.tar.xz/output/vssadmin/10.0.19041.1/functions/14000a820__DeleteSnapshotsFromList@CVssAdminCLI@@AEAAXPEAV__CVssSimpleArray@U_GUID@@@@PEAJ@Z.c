/*
 * Function : ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z
 * Address  : 0x14000a820
 * Size     : 814 bytes (181 instructions)
 * Prototype: void ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, long * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DeleteSnapshotsFromList(class CVssSimpleArray<struct _GUID> * __ptr64,long * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::DeleteSnapshotsFromList(class CVssSimpleArray<struct _GUID> *
   __ptr64,long * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_DeleteSnapshotsFromList_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEAJ_Z
          (CVssAdminCLI *this,CVssSimpleArray<_GUID> *param_1,long *param_2)

{
  code *pcVar1;
  int iVar2;
  longlong *plVar3;
  GUID *pGVar4;
  uint uVar5;
  ulonglong uVar7;
  undefined1 auStackY_1e8 [32];
  longlong **pplVar8;
  longlong *local_1a0;
  GUID local_198;
  GUID local_188;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  undefined8 local_d0;
  CVssFunctionTracer local_c8 [8];
  int local_c0;
  undefined8 local_58;
  undefined8 uStack_50;
  ulonglong local_48;
  ulonglong uVar6;
  
  local_d0 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_1e8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::DeleteSnapshotsFromList";
  local_168 = L"ADMPROCC";
  local_160 = 0x747;
  local_15c = 7;
  local_158 = 0xff;
  uVar6 = 0;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8);
  local_58 = 0;
  uStack_50 = 0;
  local_1a0 = (longlong *)0x0;
  local_198 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_188 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::DeleteSnapshotsFromList";
  local_168 = L"ADMPROCC";
  local_160 = 0x752;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  pplVar8 = &local_1a0;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_c8,&local_178,&local_188,L"Coordinator");
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x759,7,(_VSSDBG_SEV_ENUM)pplVar8)
    ;
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  pGVar4 = (GUID *)0xffffffff;
  plVar3 = local_1a0;
  local_c0 = (**(code **)(*local_1a0 + 0x18))();
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x75e,7,(_VSSDBG_SEV_ENUM)pplVar8)
    ;
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  iVar2 = *(int *)(param_1 + 8);
  uVar7 = uVar6;
  if (0 < iVar2) {
    do {
      if (((longlong)uVar7 < 0) || (iVar2 <= (int)uVar6)) {
        ATL::__AtlRaiseException_ATL__YAXKK_Z((ulong)plVar3,(ulong)pGVar4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
      }
      local_188 = *(GUID *)(uVar7 + *(longlong *)param_1);
      pGVar4 = &local_188;
      plVar3 = local_1a0;
      local_c0 = (**(code **)(*local_1a0 + 0x58))(local_1a0,pGVar4,3);
      if (local_c0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_178,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x76a,7,
                   (_VSSDBG_SEV_ENUM)pplVar8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
      }
      uVar5 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar5;
      iVar2 = *(int *)(param_1 + 8);
      uVar7 = uVar7 + 0x10;
    } while ((int)uVar5 < iVar2);
  }
  *param_2 = 0;
  if (local_1a0 != (longlong *)0x0) {
    (**(code **)(*local_1a0 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
  return;
}


