/*
 * Function : ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z
 * Address  : 0x140003f10
 * Size     : 189 bytes (33 instructions)
 * Prototype: void ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CInternalVerifier::ExposeSnapshot(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CInternalVerifier::ExposeSnapshot(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_ExposeSnapshot_CInternalVerifier__UEAAXU_GUID__PEBG1_NAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,bool param_4,
          CVssFunctionTracer *param_5)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [176];
  
  if (param_3 != (ushort *)0x0) {
    if (param_4) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ExposeSnapshot",0xc3,7
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_5,uVar1,0x1008,
                 L"CVssAdminCLI::ExposeSnapshot: Specified a ShareUsing option with an expose locally command"
                );
    }
    if (*param_3 != 0x5c) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ExposeSnapshot",200,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_5,uVar1,0x1004,
                 L"CVssAdminCLI::ExposeSnapshot: Specified SharePath doesn\'t start with \'\\\'");
    }
  }
  return;
}


