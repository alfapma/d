/*
 * Function : ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z
 * Address  : 0x1400129a4
 * Size     : 251 bytes (56 instructions)
 * Prototype: void ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssIOCTLChannel::ApplyAlignment(class CVssFunctionTracer & __ptr64,unsigned long * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssIOCTLChannel::ApplyAlignment(class CVssFunctionTracer &
   __ptr64,unsigned long * __ptr64) __ptr64 */

void __thiscall
CVssIOCTLChannel::_ApplyAlignment_CVssIOCTLChannel__AEAAXAEAVCVssFunctionTracer__PEAK_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ulong *param_2)

{
  ushort uVar1;
  uint uVar2;
  undefined8 uVar3;
  uint uVar4;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  uVar2 = *param_2;
  uVar1 = *(ushort *)(this + 0x58);
  if ((short)((ulonglong)uVar2 % (ulonglong)uVar1) != 0) {
    uVar4 = (uint)((ulonglong)uVar2 % (ulonglong)uVar1);
    if (uVar1 < uVar4) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::ApplyAlignment",0x83,10
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar3,0x8007000e,
                 L"Arithmetic overflow.  wAlignmentOffset = %hu was larger than m_wAlignmentBytes = %hu"
                 ,uVar4,*(undefined2 *)(this + 0x58));
    }
    uVar4 = uVar2 + (uVar1 - uVar4);
    if (uVar4 < uVar2) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::ApplyAlignment",0x8a,10
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar3,0x8007000e,L"Arithmetic overflow. m_wAlignmentBytes = %hu too large",
                 *(undefined2 *)(this + 0x58));
    }
    *param_2 = uVar4;
  }
  return;
}


