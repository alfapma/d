/*
 * Function : operator_new
 * Address  : 0x140014038
 * Size     : 69 bytes (20 instructions)
 * Prototype: void * operator_new(__uint64 param_1)
 * CC       : __cdecl
 * Comment  : void * __ptr64 __cdecl operator new(unsigned __int64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void * __ptr64 __cdecl operator new(unsigned __int64) */

void * __cdecl operator_new(__uint64 param_1)

{
  int iVar1;
  void *pvVar2;
  bad_alloc local_28 [32];
  
  do {
    pvVar2 = malloc(param_1);
    if (pvVar2 != (void *)0x0) {
      return pvVar2;
    }
    iVar1 = _callnewh(param_1);
  } while (iVar1 != 0);
  std::bad_alloc::__0bad_alloc_std__QEAA_XZ(local_28);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
}


