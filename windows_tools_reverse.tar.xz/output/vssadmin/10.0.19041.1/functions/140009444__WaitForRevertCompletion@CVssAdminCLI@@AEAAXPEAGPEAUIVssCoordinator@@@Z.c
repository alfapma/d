/*
 * Function : ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z
 * Address  : 0x140009444
 * Size     : 758 bytes (177 instructions)
 * Prototype: void ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::WaitForRevertCompletion(unsigned short * __ptr64,struct IVssCoordinator * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::WaitForRevertCompletion(unsigned short * __ptr64,struct
   IVssCoordinator * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_WaitForRevertCompletion_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
          (CVssAdminCLI *this,ushort *param_1,IVssCoordinator *param_2)

{
  code *pcVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  wchar_t *pwVar7;
  undefined1 auStackY_228 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe08;
  int local_1e8 [2];
  longlong *local_1e0;
  int local_1d8 [4];
  undefined8 local_1c8;
  wchar_t *local_1c0;
  wchar_t *local_1b8;
  wchar_t *local_1b0;
  undefined4 local_1a8;
  undefined4 local_1a4;
  undefined4 local_1a0;
  undefined1 local_198 [120];
  undefined4 local_120;
  CVssFunctionTracer local_118 [8];
  int local_110;
  wchar_t local_a8 [56];
  ulonglong local_38;
  
  local_1c8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_228;
  local_1c0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1b8 = L"CVssAdminCLI::WaitForRevertCompletion";
  local_1b0 = L"ADMPROCC";
  local_1a8 = 0x5fa;
  local_1a4 = 7;
  local_1a0 = 0xff;
  iVar6 = 0;
  local_120 = 0x1000000;
  memset(local_198,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_118,&local_1c0);
  local_1e0 = (longlong *)0x0;
  local_110 = (**(code **)(*(longlong *)param_2 + 0x70))(param_2,param_1,&local_1e0);
  if (local_110 == -0x7ffbdcf8) {
    local_110 = -0x7ffbdcf8;
  }
  else {
    if (local_110 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1c0,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x602,7,
                 in_stack_fffffffffffffe08);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
    }
    do {
      Sleep(300);
      local_1e8[0] = 0;
      local_1d8[0] = 0;
      local_110 = (**(code **)(*local_1e0 + 0x28))(local_1e0,local_1d8,local_1e8);
      if (local_110 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1c0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x610,7,
                   in_stack_fffffffffffffe08);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
      }
      iVar4 = 100;
      if (local_1e8[0] < 0x65) {
        iVar4 = local_1e8[0];
      }
      if (local_1d8[0] == 0x4230a) {
        local_1e8[0] = 100;
      }
      else {
        local_1e8[0] = iVar4;
        if (local_1d8[0] != 0x42309) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1c0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x616,
                     7,in_stack_fffffffffffffe08);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
        }
      }
      uVar5 = local_1e8[0] - iVar6;
      if (1 < (int)uVar5) {
        lVar3 = (longlong)((int)uVar5 / 2);
        if ((int)uVar5 / 2 != 0) {
          pwVar7 = local_a8;
          for (lVar2 = lVar3; lVar2 != 0; lVar2 = lVar2 + -1) {
            *pwVar7 = L'.';
            pwVar7 = pwVar7 + 1;
          }
        }
        if (0x65 < (ulonglong)(lVar3 * 2)) {
          __report_rangecheckfailure();
          pcVar1 = (code *)swi(3);
          (*pcVar1)();
          return;
        }
        local_a8[lVar3] = L'\0';
        wprintf(local_a8);
        uVar5 = uVar5 & 0x80000001;
        if ((int)uVar5 < 0) {
          uVar5 = (uVar5 - 1 | 0xfffffffe) + 1;
        }
        iVar6 = local_1e8[0] - uVar5;
      }
    } while (iVar6 < 100);
    wprintf(L"\n");
  }
  if (local_1e0 != (longlong *)0x0) {
    (**(code **)(*local_1e0 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_118);
  return;
}


