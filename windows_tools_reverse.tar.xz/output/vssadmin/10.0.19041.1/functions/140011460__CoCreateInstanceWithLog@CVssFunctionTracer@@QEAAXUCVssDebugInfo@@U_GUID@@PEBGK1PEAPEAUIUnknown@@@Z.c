/*
 * Function : ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z
 * Address  : 0x140011460
 * Size     : 649 bytes (156 instructions)
 * Prototype: void ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, _GUID param_2, ushort * param_3, ulong param_4, _GUID param_5, IUnknown * * param_6)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::CoCreateInstanceWithLog(struct CVssDebugInfo,struct _GUID,unsigned short const * __ptr64,unsigned long,struct _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::CoCreateInstanceWithLog(struct CVssDebugInfo,struct
   _GUID,unsigned short const * __ptr64,unsigned long,struct _GUID,struct IUnknown * __ptr64 *
   __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::
_CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,IID *param_3,undefined8 param_4,
          undefined8 param_5,IID *param_6,LPVOID *param_7)

{
  int iVar1;
  CVssDebugInfo *pCVar2;
  HRESULT HVar3;
  undefined8 uVar4;
  _GUID *this_00;
  undefined8 uVar5;
  DWORD dwMilliseconds;
  _GUID local_248 [10];
  _GUID local_1a0 [10];
  undefined1 local_f8 [184];
  
  dwMilliseconds = 1000;
  do {
    HVar3 = CoCreateInstance(param_3,(LPUNKNOWN)0x0,0x17,param_6,param_7);
    *(HRESULT *)(this + 8) = HVar3;
    if (((HVar3 != -0x7ff7fffb) && (HVar3 != -0x7ff8fff2)) && (HVar3 != -0x7ff8fbe3)) break;
    Sleep(dwMilliseconds);
    dwMilliseconds = dwMilliseconds + 2000;
  } while ((int)dwMilliseconds < 21000);
  iVar1 = *(int *)(this + 8);
  if ((iVar1 == -0x7fffbffe) || (iVar1 == -0x7ffbfeac)) {
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
    uVar5 = 0x16;
LAB_1400116af:
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,uVar5,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_1a0);
    this_00 = local_248;
  }
  else {
    if ((iVar1 == -0x7ff8fff2) || (iVar1 == -0x7ff8fbe3)) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0xd;
      goto LAB_1400116af;
    }
    if (iVar1 == -0x7ff8fbc4) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0x12;
      goto LAB_1400116af;
    }
    if (iVar1 == -0x7ff7fffb) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0xb;
      goto LAB_1400116af;
    }
    if (iVar1 == 0) goto LAB_1400116cd;
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_1a0);
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_248);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0xd,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_248);
    this_00 = local_1a0;
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)this_00);
LAB_1400116cd:
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}


