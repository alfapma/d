/*
 * Function : ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z
 * Address  : 0x140003880
 * Size     : 38 bytes (12 instructions)
 * Prototype: void * ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this, uint param_1)
 * CC       : __thiscall
 * Comment  : protected: virtual void * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 & __ptr64)>::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: virtual void * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short *
   __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned
   short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned
   short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short *
   __ptr64 & __ptr64)>::`vector deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
::
___E__CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__MEAAPEAXI_Z
          (CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
           *this,uint param_1)

{
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


