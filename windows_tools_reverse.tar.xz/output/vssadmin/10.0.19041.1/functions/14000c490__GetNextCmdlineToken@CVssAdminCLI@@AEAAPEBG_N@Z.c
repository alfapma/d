/*
 * Function : ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z
 * Address  : 0x14000c490
 * Size     : 209 bytes (48 instructions)
 * Prototype: ushort * ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z(CVssAdminCLI * this, bool param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetNextCmdlineToken(bool) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetNextCmdlineToken(bool) __ptr64
    */

ushort * __thiscall
CVssAdminCLI::_GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(CVssAdminCLI *this,bool param_1)

{
  longlong lVar1;
  ushort *puVar2;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_110 = 0xdf;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_10c = 7;
  local_120 = L"CVssAdminCLI::GetNextCmdlineToken";
  local_108 = 0xff;
  puVar2 = (ushort *)0x0;
  local_118 = L"ADMUTILC";
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  if (param_1) {
    DAT_140024710 = 0;
  }
  if (DAT_140024710 < *(int *)(this + 0x4c)) {
    lVar1 = (longlong)DAT_140024710;
    DAT_140024710 = DAT_140024710 + 1;
    puVar2 = *(ushort **)(*(longlong *)(this + 0x50) + lVar1 * 8);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return puVar2;
}


