/*
 * Function : ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z
 * Address  : 0x140003b60
 * Size     : 105 bytes (17 instructions)
 * Prototype: void ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CInternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CInternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CInternalVerifier::_ResizeDiffArea_CInternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if (0xfffff < param_4) {
    return;
  }
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ResizeDiffArea",0x6d,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar1,0x1001,
             L"CVssAdminCLI::ResizeDiffarea: maxsize of less than 1 MB specified, invalid");
}


