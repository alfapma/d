/*
 * Function : ?SetHr@CVssFunctionTracer@@QEAAXJ@Z
 * Address  : 0x1400038e0
 * Size     : 4 bytes (2 instructions)
 * Prototype: void ?SetHr@CVssFunctionTracer@@QEAAXJ@Z(CVssFunctionTracer * this, long param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64 */

void __thiscall
CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(CVssFunctionTracer *this,long param_1)

{
  *(long *)(this + 8) = param_1;
  return;
}


