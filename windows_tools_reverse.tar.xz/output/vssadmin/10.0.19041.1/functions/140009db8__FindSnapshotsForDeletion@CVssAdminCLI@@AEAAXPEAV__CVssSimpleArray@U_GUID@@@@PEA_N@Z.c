/*
 * Function : ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z
 * Address  : 0x140009db8
 * Size     : 2644 bytes (560 instructions)
 * Prototype: void ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, bool * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID> * __ptr64,bool * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID>
   * __ptr64,bool * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_FindSnapshotsForDeletion_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEA_N_Z
          (CVssAdminCLI *this,CVssSimpleArray<_GUID> *param_1,bool *param_2)

{
  undefined1 auVar1 [16];
  bool bVar2;
  int iVar3;
  BOOL BVar4;
  long lVar5;
  LPCWSTR lpszVolumeMountPoint;
  ushort *puVar6;
  void *pvVar7;
  undefined8 *puVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  CVssAdminCLI *this_00;
  longlong lVar11;
  longlong lVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined1 auStackY_3f8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc38;
  _VSSDBG_SEV_ENUM _Var18;
  longlong **pplVar19;
  int local_3a8 [4];
  undefined1 local_398 [16];
  GUID local_388;
  longlong *local_378;
  longlong *local_370;
  undefined1 local_368 [8];
  longlong local_360;
  longlong local_358;
  wchar_t *local_350;
  wchar_t *local_348;
  wchar_t *local_340;
  undefined4 local_338;
  undefined4 local_334;
  undefined4 local_330;
  undefined1 local_328 [120];
  undefined4 local_2b0;
  bool *local_2a8;
  CVssFunctionTracer local_298 [8];
  int local_290;
  undefined8 local_228;
  CVssDebugInfo local_220 [168];
  _GUID local_178;
  undefined1 local_168 [8];
  undefined4 local_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  wchar_t *local_130;
  long local_f8;
  longlong local_f0;
  WCHAR local_d8 [49];
  undefined2 local_76;
  long local_70;
  ulonglong local_58;
  
  local_228 = 0xfffffffffffffffe;
  local_58 = __security_cookie ^ (ulonglong)auStackY_3f8;
  local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_340 = L"ADMPROCC";
  local_338 = 0x6b0;
  local_334 = 7;
  local_330 = 0xff;
  local_2b0 = 0x1000000;
  local_2a8 = param_2;
  memset(local_328,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_298,&local_350);
  lpszVolumeMountPoint =
       (LPCWSTR)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  local_3a8[0] = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,6);
  lVar11 = (longlong)local_3a8[0];
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,0);
  lVar12 = (longlong)iVar3;
  uVar14 = 0;
  uVar15 = 0;
  uVar16 = 0;
  uVar17 = 0;
  local_178.Data1 = 0;
  local_178.Data2 = 0;
  local_178.Data3 = 0;
  local_178.Data4[0] = '\0';
  local_178.Data4[1] = '\0';
  local_178.Data4[2] = '\0';
  local_178.Data4[3] = '\0';
  local_178.Data4[4] = '\0';
  local_178.Data4[5] = '\0';
  local_178.Data4[6] = '\0';
  local_178.Data4[7] = '\0';
  local_360 = 0x7fffffffffffffff;
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar6 != (ushort *)0x0) {
    this_00 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar2 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar6,&local_178);
    if (!bVar2) {
      uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_350,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                          0x6be,7,in_stack_fffffffffffffc38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_298,uVar10,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  local_398._4_2_ = local_178.Data2;
  local_398._6_2_ = local_178.Data3;
  local_398._0_4_ = local_178.Data1;
  local_398[0xc] = local_178.Data4[4];
  local_398[0xd] = local_178.Data4[5];
  local_398[0xe] = local_178.Data4[6];
  local_398[0xf] = local_178.Data4[7];
  local_398[8] = local_178.Data4[0];
  local_398[9] = local_178.Data4[1];
  local_398[10] = local_178.Data4[2];
  local_398[0xb] = local_178.Data4[3];
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  (**(code **)(**(longlong **)this + 0x58))
            (*(longlong **)this,0xffffffff,lpszVolumeMountPoint,iVar3 == 1);
  local_378 = (longlong *)0x0;
  local_398 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_388 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_340 = L"ADMPROCC";
  local_338 = 0x6c9;
  local_334 = 7;
  local_330 = 0xff;
  local_2b0 = 0x1000000;
  memset(local_328,0,0x78);
  pplVar19 = &local_378;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_298,&local_350,&local_388,L"Coordinator");
  if (local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_350,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d0,7,
               (_VSSDBG_SEV_ENUM)pplVar19);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  local_290 = (**(code **)(*local_378 + 0x18))();
  _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
  if (local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_350,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d5,7,_Var18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  if ((CONCAT44(local_178._4_4_,local_178.Data1) == 0) &&
     (CONCAT44(local_178.Data4._4_4_,local_178.Data4._0_4_) == 0)) {
    memset(local_d8,0,100);
    if (lpszVolumeMountPoint != (LPCWSTR)0x0) {
      if (*lpszVolumeMountPoint == L'\\') {
        lVar5 = StringCchCopyW((ushort *)local_d8,0x32,(ushort *)lpszVolumeMountPoint);
        local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
        local_340 = L"ADMPROCC";
        local_338 = 0x701;
        local_334 = 7;
        local_330 = 0xff;
        local_2b0 = 0x1000000;
        local_290 = lVar5;
        memset(local_328,0,0x78);
        local_388._0_8_ = &local_350;
        if (lVar5 < 0) {
          uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                             (local_220,(CVssDebugInfo *)&local_350);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_298,uVar10,lVar5,L"StringCchCopy");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_350);
        local_76 = 0;
      }
      else {
        BVar4 = GetVolumeNameForVolumeMountPointW(lpszVolumeMountPoint,local_d8,0x32);
        if (BVar4 == 0) {
          uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_350,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",
                              (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6fa,1,
                              (_VSSDBG_SEV_ENUM)pplVar19);
          GetLastError();
          _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_298,uVar10,0x80042308,
                     L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx");
        }
      }
    }
    local_370 = (longlong *)0x0;
    local_398 = ZEXT816(0);
    local_290 = (**(code **)(*local_378 + 0x50))(local_378,local_398,1,3);
    if (local_290 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                 (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x70a,7,
                 (_VSSDBG_SEV_ENUM)pplVar19);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
    }
    local_290 = (**(code **)(*local_370 + 0x18))(local_370,1,local_168,local_368);
    _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
    if (-1 < local_290) {
      local_388._0_8_ = lVar12;
      local_358 = lVar11;
      do {
        if (local_290 == 1) {
          if ((local_3a8[0] != 0) &&
             ((CONCAT44(uVar15,uVar14) != 0 ||
              (auVar1._4_4_ = uVar15, auVar1._0_4_ = uVar14, auVar1._8_4_ = uVar16,
              auVar1._12_4_ = uVar17, auVar1._8_8_ != 0)))) {
            iVar3 = *(int *)(param_1 + 8);
            if (iVar3 + 1 < 1) goto LAB_14000a7b7;
            if (iVar3 == *(int *)(param_1 + 0xc)) {
              if ((0x3fffffff < iVar3) || (0x7ffffffffffffff < (ulonglong)(longlong)iVar3)) {
LAB_14000a7b7:
                local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
                _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
              }
              iVar13 = iVar3 * 2;
              if (*(int *)(param_1 + 0xc) == 0) {
                iVar13 = 1;
              }
              pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
              if (pvVar7 == (void *)0x0) goto LAB_14000a7b7;
              *(int *)(param_1 + 0xc) = iVar13;
              *(void **)param_1 = pvVar7;
            }
            *(int *)(param_1 + 8) = iVar3 + 1;
            puVar9 = (undefined4 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
            if (puVar9 != (undefined4 *)0x0) {
              *puVar9 = uVar14;
              puVar9[1] = uVar15;
              puVar9[2] = uVar16;
              puVar9[3] = uVar17;
            }
          }
          if (local_370 != (longlong *)0x0) {
            (**(code **)(*local_370 + 0x10))();
          }
          goto LAB_14000a4c4;
        }
        local_398._8_8_ = &local_160;
        local_398._0_8_ =
             &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
              ::_vftable_;
        iVar3 = _wcsicmp(local_130,local_d8);
        if ((iVar3 == 0) || ((lpszVolumeMountPoint == (LPCWSTR)0x0 && (lVar12 != 0)))) {
          iVar3 = IsCorrectContext(local_f8);
          if (iVar3 == 0) {
            *local_2a8 = true;
            goto LAB_14000a15a;
          }
          if (lVar11 != 0) {
            if (local_f0 < local_360) {
              local_360 = local_f0;
              uVar14 = local_160;
              uVar15 = uStack_15c;
              uVar16 = uStack_158;
              uVar17 = uStack_154;
            }
            goto LAB_14000a15a;
          }
          iVar3 = *(int *)(param_1 + 8);
          if (iVar3 + 1 < 1) goto LAB_14000a79d;
          if (iVar3 == *(int *)(param_1 + 0xc)) {
            if ((0x3fffffff < iVar3) || (0x7ffffffffffffff < (ulonglong)(longlong)iVar3)) {
LAB_14000a79d:
              local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
              _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
            }
            iVar13 = iVar3 * 2;
            if (*(int *)(param_1 + 0xc) == 0) {
              iVar13 = 1;
            }
            pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
            if (pvVar7 == (void *)0x0) goto LAB_14000a79d;
            *(int *)(param_1 + 0xc) = iVar13;
            *(void **)param_1 = pvVar7;
            lVar11 = local_358;
          }
          *(int *)(param_1 + 8) = iVar3 + 1;
          puVar8 = (undefined8 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
          if (puVar8 != (undefined8 *)0x0) {
            *puVar8 = CONCAT44(uStack_15c,local_160);
            puVar8[1] = CONCAT44(uStack_154,uStack_158);
          }
          VssFreeSnapshotPropertiesInternal(&local_160);
          lVar12 = local_388._0_8_;
        }
        else {
LAB_14000a15a:
          VssFreeSnapshotPropertiesInternal(&local_160);
        }
        local_398 = ZEXT816(0x140017068);
        local_290 = (**(code **)(*local_370 + 0x18))(local_370,1,local_168,local_368);
        _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
      } while (-1 < local_290);
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
               (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x715,7,
               _Var18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  local_398._4_2_ = local_178.Data2;
  local_398._6_2_ = local_178.Data3;
  local_398._0_4_ = local_178.Data1;
  local_398[0xc] = local_178.Data4[4];
  local_398[0xd] = local_178.Data4[5];
  local_398[0xe] = local_178.Data4[6];
  local_398[0xf] = local_178.Data4[7];
  local_398[8] = local_178.Data4[0];
  local_398[9] = local_178.Data4[1];
  local_398[10] = local_178.Data4[2];
  local_398[0xb] = local_178.Data4[3];
  local_290 = (**(code **)(*local_378 + 0x38))(local_378,local_398,local_d8);
  if (local_290 == -0x7ffbdcf8) {
    uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                       (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                        (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                        0x6e0,7,_Var18);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_298,uVar10,1,L"No snapshots were found with that ID");
  }
  iVar3 = IsCorrectContext(local_70);
  if (iVar3 == 0) {
    uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                       (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                        (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                        0x6e4,7,_Var18);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_298,uVar10,0x100b,
               L"Snapshot was found, but you cannot delete it in this context.");
  }
  VssFreeSnapshotPropertiesInternal(local_d8);
  iVar3 = *(int *)(param_1 + 8);
  if (0 < iVar3 + 1) {
    if (iVar3 != *(int *)(param_1 + 0xc)) {
LAB_14000a4a9:
      *(int *)(param_1 + 8) = iVar3 + 1;
      puVar8 = (undefined8 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
      if (puVar8 != (undefined8 *)0x0) {
        *puVar8 = CONCAT44(local_178._4_4_,local_178.Data1);
        puVar8[1] = CONCAT44(local_178.Data4._4_4_,local_178.Data4._0_4_);
      }
LAB_14000a4c4:
      if (local_378 != (longlong *)0x0) {
        (**(code **)(*local_378 + 0x10))();
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_298);
      return;
    }
    if ((iVar3 < 0x40000000) && ((ulonglong)(longlong)iVar3 < 0x800000000000000)) {
      iVar13 = iVar3 * 2;
      if (*(int *)(param_1 + 0xc) == 0) {
        iVar13 = 1;
      }
      pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
      if (pvVar7 != (void *)0x0) {
        *(int *)(param_1 + 0xc) = iVar13;
        *(void **)param_1 = pvVar7;
        goto LAB_14000a4a9;
      }
    }
  }
  local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
}


