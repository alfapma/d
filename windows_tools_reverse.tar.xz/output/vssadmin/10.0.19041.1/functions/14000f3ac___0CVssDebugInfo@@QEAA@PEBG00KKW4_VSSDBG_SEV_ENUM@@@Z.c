/*
 * Function : ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z
 * Address  : 0x14000f3ac
 * Size     : 75 bytes (20 instructions)
 * Prototype: undefined ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5, _VSSDBG_SEV_ENUM param_6)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssDebugInfo::CVssDebugInfo(unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long,enum _VSSDBG_SEV_ENUM) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssDebugInfo::CVssDebugInfo(unsigned short const * __ptr64,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long,enum _VSSDBG_SEV_ENUM)
   __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,ushort *param_1,ushort *param_2,ushort *param_3,ulong param_4,
          ulong param_5,_VSSDBG_SEV_ENUM param_6)

{
  *(ushort **)this = param_1;
  *(ulong *)(this + 0x18) = param_4;
  *(ushort **)(this + 0x10) = param_2;
  *(ushort **)(this + 8) = param_3;
  *(ulong *)(this + 0x1c) = param_5;
  *(undefined4 *)(this + 0x20) = 0xff;
  *(undefined4 *)(this + 0xa0) = 0x1000000;
  memset(this + 0x28,0,0x78);
  return this;
}


