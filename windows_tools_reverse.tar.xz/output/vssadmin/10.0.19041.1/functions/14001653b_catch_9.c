/*
 * Function : catch$9
 * Address  : 0x14001653b
 * Size     : 90 bytes (19 instructions)
 * Prototype: undefined * catch$9(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_9
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(_com_error **)(param_2 + 0x178),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return (undefined *)0x140013f14;
}


