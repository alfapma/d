/*
 * Function : ??1CVssIOCTLChannel@@QEAA@XZ
 * Address  : 0x1400128e0
 * Size     : 186 bytes (46 instructions)
 * Prototype: void ??1CVssIOCTLChannel@@QEAA@XZ(CVssIOCTLChannel * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssIOCTLChannel::~CVssIOCTLChannel(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssIOCTLChannel::~CVssIOCTLChannel(void) __ptr64 */

void __thiscall CVssIOCTLChannel::__1CVssIOCTLChannel__QEAA_XZ(CVssIOCTLChannel *this)

{
  if (*(HANDLE *)this != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)this);
  }
  *(undefined8 *)this = 0;
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  if (*(void **)(this + 0x38) != (void *)0x0) {
    free(*(void **)(this + 0x38));
  }
  *(undefined8 *)(this + 0x38) = 0;
  *(undefined4 *)(this + 0x30) = 0;
  if (*(void **)(this + 0x50) != (void *)0x0) {
    free(*(void **)(this + 0x50));
  }
  *(undefined8 *)(this + 0x50) = 0;
  *(undefined4 *)(this + 0x44) = 0;
  if ((*(HANDLE *)(this + 0x20) != (HANDLE)0x0) && (this[0x28] != (CVssIOCTLChannel)0x0)) {
    CloseHandle(*(HANDLE *)(this + 0x20));
  }
  *(undefined ***)(this + 0x60) =
       &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (*(LPVOID *)(this + 0x68) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 0x68));
  }
  *(undefined8 *)(this + 0x68) = 0;
  *(undefined ***)(this + 0x60) =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}


