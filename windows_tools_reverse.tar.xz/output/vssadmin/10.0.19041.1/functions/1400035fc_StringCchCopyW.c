/*
 * Function : StringCchCopyW
 * Address  : 0x1400035fc
 * Size     : 130 bytes (39 instructions)
 * Prototype: long StringCchCopyW(ushort * param_1, __uint64 param_2, ushort * param_3)
 * CC       : __cdecl
 * Comment  : long __cdecl StringCchCopyW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* long __cdecl StringCchCopyW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64) */

long __cdecl StringCchCopyW(ushort *param_1,__uint64 param_2,ushort *param_3)

{
  ushort uVar1;
  ushort *puVar2;
  longlong lVar3;
  uint uVar4;
  longlong lVar5;
  
  uVar4 = 0;
  if (0x7ffffffe < param_2 - 1) {
    uVar4 = 0x80070057;
  }
  if ((int)uVar4 < 0) {
    if (param_2 != 0) {
      *param_1 = 0;
    }
  }
  else {
    if (param_2 != 0) {
      lVar5 = 0x7ffffffe - param_2;
      lVar3 = (longlong)param_3 - (longlong)param_1;
      do {
        if ((lVar5 + param_2 == 0) || (uVar1 = *(ushort *)(lVar3 + (longlong)param_1), uVar1 == 0))
        break;
        *param_1 = uVar1;
        param_1 = param_1 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    puVar2 = param_1 + -1;
    if (param_2 != 0) {
      puVar2 = param_1;
    }
    uVar4 = ~-(uint)(param_2 != 0) & 0x8007007a;
    *puVar2 = 0;
  }
  return uVar4;
}


