/*
 * Function : `eh_vector_destructor_iterator'
 * Address  : 0x140015410
 * Size     : 103 bytes (34 instructions)
 * Prototype: void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4)
 * CC       : __cdecl
 * Comment  : void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,int,void (__cdecl*)(void * __ptr64))
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,int,void
   (__cdecl*)(void * __ptr64)) */

void __cdecl
_eh_vector_destructor_iterator_
          (void *param_1,__uint64 param_2,int param_3,_func_void_void_ptr *param_4)

{
  uint uVar1;
  ulonglong uVar2;
  void *pvVar3;
  
  uVar2 = (ulonglong)param_3;
  pvVar3 = (void *)(uVar2 * param_2 + (longlong)param_1);
  while( true ) {
    uVar1 = (int)uVar2 - 1;
    uVar2 = (ulonglong)uVar1;
    if ((int)uVar1 < 0) break;
    pvVar3 = (void *)((longlong)pvVar3 - param_2);
    (*param_4)(pvVar3);
  }
  return;
}


