/*
 * Function : ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z
 * Address  : 0x140004160
 * Size     : 120 bytes (23 instructions)
 * Prototype: void ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CExternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CExternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CExternalVerifier::_ResizeDiffArea_CExternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  ulonglong uVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  uVar1 = CVssMachineInformation::_GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z
                    (param_3);
  if (uVar1 <= param_4) {
    return;
  }
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ResizeDiffArea",0x127,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar2,0x1001,
             L"CVssAdminCLI::ResizeDiffarea: maxsize of less than (%I64u) MB specified, invalid",
             uVar1);
}


