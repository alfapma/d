/*
 * Function : __chkstk
 * Address  : 0x1400156d0
 * Size     : 77 bytes (19 instructions)
 * Prototype: undefined __chkstk(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: This is an inlined function */

void __chkstk(void)

{
  undefined1 *in_RAX;
  undefined1 *puVar1;
  void *pvVar2;
  undefined1 local_res8 [32];
  
  puVar1 = local_res8 + -(longlong)in_RAX;
  if (local_res8 < in_RAX) {
    puVar1 = (undefined1 *)0x0;
  }
  if (puVar1 < StackLimit) {
    pvVar2 = StackLimit;
    do {
      pvVar2 = (void *)((longlong)pvVar2 - 0x1000);
    } while ((void *)((ulonglong)puVar1 & 0xfffffffffffff000) < pvVar2);
  }
  return;
}


