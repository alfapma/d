/*
 * Function : MyGetChar
 * Address  : 0x14000e8bc
 * Size     : 748 bytes (166 instructions)
 * Prototype: ushort MyGetChar(void)
 * CC       : __cdecl
 * Comment  : unsigned short __cdecl MyGetChar(void)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* unsigned short __cdecl MyGetChar(void) */

ushort __cdecl MyGetChar(void)

{
  DWORD DVar1;
  BOOL BVar2;
  DWORD DVar3;
  DWORD DVar4;
  HANDLE hConsoleHandle;
  undefined8 uVar5;
  uint local_res8 [2];
  ushort local_res10 [4];
  DWORD local_res18 [4];
  undefined8 in_stack_fffffffffffffe88;
  undefined4 uVar6;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  wchar_t *local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined1 local_128 [120];
  undefined4 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  uVar6 = (undefined4)((ulonglong)in_stack_fffffffffffffe88 >> 0x20);
  local_150 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_148 = L"MyGetChar";
  local_140 = L"ADMUTILC";
  local_138 = 0x4d1;
  local_134 = 7;
  local_130 = 0xff;
  local_b0 = 0x1000000;
  memset(local_128,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_150);
  hConsoleHandle = GetStdHandle(0xfffffff6);
  if (hConsoleHandle == (HANDLE)0xffffffffffffffff) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4da,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from GetStdHandle(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  BVar2 = GetConsoleMode(hConsoleHandle,local_res8);
  if (BVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e1,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from GetConsoleMode(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  BVar2 = SetConsoleMode(hConsoleHandle,local_res8[0] & 0xfffffff9);
  if (BVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e9,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from SetConsoleMode(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  FlushConsoleInputBuffer(hConsoleHandle);
  uVar6 = 0;
  BVar2 = ReadConsoleW(hConsoleHandle,local_res10,1,local_res18,(PCONSOLE_READCONSOLE_CONTROL)0x0);
  if (BVar2 != 0) {
    SetConsoleMode(hConsoleHandle,local_res8[0]);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
    return local_res10[0];
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_150,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4f6,7,in_stack_fffffffffffffe98)
  ;
  DVar3 = GetLastError();
  DVar4 = GetLastError();
  DVar1 = DVar3 & 0xffff | 0x80070000;
  if ((int)DVar3 < 1) {
    DVar1 = DVar3;
  }
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_a8,uVar5,DVar1,L"MyGetChar - Error from ReadConsoleW(), rc: %d",
             CONCAT44(uVar6,DVar4));
}


