/*
 * Function : ?_Xran@_String_base@std@@SAXXZ
 * Address  : 0x1400150e0
 * Size     : 87 bytes (16 instructions)
 * Prototype: void ?_Xran@_String_base@std@@SAXXZ(void)
 * CC       : __cdecl
 * Comment  : public: static void __cdecl std::_String_base::_Xran(void)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: static void __cdecl std::_String_base::_Xran(void) */

void __cdecl std::_String_base::__Xran__String_base_std__SAXXZ(void)

{
  undefined1 auStack_a8 [32];
  undefined8 local_88;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> local_80 [40];
  out_of_range local_58 [64];
  ulonglong local_18;
  
  local_88 = 0xfffffffffffffffe;
  local_18 = __security_cookie ^ (ulonglong)auStack_a8;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __0__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_PEBD_Z
            (local_80,"invalid string position");
  out_of_range::
  __0out_of_range_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1_PEAV_STL70___Z
            (local_58,local_80,(_STL70 *)0x0);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVout_of_range_std__);
}


