/*
 * Function : ?ListSnapshots@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140006bbc
 * Size     : 2123 bytes (451 instructions)
 * Prototype: void ?ListSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ListSnapshots(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListSnapshots(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListSnapshots_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  bool bVar3;
  uint uVar4;
  bool bVar5;
  long lVar6;
  BOOL BVar7;
  long lVar8;
  ushort *puVar9;
  LPCWSTR lpszVolumeMountPoint;
  uchar pv [8];
  uchar auVar10 [8];
  wchar_t *pwVar11;
  undefined8 uVar12;
  CVssAdminCLI *pCVar13;
  wchar_t **ppwVar14;
  longlong *plVar15;
  longlong *plVar16;
  wchar_t *pwVar17;
  ulonglong uVar18;
  longlong lVar19;
  undefined1 auStackY_398 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc98;
  _VSSDBG_SEV_ENUM _Var20;
  ulonglong local_330;
  undefined **local_328;
  uchar auStack_320 [8];
  undefined **local_318;
  uchar auStack_310 [8];
  undefined **local_308;
  uchar auStack_300 [8];
  longlong *local_2f8;
  undefined **local_2f0;
  ushort *local_2e8;
  void *local_2e0;
  longlong *plStack_2d8;
  uint local_2d0;
  undefined **local_2c8;
  ushort *local_2c0;
  _GUID local_2b8;
  wchar_t *local_2a8;
  wchar_t *local_2a0;
  wchar_t *local_298;
  undefined4 local_290;
  undefined4 local_28c;
  undefined4 local_288;
  undefined1 local_280 [120];
  undefined4 local_208;
  undefined8 local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined4 local_1d0;
  undefined1 local_1c8 [120];
  undefined4 local_150;
  CVssFunctionTracer local_148 [8];
  long local_140;
  undefined **local_d8;
  uchar auStack_d0 [8];
  undefined **local_c8;
  uchar auStack_c0 [8];
  undefined **local_b8;
  uchar auStack_b0 [8];
  WCHAR local_a8 [49];
  undefined2 local_46;
  ulonglong local_38;
  
  local_1f8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_398;
  local_2a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_2a0 = L"CVssAdminCLI::ListSnapshots";
  local_298 = L"ADMPROCC";
  local_290 = 0x324;
  local_28c = 7;
  local_288 = 0xff;
  local_208 = 0x1000000;
  memset(local_280,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_148,&local_2a8);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar6 = -1;
  }
  else {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar6 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(pCVar13,puVar9);
  }
  local_d8 = (undefined **)0x0;
  auStack_d0[0] = '\0';
  auStack_d0[1] = '\0';
  auStack_d0[2] = '\0';
  auStack_d0[3] = '\0';
  auStack_d0[4] = '\0';
  auStack_d0[5] = '\0';
  auStack_d0[6] = '\0';
  auStack_d0[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,(_GUID *)&local_d8);
  lpszVolumeMountPoint =
       (LPCWSTR)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  bVar3 = false;
  local_b8 = (undefined **)0x0;
  auStack_b0[0] = '\0';
  auStack_b0[1] = '\0';
  auStack_b0[2] = '\0';
  auStack_b0[3] = '\0';
  auStack_b0[4] = '\0';
  auStack_b0[5] = '\0';
  auStack_b0[6] = '\0';
  auStack_b0[7] = '\0';
  puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
  if (puVar9 != (ushort *)0x0) {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
    bVar5 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar13,puVar9,(_GUID *)&local_b8);
    if (!bVar5) {
      uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1f0,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x337,7,
                          in_stack_fffffffffffffc98);
      _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar12,0x1004,L"CVssAdminCLI::ListSnapshots: invalid snapshot set ID: %s"
                );
    }
  }
  local_c8 = (undefined **)0x0;
  auStack_c0[0] = '\0';
  auStack_c0[1] = '\0';
  auStack_c0[2] = '\0';
  auStack_c0[3] = '\0';
  auStack_c0[4] = '\0';
  auStack_c0[5] = '\0';
  auStack_c0[6] = '\0';
  auStack_c0[7] = '\0';
  puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar9 != (ushort *)0x0) {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar5 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar13,puVar9,(_GUID *)&local_c8);
    if (!bVar5) {
      uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1f0,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x341,7,
                          in_stack_fffffffffffffc98);
      _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar12,0x1004,L"CVssAdminCLI::ListSnapshots: invalid snapshot ID: %s");
    }
  }
  local_308 = local_b8;
  auStack_300[0] = auStack_b0[0];
  auStack_300[1] = auStack_b0[1];
  auStack_300[2] = auStack_b0[2];
  auStack_300[3] = auStack_b0[3];
  auStack_300[4] = auStack_b0[4];
  auStack_300[5] = auStack_b0[5];
  auStack_300[6] = auStack_b0[6];
  auStack_300[7] = auStack_b0[7];
  local_318 = local_c8;
  auStack_310[0] = auStack_c0[0];
  auStack_310[1] = auStack_c0[1];
  auStack_310[2] = auStack_c0[2];
  auStack_310[3] = auStack_c0[3];
  auStack_310[4] = auStack_c0[4];
  auStack_310[5] = auStack_c0[5];
  auStack_310[6] = auStack_c0[6];
  auStack_310[7] = auStack_c0[7];
  local_328 = local_d8;
  auStack_320[0] = auStack_d0[0];
  auStack_320[1] = auStack_d0[1];
  auStack_320[2] = auStack_d0[2];
  auStack_320[3] = auStack_d0[3];
  auStack_320[4] = auStack_d0[4];
  auStack_320[5] = auStack_d0[5];
  auStack_320[6] = auStack_d0[6];
  auStack_320[7] = auStack_d0[7];
  _Var20 = (_VSSDBG_SEV_ENUM)local_148;
  (**(code **)(**(longlong **)this + 0x18))
            (*(longlong **)this,lVar6,&local_328,lpszVolumeMountPoint);
  memset(local_a8,0,100);
  if (lpszVolumeMountPoint != (LPCWSTR)0x0) {
    if (*lpszVolumeMountPoint == L'\\') {
      lVar8 = StringCchCopyW((ushort *)local_a8,0x32,(ushort *)lpszVolumeMountPoint);
      local_2a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_2a0 = L"CVssAdminCLI::ListSnapshots";
      local_298 = L"ADMPROCC";
      local_290 = 0x35b;
      local_28c = 7;
      local_288 = 0xff;
      local_208 = 0x1000000;
      local_140 = lVar8;
      memset(local_280,0,0x78);
      if (lVar8 < 0) {
        uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                           ((CVssDebugInfo *)&local_1f0,(CVssDebugInfo *)&local_2a8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                  (local_148,uVar12,lVar8,L"StringCchCopy");
      }
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_2a8);
      local_46 = 0;
    }
    else {
      BVar7 = GetVolumeNameForVolumeMountPointW(lpszVolumeMountPoint,local_a8,0x32);
      if (BVar7 == 0) {
        uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                           ((CVssDebugInfo *)&local_1f0,
                            (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                            (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x354,1,
                            _Var20);
        GetLastError();
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_148,uVar12,0x80042308,
                   L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx");
      }
    }
  }
  local_2e0 = (void *)0x0;
  plStack_2d8 = (longlong *)0x0;
  local_2d0 = 0;
  local_308 = local_d8;
  auStack_300[0] = auStack_d0[0];
  auStack_300[1] = auStack_d0[1];
  auStack_300[2] = auStack_d0[2];
  auStack_300[3] = auStack_d0[3];
  auStack_300[4] = auStack_d0[4];
  auStack_300[5] = auStack_d0[5];
  auStack_300[6] = auStack_d0[6];
  auStack_300[7] = auStack_d0[7];
  local_318 = local_c8;
  auStack_310[0] = auStack_c0[0];
  auStack_310[1] = auStack_c0[1];
  auStack_310[2] = auStack_c0[2];
  auStack_310[3] = auStack_c0[3];
  auStack_310[4] = auStack_c0[4];
  auStack_310[5] = auStack_c0[5];
  auStack_310[6] = auStack_c0[6];
  auStack_310[7] = auStack_c0[7];
  local_328 = local_b8;
  auStack_320[0] = auStack_b0[0];
  auStack_320[1] = auStack_b0[1];
  auStack_320[2] = auStack_b0[2];
  auStack_320[3] = auStack_b0[3];
  auStack_320[4] = auStack_b0[4];
  auStack_320[5] = auStack_b0[5];
  auStack_320[6] = auStack_b0[6];
  auStack_320[7] = auStack_b0[7];
  CVssAdmSnapshotSets::_Initialize_CVssAdmSnapshotSets__QEAAXJU_GUID__00PEBG_Z
            ((CVssAdmSnapshotSets *)&local_2e0,lVar6,(_GUID *)&local_328,(_GUID *)&local_318,
             (_GUID *)&local_308,(ushort *)local_a8);
  local_330 = (ulonglong)local_2d0;
  if (local_2d0 != 0) {
    plVar15 = plStack_2d8;
    bVar5 = false;
    if (0 < (int)local_2d0) {
      do {
        bVar3 = bVar5;
        puVar1 = (undefined8 *)*plVar15;
        local_2b8._0_8_ = *puVar1;
        local_2b8.Data4 = *(uchar (*) [8])(puVar1 + 1);
        local_2f8 = plVar15;
        pv = (uchar  [8])GuidToString(&local_2b8);
        local_308 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auStack_300 = pv;
        auVar10 = (uchar  [8])DateTimeToString((__int64 *)(*(longlong *)puVar1[4] + 0x70));
        local_318 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auStack_310 = auVar10;
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002752,pv,(ulonglong)*(uint *)(puVar1 + 2));
        if (0 < *(int *)(puVar1 + 5)) {
          bVar3 = true;
          lVar19 = 0;
          uVar18 = (ulonglong)*(uint *)(puVar1 + 5);
          do {
            puVar2 = *(undefined8 **)(lVar19 + puVar1[4]);
            _GetProviderName_CVssAdminCLI__AEAAPEBGAEAU_GUID___Z(this,(_GUID *)(puVar2 + 0xb));
            local_2e8 = _BuildSnapshotAttributeDisplayString_CVssAdminCLI__AEAAPEAGK_Z
                                  (this,*(ulong *)(puVar2 + 0xd));
            local_2f0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            auStack_320 = (uchar  [8])
                          _DetermineSnapshotType_CVssAdminCLI__AEAAPEAGJ_Z
                                    (this,*(long *)(puVar2 + 0xd));
            local_328 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            local_2b8._0_8_ = *puVar2;
            local_2b8.Data4 = *(uchar (*) [8])(puVar2 + 1);
            local_2c0 = GuidToString(&local_2b8);
            local_2c8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            pwVar11 = (wchar_t *)
                      _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,(ushort *)puVar2[6]);
            puVar9 = local_2c0;
            auVar10 = auStack_320;
            pwVar17 = L"?";
            if (pwVar11 != (wchar_t *)0x0) {
              pwVar17 = pwVar11;
            }
            _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002753,local_2c0,pwVar17);
            if (puVar9 != (ushort *)0x0) {
              CoTaskMemFree(puVar9);
            }
            local_2c0 = (ushort *)0x0;
            local_2c8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            if (auVar10 != (uchar  [8])0x0) {
              CoTaskMemFree((LPVOID)auVar10);
            }
            auStack_320[0] = '\0';
            auStack_320[1] = '\0';
            auStack_320[2] = '\0';
            auStack_320[3] = '\0';
            auStack_320[4] = '\0';
            auStack_320[5] = '\0';
            auStack_320[6] = '\0';
            auStack_320[7] = '\0';
            local_328 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            if (local_2e8 != (ushort *)0x0) {
              CoTaskMemFree(local_2e8);
            }
            local_2e8 = (ushort *)0x0;
            local_2f0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            lVar19 = lVar19 + 8;
            uVar18 = uVar18 - 1;
            plVar15 = local_2f8;
            auVar10 = auStack_310;
            pv = auStack_300;
          } while (uVar18 != 0);
        }
        if (auVar10 != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)auVar10);
        }
        auStack_310[0] = '\0';
        auStack_310[1] = '\0';
        auStack_310[2] = '\0';
        auStack_310[3] = '\0';
        auStack_310[4] = '\0';
        auStack_310[5] = '\0';
        auStack_310[6] = '\0';
        auStack_310[7] = '\0';
        local_318 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
        auStack_300[0] = '\0';
        auStack_300[1] = '\0';
        auStack_300[2] = '\0';
        auStack_300[3] = '\0';
        auStack_300[4] = '\0';
        auStack_300[5] = '\0';
        auStack_300[6] = '\0';
        auStack_300[7] = '\0';
        local_308 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        local_2f8 = plVar15 + 1;
        local_330 = local_330 - 1;
        plVar15 = local_2f8;
        bVar5 = bVar3;
      } while (local_330 != 0);
    }
    uVar4 = local_2d0;
    plVar15 = plStack_2d8;
    *(uint *)(this + 0x48) = (uint)!bVar3;
    local_1f0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
    local_1e8 = L"CVssAdmSnapshotSets::~CVssAdmSnapshotSets";
    local_1e0 = L"ADMPROCC";
    local_1d8 = 0xff;
    local_1d4 = 7;
    local_1d0 = 0xff;
    local_150 = 0x1000000;
    memset(local_1c8,0,0x78);
    ppwVar14 = &local_1f0;
    CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
              ((CVssFunctionTracer *)&local_2a8);
    if (0 < (int)uVar4) {
      uVar18 = (ulonglong)uVar4;
      plVar16 = plVar15;
      do {
        if ((CVssAdmSnapshotSetEntry *)*plVar16 != (CVssAdmSnapshotSetEntry *)0x0) {
          CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
                    ((CVssAdmSnapshotSetEntry *)*plVar16,(uint)ppwVar14);
        }
        plVar16 = plVar16 + 1;
        uVar18 = uVar18 - 1;
      } while (uVar18 != 0);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)&local_2a8);
    if (local_2e0 != (void *)0x0) {
      free(local_2e0);
    }
    if (plVar15 != (longlong *)0x0) {
      free(plVar15);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
    return;
  }
  uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                     ((CVssDebugInfo *)&local_1f0,
                      (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                      (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x36d,7,_Var20)
  ;
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_148,uVar12,1,
             L"CVssAdminCLI::ListSnapshots: No snapshots found that satisfy the query");
}


