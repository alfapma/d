/*
 * Function : ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z
 * Address  : 0x1400125bc
 * Size     : 206 bytes (58 instructions)
 * Prototype: basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::append(class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::append(class std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned
   __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::
_append___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                 *param_1,__uint64 param_2,__uint64 param_3)

{
  bool bVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  __uint64 _Var3;
  ulonglong uVar4;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar5;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *_Src;
  
  uVar4 = 0xffffffffffffffff;
  if (*(longlong *)(param_1 + 0x18) != -1) {
    uVar4 = *(ulonglong *)(param_1 + 0x18);
  }
  if (uVar4 < ~*(ulonglong *)(this + 0x18)) {
    if (uVar4 != 0) {
      _Var3 = *(longlong *)(this + 0x18) + uVar4;
      bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                        (this,_Var3,SUB81(param_2,0));
      if (bVar1) {
        _Src = param_1 + 8;
        if (7 < *(ulonglong *)(param_1 + 0x20)) {
          _Src = *(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                   **)_Src;
        }
        pbVar5 = this + 8;
        pbVar2 = pbVar5;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar5;
        }
        memcpy_s(pbVar2 + *(longlong *)(this + 0x18) * 2,
                 (*(ulonglong *)(this + 0x20) - *(longlong *)(this + 0x18)) * 2,_Src,uVar4 * 2);
        *(__uint64 *)(this + 0x18) = _Var3;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar5 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar5;
        }
        *(undefined2 *)(pbVar5 + _Var3 * 2) = 0;
      }
    }
    return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xlen__String_base_std__SAXXZ();
}


