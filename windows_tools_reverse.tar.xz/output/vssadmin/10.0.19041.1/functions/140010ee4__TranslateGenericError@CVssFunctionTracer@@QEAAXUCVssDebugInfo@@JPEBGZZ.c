/*
 * Function : ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ
 * Address  : 0x140010ee4
 * Size     : 488 bytes (105 instructions)
 * Prototype: void ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TranslateGenericError(struct CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TranslateGenericError(struct CVssDebugInfo,long,unsigned
   short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,ushort *param_4,...)

{
  undefined8 uVar1;
  ushort *puVar2;
  CVssDebugInfo *this_00;
  ulong in_stack_fffffffffffffe48;
  undefined4 uVar3;
  ushort *local_198;
  __uint64 local_190;
  ushort *local_188;
  undefined8 local_180;
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_180 = 0xfffffffffffffffe;
  local_188 = operator_new__(0x3ea,&std::nothrow);
  if (local_188 == (ushort *)0x0) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_190 = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_188,500,&local_198,&local_190,in_stack_fffffffffffffe48,param_4,
                      &stack0x00000028);
  uVar3 = (undefined4)((ulonglong)param_4 >> 0x20);
  if (local_190 == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  if ((((param_3 != -0x7ff8fff2) && (param_3 != -0x7ff8fff8)) && (param_3 != -0x7ff8ff8f)) &&
     (((param_3 != -0x7ff8fc05 && (param_3 != -0x7ff8fa56)) && (param_3 != -0x7ff8fb7a)))) {
    puVar2 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
    if (param_3 == -0x7ff8ff90) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar1,0x8004231f,L"ERROR_DISK_FULL detected in function %s",puVar2);
    }
    this_00 = (CVssDebugInfo *)
              CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
    uVar1 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar1);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x80042302,L"Unexpected error in routine %s. hr = 0x%08lx",puVar2,
               CONCAT44(uVar3,param_3));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}


