/*
 * Function : ??0bad_alloc@std@@QEAA@AEBV01@@Z
 * Address  : 0x14000ee60
 * Size     : 33 bytes (10 instructions)
 * Prototype: undefined ??0bad_alloc@std@@QEAA@AEBV01@@Z(bad_alloc * this, bad_alloc * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::bad_alloc::bad_alloc(class std::bad_alloc const & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::bad_alloc::bad_alloc(class std::bad_alloc const & __ptr64) __ptr64 */

bad_alloc * __thiscall
std::bad_alloc::__0bad_alloc_std__QEAA_AEBV01__Z(bad_alloc *this,bad_alloc *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &_vftable_;
  return this;
}


