/*
 * Function : ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z
 * Address  : 0x14000b754
 * Size     : 176 bytes (39 instructions)
 * Prototype: int ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetOptionValueBool(enum EVssAdmOption) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: int __cdecl CVssAdminCLI::GetOptionValueBool(enum EVssAdmOption) __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z
          (CVssAdminCLI *this,EVssAdmOption param_1)

{
  longlong lVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_110 = 0x15b;
  local_120 = L"CVssAdminCLI::GetOptionValueBool";
  local_10c = 7;
  local_118 = L"INCPNTRH";
  local_108 = 0xff;
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  lVar1 = *(longlong *)(this + (longlong)(int)param_1 * 8 + 0x68);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return (int)(lVar1 != 0);
}


