/*
 * Function : ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ
 * Address  : 0x14000fac8
 * Size     : 8 bytes (2 instructions)
 * Prototype: int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ(CVssFunctionTracer * this)
 * CC       : __thiscall
 * Comment  : public: int __cdecl CVssFunctionTracer::IsTracingEnabled(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: int __cdecl CVssFunctionTracer::IsTracingEnabled(void) __ptr64 */

int __thiscall
CVssFunctionTracer::_IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(CVssFunctionTracer *this)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  return iVar1;
}


