/*
 * Function : VssFreeSnapshotProperties
 * Address  : 0x14000bb18
 * Size     : 7 bytes (1 instructions)
 * Prototype: void VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP * param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64) */

void __cdecl VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014000bb18. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  VssFreeSnapshotPropertiesInternal();
  return;
}


