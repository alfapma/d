/*
 * Function : ?GetHr@CVssFunctionTracer@@QEAAJXZ
 * Address  : 0x1400038ec
 * Size     : 4 bytes (2 instructions)
 * Prototype: long ?GetHr@CVssFunctionTracer@@QEAAJXZ(CVssFunctionTracer * this)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssFunctionTracer::GetHr(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: long __cdecl CVssFunctionTracer::GetHr(void) __ptr64 */

long __thiscall CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(CVssFunctionTracer *this)

{
  return *(long *)(this + 8);
}


