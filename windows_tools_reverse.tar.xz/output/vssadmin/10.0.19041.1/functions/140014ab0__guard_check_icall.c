/*
 * Function : _guard_check_icall
 * Address  : 0x140014ab0
 * Size     : 3 bytes (1 instructions)
 * Prototype: undefined _guard_check_icall(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void _guard_check_icall(void)

{
  return;
}


