/*
 * Function : dtor$14
 * Address  : 0x140015d95
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$14(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::ListWriters'::__l1::dtor_14(undefined8 param_1,longlong param_2)

{
  ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ((CComBSTR *)(param_2 + 0x40));
  return;
}


