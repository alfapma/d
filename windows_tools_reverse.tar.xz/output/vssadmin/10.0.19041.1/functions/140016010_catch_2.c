/*
 * Function : catch$2
 * Address  : 0x140016010
 * Size     : 26 bytes (8 instructions)
 * Prototype: undefined8 catch$2(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined8 `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_2(void)

{
  return 0x140010c8c;
}


