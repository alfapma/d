/*
 * Function : __CxxSetUnhandledExceptionFilter
 * Address  : 0x1400147e0
 * Size     : 24 bytes (6 instructions)
 * Prototype: undefined8 __CxxSetUnhandledExceptionFilter(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined8 __CxxSetUnhandledExceptionFilter(void)

{
  SetUnhandledExceptionFilter(__CxxUnhandledExceptionFilter);
  return 0;
}


