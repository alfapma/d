/*
 * Function : ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z
 * Address  : 0x14000b824
 * Size     : 223 bytes (55 instructions)
 * Prototype: int ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2, int param_3)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2,int param_3)

{
  ushort *puVar1;
  __int64 _Var2;
  CVssFunctionTracer *this_00;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_128 = L"CVssAdminCLI::GetOptionValueNum";
  local_120 = L"INCPNTRH";
  local_118 = 0x168;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  this_00 = local_88;
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(this_00,&local_130);
  puVar1 = *(ushort **)(this + (longlong)(int)param_1 * 8 + 0x68);
  if (puVar1 != (ushort *)0x0) {
    _Var2 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,puVar1,param_3);
  }
  else {
    _Var2 = 0;
  }
  *param_2 = _Var2;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return (uint)(puVar1 != (ushort *)0x0);
}


