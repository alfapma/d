/*
 * Function : ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z
 * Address  : 0x1400116f0
 * Size     : 372 bytes (87 instructions)
 * Prototype: void ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::ComDisableSEH(struct CVssDebugInfo) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::ComDisableSEH(struct CVssDebugInfo) __ptr64 */

void __thiscall
CVssFunctionTracer::_ComDisableSEH_CVssFunctionTracer__QEAAXUCVssDebugInfo___Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2)

{
  HRESULT HVar1;
  int iVar2;
  CVssDebugInfo *pCVar3;
  undefined8 uVar4;
  longlong *local_res8;
  CVssDebugInfo *local_res10;
  _GUID local_218 [10];
  undefined1 local_170 [168];
  CVssDebugInfo local_c8 [176];
  
  local_res8 = (longlong *)0x0;
  local_res10 = param_2;
  HVar1 = CoCreateInstance((IID *)&CLSID_GlobalOptions,(LPUNKNOWN)0x0,1,
                           (IID *)&_GUID_0000015b_0000_0000_c000_000000000046,&local_res8);
  *(HRESULT *)(this + 8) = HVar1;
  if (HVar1 < 0) {
    pCVar3 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_218);
    pCVar3 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar3,(ushort *)local_c8);
    _GetHr_CVssFunctionTracer__QEAAJXZ(this);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar3,(long)local_170);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0xd,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_c8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_218);
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)local_218,param_2);
    _GetHr_CVssFunctionTracer__QEAAJXZ(this);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ();
  }
  iVar2 = (**(code **)(*local_res8 + 0x18))(local_res8,1,1);
  *(int *)(this + 8) = iVar2;
  if (-1 < iVar2) {
    if (local_res8 != (longlong *)0x0) {
      (**(code **)(*local_res8 + 0x10))();
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
    return;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)local_218,param_2);
  _GetHr_CVssFunctionTracer__QEAAJXZ(this);
                    /* WARNING: Subroutine does not return */
  _TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ();
}


