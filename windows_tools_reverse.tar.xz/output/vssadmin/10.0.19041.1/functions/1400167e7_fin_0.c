/*
 * Function : fin$0
 * Address  : 0x1400167e7
 * Size     : 43 bytes (14 instructions)
 * Prototype: undefined fin$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void ``eh_vector_constructor_iterator''::__l1::fin_0(undefined8 param_1,longlong param_2)

{
  if (*(int *)(param_2 + 0x24) == 0) {
    __ArrayUnwind(*(void **)(param_2 + 0x50),*(__uint64 *)(param_2 + 0x58),*(int *)(param_2 + 0x20),
                  *(_func_void_void_ptr **)(param_2 + 0x70));
  }
  return;
}


