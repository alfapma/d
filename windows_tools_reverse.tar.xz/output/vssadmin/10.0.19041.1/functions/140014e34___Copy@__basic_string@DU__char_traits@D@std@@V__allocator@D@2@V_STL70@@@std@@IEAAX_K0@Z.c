/*
 * Function : ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_K0@Z
 * Address  : 0x140014e34
 * Size     : 257 bytes (76 instructions)
 * Prototype: void ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          __uint64 param_1,__uint64 param_2)

{
  __uint64 _Var1;
  ulonglong uVar2;
  undefined1 auVar3 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *_Dst;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  bad_alloc local_60 [64];
  
  uVar5 = param_1 | 0xf;
  if (uVar5 != 0xffffffffffffffff) {
    uVar2 = *(ulonglong *)(this + 0x20);
    uVar6 = uVar2 >> 1;
    param_1 = uVar5;
    if ((uVar5 / 3 < uVar6) && (uVar2 <= -uVar6 - 2)) {
      param_1 = uVar6 + uVar2;
    }
  }
  _Var1 = param_1 + 1;
  if ((_Var1 != 0) &&
     (auVar3._8_8_ = 0, auVar3._0_8_ = _Var1,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3,0) == 0)) {
    bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(local_60,(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_60,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  _Dst = operator_new(_Var1);
  if (param_2 != 0) {
    pbVar4 = this + 8;
    if (0xf < *(ulonglong *)(this + 0x20)) {
      pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    memcpy_s(_Dst,param_1 + 1,pbVar4,param_2);
  }
  if (0xf < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)(this + 8) = _Dst;
  *(__uint64 *)(this + 0x20) = param_1;
  *(__uint64 *)(this + 0x18) = param_2;
  pbVar4 = this + 8;
  if (0xf < param_1) {
    pbVar4 = _Dst;
  }
  pbVar4[param_2] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}


