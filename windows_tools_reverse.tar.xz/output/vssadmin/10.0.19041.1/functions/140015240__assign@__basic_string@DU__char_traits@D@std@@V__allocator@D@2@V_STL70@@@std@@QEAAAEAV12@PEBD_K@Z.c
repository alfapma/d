/*
 * Function : ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@PEBD_K@Z
 * Address  : 0x140015240
 * Size     : 245 bytes (77 instructions)
 * Prototype: basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@PEBD_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(char const * __ptr64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(char const *
   __ptr64,unsigned __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_PEBD_K_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,char *param_1
          ,__uint64 param_2)

{
  ulonglong uVar1;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar3;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  
  pbVar4 = this + 8;
  uVar1 = *(ulonglong *)(this + 0x20);
  pbVar3 = pbVar4;
  if (0xf < uVar1) {
    pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  if (pbVar3 <= param_1) {
    pbVar3 = pbVar4;
    if (0xf < uVar1) {
      pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    if (param_1 < pbVar3 + *(longlong *)(this + 0x18)) {
      if (0xf < uVar1) {
        pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      pbVar2 = _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                         (this,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
                                *)this,(longlong)param_1 - (longlong)pbVar4,param_2);
      return pbVar2;
    }
  }
  if (param_2 == 0xffffffffffffffff) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xlen__String_base_std__SAXXZ();
  }
  if (uVar1 < param_2) {
    __Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
              (this,param_2,*(__uint64 *)(this + 0x18));
  }
  else {
    if (param_2 != 0) goto LAB_1400152e9;
    *(undefined8 *)(this + 0x18) = 0;
    pbVar3 = pbVar4;
    if (0xf < uVar1) {
      pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    *pbVar3 = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  }
  if (param_2 == 0) {
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
LAB_1400152e9:
  pbVar3 = pbVar4;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  memcpy_s(pbVar3,*(ulonglong *)(this + 0x20),param_1,param_2);
  *(__uint64 *)(this + 0x18) = param_2;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  pbVar4[param_2] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
         )this;
}


