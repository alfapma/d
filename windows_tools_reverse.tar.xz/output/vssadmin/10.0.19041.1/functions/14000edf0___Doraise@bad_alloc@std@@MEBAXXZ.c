/*
 * Function : ?_Doraise@bad_alloc@std@@MEBAXXZ
 * Address  : 0x14000edf0
 * Size     : 34 bytes (7 instructions)
 * Prototype: void ?_Doraise@bad_alloc@std@@MEBAXXZ(bad_alloc * this)
 * CC       : __thiscall
 * Comment  : protected: virtual void __cdecl std::bad_alloc::_Doraise(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: virtual void __cdecl std::bad_alloc::_Doraise(void)const __ptr64 */

void __thiscall std::bad_alloc::__Doraise_bad_alloc_std__MEBAXXZ(bad_alloc *this)

{
  bad_alloc local_28 [40];
  
  __0bad_alloc_std__QEAA_AEBV01__Z(local_28,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
}


