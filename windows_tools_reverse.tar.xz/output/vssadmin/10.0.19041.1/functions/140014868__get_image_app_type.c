/*
 * Function : _get_image_app_type
 * Address  : 0x140014868
 * Size     : 69 bytes (23 instructions)
 * Prototype: undefined4 _get_image_app_type(undefined4 param_1)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined4 _get_image_app_type(undefined4 param_1)

{
  HMODULE pHVar1;
  int *piVar2;
  
  pHVar1 = GetModuleHandleW((LPCWSTR)0x0);
  if ((pHVar1 != (HMODULE)0x0) &&
     (piVar2 = RtlpImageNtHeader((short *)pHVar1), piVar2 != (int *)0x0)) {
    if ((short)piVar2[0x17] == 2) {
      return 2;
    }
    if ((short)piVar2[0x17] == 3) {
      return 1;
    }
  }
  return param_1;
}


