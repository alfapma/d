/*
 * Function : dtor$1
 * Address  : 0x140015e49
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x160));
  return;
}


