/*
 * Function : ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ
 * Address  : 0x14000fad8
 * Size     : 408 bytes (87 instructions)
 * Prototype: void ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ(CVssFunctionTracer * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag(void) __ptr64 */

void __thiscall
CVssFunctionTracer::_UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ
          (CVssFunctionTracer *this)

{
  int iVar1;
  int iVar2;
  LPWSTR pWVar3;
  CVssFunctionTracer *this_00;
  ulong uVar4;
  undefined1 auStack_918 [32];
  wchar_t *local_8f8;
  DWORD local_8f0;
  LPWSTR local_8e8;
  CVssFunctionTracer *local_8e0;
  ulong local_8d8;
  undefined4 local_8d0;
  int local_8c8 [2];
  wchar_t *local_8c0;
  wchar_t *local_8b8;
  wchar_t *local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a4;
  undefined4 local_8a0;
  undefined1 local_898 [120];
  undefined4 local_820;
  CVssFunctionTracer local_818 [2048];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_918;
  iVar1 = Ordinal_11();
  if (iVar1 != *(int *)(this + 4)) {
    local_8c8[0] = 0;
    *(int *)(this + 4) = iVar1;
    iVar2 = Ordinal_8(*(undefined4 *)(this + 0x24),*(undefined8 *)(this + 0x28),local_8c8);
    iVar1 = local_8c8[0];
    if (iVar2 == 0) {
      if (*(CVssFunctionTracer **)(this + 0x60) == (CVssFunctionTracer *)0x0) {
        iVar1 = Ordinal_6();
      }
      else {
        iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(*(CVssFunctionTracer **)(this + 0x60))
        ;
      }
    }
    *(int *)this = iVar1;
    if (m_dwGlobalTracingSettingsSequenceNumber != *(ulong *)(this + 4)) {
      uVar4 = 0x800;
      this_00 = local_818;
      memset(local_818,0,0x800);
      _GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z(this_00,(ushort *)local_818,uVar4);
      local_8a8 = 0x24f;
      local_8c0 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
      local_8a4 = 0xb;
      local_8a0 = 0xff;
      local_8b8 = L"CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag";
      local_8b0 = L"TRCTRCC";
      local_820 = 0x1000000;
      memset(local_898,0,0x78);
      pWVar3 = GetCommandLineW();
      local_8f0 = GetCurrentProcessId();
      local_8d0 = *(undefined4 *)(this + 4);
      local_8d8 = m_dwGlobalTracingSettingsSequenceNumber;
      local_8f8 = 
      L"Tracing started or updated. PID=%d, CommandLine=[%s], UserName=[%s]. SQN=[%d -> %d]";
      local_8e8 = pWVar3;
      local_8e0 = local_818;
      _TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
                (this,&local_8c0,L"TRACING_STARTED",0x78);
      m_dwGlobalTracingSettingsSequenceNumber = *(ulong *)(this + 4);
    }
  }
  return;
}


