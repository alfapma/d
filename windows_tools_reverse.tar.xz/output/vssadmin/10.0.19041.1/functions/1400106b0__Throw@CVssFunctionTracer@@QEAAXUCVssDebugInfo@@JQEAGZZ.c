/*
 * Function : ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ
 * Address  : 0x1400106b0
 * Size     : 398 bytes (92 instructions)
 * Prototype: void ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64 const,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64
   const,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined4 param_3,ushort *param_4,...)

{
  int iVar1;
  ulong uVar2;
  undefined8 uVar3;
  ushort *puVar4;
  ulong in_stack_fffffffffffffee8;
  __uint64 local_f8;
  ushort *local_f0;
  ushort *local_e8;
  undefined8 local_e0;
  CVssDebugInfo local_d8 [184];
  
  local_e0 = 0xfffffffffffffffe;
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if ((iVar1 != 0) && (param_4 != (ushort *)0x0)) {
    local_e8 = operator_new__(0x3ea,&std::nothrow);
    if (local_e8 != (ushort *)0x0) {
      local_f8 = 0;
      local_f0 = (ushort *)0x0;
      StringCchVPrintfExW(local_e8,500,&local_f0,&local_f8,in_stack_fffffffffffffee8,param_4,
                          &stack0x00000028);
      if (local_f8 == 1) {
        local_f0[-2] = 0x2e;
        local_f0[-1] = 0x2e;
        local_f0[-3] = 0x2e;
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
      puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_e8);
      uVar2 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                        (param_2,0x50);
      _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                (this,uVar3,L"THROW",uVar2,puVar4);
    }
    CVssAutoCoString::__0CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_f8);
    puVar4 = _GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(this);
    CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z((CVssAutoCoString *)&local_f8,puVar4)
    ;
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
    puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_f8);
    uVar2 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                      (param_2,200);
    _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
              (this,uVar3,L"THROW",uVar2,puVar4);
    CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_f8);
    CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ((CVssOutputBuffer *)&local_e8);
  }
  *(undefined4 *)(this + 8) = param_3;
  local_f8 = CONCAT44(local_f8._4_4_,param_3);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(&local_f8,(ThrowInfo *)&_TI1J);
}


