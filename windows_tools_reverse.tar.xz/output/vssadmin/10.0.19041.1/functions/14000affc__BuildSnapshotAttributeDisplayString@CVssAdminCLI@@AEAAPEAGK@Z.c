/*
 * Function : ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z
 * Address  : 0x14000affc
 * Size     : 578 bytes (144 instructions)
 * Prototype: ushort * ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z(CVssAdminCLI * this, ulong param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short * __ptr64 __cdecl CVssAdminCLI::BuildSnapshotAttributeDisplayString(unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short * __ptr64 __cdecl
   CVssAdminCLI::BuildSnapshotAttributeDisplayString(unsigned long) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_BuildSnapshotAttributeDisplayString_CVssAdminCLI__AEAAPEAGK_Z
          (CVssAdminCLI *this,ulong param_1)

{
  uint uVar1;
  ushort uVar2;
  __uint64 _Var3;
  long lVar4;
  undefined1 auStackY_998 [32];
  ushort *in_stack_fffffffffffff690;
  ushort *local_968;
  undefined8 local_960;
  wchar_t *local_958;
  wchar_t *local_950;
  wchar_t *local_948;
  undefined4 local_940;
  undefined4 local_93c;
  undefined4 local_938;
  undefined1 local_930 [120];
  undefined4 local_8b8;
  CVssFunctionTracer local_8a8 [112];
  ushort local_838 [1024];
  ulonglong local_38;
  
  local_960 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_998;
  local_958 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_950 = L"CVssAdminCLI::BuildSnapshotAttributeDisplayString";
  local_948 = L"ADMPROCC";
  local_940 = 1999;
  local_93c = 7;
  local_938 = 0xff;
  local_8b8 = 0x1000000;
  memset(local_930,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_8a8);
  _Var3 = 0x800;
  memset(local_838,0,0x800);
  uVar2 = 0;
  do {
    uVar1 = 1 << ((byte)uVar2 & 0x1f) & param_1;
    if (uVar1 < 0x10001) {
      if (uVar1 == 0x10000) {
        lVar4 = 0x40002a9b;
LAB_14000b1b0:
        uVar1 = 0;
        goto LAB_14000b1b5;
      }
      if (uVar1 != 0) {
        if (uVar1 == 1) {
          lVar4 = 0x40002a94;
        }
        else if (uVar1 == 4) {
          lVar4 = 0x40002a96;
        }
        else if (uVar1 == 8) {
          lVar4 = 0x40002a97;
        }
        else if (uVar1 == 0x10) {
          lVar4 = 0x40002a98;
        }
        else if (uVar1 == 0x20) {
          lVar4 = 0x40002a99;
        }
        else {
          if (uVar1 != 0x40) goto LAB_14000b171;
          lVar4 = 0x40002a9a;
        }
        goto LAB_14000b1b0;
      }
    }
    else {
      if (uVar1 == 0x20000) {
        lVar4 = 0x40002a9c;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x40000) {
        lVar4 = 0x40002a9d;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x80000) {
        lVar4 = 0x40002a9e;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x100000) {
        lVar4 = 0x40002a9f;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x200000) {
        lVar4 = 0x40002aa0;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x400000) {
        lVar4 = 0x40002b0a;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x800000) {
        lVar4 = 0x40002b0b;
        goto LAB_14000b1b0;
      }
LAB_14000b171:
      lVar4 = 0;
LAB_14000b1b5:
      _AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
                (this,local_838,_Var3,lVar4,uVar1,in_stack_fffffffffffff690);
    }
    uVar2 = uVar2 + 1;
    if (0x1f < uVar2) {
      if (local_838[0] == 0) {
        _AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
                  (this,local_838,_Var3,0x40002aa1,0,in_stack_fffffffffffff690);
      }
      local_968 = (ushort *)0x0;
      VssSafeDuplicateStr(local_8a8,&local_968,local_838);
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_8a8);
      return local_968;
    }
  } while( true );
}


