/*
 * Function : ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z
 * Address  : 0x140010318
 * Size     : 496 bytes (104 instructions)
 * Prototype: void ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::GetCurrentUserName(unsigned short * __ptr64,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssFunctionTracer::GetCurrentUserName(unsigned short * __ptr64,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2)

{
  BOOL BVar1;
  int iVar2;
  HANDLE pvVar3;
  undefined1 auStackY_588 [32];
  HANDLE local_558;
  DWORD local_550 [4];
  HLOCAL local_540;
  _SID_NAME_USE local_538 [4];
  PSID local_528 [32];
  wchar_t local_428 [8];
  undefined1 local_418 [496];
  wchar_t local_228 [8];
  undefined1 local_218 [496];
  ulonglong local_28;
  
  local_28 = __security_cookie ^ (ulonglong)auStackY_588;
  *param_1 = 0;
  local_558 = (HANDLE)0x0;
  pvVar3 = GetCurrentThread();
  BVar1 = OpenThreadToken(pvVar3,8,1,&local_558);
  if (BVar1 == 0) {
    pvVar3 = GetCurrentProcess();
    BVar1 = OpenProcessToken(pvVar3,8,&local_558);
    if (BVar1 == 0) {
      return;
    }
  }
  local_550[0] = 0;
  BVar1 = GetTokenInformation(local_558,TokenUser,local_528,0x100,local_550);
  if (BVar1 == 0) {
    CloseHandle(local_558);
  }
  else {
    CloseHandle(local_558);
    builtin_wcsncpy(local_228,L"Unknown",8);
    memset(local_218,0,0x1f0);
    builtin_wcsncpy(local_428,L"Unknown",8);
    memset(local_418,0,0x1f0);
    local_550[2] = 0x100;
    local_550[1] = 0x100;
    BVar1 = LookupAccountSidLocalW
                      (local_528[0],local_428,local_550 + 2,local_228,local_550 + 1,local_538);
    if (BVar1 != 0) {
      local_540 = (HLOCAL)0x0;
      iVar2 = ConvertSidToStringSidW(local_528[0],&local_540);
      if (iVar2 != 0) {
        StringCchPrintfW(param_1,0x400,(ushort *)L"Name: %s\\%s, SID:%s",local_228);
        LocalFree(local_540);
      }
    }
  }
  return;
}


