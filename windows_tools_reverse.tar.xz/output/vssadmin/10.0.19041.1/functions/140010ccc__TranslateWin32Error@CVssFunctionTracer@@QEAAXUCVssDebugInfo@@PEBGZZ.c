/*
 * Function : ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ
 * Address  : 0x140010ccc
 * Size     : 525 bytes (115 instructions)
 * Prototype: void ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TranslateWin32Error(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TranslateWin32Error(struct CVssDebugInfo,unsigned short
   const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  DWORD DVar1;
  undefined8 uVar2;
  ushort *puVar3;
  CVssDebugInfo *this_00;
  DWORD DVar4;
  undefined8 local_res20;
  ulong in_stack_fffffffffffffe48;
  undefined4 uVar5;
  ushort *local_198;
  __uint64 local_190;
  ushort *local_188;
  undefined8 local_180;
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_180 = 0xfffffffffffffffe;
  local_res20 = param_4;
  local_188 = operator_new__(0x3ea,&std::nothrow);
  if (local_188 == (ushort *)0x0) {
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_190 = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_188,500,&local_198,&local_190,in_stack_fffffffffffffe48,param_3,
                      (char *)&local_res20);
  uVar5 = (undefined4)((ulonglong)param_3 >> 0x20);
  if (local_190 == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  DVar1 = GetLastError();
  DVar4 = DVar1 & 0xffff | 0x80070000;
  if ((int)DVar1 < 1) {
    DVar4 = DVar1;
  }
  if (DVar4 == 0) {
    DVar4 = 0x8000ffff;
  }
  if ((((DVar4 != 0x8007000e) && (DVar4 != 0x80070008)) && (DVar4 != 0x80070071)) &&
     (((DVar4 != 0x800703fb && (DVar4 != 0x800705aa)) && (DVar4 != 0x80070486)))) {
    puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
    if (DVar4 == 0x80070070) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar2,0x8004231f,L"ERROR_DISK_FULL detected in function %s",puVar3);
    }
    this_00 = (CVssDebugInfo *)
              CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
    uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar2);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x80042302,L"Unexpected error in routine %s. hr = 0x%08lx",puVar3,
               CONCAT44(uVar5,DVar4));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}


