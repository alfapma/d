/*
 * Function : ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z
 * Address  : 0x1400013dc
 * Size     : 1311 bytes (301 instructions)
 * Prototype: ushort * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID &
   __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetProviderName_CVssAdminCLI__AEAAPEBGAEAU_GUID___Z
          (CVssAdminCLI *this,_GUID *param_1)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auVar5 [16];
  int iVar6;
  void *pvVar7;
  ushort *puVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  ushort *puVar12;
  undefined1 auStackY_288 [32];
  _VSSDBG_SEV_ENUM _Var13;
  longlong **pplVar14;
  _GUID local_248;
  longlong *local_238;
  longlong *local_230;
  undefined1 local_228 [16];
  undefined1 local_218 [16];
  wchar_t *local_208;
  wchar_t *local_200;
  wchar_t *local_1f8;
  undefined4 local_1f0;
  undefined4 local_1ec;
  undefined4 local_1e8;
  undefined1 local_1e0 [120];
  undefined4 local_168;
  CVssFunctionTracer local_158 [8];
  int local_150;
  undefined8 local_e8;
  undefined1 local_d8 [8];
  longlong local_d0;
  longlong local_c8;
  ushort *local_c0;
  LPVOID local_b0;
  ulonglong local_48;
  
  local_e8 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_288;
  local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_200 = L"CVssAdminCLI::GetProviderName";
  local_1f8 = L"ADMVADMC";
  local_1f0 = 0xfd;
  local_1ec = 7;
  local_1e8 = 0xff;
  local_168 = 0x1000000;
  memset(local_1e0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158);
  lVar3._0_4_ = param_1->Data1;
  lVar3._4_2_ = param_1->Data2;
  lVar3._6_2_ = param_1->Data3;
  local_248 = *param_1;
  puVar8 = (ushort *)0x0;
  if (0 < *(int *)(this + 0x38)) {
    do {
      iVar6 = (int)puVar8;
      plVar10 = (longlong *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
      if ((*plVar10 == lVar3) && (plVar10[1] == *(longlong *)param_1->Data4)) goto LAB_1400014c7;
      puVar8 = (ushort *)(ulonglong)(iVar6 + 1U);
    } while ((int)(iVar6 + 1U) < *(int *)(this + 0x38));
  }
  iVar6 = -1;
LAB_1400014c7:
  if ((iVar6 == -1) ||
     (puVar8 = *(ushort **)(*(longlong *)(this + 0x30) + (longlong)iVar6 * 8),
     puVar8 == (ushort *)0x0)) {
    local_230 = (longlong *)0x0;
    local_248 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
    local_218 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
    local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
    local_200 = L"CVssAdminCLI::GetProviderName";
    local_1f8 = L"ADMVADMC";
    local_1f0 = 0x106;
    local_1ec = 7;
    local_1e8 = 0xff;
    local_168 = 0x1000000;
    memset(local_1e0,0,0x78);
    pplVar14 = &local_230;
    CVssFunctionTracer::
    _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
              (local_158,&local_208,local_218,L"Coordinator");
    if (local_150 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_208,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC"
                 ,(ushort *)L"CVssAdminCLI::GetProviderName",0x10d,7,(_VSSDBG_SEV_ENUM)pplVar14);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
    }
    local_238 = (longlong *)0x0;
    local_218 = ZEXT816(0);
    local_150 = (**(code **)(*local_230 + 0x50))(local_230,local_218,1,4);
    if (local_150 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_208,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC"
                 ,(ushort *)L"CVssAdminCLI::GetProviderName",0x115,7,(_VSSDBG_SEV_ENUM)pplVar14);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
    }
    while( true ) {
      local_150 = (**(code **)(*local_238 + 0x18))(local_238,1,local_d8,local_228);
      if (local_150 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_208,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                   (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderName",0x120,7,
                   (_VSSDBG_SEV_ENUM)pplVar14);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
      }
      if (local_150 == 1) break;
      CoTaskMemFree(local_b0);
      puVar8 = local_c0;
      _Var13 = (_VSSDBG_SEV_ENUM)pplVar14;
      local_b0 = (LPVOID)0x0;
      lVar2._0_4_ = param_1->Data1;
      lVar2._4_2_ = param_1->Data2;
      lVar2._6_2_ = param_1->Data3;
      if ((local_d0 == lVar2) && (local_c8 == *(longlong *)param_1->Data4)) {
        local_218._8_8_ = local_c0;
        local_218._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auVar5._8_8_ = 0;
        auVar5[0] = local_248.Data4[0];
        auVar5[1] = local_248.Data4[1];
        auVar5[2] = local_248.Data4[2];
        auVar5[3] = local_248.Data4[3];
        auVar5[4] = local_248.Data4[4];
        auVar5[5] = local_248.Data4[5];
        auVar5[6] = local_248.Data4[6];
        auVar5[7] = local_248.Data4[7];
        local_248 = (_GUID)(auVar5 << 0x40);
        puVar12 = (ushort *)0x0;
        if (local_c0 != (ushort *)0x0) {
          VssSafeDuplicateStr(local_158,(ushort **)&local_248,local_c0);
          puVar12 = (ushort *)local_248._0_8_;
        }
        local_248._0_8_ = puVar12;
        uVar9 = *(undefined8 *)param_1;
        uVar4 = *(undefined8 *)param_1->Data4;
        pvVar7 = realloc(*(void **)(this + 0x28),(longlong)(*(int *)(this + 0x38) + 1) << 4);
        if (pvVar7 != (void *)0x0) {
          *(void **)(this + 0x28) = pvVar7;
          pvVar7 = realloc(*(void **)(this + 0x30),(longlong)(*(int *)(this + 0x38) + 1) << 3);
          if (pvVar7 != (void *)0x0) {
            *(void **)(this + 0x30) = pvVar7;
            iVar6 = *(int *)(this + 0x38);
            *(int *)(this + 0x38) = iVar6 + 1;
            puVar11 = (undefined8 *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
            if (puVar11 != (undefined8 *)0x0) {
              *puVar11 = uVar9;
              puVar11[1] = uVar4;
              pvVar7 = *(void **)(this + 0x30);
            }
            puVar1 = (ulonglong *)((longlong)pvVar7 + (longlong)iVar6 * 8);
            if (puVar1 != (ulonglong *)0x0) {
              *puVar1 = (ulonglong)puVar12;
            }
            if (puVar8 != (ushort *)0x0) {
              CoTaskMemFree(puVar8);
            }
            if (local_238 != (longlong *)0x0) {
              (**(code **)(*local_238 + 0x10))();
            }
            if (local_230 != (longlong *)0x0) {
              (**(code **)(*local_230 + 0x10))();
            }
            CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
            return puVar12;
          }
        }
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_248);
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderName",0x142,1,
                           _Var13);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x8007000e,L"Memory allocation error");
      }
      CoTaskMemFree(local_c0);
      local_c0 = (ushort *)0x0;
    }
    puVar8 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,0x66);
    if (local_238 != (longlong *)0x0) {
      (**(code **)(*local_238 + 0x10))();
    }
    if (local_230 != (longlong *)0x0) {
      (**(code **)(*local_230 + 0x10))();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
                    /* WARNING: Read-only address (ram,0x000140019060) is written */
                    /* WARNING: Read-only address (ram,0x000140019070) is written */
  return puVar8;
}


