/*
 * Function : dtor$2
 * Address  : 0x140015747
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$2(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::GetProviderName'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x58));
  return;
}


