/*
 * Function : catch$2
 * Address  : 0x14001608b
 * Size     : 26 bytes (8 instructions)
 * Prototype: undefined1 * catch$2(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined1 * `CVssFunctionTracer::TranslateGenericErrorNoThrow'::__l1::catch_2(void)

{
  return (undefined1 *)0x140011124;
}


