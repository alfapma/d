/*
 * Function : ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ
 * Address  : 0x140009d80
 * Size     : 47 bytes (14 instructions)
 * Prototype: void ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ(CVssSimpleArray<_GUID> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssSimpleArray<struct _GUID>::~CVssSimpleArray<struct _GUID>(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssSimpleArray<struct _GUID>::~CVssSimpleArray<struct _GUID>(void) __ptr64 */

void __thiscall
CVssSimpleArray<_GUID>::__1__CVssSimpleArray_U_GUID____QEAA_XZ(CVssSimpleArray<_GUID> *this)

{
  if (*(void **)this != (void *)0x0) {
    free(*(void **)this);
    *(undefined8 *)this = 0;
  }
  *(undefined4 *)(this + 8) = 0;
  *(undefined4 *)(this + 0xc) = 0;
  return;
}


