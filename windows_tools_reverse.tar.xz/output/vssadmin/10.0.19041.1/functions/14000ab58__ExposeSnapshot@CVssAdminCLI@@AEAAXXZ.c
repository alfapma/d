/*
 * Function : ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x14000ab58
 * Size     : 1176 bytes (262 instructions)
 * Prototype: void ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ExposeSnapshot(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ExposeSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_ExposeSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  _GUID _Var1;
  uchar auVar2 [8];
  bool bVar3;
  ushort *puVar4;
  ushort *puVar5;
  ushort *puVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  CVssAdminCLI *this_00;
  int iVar9;
  undefined1 auStackY_1f8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe38;
  _VSSDBG_SEV_ENUM _Var10;
  longlong *local_1b8 [2];
  _GUID local_1a8;
  uchar local_198 [8];
  _GUID local_188;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  CVssFunctionTracer local_c8 [8];
  int local_c0;
  undefined8 local_58;
  _GUID local_48;
  ulonglong local_38;
  
  local_58 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1f8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::ExposeSnapshot";
  local_168 = L"ADMPROCC";
  local_160 = 0x777;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8,&local_178);
  puVar4 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,2);
  puVar5 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xb);
  iVar9 = 1;
  if (puVar4 != (ushort *)0x0) {
    uVar8 = 0xffffffffffffffff;
    do {
      uVar8 = uVar8 + 1;
    } while (puVar4[uVar8] != 0);
    if ((1 < uVar8) && (puVar4[1] == 0x3a)) {
      iVar9 = 0;
    }
  }
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  this_00 = this;
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  bVar3 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar6,&local_48);
  auVar2 = local_48.Data4;
  if (!bVar3) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_178,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ExposeSnapshot",0x788,7,
                       in_stack_fffffffffffffe38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_c8,uVar7,0x1004,L"CVssAdminCLI::ExposeSnapshot: Invalid snapshot id");
  }
  local_1a8.Data4[0] = local_48.Data4[0];
  local_1a8.Data4[1] = local_48.Data4[1];
  local_1a8.Data4[2] = local_48.Data4[2];
  local_1a8.Data4[3] = local_48.Data4[3];
  local_1a8.Data1 = local_48.Data1;
  local_1a8.Data2 = local_48.Data2;
  local_1a8.Data3 = local_48.Data3;
  local_1a8.Data4[4] = local_48.Data4[4];
  local_1a8.Data4[5] = local_48.Data4[5];
  local_1a8.Data4[6] = local_48.Data4[6];
  local_1a8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  (**(code **)(**(longlong **)this + 0x60))(*(longlong **)this,&local_1a8,puVar4,puVar5);
  local_1b8[0] = (longlong *)0x0;
  local_1a8 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_188 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::ExposeSnapshot";
  local_168 = L"ADMPROCC";
  local_160 = 0x799;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  _Var10 = (_VSSDBG_SEV_ENUM)local_1b8;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_c8,&local_178,&local_188,L"Coordinator");
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7a0,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  local_c0 = (**(code **)(*local_1b8[0] + 0x18))(local_1b8[0],0xffffffff);
  auVar2 = local_48.Data4;
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7a7,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  local_198[0] = '\0';
  local_198[1] = '\0';
  local_198[2] = '\0';
  local_198[3] = '\0';
  local_198[4] = '\0';
  local_198[5] = '\0';
  local_198[6] = '\0';
  local_198[7] = '\0';
  local_188.Data4[0] = local_48.Data4[0];
  local_188.Data4[1] = local_48.Data4[1];
  local_188.Data4[2] = local_48.Data4[2];
  local_188.Data4[3] = local_48.Data4[3];
  local_188.Data1 = local_48.Data1;
  local_188.Data2 = local_48.Data2;
  local_188.Data3 = local_48.Data3;
  local_188.Data4[4] = local_48.Data4[4];
  local_188.Data4[5] = local_48.Data4[5];
  local_188.Data4[6] = local_48.Data4[6];
  local_188.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  local_c0 = (**(code **)(*local_1b8[0] + 0x40))
                       (local_1b8[0],&local_188,puVar5,(iVar9 + 1) * 0x100000);
  auVar2 = local_198;
  if (local_c0 < 0) {
    if (local_c0 == -0x7ffbdcf8) {
      puVar4 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar4);
    }
    else if (local_c0 == -0x7ffbdcf3) {
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002bc9);
    }
    else {
      if (local_c0 != -0x7ff8ffa9) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_178,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7be,7,_Var10);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
      }
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002bc8);
    }
    if (local_1b8[0] != (longlong *)0x0) {
      (**(code **)(*local_1b8[0] + 0x10))();
    }
  }
  else {
    local_1a8.Data4[0] = local_198[0];
    local_1a8.Data4[1] = local_198[1];
    local_1a8.Data4[2] = local_198[2];
    local_1a8.Data4[3] = local_198[3];
    local_1a8.Data4[4] = local_198[4];
    local_1a8.Data4[5] = local_198[5];
    local_1a8.Data4[6] = local_198[6];
    local_1a8.Data4[7] = local_198[7];
    local_1a8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    _Var1 = local_1a8;
    local_1a8.Data4._0_4_ = local_198._0_4_;
    local_1a8.Data4._4_4_ = local_198._4_4_;
    local_188.Data4[0] = local_1a8.Data4[0];
    local_188.Data4[1] = local_1a8.Data4[1];
    local_188.Data4[2] = local_1a8.Data4[2];
    local_188.Data4[3] = local_1a8.Data4[3];
    local_188._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_188.Data4[4] = local_1a8.Data4[4];
    local_188.Data4[5] = local_1a8.Data4[5];
    local_188.Data4[6] = local_1a8.Data4[6];
    local_188.Data4[7] = local_1a8.Data4[7];
    local_1a8 = _Var1;
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275e,&local_188);
    *(undefined4 *)(this + 0x48) = 0;
    if (auVar2 != (uchar  [8])0x0) {
      CoTaskMemFree((LPVOID)auVar2);
    }
    if (local_1b8[0] != (longlong *)0x0) {
      (**(code **)(*local_1b8[0] + 0x10))();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
  return;
}


