/*
 * Function : ??0CVssAutoCoString@@QEAA@XZ
 * Address  : 0x14000eea4
 * Size     : 8 bytes (3 instructions)
 * Prototype: undefined ??0CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAutoCoString::CVssAutoCoString(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssAutoCoString::CVssAutoCoString(void) __ptr64 */

CVssAutoCoString * __thiscall CVssAutoCoString::__0CVssAutoCoString__QEAA_XZ(CVssAutoCoString *this)

{
  *(undefined8 *)this = 0;
  return this;
}


