/*
 * Function : catch$14
 * Address  : 0x1400161df
 * Size     : 78 bytes (17 instructions)
 * Prototype: undefined * catch$14(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_14(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return (undefined *)0x140011d6a;
}


