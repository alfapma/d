/*
 * Function : ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ
 * Address  : 0x140010c44
 * Size     : 122 bytes (29 instructions)
 * Prototype: long ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssFunctionTracer::TranslateComErrorNoThrow(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: long __cdecl CVssFunctionTracer::TranslateComErrorNoThrow(struct CVssDebugInfo,unsigned
   short const * __ptr64,...) __ptr64 */

long __thiscall
CVssFunctionTracer::_TranslateComErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined8 param_4,...
          )

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 local_res20;
  long local_c8;
  CVssDebugInfo local_b0 [168];
  
  puVar2 = &local_res20;
  local_res20 = param_4;
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_b0,param_2);
  _TranslateComError_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ(this,uVar1,param_3,puVar2);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return local_c8;
}


