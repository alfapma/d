/*
 * Function : ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z
 * Address  : 0x14000fdbc
 * Size     : 123 bytes (32 instructions)
 * Prototype: void ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned
   long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2,ushort *param_3)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    Ordinal_3(*(undefined8 *)(this + 0x10),*(undefined8 *)(this + 0x18),*(undefined4 *)(this + 0x20)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(this + 0x24),
              *(undefined8 *)(this + 0x28),param_1,param_2,param_3);
  }
  return;
}


