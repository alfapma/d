/*
 * Function : ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z
 * Address  : 0x14000c1fc
 * Size     : 650 bytes (157 instructions)
 * Prototype: ushort * ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z(CVssAdminCLI * this, uint param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::LoadStringW(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::LoadStringW(unsigned int) __ptr64
    */

ushort * __thiscall
CVssAdminCLI::_LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(CVssAdminCLI *this,uint param_1)

{
  longlong *plVar1;
  int iVar2;
  ulonglong uVar3;
  HMODULE hInstance;
  void *pvVar4;
  undefined8 uVar5;
  uint *puVar6;
  ulonglong uVar7;
  ushort *puVar8;
  undefined1 auStackY_9b8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffff678;
  ushort *local_978;
  undefined8 local_970;
  wchar_t *local_968;
  wchar_t *local_960;
  wchar_t *local_958;
  undefined4 local_950;
  undefined4 local_94c;
  undefined4 local_948;
  undefined1 local_940 [120];
  undefined4 local_8c8;
  CVssFunctionTracer local_8b8 [112];
  WCHAR local_848 [1024];
  ulonglong local_48;
  
  local_970 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_9b8;
  local_968 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_960 = L"CVssAdminCLI::LoadStringW";
  local_958 = L"ADMUTILC";
  local_950 = 0xa9;
  local_94c = 7;
  local_948 = 0xff;
  uVar3 = 0;
  local_8c8 = 0x1000000;
  memset(local_940,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_8b8,&local_968);
  if (0 < *(int *)(this + 0x20)) {
    puVar6 = *(uint **)(this + 0x10);
    uVar7 = uVar3;
    do {
      iVar2 = (int)uVar3;
      if (*puVar6 == param_1) goto LAB_14000c2c9;
      uVar3 = (ulonglong)(iVar2 + 1);
      uVar7 = uVar7 + 1;
      puVar6 = puVar6 + 1;
    } while ((longlong)uVar7 < (longlong)*(int *)(this + 0x20));
  }
  iVar2 = -1;
LAB_14000c2c9:
  if ((iVar2 != -1) &&
     (puVar8 = *(ushort **)(*(longlong *)(this + 0x18) + (longlong)iVar2 * 8),
     puVar8 != (ushort *)0x0)) {
LAB_14000c2de:
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_8b8);
    return puVar8;
  }
  hInstance = GetModuleHandleW((LPCWSTR)0x0);
  iVar2 = LoadStringW(hInstance,param_1,local_848,0x3ff);
  if (iVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_968,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::LoadStringW",0xb8,7,
                       in_stack_fffffffffffff678);
    GetLastError();
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_8b8,uVar5,0x8000ffff,L"Error on loading the string %u. 0x%08lx");
  }
  local_978 = (ushort *)0x0;
  VssSafeDuplicateStr(local_8b8,&local_978,(ushort *)local_848);
  puVar8 = local_978;
  pvVar4 = realloc(*(void **)(this + 0x10),(longlong)(*(int *)(this + 0x20) + 1) << 2);
  if (pvVar4 != (void *)0x0) {
    *(void **)(this + 0x10) = pvVar4;
    pvVar4 = realloc(*(void **)(this + 0x18),(longlong)(*(int *)(this + 0x20) + 1) << 3);
    if (pvVar4 != (void *)0x0) {
      *(void **)(this + 0x18) = pvVar4;
      iVar2 = *(int *)(this + 0x20);
      *(int *)(this + 0x20) = iVar2 + 1;
      puVar6 = (uint *)(*(longlong *)(this + 0x10) + (longlong)iVar2 * 4);
      if (puVar6 != (uint *)0x0) {
        *puVar6 = param_1;
        pvVar4 = *(void **)(this + 0x18);
      }
      plVar1 = (longlong *)((longlong)pvVar4 + (longlong)iVar2 * 8);
      if (plVar1 != (longlong *)0x0) {
        *plVar1 = (longlong)puVar8;
      }
      goto LAB_14000c2de;
    }
  }
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_978);
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_968,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::LoadStringW",0xc4,1,
                     in_stack_fffffffffffff678);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_8b8,uVar5,0x8007000e,L"Memory allocation error");
}


