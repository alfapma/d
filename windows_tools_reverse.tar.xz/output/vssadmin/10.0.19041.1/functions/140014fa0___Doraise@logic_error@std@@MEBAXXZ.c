/*
 * Function : ?_Doraise@logic_error@std@@MEBAXXZ
 * Address  : 0x140014fa0
 * Size     : 49 bytes (10 instructions)
 * Prototype: void ?_Doraise@logic_error@std@@MEBAXXZ(logic_error * this)
 * CC       : __thiscall
 * Comment  : protected: virtual void __cdecl std::logic_error::_Doraise(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: virtual void __cdecl std::logic_error::_Doraise(void)const __ptr64 */

void __thiscall std::logic_error::__Doraise_logic_error_std__MEBAXXZ(logic_error *this)

{
  undefined1 auStack_78 [32];
  logic_error local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0logic_error_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI2_AVlogic_error_std__);
}


