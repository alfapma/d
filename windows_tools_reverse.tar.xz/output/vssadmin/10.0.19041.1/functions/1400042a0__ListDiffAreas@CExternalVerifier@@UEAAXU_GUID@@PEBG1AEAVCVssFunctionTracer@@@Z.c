/*
 * Function : ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z
 * Address  : 0x1400042a0
 * Size     : 101 bytes (19 instructions)
 * Prototype: void ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CExternalVerifier::ListDiffAreas(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CExternalVerifier::ListDiffAreas(struct _GUID,unsigned short const *
   __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::_ListDiffAreas_CExternalVerifier__UEAAXU_GUID__PEBG1AEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,
          CVssFunctionTracer *param_4)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if ((param_2 != (ushort *)0x0) && (param_3 != (ushort *)0x0)) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ListDiffAreas",0x154,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_4,uVar1,0x1008,
               L"CVssAdminCLI::ListDiffAreas: Can\'t specify both ON and FOR volume options");
  }
  return;
}


