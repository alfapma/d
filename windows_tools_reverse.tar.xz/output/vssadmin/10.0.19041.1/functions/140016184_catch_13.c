/*
 * Function : catch$13
 * Address  : 0x140016184
 * Size     : 90 bytes (19 instructions)
 * Prototype: undefined * catch$13(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_13(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),*(_com_error **)(param_2 + 0x1b8),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return (undefined *)0x140011d68;
}


