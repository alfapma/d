/*
 * Function : ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ
 * Address  : 0x1400110d8
 * Size     : 131 bytes (31 instructions)
 * Prototype: long ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct
   CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64 */

long __thiscall
CVssFunctionTracer::_TranslateGenericErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__JPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,uint param_3,undefined8 param_4,...)

{
  undefined8 uVar1;
  ulonglong uVar2;
  CVssDebugInfo local_b0 [168];
  
  uVar2 = (ulonglong)param_3;
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_b0,param_2);
                    /* WARNING: Subroutine does not return */
  _TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (this,uVar1,uVar2 & 0xffffffff,param_4,&stack0x00000028);
}


