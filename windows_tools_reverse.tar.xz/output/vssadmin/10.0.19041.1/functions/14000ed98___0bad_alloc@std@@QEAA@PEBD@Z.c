/*
 * Function : ??0bad_alloc@std@@QEAA@PEBD@Z
 * Address  : 0x14000ed98
 * Size     : 49 bytes (13 instructions)
 * Prototype: undefined ??0bad_alloc@std@@QEAA@PEBD@Z(bad_alloc * this, char * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::bad_alloc::bad_alloc(char const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::bad_alloc::bad_alloc(char const * __ptr64) __ptr64 */

bad_alloc * __thiscall std::bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(bad_alloc *this,char *param_1)

{
  char *local_res10 [3];
  
  local_res10[0] = param_1;
  exception::exception((exception *)this,local_res10);
  *(undefined ***)this = &_vftable_;
  return this;
}


