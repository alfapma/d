/*
 * Function : ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z
 * Address  : 0x1400029dc
 * Size     : 953 bytes (185 instructions)
 * Prototype: long ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z(int param_1, ushort * * param_2)
 * CC       : __cdecl
 * Comment  : public: static long __cdecl CVssAdminCLI::Main(int,unsigned short * __ptr64 * __ptr64 const)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static long __cdecl CVssAdminCLI::Main(int,unsigned short * __ptr64 * __ptr64 const) */

long __cdecl CVssAdminCLI::_Main_CVssAdminCLI__SAJHQEAPEAG_Z(int param_1,ushort **param_2)

{
  int iVar1;
  undefined1 auStack_568 [72];
  long local_520;
  CVssFunctionTracer local_508 [8];
  undefined4 local_500;
  undefined8 local_3e8;
  undefined8 local_1c8;
  undefined8 local_1c0;
  undefined8 local_1b8;
  undefined8 uStack_1b0;
  undefined4 local_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined4 local_190;
  undefined8 local_188;
  long local_180;
  int local_17c;
  ushort **local_178;
  undefined4 local_168;
  undefined1 local_160 [112];
  undefined8 local_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined1 local_d8;
  wchar_t *local_c8;
  wchar_t *local_c0;
  wchar_t *local_b8;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 local_a8;
  undefined1 local_a0 [120];
  undefined4 local_28;
  ulonglong local_18;
  
  local_3e8 = 0xfffffffffffffffe;
  local_18 = __security_cookie ^ (ulonglong)auStack_568;
  local_c8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_c0 = L"CVssAdminCLI::Main";
  local_b8 = L"ADMVADMC";
  local_b0 = 0x309;
  local_ac = 7;
  local_a8 = 0xff;
  local_28 = 0x1000000;
  memset(local_a0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_508,&local_c8);
  local_520 = 2;
  HeapSetInformation((HANDLE)0x0,HeapEnableTerminationOnCorruption,(PVOID)0x0,0);
  local_1b8 = 0;
  uStack_1b0 = 0;
  local_1a8 = 0;
  local_1a0 = 0;
  local_198 = 0;
  local_190 = 0;
  local_168 = 0x17;
  memset(local_160,0,0x70);
  local_f0 = 0;
  local_e8 = 0;
  uStack_e0 = 0;
  local_180 = 2;
  local_1c0 = 0xffffffffffffffff;
  local_188 = 0;
  local_1c8 = 0;
  local_d8 = 0;
  local_17c = param_1;
  local_178 = param_2;
  _Initialize_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  iVar1 = _ParseCmdLine_CVssAdminCLI__AEAAHXZ((CVssAdminCLI *)&local_1c8);
  if (iVar1 == 0) {
    _PrintUsage_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  }
  else {
    _DoProcessing_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  }
  local_500 = 0;
  local_520 = local_180;
  __1CVssAdminCLI__QEAA_XZ((CVssAdminCLI *)&local_1c8);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_508);
  return local_520;
}


