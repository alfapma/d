/*
 * Function : ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ
 * Address  : 0x1400122f0
 * Size     : 22 bytes (6 instructions)
 * Prototype: undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct
   std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
    */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this)

{
  *(undefined8 *)(this + 0x20) = 7;
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined2 *)(this + 8) = 0;
  return this;
}


