/*
 * Function : ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z
 * Address  : 0x14000d788
 * Size     : 764 bytes (169 instructions)
 * Prototype: int ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z(CVssAdminCLI * this, long param_1, ulong param_2)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::PromptUserForConfirmation(long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: int __cdecl CVssAdminCLI::PromptUserForConfirmation(long,unsigned long) __ptr64 */

int __thiscall
CVssAdminCLI::_PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z
          (CVssAdminCLI *this,long param_1,ulong param_2)

{
  int iVar1;
  DWORD DVar2;
  BOOL BVar3;
  PCNZWCH lpString2;
  WCHAR *pv;
  undefined8 uVar4;
  undefined1 auStackY_1d8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe58;
  WCHAR local_198 [4];
  DWORD local_190 [4];
  undefined8 local_180;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  CVssFunctionTracer local_c8 [112];
  ushort local_58 [16];
  ulonglong local_38;
  
  local_180 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1d8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_170 = L"CVssAdminCLI::PromptUserForConfirmation";
  local_168 = L"ADMUTILC";
  local_160 = 0x2cc;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8,&local_178);
  local_190[0] = 0;
  local_58[0] = 0;
  local_58[1] = 0;
  local_58[2] = 0;
  local_58[3] = 0;
  local_58[4] = 0;
  local_58[5] = 0;
  local_58[6] = 0;
  local_58[7] = 0;
  local_58[8] = 0;
  local_58[9] = 0;
  local_58[10] = 0;
  local_58[0xb] = 0;
  local_58[0xc] = 0;
  local_58[0xd] = 0;
  local_58[0xe] = 0;
  local_58[0xf] = 0;
  iVar1 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  if (iVar1 != 0) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
    return 1;
  }
  lpString2 = (PCNZWCH)_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x4000300d);
  if (lpString2 != (PCNZWCH)0x0) {
    pv = (WCHAR *)_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x4000300e);
    if (pv != (WCHAR *)0x0) {
      if (param_2 == 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,param_1,lpString2,pv);
      }
      else {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,param_1,(ulonglong)param_2,lpString2);
      }
      DVar2 = GetFileType(*(HANDLE *)(this + 8));
      if (((DVar2 & 2) == 0) ||
         (BVar3 = GetConsoleMode(*(HANDLE *)(this + 8),local_190), BVar3 == 0)) {
        local_198[0] = *pv;
      }
      else {
        local_198[0] = MyGetChar();
      }
      StringCchPrintfW(local_58,0x10,(ushort *)L"%c\n\n",(ulonglong)(ushort)local_198[0]);
      _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_58);
      iVar1 = CompareStringW(0x7f,0x10001,local_198,1,lpString2,1);
      CoTaskMemFree(lpString2);
      CoTaskMemFree(pv);
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
      return (uint)(iVar1 == 2);
    }
    CoTaskMemFree(lpString2);
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_178,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::PromptUserForConfirmation",
                       0x2eb,7,in_stack_fffffffffffffe58);
    GetLastError();
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_c8,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
  }
  uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_178,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::PromptUserForConfirmation",
                     0x2e2,7,in_stack_fffffffffffffe58);
  GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_c8,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
}


