/*
 * Function : GetVolumeNameWithCheck
 * Address  : 0x1400132ec
 * Size     : 466 bytes (104 instructions)
 * Prototype: void GetVolumeNameWithCheck(CVssDebugInfo param_1, long param_2, ushort * param_3, ushort * param_4, ulong param_5)
 * CC       : __cdecl
 * Comment  : void __cdecl GetVolumeNameWithCheck(struct CVssDebugInfo,long,unsigned short const * __ptr64,unsigned short * __ptr64,unsigned long)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl GetVolumeNameWithCheck(struct CVssDebugInfo,long,unsigned short const *
   __ptr64,unsigned short * __ptr64,unsigned long) */

void __cdecl
GetVolumeNameWithCheck(CVssDebugInfo *param_1,undefined8 param_2,LPCWSTR param_3,LPWSTR param_4)

{
  BOOL BVar1;
  DWORD DVar2;
  undefined8 uVar3;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  undefined8 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  local_b0 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
  local_150 = L"GetVolumeNameWithCheck";
  local_148 = L"INCVOLH";
  local_140 = 0x15b;
  local_13c = 0xb;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8);
  *param_4 = L'\0';
  local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
  local_150 = L"GetVolumeNameWithCheck";
  local_148 = L"INCVOLH";
  local_140 = 0x163;
  local_13c = 0xb;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_a8,&local_158,L"GetVolumeNameForVolumeMountPointW will be called on %s",param_3);
  BVar1 = GetVolumeNameForVolumeMountPointW(param_3,param_4,0x32);
  if (BVar1 != 0) {
    local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
    local_150 = L"GetVolumeNameWithCheck";
    local_148 = L"INCVOLH";
    local_140 = 0x16b;
    local_13c = 0xb;
    local_138 = 0xff;
    local_b8 = 0x1000000;
    memset(local_130,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_a8,&local_158,
               L"GetVolumeNameForVolumeMountPointW succeeded and the output is %s",param_4);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_1);
    return;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)&local_158,param_1);
  DVar2 = GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_a8,uVar3,0x80070057,
             L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx",param_3,
             DVar2);
}


