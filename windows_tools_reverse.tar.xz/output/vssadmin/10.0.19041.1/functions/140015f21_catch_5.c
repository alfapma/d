/*
 * Function : catch$5
 * Address  : 0x140015f21
 * Size     : 36 bytes (8 instructions)
 * Prototype: undefined catch$5(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::catch_5(undefined8 param_1,longlong param_2)

{
  *(undefined4 *)(param_2 + 0x48) = 0x8007000e;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException((void *)(param_2 + 0x48),(ThrowInfo *)&_TI1J);
}


