/*
 * Function : ??0?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@PEBD@Z
 * Address  : 0x140014ac8
 * Size     : 53 bytes (16 instructions)
 * Prototype: undefined ??0?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@PEBD@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>(char const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>(char const * __ptr64) __ptr64 */

basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__0__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_PEBD_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,char *param_1
          )

{
  __uint64 _Var1;
  
  *(undefined8 *)(this + 0x20) = 0xf;
  *(undefined8 *)(this + 0x18) = 0;
  this[8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  _Var1 = 0xffffffffffffffff;
  do {
    _Var1 = _Var1 + 1;
  } while (param_1[_Var1] != '\0');
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_PEBD_K_Z
            (this,param_1,_Var1);
  return this;
}


