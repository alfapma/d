/*
 * Function : ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ
 * Address  : 0x14000b5cc
 * Size     : 62 bytes (16 instructions)
 * Prototype: void ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >::~CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual __cdecl CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void *
   __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void *
   __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64
   __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >::~CVssAuto<void *
   __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int
   __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 &
   __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void *
   __ptr64 & __ptr64)> >(void) __ptr64 */

void __thiscall
CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
::
__1__CVssAuto_PEAXV__CVssAutoGenericValue_Storage_PEAX_0_0P6AHPEAX_Z_1_FindVolumeClose__YAH0_ZP6AAEAPEAXAEAPEAX_Z_1_Identity___DTyper_PEAX__SAAEAPEAX1_Z____UEAA_XZ
          (CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,_1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
           *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(HANDLE *)(this + 8) != (HANDLE)0xffffffffffffffff) {
    FindVolumeClose(*(HANDLE *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0xffffffffffffffff;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}


