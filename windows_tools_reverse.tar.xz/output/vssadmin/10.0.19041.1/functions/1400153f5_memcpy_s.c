/*
 * Function : memcpy_s
 * Address  : 0x1400153f5
 * Size     : 6 bytes (1 instructions)
 * Prototype: errno_t memcpy_s(void * _Dst, rsize_t _DstSize, void * _Src, rsize_t _MaxCount)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

errno_t __cdecl memcpy_s(void *_Dst,rsize_t _DstSize,void *_Src,rsize_t _MaxCount)

{
  errno_t eVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0001400153f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  eVar1 = memcpy_s(_Dst,_DstSize,_Src,_MaxCount);
  return eVar1;
}


