/*
 * Function : __report_rangecheckfailure
 * Address  : 0x140014638
 * Size     : 247 bytes (44 instructions)
 * Prototype: undefined __report_rangecheckfailure(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __report_rangecheckfailure(void)

{
  DWORD64 ControlPc;
  PRUNTIME_FUNCTION FunctionEntry;
  DWORD64 local_28;
  ulonglong local_20;
  PVOID local_18 [3];
  
  RtlCaptureContext(&DAT_140024210);
  ControlPc = DAT_140024308;
  FunctionEntry = RtlLookupFunctionEntry(DAT_140024308,&local_28,(PUNWIND_HISTORY_TABLE)0x0);
  if (FunctionEntry == (PRUNTIME_FUNCTION)0x0) {
    DAT_140024308 = *DAT_1400242a8;
    DAT_1400242a8 = DAT_1400242a8 + 1;
  }
  else {
    RtlVirtualUnwind(0,local_28,ControlPc,FunctionEntry,(PCONTEXT)&DAT_140024210,local_18,&local_20,
                     (PKNONVOLATILE_CONTEXT_POINTERS)0x0);
  }
  _DAT_140024180 = DAT_140024308;
  _DAT_140024170 = 0xc0000409;
  _DAT_140024174 = 1;
  _DAT_140024188 = 1;
  DAT_140024190 = 8;
  __raise_securityfailure((_EXCEPTION_POINTERS *)&PTR_DAT_140017008);
  return;
}


