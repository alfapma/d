/*
 * Function : ??BCVssAutoCoString@@QEBAPEAGXZ
 * Address  : 0x14000ee98
 * Size     : 4 bytes (2 instructions)
 * Prototype: ushort * ??BCVssAutoCoString@@QEBAPEAGXZ(CVssAutoCoString * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64 */

ushort * __thiscall CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ(CVssAutoCoString *this)

{
  return *(ushort **)this;
}


