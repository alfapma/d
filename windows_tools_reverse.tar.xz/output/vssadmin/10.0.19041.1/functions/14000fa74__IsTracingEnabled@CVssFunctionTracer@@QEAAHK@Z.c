/*
 * Function : ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z
 * Address  : 0x14000fa74
 * Size     : 74 bytes (23 instructions)
 * Prototype: int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z(CVssFunctionTracer * this, ulong param_1)
 * CC       : __thiscall
 * Comment  : public: int __cdecl CVssFunctionTracer::IsTracingEnabled(unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: int __cdecl CVssFunctionTracer::IsTracingEnabled(unsigned long) __ptr64 */

int __thiscall
CVssFunctionTracer::_IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z
          (CVssFunctionTracer *this,ulong param_1)

{
  int iVar1;
  
  iVar1 = Ordinal_5();
  if ((iVar1 != 0) && (iVar1 = Ordinal_7(param_1), iVar1 != 0)) {
    _UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ(this);
    return *(int *)this;
  }
  return 0;
}


