/*
 * Function : ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z
 * Address  : 0x140012aa8
 * Size     : 1069 bytes (225 instructions)
 * Prototype: long ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ushort * param_2, bool param_3, bool param_4, _VSS_ICHANNEL_LOGGING param_5, ulong param_6, ulong param_7, ulong param_8)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssIOCTLChannel::Open(class CVssFunctionTracer & __ptr64,unsigned short const * __ptr64,bool,bool,enum _VSS_ICHANNEL_LOGGING,unsigned long,unsigned long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: long __cdecl CVssIOCTLChannel::Open(class CVssFunctionTracer & __ptr64,unsigned short
   const * __ptr64,bool,bool,enum _VSS_ICHANNEL_LOGGING,unsigned long,unsigned long,unsigned long)
   __ptr64 */

long __thiscall
CVssIOCTLChannel::
_Open_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__PEBG_N2W4_VSS_ICHANNEL_LOGGING__KKK_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ushort *param_2,bool param_3,
          bool param_4,_VSS_ICHANNEL_LOGGING param_5,ulong param_6,ulong param_7,ulong param_8)

{
  WCHAR WVar1;
  code *pcVar2;
  DWORD DVar3;
  ulonglong uVar4;
  DWORD DVar5;
  long lVar6;
  WCHAR *pWVar7;
  HANDLE pvVar8;
  undefined8 uVar9;
  longlong lVar10;
  WCHAR *pWVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined1 auStackY_408 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc28;
  _VSSDBG_SEV_ENUM _Var14;
  wchar_t *local_3b8;
  wchar_t *local_3b0;
  wchar_t *local_3a8;
  undefined4 local_3a0;
  undefined4 local_39c;
  undefined4 local_398;
  undefined1 local_390 [120];
  undefined4 local_318;
  undefined8 local_310;
  CVssDebugInfo local_308 [176];
  WCHAR local_258 [264];
  ulonglong local_48;
  
  local_310 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_408;
  local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_3b0 = L"CVssIOCTLChannel::Open";
  local_3a8 = L"INCICHLH";
  local_3a0 = 200;
  local_39c = 10;
  local_398 = 0xff;
  local_318 = 0x1000000;
  memset(local_390,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (param_1,&local_3b8,L"Opening a handle to %s (access = 0x%08lx, share = 0x%08lx)",
             param_2);
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(HANDLE *)this != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)this);
  }
  *(undefined8 *)this = 0;
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  uVar4 = 0xffffffffffffffff;
  do {
    uVar13 = uVar4;
    uVar4 = uVar13 + 1;
  } while (param_2[uVar13 + 1] != 0);
  if (0x103 < uVar13) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_308,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0xda,10,
                       in_stack_fffffffffffffc28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar9,0x8000ffff,L"Error: the buffer is too small to fit %s (%d < %d)");
  }
  if (param_2[uVar13] != 0x5c) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_3b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0xe2,10,
                       in_stack_fffffffffffffc28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar9,0x8000ffff,L"Error: the object name %s does terminate with a backslash"
              );
  }
  if (uVar13 < 0x7fffffff) {
    lVar10 = 0x104;
    pWVar11 = local_258;
    do {
      if (((uVar13 - 0x104) + lVar10 == 0) ||
         (WVar1 = *(WCHAR *)((longlong)pWVar11 + ((longlong)param_2 - (longlong)local_258)),
         WVar1 == L'\0')) break;
      *pWVar11 = WVar1;
      pWVar11 = pWVar11 + 1;
      lVar10 = lVar10 + -1;
    } while (lVar10 != 0);
    pWVar7 = pWVar11 + -1;
    if (lVar10 != 0) {
      pWVar7 = pWVar11;
    }
    *pWVar7 = L'\0';
    uVar12 = ~-(uint)(lVar10 != 0) & 0x8007007a;
  }
  else {
    uVar12 = 0x80070057;
    local_258[0] = L'\0';
  }
  *(uint *)(param_1 + 8) = uVar12;
  local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_3b0 = L"CVssIOCTLChannel::Open";
  local_3a8 = L"INCICHLH";
  local_3a0 = 0xe9;
  local_39c = 10;
  local_398 = 0xff;
  local_318 = 0x1000000;
  memset(local_390,0,0x78);
  if ((int)uVar12 < 0) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_308,(CVssDebugInfo *)&local_3b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
              (param_1,uVar9,uVar12,L"StringCchCopyN");
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_3b8);
  if (uVar13 * 2 < 0x208) {
    local_258[uVar13] = L'\0';
    _Var14 = 0xffffffff;
    pvVar8 = CreateFileW(local_258,0x80000000,3,(LPSECURITY_ATTRIBUTES)0x0,3,0x80,
                         (HANDLE)0xffffffffffffffff);
    *(HANDLE *)this = pvVar8;
    if (pvVar8 != (HANDLE)0xffffffffffffffff) {
      local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_3b0 = L"CVssIOCTLChannel::Open";
      local_3a8 = L"INCICHLH";
      local_3a0 = 300;
      local_39c = 10;
      local_398 = 0xff;
      local_318 = 0x1000000;
      memset(local_390,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (param_1,&local_3b8,L"The object \'%s\'. was opened under the device handle 0x%08lx"
                 ,local_258);
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(this + 0x60),
                 (ushort *)local_258);
      return *(long *)(param_1 + 8);
    }
    *(undefined8 *)this = 0;
    DVar5 = GetLastError();
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_308,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0x10e,2,_Var14);
    DVar3 = DVar5 & 0xffff | 0x80070000;
    if ((int)DVar5 < 1) {
      DVar3 = DVar5;
    }
    CVssFunctionTracer::
    _TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ
              (param_1,uVar9,DVar3,0x80042306);
    pcVar2 = (code *)swi(3);
    lVar6 = (*pcVar2)();
    return lVar6;
  }
  __report_rangecheckfailure();
  pcVar2 = (code *)swi(3);
  lVar6 = (*pcVar2)();
  return lVar6;
}


