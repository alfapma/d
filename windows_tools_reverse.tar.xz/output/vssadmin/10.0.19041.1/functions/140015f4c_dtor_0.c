/*
 * Function : dtor$0
 * Address  : 0x140015f4c
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)(param_2 + 0x40));
  return;
}


