/*
 * Function : ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@I@Z
 * Address  : 0x14000f198
 * Size     : 520 bytes (113 instructions)
 * Prototype: basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@I@Z(CVssResource * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> __cdecl CVssResource::LoadStringW(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> __cdecl CVssResource::LoadStringW(unsigned int)
   __ptr64 */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
CVssResource::
_LoadStringW_CVssResource__QEAA_AV__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__I_Z
          (CVssResource *this,uint param_1)

{
  int iVar1;
  WCHAR *pWVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined4 in_register_00000014;
  UINT in_R8D;
  undefined1 auStackY_158 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffed8;
  CVssDebugInfo local_108 [168];
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  local_60 [8];
  WCHAR local_58;
  undefined6 uStack_56;
  undefined8 local_48;
  ulonglong local_40;
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_158;
  if (`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
      ::__l2::hMod == (HINSTANCE__ *)0x0) {
    `public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
    ::__l2::hMod = LoadLibraryExW(L"vsstrace.dll",(HANDLE)0x0,2);
    if (`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
        ::__l2::hMod == (HMODULE)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_108,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                         (ushort *)L"TRCTRCC",(ushort *)L"CVssResource::LoadStringW",0x4c,0xb,
                         in_stack_fffffffffffffed8);
      GetLastError();
      CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
                (uVar3,0x28,L"VssLoadString",L"Error loading VSS.DLL [0x%08lx]");
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)uVar3);
    }
  }
  local_40 = 7;
  local_48 = 0;
  local_58 = L'\0';
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
            (local_60,0x401,0);
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
  }
  for (lVar4 = 0x401; lVar4 != 0; lVar4 = lVar4 + -1) {
    *pWVar2 = L'\0';
    pWVar2 = pWVar2 + 1;
  }
  local_48 = 0x401;
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
  }
  pWVar2[0x401] = L'\0';
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (LPWSTR)CONCAT62(uStack_56,local_58);
  }
  iVar1 = LoadStringW(`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
                      ::__l2::hMod,in_R8D,pWVar2,0x401);
  if (iVar1 != 0) {
    pWVar2 = &local_58;
    if (7 < local_40) {
      pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
    }
    std::
    basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
    ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
              ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                *)CONCAT44(in_register_00000014,param_1),(ushort *)pWVar2);
    if (7 < local_40) {
      operator_delete__((void *)CONCAT62(uStack_56,local_58));
    }
    return (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
            *)CONCAT44(in_register_00000014,param_1);
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_108,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                     (ushort *)L"TRCTRCC",(ushort *)L"CVssResource::LoadStringW",0x61,0xb,
                     in_stack_fffffffffffffed8);
  GetLastError();
  CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
            (uVar3,0x28,L"VssLoadString",
             L"Error loading VSS.DLL resource with ID = 0x%08lx [0x%08lx]");
                    /* WARNING: Subroutine does not return */
  InternalThrow((long)uVar3);
}


