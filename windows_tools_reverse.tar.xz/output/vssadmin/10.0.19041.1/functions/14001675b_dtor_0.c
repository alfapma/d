/*
 * Function : dtor$0
 * Address  : 0x14001675b
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `std::_String_base::_Xlen'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __1__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_XZ
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)
             (param_2 + 0x28));
  return;
}


