/*
 * Function : ??_Etype_info@@UEAAPEAXI@Z
 * Address  : 0x140014420
 * Size     : 48 bytes (15 instructions)
 * Prototype: void * ??_Etype_info@@UEAAPEAXI@Z(type_info * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int)
   __ptr64 */

void * __thiscall type_info::___Etype_info__UEAAPEAXI_Z(type_info *this,uint param_1)

{
  type_info::~type_info(this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


