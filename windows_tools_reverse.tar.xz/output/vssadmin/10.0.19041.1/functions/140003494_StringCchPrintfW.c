/*
 * Function : StringCchPrintfW
 * Address  : 0x140003494
 * Size     : 125 bytes (44 instructions)
 * Prototype: long StringCchPrintfW(ushort * param_1, __uint64 param_2, ushort * param_3, ...)
 * CC       : __cdecl
 * Comment  : long __cdecl StringCchPrintfW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64,...)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* long __cdecl StringCchPrintfW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64,...) */

long __cdecl StringCchPrintfW(ushort *param_1,__uint64 param_2,ushort *param_3,...)

{
  ulonglong _Count;
  int iVar1;
  int iVar2;
  undefined8 in_R9;
  undefined8 local_res20;
  
  iVar2 = 0;
  if (0x7ffffffe < param_2 - 1) {
    iVar2 = -0x7ff8ffa9;
  }
  if (iVar2 < 0) {
    if (param_2 != 0) {
      *param_1 = 0;
    }
  }
  else {
    _Count = param_2 - 1;
    iVar2 = 0;
    local_res20 = in_R9;
    iVar1 = _vsnwprintf((wchar_t *)param_1,_Count,(wchar_t *)param_3,(va_list)&local_res20);
    if ((iVar1 < 0) || (_Count < (ulonglong)(longlong)iVar1)) {
      param_1[_Count] = 0;
      iVar2 = -0x7ff8ff86;
    }
    else if ((longlong)iVar1 == _Count) {
      param_1[_Count] = 0;
    }
  }
  return iVar2;
}


