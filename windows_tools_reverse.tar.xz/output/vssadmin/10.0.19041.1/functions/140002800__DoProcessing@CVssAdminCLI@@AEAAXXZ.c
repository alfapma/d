/*
 * Function : ?DoProcessing@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140002800
 * Size     : 466 bytes (122 instructions)
 * Prototype: void ?DoProcessing@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DoProcessing(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::DoProcessing(void) __ptr64 */

void __thiscall CVssAdminCLI::_DoProcessing_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffeb8;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_128 = L"CVssAdminCLI::DoProcessing";
  local_120 = L"ADMVADMC";
  local_118 = 0x29f;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  iVar1 = *(int *)(this + 0x60);
  if (iVar1 < 0xc) {
    if (iVar1 < 10) {
      if (iVar1 < 8) {
        if (iVar1 < 6) {
          if (iVar1 < 0) {
LAB_140002990:
            uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                              ((CVssDebugInfo *)&local_130,
                               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                               (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::DoProcessing",0x2e1,1
                               ,in_stack_fffffffffffffeb8);
                    /* WARNING: Subroutine does not return */
            CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                      (local_88,uVar2,0x8000ffff,L"Invalid command type: %d",
                       *(undefined4 *)(this + 0x58));
          }
          if (iVar1 < 2) {
            _AddDiffArea_CVssAdminCLI__AEAAXXZ(this);
          }
          else if (iVar1 < 4) {
            _CreateSnapshot_CVssAdminCLI__AEAAXXZ(this);
          }
          else {
            _DeleteSnapshots_CVssAdminCLI__AEAAXXZ(this);
          }
        }
        else {
          _DeleteDiffAreas_CVssAdminCLI__AEAAXXZ(this);
        }
      }
      else if (iVar1 == 8) {
        _ExposeSnapshot_CVssAdminCLI__AEAAXXZ(this);
      }
      else {
        if (iVar1 != 9) goto LAB_140002990;
        _ListProviders_CVssAdminCLI__AEAAXXZ(this);
      }
    }
    else {
      _ListSnapshots_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  else if (iVar1 < 0x13) {
    if (iVar1 < 0x11) {
      if (iVar1 < 0xe) {
        _ListDiffAreas_CVssAdminCLI__AEAAXXZ(this);
      }
      else if (iVar1 < 0x10) {
        _ListVolumes_CVssAdminCLI__AEAAXXZ(this);
      }
      else {
        _ListWriters_CVssAdminCLI__AEAAXXZ(this);
      }
    }
    else {
      _ResizeDiffArea_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  else if (iVar1 < 0x15) {
    _RevertSnapshot_CVssAdminCLI__AEAAXXZ(this);
  }
  else {
    if (iVar1 != 0x15) goto LAB_140002990;
    _QueryReverts_CVssAdminCLI__AEAAXXZ(this);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}


