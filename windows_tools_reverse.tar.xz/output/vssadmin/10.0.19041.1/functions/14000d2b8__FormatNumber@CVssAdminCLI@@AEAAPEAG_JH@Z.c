/*
 * Function : ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z
 * Address  : 0x14000d2b8
 * Size     : 609 bytes (136 instructions)
 * Prototype: ushort * ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z(CVssAdminCLI * this, __int64 param_1, int param_2)
 * CC       : __thiscall
 * Comment  : private: unsigned short * __ptr64 __cdecl CVssAdminCLI::FormatNumber(__int64,int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::FormatNumber(__int64,int) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z
          (CVssAdminCLI *this,__int64 param_1,int param_2)

{
  HRESULT HVar1;
  ushort *puVar2;
  undefined8 uVar3;
  undefined1 auStackY_2d8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffd58;
  ushort *local_298;
  wchar_t **local_290;
  wchar_t *local_288;
  wchar_t *local_280;
  wchar_t *local_278;
  undefined4 local_270;
  undefined4 local_26c;
  undefined4 local_268;
  undefined1 local_260 [120];
  undefined4 local_1e8;
  undefined8 local_1e0;
  CVssFunctionTracer local_1d8 [8];
  HRESULT local_1d0;
  CVssDebugInfo local_168 [176];
  WCHAR local_b8 [64];
  ulonglong local_38;
  
  local_1e0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_2d8;
  local_288 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_280 = L"CVssAdminCLI::FormatNumber";
  local_278 = L"ADMUTILC";
  local_270 = 0x24f;
  local_26c = 7;
  local_268 = 0xff;
  local_1e8 = 0x1000000;
  memset(local_260,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_1d8);
  local_298 = (ushort *)0x0;
  memset(local_b8,0,0x80);
  if (param_1 < 0) {
    puVar2 = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x40002712);
    if (puVar2 == (ushort *)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_288,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::FormatNumber",0x25a,7,
                         in_stack_fffffffffffffd58);
      GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_1d8,uVar3,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_1d8);
    local_298 = puVar2;
  }
  else {
    if (param_2 == 0) {
      StringCchPrintfW((ushort *)local_b8,0x40,(ushort *)L"%I64d",param_1);
    }
    else {
      HVar1 = StrFormatByteSizeEx(param_1,1,local_b8,0x40);
      local_288 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_280 = L"CVssAdminCLI::FormatNumber";
      local_278 = L"ADMUTILC";
      local_270 = 0x269;
      local_26c = 7;
      local_268 = 0xff;
      local_1e8 = 0x1000000;
      local_1d0 = HVar1;
      memset(local_260,0,0x78);
      local_290 = &local_288;
      if (HVar1 < 0) {
        uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                          (local_168,(CVssDebugInfo *)&local_288);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                  (local_1d8,uVar3,HVar1,L"StrFormatByteSizeEx");
      }
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_288);
    }
    VssSafeDuplicateStr(local_1d8,&local_298,(ushort *)local_b8);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_1d8);
  }
  return local_298;
}


