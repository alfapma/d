/*
 * Function : dtor$3
 * Address  : 0x1400162a1
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$3(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssFunctionTracer::LogError'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)(param_2 + 0x78));
  return;
}


