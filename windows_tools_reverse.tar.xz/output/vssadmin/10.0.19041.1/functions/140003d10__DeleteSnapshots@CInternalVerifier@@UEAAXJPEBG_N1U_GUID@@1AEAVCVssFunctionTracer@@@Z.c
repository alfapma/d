/*
 * Function : ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z
 * Address  : 0x140003d10
 * Size     : 494 bytes (106 instructions)
 * Prototype: void ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CInternalVerifier::DeleteSnapshots(long,unsigned short const * __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CInternalVerifier::DeleteSnapshots(long,unsigned short const *
   __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::
_DeleteSnapshots_CInternalVerifier__UEAAXJPEBG_N1U_GUID__1AEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,long param_1,ushort *param_2,bool param_3,bool param_4,
          _GUID *param_5,bool param_6,CVssFunctionTracer *param_7)

{
  longlong lVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_5->Data1;
  lVar1._4_2_ = param_5->Data2;
  lVar1._6_2_ = param_5->Data3;
  if ((lVar1 != 0) || (*(longlong *)param_5->Data4 != 0)) {
    if ((param_2 == (ushort *)0x0) && (((param_1 == -1 && (!param_4)) && (!param_3)))) {
      return;
    }
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xa2,7
                       ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options");
  }
  uVar3 = 0xffffffffffffffff;
  if (param_2 == (ushort *)0x0) {
    if (param_1 != -1) goto LAB_140003e73;
    if (!param_3) {
      if (!param_4) goto LAB_140003e73;
      goto LAB_140003d6f;
    }
  }
  else {
LAB_140003d6f:
    if ((param_1 != -1) && (param_2 == (ushort *)0x0)) goto LAB_140003e73;
  }
  if ((!param_4) || (param_2 != (ushort *)0x0)) {
    if (((param_1 != -1) && (param_3)) || ((param_3 && (param_4)))) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xaf,
                         7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options:");
    }
    if (param_2 != (ushort *)0x0) {
      do {
        uVar3 = uVar3 + 1;
      } while (param_2[uVar3] != 0);
      if (0x31 < uVar3) {
        uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          (local_b0,(ushort *)
                                    L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                           (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",
                           0xb5,7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (param_7,uVar2,0x1004,L"CVssAdminCLI::DeleteSnapshots: invalid volume name");
      }
    }
    return;
  }
LAB_140003e73:
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xa9,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_7,uVar2,0x1007,L"CVssAdminCLI::DeleteSnapshots: Required option missing");
}


