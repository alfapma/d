/*
 * Function : ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ
 * Address  : 0x14000d524
 * Size     : 603 bytes (131 instructions)
 * Prototype: void ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64 */

void __thiscall
CVssAdminCLI::_OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(CVssAdminCLI *this,long param_1,...)

{
  DWORD DVar1;
  undefined8 uVar2;
  undefined8 in_R8;
  undefined8 in_R9;
  undefined8 local_res18;
  undefined8 local_res20;
  ushort **lpBuffer;
  undefined4 uVar3;
  _VSSDBG_SEV_ENUM _Var4;
  va_list *Arguments;
  ushort *local_178;
  va_list local_170;
  undefined8 local_168;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  CVssFunctionTracer local_a8 [120];
  
  local_168 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_150 = L"CVssAdminCLI::OutputErrorMsg";
  local_148 = L"ADMUTILC";
  local_140 = 0x284;
  local_13c = 7;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  local_res18 = in_R8;
  local_res20 = in_R9;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  local_170 = (va_list)&local_res18;
  DVar1 = FormatMessageW(0x900,(LPCVOID)0x0,0x40002714,0x400,(LPWSTR)&local_178,0,(va_list *)0x0);
  if (DVar1 != 0) {
    _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_178);
    LocalFree(local_178);
  }
  DVar1 = 0x1100;
  if (0x4000270f < param_1) {
    DVar1 = 0x900;
  }
  DVar1 = FormatMessageW(DVar1,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_178,0,&local_170);
  if (DVar1 == 0) {
    Arguments = &local_170;
    lpBuffer = &local_178;
    DVar1 = FormatMessageW(0x1100,(LPCVOID)0x0,param_1,0x400,(LPWSTR)lpBuffer,0,Arguments);
    _Var4 = (_VSSDBG_SEV_ENUM)Arguments;
    uVar3 = (undefined4)((ulonglong)lpBuffer >> 0x20);
    if (DVar1 == 0) {
      GetLastError();
      wprintf(L"Unable to format message for id %x - %d\n");
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_158,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::OutputErrorMsg",0x2bd,7,
                         _Var4);
      DVar1 = GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_a8,uVar2,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx",
                 CONCAT44(uVar3,param_1),DVar1);
    }
  }
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" ");
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_178);
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" \r\n");
  LocalFree(local_178);
  local_170 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}


