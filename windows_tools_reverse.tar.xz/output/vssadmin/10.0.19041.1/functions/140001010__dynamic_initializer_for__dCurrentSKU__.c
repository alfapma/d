/*
 * Function : `dynamic_initializer_for_'dCurrentSKU''
 * Address  : 0x140001010
 * Size     : 35 bytes (8 instructions)
 * Prototype: undefined `dynamic_initializer_for_'dCurrentSKU''(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void _dynamic_initializer_for__dCurrentSKU__(void)

{
  if (CVssSKU::ms_bInitialized == 0) {
    CVssSKU::_Initialize_CVssSKU__CAXXZ();
  }
  dCurrentSKU = CVssSKU::ms_eSKU;
  return;
}


