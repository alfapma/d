/*
 * Function : InternalThrow
 * Address  : 0x14000f170
 * Size     : 33 bytes (6 instructions)
 * Prototype: void InternalThrow(long param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl InternalThrow(long)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl InternalThrow(long) */

void __cdecl InternalThrow(long param_1)

{
  undefined4 local_res8 [8];
  
  local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
}


