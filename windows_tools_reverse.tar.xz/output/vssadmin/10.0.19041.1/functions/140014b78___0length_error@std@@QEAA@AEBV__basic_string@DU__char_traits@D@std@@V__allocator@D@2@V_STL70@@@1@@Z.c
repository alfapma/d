/*
 * Function : ??0length_error@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@@Z
 * Address  : 0x140014b78
 * Size     : 113 bytes (31 instructions)
 * Prototype: undefined ??0length_error@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@@Z(length_error * this, basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::length_error::length_error(class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::length_error::length_error(class std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64) __ptr64 */

length_error * __thiscall
std::length_error::
__0length_error_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1__Z
          (length_error *this,
          basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *param_1)

{
  exception::__0exception__QEAA_XZ((exception *)this);
  *(undefined ***)this = &logic_error::_vftable_;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             false,0);
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)param_1,0,0xffffffffffffffff);
  *(undefined ***)this = &_vftable_;
  return this;
}


