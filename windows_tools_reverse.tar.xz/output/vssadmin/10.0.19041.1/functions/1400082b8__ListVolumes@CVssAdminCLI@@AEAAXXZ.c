/*
 * Function : ?ListVolumes@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x1400082b8
 * Size     : 1056 bytes (231 instructions)
 * Prototype: void ?ListVolumes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ListVolumes(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListVolumes(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListVolumes_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  uchar auVar1 [8];
  LPVOID pv;
  long lVar2;
  ushort *puVar3;
  undefined8 uVar4;
  CVssAdminCLI *this_00;
  undefined1 auStackY_228 [32];
  _VSSDBG_SEV_ENUM _Var5;
  longlong **pplVar6;
  undefined1 local_1e8 [8];
  longlong *local_1e0;
  longlong *local_1d8 [2];
  _GUID local_1c8;
  undefined1 local_1b8 [16];
  wchar_t *local_1a8;
  wchar_t *local_1a0;
  wchar_t *local_198;
  undefined4 local_190;
  undefined4 local_18c;
  undefined4 local_188;
  undefined1 local_180 [120];
  undefined4 local_108;
  CVssFunctionTracer local_f8 [8];
  int local_f0;
  undefined8 local_88;
  undefined1 local_80 [8];
  uchar local_78 [8];
  LPVOID local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_88 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_228;
  local_1a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1a0 = L"CVssAdminCLI::ListVolumes";
  local_198 = L"ADMPROCC";
  local_190 = 0x4ce;
  local_18c = 7;
  local_188 = 0xff;
  local_108 = 0x1000000;
  memset(local_180,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_f8,&local_1a8);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar2 = 0x1d;
  }
  else {
    this_00 = this;
    puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar2 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(this_00,puVar3);
  }
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  local_1d8[0] = (longlong *)0x0;
  local_1c8 = (_GUID)_GUID_fa7df749_66e7_4986_a27f_e2f04ae53772;
  local_1b8 = (undefined1  [16])_GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
  local_1a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1a0 = L"CVssAdminCLI::ListVolumes";
  local_198 = L"ADMPROCC";
  local_190 = 0x4df;
  local_18c = 7;
  local_188 = 0xff;
  local_108 = 0x1000000;
  memset(local_180,0,0x78);
  pplVar6 = local_1d8;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_f8,&local_1a8,local_1b8,L"VssSnapshotMgmt");
  auVar1 = local_48.Data4;
  if (local_f0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1a8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListVolumes",0x4e6,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
  }
  local_1e0 = (longlong *)0x0;
  local_1c8.Data4[0] = local_48.Data4[0];
  local_1c8.Data4[1] = local_48.Data4[1];
  local_1c8.Data4[2] = local_48.Data4[2];
  local_1c8.Data4[3] = local_48.Data4[3];
  local_1c8.Data1 = local_48.Data1;
  local_1c8.Data2 = local_48.Data2;
  local_1c8.Data3 = local_48.Data3;
  local_1c8.Data4[4] = local_48.Data4[4];
  local_1c8.Data4[5] = local_48.Data4[5];
  local_1c8.Data4[6] = local_48.Data4[6];
  local_1c8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar1;
  local_f0 = (**(code **)(*local_1d8[0] + 0x20))(local_1d8[0],&local_1c8,lVar2,&local_1e0);
  if (local_f0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1a8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListVolumes",0x4f1,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
  }
  if (local_f0 != 1) {
    local_f0 = (**(code **)(*local_1e0 + 0x18))(local_1e0,1,local_80,local_1e8);
    _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
    auVar1 = local_78;
    pv = local_70;
    while( true ) {
      if (local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListVolumes",0x504,7,_Var5);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) break;
      local_1c8.Data4[0] = auVar1[0];
      local_1c8.Data4[1] = auVar1[1];
      local_1c8.Data4[2] = auVar1[2];
      local_1c8.Data4[3] = auVar1[3];
      local_1c8.Data4[4] = auVar1[4];
      local_1c8.Data4[5] = auVar1[5];
      local_1c8.Data4[6] = auVar1[6];
      local_1c8.Data4[7] = auVar1[7];
      local_1c8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_1b8._8_8_ = pv;
      local_1b8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_78 = auVar1;
      local_70 = pv;
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002759,pv,auVar1);
      if (pv != (LPVOID)0x0) {
        CoTaskMemFree(pv);
      }
      local_1b8 = ZEXT816(0x140017068);
      if (auVar1 != (uchar  [8])0x0) {
        CoTaskMemFree((LPVOID)auVar1);
      }
      local_1c8 = (_GUID)ZEXT816(0x140017068);
      local_f0 = (**(code **)(*local_1e0 + 0x18))(local_1e0,1,local_80,local_1e8);
      _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
      auVar1 = local_78;
      pv = local_70;
    }
    *(undefined4 *)(this + 0x48) = 0;
    if (local_1e0 != (longlong *)0x0) {
      (**(code **)(*local_1e0 + 0x10))();
    }
    if (local_1d8[0] != (longlong *)0x0) {
      (**(code **)(*local_1d8[0] + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_f8);
    return;
  }
  uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a8,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListVolumes",0x4f5,7,
                     (_VSSDBG_SEV_ENUM)pplVar6);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_f8,uVar4,1,L"CVssAdminCLI::ListVolumes: No volumes found that satisfy the query")
  ;
}


