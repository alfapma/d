/*
 * Function : ??1CVssAdmSnapshotSets@@QEAA@XZ
 * Address  : 0x140004e98
 * Size     : 261 bytes (63 instructions)
 * Prototype: void ??1CVssAdmSnapshotSets@@QEAA@XZ(CVssAdmSnapshotSets * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAdmSnapshotSets::~CVssAdmSnapshotSets(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssAdmSnapshotSets::~CVssAdmSnapshotSets(void) __ptr64 */

void __thiscall CVssAdmSnapshotSets::__1CVssAdmSnapshotSets__QEAA_XZ(CVssAdmSnapshotSets *this)

{
  wchar_t **ppwVar1;
  ulonglong uVar2;
  longlong lVar3;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_10c = 7;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_88 = 0x1000000;
  local_120 = L"CVssAdmSnapshotSets::~CVssAdmSnapshotSets";
  lVar3 = 0;
  local_118 = L"ADMPROCC";
  local_110 = 0xff;
  local_108 = 0xff;
  memset(local_100,0,0x78);
  ppwVar1 = &local_128;
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78);
  if (0 < *(int *)(this + 0x10)) {
    uVar2 = (ulonglong)*(uint *)(this + 0x10);
    do {
      if (*(CVssAdmSnapshotSetEntry **)(lVar3 + *(longlong *)(this + 8)) !=
          (CVssAdmSnapshotSetEntry *)0x0) {
        CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
                  (*(CVssAdmSnapshotSetEntry **)(lVar3 + *(longlong *)(this + 8)),(uint)ppwVar1);
      }
      lVar3 = lVar3 + 8;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  if (*(void **)this != (void *)0x0) {
    free(*(void **)this);
    *(undefined8 *)this = 0;
  }
  if (*(void **)(this + 8) != (void *)0x0) {
    free(*(void **)(this + 8));
    *(undefined8 *)(this + 8) = 0;
  }
  *(undefined4 *)(this + 0x10) = 0;
  return;
}


