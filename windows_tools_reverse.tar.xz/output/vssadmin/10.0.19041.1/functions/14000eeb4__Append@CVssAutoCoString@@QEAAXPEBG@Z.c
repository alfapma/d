/*
 * Function : ?Append@CVssAutoCoString@@QEAAXPEBG@Z
 * Address  : 0x14000eeb4
 * Size     : 530 bytes (117 instructions)
 * Prototype: void ?Append@CVssAutoCoString@@QEAAXPEBG@Z(CVssAutoCoString * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssAutoCoString::Append(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssAutoCoString::Append(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z(CVssAutoCoString *this,ushort *param_1)

{
  longlong lVar1;
  LPVOID pvVar2;
  undefined8 uVar3;
  longlong lVar4;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdf8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined4 local_1d0;
  undefined1 local_1c8 [120];
  undefined4 local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [8];
  long local_90;
  
  local_148 = L"base\\stor\\vss\\inc\\vs_str.hxx";
  local_140 = L"CVssAutoCoString::Append";
  local_138 = L"INCSTRH";
  local_130 = 0x2b9;
  local_12c = 0xb;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  lVar1 = -1;
  lVar4 = -1;
  do {
    lVar4 = lVar4 + 1;
  } while (*(short *)(*(longlong *)this + lVar4 * 2) != 0);
  do {
    lVar1 = lVar1 + 1;
  } while (param_1[lVar1] != 0);
  local_1f0 = L"base\\stor\\vss\\inc\\vs_str.hxx";
  local_1e8 = L"CVssAutoCoString::Reallocate";
  local_1e0 = L"INCSTRH";
  local_1d8 = 0x2b1;
  local_1d4 = 0xb;
  local_1d0 = 0xff;
  local_150 = 0x1000000;
  memset(local_1c8,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
            ((CVssFunctionTracer *)&local_148,&local_1f0);
  pvVar2 = CoTaskMemRealloc(*(LPVOID *)this,(longlong)((int)(lVar4 + lVar1) + 1) * 2);
  if (pvVar2 != (LPVOID)0x0) {
    *(LPVOID *)this = pvVar2;
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)&local_148);
    local_90 = StringCchCatW(*(ushort **)this,lVar4 + lVar1 + 1,param_1);
    if (-1 < local_90) {
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
      return;
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
               (ushort *)L"INCSTRH",(ushort *)L"CVssAutoCoString::Append",0x2c1,0xb,
               in_stack_fffffffffffffdf8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1f0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
                     (ushort *)L"INCSTRH",(ushort *)L"VssReallocString",0x85,0xb,
                     in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            ((CVssFunctionTracer *)&local_148,uVar3,0x8007000e,L"Memory allocation error");
}


