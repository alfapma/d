/*
 * Function : ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z
 * Address  : 0x140001908
 * Size     : 957 bytes (203 instructions)
 * Prototype: int ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetProviderIdByName(unsigned short const * __ptr64,struct _GUID * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: int __cdecl CVssAdminCLI::GetProviderIdByName(unsigned short const * __ptr64,struct
   _GUID * __ptr64) __ptr64 */

int __thiscall
CVssAdminCLI::_GetProviderIdByName_CVssAdminCLI__AEAAHPEBGPEAU_GUID___Z
          (CVssAdminCLI *this,ushort *param_1,_GUID *param_2)

{
  int iVar1;
  undefined1 auStackY_268 [32];
  longlong **pplVar2;
  longlong *local_220;
  undefined1 local_218 [16];
  GUID local_208;
  GUID local_1f8;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  wchar_t *local_1d8;
  undefined4 local_1d0;
  undefined4 local_1cc;
  undefined4 local_1c8;
  undefined1 local_1c0 [120];
  undefined4 local_148;
  CVssFunctionTracer local_138 [8];
  int local_130;
  undefined8 local_c8;
  undefined1 local_b8 [8];
  ulong local_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  wchar_t *local_a0;
  LPVOID local_90;
  ulonglong local_28;
  
  local_c8 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_268;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e0 = L"CVssAdminCLI::GetProviderIdByName";
  local_1d8 = L"ADMVADMC";
  local_1d0 = 0x14e;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_138);
  local_220 = (longlong *)0x0;
  local_208 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_1f8 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e0 = L"CVssAdminCLI::GetProviderIdByName";
  local_1d8 = L"ADMVADMC";
  local_1d0 = 0x153;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  pplVar2 = &local_220;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_138,&local_1e8,&local_1f8,L"Coordinator");
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1e8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::GetProviderIdByName",0x15a,7,(_VSSDBG_SEV_ENUM)pplVar2);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_1f8 = (GUID)ZEXT816(0);
  local_130 = (**(code **)(*local_220 + 0x50))(local_220,&local_1f8,1,4);
  if (-1 < local_130) {
    while( true ) {
      local_130 = (**(code **)(lRam0000000000000000 + 0x18))(0,1,local_b8,local_218);
      if (local_130 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1e8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                   (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderIdByName",0x16d,7,
                   (_VSSDBG_SEV_ENUM)pplVar2);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
      }
      if (local_130 == 1) break;
      CoTaskMemFree(local_90);
      local_90 = (LPVOID)0x0;
      iVar1 = _wcsicmp(local_a0,(wchar_t *)param_1);
      if (iVar1 == 0) {
        CoTaskMemFree(local_a0);
        local_a0 = (wchar_t *)0x0;
        param_2->Data1 = local_b0;
        param_2->Data2 = (undefined2)uStack_ac;
        param_2->Data3 = uStack_ac._2_2_;
        *(undefined4 *)param_2->Data4 = uStack_a8;
        *(undefined4 *)(param_2->Data4 + 4) = uStack_a4;
        if (false) {
          (**(code **)(lRam0000000000000000 + 0x10))();
        }
        if (local_220 != (longlong *)0x0) {
          (**(code **)(*local_220 + 0x10))();
        }
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
        return 1;
      }
      CoTaskMemFree(local_a0);
      local_a0 = (wchar_t *)0x0;
    }
    param_2->Data1 = 0;
    param_2->Data2 = 0;
    param_2->Data3 = 0;
    param_2->Data4[0] = '\0';
    param_2->Data4[1] = '\0';
    param_2->Data4[2] = '\0';
    param_2->Data4[3] = '\0';
    param_2->Data4[4] = '\0';
    param_2->Data4[5] = '\0';
    param_2->Data4[6] = '\0';
    param_2->Data4[7] = '\0';
    if (false) {
      (**(code **)(lRam0000000000000000 + 0x10))();
    }
    if (local_220 != (longlong *)0x0) {
      (**(code **)(*local_220 + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
                    /* WARNING: Read-only address (ram,0x000140019060) is written */
                    /* WARNING: Read-only address (ram,0x000140019070) is written */
    return 0;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1e8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::GetProviderIdByName",0x162,7,(_VSSDBG_SEV_ENUM)pplVar2);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
}


