/*
 * Function : ??1CComBSTR@ATL@@QEAA@XZ
 * Address  : 0x14000b80c
 * Size     : 10 bytes (2 instructions)
 * Prototype: void ??1CComBSTR@ATL@@QEAA@XZ(CComBSTR * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64 */

void __thiscall ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ(CComBSTR *this)

{
                    /* WARNING: Could not recover jumptable at 0x00014000b80f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  Ordinal_6(*(undefined8 *)this);
  return;
}


