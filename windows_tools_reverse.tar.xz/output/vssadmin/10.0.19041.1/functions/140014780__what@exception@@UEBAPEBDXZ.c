/*
 * Function : ?what@exception@@UEBAPEBDXZ
 * Address  : 0x140014780
 * Size     : 6 bytes (1 instructions)
 * Prototype: char * ?what@exception@@UEBAPEBDXZ(exception * this)
 * CC       : __thiscall
 * Comment  : public: virtual char const * __ptr64 __cdecl exception::what(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual char const * __ptr64 __cdecl exception::what(void)const __ptr64 */

char * __thiscall exception::_what_exception__UEBAPEBDXZ(exception *this)

{
  char *pcVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140014780. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pcVar1 = what(this);
  return pcVar1;
}


