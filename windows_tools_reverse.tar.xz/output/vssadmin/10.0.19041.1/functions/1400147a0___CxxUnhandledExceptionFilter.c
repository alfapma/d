/*
 * Function : __CxxUnhandledExceptionFilter
 * Address  : 0x1400147a0
 * Size     : 56 bytes (16 instructions)
 * Prototype: long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS * param_1)
 * CC       : __cdecl
 * Comment  : long __cdecl __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* long __cdecl __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS * __ptr64) */

long __cdecl __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS *param_1)

{
  int iVar1;
  PEXCEPTION_RECORD pEVar2;
  
  pEVar2 = param_1->ExceptionRecord;
  if (((pEVar2->ExceptionCode == 0xe06d7363) && (pEVar2->NumberParameters == 4)) &&
     ((iVar1 = (int)pEVar2->ExceptionInformation[0], iVar1 + 0xe66cfae0U < 3 || (iVar1 == 0x1994000)
      ))) {
                    /* WARNING: Subroutine does not return */
    terminate();
  }
  return 0;
}


