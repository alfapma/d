/*
 * Function : ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x1400086e4
 * Size     : 647 bytes (154 instructions)
 * Prototype: void ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ResizeDiffArea(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::ResizeDiffArea(void) __ptr64 */

void __thiscall CVssAdminCLI::_ResizeDiffArea_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  ushort *puVar2;
  ushort *puVar3;
  CVssAdminCLI *this_00;
  EVssAdmOption EVar4;
  undefined1 auStackY_1c8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe68;
  IUnknown *local_188 [2];
  _GUID local_178;
  undefined8 local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  undefined4 local_148;
  undefined4 local_144;
  undefined4 local_140;
  undefined1 local_138 [120];
  undefined4 local_c0;
  CVssFunctionTracer local_b8 [8];
  ULONG local_b0;
  _GUID local_48;
  ulonglong local_38;
  
  local_168 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1c8;
  local_160 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_158 = L"CVssAdminCLI::ResizeDiffArea";
  local_150 = L"ADMPROCC";
  local_148 = 0x517;
  local_144 = 7;
  local_140 = 0xff;
  local_c0 = 0x1000000;
  memset(local_138,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_b8,&local_160);
  local_178.Data1 = 0;
  local_178.Data2 = 0;
  local_178.Data3 = 0;
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  puVar2 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  EVar4 = 7;
  puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  this_00 = this;
  iVar1 = _GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
                    (this,EVar4,(__int64 *)&local_178);
  if (iVar1 == 0) {
    _GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z(this,5,(__int64 *)&local_178,1);
  }
  else if (0 < (longlong)local_178._0_8_) {
    _GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(this_00,puVar2);
  }
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  (**(code **)(**(longlong **)this + 0x30))(*(longlong **)this,&local_178,puVar2,puVar3);
  local_188[0] = (IUnknown *)0x0;
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_178,local_188);
  local_b0 = (*local_188[0]->lpVtbl[1].AddRef)(local_188[0]);
  if ((int)local_b0 < 0) {
    if (local_b0 != 0x80042308) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_160,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ResizeDiffArea",0x53e,7,in_stack_fffffffffffffe68);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_b8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_b8);
    }
    _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
  }
  else {
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002750);
    *(undefined4 *)(this + 0x48) = 0;
  }
  if (local_188[0] != (IUnknown *)0x0) {
    (*local_188[0]->lpVtbl->Release)();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_b8);
  return;
}


