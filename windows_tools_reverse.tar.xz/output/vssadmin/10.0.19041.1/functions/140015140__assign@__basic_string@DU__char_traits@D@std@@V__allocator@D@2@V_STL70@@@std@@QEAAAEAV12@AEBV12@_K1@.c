/*
 * Function : ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z
 * Address  : 0x140015140
 * Size     : 246 bytes (70 instructions)
 * Prototype: basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(class
   std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>
   const & __ptr64,unsigned __int64,unsigned __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
          *param_1,__uint64 param_2,__uint64 param_3)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar1;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *_Dst;
  ulonglong _MaxCount;
  
  if (*(ulonglong *)(param_1 + 0x18) < param_2) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xran__String_base_std__SAXXZ();
  }
  _MaxCount = *(ulonglong *)(param_1 + 0x18) - param_2;
  if (param_3 < _MaxCount) {
    _MaxCount = param_3;
  }
  if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)param_1) {
    _erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
              (this,_MaxCount + param_2,0xffffffffffffffff);
    _erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
              (this,0,param_2);
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
  if (_MaxCount == 0xffffffffffffffff) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xlen__String_base_std__SAXXZ();
  }
  if (*(ulonglong *)(this + 0x20) < _MaxCount) {
    __Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
              (this,_MaxCount,*(__uint64 *)(this + 0x18));
  }
  else {
    if (_MaxCount != 0) goto LAB_1400151d2;
    *(undefined8 *)(this + 0x18) = 0;
    pbVar1 = this + 8;
    if (0xf < *(ulonglong *)(this + 0x20)) {
      pbVar1 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
    }
    *pbVar1 = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  }
  if (_MaxCount == 0) {
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
LAB_1400151d2:
  pbVar2 = param_1 + 8;
  if (0xf < *(ulonglong *)(param_1 + 0x20)) {
    pbVar2 = *(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
               **)pbVar2;
  }
  pbVar1 = this + 8;
  _Dst = pbVar1;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    _Dst = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
  }
  memcpy_s(_Dst,*(ulonglong *)(this + 0x20),pbVar2 + param_2,_MaxCount);
  *(ulonglong *)(this + 0x18) = _MaxCount;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar1 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
  }
  pbVar1[_MaxCount] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
         )this;
}


