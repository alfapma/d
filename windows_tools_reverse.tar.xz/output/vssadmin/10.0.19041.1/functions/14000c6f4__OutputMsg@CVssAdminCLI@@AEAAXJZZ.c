/*
 * Function : ?OutputMsg@CVssAdminCLI@@AEAAXJZZ
 * Address  : 0x14000c6f4
 * Size     : 369 bytes (79 instructions)
 * Prototype: void ?OutputMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::OutputMsg(long,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::OutputMsg(long,...) __ptr64 */

void __thiscall CVssAdminCLI::_OutputMsg_CVssAdminCLI__AEAAXJZZ(CVssAdminCLI *this,long param_1,...)

{
  DWORD DVar1;
  undefined8 in_R8;
  undefined8 in_R9;
  undefined8 local_res18;
  undefined8 local_res20;
  ushort *local_148;
  va_list local_140;
  undefined8 local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_138 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_128 = L"CVssAdminCLI::OutputMsg";
  local_120 = L"ADMUTILC";
  local_118 = 0x149;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  local_res18 = in_R8;
  local_res20 = in_R9;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  local_140 = (va_list)&local_res18;
  DVar1 = FormatMessageW(0x900,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_148,0,&local_140);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW(0x1100,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_148,0,&local_140);
    if (DVar1 == 0) {
      GetLastError();
      wprintf(L"Unable to load message for id %x - %d\n");
      goto LAB_14000c84c;
    }
  }
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_148);
  LocalFree(local_148);
LAB_14000c84c:
  local_140 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}


