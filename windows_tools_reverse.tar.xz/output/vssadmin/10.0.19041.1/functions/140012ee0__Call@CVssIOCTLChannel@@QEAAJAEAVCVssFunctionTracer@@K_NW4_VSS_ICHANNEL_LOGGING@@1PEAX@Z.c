/*
 * Function : ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z
 * Address  : 0x140012ee0
 * Size     : 1007 bytes (232 instructions)
 * Prototype: long ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong param_2, bool param_3, _VSS_ICHANNEL_LOGGING param_4, bool param_5, void * param_6)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned
   long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64 */

long __thiscall
CVssIOCTLChannel::
_Call_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__K_NW4_VSS_ICHANNEL_LOGGING__1PEAX_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ulong param_2,bool param_3,
          _VSS_ICHANNEL_LOGGING param_4,bool param_5,void *param_6)

{
  CVssIOCTLChannel *lpBytesReturned;
  uint uVar1;
  BOOL BVar2;
  DWORD DVar3;
  void *pvVar4;
  undefined8 uVar5;
  uint uVar6;
  size_t _NewSize;
  _VSSDBG_SEV_ENUM _Var7;
  CVssIOCTLChannel *in_stack_ffffffffffffff08;
  wchar_t *local_e8;
  wchar_t *local_e0;
  wchar_t *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined4 local_c8;
  undefined1 local_c0 [120];
  undefined4 local_48;
  
  _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
  _NewSize = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(longlong *)this == 0) {
    _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x17d,10,_Var7);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar5,0x8000ffff,L"Channel not open");
  }
  if (this[0x29] != (CVssIOCTLChannel)0x0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x182,10,_Var7);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_1,uVar5,0x80070057,L"previous IOCTL hasn\'t yet completed");
  }
  uVar1 = *(uint *)(this + 0x44);
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  do {
    _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    if ((int)_NewSize == 0) {
      if (uVar1 == 0) {
        _NewSize = 0x1000;
        goto LAB_140012f54;
      }
    }
    else {
LAB_140012f54:
      uVar6 = (uint)_NewSize;
      if (uVar1 < uVar6) {
        pvVar4 = realloc(*(void **)(this + 0x50),_NewSize);
        if (pvVar4 == (void *)0x0) {
          _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
          uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_e8,
                             (ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                             (ushort *)L"CVssIOCTLChannel::Call",0x1ba,10,_Var7);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (param_1,uVar5,0x8007000e,L"Could not extend the output buffer");
        }
        *(void **)(this + 0x50) = pvVar4;
        *(uint *)(this + 0x44) = uVar6;
        uVar1 = uVar6;
      }
    }
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c3;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (param_1,&local_e8,
               L"IOCTL sent: %lx on device %s\n Input buffer size: %ld, Output buffer size: %ld",
               0x534058,*(undefined8 *)(this + 0x68),*(undefined4 *)(this + 0x2c),uVar1);
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c5;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
              (param_1,&local_e8,*(undefined4 *)(this + 0x2c),*(undefined8 *)(this + 0x38));
    lpBytesReturned = this + 0x48;
    in_stack_ffffffffffffff08 = lpBytesReturned;
    BVar2 = DeviceIoControl(*(HANDLE *)this,0x534058,*(LPVOID *)(this + 0x38),
                            *(DWORD *)(this + 0x2c),*(LPVOID *)(this + 0x50),*(DWORD *)(this + 0x44)
                            ,(LPDWORD)lpBytesReturned,(LPOVERLAPPED)0x0);
    _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    if (BVar2 != 0) {
LAB_1400130aa:
      GetLastError();
      *(undefined4 *)(this + 0x2c) = 0;
      *(undefined4 *)(this + 0x40) = 0;
      if (BVar2 == 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                   (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x1ea,10,_Var7);
        CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
        ::
        _Get___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEBAPEAGXZ
                  ((CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
                    *)(this + 0x60));
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(param_1);
      }
      local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_e0 = L"CVssIOCTLChannel::Call";
      local_d8 = L"INCICHLH";
      local_d0 = 0x225;
      local_cc = 10;
      local_c8 = 0xff;
      local_48 = 0x1000000;
      memset(local_c0,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (param_1,&local_e8,
                 L"IOCTL %lx succeeded on device %s - 0x%08lx. \n Output buffer: size received = %ld"
                 ,0x534058,*(undefined8 *)(this + 0x68),*(undefined8 *)this,
                 *(DWORD *)lpBytesReturned);
      local_cc = 10;
      local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_e0 = L"CVssIOCTLChannel::Call";
      local_d8 = L"INCICHLH";
      local_d0 = 0x227;
      local_c8 = 0xff;
      local_48 = 0x1000000;
      memset(local_c0,0,0x78);
      CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
                (param_1,&local_e8,*(DWORD *)lpBytesReturned,*(undefined8 *)(this + 0x50));
      *(undefined4 *)(param_1 + 8) = 0;
      return 0;
    }
    DVar3 = GetLastError();
    if (DVar3 != 0x7a) {
      DVar3 = GetLastError();
      _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
      if (DVar3 != 0xea) goto LAB_1400130aa;
    }
    uVar1 = *(uint *)(this + 0x44);
    _NewSize = (size_t)(uVar1 * 2);
  } while( true );
}


