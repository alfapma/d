/*
 * Function : ?ListWriters@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140007510
 * Size     : 2334 bytes (515 instructions)
 * Prototype: void ?ListWriters@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ListWriters(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListWriters(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListWriters_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  ushort *puVar1;
  ushort *pv;
  uint uVar2;
  wchar_t *pwVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined1 auStackY_218 [32];
  _VSSDBG_SEV_ENUM _Var6;
  undefined8 in_stack_fffffffffffffe18;
  wchar_t *local_1d8;
  int local_1d0 [2];
  longlong *local_1c8;
  longlong *local_1c0;
  int local_1b8;
  int local_1b4;
  uint local_1b0 [2];
  _GUID local_1a8;
  CVssFunctionTracer local_198 [8];
  int local_190;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  undefined **local_80;
  ushort *local_78;
  undefined **local_70;
  ushort *local_68;
  undefined8 local_60;
  ulong local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  ulong local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  ulonglong local_38;
  
  local_60 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_218;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_120 = L"CVssAdminCLI::ListWriters";
  local_118 = L"ADMPROCC";
  local_110 = 0x3c0;
  local_10c = 7;
  local_108 = 0xff;
  uVar4 = 0;
  local_88 = 0x1000000;
  uVar5 = 1;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_198,&local_128);
  local_1c8 = (longlong *)0x0;
  local_1c0 = (longlong *)0x0;
  local_190 = CreateVssBackupComponentsInternal(&local_1c8);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3cc,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x28))(local_1c8,0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3d0,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x48))(local_1c8,&local_1c0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3d6,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_1b8 = 0;
  uVar2 = uVar4;
  do {
    Sleep(0x9c4);
    local_1d0[0] = 0;
    local_190 = (**(code **)(*local_1c0 + 0x28))(local_1c0,&local_1b8,local_1d0);
    _Var6 = (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18;
    if (local_190 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListWriters",0x3e6,7,_Var6);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    if (local_1b8 == 0x4230a) goto LAB_1400076b3;
    if (local_1b8 != 0x42309) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListWriters",0x3ec,7,_Var6);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    uVar2 = uVar2 + 1;
  } while ((int)uVar2 < 4);
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275a);
  local_190 = (**(code **)(*local_1c0 + 0x20))(local_1c0,0xffffffff);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3f5,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
LAB_1400076b3:
  Ordinal_30(&local_1c0,0);
  local_190 = (**(code **)(*local_1c8 + 0x60))();
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3fd,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x80))(local_1c8,&local_1c0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x402,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c0 + 0x20))(local_1c0,0xffffffff);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x406,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  Ordinal_30(&local_1c0,0);
  local_190 = (**(code **)(*local_1c8 + 0x88))(local_1c8,local_1b0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x40c,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  if (local_1b0[0] != 0) {
    do {
      local_48 = 0;
      uStack_44 = 0;
      uStack_40 = 0;
      uStack_3c = 0;
      local_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_4c = 0;
      local_1d8 = (wchar_t *)0x0;
      _Var6 = (_VSSDBG_SEV_ENUM)&local_1b4;
      local_190 = (**(code **)(*local_1c8 + 0x98))(local_1c8,uVar4,&local_48,&local_58);
      if (local_190 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_128,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListWriters",0x41a,7,_Var6);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
      }
      if (local_1d0[0] == 1) {
        uVar2 = 0x6b;
      }
      else if (local_1d0[0] == 2) {
        uVar2 = 0x6e;
      }
      else if (local_1d0[0] == 3) {
        uVar2 = 0x6f;
      }
      else if (local_1d0[0] == 4) {
        uVar2 = 0x78;
      }
      else if (local_1d0[0] == 5) {
        uVar2 = 0x70;
      }
      else if (local_1d0[0] - 6U < 9) {
        uVar2 = 0x6c;
      }
      else {
        uVar2 = 0x6d;
      }
      puVar1 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar2);
      _Var6 = (_VSSDBG_SEV_ENUM)puVar1;
      if (local_1b4 == -0x7ffbdce7) {
        uVar2 = 0x79;
LAB_140007926:
        _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar2);
      }
      else {
        if (local_1b4 == -0x7ffbdc10) {
          uVar2 = 0x71;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0f) {
          uVar2 = 0x72;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0e) {
          uVar2 = 0x73;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0d) {
          uVar2 = 0x74;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0c) {
          uVar2 = 0x75;
          goto LAB_140007926;
        }
        if (local_1b4 == 0) {
          uVar2 = 0x77;
          goto LAB_140007926;
        }
        _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,0x76);
        local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_120 = L"CVssAdminCLI::ListWriters";
        local_118 = L"ADMPROCC";
        local_110 = 0x45a;
        local_10c = 7;
        local_108 = 0xff;
        local_88 = 0x1000000;
        memset(local_100,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_198,&local_128,L"Unexpected writer error failure: 0x%08x",local_1b4);
      }
      local_1a8.Data2 = (undefined2)uStack_54;
      local_1a8.Data3 = uStack_54._2_2_;
      local_1a8.Data1 = local_58;
      local_1a8.Data4[4] = (undefined1)uStack_4c;
      local_1a8.Data4[5] = uStack_4c._1_1_;
      local_1a8.Data4[6] = uStack_4c._2_1_;
      local_1a8.Data4[7] = uStack_4c._3_1_;
      local_1a8.Data4[0] = (undefined1)uStack_50;
      local_1a8.Data4[1] = uStack_50._1_1_;
      local_1a8.Data4[2] = uStack_50._2_1_;
      local_1a8.Data4[3] = uStack_50._3_1_;
      puVar1 = GuidToString(&local_1a8);
      local_70 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_1a8.Data2 = (undefined2)uStack_44;
      local_1a8.Data3 = uStack_44._2_2_;
      local_1a8.Data1 = local_48;
      local_1a8.Data4[4] = (undefined1)uStack_3c;
      local_1a8.Data4[5] = uStack_3c._1_1_;
      local_1a8.Data4[6] = uStack_3c._2_1_;
      local_1a8.Data4[7] = uStack_3c._3_1_;
      local_1a8.Data4[0] = (undefined1)uStack_40;
      local_1a8.Data4[1] = uStack_40._1_1_;
      local_1a8.Data4[2] = uStack_40._2_1_;
      local_1a8.Data4[3] = uStack_40._3_1_;
      local_68 = puVar1;
      pv = GuidToString(&local_1a8);
      local_80 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      pwVar3 = L"";
      if (false) {
        pwVar3 = local_1d8;
      }
      local_78 = pv;
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002757,pwVar3,puVar1);
      if (pv != (ushort *)0x0) {
        CoTaskMemFree(pv);
      }
      local_78 = (ushort *)0x0;
      local_80 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                  ::_vftable_;
      if (puVar1 != (ushort *)0x0) {
        CoTaskMemFree(puVar1);
      }
      local_68 = (ushort *)0x0;
      local_70 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                  ::_vftable_;
      Ordinal_6(0);
      uVar4 = uVar4 + 1;
    } while (uVar4 < local_1b0[0]);
    uVar5 = 0;
  }
  local_190 = (**(code **)(*local_1c8 + 0x90))();
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x46f,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  *(undefined4 *)(this + 0x48) = uVar5;
  if (local_1c0 != (longlong *)0x0) {
    (**(code **)(*local_1c0 + 0x10))();
  }
  if (local_1c8 != (longlong *)0x0) {
    (**(code **)(*local_1c8 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_198);
  return;
}


