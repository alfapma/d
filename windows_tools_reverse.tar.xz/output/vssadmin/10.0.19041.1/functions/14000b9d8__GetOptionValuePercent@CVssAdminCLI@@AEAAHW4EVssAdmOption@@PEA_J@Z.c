/*
 * Function : ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z
 * Address  : 0x14000b9d8
 * Size     : 309 bytes (74 instructions)
 * Prototype: int ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2)

{
  ushort uVar1;
  ushort *puVar2;
  longlong lVar3;
  longlong lVar4;
  __int64 _Var5;
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this_00;
  uint uVar6;
  undefined **local_148;
  ushort *local_140;
  undefined8 local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_138 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_128 = L"CVssAdminCLI::GetOptionValuePercent";
  local_120 = L"INCPNTRH";
  local_118 = 0x17d;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  puVar2 = *(ushort **)(this + 0x90);
  uVar6 = 0;
  if (puVar2 == (ushort *)0x0) {
    *param_2 = 0;
  }
  else if (*puVar2 != 0) {
    local_140 = (ushort *)0x0;
    local_148 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    this_00 = (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_148;
    CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
    _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z(this_00,puVar2);
    puVar2 = local_140;
    lVar3 = -1;
    do {
      lVar4 = lVar3;
      lVar3 = lVar4 + 1;
    } while (local_140[lVar4 + 1] != 0);
    uVar1 = local_140[lVar4];
    if (uVar1 == 0x25) {
      local_140[lVar4] = 0;
      _Var5 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,local_140,0);
      *param_2 = _Var5;
    }
    uVar6 = (uint)(uVar1 == 0x25);
    if (puVar2 != (ushort *)0x0) {
      CoTaskMemFree(puVar2);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return uVar6;
}


