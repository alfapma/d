/*
 * Function : ??1CVssAdminCLI@@QEAA@XZ
 * Address  : 0x140001070
 * Size     : 491 bytes (126 instructions)
 * Prototype: void ??1CVssAdminCLI@@QEAA@XZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAdminCLI::~CVssAdminCLI(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: __cdecl CVssAdminCLI::~CVssAdminCLI(void) __ptr64 */

void __thiscall CVssAdminCLI::__1CVssAdminCLI__QEAA_XZ(CVssAdminCLI *this)

{
  LPVOID pv;
  undefined8 *puVar1;
  CVssAdminCLI *pCVar2;
  uint uVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar4 = 0;
  uVar3 = uVar4;
  if (*(int *)(this + 0x20) != 0) {
    do {
      lVar6 = *(longlong *)(this + 0x18);
      lVar5 = (longlong)(int)uVar3;
      CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
      uVar3 = uVar3 + 1;
      *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
    } while (uVar3 < *(uint *)(this + 0x20));
  }
  uVar3 = uVar4;
  if (*(int *)(this + 0x38) != 0) {
    do {
      lVar6 = *(longlong *)(this + 0x30);
      lVar5 = (longlong)(int)uVar3;
      CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
      uVar3 = uVar3 + 1;
      *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
    } while (uVar3 < *(uint *)(this + 0x38));
  }
  puVar1 = *(undefined8 **)(this + 0x40);
  if (puVar1 != (undefined8 *)0x0) {
    if (*(int *)(puVar1 + 2) != 0) {
      do {
        lVar6 = puVar1[1];
        lVar5 = (longlong)(int)uVar4;
        CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
        *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
        pv = *(LPVOID *)(**(longlong **)(this + 0x40) + lVar5 * 8);
        *(LPVOID *)(lVar6 + lVar5 * 8) = pv;
        CoTaskMemFree(pv);
        *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
        uVar4 = uVar4 + 1;
        puVar1 = *(undefined8 **)(this + 0x40);
      } while (uVar4 < *(uint *)(puVar1 + 2));
    }
    if (puVar1 != (undefined8 *)0x0) {
      if ((void *)*puVar1 != (void *)0x0) {
        free((void *)*puVar1);
        *puVar1 = 0;
      }
      if ((void *)puVar1[1] != (void *)0x0) {
        free((void *)puVar1[1]);
        puVar1[1] = 0;
      }
      *(undefined4 *)(puVar1 + 2) = 0;
      operator_delete__(puVar1);
    }
  }
  puVar1 = *(undefined8 **)this;
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  if (this[0xf0] != (CVssAdminCLI)0x0) {
    CoUninitialize();
  }
  pCVar2 = this + 0x68;
  lVar6 = 0xe;
  do {
    CoTaskMemFree(*(LPVOID *)pCVar2);
    *(undefined8 *)pCVar2 = 0;
    pCVar2 = pCVar2 + 8;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  if (*(void **)(this + 0x28) != (void *)0x0) {
    free(*(void **)(this + 0x28));
    *(undefined8 *)(this + 0x28) = 0;
  }
  if (*(void **)(this + 0x30) != (void *)0x0) {
    free(*(void **)(this + 0x30));
    *(undefined8 *)(this + 0x30) = 0;
  }
  *(undefined4 *)(this + 0x38) = 0;
  if (*(void **)(this + 0x10) != (void *)0x0) {
    free(*(void **)(this + 0x10));
    *(undefined8 *)(this + 0x10) = 0;
  }
  if (*(void **)(this + 0x18) != (void *)0x0) {
    free(*(void **)(this + 0x18));
    *(undefined8 *)(this + 0x18) = 0;
  }
  *(undefined4 *)(this + 0x20) = 0;
  return;
}


