/*
 * Function : ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z
 * Address  : 0x140004728
 * Size     : 1890 bytes (409 instructions)
 * Prototype: void ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z(CVssAdmSnapshotSets * this, long param_1, _GUID * param_2, _GUID * param_3, _GUID * param_4, ushort * param_5)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssAdmSnapshotSets::Initialize(long,struct _GUID,struct _GUID,struct _GUID,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssAdmSnapshotSets::Initialize(long,struct _GUID,struct _GUID,struct
   _GUID,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdmSnapshotSets::_Initialize_CVssAdmSnapshotSets__QEAAXJU_GUID__00PEBG_Z
          (CVssAdmSnapshotSets *this,long param_1,_GUID *param_2,_GUID *param_3,_GUID *param_4,
          ushort *param_5)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  longlong *plVar9;
  void *pvVar10;
  undefined8 uVar11;
  uint uVar12;
  CVssAdmSnapshotSetEntry *pCVar13;
  size_t sVar14;
  CVssAdmSnapshotSetEntry *pCVar15;
  CVssAdmSnapshotSetEntry *pCVar16;
  undefined1 auStackY_298 [32];
  _VSSDBG_SEV_ENUM _Var17;
  longlong **pplVar18;
  undefined1 local_258 [8];
  longlong *local_250;
  GUID local_248;
  longlong *local_238;
  undefined1 local_228 [16];
  wchar_t *local_218;
  wchar_t *local_210;
  wchar_t *local_208;
  undefined4 local_200;
  undefined4 local_1fc;
  undefined4 local_1f8;
  undefined1 local_1f0 [120];
  undefined4 local_178;
  CVssFunctionTracer local_168 [8];
  int local_160;
  undefined8 local_f8;
  undefined1 local_e8 [8];
  longlong local_e0;
  longlong local_d8;
  longlong local_d0;
  longlong lStack_c8;
  undefined4 local_c0;
  wchar_t *local_b0;
  longlong local_88;
  longlong local_80;
  ulonglong local_58;
  
  local_f8 = 0xfffffffffffffffe;
  local_58 = __security_cookie ^ (ulonglong)auStackY_298;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdmSnapshotSets::Initialize";
  local_208 = L"ADMPROCC";
  local_200 = 0x8f;
  local_1fc = 7;
  local_1f8 = 0xff;
  pCVar16 = (CVssAdmSnapshotSetEntry *)0x0;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_168);
  local_250 = (longlong *)0x0;
  local_228 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_248 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdmSnapshotSets::Initialize";
  local_208 = L"ADMPROCC";
  local_200 = 0x95;
  local_1fc = 7;
  local_1f8 = 0xff;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  pplVar18 = &local_250;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_168,&local_218,&local_248,L"Coordinator");
  if (local_160 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0x9c,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_160 = (**(code **)(*local_250 + 0x18))(local_250,param_1);
  if (((local_160 < 0) && (local_160 != -0x7ff8fffb)) && (local_160 != -0x7fffbfff)) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0xa6,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_238 = (longlong *)0x0;
  local_228 = ZEXT816(0);
  local_160 = (**(code **)(*local_250 + 0x50))(local_250,local_228,1);
  if (local_160 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0xaf,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_160 = (**(code **)(*local_238 + 0x18))(local_238,1,local_e8,local_258);
  _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
  do {
    if (local_160 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_218,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdmSnapshotSets::Initialize",0xb8,7,_Var17);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
    }
    if (local_160 == 1) {
      if (local_238 != (longlong *)0x0) {
        (**(code **)(*local_238 + 0x10))();
      }
      if (local_250 != (longlong *)0x0) {
        (**(code **)(*local_250 + 0x10))();
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_168);
      return;
    }
    local_228._8_8_ = &local_e0;
    local_228._0_8_ =
         &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
          ::_vftable_;
    lVar2._0_4_ = param_2->Data1;
    lVar2._4_2_ = param_2->Data2;
    lVar2._6_2_ = param_2->Data3;
    if (((((lVar2 == 0) && (*(longlong *)param_2->Data4 == 0)) ||
         ((lVar3._0_4_ = param_2->Data1, lVar3._4_2_ = param_2->Data2, lVar3._6_2_ = param_2->Data3,
          local_d0 == lVar3 && (lStack_c8 == *(longlong *)param_2->Data4)))) &&
        (((lVar4._0_4_ = param_3->Data1, lVar4._4_2_ = param_3->Data2, lVar4._6_2_ = param_3->Data3,
          lVar4 == 0 && (*(longlong *)param_3->Data4 == 0)) ||
         ((lVar5._0_4_ = param_3->Data1, lVar5._4_2_ = param_3->Data2, lVar5._6_2_ = param_3->Data3,
          local_e0 == lVar5 && (local_d8 == *(longlong *)param_3->Data4)))))) &&
       ((((lVar6._0_4_ = param_4->Data1, lVar6._4_2_ = param_4->Data2, lVar6._6_2_ = param_4->Data3,
          lVar6 == 0 && (*(longlong *)param_4->Data4 == 0)) ||
         ((lVar7._0_4_ = param_4->Data1, lVar7._4_2_ = param_4->Data2, lVar7._6_2_ = param_4->Data3,
          local_88 == lVar7 && (local_80 == *(longlong *)param_4->Data4)))) &&
        (((param_5 == (ushort *)0x0 || (*param_5 == 0)) ||
         (iVar8 = _wcsicmp((wchar_t *)param_5,local_b0), iVar8 == 0)))))) {
      local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_210 = L"CVssAdmSnapshotSets::Initialize";
      local_208 = L"ADMPROCC";
      local_200 = 0xdf;
      local_1fc = 7;
      local_1f8 = 0xff;
      local_178 = 0x1000000;
      memset(local_1f0,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_168,&local_218,L"Snapshot: %s",local_b0);
      local_248._8_8_ = lStack_c8;
      local_248._0_8_ = local_d0;
      pCVar13 = pCVar16;
      pCVar15 = pCVar16;
      if (0 < *(int *)(this + 0x10)) {
        do {
          plVar9 = (longlong *)((longlong)(int)pCVar13 * 0x10 + *(longlong *)this);
          if ((*plVar9 == local_d0) && (plVar9[1] == lStack_c8)) goto LAB_140004aad;
          uVar12 = (int)pCVar13 + 1;
          pCVar13 = (CVssAdmSnapshotSetEntry *)(ulonglong)uVar12;
          pCVar15 = pCVar15 + 1;
        } while ((int)uVar12 < *(int *)(this + 0x10));
      }
      pCVar15 = (CVssAdmSnapshotSetEntry *)0xffffffffffffffff;
LAB_140004aad:
      if ((pCVar15 == (CVssAdmSnapshotSetEntry *)0xffffffffffffffff) ||
         (pCVar13 = *(CVssAdmSnapshotSetEntry **)(*(longlong *)(this + 8) + (longlong)pCVar15 * 8),
         pCVar13 == (CVssAdmSnapshotSetEntry *)0x0)) {
        pCVar15 = operator_new(0x30,&std::nothrow);
        lVar3 = lStack_c8;
        lVar2 = local_d0;
        local_248._0_8_ = pCVar15;
        pCVar13 = pCVar16;
        if (pCVar15 != (CVssAdmSnapshotSetEntry *)0x0) {
          *(longlong *)pCVar15 = local_d0;
          *(longlong *)(pCVar15 + 8) = lStack_c8;
          *(undefined4 *)(pCVar15 + 0x10) = local_c0;
          *(longlong *)(pCVar15 + 0x18) = 0;
          *(longlong *)(pCVar15 + 0x20) = 0;
          *(undefined4 *)(pCVar15 + 0x28) = 0;
          pCVar13 = pCVar15;
        }
        if (pCVar13 == (CVssAdmSnapshotSetEntry *)0x0) {
          uVar11 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_218,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",
                              0xea,7,(_VSSDBG_SEV_ENUM)pplVar18);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_168,uVar11,0x8007000e,L"Out of memory");
        }
        sVar14 = (longlong)(*(int *)(this + 0x10) + 1) << 4;
        pvVar10 = realloc(*(void **)this,sVar14);
        _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
        uVar12 = (uint)sVar14;
        if (pvVar10 == (void *)0x0) {
LAB_140004e42:
          CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z(pCVar13,uVar12);
          uVar11 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_218,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",
                              0xee,7,_Var17);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_168,uVar11,0x8007000e,L"Out of memory");
        }
        *(void **)this = pvVar10;
        sVar14 = (longlong)(*(int *)(this + 0x10) + 1) << 3;
        pvVar10 = realloc(*(void **)(this + 8),sVar14);
        _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
        uVar12 = (uint)sVar14;
        if (pvVar10 == (void *)0x0) goto LAB_140004e42;
        *(void **)(this + 8) = pvVar10;
        iVar8 = *(int *)(this + 0x10);
        *(int *)(this + 0x10) = iVar8 + 1;
        plVar9 = (longlong *)((longlong)iVar8 * 0x10 + *(longlong *)this);
        if (plVar9 != (longlong *)0x0) {
          *plVar9 = lVar2;
          plVar9[1] = lVar3;
          pvVar10 = *(void **)(this + 8);
        }
        puVar1 = (undefined8 *)((longlong)pvVar10 + (longlong)iVar8 * 8);
        if (puVar1 != (undefined8 *)0x0) {
          *puVar1 = pCVar13;
        }
      }
      local_160 = CVssAdmSnapshotSetEntry::
                  _AddSnapshot_CVssAdmSnapshotSetEntry__QEAAJPEAU_VSS_SNAPSHOT_PROP___Z
                            (pCVar13,(_VSS_SNAPSHOT_PROP *)&local_e0);
      if (local_160 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_218,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",0xf7,7,
                   (_VSSDBG_SEV_ENUM)pplVar18);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
      }
    }
    else {
      VssFreeSnapshotPropertiesInternal(&local_e0);
    }
    local_228 = ZEXT816(0x140017068);
    local_160 = (**(code **)(*local_238 + 0x18))(local_238,1,local_e8,local_258);
    _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
  } while( true );
}


