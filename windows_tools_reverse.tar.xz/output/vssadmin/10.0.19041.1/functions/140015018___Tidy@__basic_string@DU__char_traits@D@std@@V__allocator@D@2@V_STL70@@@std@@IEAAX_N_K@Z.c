/*
 * Function : ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_N_K@Z
 * Address  : 0x140015018
 * Size     : 100 bytes (28 instructions)
 * Prototype: void ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, bool param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,bool param_1,
          __uint64 param_2)

{
  void *_Src;
  
  if ((param_1) && (0xf < *(ulonglong *)(this + 0x20))) {
    _Src = *(void **)(this + 8);
    if (param_2 != 0) {
      memcpy_s(this + 8,0x10,_Src,param_2);
    }
    operator_delete__(_Src);
  }
  *(undefined8 *)(this + 0x20) = 0xf;
  *(__uint64 *)(this + 0x18) = param_2;
  this[param_2 + 8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}


