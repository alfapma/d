/*
 * Function : ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ
 * Address  : 0x140011164
 * Size     : 752 bytes (167 instructions)
 * Prototype: void ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, long param_3, ushort * param_4, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TranslateInternalProviderError(struct CVssDebugInfo,long,long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TranslateInternalProviderError(struct
   CVssDebugInfo,long,long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::
_TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,int param_4,ushort *param_5,
          ...)

{
  long lVar1;
  undefined8 uVar2;
  ushort *puVar3;
  CVssDebugInfo *this_00;
  ulong in_stack_fffffffffffffe48;
  ushort *local_198;
  ushort *local_190;
  __uint64 local_188 [2];
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_188[1] = 0xfffffffffffffffe;
  local_190 = operator_new__(0x3ea,&std::nothrow);
  if (local_190 == (ushort *)0x0) {
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_188[0] = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_190,500,&local_198,local_188,in_stack_fffffffffffffe48,param_5,
                      &stack0x00000030);
  if (local_188[0] == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  *(int *)(this + 8) = param_3;
  if (((((param_3 == -0x7ff8fff2) || (param_3 == -0x7ff8fff8)) || (param_3 == -0x7ff8ff8f)) ||
      ((param_3 == -0x7ff8fc05 || (param_3 == -0x7ff8fa56)))) || (param_3 == -0x7ff8fb7a)) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
    CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
  }
  if (param_3 == -0x7ff8ff90) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
    CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
  }
  if (((1 < param_3 + 0x7ff8fffeU) && (param_3 != -0x7ff8fb71)) && (param_3 != -0x7ff8ffeb)) {
    if (param_3 == -0x7ff8fa4c) {
      puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
      uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_178);
      _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3016,uVar2);
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar2,param_4,L"Timeout error calling a provider routine: %s.",puVar3);
    }
    if (param_4 != -0x7ffbdcf8) {
      CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
      this_00 = (CVssDebugInfo *)
                CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
      _GetHr_CVssFunctionTracer__QEAAJXZ(this);
      uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
      _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3001,uVar2);
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    }
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
    lVar1 = _GetHr_CVssFunctionTracer__QEAAJXZ(this);
    puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,param_4,
               L"Unexpected error calling a provider routine: %s  [hr = 0x%08lx] ",puVar3,lVar1);
  }
  puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
  uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
  _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3011,uVar2);
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (this,uVar2,0x80042308,L"Invalid device when calling a provider routine: %s",puVar3);
}


