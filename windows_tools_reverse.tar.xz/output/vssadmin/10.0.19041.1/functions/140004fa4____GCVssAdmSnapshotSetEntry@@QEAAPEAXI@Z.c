/*
 * Function : ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z
 * Address  : 0x140004fa4
 * Size     : 163 bytes (42 instructions)
 * Prototype: void * ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z(CVssAdmSnapshotSetEntry * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: void * __ptr64 __cdecl CVssAdmSnapshotSetEntry::`scalar deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void * __ptr64 __cdecl CVssAdmSnapshotSetEntry::`scalar deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
          (CVssAdmSnapshotSetEntry *this,uint param_1)

{
  void *pvVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  if (0 < *(int *)(this + 0x28)) {
    uVar2 = (ulonglong)*(uint *)(this + 0x28);
    lVar3 = 0;
    do {
      pvVar1 = *(void **)(lVar3 + *(longlong *)(this + 0x20));
      VssFreeSnapshotPropertiesInternal(pvVar1);
      operator_delete__(pvVar1);
      lVar3 = lVar3 + 8;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  if (*(void **)(this + 0x18) != (void *)0x0) {
    free(*(void **)(this + 0x18));
    *(undefined8 *)(this + 0x18) = 0;
  }
  if (*(void **)(this + 0x20) != (void *)0x0) {
    free(*(void **)(this + 0x20));
    *(undefined8 *)(this + 0x20) = 0;
  }
  *(undefined4 *)(this + 0x28) = 0;
  operator_delete__(this);
  return this;
}


