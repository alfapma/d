/*
 * Function : ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z
 * Address  : 0x1400039d0
 * Size     : 3 bytes (1 instructions)
 * Prototype: void ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, CVssFunctionTracer * param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CInternalVerifier::ListWriters(class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CInternalVerifier::ListWriters(class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CInternalVerifier::_ListWriters_CInternalVerifier__UEAAXAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,CVssFunctionTracer *param_1)

{
  return;
}


