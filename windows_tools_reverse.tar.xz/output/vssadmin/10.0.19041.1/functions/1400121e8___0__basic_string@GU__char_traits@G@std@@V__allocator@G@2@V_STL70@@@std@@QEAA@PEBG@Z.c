/*
 * Function : ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@PEBG@Z
 * Address  : 0x1400121e8
 * Size     : 253 bytes (76 instructions)
 * Prototype: undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@PEBG@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct
   std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(unsigned
   short const * __ptr64) __ptr64 */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,ushort *param_1)

{
  bool bVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar3;
  bool in_R8B;
  __uint64 _Var4;
  
  *(undefined8 *)(this + 0x20) = 7;
  pbVar3 = this + 8;
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined2 *)pbVar3 = 0;
  _Var4 = 0xffffffffffffffff;
  do {
    _Var4 = _Var4 + 1;
  } while (param_1[_Var4] != 0);
  pbVar2 = pbVar3;
  if (7 < *(ulonglong *)(this + 0x20)) {
    pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
               **)pbVar3;
  }
  if (pbVar2 <= param_1) {
    pbVar2 = pbVar3;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    if (param_1 < pbVar2 + *(longlong *)(this + 0x18) * 2) {
      if (7 < *(ulonglong *)(this + 0x20)) {
        pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar3;
      }
      _assign___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                (this,(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                       *)this,(longlong)param_1 - (longlong)pbVar3 >> 1,_Var4);
      return this;
    }
  }
  bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                    (this,_Var4,in_R8B);
  if (bVar1) {
    pbVar2 = pbVar3;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    memcpy_s(pbVar2,*(ulonglong *)(this + 0x20) * 2,param_1,_Var4 * 2);
    *(__uint64 *)(this + 0x18) = _Var4;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    *(undefined2 *)(pbVar3 + _Var4 * 2) = 0;
  }
  return this;
}


