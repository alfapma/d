/*
 * Function : ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140008974
 * Size     : 1439 bytes (323 instructions)
 * Prototype: void ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_RevertSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  uchar auVar1 [8];
  bool bVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  ushort *puVar6;
  undefined8 uVar7;
  CVssAdminCLI *pCVar8;
  undefined1 auStackY_268 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdc8;
  _VSSDBG_SEV_ENUM _Var9;
  char local_228 [8];
  CVssAdminCLI *local_220;
  _GUID local_218;
  _GUID local_208;
  wchar_t *local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  undefined4 local_1e0;
  undefined4 local_1dc;
  undefined4 local_1d8;
  undefined1 local_1d0 [120];
  undefined4 local_158;
  CVssFunctionTracer local_148 [8];
  int local_140;
  undefined8 local_d8;
  _GUID local_c8;
  undefined1 local_b8 [48];
  ushort *local_88;
  ulonglong local_38;
  
  local_d8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_268;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::RevertSnapshot";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x54d;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_148,&local_1f8);
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,4);
  local_c8.Data1 = 0;
  local_c8.Data2 = 0;
  local_c8.Data3 = 0;
  local_c8.Data4[0] = '\0';
  local_c8.Data4[1] = '\0';
  local_c8.Data4[2] = '\0';
  local_c8.Data4[3] = '\0';
  local_c8.Data4[4] = '\0';
  local_c8.Data4[5] = '\0';
  local_c8.Data4[6] = '\0';
  local_c8.Data4[7] = '\0';
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar6 != (ushort *)0x0) {
    pCVar8 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar2 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar8,puVar6,&local_c8);
    if (!bVar2) {
      uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_1f8,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x556,7,
                         in_stack_fffffffffffffdc8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar7,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  uVar4 = dCurrentSKU & 0xfffffff8;
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  local_220 = (CVssAdminCLI *)0x0;
  local_218 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_208 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::RevertSnapshot";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x565;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  _Var9 = (_VSSDBG_SEV_ENUM)&local_220;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_148,&local_1f8,&local_208,L"Coordinator");
  if (-1 < local_140) {
    local_140 = (**(code **)(*(longlong *)local_220 + 0x18))
                          (local_220,(-(uint)(uVar4 != 0) & 0xffffffe2) + 0x1d);
    auVar1 = local_c8.Data4;
    if (local_140 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1f8,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::RevertSnapshot",0x570,7,_Var9);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
    }
    local_208.Data4[0] = local_c8.Data4[0];
    local_208.Data4[1] = local_c8.Data4[1];
    local_208.Data4[2] = local_c8.Data4[2];
    local_208.Data4[3] = local_c8.Data4[3];
    local_208.Data1 = local_c8.Data1;
    local_208.Data2 = local_c8.Data2;
    local_208.Data3 = local_c8.Data3;
    local_208.Data4[4] = local_c8.Data4[4];
    local_208.Data4[5] = local_c8.Data4[5];
    local_208.Data4[6] = local_c8.Data4[6];
    local_208.Data4[7] = local_c8.Data4[7];
    local_c8.Data4 = auVar1;
    local_140 = (**(code **)(*(longlong *)local_220 + 0x38))(local_220,&local_208);
    local_208.Data4 = (uchar  [8])local_b8;
    local_208._0_8_ =
         &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
          ::_vftable_;
    if (local_140 < 0) {
      if (local_140 != -0x7ffbdcf8) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1f8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x57e,7,_Var9);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
      }
      puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar6);
      VssFreeSnapshotPropertiesInternal(local_b8);
    }
    else {
      iVar5 = _PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z(this,0x40002776,0);
      if (iVar5 == 0) {
        VssFreeSnapshotPropertiesInternal(local_b8);
      }
      else {
        local_228[0] = '\0';
        local_140 = ShouldBlockRevertInternal(local_88,local_228);
        auVar1 = local_c8.Data4;
        if ((local_140 < 0) || (local_228[0] == '\0')) {
          local_218.Data4[0] = local_c8.Data4[0];
          local_218.Data4[1] = local_c8.Data4[1];
          local_218.Data4[2] = local_c8.Data4[2];
          local_218.Data4[3] = local_c8.Data4[3];
          local_218.Data1 = local_c8.Data1;
          local_218.Data2 = local_c8.Data2;
          local_218.Data3 = local_c8.Data3;
          local_218.Data4[4] = local_c8.Data4[4];
          local_218.Data4[5] = local_c8.Data4[5];
          local_218.Data4[6] = local_c8.Data4[6];
          local_218.Data4[7] = local_c8.Data4[7];
          pCVar8 = local_220;
          local_c8.Data4 = auVar1;
          local_140 = (**(code **)(*(longlong *)local_220 + 0x68))(local_220,&local_218,iVar3);
          if (local_140 < 0) {
            if (local_140 == -0x7ffbdcf8) {
              puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar6);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else if (local_140 == -0x7ffbdcf4) {
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else if (local_140 == -0x7ffbdce3) {
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002775);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else {
              if (local_140 != -0x7ffbdcdb) {
                CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1f8,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x59f,7,
                           _Var9);
                CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
                CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                          (local_148);
              }
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002773);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
          }
          else {
            _WaitForRevertCompletion_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
                      (pCVar8,local_88,(IVssCoordinator *)local_220);
            _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002770);
            *(undefined4 *)(this + 0x48) = 0;
            VssFreeSnapshotPropertiesInternal(local_b8);
          }
        }
        else {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
      }
    }
    if (local_220 != (CVssAdminCLI *)0x0) {
      (**(code **)(*(longlong *)local_220 + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
    return;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1f8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdminCLI::RevertSnapshot",0x56c,7,_Var9);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
}


