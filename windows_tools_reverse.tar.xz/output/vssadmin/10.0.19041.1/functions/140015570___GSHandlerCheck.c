/*
 * Function : __GSHandlerCheck
 * Address  : 0x140015570
 * Size     : 29 bytes (8 instructions)
 * Prototype: undefined8 __GSHandlerCheck(undefined8 param_1, undefined8 param_2, undefined8 param_3, longlong param_4)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined8
__GSHandlerCheck(undefined8 param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  __GSHandlerCheckCommon(param_2,param_4);
  return 1;
}


