/*
 * Function : ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ
 * Address  : 0x14000c86c
 * Size     : 369 bytes (83 instructions)
 * Prototype: ushort * ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ(CVssAdminCLI * this, int param_1, long param_2, ...)
 * CC       : __thiscall
 * Comment  : private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetMsg(int,long,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetMsg(int,long,...) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(CVssAdminCLI *this,int param_1,long param_2,...)

{
  DWORD DVar1;
  undefined8 in_R9;
  undefined8 local_res20;
  ushort *local_158;
  ushort *local_150;
  va_list local_148;
  undefined8 local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [112];
  
  local_140 = 0xfffffffffffffffe;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"CVssAdminCLI::GetMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x179;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  local_res20 = in_R9;
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_138);
  local_150 = (ushort *)0x0;
  local_148 = (va_list)&local_res20;
  DVar1 = FormatMessageW((-(uint)(param_1 != 0) & 0xffffff50) + 0x9ff,(LPCVOID)0x0,param_2,0x400,
                         (LPWSTR)&local_158,0,&local_148);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW((-(uint)(param_1 != 0) & 0xffffff50) + 0x11ff,(LPCVOID)0x0,param_2,0x400,
                           (LPWSTR)&local_158,0,&local_148);
    if (DVar1 == 0) goto LAB_14000c9bf;
  }
  if (local_158 != (ushort *)0x0) {
    VssSafeDuplicateStr(local_88,&local_150,local_158);
  }
  LocalFree(local_158);
LAB_14000c9bf:
  local_148 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return local_150;
}


