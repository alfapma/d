/*
 * Function : ??0bad_alloc@std@@QEAA@XZ
 * Address  : 0x140014004
 * Size     : 46 bytes (12 instructions)
 * Prototype: undefined ??0bad_alloc@std@@QEAA@XZ(bad_alloc * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64 */

bad_alloc * __thiscall std::bad_alloc::__0bad_alloc_std__QEAA_XZ(bad_alloc *this)

{
  exception::__0exception__QEAA_AEBQEBDH_Z((exception *)this,&_bad_alloc_Message,1);
  *(undefined ***)this = &_vftable_;
  return this;
}


