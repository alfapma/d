/*
 * Function : ??0exception@@QEAA@AEBV0@@Z
 * Address  : 0x140014759
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined ??0exception@@QEAA@AEBV0@@Z(exception * this, exception * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl exception::exception(class exception const & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl exception::exception(class exception const & __ptr64) __ptr64 */

void __thiscall exception::__0exception__QEAA_AEBV0__Z(exception *this,exception *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140014759. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this,param_1);
  return;
}


