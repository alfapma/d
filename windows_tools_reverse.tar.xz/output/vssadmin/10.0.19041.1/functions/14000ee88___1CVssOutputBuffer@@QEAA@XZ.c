/*
 * Function : ??1CVssOutputBuffer@@QEAA@XZ
 * Address  : 0x14000ee88
 * Size     : 8 bytes (2 instructions)
 * Prototype: void ??1CVssOutputBuffer@@QEAA@XZ(CVssOutputBuffer * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssOutputBuffer::~CVssOutputBuffer(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssOutputBuffer::~CVssOutputBuffer(void) __ptr64 */

void __thiscall CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ(CVssOutputBuffer *this)

{
  operator_delete__(*(void **)this);
  return;
}


