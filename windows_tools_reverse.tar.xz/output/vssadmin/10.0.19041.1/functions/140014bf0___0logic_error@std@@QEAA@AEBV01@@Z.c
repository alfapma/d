/*
 * Function : ??0logic_error@std@@QEAA@AEBV01@@Z
 * Address  : 0x140014bf0
 * Size     : 98 bytes (25 instructions)
 * Prototype: undefined ??0logic_error@std@@QEAA@AEBV01@@Z(logic_error * this, logic_error * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::logic_error::logic_error(class std::logic_error const & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::logic_error::logic_error(class std::logic_error const & __ptr64) __ptr64 */

logic_error * __thiscall
std::logic_error::__0logic_error_std__QEAA_AEBV01__Z(logic_error *this,logic_error *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &_vftable_;
  *(undefined8 *)(this + 0x38) = 0xf;
  *(undefined8 *)(this + 0x30) = 0;
  this[0x20] = (logic_error)0x0;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)(param_1 + 0x18),0,0xffffffffffffffff);
  return this;
}


