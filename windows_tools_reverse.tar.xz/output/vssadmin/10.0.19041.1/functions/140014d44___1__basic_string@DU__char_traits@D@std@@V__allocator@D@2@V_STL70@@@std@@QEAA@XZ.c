/*
 * Function : ??1?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@XZ
 * Address  : 0x140014d44
 * Size     : 48 bytes (13 instructions)
 * Prototype: void ??1?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@XZ(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::~basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::~basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>(void) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__1__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_XZ
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this)

{
  if (0xf < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined8 *)(this + 0x20) = 0xf;
  this[8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}


