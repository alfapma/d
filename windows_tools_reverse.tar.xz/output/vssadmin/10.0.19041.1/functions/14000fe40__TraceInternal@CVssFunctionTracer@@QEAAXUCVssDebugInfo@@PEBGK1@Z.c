/*
 * Function : ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z
 * Address  : 0x14000fe40
 * Size     : 134 bytes (33 instructions)
 * Prototype: void ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceInternal(struct CVssDebugInfo,unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::TraceInternal(struct CVssDebugInfo,unsigned short const
   * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined4 param_4,
          undefined8 param_5)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(this);
  if (iVar1 != 0) {
    Ordinal_3(*(undefined8 *)param_2,*(undefined8 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x18)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(param_2 + 0x1c),
              *(undefined8 *)(this + 0x28),param_3,param_4,param_5);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}


