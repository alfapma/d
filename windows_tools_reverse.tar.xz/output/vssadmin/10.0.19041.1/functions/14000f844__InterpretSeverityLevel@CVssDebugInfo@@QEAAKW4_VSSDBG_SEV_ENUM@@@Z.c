/*
 * Function : ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z
 * Address  : 0x14000f844
 * Size     : 14 bytes (4 instructions)
 * Prototype: ulong ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1)
 * CC       : __thiscall
 * Comment  : public: unsigned long __cdecl CVssDebugInfo::InterpretSeverityLevel(enum _VSSDBG_SEV_ENUM) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: unsigned long __cdecl CVssDebugInfo::InterpretSeverityLevel(enum _VSSDBG_SEV_ENUM)
   __ptr64 */

ulong __thiscall
CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,_VSSDBG_SEV_ENUM param_1)

{
  if (*(int *)(this + 0x20) != 0xff) {
    param_1 = *(_VSSDBG_SEV_ENUM *)(this + 0x20);
  }
  return param_1;
}


