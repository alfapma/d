/*
 * Function : ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z
 * Address  : 0x14000c568
 * Size     : 193 bytes (46 instructions)
 * Prototype: bool ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z(CVssAdminCLI * this, ushort * param_1, ushort * param_2)
 * CC       : __thiscall
 * Comment  : private: bool __cdecl CVssAdminCLI::Match(unsigned short const * __ptr64,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: bool __cdecl CVssAdminCLI::Match(unsigned short const * __ptr64,unsigned short const *
   __ptr64) __ptr64 */

bool __thiscall
CVssAdminCLI::_Match_CVssAdminCLI__AEAA_NPEBG0_Z(CVssAdminCLI *this,ushort *param_1,ushort *param_2)

{
  int iVar1;
  bool bVar2;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_10c = 7;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_88 = 0x1000000;
  local_120 = L"CVssAdminCLI::Match";
  local_118 = L"ADMUTILC";
  bVar2 = false;
  local_110 = 0xff;
  local_108 = 0xff;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  if (param_1 != (ushort *)0x0) {
    iVar1 = _wcsicmp((wchar_t *)param_1,(wchar_t *)param_2);
    bVar2 = iVar1 == 0;
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return bVar2;
}


