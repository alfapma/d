/*
 * Function : catch$7
 * Address  : 0x140015b8a
 * Size     : 84 bytes (19 instructions)
 * Prototype: undefined8 catch$7(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined8
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_7(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(exception **)(param_2 + 0x58),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return 0x140004655;
}


