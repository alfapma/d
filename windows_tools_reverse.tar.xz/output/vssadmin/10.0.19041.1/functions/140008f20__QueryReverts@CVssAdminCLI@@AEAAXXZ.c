/*
 * Function : ?QueryReverts@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140008f20
 * Size     : 952 bytes (210 instructions)
 * Prototype: void ?QueryReverts@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::QueryReverts(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::QueryReverts(void) __ptr64 */

void __thiscall CVssAdminCLI::_QueryReverts_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  code *pcVar1;
  DWORD DVar2;
  int iVar3;
  UINT UVar4;
  BOOL BVar5;
  DWORD DVar6;
  ushort *puVar7;
  HANDLE hFindVolume;
  undefined8 uVar8;
  undefined1 auStackY_3d8 [32];
  _VSSDBG_SEV_ENUM _Var9;
  IVssCoordinator **ppIVar10;
  IVssCoordinator *local_398 [2];
  GUID local_388;
  undefined1 local_378 [16];
  wchar_t *local_368;
  wchar_t *local_360;
  wchar_t *local_358;
  undefined4 local_350;
  undefined4 local_34c;
  undefined4 local_348;
  undefined1 local_340 [120];
  undefined4 local_2c8;
  undefined8 local_2c0;
  CVssFunctionTracer local_2b8 [8];
  int local_2b0;
  WCHAR local_248 [264];
  ulonglong local_38;
  
  local_2c0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_3d8;
  local_368 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_360 = L"CVssAdminCLI::QueryReverts";
  local_358 = L"ADMPROCC";
  local_350 = 0x5b1;
  local_34c = 7;
  local_348 = 0xff;
  local_2c8 = 0x1000000;
  memset(local_340,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_2b8,&local_368);
  puVar7 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,0);
  (**(code **)(**(longlong **)this + 0x40))(*(longlong **)this,puVar7,iVar3 == 1,local_2b8);
  local_398[0] = (IVssCoordinator *)0x0;
  local_388 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_378 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_368 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_360 = L"CVssAdminCLI::QueryReverts";
  local_358 = L"ADMPROCC";
  local_350 = 0x5be;
  local_34c = 7;
  local_348 = 0xff;
  local_2c8 = 0x1000000;
  memset(local_340,0,0x78);
  ppIVar10 = local_398;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_2b8,&local_368,local_378,L"Coordinator");
  if (local_2b0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_368,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::QueryReverts",0x5c5,7,(_VSSDBG_SEV_ENUM)ppIVar10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_2b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_2b8);
  }
  local_2b0 = (**(code **)(*(longlong *)local_398[0] + 0x18))(local_398[0],0xffffffff);
  if (local_2b0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_368,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::QueryReverts",0x5c9,7,(_VSSDBG_SEV_ENUM)ppIVar10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_2b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_2b8);
  }
  if (puVar7 == (ushort *)0x0) {
    hFindVolume = FindFirstVolumeW(local_248,0x104);
    local_378._8_8_ = hFindVolume;
    local_378._0_8_ =
         &CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
          ::_vftable_;
    if (hFindVolume == (HANDLE)0xffffffffffffffff) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_368,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::QueryReverts",0x5d5,7,
                         (_VSSDBG_SEV_ENUM)ppIVar10);
      CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
                (local_2b8,uVar8,L"FindFirstVolume");
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
    do {
      UVar4 = GetDriveTypeW(local_248);
      if (UVar4 == 3) {
        _QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
                  (this,(ushort *)local_248,local_398[0]);
      }
      BVar5 = FindNextVolumeW(hFindVolume,local_248,0x104);
      _Var9 = (_VSSDBG_SEV_ENUM)ppIVar10;
    } while (BVar5 != 0);
    DVar6 = GetLastError();
    if (DVar6 != 0x12) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_368,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::QueryReverts",0x5e1,7,_Var9
                        );
      DVar2 = DVar6 & 0xffff | 0x80070000;
      if ((int)DVar6 < 1) {
        DVar2 = DVar6;
      }
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
                (local_2b8,uVar8,DVar2,L"FindNextVolume");
    }
    *(undefined4 *)(this + 0x48) = 0;
    FindVolumeClose(hFindVolume);
  }
  else {
    _QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z(this,puVar7,local_398[0]);
    *(undefined4 *)(this + 0x48) = 0;
  }
  if (local_398[0] != (IVssCoordinator *)0x0) {
    (**(code **)(*(longlong *)local_398[0] + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_2b8);
  return;
}


