/*
 * Function : ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140006468
 * Size     : 1857 bytes (410 instructions)
 * Prototype: void ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::ListDiffAreas(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::ListDiffAreas(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListDiffAreas_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  bool bVar1;
  uchar auVar2 [8];
  LPVOID pv;
  IID *riid;
  ushort *puVar3;
  undefined8 uVar4;
  IVssEnumMgmtObject *pIVar5;
  undefined1 auStackY_238 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdf8;
  _VSSDBG_SEV_ENUM _Var6;
  IVssEnumMgmtObject **ppIVar7;
  IVssEnumMgmtObject *local_1f8;
  IVssEnumMgmtObject *local_1f0;
  IVssEnumMgmtObject *local_1e8 [2];
  _GUID local_1d8;
  IUnknown *local_1c8;
  undefined1 local_1c0 [8];
  undefined1 local_1b8 [24];
  wchar_t *local_1a0;
  wchar_t *local_198;
  wchar_t *local_190;
  undefined4 local_188;
  undefined4 local_184;
  undefined4 local_180;
  undefined1 local_178 [120];
  undefined4 local_100;
  CVssFunctionTracer local_f8 [8];
  ULONG local_f0;
  undefined8 local_88;
  undefined1 local_80 [8];
  uchar local_78 [8];
  LPVOID local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_88 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_238;
  local_1a0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_198 = L"CVssAdminCLI::ListDiffAreas";
  local_190 = L"ADMPROCC";
  local_188 = 0x299;
  local_184 = 7;
  local_180 = 0xff;
  local_100 = 0x1000000;
  bVar1 = true;
  memset(local_178,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_f8,&local_1a0);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  riid = (IID *)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  auVar2 = local_48.Data4;
  local_1d8.Data4[0] = local_48.Data4[0];
  local_1d8.Data4[1] = local_48.Data4[1];
  local_1d8.Data4[2] = local_48.Data4[2];
  local_1d8.Data4[3] = local_48.Data4[3];
  local_1d8.Data1 = local_48.Data1;
  local_1d8.Data2 = local_48.Data2;
  local_1d8.Data3 = local_48.Data3;
  local_1d8.Data4[4] = local_48.Data4[4];
  local_1d8.Data4[5] = local_48.Data4[5];
  local_1d8.Data4[6] = local_48.Data4[6];
  local_1d8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  (**(code **)(**(longlong **)this + 0x50))(*(longlong **)this,&local_1d8,riid,puVar3);
  local_1c8 = (IUnknown *)0x0;
  local_1d8.Data4[0] = local_48.Data4[0];
  local_1d8.Data4[1] = local_48.Data4[1];
  local_1d8.Data4[2] = local_48.Data4[2];
  local_1d8.Data4[3] = local_48.Data4[3];
  local_1d8.Data4[4] = local_48.Data4[4];
  local_1d8.Data4[5] = local_48.Data4[5];
  local_1d8.Data4[6] = local_48.Data4[6];
  local_1d8.Data4[7] = local_48.Data4[7];
  local_1d8.Data1 = local_48.Data1;
  local_1d8.Data2 = local_48.Data2;
  local_1d8.Data3 = local_48.Data3;
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_1d8,&local_1c8);
  if (riid == (IID *)0x0) {
    if (puVar3 == (ushort *)0x0) {
      local_1f0 = (IVssEnumMgmtObject *)0x0;
      local_1d8 = (_GUID)_GUID_fa7df749_66e7_4986_a27f_e2f04ae53772;
      local_1b8._0_16_ = (undefined1  [16])_GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
      local_1a0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_198 = L"CVssAdminCLI::ListDiffAreas";
      local_190 = L"ADMPROCC";
      local_188 = 0x2d6;
      local_184 = 7;
      local_180 = 0xff;
      local_100 = 0x1000000;
      memset(local_178,0,0x78);
      ppIVar7 = &local_1f0;
      CVssFunctionTracer::
      _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
                (local_f8,&local_1a0,local_1b8,L"VssSnapshotMgmt");
      auVar2 = local_48.Data4;
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2dd,7,
                   (_VSSDBG_SEV_ENUM)ppIVar7);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      local_1f8 = (IVssEnumMgmtObject *)0x0;
      local_1d8.Data4[0] = local_48.Data4[0];
      local_1d8.Data4[1] = local_48.Data4[1];
      local_1d8.Data4[2] = local_48.Data4[2];
      local_1d8.Data4[3] = local_48.Data4[3];
      local_1d8.Data1 = local_48.Data1;
      local_1d8.Data2 = local_48.Data2;
      local_1d8.Data3 = local_48.Data3;
      local_1d8.Data4[4] = local_48.Data4[4];
      local_1d8.Data4[5] = local_48.Data4[5];
      local_1d8.Data4[6] = local_48.Data4[6];
      local_1d8.Data4[7] = local_48.Data4[7];
      local_48.Data4 = auVar2;
      local_f0 = (**(code **)(*(longlong *)local_1f0 + 0x20))
                           (local_1f0,&local_1d8,0xffffffff,&local_1f8);
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2e8,7,
                   (_VSSDBG_SEV_ENUM)ppIVar7);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2ec,7,
                           (_VSSDBG_SEV_ENUM)ppIVar7);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      local_f0 = (**(code **)(*(longlong *)local_1f8 + 0x18))(local_1f8,1,local_80,local_1c0);
      _Var6 = (_VSSDBG_SEV_ENUM)ppIVar7;
      auVar2 = local_78;
      pv = local_70;
      while( true ) {
        if ((int)local_f0 < 0) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2fa,7,_Var6);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
        }
        if (local_f0 == 1) break;
        local_1d8.Data4[0] = auVar2[0];
        local_1d8.Data4[1] = auVar2[1];
        local_1d8.Data4[2] = auVar2[2];
        local_1d8.Data4[3] = auVar2[3];
        local_1d8.Data4[4] = auVar2[4];
        local_1d8.Data4[5] = auVar2[5];
        local_1d8.Data4[6] = auVar2[6];
        local_1d8.Data4[7] = auVar2[7];
        local_1d8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_1b8._8_8_ = pv;
        local_1b8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_1e8[0] = (IVssEnumMgmtObject *)0x0;
        local_78 = auVar2;
        local_70 = pv;
        local_f0 = (*local_1c8->lpVtbl[2].QueryInterface)(local_1c8,(IID *)auVar2,local_1e8);
        if ((int)local_f0 < 0) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x30c,7,
                     (_VSSDBG_SEV_ENUM)ppIVar7);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
        }
        if (local_f0 == 1) {
          if (local_1e8[0] != (IVssEnumMgmtObject *)0x0) {
            (**(code **)(*(longlong *)local_1e8[0] + 0x10))();
          }
        }
        else {
          _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1e8[0]);
          bVar1 = false;
          if (local_1e8[0] != (IVssEnumMgmtObject *)0x0) {
            (**(code **)(*(longlong *)local_1e8[0] + 0x10))();
          }
        }
        if (pv != (LPVOID)0x0) {
          CoTaskMemFree(pv);
        }
        local_1b8._0_16_ = ZEXT816(0x140017068);
        if (auVar2 != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)auVar2);
        }
        local_1d8 = (_GUID)ZEXT816(0x140017068);
        local_f0 = (**(code **)(*(longlong *)local_1f8 + 0x18))(local_1f8,1,local_80,local_1c0);
        _Var6 = (_VSSDBG_SEV_ENUM)ppIVar7;
        auVar2 = local_78;
        pv = local_70;
      }
      if (bVar1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x31a,7,
                           (_VSSDBG_SEV_ENUM)ppIVar7);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      pIVar5 = local_1f0;
      if (local_1f8 != (IVssEnumMgmtObject *)0x0) {
        (**(code **)(*(longlong *)local_1f8 + 0x10))();
        pIVar5 = local_1f0;
      }
    }
    else {
      local_1f8 = (IVssEnumMgmtObject *)0x0;
      local_f0 = (*local_1c8->lpVtbl[2].AddRef)(local_1c8);
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2c3,7,
                   in_stack_fffffffffffffdf8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2c7,7,
                           in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1f8);
      pIVar5 = local_1f8;
    }
  }
  else {
    local_1f8 = (IVssEnumMgmtObject *)0x0;
    local_f0 = (*local_1c8->lpVtbl[2].QueryInterface)(local_1c8,riid,&local_1f8);
    if ((int)local_f0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1a0,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListDiffAreas",0x2b2,7,in_stack_fffffffffffffdf8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
    }
    if (local_f0 == 1) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_1a0,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2b6,7,
                         in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_f8,uVar4,1,
                 L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
    }
    _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1f8);
    pIVar5 = local_1f8;
  }
  if (pIVar5 != (IVssEnumMgmtObject *)0x0) {
    (**(code **)(*(longlong *)pIVar5 + 0x10))();
  }
  *(undefined4 *)(this + 0x48) = 0;
  if (local_1c8 != (IUnknown *)0x0) {
    (*local_1c8->lpVtbl->Release)();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_f8);
  return;
}


