/*
 * Function : AssertPrivilege
 * Address  : 0x1400032b0
 * Size     : 356 bytes (83 instructions)
 * Prototype: int AssertPrivilege(ushort * param_1)
 * CC       : __cdecl
 * Comment  : int __cdecl AssertPrivilege(unsigned short const * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* int __cdecl AssertPrivilege(unsigned short const * __ptr64) */

int __cdecl AssertPrivilege(ushort *param_1)

{
  BOOL BVar1;
  BOOL BVar2;
  HANDLE ProcessHandle;
  void *TokenInformation;
  undefined1 auStackY_68 [32];
  uint local_38 [2];
  HANDLE local_30;
  _LUID local_28;
  _TOKEN_PRIVILEGES local_20;
  ulonglong local_10;
  
  local_10 = __security_cookie ^ (ulonglong)auStackY_68;
  BVar2 = 0;
  ProcessHandle = GetCurrentProcess();
  BVar1 = OpenProcessToken(ProcessHandle,0x28,&local_30);
  if (BVar1 != 0) {
    BVar2 = LookupPrivilegeValueW((LPCWSTR)0x0,L"SeBackupPrivilege",&local_28);
    if (BVar2 != 0) {
      local_20.Privileges[0].Luid.LowPart = local_28.LowPart;
      local_20.Privileges[0].Luid.HighPart = local_28.HighPart;
      local_20.PrivilegeCount = 1;
      local_20.Privileges[0].Attributes = 3;
      SetLastError(0);
      AdjustTokenPrivileges(local_30,0,&local_20,0,(PTOKEN_PRIVILEGES)0x0,(PDWORD)0x0);
      GetLastError();
    }
    GetTokenInformation(local_30,TokenPrivileges,(LPVOID)0x0,0,local_38);
    TokenInformation = operator_new__((ulonglong)local_38[0],&std::nothrow);
    if (TokenInformation == (void *)0x0) {
      SetLastError(0xe);
      BVar2 = 0;
    }
    else {
      BVar2 = GetTokenInformation(local_30,TokenPrivileges,TokenInformation,local_38[0],local_38);
      operator_delete__(TokenInformation);
    }
    CloseHandle(local_30);
  }
  return BVar2;
}


