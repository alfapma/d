/*
 * Function : catch$11
 * Address  : 0x1400165e5
 * Size     : 90 bytes (19 instructions)
 * Prototype: undefined * catch$11(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_11
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(exception **)(param_2 + 0x180),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return &DAT_140013e4d;
}


