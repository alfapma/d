/*
 * Function : catch$8
 * Address  : 0x1400164e4
 * Size     : 86 bytes (19 instructions)
 * Prototype: undefined * catch$8(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_8
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(long *)(param_2 + 0x50),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return &DAT_140013e4d;
}


