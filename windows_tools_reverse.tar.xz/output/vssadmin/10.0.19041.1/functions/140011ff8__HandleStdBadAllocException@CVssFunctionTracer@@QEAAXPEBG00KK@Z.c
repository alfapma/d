/*
 * Function : ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z
 * Address  : 0x140011ff8
 * Size     : 126 bytes (25 instructions)
 * Prototype: void ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z(CVssFunctionTracer * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::HandleStdBadAllocException(unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::HandleStdBadAllocException(unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
          (CVssFunctionTracer *this,ushort *param_1,ushort *param_2,ushort *param_3,ulong param_4,
          ulong param_5)

{
  ushort *local_b8;
  ushort *local_b0;
  ushort *local_a8;
  ulong local_a0;
  ulong local_9c;
  undefined4 local_98;
  undefined1 local_90 [120];
  undefined4 local_18;
  
  *(undefined4 *)(this + 8) = 0x8007000e;
  local_a0 = param_4;
  local_9c = param_5;
  local_98 = 0xff;
  local_18 = 0x1000000;
  local_b8 = param_1;
  local_b0 = param_3;
  local_a8 = param_2;
  memset(local_90,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_b8,L"bad_alloc STL exception caught: hr: 0x%x",0x8007000e);
  return;
}


