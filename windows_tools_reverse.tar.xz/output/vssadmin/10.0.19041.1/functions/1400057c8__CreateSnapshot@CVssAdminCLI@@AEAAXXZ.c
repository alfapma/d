/*
 * Function : ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x1400057c8
 * Size     : 2074 bytes (443 instructions)
 * Prototype: void ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::CreateSnapshot(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::CreateSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_CreateSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  LARGE_INTEGER LVar1;
  long lVar2;
  DWORD DVar3;
  DWORD DVar4;
  int iVar5;
  ushort *puVar6;
  uchar auVar7 [8];
  CVssAdminCLI *this_00;
  undefined1 auStackY_298 [32];
  _VSSDBG_SEV_ENUM _Var8;
  longlong **pplVar9;
  longlong *local_258 [2];
  GUID local_248;
  longlong *local_238;
  LARGE_INTEGER local_230;
  _GUID local_228;
  int local_218 [4];
  CVssFunctionTracer local_208 [8];
  int local_200;
  wchar_t *local_198;
  wchar_t *local_190;
  wchar_t *local_188;
  undefined4 local_180;
  undefined4 local_17c;
  undefined4 local_178;
  undefined1 local_170 [120];
  undefined4 local_f8;
  undefined8 local_f0;
  undefined1 local_e8 [128];
  ulong local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  _GUID local_48;
  ulonglong local_38;
  
  local_f0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_298;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_190 = L"CVssAdminCLI::CreateSnapshot";
  local_188 = L"ADMPROCC";
  local_180 = 0x1c6;
  local_17c = 7;
  local_178 = 0xff;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
            (local_208,(CVssDebugInfo *)&local_198);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar2 = 0x1d;
  }
  else {
    this_00 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar2 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(this_00,puVar6);
  }
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  local_230.QuadPart = 0;
  _GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z(this,1,&local_230.QuadPart,0);
  local_258[0] = (longlong *)0x0;
  local_248 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_228 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_190 = L"CVssAdminCLI::CreateSnapshot";
  local_188 = L"ADMPROCC";
  local_180 = 0x1de;
  local_17c = 7;
  local_178 = 0xff;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  pplVar9 = local_258;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_208,(CVssDebugInfo *)&local_198,&local_228,L"Coordinator");
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x1e5,7,(_VSSDBG_SEV_ENUM)pplVar9);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_258[0] + 0x18))(local_258[0],lVar2);
  LVar1 = local_230;
  _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x1e9,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_238 = (longlong *)0x0;
  local_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  if (local_230.QuadPart < 1) {
    local_200 = (**(code **)(*local_258[0] + 0x20))(local_258[0],&local_58);
    if (local_200 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::CreateSnapshot",0x216,7,_Var8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
    }
  }
  else {
    QueryPerformanceCounter(&local_230);
    srand(local_230.s.LowPart);
    DVar3 = GetTickCount();
    do {
      local_200 = (**(code **)(*local_258[0] + 0x20))();
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
      if (-1 < local_200) break;
      if (local_200 != -0x7ffbdcea) {
LAB_140005e77:
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_198,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::CreateSnapshot",0x209,7,_Var8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
      }
      DVar4 = GetTickCount();
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
      if (LVar1.QuadPart * 60000 <= (longlong)(ulonglong)(DVar4 - DVar3)) goto LAB_140005e77;
      if ((int)DAT_140024130 < 10000) {
        iVar5 = rand();
        DAT_140024130 = DAT_140024130 + iVar5 % 0x2ee;
      }
      DVar4 = DAT_140024130;
      local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_190 = L"CVssAdminCLI::CreateSnapshot";
      local_188 = L"ADMPROCC";
      local_180 = 0x204;
      local_17c = 7;
      local_178 = 0xff;
      local_f8 = 0x1000000;
      memset(local_170,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_208,(CVssDebugInfo *)&local_198,
                 L"Snapshot already in progress, retrying in %u millisecs",DVar4);
      Sleep(DAT_140024130);
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
    } while (local_200 < 0);
  }
  auVar7 = local_48.Data4;
  local_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  local_228.Data4[0] = local_48.Data4[0];
  local_228.Data4[1] = local_48.Data4[1];
  local_228.Data4[2] = local_48.Data4[2];
  local_228.Data4[3] = local_48.Data4[3];
  local_228.Data1 = local_48.Data1;
  local_228.Data2 = local_48.Data2;
  local_228.Data3 = local_48.Data3;
  local_228.Data4[4] = local_48.Data4[4];
  local_228.Data4[5] = local_48.Data4[5];
  local_228.Data4[6] = local_48.Data4[6];
  local_228.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar7;
  local_200 = (**(code **)(*local_258[0] + 0x28))(local_258[0],puVar6,&local_228,&local_68);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x221,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = 0;
  Ordinal_30(&local_238,0);
  local_200 = (**(code **)(*local_258[0] + 0x30))(local_258[0],0,&local_238);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x227,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_238 + 0x20))(local_238,0xffffffff);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x22c,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_238 + 0x28))(local_238,local_218,0);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x232,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = local_218[0];
  if (local_218[0] < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x23b,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_228.Data2 = (undefined2)uStack_64;
  local_228.Data3 = uStack_64._2_2_;
  local_228.Data1 = local_68;
  local_228.Data4[0] = (undefined1)uStack_60;
  local_228.Data4[1] = uStack_60._1_1_;
  local_228.Data4[2] = uStack_60._2_1_;
  local_228.Data4[3] = uStack_60._3_1_;
  local_228.Data4[4] = (undefined1)uStack_5c;
  local_228.Data4[5] = uStack_5c._1_1_;
  local_228.Data4[6] = uStack_5c._2_1_;
  local_228.Data4[7] = uStack_5c._3_1_;
  local_200 = (**(code **)(*local_258[0] + 0x38))(local_258[0],&local_228,local_e8);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x244,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_228.Data2 = (undefined2)uStack_64;
  local_228.Data3 = uStack_64._2_2_;
  local_228.Data1 = local_68;
  local_228.Data4[4] = (undefined1)uStack_5c;
  local_228.Data4[5] = uStack_5c._1_1_;
  local_228.Data4[6] = uStack_5c._2_1_;
  local_228.Data4[7] = uStack_5c._3_1_;
  local_228.Data4[0] = (undefined1)uStack_60;
  local_228.Data4[1] = uStack_60._1_1_;
  local_228.Data4[2] = uStack_60._2_1_;
  local_228.Data4[3] = uStack_60._3_1_;
  auVar7 = (uchar  [8])GuidToString(&local_228);
  local_228.Data4[0] = auVar7[0];
  local_228.Data4[1] = auVar7[1];
  local_228.Data4[2] = auVar7[2];
  local_228.Data4[3] = auVar7[3];
  local_228.Data4[4] = auVar7[4];
  local_228.Data4[5] = auVar7[5];
  local_228.Data4[6] = auVar7[6];
  local_228.Data4[7] = auVar7[7];
  local_228._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000274d,puVar6,auVar7);
  VssFreeSnapshotPropertiesInternal(local_e8);
  *(undefined4 *)(this + 0x48) = 0;
  if (auVar7 != (uchar  [8])0x0) {
    CoTaskMemFree((LPVOID)auVar7);
  }
  if (local_238 != (longlong *)0x0) {
    (**(code **)(*local_238 + 0x10))();
  }
  if (local_258[0] != (longlong *)0x0) {
    (**(code **)(*local_258[0] + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_208);
  return;
}


