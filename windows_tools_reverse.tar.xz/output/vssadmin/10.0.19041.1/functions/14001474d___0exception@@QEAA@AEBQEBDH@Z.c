/*
 * Function : ??0exception@@QEAA@AEBQEBDH@Z
 * Address  : 0x14001474d
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined ??0exception@@QEAA@AEBQEBDH@Z(exception * this, char * * param_1, int param_2)
 * CC       : __thiscall
 * Comment  : public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64 */

void __thiscall exception::__0exception__QEAA_AEBQEBDH_Z(exception *this,char **param_1,int param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00014001474d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this,param_1,param_2);
  return;
}


