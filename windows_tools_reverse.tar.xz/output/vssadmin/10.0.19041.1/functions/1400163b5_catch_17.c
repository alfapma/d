/*
 * Function : catch$17
 * Address  : 0x1400163b5
 * Size     : 90 bytes (19 instructions)
 * Prototype: undefined * catch$17(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_17
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(_com_error **)(param_2 + 0x238),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return (undefined *)0x140013b11;
}


