/*
 * Function : VssSafeDuplicateStr
 * Address  : 0x140003688
 * Size     : 318 bytes (75 instructions)
 * Prototype: void VssSafeDuplicateStr(CVssFunctionTracer * param_1, ushort * * param_2, ushort * param_3)
 * CC       : __cdecl
 * Comment  : void __cdecl VssSafeDuplicateStr(class CVssFunctionTracer & __ptr64,unsigned short * __ptr64 & __ptr64,unsigned short const * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void __cdecl VssSafeDuplicateStr(class CVssFunctionTracer & __ptr64,unsigned short * __ptr64 &
   __ptr64,unsigned short const * __ptr64) */

void __cdecl VssSafeDuplicateStr(CVssFunctionTracer *param_1,ushort **param_2,ushort *param_3)

{
  long lVar1;
  ushort *puVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff28;
  CVssDebugInfo local_c8 [176];
  
  lVar4 = -1;
  do {
    lVar4 = lVar4 + 1;
  } while (param_3[lVar4] != 0);
  puVar2 = CoTaskMemAlloc(lVar4 * 2 + 2);
  *param_2 = puVar2;
  if (puVar2 == (ushort *)0x0) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_c8,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                       (ushort *)L"VssSafeDuplicateStr",0x54,0xb,in_stack_ffffffffffffff28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_1,uVar3,0x8007000e,L"Memory allocation error");
  }
  lVar4 = -1;
  do {
    lVar5 = lVar4;
    lVar4 = lVar5 + 1;
  } while (param_3[lVar4] != 0);
  lVar1 = StringCchCopyW(puVar2,lVar5 + 2,param_3);
  if (-1 < lVar1) {
    return;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_c8,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                     (ushort *)L"VssSafeDuplicateStr",0x58,0xb,in_stack_ffffffffffffff28);
  lVar4 = -1;
  do {
    lVar5 = lVar4;
    lVar4 = lVar5 + 1;
  } while (param_3[lVar4] != 0);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (param_1,uVar3,lVar1,L"StringCchCopy(%s, %d, %s) failed",*param_2,lVar5 + 2,param_3);
}


