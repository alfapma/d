/*
 * Function : catch$0
 * Address  : 0x14001666a
 * Size     : 31 bytes (9 instructions)
 * Prototype: undefined * catch$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `operator_new'::__l1::catch_0(undefined8 param_1,longlong param_2)

{
  *(undefined8 *)(param_2 + 0x50) = 0;
  return &DAT_14001440d;
}


