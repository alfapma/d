/*
 * Function : ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z
 * Address  : 0x140011870
 * Size     : 1510 bytes (290 instructions)
 * Prototype: void ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z(CVssFunctionTracer * this, ulong param_1, CVssDebugInfo param_2, ushort param_3)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::LogError(unsigned long,struct CVssDebugInfo,unsigned short) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssFunctionTracer::LogError(unsigned long,struct CVssDebugInfo,unsigned
   short) __ptr64 */

void __thiscall
CVssFunctionTracer::_LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z
          (CVssFunctionTracer *this,DWORD param_1,CVssDebugInfo *param_3)

{
  ushort uVar1;
  ushort uVar2;
  longlong lVar3;
  BOOL BVar4;
  DWORD DVar5;
  longlong lVar6;
  LPWSTR pWVar7;
  wchar_t *pv;
  HANDLE hEventLog;
  CVssDebugInfo *pCVar8;
  undefined8 uVar9;
  CVssFunctionTracer *this_00;
  wchar_t *pwVar10;
  ulong uVar11;
  ulonglong uVar12;
  _VSSDBG_SEV_ENUM _Var13;
  longlong lVar14;
  undefined1 auStackY_1b78 [32];
  wchar_t *local_1ae8;
  wchar_t *local_1ae0;
  wchar_t *local_1ad8;
  undefined4 local_1ad0;
  undefined4 local_1acc;
  undefined4 local_1ac8;
  undefined1 local_1ac0 [120];
  undefined4 local_1a48;
  CVssFunctionTracer local_1a38 [112];
  undefined8 local_19c8;
  CVssDebugInfo local_19b0 [168];
  wchar_t *local_1908 [3];
  undefined4 local_18f0;
  undefined4 local_18ec;
  undefined4 local_18e8;
  undefined1 local_18e0 [120];
  undefined4 local_1868;
  CVssFunctionTracer local_1858 [2048];
  char local_1058 [4112];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x140011886;
  local_19c8 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_1b78;
  local_1908[0] = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
  local_1908[1] = L"CVssFunctionTracer::LogError";
  local_1908[2] = L"TRCTRCC";
  local_18f0 = 0x8c1;
  local_18ec = 0xb;
  local_18e8 = 0xff;
  local_1868 = 0x1000000;
  memset(local_18e0,0,0x78);
  __0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_1a38);
  memset(local_1908,0,0x80);
  memset(local_1058,0,0x1001);
  if (*(ushort *)(param_3 + 0xa0) + 1 < 0xf) {
    uVar11 = 0x800;
    this_00 = local_1858;
    memset(this_00,0,0x800);
    _GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z(this_00,(ushort *)local_1858,uVar11);
    lVar6 = -1;
    do {
      lVar6 = lVar6 + 1;
    } while (*(short *)(local_1858 + lVar6 * 2) != 0);
    pWVar7 = GetCommandLineW();
    lVar6 = -1;
    do {
      lVar6 = lVar6 + 1;
    } while (pWVar7[lVar6] != L'\0');
    _Var13 = *(_VSSDBG_SEV_ENUM *)(this + 0x20);
    GetCommandLineW();
    GetCurrentThreadId();
    GetCurrentProcessId();
    StringCchPrintfA(local_1058,0x1000,
                     "- Code: %8ls%08lu- Call: %8ls%08lu- PID:  %08lu- TID:  %08lu- CMD:  %-*ls- User: %-*ls"
                     ,*(undefined8 *)(param_3 + 0x10));
    lVar6 = -1;
    do {
      lVar14 = lVar6 + 1;
      lVar3 = lVar6 + 1;
      lVar6 = lVar14;
    } while (local_1058[lVar3] != '\0');
    uVar1 = *(ushort *)(param_3 + 0xa0);
    uVar2 = 0;
    if (uVar1 != 0) {
      memcpy(local_1908,param_3 + 0x28,(ulonglong)uVar1 << 3);
      uVar2 = uVar1;
    }
    pv = (wchar_t *)_GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(this);
    pwVar10 = L"";
    if (pv != (wchar_t *)0x0) {
      pwVar10 = pv;
    }
    local_1908[uVar2] = pwVar10;
    local_1ae8 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
    local_1ae0 = L"CVssFunctionTracer::LogError";
    local_1ad8 = L"TRCTRCC";
    local_1ad0 = 0x902;
    local_1acc = 0xb;
    local_1a48 = 0x1000000;
    memset(local_1ac0,0,0x78);
    uVar12 = 100;
    local_1ac8 = 100;
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_19b0,(CVssDebugInfo *)&local_1ae8);
    uVar12 = uVar12 & 0xffffffff;
    if (*(int *)(param_3 + 0x20) != 0xff) {
      uVar12 = (ulonglong)*(uint *)(param_3 + 0x20);
    }
    _TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
              (this,local_19b0,L"CONTEXT",uVar12);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_1ae8);
    hEventLog = RegisterEventSourceW((LPCWSTR)0x0,L"VSS");
    if (hEventLog == (HANDLE)0x0) {
      pCVar8 = (CVssDebugInfo *)
               CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1ae8,
                          (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                          (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::LogError",0x912,0xb,
                          _Var13);
      uVar9 = CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
                        (pCVar8,(_VSSDBG_SEV_ENUM)local_19b0);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,uVar9,L"Error on RegisterEventSourceW 0x%08lx",DVar5);
      pCVar8 = (CVssDebugInfo *)&local_1ae8;
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(pCVar8);
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)pCVar8);
    }
    _Var13 = (_VSSDBG_SEV_ENUM)lVar14;
    BVar4 = ReportEventW(hEventLog,1,0,param_1,(PSID)0x0,uVar1 + 1,_Var13,local_1908,local_1058);
    if (BVar4 == 0) {
      local_1ae8 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
      local_1ae0 = L"CVssFunctionTracer::LogError";
      local_1ad8 = L"TRCTRCC";
      local_1ad0 = 0x923;
      local_1acc = 0xb;
      local_1a48 = 0x1000000;
      memset(local_1ac0,0,0x78);
      local_1ac8 = 100;
      CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_19b0,(CVssDebugInfo *)&local_1ae8);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,local_19b0,L"Error on ReportEventW 0x%08lx",DVar5);
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_1ae8);
    }
    BVar4 = DeregisterEventSource(hEventLog);
    if (BVar4 == 0) {
      pCVar8 = (CVssDebugInfo *)
               CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1ae8,
                          (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                          (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::LogError",0x92a,0xb,
                          _Var13);
      uVar9 = CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
                        (pCVar8,(_VSSDBG_SEV_ENUM)local_19b0);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,uVar9,L"Error on DeregisterEventSource 0x%08lx",DVar5);
      pCVar8 = (CVssDebugInfo *)&local_1ae8;
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(pCVar8);
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)pCVar8);
    }
    CoTaskMemFree(pv);
    __1CVssFunctionTracer__QEAA_XZ(local_1a38);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_3);
  }
  else {
    __1CVssFunctionTracer__QEAA_XZ(local_1a38);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_3);
  }
  return;
}


