/*
 * Function : ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ
 * Address  : 0x1400100cc
 * Size     : 577 bytes (134 instructions)
 * Prototype: ushort * ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ(CVssFunctionTracer * this)
 * CC       : __thiscall
 * Comment  : public: unsigned short * __ptr64 __cdecl CVssFunctionTracer::GetCurrentContexts(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: unsigned short * __ptr64 __cdecl CVssFunctionTracer::GetCurrentContexts(void) __ptr64 */

ushort * __thiscall
CVssFunctionTracer::_GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(CVssFunctionTracer *this)

{
  bool bVar1;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *pbVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  CVssResource *this_00;
  ushort *puVar6;
  int iVar7;
  CVssFunctionTracer *pCVar8;
  __uint64 _Var9;
  code *pcVar10;
  undefined1 auStackY_168 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffec8;
  ushort *local_128 [2];
  undefined8 local_118;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  local_108 [8];
  void *local_100;
  ulonglong local_e8;
  CVssDebugInfo local_d8 [8];
  ushort local_d0 [8];
  ulonglong auStack_c0 [19];
  ulonglong local_28;
  
  local_118 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_168;
  local_128[0] = (ushort *)0x0;
  bVar1 = CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z
                    ((CVssAutoCoString *)local_128,(ushort *)L"");
  if (!bVar1) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_d8,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                       (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::GetCurrentContexts",
                       0x37b,0xb,in_stack_fffffffffffffec8);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar5,0x8007000e,L"internal tracing buffer - out of memory");
  }
  pcVar10 = std::
            basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
            ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ;
  _Var9 = 4;
  _eh_vector_constructor_iterator_
            (local_d8,0x28,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ);
  for (iVar7 = 0; pCVar8 = this, iVar7 < 4; iVar7 = iVar7 + 1) {
    for (; pCVar8 != (CVssFunctionTracer *)0x0; pCVar8 = *(CVssFunctionTracer **)(pCVar8 + 0x60)) {
      if (*(ushort **)(pCVar8 + (longlong)iVar7 * 8 + 0x40) != (ushort *)0x0) {
        pbVar2 = (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                  *)std::
                    basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                    ::
                    __0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
                              (local_108,*(ushort **)(pCVar8 + (longlong)iVar7 * 8 + 0x40));
        std::
        basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
        ::
        _append___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                  ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                    *)(local_d8 + (longlong)iVar7 * 0x28),pbVar2,_Var9,(__uint64)pcVar10);
        if (7 < local_e8) {
          operator_delete__(local_100);
        }
      }
    }
  }
  for (iVar7 = 0; iVar7 < 4; iVar7 = iVar7 + 1) {
    lVar3 = (longlong)iVar7;
    if (auStack_c0[lVar3 * 5] != 0) {
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z
                ((CVssAutoCoString *)local_128,(ushort *)L"\n\n");
      if (iVar7 == 0) {
        this_00 = (CVssResource *)0x0;
      }
      else if (iVar7 == 1) {
        this_00 = (CVssResource *)0x0;
      }
      else {
        this_00 = (CVssResource *)(ulonglong)(iVar7 - 2);
      }
      lVar4 = CVssResource::
              _LoadStringW_CVssResource__QEAA_AV__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__I_Z
                        (this_00,(uint)local_108);
      puVar6 = (ushort *)(lVar4 + 8);
      if (7 < *(ulonglong *)(lVar4 + 0x20)) {
        puVar6 = *(ushort **)puVar6;
      }
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z((CVssAutoCoString *)local_128,puVar6);
      if (7 < local_e8) {
        operator_delete__(local_100);
      }
      puVar6 = local_d0 + lVar3 * 0x14;
      if (7 < auStack_c0[lVar3 * 5 + 1]) {
        puVar6 = *(ushort **)puVar6;
      }
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z((CVssAutoCoString *)local_128,puVar6);
    }
  }
  _eh_vector_destructor_iterator_
            (local_d8,0x28,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ);
  CoTaskMemFree((LPVOID)0x0);
  return local_128[0];
}


