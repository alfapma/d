/*
 * Function : dtor$17
 * Address  : 0x1400157b3
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$17(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::ParseCmdLine'::__l1::dtor_17(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 600));
  return;
}


