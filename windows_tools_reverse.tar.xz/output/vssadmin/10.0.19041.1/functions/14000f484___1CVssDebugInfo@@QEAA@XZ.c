/*
 * Function : ??1CVssDebugInfo@@QEAA@XZ
 * Address  : 0x14000f484
 * Size     : 73 bytes (20 instructions)
 * Prototype: void ??1CVssDebugInfo@@QEAA@XZ(CVssDebugInfo * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssDebugInfo::~CVssDebugInfo(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssDebugInfo::~CVssDebugInfo(void) __ptr64 */

void __thiscall CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(CVssDebugInfo *this)

{
  CVssDebugInfo *pCVar1;
  longlong lVar2;
  
  if (this[0xa3] != (CVssDebugInfo)0x0) {
    pCVar1 = this + 0x28;
    lVar2 = 0xf;
    do {
      if (*(LPVOID *)pCVar1 != (LPVOID)0x0) {
        CoTaskMemFree(*(LPVOID *)pCVar1);
        *(undefined8 *)pCVar1 = 0;
      }
      pCVar1 = pCVar1 + 8;
      lVar2 = lVar2 + -1;
    } while (lVar2 != 0);
  }
  return;
}


