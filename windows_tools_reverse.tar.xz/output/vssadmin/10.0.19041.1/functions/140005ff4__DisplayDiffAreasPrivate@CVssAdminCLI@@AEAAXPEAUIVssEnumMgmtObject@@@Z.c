/*
 * Function : ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z
 * Address  : 0x140005ff4
 * Size     : 1131 bytes (267 instructions)
 * Prototype: void ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z(CVssAdminCLI * this, IVssEnumMgmtObject * param_1)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DisplayDiffAreasPrivate(struct IVssEnumMgmtObject * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: void __cdecl CVssAdminCLI::DisplayDiffAreasPrivate(struct IVssEnumMgmtObject * __ptr64)
   __ptr64 */

void __thiscall
CVssAdminCLI::_DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z
          (CVssAdminCLI *this,IVssEnumMgmtObject *param_1)

{
  undefined1 auVar1 [16];
  ushort *pv;
  ushort *pv_00;
  ushort *pv_01;
  ushort *pv_02;
  __uint64 _Var2;
  ushort *pv_03;
  ushort *pv_04;
  CVssAdminCLI *this_00;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined1 local_res18 [8];
  ushort *local_res20;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdb8;
  ushort *puVar6;
  undefined **local_218;
  ushort *local_210;
  undefined **local_208;
  ushort *local_200;
  undefined **local_1f8;
  ushort *local_1f0;
  undefined **local_1e8;
  ushort *local_1e0;
  undefined **local_1d8;
  ushort *local_1d0;
  ushort *local_1c8;
  undefined **local_1c0;
  ushort *local_1b8;
  undefined **local_1b0;
  undefined8 local_1a8;
  undefined **local_1a0;
  undefined8 local_198;
  undefined1 local_190 [8];
  ushort *local_188;
  ushort *local_180;
  ulonglong local_178;
  ulonglong local_170;
  ulonglong local_168;
  undefined8 local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  CVssFunctionTracer local_a8 [8];
  int local_a0;
  
  local_160 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_150 = L"CVssAdminCLI::DisplayDiffAreasPrivate";
  local_148 = L"ADMPROCC";
  local_140 = 0x255;
  local_13c = 7;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  local_a0 = (**(code **)(*(longlong *)param_1 + 0x18))(param_1,1,local_190,local_res18);
  pv = local_188;
  pv_00 = local_180;
  while( true ) {
    if (local_a0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_158,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::DisplayDiffAreasPrivate",0x260,7,
                 in_stack_fffffffffffffdb8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_a8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_a8);
    }
    if (local_a0 == 1) break;
    local_1a0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1b0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_188 = pv;
    local_180 = pv_00;
    local_1d0 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_168,1);
    local_1d8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1e0 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_170,1);
    local_1e8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    pv_02 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_178,1);
    local_1c0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1b8 = pv_02;
    local_1c8 = _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,pv);
    this_00 = this;
    local_res20 = _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,pv_00);
    _Var2 = _GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(this_00,pv_00);
    local_1f0 = (ushort *)0x0;
    local_1f8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_200 = (ushort *)0x0;
    local_208 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_210 = (ushort *)0x0;
    local_218 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    if (_Var2 == 0) {
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_1f8,
                 (ushort *)L"0");
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_208,
                 (ushort *)L"0");
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_218,
                 (ushort *)L"0");
      pv_04 = local_200;
      pv_03 = local_1f0;
    }
    else {
      auVar1._8_8_ = 0;
      auVar1._0_8_ = _Var2;
      lVar3 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1,8);
      uVar5 = (_Var2 - lVar3 >> 1) + lVar3 >> 6;
      uVar4 = 100;
      if ((longlong)(local_168 / uVar5) < 0xffffffff) {
        uVar4 = local_168 / uVar5;
      }
      pv_03 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
      uVar4 = 100;
      if ((longlong)(local_170 / uVar5) < 0xffffffff) {
        uVar4 = local_170 / uVar5;
      }
      local_1f0 = pv_03;
      pv_04 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
      uVar4 = 100;
      if ((longlong)(local_178 / uVar5) < 0xffffffff) {
        uVar4 = local_178 / uVar5;
      }
      local_200 = pv_04;
      local_210 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
    }
    pv_01 = local_210;
    puVar6 = local_1d0;
    _OutputMsg_CVssAdminCLI__AEAAXJZZ
              (this,0x40002758,local_1c8,pv,local_res20,pv_00,local_1d0,pv_03,local_1e0,pv_04,pv_02,
               local_210);
    in_stack_fffffffffffffdb8 = (_VSSDBG_SEV_ENUM)puVar6;
    if (pv_01 != (ushort *)0x0) {
      CoTaskMemFree(pv_01);
    }
    local_210 = (ushort *)0x0;
    local_218 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_04 != (ushort *)0x0) {
      CoTaskMemFree(pv_04);
    }
    local_200 = (ushort *)0x0;
    local_208 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_03 != (ushort *)0x0) {
      CoTaskMemFree(pv_03);
    }
    local_1f0 = (ushort *)0x0;
    local_1f8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_02 != (ushort *)0x0) {
      CoTaskMemFree(pv_02);
    }
    local_1b8 = (ushort *)0x0;
    local_1c0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (local_1e0 != (ushort *)0x0) {
      CoTaskMemFree(local_1e0);
    }
    local_1e0 = (ushort *)0x0;
    local_1e8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (local_1d0 != (ushort *)0x0) {
      CoTaskMemFree(local_1d0);
    }
    local_1d0 = (ushort *)0x0;
    local_1d8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_00 != (ushort *)0x0) {
      CoTaskMemFree(pv_00);
    }
    local_1a8 = 0;
    local_1b0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv != (ushort *)0x0) {
      CoTaskMemFree(pv);
    }
    local_198 = 0;
    local_1a0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    local_a0 = (**(code **)(*(longlong *)param_1 + 0x18))(param_1,1,local_190,local_res18);
    pv = local_188;
    pv_00 = local_180;
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}


