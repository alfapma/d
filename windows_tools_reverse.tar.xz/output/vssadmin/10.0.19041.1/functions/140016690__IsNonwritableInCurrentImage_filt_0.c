/*
 * Function : _IsNonwritableInCurrentImage$filt$0
 * Address  : 0x140016690
 * Size     : 31 bytes (11 instructions)
 * Prototype: bool _IsNonwritableInCurrentImage$filt$0(undefined8 * param_1)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

bool _IsNonwritableInCurrentImage_filt_0(undefined8 *param_1)

{
  return *(int *)*param_1 == -0x3ffffffb;
}


