/*
 * Function : ?what@logic_error@std@@UEBAPEBDXZ
 * Address  : 0x1400153e0
 * Size     : 15 bytes (5 instructions)
 * Prototype: char * ?what@logic_error@std@@UEBAPEBDXZ(logic_error * this)
 * CC       : __thiscall
 * Comment  : public: virtual char const * __ptr64 __cdecl std::logic_error::what(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual char const * __ptr64 __cdecl std::logic_error::what(void)const __ptr64 */

char * __thiscall std::logic_error::_what_logic_error_std__UEBAPEBDXZ(logic_error *this)

{
  logic_error *plVar1;
  
  plVar1 = this + 0x20;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    plVar1 = *(logic_error **)plVar1;
  }
  return (char *)plVar1;
}


