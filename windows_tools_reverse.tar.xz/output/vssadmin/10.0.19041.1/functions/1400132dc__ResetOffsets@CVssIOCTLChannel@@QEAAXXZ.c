/*
 * Function : ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ
 * Address  : 0x1400132dc
 * Size     : 9 bytes (3 instructions)
 * Prototype: void ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ(CVssIOCTLChannel * this)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssIOCTLChannel::ResetOffsets(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssIOCTLChannel::ResetOffsets(void) __ptr64 */

void __thiscall CVssIOCTLChannel::_ResetOffsets_CVssIOCTLChannel__QEAAXXZ(CVssIOCTLChannel *this)

{
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  return;
}


