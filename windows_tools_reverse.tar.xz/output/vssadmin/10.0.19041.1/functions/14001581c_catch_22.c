/*
 * Function : catch$22
 * Address  : 0x14001581c
 * Size     : 87 bytes (19 instructions)
 * Prototype: undefined * catch$22(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssAdminCLI::Main'::__l1::catch_22(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x188),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002bf6;
}


