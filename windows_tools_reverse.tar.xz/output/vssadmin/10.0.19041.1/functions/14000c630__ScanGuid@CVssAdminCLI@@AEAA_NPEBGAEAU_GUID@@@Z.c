/*
 * Function : ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z
 * Address  : 0x14000c630
 * Size     : 189 bytes (42 instructions)
 * Prototype: bool ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2)
 * CC       : __thiscall
 * Comment  : private: bool __cdecl CVssAdminCLI::ScanGuid(unsigned short const * __ptr64,struct _GUID & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: bool __cdecl CVssAdminCLI::ScanGuid(unsigned short const * __ptr64,struct _GUID &
   __ptr64) __ptr64 */

bool __thiscall
CVssAdminCLI::_ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z
          (CVssAdminCLI *this,ushort *param_1,_GUID *param_2)

{
  HRESULT HVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_110 = 0x119;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_10c = 7;
  local_108 = 0xff;
  local_88 = 0x1000000;
  local_120 = L"CVssAdminCLI::ScanGuid";
  local_118 = L"ADMUTILC";
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  HVar1 = CLSIDFromString((LPCOLESTR)param_1,param_2);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return -1 < HVar1;
}


