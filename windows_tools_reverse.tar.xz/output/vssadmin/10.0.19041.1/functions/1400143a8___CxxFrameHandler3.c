/*
 * Function : __CxxFrameHandler3
 * Address  : 0x1400143a8
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined __CxxFrameHandler3()
 * CC       : unknown
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void __CxxFrameHandler3(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001400143a8. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  __CxxFrameHandler3();
  return;
}


