/*
 * Function : ?Initialize@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140001cd0
 * Size     : 782 bytes (177 instructions)
 * Prototype: void ?Initialize@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::Initialize(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::Initialize(void) __ptr64 */

void __thiscall CVssAdminCLI::_Initialize_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  DWORD DVar1;
  DWORD DVar2;
  DWORD DVar3;
  HANDLE pvVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  CVssFunctionTracer *pCVar8;
  undefined **ppuVar9;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  _VSSDBG_SEV_ENUM _Var10;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  undefined8 local_a0;
  CVssFunctionTracer local_98 [8];
  HRESULT local_90;
  
  local_a0 = 0xfffffffffffffffe;
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_140 = L"CVssAdminCLI::Initialize";
  local_138 = L"ADMVADMC";
  local_130 = 0x19b;
  local_12c = 7;
  local_128 = 0xff;
  puVar6 = (undefined8 *)0x0;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  SetThreadUILanguage(0);
  pvVar4 = GetStdHandle(0xfffffff5);
  *(HANDLE *)(this + 8) = pvVar4;
  if (pvVar4 == (HANDLE)0xffffffffffffffff) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_148,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::Initialize",0x1a7,7,
                       in_stack_fffffffffffffe98);
    DVar2 = GetLastError();
    DVar3 = GetLastError();
    DVar1 = DVar2 & 0xffff | 0x80070000;
    if ((int)DVar2 < 1) {
      DVar1 = DVar2;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar7,DVar1,L"Initialize - Error from GetStdHandle(), rc: %d",DVar3);
  }
  local_90 = CoInitializeEx((LPVOID)0x0,0);
  if (local_90 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::Initialize",0x1af,7,in_stack_fffffffffffffe98);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  this[0xf0] = (CVssAdminCLI)0x1;
  _Var10 = 0;
  local_90 = CoInitializeSecurity
                       ((PSECURITY_DESCRIPTOR)0x0,-1,(SOLE_AUTHENTICATION_SERVICE *)0x0,(void *)0x0,
                        6,2,(void *)0x0,0,(void *)0x0);
  if (local_90 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::Initialize",0x1c1,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_140 = L"CVssAdminCLI::Initialize";
  local_138 = L"ADMVADMC";
  local_130 = 0x1c6;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  pCVar8 = local_98;
  CVssFunctionTracer::_ComDisableSEH_CVssFunctionTracer__QEAAXUCVssDebugInfo___Z
            (local_98,&local_148);
  AssertPrivilege((ushort *)pCVar8);
  if (dCurrentSKU == 0xfffffff8) {
    puVar5 = operator_new(8,&std::nothrow);
    if (puVar5 == (undefined8 *)0x0) goto LAB_140001e7f;
    ppuVar9 = &CInternalVerifier::_vftable_;
    puVar6 = puVar5;
  }
  else {
    puVar5 = operator_new(8,&std::nothrow);
    if (puVar5 == (undefined8 *)0x0) goto LAB_140001e7f;
    ppuVar9 = &CExternalVerifier::_vftable_;
    puVar6 = puVar5;
  }
  *puVar6 = ppuVar9;
LAB_140001e7f:
  *(undefined8 **)this = puVar6;
  if (puVar6 == (undefined8 *)0x0) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_148,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::Initialize",0x1d2,7,_Var10);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar7,0x8007000e,L"Out of memory");
  }
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002710);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return;
}


