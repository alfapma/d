/*
 * Function : ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_K0@Z
 * Address  : 0x140012694
 * Size     : 288 bytes (82 instructions)
 * Prototype: void ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Copy(unsigned __int64,unsigned
   __int64) __ptr64 */

void __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,__uint64 param_2)

{
  undefined1 auVar1 [16];
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *_Dst;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  bad_alloc local_60 [56];
  
  uVar5 = param_1 | 7;
  if (uVar5 < 0x7fffffffffffffff) {
    uVar4 = *(ulonglong *)(this + 0x20);
    uVar3 = uVar4 >> 1;
    param_1 = uVar5;
    if ((uVar5 / 3 < uVar3) && (uVar4 <= 0x7ffffffffffffffe - uVar3)) {
      param_1 = uVar3 + uVar4;
    }
  }
  uVar5 = param_1 + 1;
  uVar4 = 0;
  if ((uVar5 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = uVar5, uVar4 = uVar5,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 2)) {
    bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(local_60,(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_60,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  _Dst = operator_new(uVar4 * 2);
  if (param_2 != 0) {
    pbVar2 = this + 8;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar2;
    }
    memcpy_s(_Dst,param_1 * 2 + 2,pbVar2,param_2 * 2);
  }
  if (7 < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
    **)(this + 8) = _Dst;
  *(__uint64 *)(this + 0x20) = param_1;
  *(__uint64 *)(this + 0x18) = param_2;
  pbVar2 = this + 8;
  if (7 < param_1) {
    pbVar2 = _Dst;
  }
  *(undefined2 *)(pbVar2 + param_2 * 2) = 0;
  return;
}


