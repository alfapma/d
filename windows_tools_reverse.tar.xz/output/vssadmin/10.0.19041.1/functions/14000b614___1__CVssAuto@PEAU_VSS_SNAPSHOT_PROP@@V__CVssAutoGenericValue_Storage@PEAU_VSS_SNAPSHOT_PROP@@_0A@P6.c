/*
 * Function : ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ
 * Address  : 0x14000b614
 * Size     : 61 bytes (16 instructions)
 * Prototype: void ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >::~CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >::~CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >(void) __ptr64 */

void __thiscall
CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
::
__1__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAA_XZ
          (CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
           *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(longlong *)(this + 8) != 0) {
    VssFreeSnapshotPropertiesInternal();
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}


