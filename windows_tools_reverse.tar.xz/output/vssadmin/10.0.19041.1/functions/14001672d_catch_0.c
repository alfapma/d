/*
 * Function : catch$0
 * Address  : 0x14001672d
 * Size     : 39 bytes (11 instructions)
 * Prototype: undefined catch$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::_Copy'::__l1::
     catch_0(undefined8 param_1,longlong param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)
              (param_2 + 0x90),true,0);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException((void *)0x0,(ThrowInfo *)0x0);
}


