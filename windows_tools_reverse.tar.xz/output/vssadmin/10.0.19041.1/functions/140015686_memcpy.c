/*
 * Function : memcpy
 * Address  : 0x140015686
 * Size     : 6 bytes (1 instructions)
 * Prototype: void * memcpy(void * _Dst, void * _Src, size_t _Size)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void * __cdecl memcpy(void *_Dst,void *_Src,size_t _Size)

{
  void *pvVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140015686. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = memcpy(_Dst,_Src,_Size);
  return pvVar1;
}


