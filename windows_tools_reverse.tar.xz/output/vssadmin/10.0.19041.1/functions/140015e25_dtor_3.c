/*
 * Function : dtor$3
 * Address  : 0x140015e25
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$3(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::DeleteDiffAreas'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x50));
  return;
}


