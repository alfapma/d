/*
 * Function : ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ
 * Address  : 0x140003464
 * Size     : 40 bytes (11 instructions)
 * Prototype: void ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ(CComPtr<IVssEnumObject> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void)
   __ptr64 */

void __thiscall
ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
          (CComPtr<IVssEnumObject> *this)

{
  if (*(longlong **)this != (longlong *)0x0) {
    (**(code **)(**(longlong **)this + 0x10))();
  }
  return;
}


