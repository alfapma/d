/*
 * Function : entry
 * Address  : 0x140014390
 * Size     : 18 bytes (4 instructions)
 * Prototype: undefined entry(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void entry(void)

{
  __security_init_cookie();
  __wmainCRTStartup();
  return;
}


