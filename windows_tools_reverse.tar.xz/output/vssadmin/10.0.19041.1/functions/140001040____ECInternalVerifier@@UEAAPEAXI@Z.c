/*
 * Function : ??_ECInternalVerifier@@UEAAPEAXI@Z
 * Address  : 0x140001040
 * Size     : 38 bytes (12 instructions)
 * Prototype: void * ??_ECInternalVerifier@@UEAAPEAXI@Z(CInternalVerifier * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl CInternalVerifier::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void * __ptr64 __cdecl CInternalVerifier::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
CInternalVerifier::___ECInternalVerifier__UEAAPEAXI_Z(CInternalVerifier *this,uint param_1)

{
  *(undefined ***)this = &CCommandVerifier::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


