/*
 * Function : pre_cpp_init
 * Address  : 0x140014170
 * Size     : 73 bytes (13 instructions)
 * Prototype: undefined pre_cpp_init(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void pre_cpp_init(void)

{
  _DAT_140024164 = _newmode;
  _DAT_14002414c =
       __wgetmainargs(&DAT_140024148,&DAT_140024150,&DAT_140024158,_dowildcard,&DAT_140024164);
  return;
}


