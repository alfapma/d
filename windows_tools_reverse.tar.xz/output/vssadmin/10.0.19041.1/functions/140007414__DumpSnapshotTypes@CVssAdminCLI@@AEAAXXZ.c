/*
 * Function : ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140007414
 * Size     : 244 bytes (58 instructions)
 * Prototype: void ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DumpSnapshotTypes(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::DumpSnapshotTypes(void) __ptr64 */

void __thiscall CVssAdminCLI::_DumpSnapshotTypes_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  longlong lVar1;
  undefined **ppuVar2;
  longlong lVar3;
  undefined8 in_R9;
  undefined8 uVar4;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  uVar4 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_128 = L"CVssAdminCLI::DumpSnapshotTypes";
  local_120 = L"ADMPROCC";
  local_118 = 0x3ab;
  local_114 = 7;
  local_110 = 0xff;
  lVar1 = 0;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  if (true) {
    ppuVar2 = &g_asAdmTypeNames;
    lVar3 = lVar1;
    do {
      if ((dCurrentSKU & *(uint *)((longlong)&DAT_1400171f8 + lVar1)) != 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ
                  (this,*(long *)((longlong)&DAT_140017200 + lVar1),*ppuVar2,in_R9,uVar4);
      }
      lVar3 = lVar3 + 1;
      lVar1 = lVar3 * 0x18;
      ppuVar2 = &g_asAdmTypeNames + lVar3 * 3;
    } while (*ppuVar2 != (undefined *)0x0);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}


