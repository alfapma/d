/*
 * Function : dtor$1
 * Address  : 0x1400166b6
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `std::length_error::length_error'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  exception::__1exception__UEAA_XZ(*(exception **)(param_2 + 0x40));
  return;
}


