/*
 * Function : ??_Gbad_alloc@std@@UEAAPEAXI@Z
 * Address  : 0x14000ee20
 * Size     : 57 bytes (17 instructions)
 * Prototype: void * ??_Gbad_alloc@std@@UEAAPEAXI@Z(bad_alloc * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl std::bad_alloc::`scalar deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void * __ptr64 __cdecl std::bad_alloc::`scalar deleting destructor'(unsigned int)
   __ptr64 */

void * __thiscall std::bad_alloc::___Gbad_alloc_std__UEAAPEAXI_Z(bad_alloc *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  exception::__1exception__UEAA_XZ((exception *)this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


