/*
 * Function : ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ
 * Address  : 0x140001fec
 * Size     : 2046 bytes (441 instructions)
 * Prototype: int ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::ParseCmdLine(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: int __cdecl CVssAdminCLI::ParseCmdLine(void) __ptr64 */

int __thiscall CVssAdminCLI::_ParseCmdLine_CVssAdminCLI__AEAAHXZ(CVssAdminCLI *this)

{
  LPVOID pvVar1;
  bool bVar2;
  long lVar3;
  int iVar4;
  ushort *puVar5;
  ushort *puVar6;
  wchar_t *pwVar7;
  longlong lVar8;
  undefined8 uVar9;
  wchar_t *pwVar10;
  CVssAdminCLI *pCVar11;
  ulonglong uVar12;
  longlong lVar13;
  undefined **ppuVar14;
  CVssAdminCLI *pCVar15;
  ulonglong uVar16;
  uint uVar17;
  ulonglong uVar18;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffde8;
  wchar_t *local_208;
  wchar_t *local_200;
  wchar_t *local_1f8;
  undefined4 local_1f0;
  undefined4 local_1ec;
  undefined4 local_1e8;
  undefined1 local_1e0 [120];
  undefined4 local_168;
  CVssFunctionTracer local_158 [8];
  long local_150;
  undefined8 local_e8;
  CVssDebugInfo local_e0 [168];
  
  local_e8 = 0xfffffffffffffffe;
  local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_200 = L"CVssAdminCLI::ParseCmdLine";
  local_1f8 = L"ADMVADMC";
  local_1f0 = 0x1e8;
  local_1ec = 7;
  local_1e8 = 0xff;
  uVar12 = 0;
  local_168 = 0x1000000;
  memset(local_1e0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_208);
  _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,true);
  puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
  if (puVar5 == (ushort *)0x0) {
LAB_140002548:
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_e0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x1f9,7,
                       in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_158,uVar9,0x1002,L"Incomplete command");
  }
  if ((((*puVar5 == 0x2f) && (puVar5[1] == 0x3f)) && (puVar5[2] == 0)) ||
     (((*puVar5 == 0x2d && (puVar5[1] == 0x3f)) && (puVar5[2] == 0)))) {
LAB_140002275:
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
    iVar4 = 0;
  }
  else {
    pCVar15 = this;
    puVar6 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    if (puVar6 == (ushort *)0x0) goto LAB_140002548;
    ppuVar14 = &g_asAdmCommands;
    uVar16 = uVar12;
    do {
      uVar17 = (uint)uVar16;
      if ((((dCurrentSKU & *(uint *)((longlong)ppuVar14 + 0x14)) != 0) &&
          (bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar15,puVar5,(ushort *)*ppuVar14), bVar2))
         && (bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar15,puVar6,(ushort *)ppuVar14[1]), bVar2
            )) break;
      uVar17 = uVar17 + 1;
      uVar16 = (ulonglong)uVar17;
      ppuVar14 = ppuVar14 + 0xc;
    } while ((longlong)ppuVar14 < 0x140017ae0);
    if (uVar17 == 0x16) {
      uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_208,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                         (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x20e,7,
                         in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_158,uVar9,0x1002,L"Invalid command");
    }
    *(uint *)(this + 0x58) = uVar17;
    *(uint *)(this + 0x60) = uVar17;
    puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    while (puVar5 != (ushort *)0x0) {
      if ((*puVar5 - 0x2d & 0xfffd) != 0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x26a,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1002,L"Invalid command");
      }
      pCVar15 = (CVssAdminCLI *)(puVar5 + 1);
      if (*(short *)pCVar15 == 0x3f) goto LAB_140002275;
      pCVar11 = pCVar15;
      pwVar7 = wcschr((wchar_t *)pCVar15,L'=');
      if (pwVar7 != (wchar_t *)0x0) {
        *pwVar7 = L'\0';
        pwVar7 = pwVar7 + 1;
      }
      ppuVar14 = &PTR_u_All_140017b48;
      uVar16 = uVar12;
      uVar18 = uVar12;
      do {
        uVar17 = (uint)uVar16;
        bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar11,(ushort *)*ppuVar14,(ushort *)pCVar15);
        if (bVar2) break;
        uVar17 = uVar17 + 1;
        uVar16 = (ulonglong)uVar17;
        uVar18 = uVar18 + 1;
        ppuVar14 = ppuVar14 + 3;
      } while ((longlong)ppuVar14 < 0x140017c98);
      if (uVar17 == 0xe) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x246,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1003,L"Invalid option: %s",pCVar15);
      }
      pCVar11 = this + uVar18 * 8 + 0x68;
      if (*(ushort **)pCVar11 != (ushort *)0x0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x24c,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1005,L"Duplicate option given: %s",pCVar15);
      }
      if (*(int *)(&DAT_1400172c4 + (uVar18 + (longlong)*(int *)(this + 0x60) * 0x18) * 4) == 0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x252,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1006,L"Option not allowed for this command: %s",pCVar15);
      }
      if ((&DAT_140017b50)[uVar18 * 6] == 0) {
        if (pwVar7 != (wchar_t *)0x0) {
LAB_1400024e7:
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_208,
                             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                             (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x259,7,
                             in_stack_fffffffffffffde8);
          pwVar10 = L"<MISSING>";
          if (pwVar7 != (wchar_t *)0x0) {
            pwVar10 = pwVar7;
          }
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x1004,L"Invalid option value: /%s=%s",pCVar15,pwVar10);
        }
      }
      else if ((pwVar7 == (wchar_t *)0x0) || (*pwVar7 == L'\0')) goto LAB_1400024e7;
      if ((&DAT_140017b50)[uVar18 * 6] == 0) {
        pwVar7 = L"TRUE";
LAB_14000224d:
        VssSafeDuplicateStr(local_158,(ushort **)pCVar11,(ushort *)pwVar7);
      }
      else {
        if (pwVar7 != (wchar_t *)0x0) goto LAB_14000224d;
        *(ushort **)pCVar11 = (ushort *)0x0;
      }
      puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    }
    pCVar15 = this + 0x68;
    do {
      if ((*(longlong *)pCVar15 == 0) &&
         (*(int *)(&DAT_1400172c4 + (uVar12 + (longlong)*(int *)(this + 0x60) * 0x18) * 4) == 1)) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x275,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1007,L"Required option missing");
      }
      uVar12 = uVar12 + 1;
      pCVar15 = pCVar15 + 8;
    } while ((longlong)uVar12 < 0xe);
    pvVar1 = *(LPVOID *)(this + 0x80);
    if (pvVar1 != (LPVOID)0x0) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
      if (*(short *)((longlong)pvVar1 + lVar8 * 2 + -2) != 0x5c) {
        lVar8 = -1;
        do {
          lVar8 = lVar8 + 1;
        } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
        puVar5 = CoTaskMemRealloc(pvVar1,(longlong)((int)lVar8 + 2) * 2);
        if (puVar5 == (ushort *)0x0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_208,
                             (ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                             (ushort *)L"VssReallocString",0x85,0xb,in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x8007000e,L"Memory allocation error");
        }
        lVar8 = -1;
        do {
          lVar13 = lVar8;
          lVar8 = lVar13 + 1;
        } while (puVar5[lVar8] != 0);
        lVar3 = StringCchCatW(puVar5,lVar13 + 3,(ushort *)L"\\");
        local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
        local_200 = L"CVssAdminCLI::ParseCmdLine";
        local_1f8 = L"ADMVADMC";
        local_1f0 = 0x286;
        local_1ec = 7;
        local_1e8 = 0xff;
        local_168 = 0x1000000;
        local_150 = lVar3;
        memset(local_1e0,0,0x78);
        if (lVar3 < 0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e0,(CVssDebugInfo *)&local_208);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar9,lVar3,L"StringCchCat");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_208);
        *(ushort **)(this + 0x80) = puVar5;
      }
    }
    pvVar1 = *(LPVOID *)(this + 0xa0);
    if (pvVar1 != (LPVOID)0x0) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
      if (*(short *)((longlong)pvVar1 + lVar8 * 2 + -2) != 0x5c) {
        lVar8 = -1;
        do {
          lVar8 = lVar8 + 1;
        } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
        puVar5 = CoTaskMemRealloc(pvVar1,(longlong)((int)lVar8 + 2) * 2);
        lVar8 = -1;
        if (puVar5 == (ushort *)0x0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            (local_e0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
                             (ushort *)L"INCSTRH",(ushort *)L"VssReallocString",0x85,0xb,
                             in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x8007000e,L"Memory allocation error");
        }
        do {
          lVar13 = lVar8;
          lVar8 = lVar13 + 1;
        } while (puVar5[lVar8] != 0);
        lVar3 = StringCchCatW(puVar5,lVar13 + 3,(ushort *)L"\\");
        local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
        local_200 = L"CVssAdminCLI::ParseCmdLine";
        local_1f8 = L"ADMVADMC";
        local_1f0 = 0x293;
        local_1ec = 7;
        local_1e8 = 0xff;
        local_168 = 0x1000000;
        local_150 = lVar3;
        memset(local_1e0,0,0x78);
        if (lVar3 < 0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e0,(CVssDebugInfo *)&local_208);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar9,lVar3,L"StringCchCat");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_208);
        *(ushort **)(this + 0xa0) = puVar5;
      }
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
    iVar4 = 1;
  }
  return iVar4;
}


