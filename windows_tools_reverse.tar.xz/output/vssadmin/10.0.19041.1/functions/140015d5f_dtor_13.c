/*
 * Function : dtor$13
 * Address  : 0x140015d5f
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$13(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_13(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x68));
  return;
}


