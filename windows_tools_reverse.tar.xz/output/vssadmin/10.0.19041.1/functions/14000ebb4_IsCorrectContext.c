/*
 * Function : IsCorrectContext
 * Address  : 0x14000ebb4
 * Size     : 85 bytes (25 instructions)
 * Prototype: int IsCorrectContext(long param_1)
 * CC       : __cdecl
 * Comment  : int __cdecl IsCorrectContext(long)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* int __cdecl IsCorrectContext(long) */

int __cdecl IsCorrectContext(long param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (CVssSKU::ms_bInitialized == 0) {
    CVssSKU::_Initialize_CVssSKU__CAXXZ();
  }
  if ((((CVssSKU::ms_eSKU == 1) && (((param_1 & 0x1fU) - 9 & 0xfffffffb) == 0)) ||
      ((dCurrentSKU & 0xfffffff8) != 0)) || ((param_1 & 0x1fU) == 0x1d)) {
    iVar1 = 1;
  }
  return iVar1;
}


