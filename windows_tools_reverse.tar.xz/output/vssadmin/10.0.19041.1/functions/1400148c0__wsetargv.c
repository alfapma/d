/*
 * Function : _wsetargv
 * Address  : 0x1400148c0
 * Size     : 3 bytes (2 instructions)
 * Prototype: int _wsetargv(_exception * _Except)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

int __cdecl _wsetargv(_exception *_Except)

{
  return 0;
}


