/*
 * Function : ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z
 * Address  : 0x14000b90c
 * Size     : 193 bytes (46 instructions)
 * Prototype: void ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >::CopyFrom(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64>
   >::CopyFrom(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
_CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
          (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this,ushort *param_1)

{
  long lVar1;
  ushort *puVar2;
  longlong lVar3;
  undefined4 local_res8 [2];
  longlong lVar4;
  
  lVar3 = -1;
  do {
    lVar4 = lVar3;
    lVar3 = lVar4 + 1;
  } while (param_1[lVar3] != 0);
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  puVar2 = CoTaskMemAlloc(lVar3 * 2 + 2);
  *(ushort **)(this + 8) = puVar2;
  if (puVar2 != (ushort *)0x0) {
    lVar1 = StringCchCopyW(puVar2,lVar4 + 2,param_1);
    if (-1 < lVar1) {
      return;
    }
    CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
    ::
    _Close___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEAAXXZ
              ((CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
                *)this);
    local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
  }
  local_res8[0] = 0x8007000e;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
}


