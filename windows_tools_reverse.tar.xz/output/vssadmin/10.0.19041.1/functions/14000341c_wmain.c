/*
 * Function : wmain
 * Address  : 0x14000341c
 * Size     : 64 bytes (18 instructions)
 * Prototype: int wmain(int _Argc, wchar_t * * _Argv, wchar_t * * _Env)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

int __cdecl wmain(int _Argc,wchar_t **_Argv,wchar_t **_Env)

{
  long lVar1;
  
  Ordinal_1();
  lVar1 = CVssAdminCLI::_Main_CVssAdminCLI__SAJHQEAPEAG_Z(_Argc,(ushort **)_Argv);
  Ordinal_2();
  return lVar1;
}


