/*
 * Function : ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z
 * Address  : 0x140012080
 * Size     : 282 bytes (71 instructions)
 * Prototype: void ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z(CVssFunctionTracer * this, exception * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::HandleStdGenericException(class exception const & __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::HandleStdGenericException(class exception const &
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const *
   __ptr64,unsigned long,unsigned long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
          (CVssFunctionTracer *this,exception *param_1,ushort *param_2,ushort *param_3,
          ushort *param_4,ulong param_5,ulong param_6)

{
  long lVar1;
  undefined8 uVar2;
  ushort *local_d8;
  ushort *local_d0;
  ushort *local_c8;
  ulong local_c0;
  ulong local_bc;
  undefined4 local_b8;
  undefined1 local_b0 [120];
  undefined4 local_38;
  
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  uVar2 = (**(code **)(*(longlong *)param_1 + 8))(param_1);
  lVar1 = _TranslateGenericErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__JPEBGZZ
                    (this,&local_d8,0x80042302,L"Unexpected STL exception caught: %s",uVar2);
  *(long *)(this + 8) = lVar1;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  uVar2 = (**(code **)(*(longlong *)param_1 + 8))(param_1);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_d8,L"Unexpected STL exception caught: %s",uVar2);
  return;
}


