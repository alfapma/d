/*
 * Function : ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ
 * Address  : 0x14000fc78
 * Size     : 316 bytes (83 instructions)
 * Prototype: void ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ(CVssDebugInfo param_1, ulong param_2, ushort * param_3, ushort * param_4, ...)
 * CC       : __cdecl
 * Comment  : public: static void __cdecl CVssFunctionTracer::StaticTrace(struct CVssDebugInfo,unsigned long,unsigned short const * __ptr64,unsigned short const * __ptr64,...)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: static void __cdecl CVssFunctionTracer::StaticTrace(struct CVssDebugInfo,unsigned
   long,unsigned short const * __ptr64,unsigned short const * __ptr64,...) */

void __cdecl
CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
          (CVssDebugInfo *param_1,undefined4 param_2,undefined8 param_3,ushort *param_4,...)

{
  int iVar1;
  wchar_t *pwVar2;
  undefined4 uVar3;
  ulong in_stack_ffffffffffffff78;
  wchar_t *pwVar4;
  CVssFunctionTracer *local_58;
  __uint64 local_50;
  ushort *local_48 [3];
  
  iVar1 = Ordinal_5();
  if (iVar1 != 0) {
    local_58 = (CVssFunctionTracer *)0x0;
    iVar1 = Ordinal_10(&local_58);
    if (-1 < iVar1) {
      uVar3 = 0;
      if (local_58 != (CVssFunctionTracer *)0x0) {
        iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(local_58,*(ulong *)(param_1 + 0x1c));
        if (iVar1 == 0) goto LAB_14000fd9f;
        uVar3 = *(undefined4 *)(local_58 + 0x30);
      }
      pwVar2 = operator_new__(0x3ea,&std::nothrow);
      if (pwVar2 == (wchar_t *)0x0) {
        pwVar4 = L"StaticTrace failed due to out of memory condition";
      }
      else {
        local_50 = 0;
        local_48[0] = (ushort *)0x0;
        StringCchVPrintfExW((ushort *)pwVar2,500,local_48,&local_50,in_stack_ffffffffffffff78,
                            param_4,&stack0x00000028);
        pwVar4 = pwVar2;
        if (local_50 == 1) {
          local_48[0][-2] = 0x2e;
          local_48[0][-1] = 0x2e;
          local_48[0][-3] = 0x2e;
        }
      }
      Ordinal_3(*(undefined8 *)param_1,*(undefined8 *)(param_1 + 0x10),
                *(undefined4 *)(param_1 + 0x18),uVar3,*(undefined4 *)(param_1 + 0x1c),param_3,
                L"STATIC",param_2,pwVar4);
      operator_delete__(pwVar2);
    }
  }
LAB_14000fd9f:
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_1);
  return;
}


