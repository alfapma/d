/*
 * Function : ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z
 * Address  : 0x140011efc
 * Size     : 245 bytes (64 instructions)
 * Prototype: void ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z(CVssFunctionTracer * this, _com_error * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::HandleComException(class _com_error & __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::HandleComException(class _com_error & __ptr64,unsigned
   short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned
   long,unsigned long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
          (CVssFunctionTracer *this,_com_error *param_1,ushort *param_2,ushort *param_3,
          ushort *param_4,ulong param_5,ulong param_6)

{
  undefined4 uVar1;
  long lVar2;
  ushort *local_d8;
  ushort *local_d0;
  ushort *local_c8;
  ulong local_c0;
  ulong local_bc;
  undefined4 local_b8;
  undefined1 local_b0 [120];
  undefined4 local_38;
  
  uVar1 = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(this + 8) = uVar1;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  lVar2 = _TranslateComErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__PEBGZZ
                    (this,&local_d8,L"Unexpected COM exception caught: hr: 0x%x",uVar1);
  *(long *)(this + 8) = lVar2;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_d8,L"COM error caught: hr: 0x%x",lVar2);
  return;
}


