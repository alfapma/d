/*
 * Function : ??0CVssDebugInfo@@QEAA@AEBU0@@Z
 * Address  : 0x14000f400
 * Size     : 122 bytes (30 instructions)
 * Prototype: undefined ??0CVssDebugInfo@@QEAA@AEBU0@@Z(CVssDebugInfo * this, CVssDebugInfo * param_1)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssDebugInfo::CVssDebugInfo(struct CVssDebugInfo const & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: __cdecl CVssDebugInfo::CVssDebugInfo(struct CVssDebugInfo const & __ptr64) __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(CVssDebugInfo *this,CVssDebugInfo *param_1)

{
  CVssDebugInfo *pCVar1;
  longlong lVar2;
  
  *(undefined8 *)this = *(undefined8 *)param_1;
  lVar2 = 0xf;
  *(undefined8 *)(this + 0x10) = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(this + 8) = *(undefined8 *)(param_1 + 8);
  *(undefined4 *)(this + 0x18) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(this + 0x1c) = *(undefined4 *)(param_1 + 0x1c);
  *(undefined2 *)(this + 0xa0) = *(undefined2 *)(param_1 + 0xa0);
  this[0xa2] = param_1[0xa2];
  *(undefined4 *)(this + 0x20) = *(undefined4 *)(param_1 + 0x20);
  this[0xa3] = param_1[0xa3];
  pCVar1 = this + 0x28;
  param_1[0xa3] = (CVssDebugInfo)0x0;
  do {
    *(undefined8 *)pCVar1 = *(undefined8 *)(pCVar1 + ((longlong)param_1 - (longlong)this));
    pCVar1 = pCVar1 + 8;
    lVar2 = lVar2 + -1;
  } while (lVar2 != 0);
  return this;
}


