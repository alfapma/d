/*
 * Function : catch$12
 * Address  : 0x14001612a
 * Size     : 89 bytes (19 instructions)
 * Prototype: undefined * catch$12(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_12(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),*(long *)(param_2 + 0x8c),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return &DAT_140011d26;
}


