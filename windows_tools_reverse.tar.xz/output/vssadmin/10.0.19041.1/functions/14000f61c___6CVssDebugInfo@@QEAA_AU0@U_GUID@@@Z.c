/*
 * Function : ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z
 * Address  : 0x14000f61c
 * Size     : 289 bytes (77 instructions)
 * Prototype: CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z(CVssDebugInfo * this, _GUID * param_1)
 * CC       : __thiscall
 * Comment  : public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(struct _GUID) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(struct _GUID) __ptr64 */

_GUID * __thiscall
CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(CVssDebugInfo *this,_GUID *param_1)

{
  undefined1 auVar1 [16];
  undefined1 (*in_R8) [16];
  undefined1 auStack_138 [32];
  uint local_118;
  uint local_110;
  uint local_108;
  uint local_100;
  uint local_f8;
  uint local_f0;
  uint local_e8;
  uint local_e0;
  uint local_d8;
  uint local_d0;
  ushort local_c8 [64];
  ulonglong local_48;
  
  local_48 = __security_cookie ^ (ulonglong)auStack_138;
  auVar1 = *in_R8;
  local_d8 = auVar1._14_2_ & 0xff;
  local_e0 = auVar1._12_4_ >> 8 & 0xff;
  local_e8 = auVar1._12_4_ & 0xff;
  local_f0 = auVar1._11_4_ & 0xff;
  local_f8 = auVar1._10_4_ & 0xff;
  local_100 = auVar1._9_4_ & 0xff;
  local_118 = auVar1._4_4_ & 0xffff;
  local_d0 = (uint)auVar1[0xf];
  local_108 = (uint)auVar1[8];
  local_110 = (uint)auVar1._6_2_;
  StringCchPrintfW(local_c8,0x3d,(ushort *)L"{%.8x-%.4x-%.4x-%.2x%.2x-%.2x%.2x%.2x%.2x%.2x%.2x}");
  __6CVssDebugInfo__QEAA_AU0_PEBG_Z(this,(ushort *)param_1);
  return param_1;
}


