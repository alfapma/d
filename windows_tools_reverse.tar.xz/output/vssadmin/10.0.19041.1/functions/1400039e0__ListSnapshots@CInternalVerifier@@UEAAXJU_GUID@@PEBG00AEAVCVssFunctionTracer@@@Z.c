/*
 * Function : ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z
 * Address  : 0x1400039e0
 * Size     : 247 bytes (51 instructions)
 * Prototype: void ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CInternalVerifier::ListSnapshots(long,struct _GUID,unsigned short const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual void __cdecl CInternalVerifier::ListSnapshots(long,struct _GUID,unsigned short
   const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_ListSnapshots_CInternalVerifier__UEAAXJU_GUID__PEBG00AEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,long param_1,_GUID *param_2,ushort *param_3,_GUID *param_4,
          _GUID *param_5,CVssFunctionTracer *param_6)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_4->Data1;
  lVar1._4_2_ = param_4->Data2;
  lVar1._6_2_ = param_4->Data3;
  if (((lVar1 != 0) || (*(longlong *)param_4->Data4 != 0)) &&
     ((lVar2._0_4_ = param_5->Data1, lVar2._4_2_ = param_5->Data2, lVar2._6_2_ = param_5->Data3,
      lVar2 != 0 || (*(longlong *)param_5->Data4 != 0)))) {
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ListSnapshots",0x43,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_6,uVar4,0x1008,
               L"CVssAdminCLI::ListSnapshots: Cannot specify both /Set and /Shadow options at the same time"
              );
  }
  if (param_3 != (ushort *)0x0) {
    uVar3 = 0xffffffffffffffff;
    do {
      uVar3 = uVar3 + 1;
    } while (param_3[uVar3] != 0);
    if (0x31 < uVar3) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ListSnapshots",0x48,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_6,uVar4,0x1004,
                 L"CVssAdminCLI::ListSnapshots:  Must specify a valid volume name for list snapshots"
                );
    }
  }
  return;
}


