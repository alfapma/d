/*
 * Function : ?assign@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z
 * Address  : 0x140012390
 * Size     : 220 bytes (65 instructions)
 * Prototype: basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?assign@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::assign(class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::assign(class std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned
   __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::
_assign___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                 *param_1,__uint64 param_2,__uint64 param_3)

{
  bool bVar1;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *_Dst;
  ulonglong uVar3;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar4;
  
  if (param_2 <= *(ulonglong *)(param_1 + 0x18)) {
    uVar3 = *(ulonglong *)(param_1 + 0x18) - param_2;
    if (param_3 < uVar3) {
      uVar3 = param_3;
    }
    if (this == (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 *)param_1) {
      _erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
                (this,uVar3 + param_2,0xffffffffffffffff);
      _erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
                (this,0,param_2);
    }
    else {
      bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                        (this,uVar3,SUB81(param_2,0));
      if (bVar1) {
        pbVar2 = param_1 + 8;
        if (7 < *(ulonglong *)(param_1 + 0x20)) {
          pbVar2 = *(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                     **)pbVar2;
        }
        pbVar4 = this + 8;
        _Dst = pbVar4;
        if (7 < *(ulonglong *)(this + 0x20)) {
          _Dst = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar4;
        }
        memcpy_s(_Dst,*(ulonglong *)(this + 0x20) * 2,pbVar2 + param_2 * 2,uVar3 * 2);
        *(ulonglong *)(this + 0x18) = uVar3;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar4 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar4;
        }
        *(undefined2 *)(pbVar4 + uVar3 * 2) = 0;
      }
    }
    return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xran__String_base_std__SAXXZ();
}


