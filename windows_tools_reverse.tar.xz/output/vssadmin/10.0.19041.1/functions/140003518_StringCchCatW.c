/*
 * Function : StringCchCatW
 * Address  : 0x140003518
 * Size     : 207 bytes (64 instructions)
 * Prototype: long StringCchCatW(ushort * param_1, __uint64 param_2, ushort * param_3)
 * CC       : __cdecl
 * Comment  : long __cdecl StringCchCatW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* long __cdecl StringCchCatW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64) */

long __cdecl StringCchCatW(ushort *param_1,__uint64 param_2,ushort *param_3)

{
  ushort uVar1;
  __uint64 _Var2;
  ushort *puVar3;
  longlong lVar4;
  ushort *puVar5;
  longlong lVar6;
  uint uVar7;
  longlong lVar8;
  
  lVar6 = 0;
  uVar7 = 0;
  if (0x7ffffffe < param_2 - 1) {
    uVar7 = 0x80070057;
  }
  puVar5 = param_1;
  _Var2 = param_2;
  if (-1 < (int)uVar7) {
    for (; (_Var2 != 0 && (*puVar5 != 0)); puVar5 = puVar5 + 1) {
      _Var2 = _Var2 - 1;
    }
    uVar7 = ~-(uint)(_Var2 != 0) & 0x80070057;
    if (_Var2 != 0) {
      lVar6 = param_2 - _Var2;
    }
  }
  if (-1 < (int)uVar7) {
    puVar5 = param_1 + lVar6;
    lVar4 = param_2 - lVar6;
    if (lVar4 != 0) {
      lVar6 = lVar6 + 0x7ffffffe + (lVar4 - param_2);
      lVar8 = (longlong)param_3 - (longlong)puVar5;
      do {
        if ((lVar6 == 0) || (uVar1 = *(ushort *)(lVar8 + (longlong)puVar5), uVar1 == 0)) break;
        *puVar5 = uVar1;
        lVar6 = lVar6 + -1;
        puVar5 = puVar5 + 1;
        lVar4 = lVar4 + -1;
      } while (lVar4 != 0);
    }
    puVar3 = puVar5 + -1;
    if (lVar4 != 0) {
      puVar3 = puVar5;
    }
    uVar7 = ~-(uint)(lVar4 != 0) & 0x8007007a;
    *puVar3 = 0;
  }
  return uVar7;
}


