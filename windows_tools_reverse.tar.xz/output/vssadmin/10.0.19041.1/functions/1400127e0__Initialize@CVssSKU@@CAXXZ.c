/*
 * Function : ?Initialize@CVssSKU@@CAXXZ
 * Address  : 0x1400127e0
 * Size     : 248 bytes (54 instructions)
 * Prototype: void ?Initialize@CVssSKU@@CAXXZ(void)
 * CC       : __cdecl
 * Comment  : private: static void __cdecl CVssSKU::Initialize(void)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: static void __cdecl CVssSKU::Initialize(void) */

void __cdecl CVssSKU::_Initialize_CVssSKU__CAXXZ(void)

{
  BOOL BVar1;
  undefined1 auStackY_178 [32];
  longlong *local_148 [2];
  _OSVERSIONINFOW local_138;
  byte local_20;
  char local_1e;
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStackY_178;
  if (ms_bInitialized == 0) {
    local_138.dwOSVersionInfoSize = 0x11c;
    BVar1 = GetVersionExW(&local_138);
    if (BVar1 == 0) {
      ms_bInitialized = 1;
    }
    if ((byte)(local_1e - 2U) < 2) {
      ms_eSKU = (-(uint)((local_20 & 0x40) != 0) & 2) + 2;
    }
    else {
      ms_eSKU = (EVssSKUType)(local_1e == '\x01');
    }
    local_148[0] = (longlong *)0x0;
    CoGetClassObject((IID *)&CLSID_VssEvent,0x15,(LPVOID)0x0,(IID *)&IID_IClassFactory,local_148);
    if (local_148[0] != (longlong *)0x0) {
      (**(code **)(*local_148[0] + 0x10))();
    }
    ms_bInitialized = 1;
  }
  return;
}


