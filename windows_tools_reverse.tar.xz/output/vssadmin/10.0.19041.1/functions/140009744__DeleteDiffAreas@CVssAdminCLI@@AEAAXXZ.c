/*
 * Function : ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x140009744
 * Size     : 1114 bytes (266 instructions)
 * Prototype: void ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DeleteDiffAreas(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::DeleteDiffAreas(void) __ptr64 */

void __thiscall CVssAdminCLI::_DeleteDiffAreas_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  IID *riid;
  ushort *puVar2;
  uchar pv [8];
  undefined1 auStackY_218 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe18;
  IUnknown *local_1d8;
  longlong *local_1d0;
  _GUID local_1c8;
  undefined **local_1b8;
  ushort *local_1b0;
  undefined1 local_1a8 [8];
  undefined8 local_1a0;
  CVssFunctionTracer local_198 [8];
  ULONG local_190;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  undefined1 local_80 [8];
  LPVOID local_78;
  ushort *local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_1a0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_218;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_120 = L"CVssAdminCLI::DeleteDiffAreas";
  local_118 = L"ADMPROCC";
  local_110 = 0x62b;
  local_10c = 7;
  local_108 = 0xff;
  pv[0] = '\0';
  pv[1] = '\0';
  pv[2] = '\0';
  pv[3] = '\0';
  pv[4] = '\0';
  pv[5] = '\0';
  pv[6] = '\0';
  pv[7] = '\0';
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_198,&local_128);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  riid = (IID *)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  puVar2 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  local_1d8 = (IUnknown *)0x0;
  local_1c8.Data1 = local_48.Data1;
  local_1c8.Data2 = local_48.Data2;
  local_1c8.Data3 = local_48.Data3;
  local_1c8.Data4[0] = local_48.Data4[0];
  local_1c8.Data4[1] = local_48.Data4[1];
  local_1c8.Data4[2] = local_48.Data4[2];
  local_1c8.Data4[3] = local_48.Data4[3];
  local_1c8.Data4[4] = local_48.Data4[4];
  local_1c8.Data4[5] = local_48.Data4[5];
  local_1c8.Data4[6] = local_48.Data4[6];
  local_1c8.Data4[7] = local_48.Data4[7];
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_1c8,&local_1d8);
  local_1c8.Data4[0] = '\0';
  local_1c8.Data4[1] = '\0';
  local_1c8.Data4[2] = '\0';
  local_1c8.Data4[3] = '\0';
  local_1c8.Data4[4] = '\0';
  local_1c8.Data4[5] = '\0';
  local_1c8.Data4[6] = '\0';
  local_1c8.Data4[7] = '\0';
  local_1c8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (puVar2 == (ushort *)0x0) {
    local_1d0 = (longlong *)0x0;
    local_190 = (*local_1d8->lpVtbl[2].QueryInterface)(local_1d8,riid,&local_1d0);
    if ((int)local_190 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x648,7,in_stack_fffffffffffffe18);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    if (local_190 == 1) {
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
      if (local_1d0 != (longlong *)0x0) {
        (**(code **)(*local_1d0 + 0x10))();
      }
    }
    else {
      local_190 = (**(code **)(*local_1d0 + 0x18))(local_1d0,1,local_80,local_1a8);
      if ((int)local_190 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_128,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x658,7,
                   in_stack_fffffffffffffe18);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
      }
      if (local_190 != 1) {
        CoTaskMemFree(local_78);
        local_78 = (LPVOID)0x0;
        local_1b0 = local_70;
        local_1b8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
        _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                  ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_1c8,local_70);
        pv = local_1c8.Data4;
        if (local_70 != (ushort *)0x0) {
          CoTaskMemFree(local_70);
        }
        if (local_1d0 != (longlong *)0x0) {
          (**(code **)(*local_1d0 + 0x10))();
        }
        goto LAB_1400099ba;
      }
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
      if (local_1d0 != (longlong *)0x0) {
        (**(code **)(*local_1d0 + 0x10))();
      }
    }
    if (local_1d8 != (IUnknown *)0x0) {
      (*local_1d8->lpVtbl->Release)();
    }
  }
  else {
LAB_1400099ba:
    local_190 = (*local_1d8->lpVtbl[1].AddRef)(local_1d8);
    if ((int)local_190 < 0) {
      if (local_190 == 0x80042308) {
        _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
      }
      else {
        if (local_190 != 0x8004231d) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_128,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x67e,7,
                     in_stack_fffffffffffffe18);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
        }
        _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b60);
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
      }
    }
    else {
      iVar1 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
      if (iVar1 == 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002751);
      }
      *(undefined4 *)(this + 0x48) = 0;
      if (pv != (uchar  [8])0x0) {
        CoTaskMemFree((LPVOID)pv);
      }
    }
    if (local_1d8 != (IUnknown *)0x0) {
      (*local_1d8->lpVtbl->Release)();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_198);
  return;
}


