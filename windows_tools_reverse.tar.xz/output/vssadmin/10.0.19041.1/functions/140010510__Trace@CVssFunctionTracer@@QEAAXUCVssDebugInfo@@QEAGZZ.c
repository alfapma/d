/*
 * Function : ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ
 * Address  : 0x140010510
 * Size     : 245 bytes (56 instructions)
 * Prototype: void ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::Trace(struct CVssDebugInfo,unsigned short * __ptr64 const,...) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::Trace(struct CVssDebugInfo,unsigned short * __ptr64
   const,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  int iVar1;
  ushort *puVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  undefined8 local_res20;
  ulong in_stack_ffffffffffffff08;
  __uint64 local_d8;
  ushort *local_d0;
  CVssDebugInfo local_c8 [176];
  
  local_res20 = param_4;
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    puVar2 = operator_new__(0x3ea,&std::nothrow);
    if (puVar2 != (ushort *)0x0) {
      local_d8 = 0;
      local_d0 = (ushort *)0x0;
      StringCchVPrintfExW(puVar2,500,&local_d0,&local_d8,in_stack_ffffffffffffff08,param_3,
                          (char *)&local_res20);
      if (local_d8 == 1) {
        local_d0[-2] = 0x2e;
        local_d0[-1] = 0x2e;
        local_d0[-3] = 0x2e;
      }
      uVar4 = 0x8c;
      if (*(int *)(param_2 + 0x20) != 0xff) {
        uVar4 = (ulonglong)*(uint *)(param_2 + 0x20);
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c8,param_2);
      _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                (this,uVar3,L"TRACE",uVar4 & 0xffffffff,puVar2);
    }
    operator_delete__(puVar2);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}


