/*
 * Function : dtor$15
 * Address  : 0x140015e7f
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$15(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_15(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x70));
  return;
}


