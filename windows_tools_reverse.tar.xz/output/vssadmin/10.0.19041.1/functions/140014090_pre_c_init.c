/*
 * Function : pre_c_init
 * Address  : 0x140014090
 * Size     : 211 bytes (49 instructions)
 * Prototype: undefined8 pre_c_init(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 pre_c_init(void)

{
  code *_Except;
  int iVar1;
  
  if ((false) || (false)) {
LAB_1400140a2:
    DAT_140024160 = 0;
  }
  else {
    if (false) {
      DAT_140024160 = 0;
      if (true) goto LAB_1400140f9;
      iVar1 = 0x17dc8;
    }
    else {
      if (false) goto LAB_1400140a2;
      DAT_140024160 = 0;
      if (false) goto LAB_1400140f9;
      iVar1 = 0;
    }
    DAT_140024160 = (uint)(iVar1 != 0);
  }
LAB_1400140f9:
  iVar1 = _get_image_app_type(1);
  __set_app_type(iVar1);
  ___onexitend = 0xffffffffffffffff;
  ___onexitbegin = 0xffffffffffffffff;
  *(undefined4 *)_fmode_exref = _fmode;
  _Except = _commode_exref;
  *(undefined4 *)_commode_exref = _commode;
  _wsetargv((_exception *)_Except);
  if (__defaultmatherr == 0) {
    __setusermatherr(_wsetargv);
  }
  return 0;
}


