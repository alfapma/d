/*
 * Function : catch$25
 * Address  : 0x140015918
 * Size     : 86 bytes (19 instructions)
 * Prototype: undefined * catch$25(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssAdminCLI::Main'::__l1::catch_25(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(long *)(param_2 + 0xd4),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x394,*(ulong *)(param_2 + 0x84));
  return &DAT_1400031df;
}


