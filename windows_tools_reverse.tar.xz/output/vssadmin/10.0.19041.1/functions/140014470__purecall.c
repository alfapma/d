/*
 * Function : _purecall
 * Address  : 0x140014470
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined _purecall()
 * CC       : unknown
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void _purecall(void)

{
                    /* WARNING: Could not recover jumptable at 0x000140014470. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _purecall();
  return;
}


