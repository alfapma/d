/*
 * Function : catch$4
 * Address  : 0x140016046
 * Size     : 26 bytes (8 instructions)
 * Prototype: undefined * catch$4(void)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined * `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_4(void)

{
  return (undefined *)0x140010ca8;
}


