/*
 * Function : ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z
 * Address  : 0x1400134c8
 * Size     : 1742 bytes (310 instructions)
 * Prototype: __int64 ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z(ushort * param_1)
 * CC       : __cdecl
 * Comment  : public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaOnVolume(unsigned short const * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaOnVolume(unsigned short
   const * __ptr64) */

__int64 __cdecl
CVssMachineInformation::_GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z(ushort *param_1)

{
  OLECHAR OVar1;
  __int64 _Var2;
  void *pvVar3;
  int iVar4;
  HRESULT HVar5;
  _VSSDBG_SEV_ENUM _Var6;
  longlong lVar7;
  OLECHAR *pOVar9;
  undefined8 uVar10;
  OLECHAR *pOVar11;
  CVssDebugInfo *this;
  wchar_t *pwVar12;
  wchar_t *pwVar13;
  undefined1 in_R9B;
  wchar_t *pwVar14;
  ushort *puVar15;
  undefined1 auStackY_348 [32];
  undefined1 in_stack_fffffffffffffcd8;
  _VSS_ICHANNEL_LOGGING in_stack_fffffffffffffce0;
  ulong uVar16;
  ulong in_stack_fffffffffffffce8;
  _VSSDBG_SEV_ENUM _Var17;
  _VSSDBG_SEV_ENUM _Var18;
  ulong in_stack_fffffffffffffcf0;
  ulong in_stack_fffffffffffffcf8;
  wchar_t *local_2f8;
  wchar_t *local_2f0;
  wchar_t *pwStack_2e8;
  undefined8 local_2e0;
  HANDLE pvStack_2d8;
  undefined2 local_2d0 [2];
  ulonglong local_2cc;
  void *local_2c0;
  undefined8 local_2b8;
  _VSSDBG_SEV_ENUM local_2b0;
  void *local_2a8;
  short local_2a0;
  undefined **local_298;
  LPVOID local_290;
  undefined4 local_258;
  wchar_t *local_248;
  wchar_t *local_240;
  wchar_t *local_238;
  undefined4 local_230;
  undefined4 local_22c;
  undefined4 local_228;
  undefined1 local_220 [120];
  undefined4 local_1a8;
  ushort *local_198;
  CVssFunctionTracer local_188 [36];
  int local_164;
  undefined8 local_118;
  CLSID local_100;
  OLECHAR local_e8 [38];
  undefined2 local_9c;
  ushort local_98 [56];
  ulonglong local_28;
  longlong lVar8;
  
  local_118 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_348;
  local_2f8 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_2f0 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
  pwStack_2e8 = L"REGREGSC";
  local_2e0 = 0xb00000698;
  pvStack_2d8 = (HANDLE)CONCAT44(pvStack_2d8._4_4_,0xff);
  local_258 = 0x1000000;
  local_198 = param_1;
  memset(local_2d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_188);
  lVar7 = -1;
  do {
    lVar8 = lVar7;
    lVar7 = lVar8 + 1;
  } while (param_1[lVar7] != 0);
  if ((lVar7 == 0x31) &&
     (iVar4 = wcsncmp((wchar_t *)param_1,L"\\\\?\\Volume",(ulonglong)((int)lVar8 - 0x26)),
     iVar4 == 0)) {
    iVar4 = wcsncmp((wchar_t *)(param_1 + 0x30),L"\\",2);
    if (iVar4 == 0) {
      lVar7 = 0x27;
      for (pOVar11 = local_e8;
          (lVar7 + -1 != 0 &&
          (OVar1 = *(OLECHAR *)((longlong)param_1 + (0x14 - (longlong)local_e8) + (longlong)pOVar11)
          , OVar1 != L'\0')); pOVar11 = pOVar11 + 1) {
        *pOVar11 = OVar1;
        lVar7 = lVar7 + -1;
      }
      pOVar9 = pOVar11 + -1;
      if (lVar7 != 0) {
        pOVar9 = pOVar11;
      }
      *pOVar9 = L'\0';
      if (lVar7 != 0) {
        local_9c = 0;
        HVar5 = CLSIDFromString(local_e8,&local_100);
        puVar15 = param_1;
        if (HVar5 == 0) goto LAB_1400136d4;
      }
    }
  }
  local_248 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_240 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
  local_238 = L"REGREGSC";
  local_230 = 0x6a4;
  local_22c = 0xb;
  local_228 = 0xff;
  local_1a8 = 0x1000000;
  memset(local_220,0,0x78);
  in_R9B = SUB81(local_98,0);
  GetVolumeNameWithCheck(&local_248);
  puVar15 = local_98;
LAB_1400136d4:
  local_2f8 = (HANDLE)0x0;
  local_2d0[0] = 0;
  local_2cc = 0;
  local_2c0 = (void *)0x0;
  local_2b8 = 0;
  local_2b0 = 0;
  local_2a8 = (void *)0x0;
  local_2a0 = 0;
  local_290 = (LPVOID)0x0;
  local_298 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  local_2f0 = (wchar_t *)0x0;
  pwStack_2e8 = (wchar_t *)0x0;
  local_2e0 = 0;
  pvStack_2d8 = (HANDLE)0x0;
  CVssIOCTLChannel::
  _Open_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__PEBG_N2W4_VSS_ICHANNEL_LOGGING__KKK_Z
            ((CVssIOCTLChannel *)&local_2f8,local_188,puVar15,(bool)in_R9B,
             (bool)in_stack_fffffffffffffcd8,in_stack_fffffffffffffce0,in_stack_fffffffffffffce8,
             in_stack_fffffffffffffcf0,in_stack_fffffffffffffcf8);
  _Var17 = 0;
  CVssIOCTLChannel::
  _Call_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__K_NW4_VSS_ICHANNEL_LOGGING__1PEAX_Z
            ((CVssIOCTLChannel *)&local_2f8,local_188,0x534058,true,0,false,(void *)0x0);
  pvVar3 = local_2a8;
  _Var18 = (_VSSDBG_SEV_ENUM)local_2b8;
  if (local_2a8 != (void *)0x0) {
    _Var6 = (_VSSDBG_SEV_ENUM)local_2b8 + 8;
    if (((_VSSDBG_SEV_ENUM)local_2b8 <= _Var6) && (_Var6 <= local_2b0)) {
      if (local_2b8._4_4_ < _Var6) {
        CVssIOCTLChannel::_ResetOffsets_CVssIOCTLChannel__QEAAXXZ((CVssIOCTLChannel *)&local_2f8);
        uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                           ((CVssDebugInfo *)&local_248,
                            (ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                            (ushort *)L"CVssIOCTLChannel::Unpack",0x300,10,_Var17);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_188,uVar10,0x8007000e,
                   L"Arithmetic overflow. m_dwOutputCurrentOffset = %lu or dwSize = %lu too large.")
        ;
      }
      _Var2 = *(__int64 *)((local_2b8 & 0xffffffff) + (longlong)local_2a8);
      local_2b8 = CONCAT44(local_2b8._4_4_,_Var6);
      if (local_2a0 != 0) {
        CVssIOCTLChannel::_ApplyAlignment_CVssIOCTLChannel__AEAAXAEAVCVssFunctionTracer__PEAK_Z
                  ((CVssIOCTLChannel *)&local_2f8,local_188,(ulong *)&local_2b8);
      }
      local_248 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
      local_240 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
      local_238 = L"REGREGSC";
      local_230 = 0x6b9;
      local_22c = 0xb;
      local_228 = 0xff;
      local_1a8 = 0x1000000;
      memset(local_220,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_188,&local_248,L"Minimum diff area size for volume %s: %I64d",param_1);
      if (local_2f8 != (HANDLE)0x0) {
        CloseHandle(local_2f8);
      }
      local_2f8 = (wchar_t *)0x0;
      local_2cc = local_2cc & 0xffffffff00000000;
      local_2b8 = local_2b8 & 0xffffffff00000000;
      local_2b0 = 0;
      if (local_2c0 != (void *)0x0) {
        free(local_2c0);
      }
      local_2c0 = (void *)0x0;
      local_2cc = local_2cc & 0xffffffff;
      if (local_2a8 != (void *)0x0) {
        free(local_2a8);
      }
      local_2a8 = (void *)0x0;
      local_2b8 = local_2b8 & 0xffffffff;
      if ((pvStack_2d8 != (HANDLE)0x0) && ((char)local_2d0[0] != '\0')) {
        CloseHandle(pvStack_2d8);
      }
      local_298 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      if (local_290 != (LPVOID)0x0) {
        CoTaskMemFree(local_290);
      }
      local_290 = (LPVOID)0x0;
      local_298 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                   ::_vftable_;
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_188);
      return _Var2;
    }
  }
  local_248 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_240 = L"CVssIOCTLChannel::Unpack";
  local_238 = L"INCICHLH";
  local_230 = 0x2e7;
  local_22c = 10;
  local_228 = 0xff;
  local_1a8 = 0x1000000;
  memset(local_220,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_188,&local_248,
             L"Output buffer overflow. Trying to read non-existent arguments. m_pbOutputBuffer = %p, m_dwOutputCurrentOffset = %lu, dwSize = %lu, m_dwOutputCurrentOffset = %lu"
             ,pvVar3);
  local_2cc = local_2cc & 0xffffffff00000000;
  local_2b8 = local_2b8 & 0xffffffff00000000;
  uVar16 = 10;
  pwVar14 = L"CVssIOCTLChannel::Unpack";
  pwVar13 = L"INCICHLH";
  pwVar12 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  this = (CVssDebugInfo *)&local_248;
  if (local_164 == 2) {
    pwVar12 = (wchar_t *)
              CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (this,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                         (ushort *)L"CVssIOCTLChannel::Unpack",0x2f2,10,_Var18);
    pwVar14 = (wchar_t *)0x80042306;
    pwVar13 = (wchar_t *)0x8000ffff;
    this = (CVssDebugInfo *)local_188;
    CVssFunctionTracer::
    _TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ();
  }
  uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                     (this,(ushort *)pwVar12,(ushort *)pwVar13,(ushort *)pwVar14,0x2f4,uVar16,_Var18
                     );
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (local_188,uVar10,0x8000ffff,
             L"Output buffer overflow. Reading bad arguments. dwSize = %lu");
}


