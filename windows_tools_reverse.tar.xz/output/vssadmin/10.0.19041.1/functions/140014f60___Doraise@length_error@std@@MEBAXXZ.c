/*
 * Function : ?_Doraise@length_error@std@@MEBAXXZ
 * Address  : 0x140014f60
 * Size     : 49 bytes (10 instructions)
 * Prototype: void ?_Doraise@length_error@std@@MEBAXXZ(length_error * this)
 * CC       : __thiscall
 * Comment  : protected: virtual void __cdecl std::length_error::_Doraise(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: virtual void __cdecl std::length_error::_Doraise(void)const __ptr64 */

void __thiscall std::length_error::__Doraise_length_error_std__MEBAXXZ(length_error *this)

{
  undefined1 auStack_78 [32];
  length_error local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0length_error_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVlength_error_std__);
}


