/*
 * Function : ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z
 * Address  : 0x14000c084
 * Size     : 368 bytes (84 instructions)
 * Prototype: __uint64 ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64)
   __ptr64 */

__uint64 __thiscall
CVssAdminCLI::_GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  ULARGE_INTEGER UVar1;
  BOOL BVar2;
  DWORD DVar3;
  DWORD DVar4;
  ULARGE_INTEGER local_res8;
  ULARGE_INTEGER local_res18;
  ULARGE_INTEGER local_res20;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_140 = L"CVssAdminCLI::GetVolumeCapacity";
  local_138 = L"ADMUTILC";
  local_130 = 0x87;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  local_res8 = (ULARGE_INTEGER)this;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  local_res8.QuadPart = 0;
  local_res18.QuadPart = 0;
  local_res20.QuadPart = 0;
  BVar2 = GetDiskFreeSpaceExW((LPCWSTR)param_1,&local_res20,&local_res8,&local_res18);
  UVar1 = local_res8;
  if (BVar2 == 0) {
    DVar3 = GetLastError();
    if (DVar3 - 2 < 2) {
      DVar4 = 0x80042308;
    }
    else {
      DVar4 = DVar3 & 0xffff | 0x80070000;
      if ((int)DVar3 < 1) {
        DVar4 = DVar3;
      }
    }
    CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(local_98,DVar4);
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
               (ushort *)L"CVssAdminCLI::GetVolumeCapacity",0x9f,7,in_stack_fffffffffffffe98);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return (__uint64)UVar1.s;
}


