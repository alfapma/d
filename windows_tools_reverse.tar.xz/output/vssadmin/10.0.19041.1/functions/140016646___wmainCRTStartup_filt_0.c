/*
 * Function : __wmainCRTStartup$filt$0
 * Address  : 0x140016646
 * Size     : 29 bytes (11 instructions)
 * Prototype: undefined __wmainCRTStartup$filt$0(_EXCEPTION_POINTERS * param_1)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void __wmainCRTStartup_filt_0(_EXCEPTION_POINTERS *param_1)

{
  _XcptFilter(param_1->ExceptionRecord->ExceptionCode,param_1);
  return;
}


