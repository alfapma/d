/*
 * Function : dtor$6
 * Address  : 0x140015def
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$6(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssAdminCLI::QueryReverts'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
  ::
  __1__CVssAuto_PEAXV__CVssAutoGenericValue_Storage_PEAX_0_0P6AHPEAX_Z_1_FindVolumeClose__YAH0_ZP6AAEAPEAXAEAPEAX_Z_1_Identity___DTyper_PEAX__SAAEAPEAX1_Z____UEAA_XZ
            ((CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,_1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
              *)(param_2 + 0x60));
  return;
}


