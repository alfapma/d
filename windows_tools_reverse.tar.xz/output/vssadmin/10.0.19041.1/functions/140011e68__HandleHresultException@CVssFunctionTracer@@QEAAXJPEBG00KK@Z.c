/*
 * Function : ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z
 * Address  : 0x140011e68
 * Size     : 140 bytes (30 instructions)
 * Prototype: void ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z(CVssFunctionTracer * this, long param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::HandleHresultException(long,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: void __cdecl CVssFunctionTracer::HandleHresultException(long,unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
          (CVssFunctionTracer *this,long param_1,ushort *param_2,ushort *param_3,ushort *param_4,
          ulong param_5,ulong param_6)

{
  ushort *local_b8;
  ushort *local_b0;
  ushort *local_a8;
  ulong local_a0;
  ulong local_9c;
  undefined4 local_98;
  undefined1 local_90 [120];
  undefined4 local_18;
  
  local_b0 = param_4;
  *(long *)(this + 8) = param_1;
  local_a0 = param_5;
  local_9c = param_6;
  local_98 = 0xff;
  local_18 = 0x1000000;
  local_b8 = param_2;
  local_a8 = param_3;
  memset(local_90,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_b8,L"HRESULT exception caught: hr: 0x%x",param_1);
  return;
}


