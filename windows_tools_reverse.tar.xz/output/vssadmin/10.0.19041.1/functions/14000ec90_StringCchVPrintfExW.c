/*
 * Function : StringCchVPrintfExW
 * Address  : 0x14000ec90
 * Size     : 255 bytes (78 instructions)
 * Prototype: long StringCchVPrintfExW(ushort * param_1, __uint64 param_2, ushort * * param_3, __uint64 * param_4, ulong param_5, ushort * param_6, char * param_7)
 * CC       : __cdecl
 * Comment  : long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short * __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char * __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short *
   __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char *
   __ptr64) */

long __cdecl
StringCchVPrintfExW(ushort *param_1,__uint64 param_2,ushort **param_3,__uint64 *param_4,
                   ulong param_5,ushort *param_6,char *param_7)

{
  ulonglong _Count;
  int iVar1;
  ulonglong uVar2;
  long lVar3;
  __uint64 _Var4;
  
  iVar1 = 0;
  if (0x7ffffffe < param_2 - 1) {
    iVar1 = -0x7ff8ffa9;
  }
  if (iVar1 < 0) {
    if (param_2 == 0) {
      return iVar1;
    }
    *param_1 = 0;
    return iVar1;
  }
  lVar3 = 0;
  if (param_2 == 0) {
    _Var4 = 0;
    if (*param_6 != 0) {
      if (param_1 == (ushort *)0x0) {
        return -0x7ff8ffa9;
      }
      lVar3 = -0x7ff8ff86;
    }
    goto LAB_14000ed53;
  }
  _Count = param_2 - 1;
  iVar1 = _vsnwprintf((wchar_t *)param_1,_Count,(wchar_t *)param_6,param_7);
  if (iVar1 < 0) {
LAB_14000ed2e:
    lVar3 = -0x7ff8ff86;
LAB_14000ed33:
    param_1[_Count] = 0;
    uVar2 = _Count;
  }
  else {
    uVar2 = (ulonglong)iVar1;
    if (_Count < uVar2) goto LAB_14000ed2e;
    if (uVar2 == _Count) goto LAB_14000ed33;
  }
  param_1 = param_1 + uVar2;
  _Var4 = param_2 - uVar2;
  if (((lVar3 + 0x80000000U & 0x80000000) == 0) && (lVar3 != -0x7ff8ff86)) {
    return lVar3;
  }
LAB_14000ed53:
  if (param_3 != (ushort **)0x0) {
    *param_3 = param_1;
  }
  if (param_4 != (__uint64 *)0x0) {
    *param_4 = _Var4;
  }
  return lVar3;
}


