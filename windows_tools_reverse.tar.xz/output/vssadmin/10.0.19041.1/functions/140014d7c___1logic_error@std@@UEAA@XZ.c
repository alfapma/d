/*
 * Function : ??1logic_error@std@@UEAA@XZ
 * Address  : 0x140014d7c
 * Size     : 65 bytes (16 instructions)
 * Prototype: void ??1logic_error@std@@UEAA@XZ(logic_error * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl std::logic_error::~logic_error(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual __cdecl std::logic_error::~logic_error(void) __ptr64 */

void __thiscall std::logic_error::__1logic_error_std__UEAA_XZ(logic_error *this)

{
  *(undefined ***)this = &_vftable_;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    operator_delete__(*(void **)(this + 0x20));
  }
  *(undefined8 *)(this + 0x30) = 0;
  *(undefined8 *)(this + 0x38) = 0xf;
  this[0x20] = (logic_error)0x0;
  exception::__1exception__UEAA_XZ((exception *)this);
  return;
}


