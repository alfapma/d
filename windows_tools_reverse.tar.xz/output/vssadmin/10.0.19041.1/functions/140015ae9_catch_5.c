/*
 * Function : catch$5
 * Address  : 0x140015ae9
 * Size     : 84 bytes (19 instructions)
 * Prototype: undefined * catch$5(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_5(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x50),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return (undefined *)0x14000468a;
}


