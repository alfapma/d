/*
 * Function : ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z
 * Address  : 0x140001264
 * Size     : 365 bytes (88 instructions)
 * Prototype: void ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::GetProviderId(struct _GUID * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* private: void __cdecl CVssAdminCLI::GetProviderId(struct _GUID * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(CVssAdminCLI *this,_GUID *param_1)

{
  bool bVar1;
  int iVar2;
  ushort *puVar3;
  undefined8 uVar4;
  CVssAdminCLI *this_00;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_138 = L"CVssAdminCLI::GetProviderId";
  local_130 = L"ADMVADMC";
  local_128 = 0xd8;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  if (*(int *)(&DAT_1400172e4 + (longlong)*(int *)(this + 0x60) * 0x60) == 0) {
    param_1->Data1 = 0xb5946137;
    param_1->Data2 = 0x7b9f;
    param_1->Data3 = 0x4925;
    param_1->Data4[0] = 0xaf;
    param_1->Data4[1] = 0x80;
    param_1->Data4[2] = 'Q';
    param_1->Data4[3] = 0xab;
    param_1->Data4[4] = 0xd6;
    param_1->Data4[5] = '\v';
    param_1->Data4[6] = ' ';
    param_1->Data4[7] = 0xd5;
  }
  else {
    param_1->Data1 = 0;
    param_1->Data2 = 0;
    param_1->Data3 = 0;
    param_1->Data4[0] = '\0';
    param_1->Data4[1] = '\0';
    param_1->Data4[2] = '\0';
    param_1->Data4[3] = '\0';
    param_1->Data4[4] = '\0';
    param_1->Data4[5] = '\0';
    param_1->Data4[6] = '\0';
    param_1->Data4[7] = '\0';
    this_00 = this;
    puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,8);
    if (puVar3 != (ushort *)0x0) {
      bVar1 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar3,param_1);
      if (!bVar1) {
        iVar2 = _GetProviderIdByName_CVssAdminCLI__AEAAHPEBGPEAU_GUID___Z(this_00,puVar3,param_1);
        if (iVar2 == 0) {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000274c,puVar3);
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_140,
                             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                             (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderId",0xf3,7,
                             in_stack_fffffffffffffea8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_98,uVar4,0,L"Already printed error message");
        }
      }
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return;
}


