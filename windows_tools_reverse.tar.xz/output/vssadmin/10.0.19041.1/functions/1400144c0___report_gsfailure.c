/*
 * Function : __report_gsfailure
 * Address  : 0x1400144c0
 * Size     : 369 bytes (65 instructions)
 * Prototype: void __report_gsfailure(uintptr_t _StackCookie)
 * CC       : __cdecl
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl __report_gsfailure(uintptr_t _StackCookie)

{
  DWORD64 ControlPc;
  PRUNTIME_FUNCTION FunctionEntry;
  DWORD64 local_38;
  ulonglong local_30;
  PVOID local_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  
  RtlCaptureContext(&DAT_140024210);
  ControlPc = DAT_140024308;
  FunctionEntry = RtlLookupFunctionEntry(DAT_140024308,&local_38,(PUNWIND_HISTORY_TABLE)0x0);
  if (FunctionEntry == (PRUNTIME_FUNCTION)0x0) {
    DAT_140024308 = *DAT_1400242a8;
    DAT_1400242a8 = DAT_1400242a8 + 1;
  }
  else {
    RtlVirtualUnwind(0,local_38,ControlPc,FunctionEntry,(PCONTEXT)&DAT_140024210,&local_28,&local_30
                     ,(PKNONVOLATILE_CONTEXT_POINTERS)0x0);
  }
  _DAT_140024180 = DAT_140024308;
  _DAT_140024170 = 0xc0000409;
  _DAT_140024174 = 1;
  _DAT_140024188 = 3;
  DAT_140024190 = 2;
  DAT_140024198 = __security_cookie;
  DAT_1400241a0 = __security_cookie_complement;
  uStack_20 = __security_cookie;
  uStack_18 = __security_cookie_complement;
  _DAT_140024290 = _StackCookie;
  __raise_securityfailure((_EXCEPTION_POINTERS *)&PTR_DAT_140017008);
  return;
}


