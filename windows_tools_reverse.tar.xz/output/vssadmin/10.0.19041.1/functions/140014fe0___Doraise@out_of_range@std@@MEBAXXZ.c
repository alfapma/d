/*
 * Function : ?_Doraise@out_of_range@std@@MEBAXXZ
 * Address  : 0x140014fe0
 * Size     : 49 bytes (10 instructions)
 * Prototype: void ?_Doraise@out_of_range@std@@MEBAXXZ(out_of_range * this)
 * CC       : __thiscall
 * Comment  : protected: virtual void __cdecl std::out_of_range::_Doraise(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* protected: virtual void __cdecl std::out_of_range::_Doraise(void)const __ptr64 */

void __thiscall std::out_of_range::__Doraise_out_of_range_std__MEBAXXZ(out_of_range *this)

{
  undefined1 auStack_78 [32];
  out_of_range local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0out_of_range_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVout_of_range_std__);
}


