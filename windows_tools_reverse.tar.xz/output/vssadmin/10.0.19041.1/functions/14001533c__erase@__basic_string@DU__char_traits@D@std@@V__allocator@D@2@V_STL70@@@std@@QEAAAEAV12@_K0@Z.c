/*
 * Function : ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z
 * Address  : 0x14001533c
 * Size     : 149 bytes (46 instructions)
 * Prototype: basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::erase(unsigned __int64,unsigned
   __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          __uint64 param_1,__uint64 param_2)

{
  longlong lVar1;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar3;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  ulonglong uVar5;
  
  if (param_1 <= *(ulonglong *)(this + 0x18)) {
    uVar5 = *(ulonglong *)(this + 0x18) - param_1;
    if (uVar5 < param_2) {
      param_2 = uVar5;
    }
    if (param_2 != 0) {
      pbVar4 = this + 8;
      pbVar3 = pbVar4;
      pbVar2 = pbVar4;
      if (0xf < *(ulonglong *)(this + 0x20)) {
        pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
        pbVar2 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      memmove_s(pbVar3 + param_1,*(ulonglong *)(this + 0x20) - param_1,pbVar2 + param_2 + param_1,
                uVar5 - param_2);
      lVar1 = *(longlong *)(this + 0x18);
      *(__uint64 *)(this + 0x18) = lVar1 - param_2;
      if (0xf < *(ulonglong *)(this + 0x20)) {
        pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      pbVar4[lVar1 - param_2] =
           (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
    }
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xran__String_base_std__SAXXZ();
}


