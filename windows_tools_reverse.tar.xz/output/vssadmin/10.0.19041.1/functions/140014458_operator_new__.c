/*
 * Function : operator_new[]
 * Address  : 0x140014458
 * Size     : 5 bytes (1 instructions)
 * Prototype: void * operator_new[](__uint64 param_1, nothrow_t * param_2)
 * CC       : __cdecl
 * Comment  : void * __ptr64 __cdecl operator new[](unsigned __int64,struct std::nothrow_t const & __ptr64)
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* void * __ptr64 __cdecl operator new[](unsigned __int64,struct std::nothrow_t const & __ptr64) */

void * __cdecl operator_new__(__uint64 param_1,nothrow_t *param_2)

{
  void *pvVar1;
  
  pvVar1 = operator_new(param_1);
  return pvVar1;
}


