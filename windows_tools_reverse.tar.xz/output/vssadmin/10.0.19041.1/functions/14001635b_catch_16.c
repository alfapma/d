/*
 * Function : catch$16
 * Address  : 0x14001635b
 * Size     : 89 bytes (19 instructions)
 * Prototype: undefined * catch$16(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_16
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(long *)(param_2 + 0x1a8),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return &DAT_140013a2d;
}


