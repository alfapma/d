/*
 * Function : ??1bad_alloc@std@@UEAA@XZ
 * Address  : 0x14000edd0
 * Size     : 15 bytes (3 instructions)
 * Prototype: void ??1bad_alloc@std@@UEAA@XZ(bad_alloc * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl std::bad_alloc::~bad_alloc(void) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: virtual __cdecl std::bad_alloc::~bad_alloc(void) __ptr64 */

void __thiscall std::bad_alloc::__1bad_alloc_std__UEAA_XZ(bad_alloc *this)

{
  *(undefined ***)this = &_vftable_;
  exception::__1exception__UEAA_XZ((exception *)this);
  return;
}


