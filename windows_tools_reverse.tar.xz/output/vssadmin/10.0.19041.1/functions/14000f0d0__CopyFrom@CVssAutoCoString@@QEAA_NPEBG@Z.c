/*
 * Function : ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z
 * Address  : 0x14000f0d0
 * Size     : 153 bytes (43 instructions)
 * Prototype: bool ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z(CVssAutoCoString * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : public: bool __cdecl CVssAutoCoString::CopyFrom(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: bool __cdecl CVssAutoCoString::CopyFrom(unsigned short const * __ptr64) __ptr64 */

bool __thiscall
CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z(CVssAutoCoString *this,ushort *param_1)

{
  ushort *puVar1;
  longlong lVar2;
  longlong lVar3;
  bool bVar4;
  
  CoTaskMemFree(*(LPVOID *)this);
  lVar2 = 0;
  *(undefined8 *)this = 0;
  if (param_1 != (ushort *)0x0) {
    lVar2 = -1;
    do {
      lVar2 = lVar2 + 1;
    } while (param_1[lVar2] != 0);
    puVar1 = CoTaskMemAlloc(lVar2 * 2 + 2);
    *(ushort **)this = puVar1;
    bVar4 = true;
    lVar2 = -1;
    if (puVar1 == (ushort *)0x0) goto LAB_14000f151;
    do {
      lVar3 = lVar2;
      lVar2 = lVar3 + 1;
    } while (param_1[lVar2] != 0);
    StringCchCopyW(puVar1,lVar3 + 2,param_1);
    lVar2 = *(longlong *)this;
  }
  bVar4 = lVar2 == 0;
LAB_14000f151:
  return !bVar4;
}


