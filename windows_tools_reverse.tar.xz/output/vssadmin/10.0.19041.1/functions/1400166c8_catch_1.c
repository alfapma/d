/*
 * Function : catch$1
 * Address  : 0x1400166c8
 * Size     : 100 bytes (25 instructions)
 * Prototype: undefined * catch$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

undefined *
`std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::_Copy'::__l1::catch_1
          (undefined8 param_1,longlong param_2)

{
  longlong lVar1;
  undefined1 auVar2 [16];
  void *pvVar3;
  ulonglong uVar4;
  
  lVar1 = *(longlong *)(param_2 + 0x98);
  *(longlong *)(param_2 + 0x98) = lVar1;
  uVar4 = lVar1 + 1;
  if ((uVar4 != 0) &&
     (auVar2._8_8_ = 0, auVar2._0_8_ = uVar4,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2,0) == 0)) {
    std::bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z((bad_alloc *)(param_2 + 0x40),(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException((void *)(param_2 + 0x40),(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  pvVar3 = operator_new(uVar4);
  *(void **)(param_2 + 0xa8) = pvVar3;
  return &DAT_140014ec1;
}


