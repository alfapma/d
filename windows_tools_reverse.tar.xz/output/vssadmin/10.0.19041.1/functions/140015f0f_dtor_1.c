/*
 * Function : dtor$1
 * Address  : 0x140015f0f
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

void `CVssResource::LoadStringW'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
            ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
              *)(param_2 + 0xf8));
  return;
}


