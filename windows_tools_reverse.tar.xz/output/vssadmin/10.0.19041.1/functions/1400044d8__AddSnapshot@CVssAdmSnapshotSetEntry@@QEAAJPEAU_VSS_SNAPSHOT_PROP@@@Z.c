/*
 * Function : ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z
 * Address  : 0x1400044d8
 * Size     : 582 bytes (131 instructions)
 * Prototype: long ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z(CVssAdmSnapshotSetEntry * this, _VSS_SNAPSHOT_PROP * param_1)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssAdmSnapshotSetEntry::AddSnapshot(struct _VSS_SNAPSHOT_PROP * __ptr64) __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: long __cdecl CVssAdmSnapshotSetEntry::AddSnapshot(struct _VSS_SNAPSHOT_PROP * __ptr64)
   __ptr64 */

long __thiscall
CVssAdmSnapshotSetEntry::_AddSnapshot_CVssAdmSnapshotSetEntry__QEAAJPEAU_VSS_SNAPSHOT_PROP___Z
          (CVssAdmSnapshotSetEntry *this,_VSS_SNAPSHOT_PROP *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  _VSS_SNAPSHOT_PROP *p_Var6;
  void *pvVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe78;
  CVssFunctionTracer local_158 [8];
  long local_150;
  wchar_t *local_e8;
  wchar_t *local_e0;
  wchar_t *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined4 local_c8;
  undefined1 local_c0 [120];
  undefined4 local_48;
  
  local_e8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_e0 = L"CVssAdmSnapshotSetEntry::AddSnapshot";
  local_d8 = L"ADMPROCC";
  local_d0 = 0x52;
  local_cc = 7;
  local_c8 = 0xff;
  local_48 = 0x1000000;
  memset(local_c0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_e8);
  p_Var6 = operator_new(0x80,&std::nothrow);
  if (p_Var6 == (_VSS_SNAPSHOT_PROP *)0x0) {
    uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x58,
                       7,in_stack_fffffffffffffe78);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_158,uVar8,0x8007000e,L"Out of memory");
  }
  uVar8 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)p_Var6 = *(undefined8 *)param_1;
  *(undefined8 *)(p_Var6 + 8) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x18);
  *(undefined8 *)(p_Var6 + 0x10) = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(p_Var6 + 0x18) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x28);
  *(undefined8 *)(p_Var6 + 0x20) = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)(p_Var6 + 0x28) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x38);
  *(undefined8 *)(p_Var6 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(undefined8 *)(p_Var6 + 0x38) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x48);
  *(undefined8 *)(p_Var6 + 0x40) = *(undefined8 *)(param_1 + 0x40);
  *(undefined8 *)(p_Var6 + 0x48) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x58);
  *(undefined8 *)(p_Var6 + 0x50) = *(undefined8 *)(param_1 + 0x50);
  *(undefined8 *)(p_Var6 + 0x58) = uVar8;
  uVar2 = *(undefined4 *)(param_1 + 100);
  uVar3 = *(undefined4 *)(param_1 + 0x68);
  uVar4 = *(undefined4 *)(param_1 + 0x6c);
  *(undefined4 *)(p_Var6 + 0x60) = *(undefined4 *)(param_1 + 0x60);
  *(undefined4 *)(p_Var6 + 100) = uVar2;
  *(undefined4 *)(p_Var6 + 0x68) = uVar3;
  *(undefined4 *)(p_Var6 + 0x6c) = uVar4;
  uVar2 = *(undefined4 *)(param_1 + 0x74);
  uVar3 = *(undefined4 *)(param_1 + 0x78);
  uVar4 = *(undefined4 *)(param_1 + 0x7c);
  *(undefined4 *)(p_Var6 + 0x70) = *(undefined4 *)(param_1 + 0x70);
  *(undefined4 *)(p_Var6 + 0x74) = uVar2;
  *(undefined4 *)(p_Var6 + 0x78) = uVar3;
  *(undefined4 *)(p_Var6 + 0x7c) = uVar4;
  uVar8 = *(undefined8 *)p_Var6;
  uVar5 = *(undefined8 *)(p_Var6 + 8);
  pvVar7 = realloc(*(void **)(this + 0x18),(longlong)(*(int *)(this + 0x28) + 1) << 4);
  if (pvVar7 != (void *)0x0) {
    *(void **)(this + 0x18) = pvVar7;
    pvVar7 = realloc(*(void **)(this + 0x20),(longlong)(*(int *)(this + 0x28) + 1) << 3);
    if (pvVar7 != (void *)0x0) {
      *(void **)(this + 0x20) = pvVar7;
      iVar1 = *(int *)(this + 0x28);
      *(int *)(this + 0x28) = iVar1 + 1;
      puVar9 = (undefined8 *)((longlong)iVar1 * 0x10 + *(longlong *)(this + 0x18));
      if (puVar9 != (undefined8 *)0x0) {
        *puVar9 = uVar8;
        puVar9[1] = uVar5;
        pvVar7 = *(void **)(this + 0x20);
      }
      puVar9 = (undefined8 *)((longlong)pvVar7 + (longlong)iVar1 * 8);
      if (puVar9 != (undefined8 *)0x0) {
        *puVar9 = p_Var6;
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
      return local_150;
    }
  }
  VssFreeSnapshotProperties(p_Var6);
  operator_delete__(p_Var6);
  uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_e8,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",99,7,
                     in_stack_fffffffffffffe78);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_158,uVar8,0x8007000e,L"Out of memory");
}


