/*
 * Function : ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ
 * Address  : 0x1400035f0
 * Size     : 5 bytes (2 instructions)
 * Prototype: ushort * ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this)
 * CC       : __thiscall
 * Comment  : public: unsigned short * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 & __ptr64)>::Get(void)const __ptr64
 * Binary   : 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476)
 */

/* public: unsigned short * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short *
   __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned
   short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned
   short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short *
   __ptr64 & __ptr64)>::Get(void)const __ptr64 */

ushort * __thiscall
CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
::
_Get___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEBAPEAGXZ
          (CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
           *this)

{
  return *(ushort **)(this + 8);
}


