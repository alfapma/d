/* Function prototypes for 10.0.19041.1.exe (SHA-256 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476) */
#pragma once
#include "types.h"

/* 0x140001010  35 bytes  [__fastcall] */
undefined `dynamic_initializer_for_'dCurrentSKU''(void);

/* 0x140001040  38 bytes  [__thiscall] */
void * ??_ECInternalVerifier@@UEAAPEAXI@Z(CInternalVerifier * this, uint param_1);

/* 0x140001070  491 bytes  [__thiscall] */
void ??1CVssAdminCLI@@QEAA@XZ(CVssAdminCLI * this);

/* 0x140001264  365 bytes  [__thiscall] */
void ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1);

/* 0x1400013dc  1311 bytes  [__thiscall] */
ushort * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1);

/* 0x140001908  957 bytes  [__thiscall] */
int ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2);

/* 0x140001cd0  782 bytes  [__thiscall] */
void ?Initialize@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140001fec  2046 bytes  [__thiscall] */
int ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ(CVssAdminCLI * this);

/* 0x140002800  466 bytes  [__thiscall] */
void ?DoProcessing@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400029dc  953 bytes  [__cdecl] */
long ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z(int param_1, ushort * * param_2);

/* 0x1400032b0  356 bytes  [__cdecl] */
int AssertPrivilege(ushort * param_1);

/* 0x14000341c  64 bytes  [__cdecl] */
int wmain(int _Argc, wchar_t * * _Argv, wchar_t * * _Env);

/* 0x140003464  40 bytes  [__thiscall] */
void ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ(CComPtr<IVssEnumObject> * this);

/* 0x140003494  125 bytes  [__cdecl] */
long StringCchPrintfW(ushort * param_1, __uint64 param_2, ushort * param_3, ...);

/* 0x140003518  207 bytes  [__cdecl] */
long StringCchCatW(ushort * param_1, __uint64 param_2, ushort * param_3);

/* 0x1400035f0  5 bytes  [__thiscall] */
ushort * ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this);

/* 0x1400035fc  130 bytes  [__cdecl] */
long StringCchCopyW(ushort * param_1, __uint64 param_2, ushort * param_3);

/* 0x140003688  318 bytes  [__cdecl] */
void VssSafeDuplicateStr(CVssFunctionTracer * param_1, ushort * * param_2, ushort * param_3);

/* 0x1400037d0  61 bytes  [__thiscall] */
void ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this);

/* 0x140003820  89 bytes  [__thiscall] */
void * ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_> * this, uint param_1);

/* 0x140003880  38 bytes  [__thiscall] */
void * ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this, uint param_1);

/* 0x1400038b0  41 bytes  [__thiscall] */
void ?Close@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEAAXXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this);

/* 0x1400038e0  4 bytes  [__thiscall] */
void ?SetHr@CVssFunctionTracer@@QEAAXJ@Z(CVssFunctionTracer * this, long param_1);

/* 0x1400038ec  4 bytes  [__thiscall] */
long ?GetHr@CVssFunctionTracer@@QEAAJXZ(CVssFunctionTracer * this);

/* 0x1400038f8  164 bytes  [__thiscall] */
ushort * ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1);

/* 0x1400039a4  34 bytes  [__thiscall] */
void ??1CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this);

/* 0x1400039d0  3 bytes  [__thiscall] */
void ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, CVssFunctionTracer * param_1);

/* 0x1400039e0  247 bytes  [__thiscall] */
void ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6);

/* 0x140003ae0  105 bytes  [__thiscall] */
void ?AddDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140003b60  105 bytes  [__thiscall] */
void ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140003be0  180 bytes  [__thiscall] */
void ?QueryReverts@CInternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3);

/* 0x140003ca0  101 bytes  [__thiscall] */
void ?ListDiffAreas@CInternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4);

/* 0x140003d10  494 bytes  [__thiscall] */
void ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7);

/* 0x140003f10  189 bytes  [__thiscall] */
void ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5);

/* 0x140003fe0  247 bytes  [__thiscall] */
void ?ListSnapshots@CExternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6);

/* 0x1400040e0  120 bytes  [__thiscall] */
void ?AddDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140004160  120 bytes  [__thiscall] */
void ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x1400041e0  180 bytes  [__thiscall] */
void ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3);

/* 0x1400042a0  101 bytes  [__thiscall] */
void ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4);

/* 0x140004310  444 bytes  [__thiscall] */
void ?DeleteSnapshots@CExternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7);

/* 0x1400044d8  582 bytes  [__thiscall] */
long ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z(CVssAdmSnapshotSetEntry * this, _VSS_SNAPSHOT_PROP * param_1);

/* 0x140004728  1890 bytes  [__thiscall] */
void ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z(CVssAdmSnapshotSets * this, long param_1, _GUID * param_2, _GUID * param_3, _GUID * param_4, ushort * param_5);

/* 0x140004e98  261 bytes  [__thiscall] */
void ??1CVssAdmSnapshotSets@@QEAA@XZ(CVssAdmSnapshotSets * this);

/* 0x140004fa4  163 bytes  [__thiscall] */
void * ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z(CVssAdmSnapshotSetEntry * this, uint param_1);

/* 0x140005050  410 bytes  [__thiscall] */
void ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z(CVssAdminCLI * this, _GUID * param_1, IUnknown * * param_2);

/* 0x1400051f4  828 bytes  [__thiscall] */
void ?PrintUsage@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000553c  642 bytes  [__thiscall] */
void ?AddDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400057c8  2074 bytes  [__thiscall] */
void ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140005ff4  1131 bytes  [__thiscall] */
void ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z(CVssAdminCLI * this, IVssEnumMgmtObject * param_1);

/* 0x140006468  1857 bytes  [__thiscall] */
void ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140006bbc  2123 bytes  [__thiscall] */
void ?ListSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140007414  244 bytes  [__thiscall] */
void ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140007510  2334 bytes  [__thiscall] */
void ?ListWriters@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140007e44  1128 bytes  [__thiscall] */
void ?ListProviders@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400082b8  1056 bytes  [__thiscall] */
void ?ListVolumes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400086e4  647 bytes  [__thiscall] */
void ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140008974  1439 bytes  [__thiscall] */
void ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140008f20  952 bytes  [__thiscall] */
void ?QueryReverts@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400092e4  342 bytes  [__thiscall] */
void ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2);

/* 0x140009444  758 bytes  [__thiscall] */
void ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2);

/* 0x140009744  1114 bytes  [__thiscall] */
void ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140009ba8  463 bytes  [__thiscall] */
void ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140009d80  47 bytes  [__thiscall] */
void ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ(CVssSimpleArray<_GUID> * this);

/* 0x140009db8  2644 bytes  [__thiscall] */
void ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, bool * param_2);

/* 0x14000a820  814 bytes  [__thiscall] */
void ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, long * param_2);

/* 0x14000ab58  1176 bytes  [__thiscall] */
void ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000affc  578 bytes  [__thiscall] */
ushort * ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z(CVssAdminCLI * this, ulong param_1);

/* 0x14000b248  388 bytes  [__thiscall] */
long ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000b3d4  494 bytes  [__thiscall] */
ushort * ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z(CVssAdminCLI * this, long param_1);

/* 0x14000b5cc  62 bytes  [__thiscall] */
void ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this);

/* 0x14000b614  61 bytes  [__thiscall] */
void ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this);

/* 0x14000b660  90 bytes  [__thiscall] */
void * ??_E?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this, uint param_1);

/* 0x14000b6d0  89 bytes  [__thiscall] */
void * ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this, uint param_1);

/* 0x14000b730  22 bytes  [__cdecl] */
void ?_AtlRaiseException@ATL@@YAXKK@Z(ulong param_1, ulong param_2);

/* 0x14000b754  176 bytes  [__thiscall] */
int ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1);

/* 0x14000b80c  10 bytes  [__thiscall] */
void ??1CComBSTR@ATL@@QEAA@XZ(CComBSTR * this);

/* 0x14000b824  223 bytes  [__thiscall] */
int ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2, int param_3);

/* 0x14000b90c  193 bytes  [__thiscall] */
void ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this, ushort * param_1);

/* 0x14000b9d8  309 bytes  [__thiscall] */
int ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2);

/* 0x14000bb18  7 bytes  [__cdecl] */
void VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP * param_1);

/* 0x14000bb2c  1354 bytes  [__thiscall] */
ushort * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000c084  368 bytes  [__thiscall] */
__uint64 ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000c1fc  650 bytes  [__thiscall] */
ushort * ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z(CVssAdminCLI * this, uint param_1);

/* 0x14000c490  209 bytes  [__thiscall] */
ushort * ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z(CVssAdminCLI * this, bool param_1);

/* 0x14000c568  193 bytes  [__thiscall] */
bool ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z(CVssAdminCLI * this, ushort * param_1, ushort * param_2);

/* 0x14000c630  189 bytes  [__thiscall] */
bool ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2);

/* 0x14000c6f4  369 bytes  [__thiscall] */
void ?OutputMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...);

/* 0x14000c86c  369 bytes  [__thiscall] */
ushort * ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ(CVssAdminCLI * this, int param_1, long param_2, ...);

/* 0x14000c9e4  914 bytes  [__thiscall] */
void ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z(CVssAdminCLI * this, ushort * param_1, __uint64 param_2, long param_3, ulong param_4, ushort * param_5);

/* 0x14000cd84  1318 bytes  [__thiscall] */
__int64 ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z(CVssAdminCLI * this, ushort * param_1, int param_2);

/* 0x14000d2b8  609 bytes  [__thiscall] */
ushort * ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z(CVssAdminCLI * this, __int64 param_1, int param_2);

/* 0x14000d524  603 bytes  [__thiscall] */
void ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...);

/* 0x14000d788  764 bytes  [__thiscall] */
int ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z(CVssAdminCLI * this, long param_1, ulong param_2);

/* 0x14000da90  822 bytes  [__thiscall] */
void ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000ddd4  902 bytes  [__cdecl] */
int MapVssErrorToMsg(long param_1, long * param_2);

/* 0x14000e164  657 bytes  [__cdecl] */
int MapGenericVssErrorToMsg(long param_1, ushort * * param_2);

/* 0x14000e3fc  403 bytes  [__cdecl] */
ushort * GuidToString(_GUID * param_1);

/* 0x14000e598  794 bytes  [__cdecl] */
ushort * DateTimeToString(__int64 * param_1);

/* 0x14000e8bc  748 bytes  [__cdecl] */
ushort MyGetChar(void);

/* 0x14000ebb4  85 bytes  [__cdecl] */
int IsCorrectContext(long param_1);

/* 0x14000ec10  121 bytes  [__cdecl] */
long StringCchPrintfA(char * param_1, __uint64 param_2, char * param_3, ...);

/* 0x14000ec90  255 bytes  [__cdecl] */
long StringCchVPrintfExW(ushort * param_1, __uint64 param_2, ushort * * param_3, __uint64 * param_4, ulong param_5, ushort * param_6, char * param_7);

/* 0x14000ed98  49 bytes  [__thiscall] */
undefined ??0bad_alloc@std@@QEAA@PEBD@Z(bad_alloc * this, char * param_1);

/* 0x14000edd0  15 bytes  [__thiscall] */
void ??1bad_alloc@std@@UEAA@XZ(bad_alloc * this);

/* 0x14000edf0  34 bytes  [__thiscall] */
void ?_Doraise@bad_alloc@std@@MEBAXXZ(bad_alloc * this);

/* 0x14000ee20  57 bytes  [__thiscall] */
void * ??_Gbad_alloc@std@@UEAAPEAXI@Z(bad_alloc * this, uint param_1);

/* 0x14000ee60  33 bytes  [__thiscall] */
undefined ??0bad_alloc@std@@QEAA@AEBV01@@Z(bad_alloc * this, bad_alloc * param_1);

/* 0x14000ee88  8 bytes  [__thiscall] */
void ??1CVssOutputBuffer@@QEAA@XZ(CVssOutputBuffer * this);

/* 0x14000ee98  4 bytes  [__thiscall] */
ushort * ??BCVssAutoCoString@@QEBAPEAGXZ(CVssAutoCoString * this);

/* 0x14000eea4  8 bytes  [__thiscall] */
undefined ??0CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this);

/* 0x14000eeb4  530 bytes  [__thiscall] */
void ?Append@CVssAutoCoString@@QEAAXPEBG@Z(CVssAutoCoString * this, ushort * param_1);

/* 0x14000f0d0  153 bytes  [__thiscall] */
bool ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z(CVssAutoCoString * this, ushort * param_1);

/* 0x14000f170  33 bytes  [__cdecl] */
void InternalThrow(long param_1);

/* 0x14000f198  520 bytes  [__thiscall] */
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@I@Z(CVssResource * this, uint param_1);

/* 0x14000f3ac  75 bytes  [__thiscall] */
undefined ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5, _VSSDBG_SEV_ENUM param_6);

/* 0x14000f400  122 bytes  [__thiscall] */
undefined ??0CVssDebugInfo@@QEAA@AEBU0@@Z(CVssDebugInfo * this, CVssDebugInfo * param_1);

/* 0x14000f484  73 bytes  [__thiscall] */
void ??1CVssDebugInfo@@QEAA@XZ(CVssDebugInfo * this);

/* 0x14000f4d4  321 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@J@Z(CVssDebugInfo * this, long param_1);

/* 0x14000f61c  289 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z(CVssDebugInfo * this, _GUID * param_1);

/* 0x14000f744  209 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z(CVssDebugInfo * this, ushort * param_1);

/* 0x14000f81c  33 bytes  [__thiscall] */
CVssDebugInfo ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1);

/* 0x14000f844  14 bytes  [__thiscall] */
ulong ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1);

/* 0x14000f85c  242 bytes  [__thiscall] */
undefined ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2);

/* 0x14000f958  271 bytes  [__thiscall] */
void ??1CVssFunctionTracer@@QEAA@XZ(CVssFunctionTracer * this);

/* 0x14000fa74  74 bytes  [__thiscall] */
int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z(CVssFunctionTracer * this, ulong param_1);

/* 0x14000fac8  8 bytes  [__thiscall] */
int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ(CVssFunctionTracer * this);

/* 0x14000fad8  408 bytes  [__thiscall] */
void ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ(CVssFunctionTracer * this);

/* 0x14000fc78  316 bytes  [__cdecl] */
void ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ(CVssDebugInfo param_1, ulong param_2, ushort * param_3, ushort * param_4, ...);

/* 0x14000fdbc  123 bytes  [__thiscall] */
void ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3);

/* 0x14000fe40  134 bytes  [__thiscall] */
void ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4);

/* 0x14000fecc  196 bytes  [__thiscall] */
void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3, ...);

/* 0x14000ff98  298 bytes  [__thiscall] */
void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4, ...);

/* 0x1400100cc  577 bytes  [__thiscall] */
ushort * ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ(CVssFunctionTracer * this);

/* 0x140010318  496 bytes  [__thiscall] */
void ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2);

/* 0x140010510  245 bytes  [__thiscall] */
void ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x14001060c  156 bytes  [__thiscall] */
void ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ulong param_2, uchar * param_3);

/* 0x1400106b0  398 bytes  [__thiscall] */
void ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x140010848  359 bytes  [__thiscall] */
void ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3);

/* 0x1400109bc  637 bytes  [__thiscall] */
void ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140010c44  122 bytes  [__thiscall] */
long ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140010ccc  525 bytes  [__thiscall] */
void ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140010ee4  488 bytes  [__thiscall] */
void ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x1400110d8  131 bytes  [__thiscall] */
long ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x140011164  752 bytes  [__thiscall] */
void ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, long param_3, ushort * param_4, ...);

/* 0x140011460  649 bytes  [__thiscall] */
void ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, _GUID param_2, ushort * param_3, ulong param_4, _GUID param_5, IUnknown * * param_6);

/* 0x1400116f0  372 bytes  [__thiscall] */
void ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1);

/* 0x140011870  1510 bytes  [__thiscall] */
void ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z(CVssFunctionTracer * this, ulong param_1, CVssDebugInfo param_2, ushort param_3);

/* 0x140011e68  140 bytes  [__thiscall] */
void ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z(CVssFunctionTracer * this, long param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x140011efc  245 bytes  [__thiscall] */
void ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z(CVssFunctionTracer * this, _com_error * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x140011ff8  126 bytes  [__thiscall] */
void ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z(CVssFunctionTracer * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5);

/* 0x140012080  282 bytes  [__thiscall] */
void ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z(CVssFunctionTracer * this, exception * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x1400121b0  49 bytes  [__thiscall] */
void ??1?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this);

/* 0x1400121e8  253 bytes  [__thiscall] */
undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@PEBG@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, ushort * param_1);

/* 0x1400122f0  22 bytes  [__thiscall] */
undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this);

/* 0x140012310  119 bytes  [__thiscall] */
void ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, bool param_1, __uint64 param_2);

/* 0x140012390  220 bytes  [__thiscall] */
basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?assign@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3);

/* 0x140012478  116 bytes  [__thiscall] */
bool ?_Grow@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAA_N_K_N@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, bool param_2);

/* 0x1400124f4  188 bytes  [__thiscall] */
basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?erase@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2);

/* 0x1400125bc  206 bytes  [__thiscall] */
basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3);

/* 0x140012694  288 bytes  [__thiscall] */
void ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2);

/* 0x1400127e0  248 bytes  [__cdecl] */
void ?Initialize@CVssSKU@@CAXXZ(void);

/* 0x1400128e0  186 bytes  [__thiscall] */
void ??1CVssIOCTLChannel@@QEAA@XZ(CVssIOCTLChannel * this);

/* 0x1400129a4  251 bytes  [__thiscall] */
void ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong * param_2);

/* 0x140012aa8  1069 bytes  [__thiscall] */
long ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ushort * param_2, bool param_3, bool param_4, _VSS_ICHANNEL_LOGGING param_5, ulong param_6, ulong param_7, ulong param_8);

/* 0x140012ee0  1007 bytes  [__thiscall] */
long ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong param_2, bool param_3, _VSS_ICHANNEL_LOGGING param_4, bool param_5, void * param_6);

/* 0x1400132dc  9 bytes  [__thiscall] */
void ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ(CVssIOCTLChannel * this);

/* 0x1400132ec  466 bytes  [__cdecl] */
void GetVolumeNameWithCheck(CVssDebugInfo param_1, long param_2, ushort * param_3, ushort * param_4, ulong param_5);

/* 0x1400134c8  1742 bytes  [__cdecl] */
__int64 ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z(ushort * param_1);

/* 0x140013bf8  956 bytes  [__cdecl] */
__int64 ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ(void);

/* 0x140014004  46 bytes  [__thiscall] */
undefined ??0bad_alloc@std@@QEAA@XZ(bad_alloc * this);

/* 0x140014038  69 bytes  [__cdecl] */
void * operator_new(__uint64 param_1);

/* 0x140014084  5 bytes  [__cdecl] */
void operator_delete[](void * param_1);

/* 0x140014090  211 bytes  [__fastcall] */
undefined8 pre_c_init(void);

/* 0x140014170  73 bytes  [__fastcall] */
undefined pre_cpp_init(void);

/* 0x1400141c0  446 bytes  [__fastcall] */
int __wmainCRTStartup(void);

/* 0x140014390  18 bytes  [__fastcall] */
undefined entry(void);

/* 0x1400143a8  6 bytes  [unknown] */
undefined __CxxFrameHandler3();

/* 0x1400143c0  30 bytes  [__cdecl] */
void __security_check_cookie(uintptr_t _StackCookie);

/* 0x1400143e4  10 bytes  [__fastcall] */
undefined __std_terminate(void);

/* 0x1400143f8  26 bytes  [__cdecl] */
void * operator_new(__uint64 param_1, nothrow_t * param_2);

/* 0x140014420  48 bytes  [__thiscall] */
void * ??_Etype_info@@UEAAPEAXI@Z(type_info * this, uint param_1);

/* 0x140014458  5 bytes  [__cdecl] */
void * operator_new[](__uint64 param_1, nothrow_t * param_2);

/* 0x140014463  6 bytes  [__cdecl] */
void free(void * _Memory);

/* 0x140014470  6 bytes  [unknown] */
undefined _purecall();

/* 0x14001447c  52 bytes  [__fastcall] */
undefined __raise_securityfailure(_EXCEPTION_POINTERS * param_1);

/* 0x1400144c0  369 bytes  [__cdecl] */
void __report_gsfailure(uintptr_t _StackCookie);

/* 0x140014638  247 bytes  [__fastcall] */
undefined __report_rangecheckfailure(void);

/* 0x140014735  6 bytes  [__cdecl] */
void * malloc(size_t _Size);

/* 0x140014741  6 bytes  [__cdecl] */
int _callnewh(size_t _Size);

/* 0x14001474d  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@AEBQEBDH@Z(exception * this, char * * param_1, int param_2);

/* 0x140014759  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@AEBV0@@Z(exception * this, exception * param_1);

/* 0x140014765  6 bytes  [__thiscall] */
void ??1exception@@UEAA@XZ(exception * this);

/* 0x140014780  6 bytes  [__thiscall] */
char * ?what@exception@@UEBAPEBDXZ(exception * this);

/* 0x14001478c  6 bytes  [__stdcall] */
void _CxxThrowException(void * pExceptionObject, ThrowInfo * pThrowInfo);

/* 0x1400147a0  56 bytes  [__cdecl] */
long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS * param_1);

/* 0x1400147e0  24 bytes  [__fastcall] */
undefined8 __CxxSetUnhandledExceptionFilter(void);

/* 0x1400147fe  6 bytes  [__cdecl] */
int _XcptFilter(ulong _ExceptionNum, _EXCEPTION_POINTERS * _ExceptionPtr);

/* 0x14001480c  78 bytes  [__fastcall] */
int * RtlpImageNtHeader(short * param_1);

/* 0x140014868  69 bytes  [__fastcall] */
undefined4 _get_image_app_type(undefined4 param_1);

/* 0x1400148b3  6 bytes  [__cdecl] */
void _amsg_exit(int param_1);

/* 0x1400148c0  3 bytes  [__cdecl] */
int _wsetargv(_exception * _Except);

/* 0x1400148d0  68 bytes  [__cdecl] */
PIMAGE_SECTION_HEADER _FindPESection(PBYTE pImageBase, DWORD_PTR rva);

/* 0x140014920  75 bytes  [__cdecl] */
BOOL _IsNonwritableInCurrentImage(PBYTE pTarget);

/* 0x140014980  45 bytes  [__cdecl] */
BOOL _ValidateImageBase(PBYTE pImageBase);

/* 0x1400149b4  212 bytes  [__cdecl] */
void __security_init_cookie(void);

/* 0x140014a8e  6 bytes  [unknown] */
undefined _initterm();

/* 0x140014a9a  6 bytes  [unknown] */
EXCEPTION_DISPOSITION __C_specific_handler(_EXCEPTION_RECORD * ExceptionRecord, void * EstablisherFrame, _CONTEXT * ContextRecord, _DISPATCHER_CONTEXT * DispatcherContext);

/* 0x140014ab0  3 bytes  [__fastcall] */
undefined _guard_check_icall(void);

/* 0x140014ac8  53 bytes  [__thiscall] */
undefined ??0?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@PEBD@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1);

/* 0x140014b04  108 bytes  [__thiscall] */
undefined ??0length_error@std@@QEAA@AEBV01@@Z(length_error * this, length_error * param_1);

/* 0x140014b78  113 bytes  [__thiscall] */
undefined ??0length_error@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@@Z(length_error * this, basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * param_1);

/* 0x140014bf0  98 bytes  [__thiscall] */
undefined ??0logic_error@std@@QEAA@AEBV01@@Z(logic_error * this, logic_error * param_1);

/* 0x140014c58  108 bytes  [__thiscall] */
undefined ??0out_of_range@std@@QEAA@AEBV01@@Z(out_of_range * this, out_of_range * param_1);

/* 0x140014ccc  113 bytes  [__thiscall] */
undefined ??0out_of_range@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@PEAV_STL70@@@Z(out_of_range * this, basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * param_1, _STL70 * param_2);

/* 0x140014d44  48 bytes  [__thiscall] */
void ??1?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@XZ(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this);

/* 0x140014d7c  65 bytes  [__thiscall] */
void ??1logic_error@std@@UEAA@XZ(logic_error * this);

/* 0x140014dd0  94 bytes  [__thiscall] */
void * ??_Eout_of_range@std@@UEAAPEAXI@Z(out_of_range * this, uint param_1);

/* 0x140014e34  257 bytes  [__thiscall] */
void ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2);

/* 0x140014f60  49 bytes  [__thiscall] */
void ?_Doraise@length_error@std@@MEBAXXZ(length_error * this);

/* 0x140014fa0  49 bytes  [__thiscall] */
void ?_Doraise@logic_error@std@@MEBAXXZ(logic_error * this);

/* 0x140014fe0  49 bytes  [__thiscall] */
void ?_Doraise@out_of_range@std@@MEBAXXZ(out_of_range * this);

/* 0x140015018  100 bytes  [__thiscall] */
void ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, bool param_1, __uint64 param_2);

/* 0x140015084  84 bytes  [__cdecl] */
void ?_Xlen@_String_base@std@@SAXXZ(void);

/* 0x1400150e0  87 bytes  [__cdecl] */
void ?_Xran@_String_base@std@@SAXXZ(void);

/* 0x140015140  246 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3);

/* 0x140015240  245 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@PEBD_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1, __uint64 param_2);

/* 0x14001533c  149 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2);

/* 0x1400153e0  15 bytes  [__thiscall] */
char * ?what@logic_error@std@@UEBAPEBDXZ(logic_error * this);

/* 0x1400153f5  6 bytes  [__cdecl] */
errno_t memcpy_s(void * _Dst, rsize_t _DstSize, void * _Src, rsize_t _MaxCount);

/* 0x140015404  5 bytes  [__cdecl] */
void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4);

/* 0x140015410  103 bytes  [__cdecl] */
void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4);

/* 0x140015480  82 bytes  [__cdecl] */
void __ArrayUnwind(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4);

/* 0x1400154d8  6 bytes  [__cdecl] */
errno_t memmove_s(void * _Dst, rsize_t _DstSize, void * _Src, rsize_t _MaxCount);

/* 0x1400154e4  5 bytes  [__cdecl] */
void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5);

/* 0x1400154f0  109 bytes  [__cdecl] */
void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5);

/* 0x140015563  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@XZ(exception * this);

/* 0x140015570  29 bytes  [__fastcall] */
undefined8 __GSHandlerCheck(undefined8 param_1, undefined8 param_2, undefined8 param_3, longlong param_4);

/* 0x140015594  91 bytes  [__fastcall] */
ulonglong __GSHandlerCheckCommon(undefined8 param_1, longlong param_2);

/* 0x1400155f8  127 bytes  [__fastcall] */
undefined __GSHandlerCheck_EH(longlong param_1, undefined8 param_2, undefined8 param_3, longlong param_4);

/* 0x140015686  6 bytes  [__cdecl] */
void * memcpy(void * _Dst, void * _Src, size_t _Size);

/* 0x140015692  6 bytes  [__cdecl] */
void * memset(void * _Dst, int _Val, size_t _Size);

/* 0x1400156b0  2 bytes  [__fastcall] */
undefined _guard_dispatch_icall(void);

/* 0x1400156d0  77 bytes  [__fastcall] */
undefined __chkstk(void);

/* 0x140015723  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015735  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015747  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015759  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x14001576b  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x14001577d  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x14001578f  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x1400157a1  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400157b3  12 bytes  [__fastcall] */
undefined dtor$17(undefined8 param_1, longlong param_2);

/* 0x1400157c5  86 bytes  [__fastcall] */
undefined * catch$21(undefined8 param_1, longlong param_2);

/* 0x14001581c  87 bytes  [__fastcall] */
undefined * catch$22(undefined8 param_1, longlong param_2);

/* 0x140015874  75 bytes  [__fastcall] */
undefined * catch$23(undefined8 param_1, longlong param_2);

/* 0x1400158c0  87 bytes  [__fastcall] */
undefined * catch$24(undefined8 param_1, longlong param_2);

/* 0x140015918  86 bytes  [__fastcall] */
undefined * catch$25(undefined8 param_1, longlong param_2);

/* 0x14001596f  87 bytes  [__fastcall] */
undefined * catch$26(undefined8 param_1, longlong param_2);

/* 0x1400159c7  75 bytes  [__fastcall] */
undefined * catch$27(undefined8 param_1, longlong param_2);

/* 0x140015a13  87 bytes  [__fastcall] */
undefined8 catch$28(undefined8 param_1, longlong param_2);

/* 0x140015a71  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015a83  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015a95  83 bytes  [__fastcall] */
undefined * catch$4(undefined8 param_1, longlong param_2);

/* 0x140015ae9  84 bytes  [__fastcall] */
undefined * catch$5(undefined8 param_1, longlong param_2);

/* 0x140015b3e  75 bytes  [__fastcall] */
undefined * catch$6(undefined8 param_1, longlong param_2);

/* 0x140015b8a  84 bytes  [__fastcall] */
undefined8 catch$7(undefined8 param_1, longlong param_2);

/* 0x140015be5  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015bf7  12 bytes  [__fastcall] */
undefined dtor$9(undefined8 param_1, longlong param_2);

/* 0x140015c09  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015c1b  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015c2d  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140015c3f  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015c51  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015c63  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015c75  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015c87  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140015c99  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140015cab  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015cbd  12 bytes  [__fastcall] */
undefined dtor$7(undefined8 param_1, longlong param_2);

/* 0x140015ccf  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x140015ce1  12 bytes  [__fastcall] */
undefined dtor$7(undefined8 param_1, longlong param_2);

/* 0x140015cf3  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015d05  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015d17  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015d29  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015d3b  12 bytes  [__fastcall] */
undefined dtor$10(undefined8 param_1, longlong param_2);

/* 0x140015d4d  12 bytes  [__fastcall] */
undefined dtor$12(undefined8 param_1, longlong param_2);

/* 0x140015d5f  12 bytes  [__fastcall] */
undefined dtor$13(undefined8 param_1, longlong param_2);

/* 0x140015d71  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015d83  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015d95  12 bytes  [__fastcall] */
undefined dtor$14(undefined8 param_1, longlong param_2);

/* 0x140015da7  12 bytes  [__fastcall] */
undefined dtor$17(undefined8 param_1, longlong param_2);

/* 0x140015db9  12 bytes  [__fastcall] */
undefined dtor$18(undefined8 param_1, longlong param_2);

/* 0x140015dcb  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015ddd  12 bytes  [__fastcall] */
undefined dtor$14(undefined8 param_1, longlong param_2);

/* 0x140015def  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015e01  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015e13  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015e25  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015e37  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015e49  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015e5b  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015e6d  12 bytes  [__fastcall] */
undefined dtor$11(undefined8 param_1, longlong param_2);

/* 0x140015e7f  12 bytes  [__fastcall] */
undefined dtor$15(undefined8 param_1, longlong param_2);

/* 0x140015e91  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015ea3  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015eb5  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140015ec7  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015ed9  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x140015eeb  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015efd  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015f0f  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015f21  36 bytes  [__fastcall] */
undefined catch$5(undefined8 param_1, longlong param_2);

/* 0x140015f4c  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140015f5e  45 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015f92  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015fa4  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140015fb6  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015fc8  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140015fda  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140015fec  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015ffe  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140016010  26 bytes  [__fastcall] */
undefined8 catch$2(void);

/* 0x14001602b  26 bytes  [__fastcall] */
undefined * catch$3(void);

/* 0x140016046  26 bytes  [__fastcall] */
undefined * catch$4(void);

/* 0x140016067  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016079  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x14001608b  26 bytes  [__fastcall] */
undefined1 * catch$2(void);

/* 0x1400160a6  26 bytes  [__fastcall] */
undefined1 * catch$3(void);

/* 0x1400160c1  26 bytes  [__fastcall] */
undefined1 * catch$4(void);

/* 0x1400160e2  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x1400160f4  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140016106  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016118  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x14001612a  89 bytes  [__fastcall] */
undefined * catch$12(undefined8 param_1, longlong param_2);

/* 0x140016184  90 bytes  [__fastcall] */
undefined * catch$13(undefined8 param_1, longlong param_2);

/* 0x1400161df  78 bytes  [__fastcall] */
undefined * catch$14(undefined8 param_1, longlong param_2);

/* 0x14001622e  90 bytes  [__fastcall] */
undefined * catch$15(undefined8 param_1, longlong param_2);

/* 0x14001628f  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x1400162a1  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x1400162b3  103 bytes  [__fastcall] */
undefined * catch$1(undefined8 param_1, longlong param_2);

/* 0x14001631b  39 bytes  [__fastcall] */
undefined catch$0(undefined8 param_1, longlong param_2);

/* 0x140016349  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x14001635b  89 bytes  [__fastcall] */
undefined * catch$16(undefined8 param_1, longlong param_2);

/* 0x1400163b5  90 bytes  [__fastcall] */
undefined * catch$17(undefined8 param_1, longlong param_2);

/* 0x140016410  78 bytes  [__fastcall] */
undefined * catch$18(undefined8 param_1, longlong param_2);

/* 0x14001645f  90 bytes  [__fastcall] */
undefined * catch$19(undefined8 param_1, longlong param_2);

/* 0x1400164c0  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400164d2  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x1400164e4  86 bytes  [__fastcall] */
undefined * catch$8(undefined8 param_1, longlong param_2);

/* 0x14001653b  90 bytes  [__fastcall] */
undefined * catch$9(undefined8 param_1, longlong param_2);

/* 0x140016596  78 bytes  [__fastcall] */
undefined * catch$10(undefined8 param_1, longlong param_2);

/* 0x1400165e5  90 bytes  [__fastcall] */
undefined * catch$11(undefined8 param_1, longlong param_2);

/* 0x140016646  29 bytes  [__fastcall] */
undefined __wmainCRTStartup$filt$0(_EXCEPTION_POINTERS * param_1);

/* 0x14001666a  31 bytes  [__fastcall] */
undefined * catch$0(undefined8 param_1, longlong param_2);

/* 0x140016690  31 bytes  [__fastcall] */
bool _IsNonwritableInCurrentImage$filt$0(undefined8 * param_1);

/* 0x1400166b6  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400166c8  100 bytes  [__fastcall] */
undefined * catch$1(undefined8 param_1, longlong param_2);

/* 0x14001672d  39 bytes  [__fastcall] */
undefined catch$0(undefined8 param_1, longlong param_2);

/* 0x14001675b  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x14001676d  43 bytes  [__fastcall] */
undefined fin$0(undefined8 param_1, longlong param_2);

/* 0x14001679f  64 bytes  [__fastcall] */
undefined4 filt$0(undefined8 param_1, longlong param_2);

/* 0x1400167e7  43 bytes  [__fastcall] */
undefined fin$0(undefined8 param_1, longlong param_2);

