/*
 * Binary   : 10.0.19041.1.exe
 * Path     : /root/reverse/work/vssadmin/10.0.19041.1/10.0.19041.1.exe
 * SHA-256  : 7e36e8c3f7efa5378e12f854e769fdb636a983bcdf338951c40e30659d3f9476
 * Format   : Portable Executable (PE)
 * Language : x86:LE:64:default
 * Compiler : windows
 * ImageBase: 0x140000000
 * Generated: Thu Oct 22 01:01:46 EDT 2026
 *
 * Pseudocode produced by Ghidra 12.1.4 from the exact Microsoft public PDB for this binary.
 */
/* ==========================================================================
 * `dynamic_initializer_for_'dCurrentSKU'' @ 0x140001010  (35 bytes, 8 instructions)
 * undefined `dynamic_initializer_for_'dCurrentSKU''(void)
 * ========================================================================== */

void _dynamic_initializer_for__dCurrentSKU__(void)

{
  if (CVssSKU::ms_bInitialized == 0) {
    CVssSKU::_Initialize_CVssSKU__CAXXZ();
  }
  dCurrentSKU = CVssSKU::ms_eSKU;
  return;
}



/* ==========================================================================
 * ??_ECInternalVerifier@@UEAAPEAXI@Z @ 0x140001040  (38 bytes, 12 instructions)
 * void * ??_ECInternalVerifier@@UEAAPEAXI@Z(CInternalVerifier * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl CInternalVerifier::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl CInternalVerifier::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
CInternalVerifier::___ECInternalVerifier__UEAAPEAXI_Z(CInternalVerifier *this,uint param_1)

{
  *(undefined ***)this = &CCommandVerifier::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ??1CVssAdminCLI@@QEAA@XZ @ 0x140001070  (491 bytes, 126 instructions)
 * void ??1CVssAdminCLI@@QEAA@XZ(CVssAdminCLI * this)
 * public: __cdecl CVssAdminCLI::~CVssAdminCLI(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: __cdecl CVssAdminCLI::~CVssAdminCLI(void) __ptr64 */

void __thiscall CVssAdminCLI::__1CVssAdminCLI__QEAA_XZ(CVssAdminCLI *this)

{
  LPVOID pv;
  undefined8 *puVar1;
  CVssAdminCLI *pCVar2;
  uint uVar3;
  uint uVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar4 = 0;
  uVar3 = uVar4;
  if (*(int *)(this + 0x20) != 0) {
    do {
      lVar6 = *(longlong *)(this + 0x18);
      lVar5 = (longlong)(int)uVar3;
      CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
      uVar3 = uVar3 + 1;
      *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
    } while (uVar3 < *(uint *)(this + 0x20));
  }
  uVar3 = uVar4;
  if (*(int *)(this + 0x38) != 0) {
    do {
      lVar6 = *(longlong *)(this + 0x30);
      lVar5 = (longlong)(int)uVar3;
      CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
      uVar3 = uVar3 + 1;
      *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
    } while (uVar3 < *(uint *)(this + 0x38));
  }
  puVar1 = *(undefined8 **)(this + 0x40);
  if (puVar1 != (undefined8 *)0x0) {
    if (*(int *)(puVar1 + 2) != 0) {
      do {
        lVar6 = puVar1[1];
        lVar5 = (longlong)(int)uVar4;
        CoTaskMemFree(*(LPVOID *)(lVar6 + lVar5 * 8));
        *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
        pv = *(LPVOID *)(**(longlong **)(this + 0x40) + lVar5 * 8);
        *(LPVOID *)(lVar6 + lVar5 * 8) = pv;
        CoTaskMemFree(pv);
        *(undefined8 *)(lVar6 + lVar5 * 8) = 0;
        uVar4 = uVar4 + 1;
        puVar1 = *(undefined8 **)(this + 0x40);
      } while (uVar4 < *(uint *)(puVar1 + 2));
    }
    if (puVar1 != (undefined8 *)0x0) {
      if ((void *)*puVar1 != (void *)0x0) {
        free((void *)*puVar1);
        *puVar1 = 0;
      }
      if ((void *)puVar1[1] != (void *)0x0) {
        free((void *)puVar1[1]);
        puVar1[1] = 0;
      }
      *(undefined4 *)(puVar1 + 2) = 0;
      operator_delete__(puVar1);
    }
  }
  puVar1 = *(undefined8 **)this;
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  if (this[0xf0] != (CVssAdminCLI)0x0) {
    CoUninitialize();
  }
  pCVar2 = this + 0x68;
  lVar6 = 0xe;
  do {
    CoTaskMemFree(*(LPVOID *)pCVar2);
    *(undefined8 *)pCVar2 = 0;
    pCVar2 = pCVar2 + 8;
    lVar6 = lVar6 + -1;
  } while (lVar6 != 0);
  if (*(void **)(this + 0x28) != (void *)0x0) {
    free(*(void **)(this + 0x28));
    *(undefined8 *)(this + 0x28) = 0;
  }
  if (*(void **)(this + 0x30) != (void *)0x0) {
    free(*(void **)(this + 0x30));
    *(undefined8 *)(this + 0x30) = 0;
  }
  *(undefined4 *)(this + 0x38) = 0;
  if (*(void **)(this + 0x10) != (void *)0x0) {
    free(*(void **)(this + 0x10));
    *(undefined8 *)(this + 0x10) = 0;
  }
  if (*(void **)(this + 0x18) != (void *)0x0) {
    free(*(void **)(this + 0x18));
    *(undefined8 *)(this + 0x18) = 0;
  }
  *(undefined4 *)(this + 0x20) = 0;
  return;
}



/* ==========================================================================
 * ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z @ 0x140001264  (365 bytes, 88 instructions)
 * void ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1)
 * private: void __cdecl CVssAdminCLI::GetProviderId(struct _GUID * __ptr64) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::GetProviderId(struct _GUID * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(CVssAdminCLI *this,_GUID *param_1)

{
  bool bVar1;
  int iVar2;
  ushort *puVar3;
  undefined8 uVar4;
  CVssAdminCLI *this_00;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_138 = L"CVssAdminCLI::GetProviderId";
  local_130 = L"ADMVADMC";
  local_128 = 0xd8;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  if (*(int *)(&DAT_1400172e4 + (longlong)*(int *)(this + 0x60) * 0x60) == 0) {
    param_1->Data1 = 0xb5946137;
    param_1->Data2 = 0x7b9f;
    param_1->Data3 = 0x4925;
    param_1->Data4[0] = 0xaf;
    param_1->Data4[1] = 0x80;
    param_1->Data4[2] = 'Q';
    param_1->Data4[3] = 0xab;
    param_1->Data4[4] = 0xd6;
    param_1->Data4[5] = '\v';
    param_1->Data4[6] = ' ';
    param_1->Data4[7] = 0xd5;
  }
  else {
    param_1->Data1 = 0;
    param_1->Data2 = 0;
    param_1->Data3 = 0;
    param_1->Data4[0] = '\0';
    param_1->Data4[1] = '\0';
    param_1->Data4[2] = '\0';
    param_1->Data4[3] = '\0';
    param_1->Data4[4] = '\0';
    param_1->Data4[5] = '\0';
    param_1->Data4[6] = '\0';
    param_1->Data4[7] = '\0';
    this_00 = this;
    puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,8);
    if (puVar3 != (ushort *)0x0) {
      bVar1 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar3,param_1);
      if (!bVar1) {
        iVar2 = _GetProviderIdByName_CVssAdminCLI__AEAAHPEBGPEAU_GUID___Z(this_00,puVar3,param_1);
        if (iVar2 == 0) {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000274c,puVar3);
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_140,
                             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                             (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderId",0xf3,7,
                             in_stack_fffffffffffffea8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_98,uVar4,0,L"Already printed error message");
        }
      }
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return;
}



/* ==========================================================================
 * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z @ 0x1400013dc  (1311 bytes, 301 instructions)
 * ushort * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1)
 * private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID & __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID &
   __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetProviderName_CVssAdminCLI__AEAAPEBGAEAU_GUID___Z
          (CVssAdminCLI *this,_GUID *param_1)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auVar5 [16];
  int iVar6;
  void *pvVar7;
  ushort *puVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  ushort *puVar12;
  undefined1 auStackY_288 [32];
  _VSSDBG_SEV_ENUM _Var13;
  longlong **pplVar14;
  _GUID local_248;
  longlong *local_238;
  longlong *local_230;
  undefined1 local_228 [16];
  undefined1 local_218 [16];
  wchar_t *local_208;
  wchar_t *local_200;
  wchar_t *local_1f8;
  undefined4 local_1f0;
  undefined4 local_1ec;
  undefined4 local_1e8;
  undefined1 local_1e0 [120];
  undefined4 local_168;
  CVssFunctionTracer local_158 [8];
  int local_150;
  undefined8 local_e8;
  undefined1 local_d8 [8];
  longlong local_d0;
  longlong local_c8;
  ushort *local_c0;
  LPVOID local_b0;
  ulonglong local_48;
  
  local_e8 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_288;
  local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_200 = L"CVssAdminCLI::GetProviderName";
  local_1f8 = L"ADMVADMC";
  local_1f0 = 0xfd;
  local_1ec = 7;
  local_1e8 = 0xff;
  local_168 = 0x1000000;
  memset(local_1e0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158);
  lVar3._0_4_ = param_1->Data1;
  lVar3._4_2_ = param_1->Data2;
  lVar3._6_2_ = param_1->Data3;
  local_248 = *param_1;
  puVar8 = (ushort *)0x0;
  if (0 < *(int *)(this + 0x38)) {
    do {
      iVar6 = (int)puVar8;
      plVar10 = (longlong *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
      if ((*plVar10 == lVar3) && (plVar10[1] == *(longlong *)param_1->Data4)) goto LAB_1400014c7;
      puVar8 = (ushort *)(ulonglong)(iVar6 + 1U);
    } while ((int)(iVar6 + 1U) < *(int *)(this + 0x38));
  }
  iVar6 = -1;
LAB_1400014c7:
  if ((iVar6 == -1) ||
     (puVar8 = *(ushort **)(*(longlong *)(this + 0x30) + (longlong)iVar6 * 8),
     puVar8 == (ushort *)0x0)) {
    local_230 = (longlong *)0x0;
    local_248 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
    local_218 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
    local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
    local_200 = L"CVssAdminCLI::GetProviderName";
    local_1f8 = L"ADMVADMC";
    local_1f0 = 0x106;
    local_1ec = 7;
    local_1e8 = 0xff;
    local_168 = 0x1000000;
    memset(local_1e0,0,0x78);
    pplVar14 = &local_230;
    CVssFunctionTracer::
    _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
              (local_158,&local_208,local_218,L"Coordinator");
    if (local_150 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_208,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC"
                 ,(ushort *)L"CVssAdminCLI::GetProviderName",0x10d,7,(_VSSDBG_SEV_ENUM)pplVar14);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
    }
    local_238 = (longlong *)0x0;
    local_218 = ZEXT816(0);
    local_150 = (**(code **)(*local_230 + 0x50))(local_230,local_218,1,4);
    if (local_150 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_208,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC"
                 ,(ushort *)L"CVssAdminCLI::GetProviderName",0x115,7,(_VSSDBG_SEV_ENUM)pplVar14);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
    }
    while( true ) {
      local_150 = (**(code **)(*local_238 + 0x18))(local_238,1,local_d8,local_228);
      if (local_150 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_208,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                   (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderName",0x120,7,
                   (_VSSDBG_SEV_ENUM)pplVar14);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_158);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_158);
      }
      if (local_150 == 1) break;
      CoTaskMemFree(local_b0);
      puVar8 = local_c0;
      _Var13 = (_VSSDBG_SEV_ENUM)pplVar14;
      local_b0 = (LPVOID)0x0;
      lVar2._0_4_ = param_1->Data1;
      lVar2._4_2_ = param_1->Data2;
      lVar2._6_2_ = param_1->Data3;
      if ((local_d0 == lVar2) && (local_c8 == *(longlong *)param_1->Data4)) {
        local_218._8_8_ = local_c0;
        local_218._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auVar5._8_8_ = 0;
        auVar5[0] = local_248.Data4[0];
        auVar5[1] = local_248.Data4[1];
        auVar5[2] = local_248.Data4[2];
        auVar5[3] = local_248.Data4[3];
        auVar5[4] = local_248.Data4[4];
        auVar5[5] = local_248.Data4[5];
        auVar5[6] = local_248.Data4[6];
        auVar5[7] = local_248.Data4[7];
        local_248 = (_GUID)(auVar5 << 0x40);
        puVar12 = (ushort *)0x0;
        if (local_c0 != (ushort *)0x0) {
          VssSafeDuplicateStr(local_158,(ushort **)&local_248,local_c0);
          puVar12 = (ushort *)local_248._0_8_;
        }
        local_248._0_8_ = puVar12;
        uVar9 = *(undefined8 *)param_1;
        uVar4 = *(undefined8 *)param_1->Data4;
        pvVar7 = realloc(*(void **)(this + 0x28),(longlong)(*(int *)(this + 0x38) + 1) << 4);
        if (pvVar7 != (void *)0x0) {
          *(void **)(this + 0x28) = pvVar7;
          pvVar7 = realloc(*(void **)(this + 0x30),(longlong)(*(int *)(this + 0x38) + 1) << 3);
          if (pvVar7 != (void *)0x0) {
            *(void **)(this + 0x30) = pvVar7;
            iVar6 = *(int *)(this + 0x38);
            *(int *)(this + 0x38) = iVar6 + 1;
            puVar11 = (undefined8 *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
            if (puVar11 != (undefined8 *)0x0) {
              *puVar11 = uVar9;
              puVar11[1] = uVar4;
              pvVar7 = *(void **)(this + 0x30);
            }
            puVar1 = (ulonglong *)((longlong)pvVar7 + (longlong)iVar6 * 8);
            if (puVar1 != (ulonglong *)0x0) {
              *puVar1 = (ulonglong)puVar12;
            }
            if (puVar8 != (ushort *)0x0) {
              CoTaskMemFree(puVar8);
            }
            if (local_238 != (longlong *)0x0) {
              (**(code **)(*local_238 + 0x10))();
            }
            if (local_230 != (longlong *)0x0) {
              (**(code **)(*local_230 + 0x10))();
            }
            CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
            return puVar12;
          }
        }
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_248);
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderName",0x142,1,
                           _Var13);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x8007000e,L"Memory allocation error");
      }
      CoTaskMemFree(local_c0);
      local_c0 = (ushort *)0x0;
    }
    puVar8 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,0x66);
    if (local_238 != (longlong *)0x0) {
      (**(code **)(*local_238 + 0x10))();
    }
    if (local_230 != (longlong *)0x0) {
      (**(code **)(*local_230 + 0x10))();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
                    /* WARNING: Read-only address (ram,0x000140019060) is written */
                    /* WARNING: Read-only address (ram,0x000140019070) is written */
  return puVar8;
}



/* ==========================================================================
 * ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z @ 0x140001908  (957 bytes, 203 instructions)
 * int ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2)
 * private: int __cdecl CVssAdminCLI::GetProviderIdByName(unsigned short const * __ptr64,struct _GUID * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: int __cdecl CVssAdminCLI::GetProviderIdByName(unsigned short const * __ptr64,struct
   _GUID * __ptr64) __ptr64 */

int __thiscall
CVssAdminCLI::_GetProviderIdByName_CVssAdminCLI__AEAAHPEBGPEAU_GUID___Z
          (CVssAdminCLI *this,ushort *param_1,_GUID *param_2)

{
  int iVar1;
  undefined1 auStackY_268 [32];
  longlong **pplVar2;
  longlong *local_220;
  undefined1 local_218 [16];
  GUID local_208;
  GUID local_1f8;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  wchar_t *local_1d8;
  undefined4 local_1d0;
  undefined4 local_1cc;
  undefined4 local_1c8;
  undefined1 local_1c0 [120];
  undefined4 local_148;
  CVssFunctionTracer local_138 [8];
  int local_130;
  undefined8 local_c8;
  undefined1 local_b8 [8];
  ulong local_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  wchar_t *local_a0;
  LPVOID local_90;
  ulonglong local_28;
  
  local_c8 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_268;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e0 = L"CVssAdminCLI::GetProviderIdByName";
  local_1d8 = L"ADMVADMC";
  local_1d0 = 0x14e;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_138);
  local_220 = (longlong *)0x0;
  local_208 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_1f8 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e0 = L"CVssAdminCLI::GetProviderIdByName";
  local_1d8 = L"ADMVADMC";
  local_1d0 = 0x153;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  pplVar2 = &local_220;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_138,&local_1e8,&local_1f8,L"Coordinator");
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1e8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::GetProviderIdByName",0x15a,7,(_VSSDBG_SEV_ENUM)pplVar2);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_1f8 = (GUID)ZEXT816(0);
  local_130 = (**(code **)(*local_220 + 0x50))(local_220,&local_1f8,1,4);
  if (-1 < local_130) {
    while( true ) {
      local_130 = (**(code **)(lRam0000000000000000 + 0x18))(0,1,local_b8,local_218);
      if (local_130 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1e8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                   (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderIdByName",0x16d,7,
                   (_VSSDBG_SEV_ENUM)pplVar2);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
      }
      if (local_130 == 1) break;
      CoTaskMemFree(local_90);
      local_90 = (LPVOID)0x0;
      iVar1 = _wcsicmp(local_a0,(wchar_t *)param_1);
      if (iVar1 == 0) {
        CoTaskMemFree(local_a0);
        local_a0 = (wchar_t *)0x0;
        param_2->Data1 = local_b0;
        param_2->Data2 = (undefined2)uStack_ac;
        param_2->Data3 = uStack_ac._2_2_;
        *(undefined4 *)param_2->Data4 = uStack_a8;
        *(undefined4 *)(param_2->Data4 + 4) = uStack_a4;
        if (false) {
          (**(code **)(lRam0000000000000000 + 0x10))();
        }
        if (local_220 != (longlong *)0x0) {
          (**(code **)(*local_220 + 0x10))();
        }
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
        return 1;
      }
      CoTaskMemFree(local_a0);
      local_a0 = (wchar_t *)0x0;
    }
    param_2->Data1 = 0;
    param_2->Data2 = 0;
    param_2->Data3 = 0;
    param_2->Data4[0] = '\0';
    param_2->Data4[1] = '\0';
    param_2->Data4[2] = '\0';
    param_2->Data4[3] = '\0';
    param_2->Data4[4] = '\0';
    param_2->Data4[5] = '\0';
    param_2->Data4[6] = '\0';
    param_2->Data4[7] = '\0';
    if (false) {
      (**(code **)(lRam0000000000000000 + 0x10))();
    }
    if (local_220 != (longlong *)0x0) {
      (**(code **)(*local_220 + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
                    /* WARNING: Read-only address (ram,0x000140019060) is written */
                    /* WARNING: Read-only address (ram,0x000140019070) is written */
    return 0;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1e8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::GetProviderIdByName",0x162,7,(_VSSDBG_SEV_ENUM)pplVar2);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
}



/* ==========================================================================
 * ?Initialize@CVssAdminCLI@@AEAAXXZ @ 0x140001cd0  (782 bytes, 177 instructions)
 * void ?Initialize@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::Initialize(void) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::Initialize(void) __ptr64 */

void __thiscall CVssAdminCLI::_Initialize_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  DWORD DVar1;
  DWORD DVar2;
  DWORD DVar3;
  HANDLE pvVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  CVssFunctionTracer *pCVar8;
  undefined **ppuVar9;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  _VSSDBG_SEV_ENUM _Var10;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  undefined8 local_a0;
  CVssFunctionTracer local_98 [8];
  HRESULT local_90;
  
  local_a0 = 0xfffffffffffffffe;
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_140 = L"CVssAdminCLI::Initialize";
  local_138 = L"ADMVADMC";
  local_130 = 0x19b;
  local_12c = 7;
  local_128 = 0xff;
  puVar6 = (undefined8 *)0x0;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  SetThreadUILanguage(0);
  pvVar4 = GetStdHandle(0xfffffff5);
  *(HANDLE *)(this + 8) = pvVar4;
  if (pvVar4 == (HANDLE)0xffffffffffffffff) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_148,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::Initialize",0x1a7,7,
                       in_stack_fffffffffffffe98);
    DVar2 = GetLastError();
    DVar3 = GetLastError();
    DVar1 = DVar2 & 0xffff | 0x80070000;
    if ((int)DVar2 < 1) {
      DVar1 = DVar2;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar7,DVar1,L"Initialize - Error from GetStdHandle(), rc: %d",DVar3);
  }
  local_90 = CoInitializeEx((LPVOID)0x0,0);
  if (local_90 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::Initialize",0x1af,7,in_stack_fffffffffffffe98);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  this[0xf0] = (CVssAdminCLI)0x1;
  _Var10 = 0;
  local_90 = CoInitializeSecurity
                       ((PSECURITY_DESCRIPTOR)0x0,-1,(SOLE_AUTHENTICATION_SERVICE *)0x0,(void *)0x0,
                        6,2,(void *)0x0,0,(void *)0x0);
  if (local_90 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::Initialize",0x1c1,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_140 = L"CVssAdminCLI::Initialize";
  local_138 = L"ADMVADMC";
  local_130 = 0x1c6;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  pCVar8 = local_98;
  CVssFunctionTracer::_ComDisableSEH_CVssFunctionTracer__QEAAXUCVssDebugInfo___Z
            (local_98,&local_148);
  AssertPrivilege((ushort *)pCVar8);
  if (dCurrentSKU == 0xfffffff8) {
    puVar5 = operator_new(8,&std::nothrow);
    if (puVar5 == (undefined8 *)0x0) goto LAB_140001e7f;
    ppuVar9 = &CInternalVerifier::_vftable_;
    puVar6 = puVar5;
  }
  else {
    puVar5 = operator_new(8,&std::nothrow);
    if (puVar5 == (undefined8 *)0x0) goto LAB_140001e7f;
    ppuVar9 = &CExternalVerifier::_vftable_;
    puVar6 = puVar5;
  }
  *puVar6 = ppuVar9;
LAB_140001e7f:
  *(undefined8 **)this = puVar6;
  if (puVar6 == (undefined8 *)0x0) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_148,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::Initialize",0x1d2,7,_Var10);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar7,0x8007000e,L"Out of memory");
  }
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002710);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return;
}



/* ==========================================================================
 * ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ @ 0x140001fec  (2046 bytes, 441 instructions)
 * int ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ(CVssAdminCLI * this)
 * private: int __cdecl CVssAdminCLI::ParseCmdLine(void) __ptr64
 * ========================================================================== */

/* private: int __cdecl CVssAdminCLI::ParseCmdLine(void) __ptr64 */

int __thiscall CVssAdminCLI::_ParseCmdLine_CVssAdminCLI__AEAAHXZ(CVssAdminCLI *this)

{
  LPVOID pvVar1;
  bool bVar2;
  long lVar3;
  int iVar4;
  ushort *puVar5;
  ushort *puVar6;
  wchar_t *pwVar7;
  longlong lVar8;
  undefined8 uVar9;
  wchar_t *pwVar10;
  CVssAdminCLI *pCVar11;
  ulonglong uVar12;
  longlong lVar13;
  undefined **ppuVar14;
  CVssAdminCLI *pCVar15;
  ulonglong uVar16;
  uint uVar17;
  ulonglong uVar18;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffde8;
  wchar_t *local_208;
  wchar_t *local_200;
  wchar_t *local_1f8;
  undefined4 local_1f0;
  undefined4 local_1ec;
  undefined4 local_1e8;
  undefined1 local_1e0 [120];
  undefined4 local_168;
  CVssFunctionTracer local_158 [8];
  long local_150;
  undefined8 local_e8;
  CVssDebugInfo local_e0 [168];
  
  local_e8 = 0xfffffffffffffffe;
  local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_200 = L"CVssAdminCLI::ParseCmdLine";
  local_1f8 = L"ADMVADMC";
  local_1f0 = 0x1e8;
  local_1ec = 7;
  local_1e8 = 0xff;
  uVar12 = 0;
  local_168 = 0x1000000;
  memset(local_1e0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_208);
  _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,true);
  puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
  if (puVar5 == (ushort *)0x0) {
LAB_140002548:
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_e0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                       (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x1f9,7,
                       in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_158,uVar9,0x1002,L"Incomplete command");
  }
  if ((((*puVar5 == 0x2f) && (puVar5[1] == 0x3f)) && (puVar5[2] == 0)) ||
     (((*puVar5 == 0x2d && (puVar5[1] == 0x3f)) && (puVar5[2] == 0)))) {
LAB_140002275:
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
    iVar4 = 0;
  }
  else {
    pCVar15 = this;
    puVar6 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    if (puVar6 == (ushort *)0x0) goto LAB_140002548;
    ppuVar14 = &g_asAdmCommands;
    uVar16 = uVar12;
    do {
      uVar17 = (uint)uVar16;
      if ((((dCurrentSKU & *(uint *)((longlong)ppuVar14 + 0x14)) != 0) &&
          (bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar15,puVar5,(ushort *)*ppuVar14), bVar2))
         && (bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar15,puVar6,(ushort *)ppuVar14[1]), bVar2
            )) break;
      uVar17 = uVar17 + 1;
      uVar16 = (ulonglong)uVar17;
      ppuVar14 = ppuVar14 + 0xc;
    } while ((longlong)ppuVar14 < 0x140017ae0);
    if (uVar17 == 0x16) {
      uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_208,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                         (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x20e,7,
                         in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_158,uVar9,0x1002,L"Invalid command");
    }
    *(uint *)(this + 0x58) = uVar17;
    *(uint *)(this + 0x60) = uVar17;
    puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    while (puVar5 != (ushort *)0x0) {
      if ((*puVar5 - 0x2d & 0xfffd) != 0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x26a,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1002,L"Invalid command");
      }
      pCVar15 = (CVssAdminCLI *)(puVar5 + 1);
      if (*(short *)pCVar15 == 0x3f) goto LAB_140002275;
      pCVar11 = pCVar15;
      pwVar7 = wcschr((wchar_t *)pCVar15,L'=');
      if (pwVar7 != (wchar_t *)0x0) {
        *pwVar7 = L'\0';
        pwVar7 = pwVar7 + 1;
      }
      ppuVar14 = &PTR_u_All_140017b48;
      uVar16 = uVar12;
      uVar18 = uVar12;
      do {
        uVar17 = (uint)uVar16;
        bVar2 = _Match_CVssAdminCLI__AEAA_NPEBG0_Z(pCVar11,(ushort *)*ppuVar14,(ushort *)pCVar15);
        if (bVar2) break;
        uVar17 = uVar17 + 1;
        uVar16 = (ulonglong)uVar17;
        uVar18 = uVar18 + 1;
        ppuVar14 = ppuVar14 + 3;
      } while ((longlong)ppuVar14 < 0x140017c98);
      if (uVar17 == 0xe) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x246,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1003,L"Invalid option: %s",pCVar15);
      }
      pCVar11 = this + uVar18 * 8 + 0x68;
      if (*(ushort **)pCVar11 != (ushort *)0x0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x24c,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1005,L"Duplicate option given: %s",pCVar15);
      }
      if (*(int *)(&DAT_1400172c4 + (uVar18 + (longlong)*(int *)(this + 0x60) * 0x18) * 4) == 0) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x252,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1006,L"Option not allowed for this command: %s",pCVar15);
      }
      if ((&DAT_140017b50)[uVar18 * 6] == 0) {
        if (pwVar7 != (wchar_t *)0x0) {
LAB_1400024e7:
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_208,
                             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                             (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x259,7,
                             in_stack_fffffffffffffde8);
          pwVar10 = L"<MISSING>";
          if (pwVar7 != (wchar_t *)0x0) {
            pwVar10 = pwVar7;
          }
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x1004,L"Invalid option value: /%s=%s",pCVar15,pwVar10);
        }
      }
      else if ((pwVar7 == (wchar_t *)0x0) || (*pwVar7 == L'\0')) goto LAB_1400024e7;
      if ((&DAT_140017b50)[uVar18 * 6] == 0) {
        pwVar7 = L"TRUE";
LAB_14000224d:
        VssSafeDuplicateStr(local_158,(ushort **)pCVar11,(ushort *)pwVar7);
      }
      else {
        if (pwVar7 != (wchar_t *)0x0) goto LAB_14000224d;
        *(ushort **)pCVar11 = (ushort *)0x0;
      }
      puVar5 = _GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(this,false);
    }
    pCVar15 = this + 0x68;
    do {
      if ((*(longlong *)pCVar15 == 0) &&
         (*(int *)(&DAT_1400172c4 + (uVar12 + (longlong)*(int *)(this + 0x60) * 0x18) * 4) == 1)) {
        uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_208,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                           (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::ParseCmdLine",0x275,7,
                           in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_158,uVar9,0x1007,L"Required option missing");
      }
      uVar12 = uVar12 + 1;
      pCVar15 = pCVar15 + 8;
    } while ((longlong)uVar12 < 0xe);
    pvVar1 = *(LPVOID *)(this + 0x80);
    if (pvVar1 != (LPVOID)0x0) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
      if (*(short *)((longlong)pvVar1 + lVar8 * 2 + -2) != 0x5c) {
        lVar8 = -1;
        do {
          lVar8 = lVar8 + 1;
        } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
        puVar5 = CoTaskMemRealloc(pvVar1,(longlong)((int)lVar8 + 2) * 2);
        if (puVar5 == (ushort *)0x0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_208,
                             (ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                             (ushort *)L"VssReallocString",0x85,0xb,in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x8007000e,L"Memory allocation error");
        }
        lVar8 = -1;
        do {
          lVar13 = lVar8;
          lVar8 = lVar13 + 1;
        } while (puVar5[lVar8] != 0);
        lVar3 = StringCchCatW(puVar5,lVar13 + 3,(ushort *)L"\\");
        local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
        local_200 = L"CVssAdminCLI::ParseCmdLine";
        local_1f8 = L"ADMVADMC";
        local_1f0 = 0x286;
        local_1ec = 7;
        local_1e8 = 0xff;
        local_168 = 0x1000000;
        local_150 = lVar3;
        memset(local_1e0,0,0x78);
        if (lVar3 < 0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e0,(CVssDebugInfo *)&local_208);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar9,lVar3,L"StringCchCat");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_208);
        *(ushort **)(this + 0x80) = puVar5;
      }
    }
    pvVar1 = *(LPVOID *)(this + 0xa0);
    if (pvVar1 != (LPVOID)0x0) {
      lVar8 = -1;
      do {
        lVar8 = lVar8 + 1;
      } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
      if (*(short *)((longlong)pvVar1 + lVar8 * 2 + -2) != 0x5c) {
        lVar8 = -1;
        do {
          lVar8 = lVar8 + 1;
        } while (*(short *)((longlong)pvVar1 + lVar8 * 2) != 0);
        puVar5 = CoTaskMemRealloc(pvVar1,(longlong)((int)lVar8 + 2) * 2);
        lVar8 = -1;
        if (puVar5 == (ushort *)0x0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            (local_e0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
                             (ushort *)L"INCSTRH",(ushort *)L"VssReallocString",0x85,0xb,
                             in_stack_fffffffffffffde8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_158,uVar9,0x8007000e,L"Memory allocation error");
        }
        do {
          lVar13 = lVar8;
          lVar8 = lVar13 + 1;
        } while (puVar5[lVar8] != 0);
        lVar3 = StringCchCatW(puVar5,lVar13 + 3,(ushort *)L"\\");
        local_208 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
        local_200 = L"CVssAdminCLI::ParseCmdLine";
        local_1f8 = L"ADMVADMC";
        local_1f0 = 0x293;
        local_1ec = 7;
        local_1e8 = 0xff;
        local_168 = 0x1000000;
        local_150 = lVar3;
        memset(local_1e0,0,0x78);
        if (lVar3 < 0) {
          uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e0,(CVssDebugInfo *)&local_208);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar9,lVar3,L"StringCchCat");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_208);
        *(ushort **)(this + 0xa0) = puVar5;
      }
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
    iVar4 = 1;
  }
  return iVar4;
}



/* ==========================================================================
 * ?DoProcessing@CVssAdminCLI@@AEAAXXZ @ 0x140002800  (466 bytes, 122 instructions)
 * void ?DoProcessing@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::DoProcessing(void) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::DoProcessing(void) __ptr64 */

void __thiscall CVssAdminCLI::_DoProcessing_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffeb8;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_128 = L"CVssAdminCLI::DoProcessing";
  local_120 = L"ADMVADMC";
  local_118 = 0x29f;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  iVar1 = *(int *)(this + 0x60);
  if (iVar1 < 0xc) {
    if (iVar1 < 10) {
      if (iVar1 < 8) {
        if (iVar1 < 6) {
          if (iVar1 < 0) {
LAB_140002990:
            uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                              ((CVssDebugInfo *)&local_130,
                               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                               (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::DoProcessing",0x2e1,1
                               ,in_stack_fffffffffffffeb8);
                    /* WARNING: Subroutine does not return */
            CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                      (local_88,uVar2,0x8000ffff,L"Invalid command type: %d",
                       *(undefined4 *)(this + 0x58));
          }
          if (iVar1 < 2) {
            _AddDiffArea_CVssAdminCLI__AEAAXXZ(this);
          }
          else if (iVar1 < 4) {
            _CreateSnapshot_CVssAdminCLI__AEAAXXZ(this);
          }
          else {
            _DeleteSnapshots_CVssAdminCLI__AEAAXXZ(this);
          }
        }
        else {
          _DeleteDiffAreas_CVssAdminCLI__AEAAXXZ(this);
        }
      }
      else if (iVar1 == 8) {
        _ExposeSnapshot_CVssAdminCLI__AEAAXXZ(this);
      }
      else {
        if (iVar1 != 9) goto LAB_140002990;
        _ListProviders_CVssAdminCLI__AEAAXXZ(this);
      }
    }
    else {
      _ListSnapshots_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  else if (iVar1 < 0x13) {
    if (iVar1 < 0x11) {
      if (iVar1 < 0xe) {
        _ListDiffAreas_CVssAdminCLI__AEAAXXZ(this);
      }
      else if (iVar1 < 0x10) {
        _ListVolumes_CVssAdminCLI__AEAAXXZ(this);
      }
      else {
        _ListWriters_CVssAdminCLI__AEAAXXZ(this);
      }
    }
    else {
      _ResizeDiffArea_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  else if (iVar1 < 0x15) {
    _RevertSnapshot_CVssAdminCLI__AEAAXXZ(this);
  }
  else {
    if (iVar1 != 0x15) goto LAB_140002990;
    _QueryReverts_CVssAdminCLI__AEAAXXZ(this);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}



/* ==========================================================================
 * ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z @ 0x1400029dc  (953 bytes, 185 instructions)
 * long ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z(int param_1, ushort * * param_2)
 * public: static long __cdecl CVssAdminCLI::Main(int,unsigned short * __ptr64 * __ptr64 const)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static long __cdecl CVssAdminCLI::Main(int,unsigned short * __ptr64 * __ptr64 const) */

long __cdecl CVssAdminCLI::_Main_CVssAdminCLI__SAJHQEAPEAG_Z(int param_1,ushort **param_2)

{
  int iVar1;
  undefined1 auStack_568 [72];
  long local_520;
  CVssFunctionTracer local_508 [8];
  undefined4 local_500;
  undefined8 local_3e8;
  undefined8 local_1c8;
  undefined8 local_1c0;
  undefined8 local_1b8;
  undefined8 uStack_1b0;
  undefined4 local_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined4 local_190;
  undefined8 local_188;
  long local_180;
  int local_17c;
  ushort **local_178;
  undefined4 local_168;
  undefined1 local_160 [112];
  undefined8 local_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined1 local_d8;
  wchar_t *local_c8;
  wchar_t *local_c0;
  wchar_t *local_b8;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 local_a8;
  undefined1 local_a0 [120];
  undefined4 local_28;
  ulonglong local_18;
  
  local_3e8 = 0xfffffffffffffffe;
  local_18 = __security_cookie ^ (ulonglong)auStack_568;
  local_c8 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_c0 = L"CVssAdminCLI::Main";
  local_b8 = L"ADMVADMC";
  local_b0 = 0x309;
  local_ac = 7;
  local_a8 = 0xff;
  local_28 = 0x1000000;
  memset(local_a0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_508,&local_c8);
  local_520 = 2;
  HeapSetInformation((HANDLE)0x0,HeapEnableTerminationOnCorruption,(PVOID)0x0,0);
  local_1b8 = 0;
  uStack_1b0 = 0;
  local_1a8 = 0;
  local_1a0 = 0;
  local_198 = 0;
  local_190 = 0;
  local_168 = 0x17;
  memset(local_160,0,0x70);
  local_f0 = 0;
  local_e8 = 0;
  uStack_e0 = 0;
  local_180 = 2;
  local_1c0 = 0xffffffffffffffff;
  local_188 = 0;
  local_1c8 = 0;
  local_d8 = 0;
  local_17c = param_1;
  local_178 = param_2;
  _Initialize_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  iVar1 = _ParseCmdLine_CVssAdminCLI__AEAAHXZ((CVssAdminCLI *)&local_1c8);
  if (iVar1 == 0) {
    _PrintUsage_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  }
  else {
    _DoProcessing_CVssAdminCLI__AEAAXXZ((CVssAdminCLI *)&local_1c8);
  }
  local_500 = 0;
  local_520 = local_180;
  __1CVssAdminCLI__QEAA_XZ((CVssAdminCLI *)&local_1c8);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_508);
  return local_520;
}



/* ==========================================================================
 * AssertPrivilege @ 0x1400032b0  (356 bytes, 83 instructions)
 * int AssertPrivilege(ushort * param_1)
 * int __cdecl AssertPrivilege(unsigned short const * __ptr64)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* int __cdecl AssertPrivilege(unsigned short const * __ptr64) */

int __cdecl AssertPrivilege(ushort *param_1)

{
  BOOL BVar1;
  BOOL BVar2;
  HANDLE ProcessHandle;
  void *TokenInformation;
  undefined1 auStackY_68 [32];
  uint local_38 [2];
  HANDLE local_30;
  _LUID local_28;
  _TOKEN_PRIVILEGES local_20;
  ulonglong local_10;
  
  local_10 = __security_cookie ^ (ulonglong)auStackY_68;
  BVar2 = 0;
  ProcessHandle = GetCurrentProcess();
  BVar1 = OpenProcessToken(ProcessHandle,0x28,&local_30);
  if (BVar1 != 0) {
    BVar2 = LookupPrivilegeValueW((LPCWSTR)0x0,L"SeBackupPrivilege",&local_28);
    if (BVar2 != 0) {
      local_20.Privileges[0].Luid.LowPart = local_28.LowPart;
      local_20.Privileges[0].Luid.HighPart = local_28.HighPart;
      local_20.PrivilegeCount = 1;
      local_20.Privileges[0].Attributes = 3;
      SetLastError(0);
      AdjustTokenPrivileges(local_30,0,&local_20,0,(PTOKEN_PRIVILEGES)0x0,(PDWORD)0x0);
      GetLastError();
    }
    GetTokenInformation(local_30,TokenPrivileges,(LPVOID)0x0,0,local_38);
    TokenInformation = operator_new__((ulonglong)local_38[0],&std::nothrow);
    if (TokenInformation == (void *)0x0) {
      SetLastError(0xe);
      BVar2 = 0;
    }
    else {
      BVar2 = GetTokenInformation(local_30,TokenPrivileges,TokenInformation,local_38[0],local_38);
      operator_delete__(TokenInformation);
    }
    CloseHandle(local_30);
  }
  return BVar2;
}



/* ==========================================================================
 * wmain @ 0x14000341c  (64 bytes, 18 instructions)
 * int wmain(int _Argc, wchar_t * * _Argv, wchar_t * * _Env)
 * ========================================================================== */

int __cdecl wmain(int _Argc,wchar_t **_Argv,wchar_t **_Env)

{
  long lVar1;
  
  Ordinal_1();
  lVar1 = CVssAdminCLI::_Main_CVssAdminCLI__SAJHQEAPEAG_Z(_Argc,(ushort **)_Argv);
  Ordinal_2();
  return lVar1;
}



/* ==========================================================================
 * ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ @ 0x140003464  (40 bytes, 11 instructions)
 * void ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ(CComPtr<IVssEnumObject> * this)
 * public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void)
   __ptr64 */

void __thiscall
ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
          (CComPtr<IVssEnumObject> *this)

{
  if (*(longlong **)this != (longlong *)0x0) {
    (**(code **)(**(longlong **)this + 0x10))();
  }
  return;
}



/* ==========================================================================
 * StringCchPrintfW @ 0x140003494  (125 bytes, 44 instructions)
 * long StringCchPrintfW(ushort * param_1, __uint64 param_2, ushort * param_3, ...)
 * long __cdecl StringCchPrintfW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64,...)
 * ========================================================================== */

/* long __cdecl StringCchPrintfW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64,...) */

long __cdecl StringCchPrintfW(ushort *param_1,__uint64 param_2,ushort *param_3,...)

{
  ulonglong _Count;
  int iVar1;
  int iVar2;
  undefined8 in_R9;
  undefined8 local_res20;
  
  iVar2 = 0;
  if (0x7ffffffe < param_2 - 1) {
    iVar2 = -0x7ff8ffa9;
  }
  if (iVar2 < 0) {
    if (param_2 != 0) {
      *param_1 = 0;
    }
  }
  else {
    _Count = param_2 - 1;
    iVar2 = 0;
    local_res20 = in_R9;
    iVar1 = _vsnwprintf((wchar_t *)param_1,_Count,(wchar_t *)param_3,(va_list)&local_res20);
    if ((iVar1 < 0) || (_Count < (ulonglong)(longlong)iVar1)) {
      param_1[_Count] = 0;
      iVar2 = -0x7ff8ff86;
    }
    else if ((longlong)iVar1 == _Count) {
      param_1[_Count] = 0;
    }
  }
  return iVar2;
}



/* ==========================================================================
 * StringCchCatW @ 0x140003518  (207 bytes, 64 instructions)
 * long StringCchCatW(ushort * param_1, __uint64 param_2, ushort * param_3)
 * long __cdecl StringCchCatW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64)
 * ========================================================================== */

/* long __cdecl StringCchCatW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64) */

long __cdecl StringCchCatW(ushort *param_1,__uint64 param_2,ushort *param_3)

{
  ushort uVar1;
  __uint64 _Var2;
  ushort *puVar3;
  longlong lVar4;
  ushort *puVar5;
  longlong lVar6;
  uint uVar7;
  longlong lVar8;
  
  lVar6 = 0;
  uVar7 = 0;
  if (0x7ffffffe < param_2 - 1) {
    uVar7 = 0x80070057;
  }
  puVar5 = param_1;
  _Var2 = param_2;
  if (-1 < (int)uVar7) {
    for (; (_Var2 != 0 && (*puVar5 != 0)); puVar5 = puVar5 + 1) {
      _Var2 = _Var2 - 1;
    }
    uVar7 = ~-(uint)(_Var2 != 0) & 0x80070057;
    if (_Var2 != 0) {
      lVar6 = param_2 - _Var2;
    }
  }
  if (-1 < (int)uVar7) {
    puVar5 = param_1 + lVar6;
    lVar4 = param_2 - lVar6;
    if (lVar4 != 0) {
      lVar6 = lVar6 + 0x7ffffffe + (lVar4 - param_2);
      lVar8 = (longlong)param_3 - (longlong)puVar5;
      do {
        if ((lVar6 == 0) || (uVar1 = *(ushort *)(lVar8 + (longlong)puVar5), uVar1 == 0)) break;
        *puVar5 = uVar1;
        lVar6 = lVar6 + -1;
        puVar5 = puVar5 + 1;
        lVar4 = lVar4 + -1;
      } while (lVar4 != 0);
    }
    puVar3 = puVar5 + -1;
    if (lVar4 != 0) {
      puVar3 = puVar5;
    }
    uVar7 = ~-(uint)(lVar4 != 0) & 0x8007007a;
    *puVar3 = 0;
  }
  return uVar7;
}



/* ==========================================================================
 * ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ @ 0x1400035f0  (5 bytes, 2 instructions)
 * ushort * ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this)
 * public: unsigned short * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 & __ptr64)>::Get(void)const __ptr64
 * ========================================================================== */

/* public: unsigned short * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short *
   __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned
   short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned
   short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short *
   __ptr64 & __ptr64)>::Get(void)const __ptr64 */

ushort * __thiscall
CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
::
_Get___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEBAPEAGXZ
          (CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
           *this)

{
  return *(ushort **)(this + 8);
}



/* ==========================================================================
 * StringCchCopyW @ 0x1400035fc  (130 bytes, 39 instructions)
 * long StringCchCopyW(ushort * param_1, __uint64 param_2, ushort * param_3)
 * long __cdecl StringCchCopyW(unsigned short * __ptr64,unsigned __int64,unsigned short const * __ptr64)
 * ========================================================================== */

/* long __cdecl StringCchCopyW(unsigned short * __ptr64,unsigned __int64,unsigned short const *
   __ptr64) */

long __cdecl StringCchCopyW(ushort *param_1,__uint64 param_2,ushort *param_3)

{
  ushort uVar1;
  ushort *puVar2;
  longlong lVar3;
  uint uVar4;
  longlong lVar5;
  
  uVar4 = 0;
  if (0x7ffffffe < param_2 - 1) {
    uVar4 = 0x80070057;
  }
  if ((int)uVar4 < 0) {
    if (param_2 != 0) {
      *param_1 = 0;
    }
  }
  else {
    if (param_2 != 0) {
      lVar5 = 0x7ffffffe - param_2;
      lVar3 = (longlong)param_3 - (longlong)param_1;
      do {
        if ((lVar5 + param_2 == 0) || (uVar1 = *(ushort *)(lVar3 + (longlong)param_1), uVar1 == 0))
        break;
        *param_1 = uVar1;
        param_1 = param_1 + 1;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    puVar2 = param_1 + -1;
    if (param_2 != 0) {
      puVar2 = param_1;
    }
    uVar4 = ~-(uint)(param_2 != 0) & 0x8007007a;
    *puVar2 = 0;
  }
  return uVar4;
}



/* ==========================================================================
 * VssSafeDuplicateStr @ 0x140003688  (318 bytes, 75 instructions)
 * void VssSafeDuplicateStr(CVssFunctionTracer * param_1, ushort * * param_2, ushort * param_3)
 * void __cdecl VssSafeDuplicateStr(class CVssFunctionTracer & __ptr64,unsigned short * __ptr64 & __ptr64,unsigned short const * __ptr64)
 * ========================================================================== */

/* void __cdecl VssSafeDuplicateStr(class CVssFunctionTracer & __ptr64,unsigned short * __ptr64 &
   __ptr64,unsigned short const * __ptr64) */

void __cdecl VssSafeDuplicateStr(CVssFunctionTracer *param_1,ushort **param_2,ushort *param_3)

{
  long lVar1;
  ushort *puVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff28;
  CVssDebugInfo local_c8 [176];
  
  lVar4 = -1;
  do {
    lVar4 = lVar4 + 1;
  } while (param_3[lVar4] != 0);
  puVar2 = CoTaskMemAlloc(lVar4 * 2 + 2);
  *param_2 = puVar2;
  if (puVar2 == (ushort *)0x0) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_c8,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                       (ushort *)L"VssSafeDuplicateStr",0x54,0xb,in_stack_ffffffffffffff28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_1,uVar3,0x8007000e,L"Memory allocation error");
  }
  lVar4 = -1;
  do {
    lVar5 = lVar4;
    lVar4 = lVar5 + 1;
  } while (param_3[lVar4] != 0);
  lVar1 = StringCchCopyW(puVar2,lVar5 + 2,param_3);
  if (-1 < lVar1) {
    return;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_c8,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",(ushort *)L"INCSTRH",
                     (ushort *)L"VssSafeDuplicateStr",0x58,0xb,in_stack_ffffffffffffff28);
  lVar4 = -1;
  do {
    lVar5 = lVar4;
    lVar4 = lVar5 + 1;
  } while (param_3[lVar4] != 0);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (param_1,uVar3,lVar1,L"StringCchCopy(%s, %d, %s) failed",*param_2,lVar5 + 2,param_3);
}



/* ==========================================================================
 * ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ @ 0x1400037d0  (61 bytes, 16 instructions)
 * void ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this)
 * public: virtual __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >::~CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64>
   >::~CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >(void) __ptr64 */

void __thiscall
CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
__1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
          (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}



/* ==========================================================================
 * ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z @ 0x140003820  (89 bytes, 24 instructions)
 * void * ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_> * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl CVssAuto<unsigned short * __ptr64,class CVssAllocatingPtr_Storage<unsigned short * __ptr64,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),void * __ptr64 (__cdecl*)(unsigned __int64),&void * __ptr64 __cdecl CoTaskMemAlloc(unsigned __int64)> >::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl CVssAuto<unsigned short * __ptr64,class
   CVssAllocatingPtr_Storage<unsigned short * __ptr64,void (__cdecl*)(void * __ptr64),&void __cdecl
   CoTaskMemFree(void * __ptr64),void * __ptr64 (__cdecl*)(unsigned __int64),&void * __ptr64 __cdecl
   CoTaskMemAlloc(unsigned __int64)> >::`vector deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_>
::
___E__CVssAuto_PEAGV__CVssAllocatingPtr_Storage_PEAGP6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6APEAX_K_Z_1_CoTaskMemAlloc__YAPEAX1_Z____UEAAPEAXI_Z
          (CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_>
           *this,uint param_1)

{
  *(undefined ***)this = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z @ 0x140003880  (38 bytes, 12 instructions)
 * void * ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this, uint param_1)
 * protected: virtual void * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 & __ptr64)>::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* protected: virtual void * __ptr64 __cdecl CVssAutoGenericValue_Storage<unsigned short *
   __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned
   short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned
   short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short *
   __ptr64 & __ptr64)>::`vector deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
::
___E__CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__MEAAPEAXI_Z
          (CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
           *this,uint param_1)

{
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ?Close@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEAAXXZ @ 0x1400038b0  (41 bytes, 12 instructions)
 * void ?Close@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEAAXXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this)
 * public: void __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64 (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64 __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 & __ptr64)>::Close(void) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssAutoGenericValue_Storage<unsigned short * __ptr64,0,void (__cdecl*)(void
   * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),unsigned short * __ptr64 & __ptr64
   (__cdecl*)(unsigned short * __ptr64 & __ptr64),&public: static unsigned short * __ptr64 & __ptr64
   __cdecl DTyper<unsigned short * __ptr64>::Identity(unsigned short * __ptr64 &
   __ptr64)>::Close(void) __ptr64 */

void __thiscall
CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
::
_Close___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEAAXXZ
          (CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
           *this)

{
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  return;
}



/* ==========================================================================
 * ?SetHr@CVssFunctionTracer@@QEAAXJ@Z @ 0x1400038e0  (4 bytes, 2 instructions)
 * void ?SetHr@CVssFunctionTracer@@QEAAXJ@Z(CVssFunctionTracer * this, long param_1)
 * public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64 */

void __thiscall
CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(CVssFunctionTracer *this,long param_1)

{
  *(long *)(this + 8) = param_1;
  return;
}



/* ==========================================================================
 * ?GetHr@CVssFunctionTracer@@QEAAJXZ @ 0x1400038ec  (4 bytes, 2 instructions)
 * long ?GetHr@CVssFunctionTracer@@QEAAJXZ(CVssFunctionTracer * this)
 * public: long __cdecl CVssFunctionTracer::GetHr(void) __ptr64
 * ========================================================================== */

/* public: long __cdecl CVssFunctionTracer::GetHr(void) __ptr64 */

long __thiscall CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(CVssFunctionTracer *this)

{
  return *(long *)(this + 8);
}



/* ==========================================================================
 * ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z @ 0x1400038f8  (164 bytes, 34 instructions)
 * ushort * ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1)
 * private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetOptionValueStr(enum EVssAdmOption) __ptr64
 * ========================================================================== */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetOptionValueStr(enum EVssAdmOption)
   __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z
          (CVssAdminCLI *this,EVssAdmOption param_1)

{
  ushort *puVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_110 = 0x150;
  local_120 = L"CVssAdminCLI::GetOptionValueStr";
  local_10c = 7;
  local_118 = L"INCPNTRH";
  local_108 = 0xff;
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  puVar1 = *(ushort **)(this + (longlong)(int)param_1 * 8 + 0x68);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return puVar1;
}



/* ==========================================================================
 * ??1CVssAutoCoString@@QEAA@XZ @ 0x1400039a4  (34 bytes, 10 instructions)
 * void ??1CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this)
 * public: __cdecl CVssAutoCoString::~CVssAutoCoString(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssAutoCoString::~CVssAutoCoString(void) __ptr64 */

void __thiscall CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ(CVssAutoCoString *this)

{
  CoTaskMemFree(*(LPVOID *)this);
  *(undefined8 *)this = 0;
  return;
}



/* ==========================================================================
 * ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z @ 0x1400039d0  (3 bytes, 1 instructions)
 * void ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, CVssFunctionTracer * param_1)
 * public: virtual void __cdecl CInternalVerifier::ListWriters(class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::ListWriters(class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CInternalVerifier::_ListWriters_CInternalVerifier__UEAAXAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,CVssFunctionTracer *param_1)

{
  return;
}



/* ==========================================================================
 * ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z @ 0x1400039e0  (247 bytes, 51 instructions)
 * void ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6)
 * public: virtual void __cdecl CInternalVerifier::ListSnapshots(long,struct _GUID,unsigned short const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::ListSnapshots(long,struct _GUID,unsigned short
   const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_ListSnapshots_CInternalVerifier__UEAAXJU_GUID__PEBG00AEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,long param_1,_GUID *param_2,ushort *param_3,_GUID *param_4,
          _GUID *param_5,CVssFunctionTracer *param_6)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_4->Data1;
  lVar1._4_2_ = param_4->Data2;
  lVar1._6_2_ = param_4->Data3;
  if (((lVar1 != 0) || (*(longlong *)param_4->Data4 != 0)) &&
     ((lVar2._0_4_ = param_5->Data1, lVar2._4_2_ = param_5->Data2, lVar2._6_2_ = param_5->Data3,
      lVar2 != 0 || (*(longlong *)param_5->Data4 != 0)))) {
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ListSnapshots",0x43,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_6,uVar4,0x1008,
               L"CVssAdminCLI::ListSnapshots: Cannot specify both /Set and /Shadow options at the same time"
              );
  }
  if (param_3 != (ushort *)0x0) {
    uVar3 = 0xffffffffffffffff;
    do {
      uVar3 = uVar3 + 1;
    } while (param_3[uVar3] != 0);
    if (0x31 < uVar3) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ListSnapshots",0x48,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_6,uVar4,0x1004,
                 L"CVssAdminCLI::ListSnapshots:  Must specify a valid volume name for list snapshots"
                );
    }
  }
  return;
}



/* ==========================================================================
 * ?AddDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z @ 0x140003ae0  (105 bytes, 17 instructions)
 * void ?AddDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * public: virtual void __cdecl CInternalVerifier::AddDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::AddDiffArea(struct _GUID,unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CInternalVerifier::_AddDiffArea_CInternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if (0xfffff < param_4) {
    return;
  }
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::AddDiffArea",0x5d,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar1,0x1001,
             L"CVssAdminCLI::AddDiffarea: A maxsize of less than 1 MB specified, invalid");
}



/* ==========================================================================
 * ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z @ 0x140003b60  (105 bytes, 17 instructions)
 * void ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * public: virtual void __cdecl CInternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CInternalVerifier::_ResizeDiffArea_CInternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if (0xfffff < param_4) {
    return;
  }
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ResizeDiffArea",0x6d,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar1,0x1001,
             L"CVssAdminCLI::ResizeDiffarea: maxsize of less than 1 MB specified, invalid");
}



/* ==========================================================================
 * ?QueryReverts@CInternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z @ 0x140003be0  (180 bytes, 37 instructions)
 * void ?QueryReverts@CInternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3)
 * public: virtual void __cdecl CInternalVerifier::QueryReverts(unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::QueryReverts(unsigned short const *
   __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_QueryReverts_CInternalVerifier__UEAAXPEBG_NAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,ushort *param_1,bool param_2,CVssFunctionTracer *param_3)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  if (param_1 == (ushort *)0x0) {
    if (!param_2) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::QueryReverts",0x80,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_3,uVar1,0x1008,
                 L"CVssAdminCLI::QueryReverts: must specify either For or All parameter");
    }
  }
  else if (param_2) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::QueryReverts",0x7d,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_3,uVar1,0x1008,
               L"CVssAdminCLI::QueryReverts: Can\'t specify both For and All options");
  }
  return;
}



/* ==========================================================================
 * ?ListDiffAreas@CInternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z @ 0x140003ca0  (101 bytes, 19 instructions)
 * void ?ListDiffAreas@CInternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4)
 * public: virtual void __cdecl CInternalVerifier::ListDiffAreas(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::ListDiffAreas(struct _GUID,unsigned short const *
   __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_ListDiffAreas_CInternalVerifier__UEAAXU_GUID__PEBG1AEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,
          CVssFunctionTracer *param_4)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if ((param_2 != (ushort *)0x0) && (param_3 != (ushort *)0x0)) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ListDiffAreas",0x96,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_4,uVar1,0x1008,
               L"CVssAdminCLI::ListDiffAreas: Can\'t specify both ON and FOR volume options");
  }
  return;
}



/* ==========================================================================
 * ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z @ 0x140003d10  (494 bytes, 106 instructions)
 * void ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7)
 * public: virtual void __cdecl CInternalVerifier::DeleteSnapshots(long,unsigned short const * __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::DeleteSnapshots(long,unsigned short const *
   __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::
_DeleteSnapshots_CInternalVerifier__UEAAXJPEBG_N1U_GUID__1AEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,long param_1,ushort *param_2,bool param_3,bool param_4,
          _GUID *param_5,bool param_6,CVssFunctionTracer *param_7)

{
  longlong lVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_5->Data1;
  lVar1._4_2_ = param_5->Data2;
  lVar1._6_2_ = param_5->Data3;
  if ((lVar1 != 0) || (*(longlong *)param_5->Data4 != 0)) {
    if ((param_2 == (ushort *)0x0) && (((param_1 == -1 && (!param_4)) && (!param_3)))) {
      return;
    }
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xa2,7
                       ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options");
  }
  uVar3 = 0xffffffffffffffff;
  if (param_2 == (ushort *)0x0) {
    if (param_1 != -1) goto LAB_140003e73;
    if (!param_3) {
      if (!param_4) goto LAB_140003e73;
      goto LAB_140003d6f;
    }
  }
  else {
LAB_140003d6f:
    if ((param_1 != -1) && (param_2 == (ushort *)0x0)) goto LAB_140003e73;
  }
  if ((!param_4) || (param_2 != (ushort *)0x0)) {
    if (((param_1 != -1) && (param_3)) || ((param_3 && (param_4)))) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xaf,
                         7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options:");
    }
    if (param_2 != (ushort *)0x0) {
      do {
        uVar3 = uVar3 + 1;
      } while (param_2[uVar3] != 0);
      if (0x31 < uVar3) {
        uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          (local_b0,(ushort *)
                                    L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                           (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",
                           0xb5,7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (param_7,uVar2,0x1004,L"CVssAdminCLI::DeleteSnapshots: invalid volume name");
      }
    }
    return;
  }
LAB_140003e73:
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::DeleteSnapshots",0xa9,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_7,uVar2,0x1007,L"CVssAdminCLI::DeleteSnapshots: Required option missing");
}



/* ==========================================================================
 * ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z @ 0x140003f10  (189 bytes, 33 instructions)
 * void ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5)
 * public: virtual void __cdecl CInternalVerifier::ExposeSnapshot(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CInternalVerifier::ExposeSnapshot(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CInternalVerifier::_ExposeSnapshot_CInternalVerifier__UEAAXU_GUID__PEBG1_NAEAVCVssFunctionTracer___Z
          (CInternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,bool param_4,
          CVssFunctionTracer *param_5)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [176];
  
  if (param_3 != (ushort *)0x0) {
    if (param_4) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ExposeSnapshot",0xc3,7
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_5,uVar1,0x1008,
                 L"CVssAdminCLI::ExposeSnapshot: Specified a ShareUsing option with an expose locally command"
                );
    }
    if (*param_3 != 0x5c) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CInternalVerifier::ExposeSnapshot",200,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_5,uVar1,0x1004,
                 L"CVssAdminCLI::ExposeSnapshot: Specified SharePath doesn\'t start with \'\\\'");
    }
  }
  return;
}



/* ==========================================================================
 * ?ListSnapshots@CExternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z @ 0x140003fe0  (247 bytes, 51 instructions)
 * void ?ListSnapshots@CExternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6)
 * public: virtual void __cdecl CExternalVerifier::ListSnapshots(long,struct _GUID,unsigned short const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::ListSnapshots(long,struct _GUID,unsigned short
   const * __ptr64,struct _GUID,struct _GUID,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::_ListSnapshots_CExternalVerifier__UEAAXJU_GUID__PEBG00AEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,long param_1,_GUID *param_2,ushort *param_3,_GUID *param_4,
          _GUID *param_5,CVssFunctionTracer *param_6)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_4->Data1;
  lVar1._4_2_ = param_4->Data2;
  lVar1._6_2_ = param_4->Data3;
  if (((lVar1 != 0) || (*(longlong *)param_4->Data4 != 0)) &&
     ((lVar2._0_4_ = param_5->Data1, lVar2._4_2_ = param_5->Data2, lVar2._6_2_ = param_5->Data3,
      lVar2 != 0 || (*(longlong *)param_5->Data4 != 0)))) {
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ListSnapshots",0xf5,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_6,uVar4,0x1008,
               L"CVssAdminCLI::ListSnapshots: Cannot specify both /Set and /Shadow options at the same time"
              );
  }
  if (param_3 != (ushort *)0x0) {
    uVar3 = 0xffffffffffffffff;
    do {
      uVar3 = uVar3 + 1;
    } while (param_3[uVar3] != 0);
    if (0x31 < uVar3) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ListSnapshots",0xfa,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_6,uVar4,0x1004,
                 L"CVssAdminCLI::ListSnapshots:  Must specify a valid volume name for list snapshots"
                );
    }
  }
  return;
}



/* ==========================================================================
 * ?AddDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z @ 0x1400040e0  (120 bytes, 23 instructions)
 * void ?AddDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * public: virtual void __cdecl CExternalVerifier::AddDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::AddDiffArea(struct _GUID,unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CExternalVerifier::_AddDiffArea_CExternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  ulonglong uVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  uVar1 = CVssMachineInformation::_GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z
                    (param_3);
  if (uVar1 <= param_4) {
    return;
  }
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::AddDiffArea",0x113,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar2,0x1001,
             L"CVssAdminCLI::AddDiffarea: A maxsize of less than (%I64u) MB specified, invalid",
             uVar1);
}



/* ==========================================================================
 * ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z @ 0x140004160  (120 bytes, 23 instructions)
 * void ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5)
 * public: virtual void __cdecl CExternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::ResizeDiffArea(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned __int64,class CVssFunctionTracer & __ptr64)
   __ptr64 */

void __thiscall
CExternalVerifier::_ResizeDiffArea_CExternalVerifier__UEAAXU_GUID__PEBG1_KAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,__uint64 param_4,
          CVssFunctionTracer *param_5)

{
  ulonglong uVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  uVar1 = CVssMachineInformation::_GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z
                    (param_3);
  if (uVar1 <= param_4) {
    return;
  }
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                     (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ResizeDiffArea",0x127,7,
                     in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (param_5,uVar2,0x1001,
             L"CVssAdminCLI::ResizeDiffarea: maxsize of less than (%I64u) MB specified, invalid",
             uVar1);
}



/* ==========================================================================
 * ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z @ 0x1400041e0  (180 bytes, 37 instructions)
 * void ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3)
 * public: virtual void __cdecl CExternalVerifier::QueryReverts(unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::QueryReverts(unsigned short const *
   __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::_QueryReverts_CExternalVerifier__UEAAXPEBG_NAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,ushort *param_1,bool param_2,CVssFunctionTracer *param_3)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  if (param_1 == (ushort *)0x0) {
    if (!param_2) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::QueryReverts",0x13b,7,
                         in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_3,uVar1,0x1008,
                 L"CVssAdminCLI::QueryReverts: must specify either For or All parameter");
    }
  }
  else if (param_2) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::QueryReverts",0x138,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_3,uVar1,0x1008,
               L"CVssAdminCLI::QueryReverts: Can\'t specify both For and All options");
  }
  return;
}



/* ==========================================================================
 * ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z @ 0x1400042a0  (101 bytes, 19 instructions)
 * void ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4)
 * public: virtual void __cdecl CExternalVerifier::ListDiffAreas(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::ListDiffAreas(struct _GUID,unsigned short const *
   __ptr64,unsigned short const * __ptr64,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::_ListDiffAreas_CExternalVerifier__UEAAXU_GUID__PEBG1AEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,
          CVssFunctionTracer *param_4)

{
  undefined8 uVar1;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [184];
  
  if ((param_2 != (ushort *)0x0) && (param_3 != (ushort *)0x0)) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b8,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::ListDiffAreas",0x154,7,
                       in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_4,uVar1,0x1008,
               L"CVssAdminCLI::ListDiffAreas: Can\'t specify both ON and FOR volume options");
  }
  return;
}



/* ==========================================================================
 * ?DeleteSnapshots@CExternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z @ 0x140004310  (444 bytes, 93 instructions)
 * void ?DeleteSnapshots@CExternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7)
 * public: virtual void __cdecl CExternalVerifier::DeleteSnapshots(long,unsigned short const * __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * ========================================================================== */

/* public: virtual void __cdecl CExternalVerifier::DeleteSnapshots(long,unsigned short const *
   __ptr64,bool,bool,struct _GUID,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::
_DeleteSnapshots_CExternalVerifier__UEAAXJPEBG_N1U_GUID__1AEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,long param_1,ushort *param_2,bool param_3,bool param_4,
          _GUID *param_5,bool param_6,CVssFunctionTracer *param_7)

{
  longlong lVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b0 [168];
  
  lVar1._0_4_ = param_5->Data1;
  lVar1._4_2_ = param_5->Data2;
  lVar1._6_2_ = param_5->Data3;
  if ((lVar1 == 0) && (*(longlong *)param_5->Data4 == 0)) {
    if ((((param_2 == (ushort *)0x0) && (!param_3)) && (!param_4)) ||
       ((param_4 && (param_2 == (ushort *)0x0)))) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::DeleteSnapshots",0x167
                         ,7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_7,uVar2,0x1007,L"CVssAdminCLI::DeleteSnapshots: Required option missing");
    }
    if ((param_3) && (param_4)) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b0,(ushort *)
                                  L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                         (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::DeleteSnapshots",0x16c
                         ,7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options");
    }
    if (param_2 != (ushort *)0x0) {
      uVar3 = 0xffffffffffffffff;
      do {
        uVar3 = uVar3 + 1;
      } while (param_2[uVar3] != 0);
      if (0x31 < uVar3) {
        uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          (local_b0,(ushort *)
                                    L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp",
                           (ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::DeleteSnapshots",
                           0x172,7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (param_7,uVar2,0x1004,L"CVssAdminCLI::DeleteSnapshots: invalid volume name");
      }
    }
  }
  else if ((param_2 != (ushort *)0x0) || ((param_3 || (param_4)))) {
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_b0,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\commandverifier.cpp"
                       ,(ushort *)L"ADMVERFR",(ushort *)L"CExternalVerifier::DeleteSnapshots",0x161,
                       7,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_7,uVar2,0x1008,L"CVssAdminCLI::DeleteSnapshots: Invalid set of options");
  }
  return;
}



/* ==========================================================================
 * ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z @ 0x1400044d8  (582 bytes, 131 instructions)
 * long ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z(CVssAdmSnapshotSetEntry * this, _VSS_SNAPSHOT_PROP * param_1)
 * public: long __cdecl CVssAdmSnapshotSetEntry::AddSnapshot(struct _VSS_SNAPSHOT_PROP * __ptr64) __ptr64
 * ========================================================================== */

/* public: long __cdecl CVssAdmSnapshotSetEntry::AddSnapshot(struct _VSS_SNAPSHOT_PROP * __ptr64)
   __ptr64 */

long __thiscall
CVssAdmSnapshotSetEntry::_AddSnapshot_CVssAdmSnapshotSetEntry__QEAAJPEAU_VSS_SNAPSHOT_PROP___Z
          (CVssAdmSnapshotSetEntry *this,_VSS_SNAPSHOT_PROP *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  _VSS_SNAPSHOT_PROP *p_Var6;
  void *pvVar7;
  undefined8 uVar8;
  undefined8 *puVar9;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe78;
  CVssFunctionTracer local_158 [8];
  long local_150;
  wchar_t *local_e8;
  wchar_t *local_e0;
  wchar_t *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined4 local_c8;
  undefined1 local_c0 [120];
  undefined4 local_48;
  
  local_e8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_e0 = L"CVssAdmSnapshotSetEntry::AddSnapshot";
  local_d8 = L"ADMPROCC";
  local_d0 = 0x52;
  local_cc = 7;
  local_c8 = 0xff;
  local_48 = 0x1000000;
  memset(local_c0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_e8);
  p_Var6 = operator_new(0x80,&std::nothrow);
  if (p_Var6 == (_VSS_SNAPSHOT_PROP *)0x0) {
    uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x58,
                       7,in_stack_fffffffffffffe78);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_158,uVar8,0x8007000e,L"Out of memory");
  }
  uVar8 = *(undefined8 *)(param_1 + 8);
  *(undefined8 *)p_Var6 = *(undefined8 *)param_1;
  *(undefined8 *)(p_Var6 + 8) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x18);
  *(undefined8 *)(p_Var6 + 0x10) = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(p_Var6 + 0x18) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x28);
  *(undefined8 *)(p_Var6 + 0x20) = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)(p_Var6 + 0x28) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x38);
  *(undefined8 *)(p_Var6 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(undefined8 *)(p_Var6 + 0x38) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x48);
  *(undefined8 *)(p_Var6 + 0x40) = *(undefined8 *)(param_1 + 0x40);
  *(undefined8 *)(p_Var6 + 0x48) = uVar8;
  uVar8 = *(undefined8 *)(param_1 + 0x58);
  *(undefined8 *)(p_Var6 + 0x50) = *(undefined8 *)(param_1 + 0x50);
  *(undefined8 *)(p_Var6 + 0x58) = uVar8;
  uVar2 = *(undefined4 *)(param_1 + 100);
  uVar3 = *(undefined4 *)(param_1 + 0x68);
  uVar4 = *(undefined4 *)(param_1 + 0x6c);
  *(undefined4 *)(p_Var6 + 0x60) = *(undefined4 *)(param_1 + 0x60);
  *(undefined4 *)(p_Var6 + 100) = uVar2;
  *(undefined4 *)(p_Var6 + 0x68) = uVar3;
  *(undefined4 *)(p_Var6 + 0x6c) = uVar4;
  uVar2 = *(undefined4 *)(param_1 + 0x74);
  uVar3 = *(undefined4 *)(param_1 + 0x78);
  uVar4 = *(undefined4 *)(param_1 + 0x7c);
  *(undefined4 *)(p_Var6 + 0x70) = *(undefined4 *)(param_1 + 0x70);
  *(undefined4 *)(p_Var6 + 0x74) = uVar2;
  *(undefined4 *)(p_Var6 + 0x78) = uVar3;
  *(undefined4 *)(p_Var6 + 0x7c) = uVar4;
  uVar8 = *(undefined8 *)p_Var6;
  uVar5 = *(undefined8 *)(p_Var6 + 8);
  pvVar7 = realloc(*(void **)(this + 0x18),(longlong)(*(int *)(this + 0x28) + 1) << 4);
  if (pvVar7 != (void *)0x0) {
    *(void **)(this + 0x18) = pvVar7;
    pvVar7 = realloc(*(void **)(this + 0x20),(longlong)(*(int *)(this + 0x28) + 1) << 3);
    if (pvVar7 != (void *)0x0) {
      *(void **)(this + 0x20) = pvVar7;
      iVar1 = *(int *)(this + 0x28);
      *(int *)(this + 0x28) = iVar1 + 1;
      puVar9 = (undefined8 *)((longlong)iVar1 * 0x10 + *(longlong *)(this + 0x18));
      if (puVar9 != (undefined8 *)0x0) {
        *puVar9 = uVar8;
        puVar9[1] = uVar5;
        pvVar7 = *(void **)(this + 0x20);
      }
      puVar9 = (undefined8 *)((longlong)pvVar7 + (longlong)iVar1 * 8);
      if (puVar9 != (undefined8 *)0x0) {
        *puVar9 = p_Var6;
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
      return local_150;
    }
  }
  VssFreeSnapshotProperties(p_Var6);
  operator_delete__(p_Var6);
  uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_e8,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",99,7,
                     in_stack_fffffffffffffe78);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_158,uVar8,0x8007000e,L"Out of memory");
}



/* ==========================================================================
 * ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z @ 0x140004728  (1890 bytes, 409 instructions)
 * void ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z(CVssAdmSnapshotSets * this, long param_1, _GUID * param_2, _GUID * param_3, _GUID * param_4, ushort * param_5)
 * public: void __cdecl CVssAdmSnapshotSets::Initialize(long,struct _GUID,struct _GUID,struct _GUID,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssAdmSnapshotSets::Initialize(long,struct _GUID,struct _GUID,struct
   _GUID,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdmSnapshotSets::_Initialize_CVssAdmSnapshotSets__QEAAXJU_GUID__00PEBG_Z
          (CVssAdmSnapshotSets *this,long param_1,_GUID *param_2,_GUID *param_3,_GUID *param_4,
          ushort *param_5)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  longlong *plVar9;
  void *pvVar10;
  undefined8 uVar11;
  uint uVar12;
  CVssAdmSnapshotSetEntry *pCVar13;
  size_t sVar14;
  CVssAdmSnapshotSetEntry *pCVar15;
  CVssAdmSnapshotSetEntry *pCVar16;
  undefined1 auStackY_298 [32];
  _VSSDBG_SEV_ENUM _Var17;
  longlong **pplVar18;
  undefined1 local_258 [8];
  longlong *local_250;
  GUID local_248;
  longlong *local_238;
  undefined1 local_228 [16];
  wchar_t *local_218;
  wchar_t *local_210;
  wchar_t *local_208;
  undefined4 local_200;
  undefined4 local_1fc;
  undefined4 local_1f8;
  undefined1 local_1f0 [120];
  undefined4 local_178;
  CVssFunctionTracer local_168 [8];
  int local_160;
  undefined8 local_f8;
  undefined1 local_e8 [8];
  longlong local_e0;
  longlong local_d8;
  longlong local_d0;
  longlong lStack_c8;
  undefined4 local_c0;
  wchar_t *local_b0;
  longlong local_88;
  longlong local_80;
  ulonglong local_58;
  
  local_f8 = 0xfffffffffffffffe;
  local_58 = __security_cookie ^ (ulonglong)auStackY_298;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdmSnapshotSets::Initialize";
  local_208 = L"ADMPROCC";
  local_200 = 0x8f;
  local_1fc = 7;
  local_1f8 = 0xff;
  pCVar16 = (CVssAdmSnapshotSetEntry *)0x0;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_168);
  local_250 = (longlong *)0x0;
  local_228 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_248 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdmSnapshotSets::Initialize";
  local_208 = L"ADMPROCC";
  local_200 = 0x95;
  local_1fc = 7;
  local_1f8 = 0xff;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  pplVar18 = &local_250;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_168,&local_218,&local_248,L"Coordinator");
  if (local_160 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0x9c,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_160 = (**(code **)(*local_250 + 0x18))(local_250,param_1);
  if (((local_160 < 0) && (local_160 != -0x7ff8fffb)) && (local_160 != -0x7fffbfff)) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0xa6,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_238 = (longlong *)0x0;
  local_228 = ZEXT816(0);
  local_160 = (**(code **)(*local_250 + 0x50))(local_250,local_228,1);
  if (local_160 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_218,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdmSnapshotSets::Initialize",0xaf,7,(_VSSDBG_SEV_ENUM)pplVar18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
  }
  local_160 = (**(code **)(*local_238 + 0x18))(local_238,1,local_e8,local_258);
  _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
  do {
    if (local_160 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_218,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdmSnapshotSets::Initialize",0xb8,7,_Var17);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
    }
    if (local_160 == 1) {
      if (local_238 != (longlong *)0x0) {
        (**(code **)(*local_238 + 0x10))();
      }
      if (local_250 != (longlong *)0x0) {
        (**(code **)(*local_250 + 0x10))();
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_168);
      return;
    }
    local_228._8_8_ = &local_e0;
    local_228._0_8_ =
         &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
          ::_vftable_;
    lVar2._0_4_ = param_2->Data1;
    lVar2._4_2_ = param_2->Data2;
    lVar2._6_2_ = param_2->Data3;
    if (((((lVar2 == 0) && (*(longlong *)param_2->Data4 == 0)) ||
         ((lVar3._0_4_ = param_2->Data1, lVar3._4_2_ = param_2->Data2, lVar3._6_2_ = param_2->Data3,
          local_d0 == lVar3 && (lStack_c8 == *(longlong *)param_2->Data4)))) &&
        (((lVar4._0_4_ = param_3->Data1, lVar4._4_2_ = param_3->Data2, lVar4._6_2_ = param_3->Data3,
          lVar4 == 0 && (*(longlong *)param_3->Data4 == 0)) ||
         ((lVar5._0_4_ = param_3->Data1, lVar5._4_2_ = param_3->Data2, lVar5._6_2_ = param_3->Data3,
          local_e0 == lVar5 && (local_d8 == *(longlong *)param_3->Data4)))))) &&
       ((((lVar6._0_4_ = param_4->Data1, lVar6._4_2_ = param_4->Data2, lVar6._6_2_ = param_4->Data3,
          lVar6 == 0 && (*(longlong *)param_4->Data4 == 0)) ||
         ((lVar7._0_4_ = param_4->Data1, lVar7._4_2_ = param_4->Data2, lVar7._6_2_ = param_4->Data3,
          local_88 == lVar7 && (local_80 == *(longlong *)param_4->Data4)))) &&
        (((param_5 == (ushort *)0x0 || (*param_5 == 0)) ||
         (iVar8 = _wcsicmp((wchar_t *)param_5,local_b0), iVar8 == 0)))))) {
      local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_210 = L"CVssAdmSnapshotSets::Initialize";
      local_208 = L"ADMPROCC";
      local_200 = 0xdf;
      local_1fc = 7;
      local_1f8 = 0xff;
      local_178 = 0x1000000;
      memset(local_1f0,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_168,&local_218,L"Snapshot: %s",local_b0);
      local_248._8_8_ = lStack_c8;
      local_248._0_8_ = local_d0;
      pCVar13 = pCVar16;
      pCVar15 = pCVar16;
      if (0 < *(int *)(this + 0x10)) {
        do {
          plVar9 = (longlong *)((longlong)(int)pCVar13 * 0x10 + *(longlong *)this);
          if ((*plVar9 == local_d0) && (plVar9[1] == lStack_c8)) goto LAB_140004aad;
          uVar12 = (int)pCVar13 + 1;
          pCVar13 = (CVssAdmSnapshotSetEntry *)(ulonglong)uVar12;
          pCVar15 = pCVar15 + 1;
        } while ((int)uVar12 < *(int *)(this + 0x10));
      }
      pCVar15 = (CVssAdmSnapshotSetEntry *)0xffffffffffffffff;
LAB_140004aad:
      if ((pCVar15 == (CVssAdmSnapshotSetEntry *)0xffffffffffffffff) ||
         (pCVar13 = *(CVssAdmSnapshotSetEntry **)(*(longlong *)(this + 8) + (longlong)pCVar15 * 8),
         pCVar13 == (CVssAdmSnapshotSetEntry *)0x0)) {
        pCVar15 = operator_new(0x30,&std::nothrow);
        lVar3 = lStack_c8;
        lVar2 = local_d0;
        local_248._0_8_ = pCVar15;
        pCVar13 = pCVar16;
        if (pCVar15 != (CVssAdmSnapshotSetEntry *)0x0) {
          *(longlong *)pCVar15 = local_d0;
          *(longlong *)(pCVar15 + 8) = lStack_c8;
          *(undefined4 *)(pCVar15 + 0x10) = local_c0;
          *(longlong *)(pCVar15 + 0x18) = 0;
          *(longlong *)(pCVar15 + 0x20) = 0;
          *(undefined4 *)(pCVar15 + 0x28) = 0;
          pCVar13 = pCVar15;
        }
        if (pCVar13 == (CVssAdmSnapshotSetEntry *)0x0) {
          uVar11 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_218,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",
                              0xea,7,(_VSSDBG_SEV_ENUM)pplVar18);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_168,uVar11,0x8007000e,L"Out of memory");
        }
        sVar14 = (longlong)(*(int *)(this + 0x10) + 1) << 4;
        pvVar10 = realloc(*(void **)this,sVar14);
        _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
        uVar12 = (uint)sVar14;
        if (pvVar10 == (void *)0x0) {
LAB_140004e42:
          CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z(pCVar13,uVar12);
          uVar11 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_218,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",
                              0xee,7,_Var17);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_168,uVar11,0x8007000e,L"Out of memory");
        }
        *(void **)this = pvVar10;
        sVar14 = (longlong)(*(int *)(this + 0x10) + 1) << 3;
        pvVar10 = realloc(*(void **)(this + 8),sVar14);
        _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
        uVar12 = (uint)sVar14;
        if (pvVar10 == (void *)0x0) goto LAB_140004e42;
        *(void **)(this + 8) = pvVar10;
        iVar8 = *(int *)(this + 0x10);
        *(int *)(this + 0x10) = iVar8 + 1;
        plVar9 = (longlong *)((longlong)iVar8 * 0x10 + *(longlong *)this);
        if (plVar9 != (longlong *)0x0) {
          *plVar9 = lVar2;
          plVar9[1] = lVar3;
          pvVar10 = *(void **)(this + 8);
        }
        puVar1 = (undefined8 *)((longlong)pvVar10 + (longlong)iVar8 * 8);
        if (puVar1 != (undefined8 *)0x0) {
          *puVar1 = pCVar13;
        }
      }
      local_160 = CVssAdmSnapshotSetEntry::
                  _AddSnapshot_CVssAdmSnapshotSetEntry__QEAAJPEAU_VSS_SNAPSHOT_PROP___Z
                            (pCVar13,(_VSS_SNAPSHOT_PROP *)&local_e0);
      if (local_160 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_218,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdmSnapshotSets::Initialize",0xf7,7,
                   (_VSSDBG_SEV_ENUM)pplVar18);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_168);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_168);
      }
    }
    else {
      VssFreeSnapshotPropertiesInternal(&local_e0);
    }
    local_228 = ZEXT816(0x140017068);
    local_160 = (**(code **)(*local_238 + 0x18))(local_238,1,local_e8,local_258);
    _Var17 = (_VSSDBG_SEV_ENUM)pplVar18;
  } while( true );
}



/* ==========================================================================
 * ??1CVssAdmSnapshotSets@@QEAA@XZ @ 0x140004e98  (261 bytes, 63 instructions)
 * void ??1CVssAdmSnapshotSets@@QEAA@XZ(CVssAdmSnapshotSets * this)
 * public: __cdecl CVssAdmSnapshotSets::~CVssAdmSnapshotSets(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssAdmSnapshotSets::~CVssAdmSnapshotSets(void) __ptr64 */

void __thiscall CVssAdmSnapshotSets::__1CVssAdmSnapshotSets__QEAA_XZ(CVssAdmSnapshotSets *this)

{
  wchar_t **ppwVar1;
  ulonglong uVar2;
  longlong lVar3;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_10c = 7;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_88 = 0x1000000;
  local_120 = L"CVssAdmSnapshotSets::~CVssAdmSnapshotSets";
  lVar3 = 0;
  local_118 = L"ADMPROCC";
  local_110 = 0xff;
  local_108 = 0xff;
  memset(local_100,0,0x78);
  ppwVar1 = &local_128;
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78);
  if (0 < *(int *)(this + 0x10)) {
    uVar2 = (ulonglong)*(uint *)(this + 0x10);
    do {
      if (*(CVssAdmSnapshotSetEntry **)(lVar3 + *(longlong *)(this + 8)) !=
          (CVssAdmSnapshotSetEntry *)0x0) {
        CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
                  (*(CVssAdmSnapshotSetEntry **)(lVar3 + *(longlong *)(this + 8)),(uint)ppwVar1);
      }
      lVar3 = lVar3 + 8;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  if (*(void **)this != (void *)0x0) {
    free(*(void **)this);
    *(undefined8 *)this = 0;
  }
  if (*(void **)(this + 8) != (void *)0x0) {
    free(*(void **)(this + 8));
    *(undefined8 *)(this + 8) = 0;
  }
  *(undefined4 *)(this + 0x10) = 0;
  return;
}



/* ==========================================================================
 * ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z @ 0x140004fa4  (163 bytes, 42 instructions)
 * void * ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z(CVssAdmSnapshotSetEntry * this, uint param_1)
 * public: void * __ptr64 __cdecl CVssAdmSnapshotSetEntry::`scalar deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: void * __ptr64 __cdecl CVssAdmSnapshotSetEntry::`scalar deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
          (CVssAdmSnapshotSetEntry *this,uint param_1)

{
  void *pvVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  if (0 < *(int *)(this + 0x28)) {
    uVar2 = (ulonglong)*(uint *)(this + 0x28);
    lVar3 = 0;
    do {
      pvVar1 = *(void **)(lVar3 + *(longlong *)(this + 0x20));
      VssFreeSnapshotPropertiesInternal(pvVar1);
      operator_delete__(pvVar1);
      lVar3 = lVar3 + 8;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  if (*(void **)(this + 0x18) != (void *)0x0) {
    free(*(void **)(this + 0x18));
    *(undefined8 *)(this + 0x18) = 0;
  }
  if (*(void **)(this + 0x20) != (void *)0x0) {
    free(*(void **)(this + 0x20));
    *(undefined8 *)(this + 0x20) = 0;
  }
  *(undefined4 *)(this + 0x28) = 0;
  operator_delete__(this);
  return this;
}



/* ==========================================================================
 * ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z @ 0x140005050  (410 bytes, 95 instructions)
 * void ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z(CVssAdminCLI * this, _GUID * param_1, IUnknown * * param_2)
 * private: void __cdecl CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface(struct _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface(struct
   _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::
_GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
          (CVssAdminCLI *this,_GUID *param_1,IUnknown **param_2)

{
  ushort *puVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe78;
  GUID local_168;
  ulong local_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [8];
  int local_90;
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface";
  local_138 = L"ADMPROCC";
  local_130 = 0x11c;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  local_168 = _GUID_949d7353_675f_4275_8969_f044c6277815;
  local_158 = param_1->Data1;
  uStack_154._0_2_ = param_1->Data2;
  uStack_154._2_2_ = param_1->Data3;
  uStack_150 = *(undefined4 *)param_1->Data4;
  uStack_14c = *(undefined4 *)(param_1->Data4 + 4);
  local_90 = GetProviderMgmtInterfaceInternal(&local_158,&local_168,param_2);
  if (-1 < local_90) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return;
  }
  if (local_90 != -0x7fffbffe) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface",0x128,7,
               in_stack_fffffffffffffe78);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  puVar1 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,8);
  _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5d,puVar1);
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_148,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",
                     (ushort *)L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface",0x126,7
                     ,in_stack_fffffffffffffe78);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar2,0,L"Provider doesn\'t support diff aras");
}



/* ==========================================================================
 * ?PrintUsage@CVssAdminCLI@@AEAAXXZ @ 0x1400051f4  (828 bytes, 190 instructions)
 * void ?PrintUsage@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::PrintUsage(void) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::PrintUsage(void) __ptr64 */

void __thiscall CVssAdminCLI::_PrintUsage_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  long lVar2;
  longlong lVar3;
  __int64 _Var4;
  longlong lVar5;
  ushort *pv;
  undefined8 uVar7;
  undefined **ppuVar8;
  undefined **ppuVar9;
  int iVar10;
  wchar_t **local_res8 [2];
  wchar_t *local_218;
  wchar_t *local_210;
  wchar_t *local_208;
  undefined4 local_200;
  undefined4 local_1fc;
  undefined4 local_1f8;
  undefined1 local_1f0 [120];
  undefined4 local_178;
  undefined8 local_170;
  undefined **local_168;
  ushort *local_160;
  CVssFunctionTracer local_158 [8];
  long local_150;
  CVssDebugInfo local_e8 [176];
  longlong lVar6;
  
  local_170 = 0xfffffffffffffffe;
  local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_210 = L"CVssAdminCLI::PrintUsage";
  local_208 = L"ADMPROCC";
  local_200 = 0x133;
  local_1fc = 7;
  local_1f8 = 0xff;
  local_178 = 0x1000000;
  memset(local_1f0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_158,&local_218);
  if (*(int *)(this + 0x60) == 0x17) {
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002724);
    iVar10 = 0;
    ppuVar9 = &PTR_u_ShadowStorage_1400172a8;
    ppuVar8 = &PTR_u_ShadowStorage_1400172a8;
    do {
      if ((*(uint *)((longlong)ppuVar8 + 0xc) & dCurrentSKU) != 0) {
        lVar3 = -1;
        do {
          lVar3 = lVar3 + 1;
        } while (*(short *)(ppuVar8[-1] + lVar3 * 2) != 0);
        lVar5 = -1;
        do {
          lVar6 = lVar5;
          lVar5 = lVar6 + 1;
        } while (*(short *)(*ppuVar8 + lVar5 * 2) != 0);
        iVar1 = (int)lVar6 + 3 + (int)lVar3;
        if (iVar10 < iVar1) {
          iVar10 = iVar1;
        }
      }
      ppuVar8 = ppuVar8 + 0xc;
    } while ((longlong)ppuVar8 < 0x140017ae8);
    local_168 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    lVar3 = (longlong)iVar10;
    pv = CoTaskMemAlloc(lVar3 * 2 + 2);
    local_160 = pv;
    if (pv == (ushort *)0x0) {
      local_res8[0] = (wchar_t **)CONCAT44(local_res8[0]._4_4_,0x8007000e);
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    do {
      if ((dCurrentSKU & *(uint *)((longlong)ppuVar9 + 0xc)) != 0) {
        lVar2 = StringCchPrintfW(pv,(longlong)(iVar10 + 1),(ushort *)L"%s %s",ppuVar9[-1],*ppuVar9);
        local_218 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_210 = L"CVssAdminCLI::PrintUsage";
        local_208 = L"ADMPROCC";
        local_200 = 0x17e;
        local_1fc = 7;
        local_1f8 = 0xff;
        local_178 = 0x1000000;
        local_150 = lVar2;
        memset(local_1f0,0,0x78);
        local_res8[0] = &local_218;
        if (lVar2 < 0) {
          uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                            (local_e8,(CVssDebugInfo *)&local_218);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_158,uVar7,lVar2,L"StringCchPrintf");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_218);
        lVar5 = -1;
        do {
          lVar5 = lVar5 + 1;
        } while (pv[lVar5] != 0);
        for (lVar5 = (longlong)(int)lVar5; lVar5 < lVar3; lVar5 = lVar5 + 1) {
          pv[lVar5] = 0x20;
        }
        pv[lVar3] = 0;
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,*(long *)(ppuVar9 + 2),pv);
      }
      ppuVar9 = ppuVar9 + 0xc;
    } while ((longlong)ppuVar9 < 0x140017ae8);
    *(undefined4 *)(this + 0x48) = 0;
    CoTaskMemFree(pv);
  }
  else {
    lVar3 = (longlong)*(int *)(this + 0x60);
    iVar10 = *(int *)(&DAT_1400172bc + lVar3 * 0x60);
    if ((iVar10 == 0x40002766) || (iVar10 == 0x4000276d)) {
      _Var4 = CVssMachineInformation::_GetMinDiffAreaForSystem_CVssMachineInformation__SA_JXZ();
      lVar3 = (longlong)*(int *)(this + 0x60);
      _OutputMsg_CVssAdminCLI__AEAAXJZZ
                (this,*(long *)(&DAT_1400172bc + lVar3 * 0x60),(&g_asAdmCommands)[lVar3 * 0xc],
                 (&PTR_u_ShadowStorage_1400172a8)[lVar3 * 0xc],
                 (longlong)(_Var4 + (ulonglong)((uint)(_Var4 >> 0x3f) & 0xfffff)) >> 0x14);
    }
    else {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ
                (this,iVar10,(&g_asAdmCommands)[lVar3 * 0xc],
                 (&PTR_u_ShadowStorage_1400172a8)[lVar3 * 0xc]);
    }
    if (*(int *)(&DAT_1400172c0 + (longlong)*(int *)(this + 0x60) * 0x60) != 0) {
      _DumpSnapshotTypes_CVssAdminCLI__AEAAXXZ(this);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_158);
  return;
}



/* ==========================================================================
 * ?AddDiffArea@CVssAdminCLI@@AEAAXXZ @ 0x14000553c  (642 bytes, 153 instructions)
 * void ?AddDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::AddDiffArea(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::AddDiffArea(void) __ptr64 */

void __thiscall CVssAdminCLI::_AddDiffArea_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  IID *riid;
  void **ppvObject;
  CVssAdminCLI *this_00;
  EVssAdmOption EVar2;
  undefined1 auStackY_1c8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe68;
  IUnknown *local_188 [2];
  _GUID local_178;
  undefined8 local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  undefined4 local_148;
  undefined4 local_144;
  undefined4 local_140;
  undefined1 local_138 [120];
  undefined4 local_c0;
  CVssFunctionTracer local_b8 [8];
  HRESULT local_b0;
  _GUID local_48;
  ulonglong local_38;
  
  local_168 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1c8;
  local_160 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_158 = L"CVssAdminCLI::AddDiffArea";
  local_150 = L"ADMPROCC";
  local_148 = 0x18e;
  local_144 = 7;
  local_140 = 0xff;
  local_c0 = 0x1000000;
  memset(local_138,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_b8,&local_160);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  riid = (IID *)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  EVar2 = 7;
  ppvObject = (void **)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  this_00 = this;
  iVar1 = _GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
                    (this,EVar2,(__int64 *)&local_178);
  if (iVar1 == 0) {
    _GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z(this,5,(__int64 *)&local_178,1);
  }
  else if (0 < (longlong)local_178._0_8_) {
    _GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(this_00,(ushort *)riid);
  }
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  (**(code **)(**(longlong **)this + 0x28))(*(longlong **)this,&local_178,riid,ppvObject);
  local_188[0] = (IUnknown *)0x0;
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_178,local_188);
  local_b0 = (*local_188[0]->lpVtbl[1].QueryInterface)(local_188[0],riid,ppvObject);
  if (local_b0 < 0) {
    if (local_b0 != -0x7ffbdcf3) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_160,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::AddDiffArea",0x1b4,7,in_stack_fffffffffffffe68);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_b8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_b8);
    }
    _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5f);
  }
  else {
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000274f);
    *(undefined4 *)(this + 0x48) = 0;
  }
  if (local_188[0] != (IUnknown *)0x0) {
    (*local_188[0]->lpVtbl->Release)();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_b8);
  return;
}



/* ==========================================================================
 * ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ @ 0x1400057c8  (2074 bytes, 443 instructions)
 * void ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::CreateSnapshot(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::CreateSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_CreateSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  LARGE_INTEGER LVar1;
  long lVar2;
  DWORD DVar3;
  DWORD DVar4;
  int iVar5;
  ushort *puVar6;
  uchar auVar7 [8];
  CVssAdminCLI *this_00;
  undefined1 auStackY_298 [32];
  _VSSDBG_SEV_ENUM _Var8;
  longlong **pplVar9;
  longlong *local_258 [2];
  GUID local_248;
  longlong *local_238;
  LARGE_INTEGER local_230;
  _GUID local_228;
  int local_218 [4];
  CVssFunctionTracer local_208 [8];
  int local_200;
  wchar_t *local_198;
  wchar_t *local_190;
  wchar_t *local_188;
  undefined4 local_180;
  undefined4 local_17c;
  undefined4 local_178;
  undefined1 local_170 [120];
  undefined4 local_f8;
  undefined8 local_f0;
  undefined1 local_e8 [128];
  ulong local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  _GUID local_48;
  ulonglong local_38;
  
  local_f0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_298;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_190 = L"CVssAdminCLI::CreateSnapshot";
  local_188 = L"ADMPROCC";
  local_180 = 0x1c6;
  local_17c = 7;
  local_178 = 0xff;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
            (local_208,(CVssDebugInfo *)&local_198);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar2 = 0x1d;
  }
  else {
    this_00 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar2 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(this_00,puVar6);
  }
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  local_230.QuadPart = 0;
  _GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z(this,1,&local_230.QuadPart,0);
  local_258[0] = (longlong *)0x0;
  local_248 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_228 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_190 = L"CVssAdminCLI::CreateSnapshot";
  local_188 = L"ADMPROCC";
  local_180 = 0x1de;
  local_17c = 7;
  local_178 = 0xff;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  pplVar9 = local_258;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_208,(CVssDebugInfo *)&local_198,&local_228,L"Coordinator");
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x1e5,7,(_VSSDBG_SEV_ENUM)pplVar9);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_258[0] + 0x18))(local_258[0],lVar2);
  LVar1 = local_230;
  _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x1e9,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_238 = (longlong *)0x0;
  local_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  if (local_230.QuadPart < 1) {
    local_200 = (**(code **)(*local_258[0] + 0x20))(local_258[0],&local_58);
    if (local_200 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::CreateSnapshot",0x216,7,_Var8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
    }
  }
  else {
    QueryPerformanceCounter(&local_230);
    srand(local_230.s.LowPart);
    DVar3 = GetTickCount();
    do {
      local_200 = (**(code **)(*local_258[0] + 0x20))();
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
      if (-1 < local_200) break;
      if (local_200 != -0x7ffbdcea) {
LAB_140005e77:
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_198,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::CreateSnapshot",0x209,7,_Var8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
      }
      DVar4 = GetTickCount();
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
      if (LVar1.QuadPart * 60000 <= (longlong)(ulonglong)(DVar4 - DVar3)) goto LAB_140005e77;
      if ((int)DAT_140024130 < 10000) {
        iVar5 = rand();
        DAT_140024130 = DAT_140024130 + iVar5 % 0x2ee;
      }
      DVar4 = DAT_140024130;
      local_198 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_190 = L"CVssAdminCLI::CreateSnapshot";
      local_188 = L"ADMPROCC";
      local_180 = 0x204;
      local_17c = 7;
      local_178 = 0xff;
      local_f8 = 0x1000000;
      memset(local_170,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_208,(CVssDebugInfo *)&local_198,
                 L"Snapshot already in progress, retrying in %u millisecs",DVar4);
      Sleep(DAT_140024130);
      _Var8 = (_VSSDBG_SEV_ENUM)pplVar9;
    } while (local_200 < 0);
  }
  auVar7 = local_48.Data4;
  local_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  local_228.Data4[0] = local_48.Data4[0];
  local_228.Data4[1] = local_48.Data4[1];
  local_228.Data4[2] = local_48.Data4[2];
  local_228.Data4[3] = local_48.Data4[3];
  local_228.Data1 = local_48.Data1;
  local_228.Data2 = local_48.Data2;
  local_228.Data3 = local_48.Data3;
  local_228.Data4[4] = local_48.Data4[4];
  local_228.Data4[5] = local_48.Data4[5];
  local_228.Data4[6] = local_48.Data4[6];
  local_228.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar7;
  local_200 = (**(code **)(*local_258[0] + 0x28))(local_258[0],puVar6,&local_228,&local_68);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x221,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = 0;
  Ordinal_30(&local_238,0);
  local_200 = (**(code **)(*local_258[0] + 0x30))(local_258[0],0,&local_238);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x227,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_238 + 0x20))(local_238,0xffffffff);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x22c,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = (**(code **)(*local_238 + 0x28))(local_238,local_218,0);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x232,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_200 = local_218[0];
  if (local_218[0] < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x23b,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_228.Data2 = (undefined2)uStack_64;
  local_228.Data3 = uStack_64._2_2_;
  local_228.Data1 = local_68;
  local_228.Data4[0] = (undefined1)uStack_60;
  local_228.Data4[1] = uStack_60._1_1_;
  local_228.Data4[2] = uStack_60._2_1_;
  local_228.Data4[3] = uStack_60._3_1_;
  local_228.Data4[4] = (undefined1)uStack_5c;
  local_228.Data4[5] = uStack_5c._1_1_;
  local_228.Data4[6] = uStack_5c._2_1_;
  local_228.Data4[7] = uStack_5c._3_1_;
  local_200 = (**(code **)(*local_258[0] + 0x38))(local_258[0],&local_228,local_e8);
  if (local_200 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_198,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::CreateSnapshot",0x244,7,_Var8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_208);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_208);
  }
  local_228.Data2 = (undefined2)uStack_64;
  local_228.Data3 = uStack_64._2_2_;
  local_228.Data1 = local_68;
  local_228.Data4[4] = (undefined1)uStack_5c;
  local_228.Data4[5] = uStack_5c._1_1_;
  local_228.Data4[6] = uStack_5c._2_1_;
  local_228.Data4[7] = uStack_5c._3_1_;
  local_228.Data4[0] = (undefined1)uStack_60;
  local_228.Data4[1] = uStack_60._1_1_;
  local_228.Data4[2] = uStack_60._2_1_;
  local_228.Data4[3] = uStack_60._3_1_;
  auVar7 = (uchar  [8])GuidToString(&local_228);
  local_228.Data4[0] = auVar7[0];
  local_228.Data4[1] = auVar7[1];
  local_228.Data4[2] = auVar7[2];
  local_228.Data4[3] = auVar7[3];
  local_228.Data4[4] = auVar7[4];
  local_228.Data4[5] = auVar7[5];
  local_228.Data4[6] = auVar7[6];
  local_228.Data4[7] = auVar7[7];
  local_228._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000274d,puVar6,auVar7);
  VssFreeSnapshotPropertiesInternal(local_e8);
  *(undefined4 *)(this + 0x48) = 0;
  if (auVar7 != (uchar  [8])0x0) {
    CoTaskMemFree((LPVOID)auVar7);
  }
  if (local_238 != (longlong *)0x0) {
    (**(code **)(*local_238 + 0x10))();
  }
  if (local_258[0] != (longlong *)0x0) {
    (**(code **)(*local_258[0] + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_208);
  return;
}



/* ==========================================================================
 * ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z @ 0x140005ff4  (1131 bytes, 267 instructions)
 * void ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z(CVssAdminCLI * this, IVssEnumMgmtObject * param_1)
 * private: void __cdecl CVssAdminCLI::DisplayDiffAreasPrivate(struct IVssEnumMgmtObject * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: void __cdecl CVssAdminCLI::DisplayDiffAreasPrivate(struct IVssEnumMgmtObject * __ptr64)
   __ptr64 */

void __thiscall
CVssAdminCLI::_DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z
          (CVssAdminCLI *this,IVssEnumMgmtObject *param_1)

{
  undefined1 auVar1 [16];
  ushort *pv;
  ushort *pv_00;
  ushort *pv_01;
  ushort *pv_02;
  __uint64 _Var2;
  ushort *pv_03;
  ushort *pv_04;
  CVssAdminCLI *this_00;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined1 local_res18 [8];
  ushort *local_res20;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdb8;
  ushort *puVar6;
  undefined **local_218;
  ushort *local_210;
  undefined **local_208;
  ushort *local_200;
  undefined **local_1f8;
  ushort *local_1f0;
  undefined **local_1e8;
  ushort *local_1e0;
  undefined **local_1d8;
  ushort *local_1d0;
  ushort *local_1c8;
  undefined **local_1c0;
  ushort *local_1b8;
  undefined **local_1b0;
  undefined8 local_1a8;
  undefined **local_1a0;
  undefined8 local_198;
  undefined1 local_190 [8];
  ushort *local_188;
  ushort *local_180;
  ulonglong local_178;
  ulonglong local_170;
  ulonglong local_168;
  undefined8 local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  CVssFunctionTracer local_a8 [8];
  int local_a0;
  
  local_160 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_150 = L"CVssAdminCLI::DisplayDiffAreasPrivate";
  local_148 = L"ADMPROCC";
  local_140 = 0x255;
  local_13c = 7;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  local_a0 = (**(code **)(*(longlong *)param_1 + 0x18))(param_1,1,local_190,local_res18);
  pv = local_188;
  pv_00 = local_180;
  while( true ) {
    if (local_a0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_158,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::DisplayDiffAreasPrivate",0x260,7,
                 in_stack_fffffffffffffdb8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_a8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_a8);
    }
    if (local_a0 == 1) break;
    local_1a0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1b0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_188 = pv;
    local_180 = pv_00;
    local_1d0 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_168,1);
    local_1d8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1e0 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_170,1);
    local_1e8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    pv_02 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,local_178,1);
    local_1c0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_1b8 = pv_02;
    local_1c8 = _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,pv);
    this_00 = this;
    local_res20 = _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,pv_00);
    _Var2 = _GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(this_00,pv_00);
    local_1f0 = (ushort *)0x0;
    local_1f8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_200 = (ushort *)0x0;
    local_208 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_210 = (ushort *)0x0;
    local_218 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    if (_Var2 == 0) {
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_1f8,
                 (ushort *)L"0");
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_208,
                 (ushort *)L"0");
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_218,
                 (ushort *)L"0");
      pv_04 = local_200;
      pv_03 = local_1f0;
    }
    else {
      auVar1._8_8_ = 0;
      auVar1._0_8_ = _Var2;
      lVar3 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar1,8);
      uVar5 = (_Var2 - lVar3 >> 1) + lVar3 >> 6;
      uVar4 = 100;
      if ((longlong)(local_168 / uVar5) < 0xffffffff) {
        uVar4 = local_168 / uVar5;
      }
      pv_03 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
      uVar4 = 100;
      if ((longlong)(local_170 / uVar5) < 0xffffffff) {
        uVar4 = local_170 / uVar5;
      }
      local_1f0 = pv_03;
      pv_04 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
      uVar4 = 100;
      if ((longlong)(local_178 / uVar5) < 0xffffffff) {
        uVar4 = local_178 / uVar5;
      }
      local_200 = pv_04;
      local_210 = _FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z(this,uVar4,0);
    }
    pv_01 = local_210;
    puVar6 = local_1d0;
    _OutputMsg_CVssAdminCLI__AEAAXJZZ
              (this,0x40002758,local_1c8,pv,local_res20,pv_00,local_1d0,pv_03,local_1e0,pv_04,pv_02,
               local_210);
    in_stack_fffffffffffffdb8 = (_VSSDBG_SEV_ENUM)puVar6;
    if (pv_01 != (ushort *)0x0) {
      CoTaskMemFree(pv_01);
    }
    local_210 = (ushort *)0x0;
    local_218 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_04 != (ushort *)0x0) {
      CoTaskMemFree(pv_04);
    }
    local_200 = (ushort *)0x0;
    local_208 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_03 != (ushort *)0x0) {
      CoTaskMemFree(pv_03);
    }
    local_1f0 = (ushort *)0x0;
    local_1f8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_02 != (ushort *)0x0) {
      CoTaskMemFree(pv_02);
    }
    local_1b8 = (ushort *)0x0;
    local_1c0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (local_1e0 != (ushort *)0x0) {
      CoTaskMemFree(local_1e0);
    }
    local_1e0 = (ushort *)0x0;
    local_1e8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (local_1d0 != (ushort *)0x0) {
      CoTaskMemFree(local_1d0);
    }
    local_1d0 = (ushort *)0x0;
    local_1d8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv_00 != (ushort *)0x0) {
      CoTaskMemFree(pv_00);
    }
    local_1a8 = 0;
    local_1b0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    if (pv != (ushort *)0x0) {
      CoTaskMemFree(pv);
    }
    local_198 = 0;
    local_1a0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                 ::_vftable_;
    local_a0 = (**(code **)(*(longlong *)param_1 + 0x18))(param_1,1,local_190,local_res18);
    pv = local_188;
    pv_00 = local_180;
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}



/* ==========================================================================
 * ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ @ 0x140006468  (1857 bytes, 410 instructions)
 * void ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ListDiffAreas(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::ListDiffAreas(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListDiffAreas_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  bool bVar1;
  uchar auVar2 [8];
  LPVOID pv;
  IID *riid;
  ushort *puVar3;
  undefined8 uVar4;
  IVssEnumMgmtObject *pIVar5;
  undefined1 auStackY_238 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdf8;
  _VSSDBG_SEV_ENUM _Var6;
  IVssEnumMgmtObject **ppIVar7;
  IVssEnumMgmtObject *local_1f8;
  IVssEnumMgmtObject *local_1f0;
  IVssEnumMgmtObject *local_1e8 [2];
  _GUID local_1d8;
  IUnknown *local_1c8;
  undefined1 local_1c0 [8];
  undefined1 local_1b8 [24];
  wchar_t *local_1a0;
  wchar_t *local_198;
  wchar_t *local_190;
  undefined4 local_188;
  undefined4 local_184;
  undefined4 local_180;
  undefined1 local_178 [120];
  undefined4 local_100;
  CVssFunctionTracer local_f8 [8];
  ULONG local_f0;
  undefined8 local_88;
  undefined1 local_80 [8];
  uchar local_78 [8];
  LPVOID local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_88 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_238;
  local_1a0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_198 = L"CVssAdminCLI::ListDiffAreas";
  local_190 = L"ADMPROCC";
  local_188 = 0x299;
  local_184 = 7;
  local_180 = 0xff;
  local_100 = 0x1000000;
  bVar1 = true;
  memset(local_178,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_f8,&local_1a0);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  riid = (IID *)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  auVar2 = local_48.Data4;
  local_1d8.Data4[0] = local_48.Data4[0];
  local_1d8.Data4[1] = local_48.Data4[1];
  local_1d8.Data4[2] = local_48.Data4[2];
  local_1d8.Data4[3] = local_48.Data4[3];
  local_1d8.Data1 = local_48.Data1;
  local_1d8.Data2 = local_48.Data2;
  local_1d8.Data3 = local_48.Data3;
  local_1d8.Data4[4] = local_48.Data4[4];
  local_1d8.Data4[5] = local_48.Data4[5];
  local_1d8.Data4[6] = local_48.Data4[6];
  local_1d8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  (**(code **)(**(longlong **)this + 0x50))(*(longlong **)this,&local_1d8,riid,puVar3);
  local_1c8 = (IUnknown *)0x0;
  local_1d8.Data4[0] = local_48.Data4[0];
  local_1d8.Data4[1] = local_48.Data4[1];
  local_1d8.Data4[2] = local_48.Data4[2];
  local_1d8.Data4[3] = local_48.Data4[3];
  local_1d8.Data4[4] = local_48.Data4[4];
  local_1d8.Data4[5] = local_48.Data4[5];
  local_1d8.Data4[6] = local_48.Data4[6];
  local_1d8.Data4[7] = local_48.Data4[7];
  local_1d8.Data1 = local_48.Data1;
  local_1d8.Data2 = local_48.Data2;
  local_1d8.Data3 = local_48.Data3;
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_1d8,&local_1c8);
  if (riid == (IID *)0x0) {
    if (puVar3 == (ushort *)0x0) {
      local_1f0 = (IVssEnumMgmtObject *)0x0;
      local_1d8 = (_GUID)_GUID_fa7df749_66e7_4986_a27f_e2f04ae53772;
      local_1b8._0_16_ = (undefined1  [16])_GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
      local_1a0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_198 = L"CVssAdminCLI::ListDiffAreas";
      local_190 = L"ADMPROCC";
      local_188 = 0x2d6;
      local_184 = 7;
      local_180 = 0xff;
      local_100 = 0x1000000;
      memset(local_178,0,0x78);
      ppIVar7 = &local_1f0;
      CVssFunctionTracer::
      _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
                (local_f8,&local_1a0,local_1b8,L"VssSnapshotMgmt");
      auVar2 = local_48.Data4;
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2dd,7,
                   (_VSSDBG_SEV_ENUM)ppIVar7);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      local_1f8 = (IVssEnumMgmtObject *)0x0;
      local_1d8.Data4[0] = local_48.Data4[0];
      local_1d8.Data4[1] = local_48.Data4[1];
      local_1d8.Data4[2] = local_48.Data4[2];
      local_1d8.Data4[3] = local_48.Data4[3];
      local_1d8.Data1 = local_48.Data1;
      local_1d8.Data2 = local_48.Data2;
      local_1d8.Data3 = local_48.Data3;
      local_1d8.Data4[4] = local_48.Data4[4];
      local_1d8.Data4[5] = local_48.Data4[5];
      local_1d8.Data4[6] = local_48.Data4[6];
      local_1d8.Data4[7] = local_48.Data4[7];
      local_48.Data4 = auVar2;
      local_f0 = (**(code **)(*(longlong *)local_1f0 + 0x20))
                           (local_1f0,&local_1d8,0xffffffff,&local_1f8);
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2e8,7,
                   (_VSSDBG_SEV_ENUM)ppIVar7);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2ec,7,
                           (_VSSDBG_SEV_ENUM)ppIVar7);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      local_f0 = (**(code **)(*(longlong *)local_1f8 + 0x18))(local_1f8,1,local_80,local_1c0);
      _Var6 = (_VSSDBG_SEV_ENUM)ppIVar7;
      auVar2 = local_78;
      pv = local_70;
      while( true ) {
        if ((int)local_f0 < 0) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2fa,7,_Var6);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
        }
        if (local_f0 == 1) break;
        local_1d8.Data4[0] = auVar2[0];
        local_1d8.Data4[1] = auVar2[1];
        local_1d8.Data4[2] = auVar2[2];
        local_1d8.Data4[3] = auVar2[3];
        local_1d8.Data4[4] = auVar2[4];
        local_1d8.Data4[5] = auVar2[5];
        local_1d8.Data4[6] = auVar2[6];
        local_1d8.Data4[7] = auVar2[7];
        local_1d8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_1b8._8_8_ = pv;
        local_1b8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_1e8[0] = (IVssEnumMgmtObject *)0x0;
        local_78 = auVar2;
        local_70 = pv;
        local_f0 = (*local_1c8->lpVtbl[2].QueryInterface)(local_1c8,(IID *)auVar2,local_1e8);
        if ((int)local_f0 < 0) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x30c,7,
                     (_VSSDBG_SEV_ENUM)ppIVar7);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
        }
        if (local_f0 == 1) {
          if (local_1e8[0] != (IVssEnumMgmtObject *)0x0) {
            (**(code **)(*(longlong *)local_1e8[0] + 0x10))();
          }
        }
        else {
          _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1e8[0]);
          bVar1 = false;
          if (local_1e8[0] != (IVssEnumMgmtObject *)0x0) {
            (**(code **)(*(longlong *)local_1e8[0] + 0x10))();
          }
        }
        if (pv != (LPVOID)0x0) {
          CoTaskMemFree(pv);
        }
        local_1b8._0_16_ = ZEXT816(0x140017068);
        if (auVar2 != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)auVar2);
        }
        local_1d8 = (_GUID)ZEXT816(0x140017068);
        local_f0 = (**(code **)(*(longlong *)local_1f8 + 0x18))(local_1f8,1,local_80,local_1c0);
        _Var6 = (_VSSDBG_SEV_ENUM)ppIVar7;
        auVar2 = local_78;
        pv = local_70;
      }
      if (bVar1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x31a,7,
                           (_VSSDBG_SEV_ENUM)ppIVar7);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      pIVar5 = local_1f0;
      if (local_1f8 != (IVssEnumMgmtObject *)0x0) {
        (**(code **)(*(longlong *)local_1f8 + 0x10))();
        pIVar5 = local_1f0;
      }
    }
    else {
      local_1f8 = (IVssEnumMgmtObject *)0x0;
      local_f0 = (*local_1c8->lpVtbl[2].AddRef)(local_1c8);
      if ((int)local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2c3,7,
                   in_stack_fffffffffffffdf8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) {
        uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1a0,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2c7,7,
                           in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_f8,uVar4,1,
                   L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
      }
      _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1f8);
      pIVar5 = local_1f8;
    }
  }
  else {
    local_1f8 = (IVssEnumMgmtObject *)0x0;
    local_f0 = (*local_1c8->lpVtbl[2].QueryInterface)(local_1c8,riid,&local_1f8);
    if ((int)local_f0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1a0,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListDiffAreas",0x2b2,7,in_stack_fffffffffffffdf8);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
    }
    if (local_f0 == 1) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_1a0,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListDiffAreas",0x2b6,7,
                         in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_f8,uVar4,1,
                 L"CVssAdminCLI::ListDiffareas: No diffareas found that satisfy the query");
    }
    _DisplayDiffAreasPrivate_CVssAdminCLI__AEAAXPEAUIVssEnumMgmtObject___Z(this,local_1f8);
    pIVar5 = local_1f8;
  }
  if (pIVar5 != (IVssEnumMgmtObject *)0x0) {
    (**(code **)(*(longlong *)pIVar5 + 0x10))();
  }
  *(undefined4 *)(this + 0x48) = 0;
  if (local_1c8 != (IUnknown *)0x0) {
    (*local_1c8->lpVtbl->Release)();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_f8);
  return;
}



/* ==========================================================================
 * ?ListSnapshots@CVssAdminCLI@@AEAAXXZ @ 0x140006bbc  (2123 bytes, 451 instructions)
 * void ?ListSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ListSnapshots(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListSnapshots(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListSnapshots_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  bool bVar3;
  uint uVar4;
  bool bVar5;
  long lVar6;
  BOOL BVar7;
  long lVar8;
  ushort *puVar9;
  LPCWSTR lpszVolumeMountPoint;
  uchar pv [8];
  uchar auVar10 [8];
  wchar_t *pwVar11;
  undefined8 uVar12;
  CVssAdminCLI *pCVar13;
  wchar_t **ppwVar14;
  longlong *plVar15;
  longlong *plVar16;
  wchar_t *pwVar17;
  ulonglong uVar18;
  longlong lVar19;
  undefined1 auStackY_398 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc98;
  _VSSDBG_SEV_ENUM _Var20;
  ulonglong local_330;
  undefined **local_328;
  uchar auStack_320 [8];
  undefined **local_318;
  uchar auStack_310 [8];
  undefined **local_308;
  uchar auStack_300 [8];
  longlong *local_2f8;
  undefined **local_2f0;
  ushort *local_2e8;
  void *local_2e0;
  longlong *plStack_2d8;
  uint local_2d0;
  undefined **local_2c8;
  ushort *local_2c0;
  _GUID local_2b8;
  wchar_t *local_2a8;
  wchar_t *local_2a0;
  wchar_t *local_298;
  undefined4 local_290;
  undefined4 local_28c;
  undefined4 local_288;
  undefined1 local_280 [120];
  undefined4 local_208;
  undefined8 local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined4 local_1d0;
  undefined1 local_1c8 [120];
  undefined4 local_150;
  CVssFunctionTracer local_148 [8];
  long local_140;
  undefined **local_d8;
  uchar auStack_d0 [8];
  undefined **local_c8;
  uchar auStack_c0 [8];
  undefined **local_b8;
  uchar auStack_b0 [8];
  WCHAR local_a8 [49];
  undefined2 local_46;
  ulonglong local_38;
  
  local_1f8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_398;
  local_2a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_2a0 = L"CVssAdminCLI::ListSnapshots";
  local_298 = L"ADMPROCC";
  local_290 = 0x324;
  local_28c = 7;
  local_288 = 0xff;
  local_208 = 0x1000000;
  memset(local_280,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_148,&local_2a8);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar6 = -1;
  }
  else {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar6 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(pCVar13,puVar9);
  }
  local_d8 = (undefined **)0x0;
  auStack_d0[0] = '\0';
  auStack_d0[1] = '\0';
  auStack_d0[2] = '\0';
  auStack_d0[3] = '\0';
  auStack_d0[4] = '\0';
  auStack_d0[5] = '\0';
  auStack_d0[6] = '\0';
  auStack_d0[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,(_GUID *)&local_d8);
  lpszVolumeMountPoint =
       (LPCWSTR)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  bVar3 = false;
  local_b8 = (undefined **)0x0;
  auStack_b0[0] = '\0';
  auStack_b0[1] = '\0';
  auStack_b0[2] = '\0';
  auStack_b0[3] = '\0';
  auStack_b0[4] = '\0';
  auStack_b0[5] = '\0';
  auStack_b0[6] = '\0';
  auStack_b0[7] = '\0';
  puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
  if (puVar9 != (ushort *)0x0) {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
    bVar5 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar13,puVar9,(_GUID *)&local_b8);
    if (!bVar5) {
      uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1f0,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x337,7,
                          in_stack_fffffffffffffc98);
      _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,10);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar12,0x1004,L"CVssAdminCLI::ListSnapshots: invalid snapshot set ID: %s"
                );
    }
  }
  local_c8 = (undefined **)0x0;
  auStack_c0[0] = '\0';
  auStack_c0[1] = '\0';
  auStack_c0[2] = '\0';
  auStack_c0[3] = '\0';
  auStack_c0[4] = '\0';
  auStack_c0[5] = '\0';
  auStack_c0[6] = '\0';
  auStack_c0[7] = '\0';
  puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar9 != (ushort *)0x0) {
    pCVar13 = this;
    puVar9 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar5 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar13,puVar9,(_GUID *)&local_c8);
    if (!bVar5) {
      uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1f0,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x341,7,
                          in_stack_fffffffffffffc98);
      _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar12,0x1004,L"CVssAdminCLI::ListSnapshots: invalid snapshot ID: %s");
    }
  }
  local_308 = local_b8;
  auStack_300[0] = auStack_b0[0];
  auStack_300[1] = auStack_b0[1];
  auStack_300[2] = auStack_b0[2];
  auStack_300[3] = auStack_b0[3];
  auStack_300[4] = auStack_b0[4];
  auStack_300[5] = auStack_b0[5];
  auStack_300[6] = auStack_b0[6];
  auStack_300[7] = auStack_b0[7];
  local_318 = local_c8;
  auStack_310[0] = auStack_c0[0];
  auStack_310[1] = auStack_c0[1];
  auStack_310[2] = auStack_c0[2];
  auStack_310[3] = auStack_c0[3];
  auStack_310[4] = auStack_c0[4];
  auStack_310[5] = auStack_c0[5];
  auStack_310[6] = auStack_c0[6];
  auStack_310[7] = auStack_c0[7];
  local_328 = local_d8;
  auStack_320[0] = auStack_d0[0];
  auStack_320[1] = auStack_d0[1];
  auStack_320[2] = auStack_d0[2];
  auStack_320[3] = auStack_d0[3];
  auStack_320[4] = auStack_d0[4];
  auStack_320[5] = auStack_d0[5];
  auStack_320[6] = auStack_d0[6];
  auStack_320[7] = auStack_d0[7];
  _Var20 = (_VSSDBG_SEV_ENUM)local_148;
  (**(code **)(**(longlong **)this + 0x18))
            (*(longlong **)this,lVar6,&local_328,lpszVolumeMountPoint);
  memset(local_a8,0,100);
  if (lpszVolumeMountPoint != (LPCWSTR)0x0) {
    if (*lpszVolumeMountPoint == L'\\') {
      lVar8 = StringCchCopyW((ushort *)local_a8,0x32,(ushort *)lpszVolumeMountPoint);
      local_2a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
      local_2a0 = L"CVssAdminCLI::ListSnapshots";
      local_298 = L"ADMPROCC";
      local_290 = 0x35b;
      local_28c = 7;
      local_288 = 0xff;
      local_208 = 0x1000000;
      local_140 = lVar8;
      memset(local_280,0,0x78);
      if (lVar8 < 0) {
        uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                           ((CVssDebugInfo *)&local_1f0,(CVssDebugInfo *)&local_2a8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                  (local_148,uVar12,lVar8,L"StringCchCopy");
      }
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_2a8);
      local_46 = 0;
    }
    else {
      BVar7 = GetVolumeNameForVolumeMountPointW(lpszVolumeMountPoint,local_a8,0x32);
      if (BVar7 == 0) {
        uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                           ((CVssDebugInfo *)&local_1f0,
                            (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                            (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x354,1,
                            _Var20);
        GetLastError();
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_148,uVar12,0x80042308,
                   L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx");
      }
    }
  }
  local_2e0 = (void *)0x0;
  plStack_2d8 = (longlong *)0x0;
  local_2d0 = 0;
  local_308 = local_d8;
  auStack_300[0] = auStack_d0[0];
  auStack_300[1] = auStack_d0[1];
  auStack_300[2] = auStack_d0[2];
  auStack_300[3] = auStack_d0[3];
  auStack_300[4] = auStack_d0[4];
  auStack_300[5] = auStack_d0[5];
  auStack_300[6] = auStack_d0[6];
  auStack_300[7] = auStack_d0[7];
  local_318 = local_c8;
  auStack_310[0] = auStack_c0[0];
  auStack_310[1] = auStack_c0[1];
  auStack_310[2] = auStack_c0[2];
  auStack_310[3] = auStack_c0[3];
  auStack_310[4] = auStack_c0[4];
  auStack_310[5] = auStack_c0[5];
  auStack_310[6] = auStack_c0[6];
  auStack_310[7] = auStack_c0[7];
  local_328 = local_b8;
  auStack_320[0] = auStack_b0[0];
  auStack_320[1] = auStack_b0[1];
  auStack_320[2] = auStack_b0[2];
  auStack_320[3] = auStack_b0[3];
  auStack_320[4] = auStack_b0[4];
  auStack_320[5] = auStack_b0[5];
  auStack_320[6] = auStack_b0[6];
  auStack_320[7] = auStack_b0[7];
  CVssAdmSnapshotSets::_Initialize_CVssAdmSnapshotSets__QEAAXJU_GUID__00PEBG_Z
            ((CVssAdmSnapshotSets *)&local_2e0,lVar6,(_GUID *)&local_328,(_GUID *)&local_318,
             (_GUID *)&local_308,(ushort *)local_a8);
  local_330 = (ulonglong)local_2d0;
  if (local_2d0 != 0) {
    plVar15 = plStack_2d8;
    bVar5 = false;
    if (0 < (int)local_2d0) {
      do {
        bVar3 = bVar5;
        puVar1 = (undefined8 *)*plVar15;
        local_2b8._0_8_ = *puVar1;
        local_2b8.Data4 = *(uchar (*) [8])(puVar1 + 1);
        local_2f8 = plVar15;
        pv = (uchar  [8])GuidToString(&local_2b8);
        local_308 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auStack_300 = pv;
        auVar10 = (uchar  [8])DateTimeToString((__int64 *)(*(longlong *)puVar1[4] + 0x70));
        local_318 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        auStack_310 = auVar10;
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002752,pv,(ulonglong)*(uint *)(puVar1 + 2));
        if (0 < *(int *)(puVar1 + 5)) {
          bVar3 = true;
          lVar19 = 0;
          uVar18 = (ulonglong)*(uint *)(puVar1 + 5);
          do {
            puVar2 = *(undefined8 **)(lVar19 + puVar1[4]);
            _GetProviderName_CVssAdminCLI__AEAAPEBGAEAU_GUID___Z(this,(_GUID *)(puVar2 + 0xb));
            local_2e8 = _BuildSnapshotAttributeDisplayString_CVssAdminCLI__AEAAPEAGK_Z
                                  (this,*(ulong *)(puVar2 + 0xd));
            local_2f0 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            auStack_320 = (uchar  [8])
                          _DetermineSnapshotType_CVssAdminCLI__AEAAPEAGJ_Z
                                    (this,*(long *)(puVar2 + 0xd));
            local_328 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            local_2b8._0_8_ = *puVar2;
            local_2b8.Data4 = *(uchar (*) [8])(puVar2 + 1);
            local_2c0 = GuidToString(&local_2b8);
            local_2c8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
            pwVar11 = (wchar_t *)
                      _GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(this,(ushort *)puVar2[6]);
            puVar9 = local_2c0;
            auVar10 = auStack_320;
            pwVar17 = L"?";
            if (pwVar11 != (wchar_t *)0x0) {
              pwVar17 = pwVar11;
            }
            _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002753,local_2c0,pwVar17);
            if (puVar9 != (ushort *)0x0) {
              CoTaskMemFree(puVar9);
            }
            local_2c0 = (ushort *)0x0;
            local_2c8 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            if (auVar10 != (uchar  [8])0x0) {
              CoTaskMemFree((LPVOID)auVar10);
            }
            auStack_320[0] = '\0';
            auStack_320[1] = '\0';
            auStack_320[2] = '\0';
            auStack_320[3] = '\0';
            auStack_320[4] = '\0';
            auStack_320[5] = '\0';
            auStack_320[6] = '\0';
            auStack_320[7] = '\0';
            local_328 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            if (local_2e8 != (ushort *)0x0) {
              CoTaskMemFree(local_2e8);
            }
            local_2e8 = (ushort *)0x0;
            local_2f0 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                         ::_vftable_;
            lVar19 = lVar19 + 8;
            uVar18 = uVar18 - 1;
            plVar15 = local_2f8;
            auVar10 = auStack_310;
            pv = auStack_300;
          } while (uVar18 != 0);
        }
        if (auVar10 != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)auVar10);
        }
        auStack_310[0] = '\0';
        auStack_310[1] = '\0';
        auStack_310[2] = '\0';
        auStack_310[3] = '\0';
        auStack_310[4] = '\0';
        auStack_310[5] = '\0';
        auStack_310[6] = '\0';
        auStack_310[7] = '\0';
        local_318 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
        auStack_300[0] = '\0';
        auStack_300[1] = '\0';
        auStack_300[2] = '\0';
        auStack_300[3] = '\0';
        auStack_300[4] = '\0';
        auStack_300[5] = '\0';
        auStack_300[6] = '\0';
        auStack_300[7] = '\0';
        local_308 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        local_2f8 = plVar15 + 1;
        local_330 = local_330 - 1;
        plVar15 = local_2f8;
        bVar5 = bVar3;
      } while (local_330 != 0);
    }
    uVar4 = local_2d0;
    plVar15 = plStack_2d8;
    *(uint *)(this + 0x48) = (uint)!bVar3;
    local_1f0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
    local_1e8 = L"CVssAdmSnapshotSets::~CVssAdmSnapshotSets";
    local_1e0 = L"ADMPROCC";
    local_1d8 = 0xff;
    local_1d4 = 7;
    local_1d0 = 0xff;
    local_150 = 0x1000000;
    memset(local_1c8,0,0x78);
    ppwVar14 = &local_1f0;
    CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
              ((CVssFunctionTracer *)&local_2a8);
    if (0 < (int)uVar4) {
      uVar18 = (ulonglong)uVar4;
      plVar16 = plVar15;
      do {
        if ((CVssAdmSnapshotSetEntry *)*plVar16 != (CVssAdmSnapshotSetEntry *)0x0) {
          CVssAdmSnapshotSetEntry::___GCVssAdmSnapshotSetEntry__QEAAPEAXI_Z
                    ((CVssAdmSnapshotSetEntry *)*plVar16,(uint)ppwVar14);
        }
        plVar16 = plVar16 + 1;
        uVar18 = uVar18 - 1;
      } while (uVar18 != 0);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)&local_2a8);
    if (local_2e0 != (void *)0x0) {
      free(local_2e0);
    }
    if (plVar15 != (longlong *)0x0) {
      free(plVar15);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
    return;
  }
  uVar12 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                     ((CVssDebugInfo *)&local_1f0,
                      (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                      (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListSnapshots",0x36d,7,_Var20)
  ;
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_148,uVar12,1,
             L"CVssAdminCLI::ListSnapshots: No snapshots found that satisfy the query");
}



/* ==========================================================================
 * ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ @ 0x140007414  (244 bytes, 58 instructions)
 * void ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::DumpSnapshotTypes(void) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::DumpSnapshotTypes(void) __ptr64 */

void __thiscall CVssAdminCLI::_DumpSnapshotTypes_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  longlong lVar1;
  undefined **ppuVar2;
  longlong lVar3;
  undefined8 in_R9;
  undefined8 uVar4;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  uVar4 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_128 = L"CVssAdminCLI::DumpSnapshotTypes";
  local_120 = L"ADMPROCC";
  local_118 = 0x3ab;
  local_114 = 7;
  local_110 = 0xff;
  lVar1 = 0;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  if (true) {
    ppuVar2 = &g_asAdmTypeNames;
    lVar3 = lVar1;
    do {
      if ((dCurrentSKU & *(uint *)((longlong)&DAT_1400171f8 + lVar1)) != 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ
                  (this,*(long *)((longlong)&DAT_140017200 + lVar1),*ppuVar2,in_R9,uVar4);
      }
      lVar3 = lVar3 + 1;
      lVar1 = lVar3 * 0x18;
      ppuVar2 = &g_asAdmTypeNames + lVar3 * 3;
    } while (*ppuVar2 != (undefined *)0x0);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}



/* ==========================================================================
 * ?ListWriters@CVssAdminCLI@@AEAAXXZ @ 0x140007510  (2334 bytes, 515 instructions)
 * void ?ListWriters@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ListWriters(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListWriters(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListWriters_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  ushort *puVar1;
  ushort *pv;
  uint uVar2;
  wchar_t *pwVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined1 auStackY_218 [32];
  _VSSDBG_SEV_ENUM _Var6;
  undefined8 in_stack_fffffffffffffe18;
  wchar_t *local_1d8;
  int local_1d0 [2];
  longlong *local_1c8;
  longlong *local_1c0;
  int local_1b8;
  int local_1b4;
  uint local_1b0 [2];
  _GUID local_1a8;
  CVssFunctionTracer local_198 [8];
  int local_190;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  undefined **local_80;
  ushort *local_78;
  undefined **local_70;
  ushort *local_68;
  undefined8 local_60;
  ulong local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  ulong local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  ulonglong local_38;
  
  local_60 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_218;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_120 = L"CVssAdminCLI::ListWriters";
  local_118 = L"ADMPROCC";
  local_110 = 0x3c0;
  local_10c = 7;
  local_108 = 0xff;
  uVar4 = 0;
  local_88 = 0x1000000;
  uVar5 = 1;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_198,&local_128);
  local_1c8 = (longlong *)0x0;
  local_1c0 = (longlong *)0x0;
  local_190 = CreateVssBackupComponentsInternal(&local_1c8);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3cc,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x28))(local_1c8,0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3d0,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x48))(local_1c8,&local_1c0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3d6,7,
               (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_1b8 = 0;
  uVar2 = uVar4;
  do {
    Sleep(0x9c4);
    local_1d0[0] = 0;
    local_190 = (**(code **)(*local_1c0 + 0x28))(local_1c0,&local_1b8,local_1d0);
    _Var6 = (_VSSDBG_SEV_ENUM)in_stack_fffffffffffffe18;
    if (local_190 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListWriters",0x3e6,7,_Var6);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    if (local_1b8 == 0x4230a) goto LAB_1400076b3;
    if (local_1b8 != 0x42309) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ListWriters",0x3ec,7,_Var6);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    uVar2 = uVar2 + 1;
  } while ((int)uVar2 < 4);
  _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275a);
  local_190 = (**(code **)(*local_1c0 + 0x20))(local_1c0,0xffffffff);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3f5,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
LAB_1400076b3:
  Ordinal_30(&local_1c0,0);
  local_190 = (**(code **)(*local_1c8 + 0x60))();
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x3fd,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c8 + 0x80))(local_1c8,&local_1c0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x402,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  local_190 = (**(code **)(*local_1c0 + 0x20))(local_1c0,0xffffffff);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x406,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  Ordinal_30(&local_1c0,0);
  local_190 = (**(code **)(*local_1c8 + 0x88))(local_1c8,local_1b0);
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x40c,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  if (local_1b0[0] != 0) {
    do {
      local_48 = 0;
      uStack_44 = 0;
      uStack_40 = 0;
      uStack_3c = 0;
      local_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_4c = 0;
      local_1d8 = (wchar_t *)0x0;
      _Var6 = (_VSSDBG_SEV_ENUM)&local_1b4;
      local_190 = (**(code **)(*local_1c8 + 0x98))(local_1c8,uVar4,&local_48,&local_58);
      if (local_190 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_128,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListWriters",0x41a,7,_Var6);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
      }
      if (local_1d0[0] == 1) {
        uVar2 = 0x6b;
      }
      else if (local_1d0[0] == 2) {
        uVar2 = 0x6e;
      }
      else if (local_1d0[0] == 3) {
        uVar2 = 0x6f;
      }
      else if (local_1d0[0] == 4) {
        uVar2 = 0x78;
      }
      else if (local_1d0[0] == 5) {
        uVar2 = 0x70;
      }
      else if (local_1d0[0] - 6U < 9) {
        uVar2 = 0x6c;
      }
      else {
        uVar2 = 0x6d;
      }
      puVar1 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar2);
      _Var6 = (_VSSDBG_SEV_ENUM)puVar1;
      if (local_1b4 == -0x7ffbdce7) {
        uVar2 = 0x79;
LAB_140007926:
        _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar2);
      }
      else {
        if (local_1b4 == -0x7ffbdc10) {
          uVar2 = 0x71;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0f) {
          uVar2 = 0x72;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0e) {
          uVar2 = 0x73;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0d) {
          uVar2 = 0x74;
          goto LAB_140007926;
        }
        if (local_1b4 == -0x7ffbdc0c) {
          uVar2 = 0x75;
          goto LAB_140007926;
        }
        if (local_1b4 == 0) {
          uVar2 = 0x77;
          goto LAB_140007926;
        }
        _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,0x76);
        local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_120 = L"CVssAdminCLI::ListWriters";
        local_118 = L"ADMPROCC";
        local_110 = 0x45a;
        local_10c = 7;
        local_108 = 0xff;
        local_88 = 0x1000000;
        memset(local_100,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_198,&local_128,L"Unexpected writer error failure: 0x%08x",local_1b4);
      }
      local_1a8.Data2 = (undefined2)uStack_54;
      local_1a8.Data3 = uStack_54._2_2_;
      local_1a8.Data1 = local_58;
      local_1a8.Data4[4] = (undefined1)uStack_4c;
      local_1a8.Data4[5] = uStack_4c._1_1_;
      local_1a8.Data4[6] = uStack_4c._2_1_;
      local_1a8.Data4[7] = uStack_4c._3_1_;
      local_1a8.Data4[0] = (undefined1)uStack_50;
      local_1a8.Data4[1] = uStack_50._1_1_;
      local_1a8.Data4[2] = uStack_50._2_1_;
      local_1a8.Data4[3] = uStack_50._3_1_;
      puVar1 = GuidToString(&local_1a8);
      local_70 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_1a8.Data2 = (undefined2)uStack_44;
      local_1a8.Data3 = uStack_44._2_2_;
      local_1a8.Data1 = local_48;
      local_1a8.Data4[4] = (undefined1)uStack_3c;
      local_1a8.Data4[5] = uStack_3c._1_1_;
      local_1a8.Data4[6] = uStack_3c._2_1_;
      local_1a8.Data4[7] = uStack_3c._3_1_;
      local_1a8.Data4[0] = (undefined1)uStack_40;
      local_1a8.Data4[1] = uStack_40._1_1_;
      local_1a8.Data4[2] = uStack_40._2_1_;
      local_1a8.Data4[3] = uStack_40._3_1_;
      local_68 = puVar1;
      pv = GuidToString(&local_1a8);
      local_80 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      pwVar3 = L"";
      if (false) {
        pwVar3 = local_1d8;
      }
      local_78 = pv;
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002757,pwVar3,puVar1);
      if (pv != (ushort *)0x0) {
        CoTaskMemFree(pv);
      }
      local_78 = (ushort *)0x0;
      local_80 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                  ::_vftable_;
      if (puVar1 != (ushort *)0x0) {
        CoTaskMemFree(puVar1);
      }
      local_68 = (ushort *)0x0;
      local_70 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                  ::_vftable_;
      Ordinal_6(0);
      uVar4 = uVar4 + 1;
    } while (uVar4 < local_1b0[0]);
    uVar5 = 0;
  }
  local_190 = (**(code **)(*local_1c8 + 0x90))();
  if (local_190 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_128,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListWriters",0x46f,7,_Var6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
  }
  *(undefined4 *)(this + 0x48) = uVar5;
  if (local_1c0 != (longlong *)0x0) {
    (**(code **)(*local_1c0 + 0x10))();
  }
  if (local_1c8 != (longlong *)0x0) {
    (**(code **)(*local_1c8 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_198);
  return;
}



/* ==========================================================================
 * ?ListProviders@CVssAdminCLI@@AEAAXXZ @ 0x140007e44  (1128 bytes, 253 instructions)
 * void ?ListProviders@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ListProviders(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListProviders(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListProviders_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  wchar_t *pv;
  LPVOID pv_00;
  ushort *puVar1;
  ushort *pv_01;
  undefined4 uVar2;
  uint uVar3;
  wchar_t *pwVar4;
  undefined1 auStackY_288 [32];
  _VSSDBG_SEV_ENUM _Var5;
  longlong **pplVar6;
  undefined1 local_248 [8];
  longlong *local_240;
  longlong *local_238 [2];
  undefined1 local_228 [16];
  undefined1 local_218 [16];
  undefined **local_208;
  LPVOID local_200;
  wchar_t *local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  undefined4 local_1e0;
  undefined4 local_1dc;
  undefined4 local_1d8;
  undefined1 local_1d0 [120];
  undefined4 local_158;
  undefined8 local_150;
  _GUID local_148;
  CVssFunctionTracer local_138 [8];
  int local_130;
  undefined1 local_c8 [8];
  _GUID local_c0;
  wchar_t *local_b0;
  int local_a8;
  LPVOID local_a0;
  ulonglong local_38;
  
  local_150 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_288;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::ListProviders";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x478;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_138);
  local_238[0] = (longlong *)0x0;
  local_228 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_218 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::ListProviders";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x483;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  pplVar6 = local_238;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_138,&local_1f8,local_218,L"Coordinator");
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListProviders",0x48a,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_240 = (longlong *)0x0;
  local_228 = ZEXT816(0);
  local_130 = (**(code **)(*local_238[0] + 0x50))(local_238[0],local_228,1,4);
  if (-1 < local_130) {
    local_130 = (**(code **)(*local_240 + 0x18))(local_240,1,local_c8,local_248);
    _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
    if (-1 < local_130) {
      uVar2 = 1;
      do {
        if (local_130 == 1) {
          *(undefined4 *)(this + 0x48) = uVar2;
          if (local_240 != (longlong *)0x0) {
            (**(code **)(*local_240 + 0x10))();
          }
          if (local_238[0] != (longlong *)0x0) {
            (**(code **)(*local_238[0] + 0x10))();
          }
          CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
          return;
        }
        if (local_a8 == 1) {
          uVar3 = 0x67;
        }
        else if (local_a8 == 2) {
          uVar3 = 0x68;
        }
        else if (local_a8 == 3) {
          uVar3 = 0x69;
        }
        else if (local_a8 == 4) {
          uVar3 = 0x7a;
        }
        else {
          uVar3 = 0x6a;
        }
        puVar1 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,uVar3);
        local_148.Data1 = local_c0.Data1;
        local_148.Data2 = local_c0.Data2;
        local_148.Data3 = local_c0.Data3;
        local_148.Data4[0] = local_c0.Data4[0];
        local_148.Data4[1] = local_c0.Data4[1];
        local_148.Data4[2] = local_c0.Data4[2];
        local_148.Data4[3] = local_c0.Data4[3];
        local_148.Data4[4] = local_c0.Data4[4];
        local_148.Data4[5] = local_c0.Data4[5];
        local_148.Data4[6] = local_c0.Data4[6];
        local_148.Data4[7] = local_c0.Data4[7];
        pv_01 = GuidToString(&local_148);
        pv_00 = local_a0;
        pv = local_b0;
        local_228._8_8_ = pv_01;
        local_228._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_218._8_8_ = local_b0;
        local_218._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        local_200 = local_a0;
        local_208 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        pwVar4 = L"";
        if (local_b0 != (wchar_t *)0x0) {
          pwVar4 = local_b0;
        }
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002756,pwVar4,puVar1);
        if (pv_00 != (LPVOID)0x0) {
          CoTaskMemFree(pv_00);
        }
        local_200 = (LPVOID)0x0;
        local_208 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                     ::_vftable_;
        if (pv != (wchar_t *)0x0) {
          CoTaskMemFree(pv);
        }
        local_218 = ZEXT816(0x140017068);
        if (pv_01 != (ushort *)0x0) {
          CoTaskMemFree(pv_01);
        }
        local_228 = ZEXT816(0x140017068);
        local_130 = (**(code **)(*local_240 + 0x18))(local_240,1,local_c8,local_248);
        _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
        uVar2 = 0;
      } while (-1 < local_130);
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListProviders",0x49d,7,_Var5);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1f8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdminCLI::ListProviders",0x493,7,(_VSSDBG_SEV_ENUM)pplVar6);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
}



/* ==========================================================================
 * ?ListVolumes@CVssAdminCLI@@AEAAXXZ @ 0x1400082b8  (1056 bytes, 231 instructions)
 * void ?ListVolumes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ListVolumes(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ListVolumes(void) __ptr64 */

void __thiscall CVssAdminCLI::_ListVolumes_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  uchar auVar1 [8];
  LPVOID pv;
  long lVar2;
  ushort *puVar3;
  undefined8 uVar4;
  CVssAdminCLI *this_00;
  undefined1 auStackY_228 [32];
  _VSSDBG_SEV_ENUM _Var5;
  longlong **pplVar6;
  undefined1 local_1e8 [8];
  longlong *local_1e0;
  longlong *local_1d8 [2];
  _GUID local_1c8;
  undefined1 local_1b8 [16];
  wchar_t *local_1a8;
  wchar_t *local_1a0;
  wchar_t *local_198;
  undefined4 local_190;
  undefined4 local_18c;
  undefined4 local_188;
  undefined1 local_180 [120];
  undefined4 local_108;
  CVssFunctionTracer local_f8 [8];
  int local_f0;
  undefined8 local_88;
  undefined1 local_80 [8];
  uchar local_78 [8];
  LPVOID local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_88 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_228;
  local_1a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1a0 = L"CVssAdminCLI::ListVolumes";
  local_198 = L"ADMPROCC";
  local_190 = 0x4ce;
  local_18c = 7;
  local_188 = 0xff;
  local_108 = 0x1000000;
  memset(local_180,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_f8,&local_1a8);
  if ((dCurrentSKU & 0xfffffff8) == 0) {
    lVar2 = 0x1d;
  }
  else {
    this_00 = this;
    puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xd);
    lVar2 = _DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(this_00,puVar3);
  }
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  local_1d8[0] = (longlong *)0x0;
  local_1c8 = (_GUID)_GUID_fa7df749_66e7_4986_a27f_e2f04ae53772;
  local_1b8 = (undefined1  [16])_GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
  local_1a8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1a0 = L"CVssAdminCLI::ListVolumes";
  local_198 = L"ADMPROCC";
  local_190 = 0x4df;
  local_18c = 7;
  local_188 = 0xff;
  local_108 = 0x1000000;
  memset(local_180,0,0x78);
  pplVar6 = local_1d8;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_f8,&local_1a8,local_1b8,L"VssSnapshotMgmt");
  auVar1 = local_48.Data4;
  if (local_f0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1a8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListVolumes",0x4e6,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
  }
  local_1e0 = (longlong *)0x0;
  local_1c8.Data4[0] = local_48.Data4[0];
  local_1c8.Data4[1] = local_48.Data4[1];
  local_1c8.Data4[2] = local_48.Data4[2];
  local_1c8.Data4[3] = local_48.Data4[3];
  local_1c8.Data1 = local_48.Data1;
  local_1c8.Data2 = local_48.Data2;
  local_1c8.Data3 = local_48.Data3;
  local_1c8.Data4[4] = local_48.Data4[4];
  local_1c8.Data4[5] = local_48.Data4[5];
  local_1c8.Data4[6] = local_48.Data4[6];
  local_1c8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar1;
  local_f0 = (**(code **)(*local_1d8[0] + 0x20))(local_1d8[0],&local_1c8,lVar2,&local_1e0);
  if (local_f0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1a8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ListVolumes",0x4f1,7,(_VSSDBG_SEV_ENUM)pplVar6);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
  }
  if (local_f0 != 1) {
    local_f0 = (**(code **)(*local_1e0 + 0x18))(local_1e0,1,local_80,local_1e8);
    _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
    auVar1 = local_78;
    pv = local_70;
    while( true ) {
      if (local_f0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1a8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListVolumes",0x504,7,_Var5);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_f8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_f8);
      }
      if (local_f0 == 1) break;
      local_1c8.Data4[0] = auVar1[0];
      local_1c8.Data4[1] = auVar1[1];
      local_1c8.Data4[2] = auVar1[2];
      local_1c8.Data4[3] = auVar1[3];
      local_1c8.Data4[4] = auVar1[4];
      local_1c8.Data4[5] = auVar1[5];
      local_1c8.Data4[6] = auVar1[6];
      local_1c8.Data4[7] = auVar1[7];
      local_1c8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_1b8._8_8_ = pv;
      local_1b8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      local_78 = auVar1;
      local_70 = pv;
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002759,pv,auVar1);
      if (pv != (LPVOID)0x0) {
        CoTaskMemFree(pv);
      }
      local_1b8 = ZEXT816(0x140017068);
      if (auVar1 != (uchar  [8])0x0) {
        CoTaskMemFree((LPVOID)auVar1);
      }
      local_1c8 = (_GUID)ZEXT816(0x140017068);
      local_f0 = (**(code **)(*local_1e0 + 0x18))(local_1e0,1,local_80,local_1e8);
      _Var5 = (_VSSDBG_SEV_ENUM)pplVar6;
      auVar1 = local_78;
      pv = local_70;
    }
    *(undefined4 *)(this + 0x48) = 0;
    if (local_1e0 != (longlong *)0x0) {
      (**(code **)(*local_1e0 + 0x10))();
    }
    if (local_1d8[0] != (longlong *)0x0) {
      (**(code **)(*local_1d8[0] + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_f8);
    return;
  }
  uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1a8,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ListVolumes",0x4f5,7,
                     (_VSSDBG_SEV_ENUM)pplVar6);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_f8,uVar4,1,L"CVssAdminCLI::ListVolumes: No volumes found that satisfy the query")
  ;
}



/* ==========================================================================
 * ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ @ 0x1400086e4  (647 bytes, 154 instructions)
 * void ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ResizeDiffArea(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::ResizeDiffArea(void) __ptr64 */

void __thiscall CVssAdminCLI::_ResizeDiffArea_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  ushort *puVar2;
  ushort *puVar3;
  CVssAdminCLI *this_00;
  EVssAdmOption EVar4;
  undefined1 auStackY_1c8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe68;
  IUnknown *local_188 [2];
  _GUID local_178;
  undefined8 local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  undefined4 local_148;
  undefined4 local_144;
  undefined4 local_140;
  undefined1 local_138 [120];
  undefined4 local_c0;
  CVssFunctionTracer local_b8 [8];
  ULONG local_b0;
  _GUID local_48;
  ulonglong local_38;
  
  local_168 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1c8;
  local_160 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_158 = L"CVssAdminCLI::ResizeDiffArea";
  local_150 = L"ADMPROCC";
  local_148 = 0x517;
  local_144 = 7;
  local_140 = 0xff;
  local_c0 = 0x1000000;
  memset(local_138,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_b8,&local_160);
  local_178.Data1 = 0;
  local_178.Data2 = 0;
  local_178.Data3 = 0;
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  puVar2 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  EVar4 = 7;
  puVar3 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  this_00 = this;
  iVar1 = _GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
                    (this,EVar4,(__int64 *)&local_178);
  if (iVar1 == 0) {
    _GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z(this,5,(__int64 *)&local_178,1);
  }
  else if (0 < (longlong)local_178._0_8_) {
    _GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(this_00,puVar2);
  }
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  (**(code **)(**(longlong **)this + 0x30))(*(longlong **)this,&local_178,puVar2,puVar3);
  local_188[0] = (IUnknown *)0x0;
  local_178.Data1 = local_48.Data1;
  local_178.Data2 = local_48.Data2;
  local_178.Data3 = local_48.Data3;
  local_178.Data4[0] = local_48.Data4[0];
  local_178.Data4[1] = local_48.Data4[1];
  local_178.Data4[2] = local_48.Data4[2];
  local_178.Data4[3] = local_48.Data4[3];
  local_178.Data4[4] = local_48.Data4[4];
  local_178.Data4[5] = local_48.Data4[5];
  local_178.Data4[6] = local_48.Data4[6];
  local_178.Data4[7] = local_48.Data4[7];
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_178,local_188);
  local_b0 = (*local_188[0]->lpVtbl[1].AddRef)(local_188[0]);
  if ((int)local_b0 < 0) {
    if (local_b0 != 0x80042308) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_160,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::ResizeDiffArea",0x53e,7,in_stack_fffffffffffffe68);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_b8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_b8);
    }
    _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
  }
  else {
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002750);
    *(undefined4 *)(this + 0x48) = 0;
  }
  if (local_188[0] != (IUnknown *)0x0) {
    (*local_188[0]->lpVtbl->Release)();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_b8);
  return;
}



/* ==========================================================================
 * ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ @ 0x140008974  (1439 bytes, 323 instructions)
 * void ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_RevertSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  uchar auVar1 [8];
  bool bVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  ushort *puVar6;
  undefined8 uVar7;
  CVssAdminCLI *pCVar8;
  undefined1 auStackY_268 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdc8;
  _VSSDBG_SEV_ENUM _Var9;
  char local_228 [8];
  CVssAdminCLI *local_220;
  _GUID local_218;
  _GUID local_208;
  wchar_t *local_1f8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  undefined4 local_1e0;
  undefined4 local_1dc;
  undefined4 local_1d8;
  undefined1 local_1d0 [120];
  undefined4 local_158;
  CVssFunctionTracer local_148 [8];
  int local_140;
  undefined8 local_d8;
  _GUID local_c8;
  undefined1 local_b8 [48];
  ushort *local_88;
  ulonglong local_38;
  
  local_d8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_268;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::RevertSnapshot";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x54d;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_148,&local_1f8);
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,4);
  local_c8.Data1 = 0;
  local_c8.Data2 = 0;
  local_c8.Data3 = 0;
  local_c8.Data4[0] = '\0';
  local_c8.Data4[1] = '\0';
  local_c8.Data4[2] = '\0';
  local_c8.Data4[3] = '\0';
  local_c8.Data4[4] = '\0';
  local_c8.Data4[5] = '\0';
  local_c8.Data4[6] = '\0';
  local_c8.Data4[7] = '\0';
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar6 != (ushort *)0x0) {
    pCVar8 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar2 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar8,puVar6,&local_c8);
    if (!bVar2) {
      uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_1f8,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x556,7,
                         in_stack_fffffffffffffdc8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar7,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  uVar4 = dCurrentSKU & 0xfffffff8;
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  local_220 = (CVssAdminCLI *)0x0;
  local_218 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_208 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_1f8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1f0 = L"CVssAdminCLI::RevertSnapshot";
  local_1e8 = L"ADMPROCC";
  local_1e0 = 0x565;
  local_1dc = 7;
  local_1d8 = 0xff;
  local_158 = 0x1000000;
  memset(local_1d0,0,0x78);
  _Var9 = (_VSSDBG_SEV_ENUM)&local_220;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_148,&local_1f8,&local_208,L"Coordinator");
  if (-1 < local_140) {
    local_140 = (**(code **)(*(longlong *)local_220 + 0x18))
                          (local_220,(-(uint)(uVar4 != 0) & 0xffffffe2) + 0x1d);
    auVar1 = local_c8.Data4;
    if (local_140 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1f8,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::RevertSnapshot",0x570,7,_Var9);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
    }
    local_208.Data4[0] = local_c8.Data4[0];
    local_208.Data4[1] = local_c8.Data4[1];
    local_208.Data4[2] = local_c8.Data4[2];
    local_208.Data4[3] = local_c8.Data4[3];
    local_208.Data1 = local_c8.Data1;
    local_208.Data2 = local_c8.Data2;
    local_208.Data3 = local_c8.Data3;
    local_208.Data4[4] = local_c8.Data4[4];
    local_208.Data4[5] = local_c8.Data4[5];
    local_208.Data4[6] = local_c8.Data4[6];
    local_208.Data4[7] = local_c8.Data4[7];
    local_c8.Data4 = auVar1;
    local_140 = (**(code **)(*(longlong *)local_220 + 0x38))(local_220,&local_208);
    local_208.Data4 = (uchar  [8])local_b8;
    local_208._0_8_ =
         &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
          ::_vftable_;
    if (local_140 < 0) {
      if (local_140 != -0x7ffbdcf8) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1f8,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x57e,7,_Var9);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
      }
      puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar6);
      VssFreeSnapshotPropertiesInternal(local_b8);
    }
    else {
      iVar5 = _PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z(this,0x40002776,0);
      if (iVar5 == 0) {
        VssFreeSnapshotPropertiesInternal(local_b8);
      }
      else {
        local_228[0] = '\0';
        local_140 = ShouldBlockRevertInternal(local_88,local_228);
        auVar1 = local_c8.Data4;
        if ((local_140 < 0) || (local_228[0] == '\0')) {
          local_218.Data4[0] = local_c8.Data4[0];
          local_218.Data4[1] = local_c8.Data4[1];
          local_218.Data4[2] = local_c8.Data4[2];
          local_218.Data4[3] = local_c8.Data4[3];
          local_218.Data1 = local_c8.Data1;
          local_218.Data2 = local_c8.Data2;
          local_218.Data3 = local_c8.Data3;
          local_218.Data4[4] = local_c8.Data4[4];
          local_218.Data4[5] = local_c8.Data4[5];
          local_218.Data4[6] = local_c8.Data4[6];
          local_218.Data4[7] = local_c8.Data4[7];
          pCVar8 = local_220;
          local_c8.Data4 = auVar1;
          local_140 = (**(code **)(*(longlong *)local_220 + 0x68))(local_220,&local_218,iVar3);
          if (local_140 < 0) {
            if (local_140 == -0x7ffbdcf8) {
              puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar6);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else if (local_140 == -0x7ffbdcf4) {
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else if (local_140 == -0x7ffbdce3) {
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002775);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
            else {
              if (local_140 != -0x7ffbdcdb) {
                CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_1f8,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                           (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x59f,7,
                           _Var9);
                CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
                CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                          (local_148);
              }
              _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002773);
              VssFreeSnapshotPropertiesInternal(local_b8);
            }
          }
          else {
            _WaitForRevertCompletion_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
                      (pCVar8,local_88,(IVssCoordinator *)local_220);
            _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002770);
            *(undefined4 *)(this + 0x48) = 0;
            VssFreeSnapshotPropertiesInternal(local_b8);
          }
        }
        else {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
      }
    }
    if (local_220 != (CVssAdminCLI *)0x0) {
      (**(code **)(*(longlong *)local_220 + 0x10))();
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
    return;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
            ((CVssDebugInfo *)&local_1f8,
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdminCLI::RevertSnapshot",0x56c,7,_Var9);
  CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
}



/* ==========================================================================
 * ?QueryReverts@CVssAdminCLI@@AEAAXXZ @ 0x140008f20  (952 bytes, 210 instructions)
 * void ?QueryReverts@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::QueryReverts(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::QueryReverts(void) __ptr64 */

void __thiscall CVssAdminCLI::_QueryReverts_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  code *pcVar1;
  DWORD DVar2;
  int iVar3;
  UINT UVar4;
  BOOL BVar5;
  DWORD DVar6;
  ushort *puVar7;
  HANDLE hFindVolume;
  undefined8 uVar8;
  undefined1 auStackY_3d8 [32];
  _VSSDBG_SEV_ENUM _Var9;
  IVssCoordinator **ppIVar10;
  IVssCoordinator *local_398 [2];
  GUID local_388;
  undefined1 local_378 [16];
  wchar_t *local_368;
  wchar_t *local_360;
  wchar_t *local_358;
  undefined4 local_350;
  undefined4 local_34c;
  undefined4 local_348;
  undefined1 local_340 [120];
  undefined4 local_2c8;
  undefined8 local_2c0;
  CVssFunctionTracer local_2b8 [8];
  int local_2b0;
  WCHAR local_248 [264];
  ulonglong local_38;
  
  local_2c0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_3d8;
  local_368 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_360 = L"CVssAdminCLI::QueryReverts";
  local_358 = L"ADMPROCC";
  local_350 = 0x5b1;
  local_34c = 7;
  local_348 = 0xff;
  local_2c8 = 0x1000000;
  memset(local_340,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_2b8,&local_368);
  puVar7 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,0);
  (**(code **)(**(longlong **)this + 0x40))(*(longlong **)this,puVar7,iVar3 == 1,local_2b8);
  local_398[0] = (IVssCoordinator *)0x0;
  local_388 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_378 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_368 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_360 = L"CVssAdminCLI::QueryReverts";
  local_358 = L"ADMPROCC";
  local_350 = 0x5be;
  local_34c = 7;
  local_348 = 0xff;
  local_2c8 = 0x1000000;
  memset(local_340,0,0x78);
  ppIVar10 = local_398;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_2b8,&local_368,local_378,L"Coordinator");
  if (local_2b0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_368,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::QueryReverts",0x5c5,7,(_VSSDBG_SEV_ENUM)ppIVar10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_2b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_2b8);
  }
  local_2b0 = (**(code **)(*(longlong *)local_398[0] + 0x18))(local_398[0],0xffffffff);
  if (local_2b0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_368,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::QueryReverts",0x5c9,7,(_VSSDBG_SEV_ENUM)ppIVar10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_2b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_2b8);
  }
  if (puVar7 == (ushort *)0x0) {
    hFindVolume = FindFirstVolumeW(local_248,0x104);
    local_378._8_8_ = hFindVolume;
    local_378._0_8_ =
         &CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
          ::_vftable_;
    if (hFindVolume == (HANDLE)0xffffffffffffffff) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_368,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::QueryReverts",0x5d5,7,
                         (_VSSDBG_SEV_ENUM)ppIVar10);
      CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
                (local_2b8,uVar8,L"FindFirstVolume");
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
    do {
      UVar4 = GetDriveTypeW(local_248);
      if (UVar4 == 3) {
        _QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
                  (this,(ushort *)local_248,local_398[0]);
      }
      BVar5 = FindNextVolumeW(hFindVolume,local_248,0x104);
      _Var9 = (_VSSDBG_SEV_ENUM)ppIVar10;
    } while (BVar5 != 0);
    DVar6 = GetLastError();
    if (DVar6 != 0x12) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_368,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::QueryReverts",0x5e1,7,_Var9
                        );
      DVar2 = DVar6 & 0xffff | 0x80070000;
      if ((int)DVar6 < 1) {
        DVar2 = DVar6;
      }
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
                (local_2b8,uVar8,DVar2,L"FindNextVolume");
    }
    *(undefined4 *)(this + 0x48) = 0;
    FindVolumeClose(hFindVolume);
  }
  else {
    _QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z(this,puVar7,local_398[0]);
    *(undefined4 *)(this + 0x48) = 0;
  }
  if (local_398[0] != (IVssCoordinator *)0x0) {
    (**(code **)(*(longlong *)local_398[0] + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_2b8);
  return;
}



/* ==========================================================================
 * ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z @ 0x1400092e4  (342 bytes, 82 instructions)
 * void ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2)
 * private: void __cdecl CVssAdminCLI::QueryRevert(unsigned short * __ptr64,struct IVssCoordinator * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: void __cdecl CVssAdminCLI::QueryRevert(unsigned short * __ptr64,struct IVssCoordinator *
   __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_QueryRevert_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
          (CVssAdminCLI *this,ushort *param_1,IVssCoordinator *param_2)

{
  int local_res18 [2];
  uint local_res20 [2];
  longlong *local_148;
  undefined8 local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [8];
  int local_80;
  
  local_140 = 0xfffffffffffffffe;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_130 = L"CVssAdminCLI::QueryRevert";
  local_128 = L"ADMPROCC";
  local_120 = 0x5e8;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_138);
  local_148 = (longlong *)0x0;
  local_80 = (**(code **)(*(longlong *)param_2 + 0x70))(param_2,param_1,&local_148);
  if (-1 < local_80) {
    local_res18[0] = 0;
    local_res20[0] = 0;
    local_80 = (**(code **)(*local_148 + 0x28))(local_148,local_res18,local_res20);
    if ((local_80 < 0) || (local_res18[0] < 0)) {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002772,param_1);
    }
    else {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002771,param_1,(ulonglong)local_res20[0]);
    }
  }
  if (local_148 != (longlong *)0x0) {
    (**(code **)(*local_148 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}



/* ==========================================================================
 * ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z @ 0x140009444  (758 bytes, 177 instructions)
 * void ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2)
 * private: void __cdecl CVssAdminCLI::WaitForRevertCompletion(unsigned short * __ptr64,struct IVssCoordinator * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::WaitForRevertCompletion(unsigned short * __ptr64,struct
   IVssCoordinator * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_WaitForRevertCompletion_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
          (CVssAdminCLI *this,ushort *param_1,IVssCoordinator *param_2)

{
  code *pcVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  wchar_t *pwVar7;
  undefined1 auStackY_228 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe08;
  int local_1e8 [2];
  longlong *local_1e0;
  int local_1d8 [4];
  undefined8 local_1c8;
  wchar_t *local_1c0;
  wchar_t *local_1b8;
  wchar_t *local_1b0;
  undefined4 local_1a8;
  undefined4 local_1a4;
  undefined4 local_1a0;
  undefined1 local_198 [120];
  undefined4 local_120;
  CVssFunctionTracer local_118 [8];
  int local_110;
  wchar_t local_a8 [56];
  ulonglong local_38;
  
  local_1c8 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_228;
  local_1c0 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1b8 = L"CVssAdminCLI::WaitForRevertCompletion";
  local_1b0 = L"ADMPROCC";
  local_1a8 = 0x5fa;
  local_1a4 = 7;
  local_1a0 = 0xff;
  iVar6 = 0;
  local_120 = 0x1000000;
  memset(local_198,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_118,&local_1c0);
  local_1e0 = (longlong *)0x0;
  local_110 = (**(code **)(*(longlong *)param_2 + 0x70))(param_2,param_1,&local_1e0);
  if (local_110 == -0x7ffbdcf8) {
    local_110 = -0x7ffbdcf8;
  }
  else {
    if (local_110 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1c0,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x602,7,
                 in_stack_fffffffffffffe08);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
    }
    do {
      Sleep(300);
      local_1e8[0] = 0;
      local_1d8[0] = 0;
      local_110 = (**(code **)(*local_1e0 + 0x28))(local_1e0,local_1d8,local_1e8);
      if (local_110 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_1c0,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x610,7,
                   in_stack_fffffffffffffe08);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
      }
      iVar4 = 100;
      if (local_1e8[0] < 0x65) {
        iVar4 = local_1e8[0];
      }
      if (local_1d8[0] == 0x4230a) {
        local_1e8[0] = 100;
      }
      else {
        local_1e8[0] = iVar4;
        if (local_1d8[0] != 0x42309) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1c0,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::WaitForRevertCompletion",0x616,
                     7,in_stack_fffffffffffffe08);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_118);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_118);
        }
      }
      uVar5 = local_1e8[0] - iVar6;
      if (1 < (int)uVar5) {
        lVar3 = (longlong)((int)uVar5 / 2);
        if ((int)uVar5 / 2 != 0) {
          pwVar7 = local_a8;
          for (lVar2 = lVar3; lVar2 != 0; lVar2 = lVar2 + -1) {
            *pwVar7 = L'.';
            pwVar7 = pwVar7 + 1;
          }
        }
        if (0x65 < (ulonglong)(lVar3 * 2)) {
          __report_rangecheckfailure();
          pcVar1 = (code *)swi(3);
          (*pcVar1)();
          return;
        }
        local_a8[lVar3] = L'\0';
        wprintf(local_a8);
        uVar5 = uVar5 & 0x80000001;
        if ((int)uVar5 < 0) {
          uVar5 = (uVar5 - 1 | 0xfffffffe) + 1;
        }
        iVar6 = local_1e8[0] - uVar5;
      }
    } while (iVar6 < 100);
    wprintf(L"\n");
  }
  if (local_1e0 != (longlong *)0x0) {
    (**(code **)(*local_1e0 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_118);
  return;
}



/* ==========================================================================
 * ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ @ 0x140009744  (1114 bytes, 266 instructions)
 * void ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::DeleteDiffAreas(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Exceeded maximum restarts with more pending */
/* private: void __cdecl CVssAdminCLI::DeleteDiffAreas(void) __ptr64 */

void __thiscall CVssAdminCLI::_DeleteDiffAreas_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  IID *riid;
  ushort *puVar2;
  uchar pv [8];
  undefined1 auStackY_218 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe18;
  IUnknown *local_1d8;
  longlong *local_1d0;
  _GUID local_1c8;
  undefined **local_1b8;
  ushort *local_1b0;
  undefined1 local_1a8 [8];
  undefined8 local_1a0;
  CVssFunctionTracer local_198 [8];
  ULONG local_190;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  undefined1 local_80 [8];
  LPVOID local_78;
  ushort *local_70;
  _GUID local_48;
  ulonglong local_38;
  
  local_1a0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_218;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_120 = L"CVssAdminCLI::DeleteDiffAreas";
  local_118 = L"ADMPROCC";
  local_110 = 0x62b;
  local_10c = 7;
  local_108 = 0xff;
  pv[0] = '\0';
  pv[1] = '\0';
  pv[2] = '\0';
  pv[3] = '\0';
  pv[4] = '\0';
  pv[5] = '\0';
  pv[6] = '\0';
  pv[7] = '\0';
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_198,&local_128);
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  _GetProviderId_CVssAdminCLI__AEAAXPEAU_GUID___Z(this,&local_48);
  riid = (IID *)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  puVar2 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,7);
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  local_1d8 = (IUnknown *)0x0;
  local_1c8.Data1 = local_48.Data1;
  local_1c8.Data2 = local_48.Data2;
  local_1c8.Data3 = local_48.Data3;
  local_1c8.Data4[0] = local_48.Data4[0];
  local_1c8.Data4[1] = local_48.Data4[1];
  local_1c8.Data4[2] = local_48.Data4[2];
  local_1c8.Data4[3] = local_48.Data4[3];
  local_1c8.Data4[4] = local_48.Data4[4];
  local_1c8.Data4[5] = local_48.Data4[5];
  local_1c8.Data4[6] = local_48.Data4[6];
  local_1c8.Data4[7] = local_48.Data4[7];
  _GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
            (this,&local_1c8,&local_1d8);
  local_1c8.Data4[0] = '\0';
  local_1c8.Data4[1] = '\0';
  local_1c8.Data4[2] = '\0';
  local_1c8.Data4[3] = '\0';
  local_1c8.Data4[4] = '\0';
  local_1c8.Data4[5] = '\0';
  local_1c8.Data4[6] = '\0';
  local_1c8.Data4[7] = '\0';
  local_1c8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (puVar2 == (ushort *)0x0) {
    local_1d0 = (longlong *)0x0;
    local_190 = (*local_1d8->lpVtbl[2].QueryInterface)(local_1d8,riid,&local_1d0);
    if ((int)local_190 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_128,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x648,7,in_stack_fffffffffffffe18);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
    }
    if (local_190 == 1) {
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
      if (local_1d0 != (longlong *)0x0) {
        (**(code **)(*local_1d0 + 0x10))();
      }
    }
    else {
      local_190 = (**(code **)(*local_1d0 + 0x18))(local_1d0,1,local_80,local_1a8);
      if ((int)local_190 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_128,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x658,7,
                   in_stack_fffffffffffffe18);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
      }
      if (local_190 != 1) {
        CoTaskMemFree(local_78);
        local_78 = (LPVOID)0x0;
        local_1b0 = local_70;
        local_1b8 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
        CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
        _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                  ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_1c8,local_70);
        pv = local_1c8.Data4;
        if (local_70 != (ushort *)0x0) {
          CoTaskMemFree(local_70);
        }
        if (local_1d0 != (longlong *)0x0) {
          (**(code **)(*local_1d0 + 0x10))();
        }
        goto LAB_1400099ba;
      }
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
      if (local_1d0 != (longlong *)0x0) {
        (**(code **)(*local_1d0 + 0x10))();
      }
    }
    if (local_1d8 != (IUnknown *)0x0) {
      (*local_1d8->lpVtbl->Release)();
    }
  }
  else {
LAB_1400099ba:
    local_190 = (*local_1d8->lpVtbl[1].AddRef)(local_1d8);
    if ((int)local_190 < 0) {
      if (local_190 == 0x80042308) {
        _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5e);
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
      }
      else {
        if (local_190 != 0x8004231d) {
          CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_128,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteDiffAreas",0x67e,7,
                     in_stack_fffffffffffffe18);
          CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_198);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_198);
        }
        _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b60);
        if (pv != (uchar  [8])0x0) {
          CoTaskMemFree((LPVOID)pv);
        }
      }
    }
    else {
      iVar1 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
      if (iVar1 == 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002751);
      }
      *(undefined4 *)(this + 0x48) = 0;
      if (pv != (uchar  [8])0x0) {
        CoTaskMemFree((LPVOID)pv);
      }
    }
    if (local_1d8 != (IUnknown *)0x0) {
      (*local_1d8->lpVtbl->Release)();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_198);
  return;
}



/* ==========================================================================
 * ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ @ 0x140009ba8  (463 bytes, 107 instructions)
 * void ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::DeleteSnapshots(void) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::DeleteSnapshots(void) __ptr64 */

void __thiscall CVssAdminCLI::_DeleteSnapshots_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  CVssAdminCLI *this_00;
  uint uVar4;
  bool local_res10 [8];
  uint local_res18 [2];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  void *local_158;
  undefined8 local_150;
  undefined8 local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  local_148 = 0xfffffffffffffffe;
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_138 = L"CVssAdminCLI::DeleteSnapshots";
  local_130 = L"ADMPROCC";
  local_128 = 0x68f;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  local_res18[0] = 0;
  local_res10[0] = false;
  local_158 = (void *)0x0;
  local_150 = 0;
  _FindSnapshotsForDeletion_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEA_N_Z
            (this,(CVssSimpleArray<_GUID> *)&local_158,local_res10);
  if ((ulong)local_150 != 0) {
    this_00 = this;
    iVar1 = _PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z(this,0x4000275b,(ulong)local_150);
    uVar4 = 0;
    if (iVar1 != 0) {
      _DeleteSnapshotsFromList_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEAJ_Z
                (this_00,(CVssSimpleArray<_GUID> *)&local_158,(long *)local_res18);
      uVar4 = local_res18[0];
    }
    iVar2 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
    if (((iVar2 == 0) && (iVar1 != 0)) && (0 < (int)uVar4)) {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275d,(ulonglong)uVar4);
    }
    *(undefined4 *)(this + 0x48) = 0;
    if (local_158 != (void *)0x0) {
      free(local_158);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return;
  }
  if (local_res10[0] == false) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_140,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshots",0x69d,7,
                       in_stack_fffffffffffffe98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar3,1,L"CVssAdminCLI: No snaphots found that satisfy the query");
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_140,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshots",0x69a,7,
                     in_stack_fffffffffffffe98);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar3,0x100b,
             L"CVssAdminCLI: Snapshots were found, but none were in the correct context");
}



/* ==========================================================================
 * ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ @ 0x140009d80  (47 bytes, 14 instructions)
 * void ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ(CVssSimpleArray<_GUID> * this)
 * public: __cdecl CVssSimpleArray<struct _GUID>::~CVssSimpleArray<struct _GUID>(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssSimpleArray<struct _GUID>::~CVssSimpleArray<struct _GUID>(void) __ptr64 */

void __thiscall
CVssSimpleArray<_GUID>::__1__CVssSimpleArray_U_GUID____QEAA_XZ(CVssSimpleArray<_GUID> *this)

{
  if (*(void **)this != (void *)0x0) {
    free(*(void **)this);
    *(undefined8 *)this = 0;
  }
  *(undefined4 *)(this + 8) = 0;
  *(undefined4 *)(this + 0xc) = 0;
  return;
}



/* ==========================================================================
 * ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z @ 0x140009db8  (2644 bytes, 560 instructions)
 * void ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, bool * param_2)
 * private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID> * __ptr64,bool * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID>
   * __ptr64,bool * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_FindSnapshotsForDeletion_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEA_N_Z
          (CVssAdminCLI *this,CVssSimpleArray<_GUID> *param_1,bool *param_2)

{
  undefined1 auVar1 [16];
  bool bVar2;
  int iVar3;
  BOOL BVar4;
  long lVar5;
  LPCWSTR lpszVolumeMountPoint;
  ushort *puVar6;
  void *pvVar7;
  undefined8 *puVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  CVssAdminCLI *this_00;
  longlong lVar11;
  longlong lVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined1 auStackY_3f8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc38;
  _VSSDBG_SEV_ENUM _Var18;
  longlong **pplVar19;
  int local_3a8 [4];
  undefined1 local_398 [16];
  GUID local_388;
  longlong *local_378;
  longlong *local_370;
  undefined1 local_368 [8];
  longlong local_360;
  longlong local_358;
  wchar_t *local_350;
  wchar_t *local_348;
  wchar_t *local_340;
  undefined4 local_338;
  undefined4 local_334;
  undefined4 local_330;
  undefined1 local_328 [120];
  undefined4 local_2b0;
  bool *local_2a8;
  CVssFunctionTracer local_298 [8];
  int local_290;
  undefined8 local_228;
  CVssDebugInfo local_220 [168];
  _GUID local_178;
  undefined1 local_168 [8];
  undefined4 local_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  wchar_t *local_130;
  long local_f8;
  longlong local_f0;
  WCHAR local_d8 [49];
  undefined2 local_76;
  long local_70;
  ulonglong local_58;
  
  local_228 = 0xfffffffffffffffe;
  local_58 = __security_cookie ^ (ulonglong)auStackY_3f8;
  local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_340 = L"ADMPROCC";
  local_338 = 0x6b0;
  local_334 = 7;
  local_330 = 0xff;
  local_2b0 = 0x1000000;
  local_2a8 = param_2;
  memset(local_328,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_298,&local_350);
  lpszVolumeMountPoint =
       (LPCWSTR)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  local_3a8[0] = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,6);
  lVar11 = (longlong)local_3a8[0];
  iVar3 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,0);
  lVar12 = (longlong)iVar3;
  uVar14 = 0;
  uVar15 = 0;
  uVar16 = 0;
  uVar17 = 0;
  local_178.Data1 = 0;
  local_178.Data2 = 0;
  local_178.Data3 = 0;
  local_178.Data4[0] = '\0';
  local_178.Data4[1] = '\0';
  local_178.Data4[2] = '\0';
  local_178.Data4[3] = '\0';
  local_178.Data4[4] = '\0';
  local_178.Data4[5] = '\0';
  local_178.Data4[6] = '\0';
  local_178.Data4[7] = '\0';
  local_360 = 0x7fffffffffffffff;
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar6 != (ushort *)0x0) {
    this_00 = this;
    puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar2 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar6,&local_178);
    if (!bVar2) {
      uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_350,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                          0x6be,7,in_stack_fffffffffffffc38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_298,uVar10,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  local_398._4_2_ = local_178.Data2;
  local_398._6_2_ = local_178.Data3;
  local_398._0_4_ = local_178.Data1;
  local_398[0xc] = local_178.Data4[4];
  local_398[0xd] = local_178.Data4[5];
  local_398[0xe] = local_178.Data4[6];
  local_398[0xf] = local_178.Data4[7];
  local_398[8] = local_178.Data4[0];
  local_398[9] = local_178.Data4[1];
  local_398[10] = local_178.Data4[2];
  local_398[0xb] = local_178.Data4[3];
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  (**(code **)(**(longlong **)this + 0x58))
            (*(longlong **)this,0xffffffff,lpszVolumeMountPoint,iVar3 == 1);
  local_378 = (longlong *)0x0;
  local_398 = (undefined1  [16])_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_388 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_340 = L"ADMPROCC";
  local_338 = 0x6c9;
  local_334 = 7;
  local_330 = 0xff;
  local_2b0 = 0x1000000;
  memset(local_328,0,0x78);
  pplVar19 = &local_378;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_298,&local_350,&local_388,L"Coordinator");
  if (local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_350,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d0,7,
               (_VSSDBG_SEV_ENUM)pplVar19);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  local_290 = (**(code **)(*local_378 + 0x18))();
  _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
  if (local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_350,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d5,7,_Var18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  if ((CONCAT44(local_178._4_4_,local_178.Data1) == 0) &&
     (CONCAT44(local_178.Data4._4_4_,local_178.Data4._0_4_) == 0)) {
    memset(local_d8,0,100);
    if (lpszVolumeMountPoint != (LPCWSTR)0x0) {
      if (*lpszVolumeMountPoint == L'\\') {
        lVar5 = StringCchCopyW((ushort *)local_d8,0x32,(ushort *)lpszVolumeMountPoint);
        local_350 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_348 = L"CVssAdminCLI::FindSnapshotsForDeletion";
        local_340 = L"ADMPROCC";
        local_338 = 0x701;
        local_334 = 7;
        local_330 = 0xff;
        local_2b0 = 0x1000000;
        local_290 = lVar5;
        memset(local_328,0,0x78);
        local_388._0_8_ = &local_350;
        if (lVar5 < 0) {
          uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                             (local_220,(CVssDebugInfo *)&local_350);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_298,uVar10,lVar5,L"StringCchCopy");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_350);
        local_76 = 0;
      }
      else {
        BVar4 = GetVolumeNameForVolumeMountPointW(lpszVolumeMountPoint,local_d8,0x32);
        if (BVar4 == 0) {
          uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_350,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",
                              (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6fa,1,
                              (_VSSDBG_SEV_ENUM)pplVar19);
          GetLastError();
          _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_298,uVar10,0x80042308,
                     L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx");
        }
      }
    }
    local_370 = (longlong *)0x0;
    local_398 = ZEXT816(0);
    local_290 = (**(code **)(*local_378 + 0x50))(local_378,local_398,1,3);
    if (local_290 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                 (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x70a,7,
                 (_VSSDBG_SEV_ENUM)pplVar19);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
    }
    local_290 = (**(code **)(*local_370 + 0x18))(local_370,1,local_168,local_368);
    _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
    if (-1 < local_290) {
      local_388._0_8_ = lVar12;
      local_358 = lVar11;
      do {
        if (local_290 == 1) {
          if ((local_3a8[0] != 0) &&
             ((CONCAT44(uVar15,uVar14) != 0 ||
              (auVar1._4_4_ = uVar15, auVar1._0_4_ = uVar14, auVar1._8_4_ = uVar16,
              auVar1._12_4_ = uVar17, auVar1._8_8_ != 0)))) {
            iVar3 = *(int *)(param_1 + 8);
            if (iVar3 + 1 < 1) goto LAB_14000a7b7;
            if (iVar3 == *(int *)(param_1 + 0xc)) {
              if ((0x3fffffff < iVar3) || (0x7ffffffffffffff < (ulonglong)(longlong)iVar3)) {
LAB_14000a7b7:
                local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
                _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
              }
              iVar13 = iVar3 * 2;
              if (*(int *)(param_1 + 0xc) == 0) {
                iVar13 = 1;
              }
              pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
              if (pvVar7 == (void *)0x0) goto LAB_14000a7b7;
              *(int *)(param_1 + 0xc) = iVar13;
              *(void **)param_1 = pvVar7;
            }
            *(int *)(param_1 + 8) = iVar3 + 1;
            puVar9 = (undefined4 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
            if (puVar9 != (undefined4 *)0x0) {
              *puVar9 = uVar14;
              puVar9[1] = uVar15;
              puVar9[2] = uVar16;
              puVar9[3] = uVar17;
            }
          }
          if (local_370 != (longlong *)0x0) {
            (**(code **)(*local_370 + 0x10))();
          }
          goto LAB_14000a4c4;
        }
        local_398._8_8_ = &local_160;
        local_398._0_8_ =
             &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
              ::_vftable_;
        iVar3 = _wcsicmp(local_130,local_d8);
        if ((iVar3 == 0) || ((lpszVolumeMountPoint == (LPCWSTR)0x0 && (lVar12 != 0)))) {
          iVar3 = IsCorrectContext(local_f8);
          if (iVar3 == 0) {
            *local_2a8 = true;
            goto LAB_14000a15a;
          }
          if (lVar11 != 0) {
            if (local_f0 < local_360) {
              local_360 = local_f0;
              uVar14 = local_160;
              uVar15 = uStack_15c;
              uVar16 = uStack_158;
              uVar17 = uStack_154;
            }
            goto LAB_14000a15a;
          }
          iVar3 = *(int *)(param_1 + 8);
          if (iVar3 + 1 < 1) goto LAB_14000a79d;
          if (iVar3 == *(int *)(param_1 + 0xc)) {
            if ((0x3fffffff < iVar3) || (0x7ffffffffffffff < (ulonglong)(longlong)iVar3)) {
LAB_14000a79d:
              local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
              _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
            }
            iVar13 = iVar3 * 2;
            if (*(int *)(param_1 + 0xc) == 0) {
              iVar13 = 1;
            }
            pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
            if (pvVar7 == (void *)0x0) goto LAB_14000a79d;
            *(int *)(param_1 + 0xc) = iVar13;
            *(void **)param_1 = pvVar7;
            lVar11 = local_358;
          }
          *(int *)(param_1 + 8) = iVar3 + 1;
          puVar8 = (undefined8 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
          if (puVar8 != (undefined8 *)0x0) {
            *puVar8 = CONCAT44(uStack_15c,local_160);
            puVar8[1] = CONCAT44(uStack_154,uStack_158);
          }
          VssFreeSnapshotPropertiesInternal(&local_160);
          lVar12 = local_388._0_8_;
        }
        else {
LAB_14000a15a:
          VssFreeSnapshotPropertiesInternal(&local_160);
        }
        local_398 = ZEXT816(0x140017068);
        local_290 = (**(code **)(*local_370 + 0x18))(local_370,1,local_168,local_368);
        _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
      } while (-1 < local_290);
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
               (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x715,7,
               _Var18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  local_398._4_2_ = local_178.Data2;
  local_398._6_2_ = local_178.Data3;
  local_398._0_4_ = local_178.Data1;
  local_398[0xc] = local_178.Data4[4];
  local_398[0xd] = local_178.Data4[5];
  local_398[0xe] = local_178.Data4[6];
  local_398[0xf] = local_178.Data4[7];
  local_398[8] = local_178.Data4[0];
  local_398[9] = local_178.Data4[1];
  local_398[10] = local_178.Data4[2];
  local_398[0xb] = local_178.Data4[3];
  local_290 = (**(code **)(*local_378 + 0x38))(local_378,local_398,local_d8);
  if (local_290 == -0x7ffbdcf8) {
    uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                       (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                        (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                        0x6e0,7,_Var18);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_298,uVar10,1,L"No snapshots were found with that ID");
  }
  iVar3 = IsCorrectContext(local_70);
  if (iVar3 == 0) {
    uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                       (local_220,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                        (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                        0x6e4,7,_Var18);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_298,uVar10,0x100b,
               L"Snapshot was found, but you cannot delete it in this context.");
  }
  VssFreeSnapshotPropertiesInternal(local_d8);
  iVar3 = *(int *)(param_1 + 8);
  if (0 < iVar3 + 1) {
    if (iVar3 != *(int *)(param_1 + 0xc)) {
LAB_14000a4a9:
      *(int *)(param_1 + 8) = iVar3 + 1;
      puVar8 = (undefined8 *)((longlong)iVar3 * 0x10 + *(longlong *)param_1);
      if (puVar8 != (undefined8 *)0x0) {
        *puVar8 = CONCAT44(local_178._4_4_,local_178.Data1);
        puVar8[1] = CONCAT44(local_178.Data4._4_4_,local_178.Data4._0_4_);
      }
LAB_14000a4c4:
      if (local_378 != (longlong *)0x0) {
        (**(code **)(*local_378 + 0x10))();
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_298);
      return;
    }
    if ((iVar3 < 0x40000000) && ((ulonglong)(longlong)iVar3 < 0x800000000000000)) {
      iVar13 = iVar3 * 2;
      if (*(int *)(param_1 + 0xc) == 0) {
        iVar13 = 1;
      }
      pvVar7 = realloc(*(void **)param_1,(longlong)iVar13 << 4);
      if (pvVar7 != (void *)0x0) {
        *(int *)(param_1 + 0xc) = iVar13;
        *(void **)param_1 = pvVar7;
        goto LAB_14000a4a9;
      }
    }
  }
  local_3a8[0] = -0x7ff8fff2;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_3a8,(ThrowInfo *)&_TI1J);
}



/* ==========================================================================
 * ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z @ 0x14000a820  (814 bytes, 181 instructions)
 * void ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, long * param_2)
 * private: void __cdecl CVssAdminCLI::DeleteSnapshotsFromList(class CVssSimpleArray<struct _GUID> * __ptr64,long * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::DeleteSnapshotsFromList(class CVssSimpleArray<struct _GUID> *
   __ptr64,long * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_DeleteSnapshotsFromList_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEAJ_Z
          (CVssAdminCLI *this,CVssSimpleArray<_GUID> *param_1,long *param_2)

{
  code *pcVar1;
  int iVar2;
  longlong *plVar3;
  GUID *pGVar4;
  uint uVar5;
  ulonglong uVar7;
  undefined1 auStackY_1e8 [32];
  longlong **pplVar8;
  longlong *local_1a0;
  GUID local_198;
  GUID local_188;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  undefined8 local_d0;
  CVssFunctionTracer local_c8 [8];
  int local_c0;
  undefined8 local_58;
  undefined8 uStack_50;
  ulonglong local_48;
  ulonglong uVar6;
  
  local_d0 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_1e8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::DeleteSnapshotsFromList";
  local_168 = L"ADMPROCC";
  local_160 = 0x747;
  local_15c = 7;
  local_158 = 0xff;
  uVar6 = 0;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8);
  local_58 = 0;
  uStack_50 = 0;
  local_1a0 = (longlong *)0x0;
  local_198 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_188 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::DeleteSnapshotsFromList";
  local_168 = L"ADMPROCC";
  local_160 = 0x752;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  pplVar8 = &local_1a0;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_c8,&local_178,&local_188,L"Coordinator");
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x759,7,(_VSSDBG_SEV_ENUM)pplVar8)
    ;
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  pGVar4 = (GUID *)0xffffffff;
  plVar3 = local_1a0;
  local_c0 = (**(code **)(*local_1a0 + 0x18))();
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x75e,7,(_VSSDBG_SEV_ENUM)pplVar8)
    ;
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  iVar2 = *(int *)(param_1 + 8);
  uVar7 = uVar6;
  if (0 < iVar2) {
    do {
      if (((longlong)uVar7 < 0) || (iVar2 <= (int)uVar6)) {
        ATL::__AtlRaiseException_ATL__YAXKK_Z((ulong)plVar3,(ulong)pGVar4);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
      }
      local_188 = *(GUID *)(uVar7 + *(longlong *)param_1);
      pGVar4 = &local_188;
      plVar3 = local_1a0;
      local_c0 = (**(code **)(*local_1a0 + 0x58))(local_1a0,pGVar4,3);
      if (local_c0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_178,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshotsFromList",0x76a,7,
                   (_VSSDBG_SEV_ENUM)pplVar8);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
      }
      uVar5 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar5;
      iVar2 = *(int *)(param_1 + 8);
      uVar7 = uVar7 + 0x10;
    } while ((int)uVar5 < iVar2);
  }
  *param_2 = 0;
  if (local_1a0 != (longlong *)0x0) {
    (**(code **)(*local_1a0 + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
  return;
}



/* ==========================================================================
 * ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ @ 0x14000ab58  (1176 bytes, 262 instructions)
 * void ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * private: void __cdecl CVssAdminCLI::ExposeSnapshot(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::ExposeSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_ExposeSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  _GUID _Var1;
  uchar auVar2 [8];
  bool bVar3;
  ushort *puVar4;
  ushort *puVar5;
  ushort *puVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  CVssAdminCLI *this_00;
  int iVar9;
  undefined1 auStackY_1f8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe38;
  _VSSDBG_SEV_ENUM _Var10;
  longlong *local_1b8 [2];
  _GUID local_1a8;
  uchar local_198 [8];
  _GUID local_188;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  CVssFunctionTracer local_c8 [8];
  int local_c0;
  undefined8 local_58;
  _GUID local_48;
  ulonglong local_38;
  
  local_58 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1f8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::ExposeSnapshot";
  local_168 = L"ADMPROCC";
  local_160 = 0x777;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8,&local_178);
  puVar4 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,2);
  puVar5 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xb);
  iVar9 = 1;
  if (puVar4 != (ushort *)0x0) {
    uVar8 = 0xffffffffffffffff;
    do {
      uVar8 = uVar8 + 1;
    } while (puVar4[uVar8] != 0);
    if ((1 < uVar8) && (puVar4[1] == 0x3a)) {
      iVar9 = 0;
    }
  }
  local_48.Data1 = 0;
  local_48.Data2 = 0;
  local_48.Data3 = 0;
  local_48.Data4[0] = '\0';
  local_48.Data4[1] = '\0';
  local_48.Data4[2] = '\0';
  local_48.Data4[3] = '\0';
  local_48.Data4[4] = '\0';
  local_48.Data4[5] = '\0';
  local_48.Data4[6] = '\0';
  local_48.Data4[7] = '\0';
  this_00 = this;
  puVar6 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  bVar3 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar6,&local_48);
  auVar2 = local_48.Data4;
  if (!bVar3) {
    uVar7 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_178,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ExposeSnapshot",0x788,7,
                       in_stack_fffffffffffffe38);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_c8,uVar7,0x1004,L"CVssAdminCLI::ExposeSnapshot: Invalid snapshot id");
  }
  local_1a8.Data4[0] = local_48.Data4[0];
  local_1a8.Data4[1] = local_48.Data4[1];
  local_1a8.Data4[2] = local_48.Data4[2];
  local_1a8.Data4[3] = local_48.Data4[3];
  local_1a8.Data1 = local_48.Data1;
  local_1a8.Data2 = local_48.Data2;
  local_1a8.Data3 = local_48.Data3;
  local_1a8.Data4[4] = local_48.Data4[4];
  local_1a8.Data4[5] = local_48.Data4[5];
  local_1a8.Data4[6] = local_48.Data4[6];
  local_1a8.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  (**(code **)(**(longlong **)this + 0x60))(*(longlong **)this,&local_1a8,puVar4,puVar5);
  local_1b8[0] = (longlong *)0x0;
  local_1a8 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_188 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_170 = L"CVssAdminCLI::ExposeSnapshot";
  local_168 = L"ADMPROCC";
  local_160 = 0x799;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  _Var10 = (_VSSDBG_SEV_ENUM)local_1b8;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_c8,&local_178,&local_188,L"Coordinator");
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7a0,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  local_c0 = (**(code **)(*local_1b8[0] + 0x18))(local_1b8[0],0xffffffff);
  auVar2 = local_48.Data4;
  if (local_c0 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_178,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7a7,7,_Var10);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
  }
  local_198[0] = '\0';
  local_198[1] = '\0';
  local_198[2] = '\0';
  local_198[3] = '\0';
  local_198[4] = '\0';
  local_198[5] = '\0';
  local_198[6] = '\0';
  local_198[7] = '\0';
  local_188.Data4[0] = local_48.Data4[0];
  local_188.Data4[1] = local_48.Data4[1];
  local_188.Data4[2] = local_48.Data4[2];
  local_188.Data4[3] = local_48.Data4[3];
  local_188.Data1 = local_48.Data1;
  local_188.Data2 = local_48.Data2;
  local_188.Data3 = local_48.Data3;
  local_188.Data4[4] = local_48.Data4[4];
  local_188.Data4[5] = local_48.Data4[5];
  local_188.Data4[6] = local_48.Data4[6];
  local_188.Data4[7] = local_48.Data4[7];
  local_48.Data4 = auVar2;
  local_c0 = (**(code **)(*local_1b8[0] + 0x40))
                       (local_1b8[0],&local_188,puVar5,(iVar9 + 1) * 0x100000);
  auVar2 = local_198;
  if (local_c0 < 0) {
    if (local_c0 == -0x7ffbdcf8) {
      puVar4 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar4);
    }
    else if (local_c0 == -0x7ffbdcf3) {
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002bc9);
    }
    else {
      if (local_c0 != -0x7ff8ffa9) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_178,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::ExposeSnapshot",0x7be,7,_Var10);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_c8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_c8);
      }
      _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002bc8);
    }
    if (local_1b8[0] != (longlong *)0x0) {
      (**(code **)(*local_1b8[0] + 0x10))();
    }
  }
  else {
    local_1a8.Data4[0] = local_198[0];
    local_1a8.Data4[1] = local_198[1];
    local_1a8.Data4[2] = local_198[2];
    local_1a8.Data4[3] = local_198[3];
    local_1a8.Data4[4] = local_198[4];
    local_1a8.Data4[5] = local_198[5];
    local_1a8.Data4[6] = local_198[6];
    local_1a8.Data4[7] = local_198[7];
    local_1a8._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    _Var1 = local_1a8;
    local_1a8.Data4._0_4_ = local_198._0_4_;
    local_1a8.Data4._4_4_ = local_198._4_4_;
    local_188.Data4[0] = local_1a8.Data4[0];
    local_188.Data4[1] = local_1a8.Data4[1];
    local_188.Data4[2] = local_1a8.Data4[2];
    local_188.Data4[3] = local_1a8.Data4[3];
    local_188._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    local_188.Data4[4] = local_1a8.Data4[4];
    local_188.Data4[5] = local_1a8.Data4[5];
    local_188.Data4[6] = local_1a8.Data4[6];
    local_188.Data4[7] = local_1a8.Data4[7];
    local_1a8 = _Var1;
    _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275e,&local_188);
    *(undefined4 *)(this + 0x48) = 0;
    if (auVar2 != (uchar  [8])0x0) {
      CoTaskMemFree((LPVOID)auVar2);
    }
    if (local_1b8[0] != (longlong *)0x0) {
      (**(code **)(*local_1b8[0] + 0x10))();
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
  return;
}



/* ==========================================================================
 * ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z @ 0x14000affc  (578 bytes, 144 instructions)
 * ushort * ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z(CVssAdminCLI * this, ulong param_1)
 * private: unsigned short * __ptr64 __cdecl CVssAdminCLI::BuildSnapshotAttributeDisplayString(unsigned long) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short * __ptr64 __cdecl
   CVssAdminCLI::BuildSnapshotAttributeDisplayString(unsigned long) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_BuildSnapshotAttributeDisplayString_CVssAdminCLI__AEAAPEAGK_Z
          (CVssAdminCLI *this,ulong param_1)

{
  uint uVar1;
  ushort uVar2;
  __uint64 _Var3;
  long lVar4;
  undefined1 auStackY_998 [32];
  ushort *in_stack_fffffffffffff690;
  ushort *local_968;
  undefined8 local_960;
  wchar_t *local_958;
  wchar_t *local_950;
  wchar_t *local_948;
  undefined4 local_940;
  undefined4 local_93c;
  undefined4 local_938;
  undefined1 local_930 [120];
  undefined4 local_8b8;
  CVssFunctionTracer local_8a8 [112];
  ushort local_838 [1024];
  ulonglong local_38;
  
  local_960 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_998;
  local_958 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_950 = L"CVssAdminCLI::BuildSnapshotAttributeDisplayString";
  local_948 = L"ADMPROCC";
  local_940 = 1999;
  local_93c = 7;
  local_938 = 0xff;
  local_8b8 = 0x1000000;
  memset(local_930,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_8a8);
  _Var3 = 0x800;
  memset(local_838,0,0x800);
  uVar2 = 0;
  do {
    uVar1 = 1 << ((byte)uVar2 & 0x1f) & param_1;
    if (uVar1 < 0x10001) {
      if (uVar1 == 0x10000) {
        lVar4 = 0x40002a9b;
LAB_14000b1b0:
        uVar1 = 0;
        goto LAB_14000b1b5;
      }
      if (uVar1 != 0) {
        if (uVar1 == 1) {
          lVar4 = 0x40002a94;
        }
        else if (uVar1 == 4) {
          lVar4 = 0x40002a96;
        }
        else if (uVar1 == 8) {
          lVar4 = 0x40002a97;
        }
        else if (uVar1 == 0x10) {
          lVar4 = 0x40002a98;
        }
        else if (uVar1 == 0x20) {
          lVar4 = 0x40002a99;
        }
        else {
          if (uVar1 != 0x40) goto LAB_14000b171;
          lVar4 = 0x40002a9a;
        }
        goto LAB_14000b1b0;
      }
    }
    else {
      if (uVar1 == 0x20000) {
        lVar4 = 0x40002a9c;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x40000) {
        lVar4 = 0x40002a9d;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x80000) {
        lVar4 = 0x40002a9e;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x100000) {
        lVar4 = 0x40002a9f;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x200000) {
        lVar4 = 0x40002aa0;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x400000) {
        lVar4 = 0x40002b0a;
        goto LAB_14000b1b0;
      }
      if (uVar1 == 0x800000) {
        lVar4 = 0x40002b0b;
        goto LAB_14000b1b0;
      }
LAB_14000b171:
      lVar4 = 0;
LAB_14000b1b5:
      _AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
                (this,local_838,_Var3,lVar4,uVar1,in_stack_fffffffffffff690);
    }
    uVar2 = uVar2 + 1;
    if (0x1f < uVar2) {
      if (local_838[0] == 0) {
        _AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
                  (this,local_838,_Var3,0x40002aa1,0,in_stack_fffffffffffff690);
      }
      local_968 = (ushort *)0x0;
      VssSafeDuplicateStr(local_8a8,&local_968,local_838);
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_8a8);
      return local_968;
    }
  } while( true );
}



/* ==========================================================================
 * ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z @ 0x14000b248  (388 bytes, 94 instructions)
 * long ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * private: long __cdecl CVssAdminCLI::DetermineSnapshotType(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* private: long __cdecl CVssAdminCLI::DetermineSnapshotType(unsigned short const * __ptr64) __ptr64
    */

long __thiscall
CVssAdminCLI::_DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_138 = L"CVssAdminCLI::DetermineSnapshotType";
  local_130 = L"ADMPROCC";
  local_128 = 0x82c;
  local_124 = 7;
  local_120 = 0xff;
  uVar4 = 0;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  if ((param_1 == (ushort *)0x0) || (*param_1 == 0)) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    lVar2 = -1;
  }
  else {
    uVar6 = 0;
    uVar5 = uVar4;
    uVar7 = uVar4;
    if (true) {
      do {
        uVar6 = (uint)uVar7;
        if (((dCurrentSKU & *(uint *)((longlong)&DAT_1400171f8 + uVar4)) != 0) &&
           (iVar1 = _wcsicmp((wchar_t *)param_1,*(wchar_t **)((longlong)&g_asAdmTypeNames + uVar4)),
           iVar1 == 0)) break;
        uVar6 = uVar6 + 1;
        uVar5 = uVar5 + 1;
        uVar4 = uVar5 * 0x18;
        uVar7 = (ulonglong)uVar6;
      } while ((&g_asAdmTypeNames)[uVar5 * 3] != (undefined *)0x0);
    }
    if ((&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3] == (undefined *)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_140,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DetermineSnapshotType",
                         0x844,7,in_stack_fffffffffffffea8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_98,uVar3,0x1004,L"DetermineSnapshotType: Invalid type specified: %s",param_1)
      ;
    }
    lVar2 = (&DAT_1400171fc)[(longlong)(int)uVar6 * 6];
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  }
  return lVar2;
}



/* ==========================================================================
 * ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z @ 0x14000b3d4  (494 bytes, 115 instructions)
 * ushort * ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z(CVssAdminCLI * this, long param_1)
 * private: unsigned short * __ptr64 __cdecl CVssAdminCLI::DetermineSnapshotType(long) __ptr64
 * ========================================================================== */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::DetermineSnapshotType(long) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_DetermineSnapshotType_CVssAdminCLI__AEAAPEAGJ_Z(CVssAdminCLI *this,long param_1)

{
  DWORD DVar1;
  ulonglong uVar2;
  ushort *puVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  uint uVar6;
  ushort *local_res18 [2];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  undefined8 local_a0;
  CVssFunctionTracer local_98 [112];
  ulonglong uVar7;
  
  local_a0 = 0xfffffffffffffffe;
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::DetermineSnapshotType";
  local_138 = L"ADMPROCC";
  local_130 = 0x853;
  local_12c = 7;
  local_128 = 0xff;
  uVar2 = 0;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  local_res18[0] = (ushort *)0x0;
  uVar6 = 0;
  if (true) {
    uVar5 = uVar2;
    uVar7 = uVar2;
    do {
      uVar6 = (uint)uVar7;
      if (*(uint *)((longlong)&DAT_1400171fc + uVar2) == (param_1 & 0x1fU)) break;
      uVar6 = uVar6 + 1;
      uVar7 = (ulonglong)uVar6;
      uVar5 = uVar5 + 1;
      uVar2 = uVar5 * 0x18;
    } while ((&g_asAdmTypeNames)[uVar5 * 3] != (undefined *)0x0);
  }
  if ((ushort *)(&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3] == (ushort *)0x0) {
    local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
    local_140 = L"CVssAdminCLI::DetermineSnapshotType";
    local_138 = L"ADMPROCC";
    local_130 = 0x863;
    local_12c = 7;
    local_128 = 0xff;
    local_a8 = 0x1000000;
    memset(local_120,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_98,&local_148,
               L"DetermineSnapshotType: Invalid context in lSnapshotAttributes: 0x%08x",param_1);
    puVar3 = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x40002713);
    if (puVar3 == (ushort *)0x0) {
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_148,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DetermineSnapshotType",
                         0x868,7,in_stack_fffffffffffffea8);
      DVar1 = GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_98,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx",
                 0x40002713,DVar1);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    local_res18[0] = puVar3;
  }
  else {
    VssSafeDuplicateStr(local_98,local_res18,(ushort *)(&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3]
                       );
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  }
  return local_res18[0];
}



/* ==========================================================================
 * ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ @ 0x14000b5cc  (62 bytes, 16 instructions)
 * void ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this)
 * public: virtual __cdecl CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >::~CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void *
   __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void *
   __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64
   __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >::~CVssAuto<void *
   __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int
   __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 &
   __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void *
   __ptr64 & __ptr64)> >(void) __ptr64 */

void __thiscall
CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
::
__1__CVssAuto_PEAXV__CVssAutoGenericValue_Storage_PEAX_0_0P6AHPEAX_Z_1_FindVolumeClose__YAH0_ZP6AAEAPEAXAEAPEAX_Z_1_Identity___DTyper_PEAX__SAAEAPEAX1_Z____UEAA_XZ
          (CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,_1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
           *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(HANDLE *)(this + 8) != (HANDLE)0xffffffffffffffff) {
    FindVolumeClose(*(HANDLE *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0xffffffffffffffff;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}



/* ==========================================================================
 * ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ @ 0x14000b614  (61 bytes, 16 instructions)
 * void ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this)
 * public: virtual __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >::~CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >::~CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >(void) __ptr64 */

void __thiscall
CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
::
__1__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAA_XZ
          (CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
           *this)

{
  *(undefined ***)this = &_vftable_;
  if (*(longlong *)(this + 8) != 0) {
    VssFreeSnapshotPropertiesInternal();
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}



/* ==========================================================================
 * ??_E?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAAPEAXI@Z @ 0x14000b660  (90 bytes, 24 instructions)
 * void * ??_E?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl CVssAuto<void * __ptr64,class CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 & __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void * __ptr64 & __ptr64)> >::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl CVssAuto<void * __ptr64,class
   CVssAutoGenericValue_Storage<void * __ptr64,-1,int (__cdecl*)(void * __ptr64),&int __cdecl
   FindVolumeClose(void * __ptr64),void * __ptr64 & __ptr64 (__cdecl*)(void * __ptr64 &
   __ptr64),&public: static void * __ptr64 & __ptr64 __cdecl DTyper<void * __ptr64>::Identity(void *
   __ptr64 & __ptr64)> >::`vector deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
::
___E__CVssAuto_PEAXV__CVssAutoGenericValue_Storage_PEAX_0_0P6AHPEAX_Z_1_FindVolumeClose__YAH0_ZP6AAEAPEAXAEAPEAX_Z_1_Identity___DTyper_PEAX__SAAEAPEAX1_Z____UEAAPEAXI_Z
          (CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,_1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
           *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  if (*(HANDLE *)(this + 8) != (HANDLE)0xffffffffffffffff) {
    FindVolumeClose(*(HANDLE *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0xffffffffffffffff;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z @ 0x14000b6d0  (89 bytes, 24 instructions)
 * void * ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >::`scalar deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >::`scalar deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
::
___G__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAAPEAXI_Z
          (CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
           *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  if (*(longlong *)(this + 8) != 0) {
    VssFreeSnapshotPropertiesInternal();
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ?_AtlRaiseException@ATL@@YAXKK@Z @ 0x14000b730  (22 bytes, 5 instructions)
 * void ?_AtlRaiseException@ATL@@YAXKK@Z(ulong param_1, ulong param_2)
 * void __cdecl ATL::_AtlRaiseException(unsigned long,unsigned long)
 * ========================================================================== */

/* void __cdecl ATL::_AtlRaiseException(unsigned long,unsigned long) */

void __cdecl ATL::__AtlRaiseException_ATL__YAXKK_Z(ulong param_1,ulong param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00014000b73f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  RaiseException(0xc000008c,1,0);
  return;
}



/* ==========================================================================
 * ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z @ 0x14000b754  (176 bytes, 39 instructions)
 * int ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1)
 * private: int __cdecl CVssAdminCLI::GetOptionValueBool(enum EVssAdmOption) __ptr64
 * ========================================================================== */

/* private: int __cdecl CVssAdminCLI::GetOptionValueBool(enum EVssAdmOption) __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z
          (CVssAdminCLI *this,EVssAdmOption param_1)

{
  longlong lVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_110 = 0x15b;
  local_120 = L"CVssAdminCLI::GetOptionValueBool";
  local_10c = 7;
  local_118 = L"INCPNTRH";
  local_108 = 0xff;
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  lVar1 = *(longlong *)(this + (longlong)(int)param_1 * 8 + 0x68);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return (int)(lVar1 != 0);
}



/* ==========================================================================
 * ??1CComBSTR@ATL@@QEAA@XZ @ 0x14000b80c  (10 bytes, 2 instructions)
 * void ??1CComBSTR@ATL@@QEAA@XZ(CComBSTR * this)
 * public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64
 * ========================================================================== */

/* public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64 */

void __thiscall ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ(CComBSTR *this)

{
                    /* WARNING: Could not recover jumptable at 0x00014000b80f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  Ordinal_6(*(undefined8 *)this);
  return;
}



/* ==========================================================================
 * ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z @ 0x14000b824  (223 bytes, 55 instructions)
 * int ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2, int param_3)
 * private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int) __ptr64
 * ========================================================================== */

/* private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2,int param_3)

{
  ushort *puVar1;
  __int64 _Var2;
  CVssFunctionTracer *this_00;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_128 = L"CVssAdminCLI::GetOptionValueNum";
  local_120 = L"INCPNTRH";
  local_118 = 0x168;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  this_00 = local_88;
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(this_00,&local_130);
  puVar1 = *(ushort **)(this + (longlong)(int)param_1 * 8 + 0x68);
  if (puVar1 != (ushort *)0x0) {
    _Var2 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,puVar1,param_3);
  }
  else {
    _Var2 = 0;
  }
  *param_2 = _Var2;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return (uint)(puVar1 != (ushort *)0x0);
}



/* ==========================================================================
 * ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z @ 0x14000b90c  (193 bytes, 46 instructions)
 * void ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this, ushort * param_1)
 * public: void __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64> >::CopyFrom(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssAutoString<class CVssAutoCOMPtr<unsigned short * __ptr64>
   >::CopyFrom(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
_CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
          (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this,ushort *param_1)

{
  long lVar1;
  ushort *puVar2;
  longlong lVar3;
  undefined4 local_res8 [2];
  longlong lVar4;
  
  lVar3 = -1;
  do {
    lVar4 = lVar3;
    lVar3 = lVar4 + 1;
  } while (param_1[lVar3] != 0);
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  puVar2 = CoTaskMemAlloc(lVar3 * 2 + 2);
  *(ushort **)(this + 8) = puVar2;
  if (puVar2 != (ushort *)0x0) {
    lVar1 = StringCchCopyW(puVar2,lVar4 + 2,param_1);
    if (-1 < lVar1) {
      return;
    }
    CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
    ::
    _Close___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEAAXXZ
              ((CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
                *)this);
    local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
  }
  local_res8[0] = 0x8007000e;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
}



/* ==========================================================================
 * ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z @ 0x14000b9d8  (309 bytes, 74 instructions)
 * int ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2)
 * private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64) __ptr64
 * ========================================================================== */

/* private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2)

{
  ushort uVar1;
  ushort *puVar2;
  longlong lVar3;
  longlong lVar4;
  __int64 _Var5;
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this_00;
  uint uVar6;
  undefined **local_148;
  ushort *local_140;
  undefined8 local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_138 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_128 = L"CVssAdminCLI::GetOptionValuePercent";
  local_120 = L"INCPNTRH";
  local_118 = 0x17d;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  puVar2 = *(ushort **)(this + 0x90);
  uVar6 = 0;
  if (puVar2 == (ushort *)0x0) {
    *param_2 = 0;
  }
  else if (*puVar2 != 0) {
    local_140 = (ushort *)0x0;
    local_148 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    this_00 = (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_148;
    CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
    _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z(this_00,puVar2);
    puVar2 = local_140;
    lVar3 = -1;
    do {
      lVar4 = lVar3;
      lVar3 = lVar4 + 1;
    } while (local_140[lVar4 + 1] != 0);
    uVar1 = local_140[lVar4];
    if (uVar1 == 0x25) {
      local_140[lVar4] = 0;
      _Var5 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,local_140,0);
      *param_2 = _Var5;
    }
    uVar6 = (uint)(uVar1 == 0x25);
    if (puVar2 != (ushort *)0x0) {
      CoTaskMemFree(puVar2);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return uVar6;
}



/* ==========================================================================
 * VssFreeSnapshotProperties @ 0x14000bb18  (7 bytes, 1 instructions)
 * void VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP * param_1)
 * void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64)
 * ========================================================================== */

/* void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64) */

void __cdecl VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014000bb18. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  VssFreeSnapshotPropertiesInternal();
  return;
}



/* ==========================================================================
 * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z @ 0x14000bb2c  (1354 bytes, 307 instructions)
 * ushort * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short
   const * __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  short sVar1;
  short sVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  void *pvVar6;
  ushort *puVar7;
  undefined8 uVar8;
  short *psVar9;
  undefined8 *puVar10;
  ushort *puVar11;
  ushort *puVar12;
  undefined8 *puVar13;
  longlong lVar14;
  ushort *local_res8;
  longlong *local_res18;
  longlong *local_res20;
  _VSSDBG_SEV_ENUM _Var15;
  longlong **pplVar16;
  GUID local_1a8;
  wchar_t *local_198;
  wchar_t *local_190;
  wchar_t *local_188;
  undefined4 local_180;
  undefined4 local_17c;
  undefined4 local_178;
  undefined1 local_170 [120];
  undefined4 local_f8;
  CVssFunctionTracer local_e8 [8];
  int local_e0;
  undefined1 local_78 [8];
  undefined8 local_70;
  longlong local_68 [4];
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  local_198 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_190 = L"CVssAdminCLI::GetVolumeDisplayName";
  local_188 = L"ADMUTILC";
  local_180 = 0x38;
  local_17c = 7;
  local_178 = 0xff;
  puVar11 = (ushort *)0x0;
  local_f8 = 0x1000000;
  memset(local_170,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_e8,&local_198);
  puVar10 = *(undefined8 **)(this + 0x40);
  if (puVar10 == (undefined8 *)0x0) {
    local_res20 = (longlong *)0x0;
    local_1a8 = _GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
    local_198 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_190 = L"CVssAdminCLI::GetVolumeDisplayName";
    local_188 = L"ADMUTILC";
    local_180 = 0x40;
    local_17c = 7;
    local_178 = 0xff;
    local_f8 = 0x1000000;
    memset(local_170,0,0x78);
    pplVar16 = &local_res20;
    CVssFunctionTracer::
    _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
              (local_e8,&local_198,&local_1a8,L"VssSnapshotMgmt");
    if (local_e0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x47,7,(_VSSDBG_SEV_ENUM)pplVar16);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
    }
    local_res18 = (longlong *)0x0;
    local_1a8._8_4_ = 0xab5180af;
    local_1a8._0_8_ = 0x49257b9fb5946137;
    local_1a8._12_4_ = 0xd5200bd6;
    local_e0 = (**(code **)(*local_res20 + 0x20))(local_res20,&local_1a8,0xffffffff,&local_res18);
    if (local_e0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_198,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x52,7,(_VSSDBG_SEV_ENUM)pplVar16);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
    }
    if (local_e0 == 1) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_198,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x56,
                         7,(_VSSDBG_SEV_ENUM)pplVar16);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_e8,uVar8,1,
                 L"CVssAdminCLI::ListVolumes: No volumes found that satisfy the query");
    }
    local_res8 = operator_new(0x18,&std::nothrow);
    puVar7 = puVar11;
    if (local_res8 != (ushort *)0x0) {
      local_res8[0] = 0;
      local_res8[1] = 0;
      local_res8[2] = 0;
      local_res8[3] = 0;
      local_res8[4] = 0;
      local_res8[5] = 0;
      local_res8[6] = 0;
      local_res8[7] = 0;
      local_res8[8] = 0;
      local_res8[9] = 0;
      puVar7 = local_res8;
    }
    *(ushort **)(this + 0x40) = puVar7;
    if (puVar7 == (ushort *)0x0) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_198,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x60,
                         1,(_VSSDBG_SEV_ENUM)pplVar16);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_e8,uVar8,0x8007000e,L"Memory allocation error");
    }
    local_e0 = (**(code **)(*local_res18 + 0x18))(local_res18,1,local_78,&local_res8);
    _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
    uVar8 = local_70;
    lVar14 = local_68[0];
    while( true ) {
      if (local_e0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_198,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                   (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x68,7,
                   _Var15);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_e8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_e8);
      }
      if (local_e0 == 1) break;
      lVar5 = -1;
      do {
        lVar5 = lVar5 + 1;
      } while (*(short *)(lVar14 + lVar5 * 2) != 0);
      if ((lVar5 == 3) && (*(short *)(lVar14 + 4) == 0x5c)) {
        *(undefined2 *)(lVar14 + 4) = 0;
      }
      plVar3 = *(longlong **)(this + 0x40);
      local_70 = uVar8;
      local_68[0] = lVar14;
      pvVar6 = realloc((void *)*plVar3,(longlong)((int)plVar3[2] + 1) << 3);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      if (pvVar6 == (void *)0x0) {
LAB_14000bec1:
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_70);
        CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)local_68);
        uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_198,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                           (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",
                           0x7a,1,_Var15);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_e8,uVar8,0x8007000e,L"Memory allocation error");
      }
      *plVar3 = (longlong)pvVar6;
      pvVar6 = realloc((void *)plVar3[1],(longlong)((int)plVar3[2] + 1) << 3);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      if (pvVar6 == (void *)0x0) goto LAB_14000bec1;
      plVar3[1] = (longlong)pvVar6;
      iVar4 = (int)plVar3[2];
      *(int *)(plVar3 + 2) = iVar4 + 1;
      puVar10 = (undefined8 *)(*plVar3 + (longlong)iVar4 * 8);
      if (puVar10 != (undefined8 *)0x0) {
        *puVar10 = uVar8;
        pvVar6 = (void *)plVar3[1];
      }
      plVar3 = (longlong *)((longlong)pvVar6 + (longlong)iVar4 * 8);
      if (plVar3 != (longlong *)0x0) {
        *plVar3 = lVar14;
      }
      local_e0 = (**(code **)(*local_res18 + 0x18))(local_res18,1,local_78,&local_res8);
      _Var15 = (_VSSDBG_SEV_ENUM)pplVar16;
      uVar8 = local_70;
      lVar14 = local_68[0];
    }
    if (local_res18 != (longlong *)0x0) {
      (**(code **)(*local_res18 + 0x10))();
    }
    if (local_res20 != (longlong *)0x0) {
      (**(code **)(*local_res20 + 0x10))();
    }
    puVar10 = *(undefined8 **)(this + 0x40);
  }
  if (0 < *(int *)(puVar10 + 2)) {
    puVar13 = (undefined8 *)*puVar10;
    puVar7 = puVar11;
    puVar12 = puVar11;
    do {
      iVar4 = (int)puVar7;
      psVar9 = (short *)*puVar13;
      lVar14 = (longlong)param_1 - (longlong)psVar9;
      do {
        sVar1 = *psVar9;
        sVar2 = *(short *)((longlong)psVar9 + lVar14);
        if (sVar1 != sVar2) break;
        psVar9 = psVar9 + 1;
      } while (sVar2 != 0);
      if (sVar1 == sVar2) goto LAB_14000be89;
      puVar7 = (ushort *)(ulonglong)(iVar4 + 1);
      puVar12 = (ushort *)((longlong)puVar12 + 1);
      puVar13 = puVar13 + 1;
    } while ((longlong)puVar12 < (longlong)*(int *)(puVar10 + 2));
  }
  iVar4 = -1;
LAB_14000be89:
  if (iVar4 != -1) {
    puVar11 = *(ushort **)(puVar10[1] + (longlong)iVar4 * 8);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_e8);
  return puVar11;
}



/* ==========================================================================
 * ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z @ 0x14000c084  (368 bytes, 84 instructions)
 * __uint64 ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64)
   __ptr64 */

__uint64 __thiscall
CVssAdminCLI::_GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  ULARGE_INTEGER UVar1;
  BOOL BVar2;
  DWORD DVar3;
  DWORD DVar4;
  ULARGE_INTEGER local_res8;
  ULARGE_INTEGER local_res18;
  ULARGE_INTEGER local_res20;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_140 = L"CVssAdminCLI::GetVolumeCapacity";
  local_138 = L"ADMUTILC";
  local_130 = 0x87;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  local_res8 = (ULARGE_INTEGER)this;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  local_res8.QuadPart = 0;
  local_res18.QuadPart = 0;
  local_res20.QuadPart = 0;
  BVar2 = GetDiskFreeSpaceExW((LPCWSTR)param_1,&local_res20,&local_res8,&local_res18);
  UVar1 = local_res8;
  if (BVar2 == 0) {
    DVar3 = GetLastError();
    if (DVar3 - 2 < 2) {
      DVar4 = 0x80042308;
    }
    else {
      DVar4 = DVar3 & 0xffff | 0x80070000;
      if ((int)DVar3 < 1) {
        DVar4 = DVar3;
      }
    }
    CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(local_98,DVar4);
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
               (ushort *)L"CVssAdminCLI::GetVolumeCapacity",0x9f,7,in_stack_fffffffffffffe98);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return (__uint64)UVar1.s;
}



/* ==========================================================================
 * ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z @ 0x14000c1fc  (650 bytes, 157 instructions)
 * ushort * ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z(CVssAdminCLI * this, uint param_1)
 * private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::LoadStringW(unsigned int) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::LoadStringW(unsigned int) __ptr64
    */

ushort * __thiscall
CVssAdminCLI::_LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(CVssAdminCLI *this,uint param_1)

{
  longlong *plVar1;
  int iVar2;
  ulonglong uVar3;
  HMODULE hInstance;
  void *pvVar4;
  undefined8 uVar5;
  uint *puVar6;
  ulonglong uVar7;
  ushort *puVar8;
  undefined1 auStackY_9b8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffff678;
  ushort *local_978;
  undefined8 local_970;
  wchar_t *local_968;
  wchar_t *local_960;
  wchar_t *local_958;
  undefined4 local_950;
  undefined4 local_94c;
  undefined4 local_948;
  undefined1 local_940 [120];
  undefined4 local_8c8;
  CVssFunctionTracer local_8b8 [112];
  WCHAR local_848 [1024];
  ulonglong local_48;
  
  local_970 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_9b8;
  local_968 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_960 = L"CVssAdminCLI::LoadStringW";
  local_958 = L"ADMUTILC";
  local_950 = 0xa9;
  local_94c = 7;
  local_948 = 0xff;
  uVar3 = 0;
  local_8c8 = 0x1000000;
  memset(local_940,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_8b8,&local_968);
  if (0 < *(int *)(this + 0x20)) {
    puVar6 = *(uint **)(this + 0x10);
    uVar7 = uVar3;
    do {
      iVar2 = (int)uVar3;
      if (*puVar6 == param_1) goto LAB_14000c2c9;
      uVar3 = (ulonglong)(iVar2 + 1);
      uVar7 = uVar7 + 1;
      puVar6 = puVar6 + 1;
    } while ((longlong)uVar7 < (longlong)*(int *)(this + 0x20));
  }
  iVar2 = -1;
LAB_14000c2c9:
  if ((iVar2 != -1) &&
     (puVar8 = *(ushort **)(*(longlong *)(this + 0x18) + (longlong)iVar2 * 8),
     puVar8 != (ushort *)0x0)) {
LAB_14000c2de:
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_8b8);
    return puVar8;
  }
  hInstance = GetModuleHandleW((LPCWSTR)0x0);
  iVar2 = LoadStringW(hInstance,param_1,local_848,0x3ff);
  if (iVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_968,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::LoadStringW",0xb8,7,
                       in_stack_fffffffffffff678);
    GetLastError();
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_8b8,uVar5,0x8000ffff,L"Error on loading the string %u. 0x%08lx");
  }
  local_978 = (ushort *)0x0;
  VssSafeDuplicateStr(local_8b8,&local_978,(ushort *)local_848);
  puVar8 = local_978;
  pvVar4 = realloc(*(void **)(this + 0x10),(longlong)(*(int *)(this + 0x20) + 1) << 2);
  if (pvVar4 != (void *)0x0) {
    *(void **)(this + 0x10) = pvVar4;
    pvVar4 = realloc(*(void **)(this + 0x18),(longlong)(*(int *)(this + 0x20) + 1) << 3);
    if (pvVar4 != (void *)0x0) {
      *(void **)(this + 0x18) = pvVar4;
      iVar2 = *(int *)(this + 0x20);
      *(int *)(this + 0x20) = iVar2 + 1;
      puVar6 = (uint *)(*(longlong *)(this + 0x10) + (longlong)iVar2 * 4);
      if (puVar6 != (uint *)0x0) {
        *puVar6 = param_1;
        pvVar4 = *(void **)(this + 0x18);
      }
      plVar1 = (longlong *)((longlong)pvVar4 + (longlong)iVar2 * 8);
      if (plVar1 != (longlong *)0x0) {
        *plVar1 = (longlong)puVar8;
      }
      goto LAB_14000c2de;
    }
  }
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_978);
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_968,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::LoadStringW",0xc4,1,
                     in_stack_fffffffffffff678);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_8b8,uVar5,0x8007000e,L"Memory allocation error");
}



/* ==========================================================================
 * ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z @ 0x14000c490  (209 bytes, 48 instructions)
 * ushort * ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z(CVssAdminCLI * this, bool param_1)
 * private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetNextCmdlineToken(bool) __ptr64
 * ========================================================================== */

/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetNextCmdlineToken(bool) __ptr64
    */

ushort * __thiscall
CVssAdminCLI::_GetNextCmdlineToken_CVssAdminCLI__AEAAPEBG_N_Z(CVssAdminCLI *this,bool param_1)

{
  longlong lVar1;
  ushort *puVar2;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_110 = 0xdf;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_10c = 7;
  local_120 = L"CVssAdminCLI::GetNextCmdlineToken";
  local_108 = 0xff;
  puVar2 = (ushort *)0x0;
  local_118 = L"ADMUTILC";
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  if (param_1) {
    DAT_140024710 = 0;
  }
  if (DAT_140024710 < *(int *)(this + 0x4c)) {
    lVar1 = (longlong)DAT_140024710;
    DAT_140024710 = DAT_140024710 + 1;
    puVar2 = *(ushort **)(*(longlong *)(this + 0x50) + lVar1 * 8);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return puVar2;
}



/* ==========================================================================
 * ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z @ 0x14000c568  (193 bytes, 46 instructions)
 * bool ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z(CVssAdminCLI * this, ushort * param_1, ushort * param_2)
 * private: bool __cdecl CVssAdminCLI::Match(unsigned short const * __ptr64,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* private: bool __cdecl CVssAdminCLI::Match(unsigned short const * __ptr64,unsigned short const *
   __ptr64) __ptr64 */

bool __thiscall
CVssAdminCLI::_Match_CVssAdminCLI__AEAA_NPEBG0_Z(CVssAdminCLI *this,ushort *param_1,ushort *param_2)

{
  int iVar1;
  bool bVar2;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_10c = 7;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_88 = 0x1000000;
  local_120 = L"CVssAdminCLI::Match";
  local_118 = L"ADMUTILC";
  bVar2 = false;
  local_110 = 0xff;
  local_108 = 0xff;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  if (param_1 != (ushort *)0x0) {
    iVar1 = _wcsicmp((wchar_t *)param_1,(wchar_t *)param_2);
    bVar2 = iVar1 == 0;
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return bVar2;
}



/* ==========================================================================
 * ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z @ 0x14000c630  (189 bytes, 42 instructions)
 * bool ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2)
 * private: bool __cdecl CVssAdminCLI::ScanGuid(unsigned short const * __ptr64,struct _GUID & __ptr64) __ptr64
 * ========================================================================== */

/* private: bool __cdecl CVssAdminCLI::ScanGuid(unsigned short const * __ptr64,struct _GUID &
   __ptr64) __ptr64 */

bool __thiscall
CVssAdminCLI::_ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z
          (CVssAdminCLI *this,ushort *param_1,_GUID *param_2)

{
  HRESULT HVar1;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_110 = 0x119;
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_10c = 7;
  local_108 = 0xff;
  local_88 = 0x1000000;
  local_120 = L"CVssAdminCLI::ScanGuid";
  local_118 = L"ADMUTILC";
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  HVar1 = CLSIDFromString((LPCOLESTR)param_1,param_2);
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return -1 < HVar1;
}



/* ==========================================================================
 * ?OutputMsg@CVssAdminCLI@@AEAAXJZZ @ 0x14000c6f4  (369 bytes, 79 instructions)
 * void ?OutputMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...)
 * private: void __cdecl CVssAdminCLI::OutputMsg(long,...) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::OutputMsg(long,...) __ptr64 */

void __thiscall CVssAdminCLI::_OutputMsg_CVssAdminCLI__AEAAXJZZ(CVssAdminCLI *this,long param_1,...)

{
  DWORD DVar1;
  undefined8 in_R8;
  undefined8 in_R9;
  undefined8 local_res18;
  undefined8 local_res20;
  ushort *local_148;
  va_list local_140;
  undefined8 local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 local_110;
  undefined1 local_108 [120];
  undefined4 local_90;
  CVssFunctionTracer local_88 [112];
  
  local_138 = 0xfffffffffffffffe;
  local_130 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_128 = L"CVssAdminCLI::OutputMsg";
  local_120 = L"ADMUTILC";
  local_118 = 0x149;
  local_114 = 7;
  local_110 = 0xff;
  local_90 = 0x1000000;
  local_res18 = in_R8;
  local_res20 = in_R9;
  memset(local_108,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_130);
  local_140 = (va_list)&local_res18;
  DVar1 = FormatMessageW(0x900,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_148,0,&local_140);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW(0x1100,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_148,0,&local_140);
    if (DVar1 == 0) {
      GetLastError();
      wprintf(L"Unable to load message for id %x - %d\n");
      goto LAB_14000c84c;
    }
  }
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_148);
  LocalFree(local_148);
LAB_14000c84c:
  local_140 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return;
}



/* ==========================================================================
 * ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ @ 0x14000c86c  (369 bytes, 83 instructions)
 * ushort * ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ(CVssAdminCLI * this, int param_1, long param_2, ...)
 * private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetMsg(int,long,...) __ptr64
 * ========================================================================== */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::GetMsg(int,long,...) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(CVssAdminCLI *this,int param_1,long param_2,...)

{
  DWORD DVar1;
  undefined8 in_R9;
  undefined8 local_res20;
  ushort *local_158;
  ushort *local_150;
  va_list local_148;
  undefined8 local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [112];
  
  local_140 = 0xfffffffffffffffe;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"CVssAdminCLI::GetMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x179;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  local_res20 = in_R9;
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88,&local_138);
  local_150 = (ushort *)0x0;
  local_148 = (va_list)&local_res20;
  DVar1 = FormatMessageW((-(uint)(param_1 != 0) & 0xffffff50) + 0x9ff,(LPCVOID)0x0,param_2,0x400,
                         (LPWSTR)&local_158,0,&local_148);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW((-(uint)(param_1 != 0) & 0xffffff50) + 0x11ff,(LPCVOID)0x0,param_2,0x400,
                           (LPWSTR)&local_158,0,&local_148);
    if (DVar1 == 0) goto LAB_14000c9bf;
  }
  if (local_158 != (ushort *)0x0) {
    VssSafeDuplicateStr(local_88,&local_150,local_158);
  }
  LocalFree(local_158);
LAB_14000c9bf:
  local_148 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return local_150;
}



/* ==========================================================================
 * ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z @ 0x14000c9e4  (914 bytes, 186 instructions)
 * void ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z(CVssAdminCLI * this, ushort * param_1, __uint64 param_2, long param_3, ulong param_4, ushort * param_5)
 * private: void __cdecl CVssAdminCLI::AppendMessageToStr(unsigned short * __ptr64,unsigned __int64,long,unsigned long,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::AppendMessageToStr(unsigned short * __ptr64,unsigned
   __int64,long,unsigned long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_AppendMessageToStr_CVssAdminCLI__AEAAXPEAG_KJKPEBG_Z
          (CVssAdminCLI *this,ushort *param_1,__uint64 param_2,long param_3,ulong param_4,
          ushort *param_5)

{
  long lVar1;
  ushort *pv;
  undefined8 uVar2;
  undefined1 auStackY_318 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffd18;
  wchar_t *local_2c8;
  wchar_t *local_2c0;
  wchar_t *local_2b8;
  undefined4 local_2b0;
  undefined4 local_2ac;
  undefined4 local_2a8;
  undefined1 local_2a0 [120];
  undefined4 local_228;
  undefined8 local_220;
  CVssFunctionTracer local_218 [8];
  long local_210;
  CVssDebugInfo local_1a8 [176];
  wchar_t *local_f8;
  wchar_t *local_f0;
  wchar_t *local_e8;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined4 local_d8;
  undefined1 local_d0 [120];
  undefined4 local_58;
  ulonglong local_48;
  
  local_220 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_318;
  local_2c8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_2c0 = L"CVssAdminCLI::AppendMessageToStr";
  local_2b8 = L"ADMUTILC";
  local_2b0 = 0x1ab;
  local_2ac = 7;
  local_2a8 = 0xff;
  local_228 = 0x1000000;
  memset(local_2a0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_218);
  if (*param_1 != 0) {
    lVar1 = StringCchCatW(param_1,0x400,(ushort *)L", ");
    local_f8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_f0 = L"CVssAdminCLI::AppendMessageToStr";
    local_e8 = L"ADMUTILC";
    local_e0 = 0x1b1;
    local_dc = 7;
    local_d8 = 0xff;
    local_58 = 0x1000000;
    local_210 = lVar1;
    memset(local_d0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                        ((CVssDebugInfo *)&local_2c8,(CVssDebugInfo *)&local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_f8);
  }
  if (param_3 == 0) {
    StringCchPrintfW((ushort *)&local_f8,0x40,(ushort *)L"0x%x",(ulonglong)param_4);
    lVar1 = StringCchCatW(param_1,0x400,(ushort *)&local_f8);
    local_2c8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_2c0 = L"CVssAdminCLI::AppendMessageToStr";
    local_2b8 = L"ADMUTILC";
    local_2b0 = 0x1ce;
    local_2ac = 7;
    local_2a8 = 0xff;
    local_228 = 0x1000000;
    local_210 = lVar1;
    memset(local_2a0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_1a8,(CVssDebugInfo *)&local_2c8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_2c8);
  }
  else {
    pv = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,param_3);
    if (pv == (ushort *)0x0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_2c8,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::AppendMessageToStr",0x1bb,7
                         ,in_stack_fffffffffffffd18);
      GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_218,uVar2,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
    }
    lVar1 = StringCchCatW(param_1,0x400,pv);
    local_f8 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_f0 = L"CVssAdminCLI::AppendMessageToStr";
    local_e8 = L"ADMUTILC";
    local_e0 = 0x1c1;
    local_dc = 7;
    local_d8 = 0xff;
    local_58 = 0x1000000;
    local_210 = lVar1;
    memset(local_d0,0,0x78);
    if (lVar1 < 0) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                        ((CVssDebugInfo *)&local_2c8,(CVssDebugInfo *)&local_f8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                (local_218,uVar2,lVar1,L"StringCchCat");
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_f8);
    CoTaskMemFree(pv);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_218);
  return;
}



/* ==========================================================================
 * ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z @ 0x14000cd84  (1318 bytes, 285 instructions)
 * __int64 ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z(CVssAdminCLI * this, ushort * param_1, int param_2)
 * private: __int64 __cdecl CVssAdminCLI::ScanNumber(unsigned short const * __ptr64,int) __ptr64
 * ========================================================================== */

/* private: __int64 __cdecl CVssAdminCLI::ScanNumber(unsigned short const * __ptr64,int) __ptr64 */

__int64 __thiscall
CVssAdminCLI::_ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z
          (CVssAdminCLI *this,ushort *param_1,int param_2)

{
  wchar_t *_Src;
  wint_t wVar1;
  int iVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  wchar_t _C;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe88;
  undefined **local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  undefined8 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  local_b0 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_150 = L"CVssAdminCLI::ScanNumber";
  local_148 = L"ADMUTILC";
  local_140 = 0x1db;
  local_13c = 7;
  local_138 = 0xff;
  uVar5 = 0;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  _C = L'B';
  iVar2 = _wcsicmp((wchar_t *)param_1,L"UNBOUNDED");
  if (iVar2 == 0) goto LAB_14000ce9f;
  local_160 = (wchar_t *)0x0;
  local_168 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_168,param_1);
  _Src = local_160;
  uVar4 = 0xffffffffffffffff;
  do {
    uVar4 = uVar4 + 1;
  } while (local_160[uVar4] != L'\0');
  if (uVar4 != 0) {
    do {
      if (local_160[uVar4 - 1] != L' ') break;
      uVar4 = uVar4 - 1;
      local_160[uVar4] = L'\0';
    } while (uVar4 != 0);
    if (uVar4 != 0) {
      if (param_2 == 0) {
        uVar4 = 0xffffffffffffffff;
        do {
          uVar4 = uVar4 + 1;
        } while (local_160[uVar4] != L'\0');
        if (uVar4 != 0) {
          do {
            iVar2 = iswdigit(_Src[uVar5]);
            if (iVar2 == 0) {
              uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                                ((CVssDebugInfo *)&local_158,
                                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                                 (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x21a,7
                                 ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
              CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                        (local_a8,uVar3,0x1001,
                         L"Invalid input number: \'%s\', number must be all digits",param_1);
            }
            uVar5 = uVar5 + 1;
          } while (uVar5 < uVar4);
        }
      }
      else {
        if ((((3 < uVar4) && (iVar2 = iswalpha(local_160[uVar4 - 3]), iVar2 != 0)) &&
            (iVar2 = iswalpha(_Src[uVar4 - 2]), iVar2 != 0)) &&
           (iVar2 = iswalpha(_Src[uVar4 - 1]), iVar2 != 0)) {
          uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_158,
                             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                             (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x1fe,7,
                             in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_a8,uVar3,0x1001,
                     L"Invalid input number: \'%s\', too many alpha chars in suffix.",param_1);
        }
        if (((uVar4 < 3) || (iVar2 = iswalpha(_Src[uVar4 - 2]), iVar2 == 0)) ||
           (wVar1 = towupper(_Src[uVar4 - 1]), wVar1 != 0x42)) {
          if ((1 < uVar4) && (iVar2 = iswalpha(_Src[uVar4 - 1]), iVar2 != 0)) {
            _C = _Src[uVar4 - 1];
            _Src[uVar4 - 1] = L'\0';
          }
        }
        else {
          wVar1 = towupper(_Src[uVar4 - 2]);
          if (wVar1 == 0x42) {
            uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                              ((CVssDebugInfo *)&local_158,
                               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                               (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x205,7,
                               in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
            CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                      (local_a8,uVar3,0x1001,
                       L"Invalid input number: \'%s\', BB is not a valid suffix",param_1);
          }
          _C = _Src[uVar4 - 2];
          _Src[uVar4 - 2] = L'\0';
        }
      }
      iVar2 = swscanf(_Src,L"%lf");
      if (iVar2 != 1) {
        uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_158,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                           (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x222,7,
                           in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
      }
      wVar1 = towupper(_C);
      if (wVar1 == 0x42) goto LAB_14000d0ad;
      if (wVar1 == 0x45) {
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14000d087:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14000d08b:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14000d08f:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14000d093:
        this = (CVssAdminCLI *)((double)this * 1024.0);
      }
      else {
        if (wVar1 == 0x47) goto LAB_14000d08f;
        if (wVar1 != 0x4b) {
          if (wVar1 != 0x4d) {
            if (wVar1 == 0x50) goto LAB_14000d087;
            if (wVar1 != 0x54) {
              uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                                ((CVssDebugInfo *)&local_158,
                                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                                 (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x238,7
                                 ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
              CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                        (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
            }
            goto LAB_14000d08b;
          }
          goto LAB_14000d093;
        }
      }
      this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14000d0ad:
      if (-1 < (longlong)(double)this) {
        if (_Src != (wchar_t *)0x0) {
          CoTaskMemFree(_Src);
        }
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
        return (longlong)(double)this;
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_158,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x240,7,
                         in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
    }
  }
  if (local_160 != (wchar_t *)0x0) {
    CoTaskMemFree(local_160);
  }
LAB_14000ce9f:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return -1;
}



/* ==========================================================================
 * ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z @ 0x14000d2b8  (609 bytes, 136 instructions)
 * ushort * ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z(CVssAdminCLI * this, __int64 param_1, int param_2)
 * private: unsigned short * __ptr64 __cdecl CVssAdminCLI::FormatNumber(__int64,int) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::FormatNumber(__int64,int) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_FormatNumber_CVssAdminCLI__AEAAPEAG_JH_Z
          (CVssAdminCLI *this,__int64 param_1,int param_2)

{
  HRESULT HVar1;
  ushort *puVar2;
  undefined8 uVar3;
  undefined1 auStackY_2d8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffd58;
  ushort *local_298;
  wchar_t **local_290;
  wchar_t *local_288;
  wchar_t *local_280;
  wchar_t *local_278;
  undefined4 local_270;
  undefined4 local_26c;
  undefined4 local_268;
  undefined1 local_260 [120];
  undefined4 local_1e8;
  undefined8 local_1e0;
  CVssFunctionTracer local_1d8 [8];
  HRESULT local_1d0;
  CVssDebugInfo local_168 [176];
  WCHAR local_b8 [64];
  ulonglong local_38;
  
  local_1e0 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_2d8;
  local_288 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_280 = L"CVssAdminCLI::FormatNumber";
  local_278 = L"ADMUTILC";
  local_270 = 0x24f;
  local_26c = 7;
  local_268 = 0xff;
  local_1e8 = 0x1000000;
  memset(local_260,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_1d8);
  local_298 = (ushort *)0x0;
  memset(local_b8,0,0x80);
  if (param_1 < 0) {
    puVar2 = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x40002712);
    if (puVar2 == (ushort *)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_288,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::FormatNumber",0x25a,7,
                         in_stack_fffffffffffffd58);
      GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_1d8,uVar3,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_1d8);
    local_298 = puVar2;
  }
  else {
    if (param_2 == 0) {
      StringCchPrintfW((ushort *)local_b8,0x40,(ushort *)L"%I64d",param_1);
    }
    else {
      HVar1 = StrFormatByteSizeEx(param_1,1,local_b8,0x40);
      local_288 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_280 = L"CVssAdminCLI::FormatNumber";
      local_278 = L"ADMUTILC";
      local_270 = 0x269;
      local_26c = 7;
      local_268 = 0xff;
      local_1e8 = 0x1000000;
      local_1d0 = HVar1;
      memset(local_260,0,0x78);
      local_290 = &local_288;
      if (HVar1 < 0) {
        uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                          (local_168,(CVssDebugInfo *)&local_288);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                  (local_1d8,uVar3,HVar1,L"StrFormatByteSizeEx");
      }
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_288);
    }
    VssSafeDuplicateStr(local_1d8,&local_298,(ushort *)local_b8);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_1d8);
  }
  return local_298;
}



/* ==========================================================================
 * ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ @ 0x14000d524  (603 bytes, 131 instructions)
 * void ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...)
 * private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64 */

void __thiscall
CVssAdminCLI::_OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(CVssAdminCLI *this,long param_1,...)

{
  DWORD DVar1;
  undefined8 uVar2;
  undefined8 in_R8;
  undefined8 in_R9;
  undefined8 local_res18;
  undefined8 local_res20;
  ushort **lpBuffer;
  undefined4 uVar3;
  _VSSDBG_SEV_ENUM _Var4;
  va_list *Arguments;
  ushort *local_178;
  va_list local_170;
  undefined8 local_168;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  CVssFunctionTracer local_a8 [120];
  
  local_168 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_150 = L"CVssAdminCLI::OutputErrorMsg";
  local_148 = L"ADMUTILC";
  local_140 = 0x284;
  local_13c = 7;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  local_res18 = in_R8;
  local_res20 = in_R9;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  local_170 = (va_list)&local_res18;
  DVar1 = FormatMessageW(0x900,(LPCVOID)0x0,0x40002714,0x400,(LPWSTR)&local_178,0,(va_list *)0x0);
  if (DVar1 != 0) {
    _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_178);
    LocalFree(local_178);
  }
  DVar1 = 0x1100;
  if (0x4000270f < param_1) {
    DVar1 = 0x900;
  }
  DVar1 = FormatMessageW(DVar1,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_178,0,&local_170);
  if (DVar1 == 0) {
    Arguments = &local_170;
    lpBuffer = &local_178;
    DVar1 = FormatMessageW(0x1100,(LPCVOID)0x0,param_1,0x400,(LPWSTR)lpBuffer,0,Arguments);
    _Var4 = (_VSSDBG_SEV_ENUM)Arguments;
    uVar3 = (undefined4)((ulonglong)lpBuffer >> 0x20);
    if (DVar1 == 0) {
      GetLastError();
      wprintf(L"Unable to format message for id %x - %d\n");
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_158,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::OutputErrorMsg",0x2bd,7,
                         _Var4);
      DVar1 = GetLastError();
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_a8,uVar2,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx",
                 CONCAT44(uVar3,param_1),DVar1);
    }
  }
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" ");
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_178);
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" \r\n");
  LocalFree(local_178);
  local_170 = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}



/* ==========================================================================
 * ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z @ 0x14000d788  (764 bytes, 169 instructions)
 * int ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z(CVssAdminCLI * this, long param_1, ulong param_2)
 * private: int __cdecl CVssAdminCLI::PromptUserForConfirmation(long,unsigned long) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: int __cdecl CVssAdminCLI::PromptUserForConfirmation(long,unsigned long) __ptr64 */

int __thiscall
CVssAdminCLI::_PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z
          (CVssAdminCLI *this,long param_1,ulong param_2)

{
  int iVar1;
  DWORD DVar2;
  BOOL BVar3;
  PCNZWCH lpString2;
  WCHAR *pv;
  undefined8 uVar4;
  undefined1 auStackY_1d8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe58;
  WCHAR local_198 [4];
  DWORD local_190 [4];
  undefined8 local_180;
  wchar_t *local_178;
  wchar_t *local_170;
  wchar_t *local_168;
  undefined4 local_160;
  undefined4 local_15c;
  undefined4 local_158;
  undefined1 local_150 [120];
  undefined4 local_d8;
  CVssFunctionTracer local_c8 [112];
  ushort local_58 [16];
  ulonglong local_38;
  
  local_180 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_1d8;
  local_178 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_170 = L"CVssAdminCLI::PromptUserForConfirmation";
  local_168 = L"ADMUTILC";
  local_160 = 0x2cc;
  local_15c = 7;
  local_158 = 0xff;
  local_d8 = 0x1000000;
  memset(local_150,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_c8,&local_178);
  local_190[0] = 0;
  local_58[0] = 0;
  local_58[1] = 0;
  local_58[2] = 0;
  local_58[3] = 0;
  local_58[4] = 0;
  local_58[5] = 0;
  local_58[6] = 0;
  local_58[7] = 0;
  local_58[8] = 0;
  local_58[9] = 0;
  local_58[10] = 0;
  local_58[0xb] = 0;
  local_58[0xc] = 0;
  local_58[0xd] = 0;
  local_58[0xe] = 0;
  local_58[0xf] = 0;
  iVar1 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  if (iVar1 != 0) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
    return 1;
  }
  lpString2 = (PCNZWCH)_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x4000300d);
  if (lpString2 != (PCNZWCH)0x0) {
    pv = (WCHAR *)_GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x4000300e);
    if (pv != (WCHAR *)0x0) {
      if (param_2 == 0) {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,param_1,lpString2,pv);
      }
      else {
        _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,param_1,(ulonglong)param_2,lpString2);
      }
      DVar2 = GetFileType(*(HANDLE *)(this + 8));
      if (((DVar2 & 2) == 0) ||
         (BVar3 = GetConsoleMode(*(HANDLE *)(this + 8),local_190), BVar3 == 0)) {
        local_198[0] = *pv;
      }
      else {
        local_198[0] = MyGetChar();
      }
      StringCchPrintfW(local_58,0x10,(ushort *)L"%c\n\n",(ulonglong)(ushort)local_198[0]);
      _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_58);
      iVar1 = CompareStringW(0x7f,0x10001,local_198,1,lpString2,1);
      CoTaskMemFree(lpString2);
      CoTaskMemFree(pv);
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_c8);
      return (uint)(iVar1 == 2);
    }
    CoTaskMemFree(lpString2);
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_178,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::PromptUserForConfirmation",
                       0x2eb,7,in_stack_fffffffffffffe58);
    GetLastError();
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_c8,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
  }
  uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_178,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::PromptUserForConfirmation",
                     0x2e2,7,in_stack_fffffffffffffe58);
  GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_c8,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx");
}



/* ==========================================================================
 * ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z @ 0x14000da90  (822 bytes, 181 instructions)
 * void ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * private: void __cdecl CVssAdminCLI::OutputOnConsole(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssAdminCLI::OutputOnConsole(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  DWORD DVar1;
  BOOL BVar2;
  UINT UVar3;
  uint cbMultiByte;
  int iVar4;
  LPSTR lpMultiByteStr;
  longlong lVar5;
  DWORD local_res8 [4];
  DWORD local_res18 [2];
  DWORD local_res20 [2];
  wchar_t *local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined1 local_128 [120];
  undefined4 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  local_150 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_148 = L"CVssAdminCLI::OutputOnConsole";
  local_140 = L"ADMUTILC";
  local_138 = 0x326;
  local_134 = 7;
  local_130 = 0xff;
  local_b0 = 0x1000000;
  memset(local_128,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_150);
  lVar5 = -1;
  if (*(HANDLE *)(this + 8) == (HANDLE)0xffffffffffffffff) {
    local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
  }
  if (DAT_140024134 != 0) {
    DVar1 = GetFileType(*(HANDLE *)(this + 8));
    if (((DVar1 & 2) == 0) ||
       (BVar2 = GetConsoleMode(*(HANDLE *)(this + 8),local_res20), DAT_140024714 = 1, BVar2 == 0)) {
      DAT_140024714 = 0;
    }
    DAT_140024134 = 0;
  }
  if (DAT_140024714 == 0) {
    UVar3 = GetConsoleOutputCP();
    cbMultiByte = WideCharToMultiByte(UVar3,0,(LPCWSTR)param_1,-1,(LPSTR)0x0,0,(LPCSTR)0x0,
                                      (LPBOOL)0x0);
    if (cbMultiByte == 0) {
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    lpMultiByteStr = malloc((ulonglong)cbMultiByte);
    if (lpMultiByteStr == (LPSTR)0x0) {
      local_res8[0] = 0x8007000e;
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    UVar3 = GetConsoleOutputCP();
    iVar4 = WideCharToMultiByte(UVar3,0,(LPCWSTR)param_1,-1,lpMultiByteStr,cbMultiByte,(LPCSTR)0x0,
                                (LPBOOL)0x0);
    if (iVar4 == 0) {
      free(lpMultiByteStr);
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    BVar2 = WriteFile(*(HANDLE *)(this + 8),lpMultiByteStr,iVar4 - 1,local_res18,(LPOVERLAPPED)0x0);
    if (BVar2 == 0) {
      free(lpMultiByteStr);
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
    free(lpMultiByteStr);
  }
  else {
    do {
      lVar5 = lVar5 + 1;
    } while (param_1[lVar5] != 0);
    BVar2 = WriteConsoleW(*(HANDLE *)(this + 8),param_1,(DWORD)lVar5,local_res18,(LPVOID)0x0);
    if (BVar2 == 0) {
      DVar1 = GetLastError();
      local_res8[0] = DVar1 & 0xffff | 0x80070000;
      if ((int)DVar1 < 1) {
        local_res8[0] = DVar1;
      }
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}



/* ==========================================================================
 * MapVssErrorToMsg @ 0x14000ddd4  (902 bytes, 208 instructions)
 * int MapVssErrorToMsg(long param_1, long * param_2)
 * int __cdecl MapVssErrorToMsg(long,long * __ptr64)
 * ========================================================================== */

/* int __cdecl MapVssErrorToMsg(long,long * __ptr64) */

int __cdecl MapVssErrorToMsg(long param_1,long *param_2)

{
  long lVar1;
  int iVar2;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [112];
  
  local_120 = 0x3a9;
  local_11c = 7;
  iVar2 = 0;
  local_118 = 0xff;
  local_98 = 0x1000000;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88);
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x3ab;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_88,&local_138,L"Input HR: 0x%08x",param_1);
  *param_2 = 0;
  if (param_1 < -0x7ffbdcd9) {
    if (param_1 == -0x7ffbdcda) {
      lVar1 = 0x40002b0c;
    }
    else if (param_1 < -0x7ffbdcec) {
      if (param_1 == -0x7ffbdced) {
        lVar1 = 0x40002aff;
      }
      else if (param_1 == -0x7ffbdcff) {
LAB_14000df24:
        lVar1 = 0x40002b64;
      }
      else if (param_1 == -0x7ffbdcfc) {
        lVar1 = 0x40002af9;
      }
      else if (param_1 == -0x7ffbdcfa) {
        lVar1 = 0x40002afa;
      }
      else if (param_1 == -0x7ffbdcf8) {
        lVar1 = 0x40002afb;
      }
      else if (param_1 == -0x7ffbdcf4) {
        lVar1 = 0x40002afc;
      }
      else if (param_1 == -0x7ffbdcf2) {
        lVar1 = 0x40002afd;
      }
      else {
        if (param_1 != -0x7ffbdcf1) {
          iVar2 = 0;
          if (1 < param_1 + 0x7ffbdcefU) goto LAB_14000e12e;
          goto LAB_14000df24;
        }
        lVar1 = 0x40002afe;
      }
    }
    else if (param_1 == -0x7ffbdcec) {
      lVar1 = 0x40002b00;
    }
    else if (param_1 == -0x7ffbdceb) {
      lVar1 = 0x40002b01;
    }
    else if (param_1 == -0x7ffbdcea) {
      lVar1 = 0x40002b02;
    }
    else if (param_1 == -0x7ffbdce9) {
      lVar1 = 0x40002b03;
    }
    else if (param_1 == -0x7ffbdce5) {
      lVar1 = 0x40002b04;
    }
    else if (param_1 == -0x7ffbdce2) {
      lVar1 = 0x40002b05;
    }
    else {
      if (param_1 != -0x7ffbdce1) goto LAB_14000e12e;
      lVar1 = 0x40002b06;
    }
  }
  else if (param_1 < 0x1005) {
    if (param_1 == 0x1004) {
LAB_14000e071:
      lVar1 = 0x40002bc3;
    }
    else if (param_1 == -0x7ff8fffb) {
      lVar1 = 0x40002b09;
    }
    else if (param_1 == -0x7ff8fff2) {
      lVar1 = 0x40002b08;
    }
    else {
      if (param_1 == -0x7ff8ffa9) goto LAB_14000e071;
      if (param_1 == 1) {
        lVar1 = 0x40002b07;
      }
      else if (param_1 == 0x1001) {
        lVar1 = 0x40002bc0;
      }
      else if (param_1 == 0x1002) {
        lVar1 = 0x40002bc1;
      }
      else {
        if (param_1 != 0x1003) goto LAB_14000e12e;
        lVar1 = 0x40002bc2;
      }
    }
  }
  else if (param_1 == 0x1005) {
    lVar1 = 0x40002bc4;
  }
  else if (param_1 == 0x1006) {
    lVar1 = 0x40002bc5;
  }
  else if (param_1 == 0x1007) {
    lVar1 = 0x40002bc6;
  }
  else if (param_1 == 0x1008) {
    lVar1 = 0x40002bc7;
  }
  else if (param_1 == 0x1009) {
    lVar1 = 0x4000276e;
  }
  else if (param_1 == 0x100a) {
    lVar1 = 0x4000276f;
  }
  else {
    if (param_1 != 0x100b) goto LAB_14000e12e;
    lVar1 = 0x40002b0d;
  }
  *param_2 = lVar1;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x41a;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_88,&local_138,L"Output Msg#: 0x%08x",lVar1);
  iVar2 = 1;
LAB_14000e12e:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return iVar2;
}



/* ==========================================================================
 * MapGenericVssErrorToMsg @ 0x14000e164  (657 bytes, 135 instructions)
 * int MapGenericVssErrorToMsg(long param_1, ushort * * param_2)
 * int __cdecl MapGenericVssErrorToMsg(long,unsigned short * __ptr64 * __ptr64)
 * ========================================================================== */

/* int __cdecl MapGenericVssErrorToMsg(long,unsigned short * __ptr64 * __ptr64) */

int __cdecl MapGenericVssErrorToMsg(long param_1,ushort **param_2)

{
  DWORD DVar1;
  BOOL BVar2;
  HMODULE hLibModule;
  uint uVar3;
  wchar_t *pwVar4;
  bool bVar5;
  ushort *local_res10;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_130 = 0x42a;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_140 = L"MapGenericVssErrorToMsg";
  local_138 = L"ADMUTILC";
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  local_res10 = (ushort *)0x0;
  if (param_2 == (ushort **)0x0) {
    local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_140 = L"MapGenericVssErrorToMsg";
    local_138 = L"ADMUTILC";
    local_130 = 0x432;
    local_12c = 7;
    local_128 = 0xff;
    local_a8 = 0x1000000;
    memset(local_120,0,0x78);
    pwVar4 = L"Invalid parameter";
    uVar3 = 0;
  }
  else {
    *param_2 = (ushort *)0x0;
    hLibModule = LoadLibraryW(L"vsstrace.dll");
    if (hLibModule == (HMODULE)0x0) {
      local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_138 = L"ADMUTILC";
      local_140 = L"MapGenericVssErrorToMsg";
      local_130 = 0x43c;
      local_12c = 7;
      local_128 = 0xff;
      local_a8 = 0x1000000;
      memset(local_120,0,0x78);
      pwVar4 = L"Failed to load vsstrace.dll";
      uVar3 = 0;
    }
    else {
      DVar1 = FormatMessageW(0xb00,hLibModule,param_1,0x400,(LPWSTR)&local_res10,0,(va_list *)0x0);
      bVar5 = DVar1 != 0;
      if (bVar5) {
        *param_2 = local_res10;
      }
      else {
        local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
        local_138 = L"ADMUTILC";
        local_140 = L"MapGenericVssErrorToMsg";
        local_130 = 0x44c;
        local_12c = 7;
        local_128 = 0xff;
        local_a8 = 0x1000000;
        memset(local_120,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_98,&local_148,L"Unable to find error message in VssTrace.");
      }
      uVar3 = (uint)bVar5;
      BVar2 = FreeLibrary(hLibModule);
      if (BVar2 != 0) goto LAB_14000e3c9;
      local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_140 = L"MapGenericVssErrorToMsg";
      local_138 = L"ADMUTILC";
      local_130 = 0x458;
      local_12c = 7;
      local_128 = 0xff;
      local_a8 = 0x1000000;
      memset(local_120,0,0x78);
      pwVar4 = L"Unable to free VssTrace.dll";
      uVar3 = (uint)bVar5;
    }
  }
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_98,&local_148,pwVar4);
LAB_14000e3c9:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return uVar3;
}



/* ==========================================================================
 * GuidToString @ 0x14000e3fc  (403 bytes, 91 instructions)
 * ushort * GuidToString(_GUID * param_1)
 * unsigned short * __ptr64 __cdecl GuidToString(struct _GUID)
 * ========================================================================== */

/* unsigned short * __ptr64 __cdecl GuidToString(struct _GUID) */

ushort * __cdecl GuidToString(_GUID *param_1)

{
  DWORD DVar1;
  ushort *puVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe78;
  undefined8 uVar3;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  uVar3 = 0xfffffffffffffffe;
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_138 = L"GuidToString";
  local_130 = L"ADMUTILC";
  local_128 = 0x463;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  puVar2 = CoTaskMemAlloc(0x50);
  if (puVar2 != (ushort *)0x0) {
    StringCchPrintfW(puVar2,0x28,(ushort *)L"{%.8x-%.4x-%.4x-%.2x%.2x-%.2x%.2x%.2x%.2x%.2x%.2x}",
                     (ulonglong)param_1->Data1,(uint)param_1->Data2,(uint)param_1->Data3,
                     (uint)param_1->Data4[0],(uint)param_1->Data4[1],(uint)param_1->Data4[2],
                     (uint)param_1->Data4[3],(uint)param_1->Data4[4],(uint)param_1->Data4[5],
                     (uint)param_1->Data4[6],(uint)param_1->Data4[7],uVar3);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return puVar2;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_140,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"GuidToString",0x46b,7,
                     in_stack_fffffffffffffe78);
  DVar1 = GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar3,0x8007000e,L"Error from CoTaskMemAlloc: 0x%08lx",DVar1);
}



/* ==========================================================================
 * DateTimeToString @ 0x14000e598  (794 bytes, 173 instructions)
 * ushort * DateTimeToString(__int64 * param_1)
 * unsigned short * __ptr64 __cdecl DateTimeToString(__int64 * __ptr64)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* unsigned short * __ptr64 __cdecl DateTimeToString(__int64 * __ptr64) */

ushort * __cdecl DateTimeToString(__int64 *param_1)

{
  LCID LVar1;
  long lVar2;
  longlong lVar3;
  ushort *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auStackY_378 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffcb8;
  _FILETIME local_338;
  _FILETIME local_330;
  wchar_t *local_328;
  wchar_t *local_320;
  wchar_t *local_318;
  undefined4 local_310;
  undefined4 local_30c;
  undefined4 local_308;
  undefined1 local_300 [120];
  undefined4 local_288;
  undefined8 local_280;
  CVssFunctionTracer local_278 [8];
  long local_270;
  CVssDebugInfo local_208 [168];
  _SYSTEMTIME local_160;
  _SYSTEMTIME local_150;
  WCHAR local_138 [64];
  WCHAR local_b8 [64];
  ulonglong local_38;
  
  local_280 = 0xfffffffffffffffe;
  local_38 = __security_cookie ^ (ulonglong)auStackY_378;
  local_328 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_320 = L"DateTimeToString";
  local_318 = L"ADMUTILC";
  local_310 = 0x47b;
  local_30c = 7;
  local_308 = 0xff;
  local_288 = 0x1000000;
  memset(local_300,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_278,&local_328);
  if ((param_1 == (__int64 *)0x0) || (*param_1 == 0)) {
    GetSystemTime(&local_160);
    SystemTimeToFileTime(&local_160,&local_338);
    param_1 = (__int64 *)&local_338;
  }
  FileTimeToLocalFileTime((FILETIME *)param_1,&local_330);
  FileTimeToSystemTime(&local_330,&local_150);
  LVar1 = GetThreadLocale();
  GetDateFormatW(LVar1,1,&local_150,(LPCWSTR)0x0,local_b8,0x40);
  LVar1 = GetThreadLocale();
  GetTimeFormatW(LVar1,0,&local_150,(LPCWSTR)0x0,local_138,0x40);
  lVar7 = -1;
  lVar6 = -1;
  do {
    lVar6 = lVar6 + 1;
  } while (local_138[lVar6] != L'\0');
  lVar3 = -1;
  do {
    lVar3 = lVar3 + 1;
  } while (local_b8[lVar3] != L'\0');
  puVar4 = CoTaskMemAlloc((lVar6 + lVar3) * 2 + 4);
  if (puVar4 == (ushort *)0x0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_328,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"DateTimeToString",0x4ad,7,
                       in_stack_fffffffffffffcb8);
    GetLastError();
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_278,uVar5,0x8007000e,L"Error from CoTaskMemAlloc, rc: %d");
  }
  lVar6 = -1;
  do {
    lVar3 = lVar6;
    lVar6 = lVar3 + 1;
  } while (local_138[lVar6] != L'\0');
  do {
    lVar7 = lVar7 + 1;
  } while (local_b8[lVar7] != L'\0');
  lVar2 = StringCchPrintfW(puVar4,lVar3 + 3 + lVar7,(ushort *)L"%s %s",local_b8);
  local_328 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_320 = L"DateTimeToString";
  local_318 = L"ADMUTILC";
  local_310 = 0x4b2;
  local_30c = 7;
  local_308 = 0xff;
  local_288 = 0x1000000;
  local_270 = lVar2;
  memset(local_300,0,0x78);
  local_338 = (_FILETIME)&local_328;
  if (-1 < lVar2) {
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_328);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_278);
    return puVar4;
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_208,(CVssDebugInfo *)&local_328);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
            (local_278,uVar5,lVar2,L"StringCchPrintf");
}



/* ==========================================================================
 * MyGetChar @ 0x14000e8bc  (748 bytes, 166 instructions)
 * ushort MyGetChar(void)
 * unsigned short __cdecl MyGetChar(void)
 * ========================================================================== */

/* unsigned short __cdecl MyGetChar(void) */

ushort __cdecl MyGetChar(void)

{
  DWORD DVar1;
  BOOL BVar2;
  DWORD DVar3;
  DWORD DVar4;
  HANDLE hConsoleHandle;
  undefined8 uVar5;
  uint local_res8 [2];
  ushort local_res10 [4];
  DWORD local_res18 [4];
  undefined8 in_stack_fffffffffffffe88;
  undefined4 uVar6;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  wchar_t *local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined1 local_128 [120];
  undefined4 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  uVar6 = (undefined4)((ulonglong)in_stack_fffffffffffffe88 >> 0x20);
  local_150 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_148 = L"MyGetChar";
  local_140 = L"ADMUTILC";
  local_138 = 0x4d1;
  local_134 = 7;
  local_130 = 0xff;
  local_b0 = 0x1000000;
  memset(local_128,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_150);
  hConsoleHandle = GetStdHandle(0xfffffff6);
  if (hConsoleHandle == (HANDLE)0xffffffffffffffff) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4da,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from GetStdHandle(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  BVar2 = GetConsoleMode(hConsoleHandle,local_res8);
  if (BVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e1,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from GetConsoleMode(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  BVar2 = SetConsoleMode(hConsoleHandle,local_res8[0] & 0xfffffff9);
  if (BVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_150,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e9,7,
                       in_stack_fffffffffffffe98);
    DVar3 = GetLastError();
    DVar4 = GetLastError();
    DVar1 = DVar3 & 0xffff | 0x80070000;
    if ((int)DVar3 < 1) {
      DVar1 = DVar3;
    }
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_a8,uVar5,DVar1,L"MyGetChar - Error from SetConsoleMode(), rc: %d",
               CONCAT44(uVar6,DVar4));
  }
  FlushConsoleInputBuffer(hConsoleHandle);
  uVar6 = 0;
  BVar2 = ReadConsoleW(hConsoleHandle,local_res10,1,local_res18,(PCONSOLE_READCONSOLE_CONTROL)0x0);
  if (BVar2 != 0) {
    SetConsoleMode(hConsoleHandle,local_res8[0]);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
    return local_res10[0];
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_150,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4f6,7,in_stack_fffffffffffffe98)
  ;
  DVar3 = GetLastError();
  DVar4 = GetLastError();
  DVar1 = DVar3 & 0xffff | 0x80070000;
  if ((int)DVar3 < 1) {
    DVar1 = DVar3;
  }
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_a8,uVar5,DVar1,L"MyGetChar - Error from ReadConsoleW(), rc: %d",
             CONCAT44(uVar6,DVar4));
}



/* ==========================================================================
 * IsCorrectContext @ 0x14000ebb4  (85 bytes, 25 instructions)
 * int IsCorrectContext(long param_1)
 * int __cdecl IsCorrectContext(long)
 * ========================================================================== */

/* int __cdecl IsCorrectContext(long) */

int __cdecl IsCorrectContext(long param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if (CVssSKU::ms_bInitialized == 0) {
    CVssSKU::_Initialize_CVssSKU__CAXXZ();
  }
  if ((((CVssSKU::ms_eSKU == 1) && (((param_1 & 0x1fU) - 9 & 0xfffffffb) == 0)) ||
      ((dCurrentSKU & 0xfffffff8) != 0)) || ((param_1 & 0x1fU) == 0x1d)) {
    iVar1 = 1;
  }
  return iVar1;
}



/* ==========================================================================
 * StringCchPrintfA @ 0x14000ec10  (121 bytes, 41 instructions)
 * long StringCchPrintfA(char * param_1, __uint64 param_2, char * param_3, ...)
 * long __cdecl StringCchPrintfA(char * __ptr64,unsigned __int64,char const * __ptr64,...)
 * ========================================================================== */

/* long __cdecl StringCchPrintfA(char * __ptr64,unsigned __int64,char const * __ptr64,...) */

long __cdecl StringCchPrintfA(char *param_1,__uint64 param_2,char *param_3,...)

{
  ulonglong _Count;
  int iVar1;
  int iVar2;
  undefined8 in_R9;
  undefined8 local_res20;
  
  iVar2 = 0;
  if (0x7ffffffe < param_2 - 1) {
    iVar2 = -0x7ff8ffa9;
  }
  if (iVar2 < 0) {
    if (param_2 != 0) {
      *param_1 = '\0';
    }
  }
  else {
    _Count = param_2 - 1;
    iVar2 = 0;
    local_res20 = in_R9;
    iVar1 = _vsnprintf(param_1,_Count,param_3,(va_list)&local_res20);
    if ((iVar1 < 0) || (_Count < (ulonglong)(longlong)iVar1)) {
      param_1[_Count] = '\0';
      iVar2 = -0x7ff8ff86;
    }
    else if ((longlong)iVar1 == _Count) {
      param_1[_Count] = '\0';
    }
  }
  return iVar2;
}



/* ==========================================================================
 * StringCchVPrintfExW @ 0x14000ec90  (255 bytes, 78 instructions)
 * long StringCchVPrintfExW(ushort * param_1, __uint64 param_2, ushort * * param_3, __uint64 * param_4, ulong param_5, ushort * param_6, char * param_7)
 * long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short * __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char * __ptr64)
 * ========================================================================== */

/* long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short *
   __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char *
   __ptr64) */

long __cdecl
StringCchVPrintfExW(ushort *param_1,__uint64 param_2,ushort **param_3,__uint64 *param_4,
                   ulong param_5,ushort *param_6,char *param_7)

{
  ulonglong _Count;
  int iVar1;
  ulonglong uVar2;
  long lVar3;
  __uint64 _Var4;
  
  iVar1 = 0;
  if (0x7ffffffe < param_2 - 1) {
    iVar1 = -0x7ff8ffa9;
  }
  if (iVar1 < 0) {
    if (param_2 == 0) {
      return iVar1;
    }
    *param_1 = 0;
    return iVar1;
  }
  lVar3 = 0;
  if (param_2 == 0) {
    _Var4 = 0;
    if (*param_6 != 0) {
      if (param_1 == (ushort *)0x0) {
        return -0x7ff8ffa9;
      }
      lVar3 = -0x7ff8ff86;
    }
    goto LAB_14000ed53;
  }
  _Count = param_2 - 1;
  iVar1 = _vsnwprintf((wchar_t *)param_1,_Count,(wchar_t *)param_6,param_7);
  if (iVar1 < 0) {
LAB_14000ed2e:
    lVar3 = -0x7ff8ff86;
LAB_14000ed33:
    param_1[_Count] = 0;
    uVar2 = _Count;
  }
  else {
    uVar2 = (ulonglong)iVar1;
    if (_Count < uVar2) goto LAB_14000ed2e;
    if (uVar2 == _Count) goto LAB_14000ed33;
  }
  param_1 = param_1 + uVar2;
  _Var4 = param_2 - uVar2;
  if (((lVar3 + 0x80000000U & 0x80000000) == 0) && (lVar3 != -0x7ff8ff86)) {
    return lVar3;
  }
LAB_14000ed53:
  if (param_3 != (ushort **)0x0) {
    *param_3 = param_1;
  }
  if (param_4 != (__uint64 *)0x0) {
    *param_4 = _Var4;
  }
  return lVar3;
}



/* ==========================================================================
 * ??0bad_alloc@std@@QEAA@PEBD@Z @ 0x14000ed98  (49 bytes, 13 instructions)
 * undefined ??0bad_alloc@std@@QEAA@PEBD@Z(bad_alloc * this, char * param_1)
 * public: __cdecl std::bad_alloc::bad_alloc(char const * __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::bad_alloc::bad_alloc(char const * __ptr64) __ptr64 */

bad_alloc * __thiscall std::bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(bad_alloc *this,char *param_1)

{
  char *local_res10 [3];
  
  local_res10[0] = param_1;
  exception::exception((exception *)this,local_res10);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??1bad_alloc@std@@UEAA@XZ @ 0x14000edd0  (15 bytes, 3 instructions)
 * void ??1bad_alloc@std@@UEAA@XZ(bad_alloc * this)
 * public: virtual __cdecl std::bad_alloc::~bad_alloc(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl std::bad_alloc::~bad_alloc(void) __ptr64 */

void __thiscall std::bad_alloc::__1bad_alloc_std__UEAA_XZ(bad_alloc *this)

{
  *(undefined ***)this = &_vftable_;
  exception::__1exception__UEAA_XZ((exception *)this);
  return;
}



/* ==========================================================================
 * ?_Doraise@bad_alloc@std@@MEBAXXZ @ 0x14000edf0  (34 bytes, 7 instructions)
 * void ?_Doraise@bad_alloc@std@@MEBAXXZ(bad_alloc * this)
 * protected: virtual void __cdecl std::bad_alloc::_Doraise(void)const __ptr64
 * ========================================================================== */

/* protected: virtual void __cdecl std::bad_alloc::_Doraise(void)const __ptr64 */

void __thiscall std::bad_alloc::__Doraise_bad_alloc_std__MEBAXXZ(bad_alloc *this)

{
  bad_alloc local_28 [40];
  
  __0bad_alloc_std__QEAA_AEBV01__Z(local_28,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
}



/* ==========================================================================
 * ??_Gbad_alloc@std@@UEAAPEAXI@Z @ 0x14000ee20  (57 bytes, 17 instructions)
 * void * ??_Gbad_alloc@std@@UEAAPEAXI@Z(bad_alloc * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl std::bad_alloc::`scalar deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl std::bad_alloc::`scalar deleting destructor'(unsigned int)
   __ptr64 */

void * __thiscall std::bad_alloc::___Gbad_alloc_std__UEAAPEAXI_Z(bad_alloc *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  exception::__1exception__UEAA_XZ((exception *)this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ??0bad_alloc@std@@QEAA@AEBV01@@Z @ 0x14000ee60  (33 bytes, 10 instructions)
 * undefined ??0bad_alloc@std@@QEAA@AEBV01@@Z(bad_alloc * this, bad_alloc * param_1)
 * public: __cdecl std::bad_alloc::bad_alloc(class std::bad_alloc const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::bad_alloc::bad_alloc(class std::bad_alloc const & __ptr64) __ptr64 */

bad_alloc * __thiscall
std::bad_alloc::__0bad_alloc_std__QEAA_AEBV01__Z(bad_alloc *this,bad_alloc *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??1CVssOutputBuffer@@QEAA@XZ @ 0x14000ee88  (8 bytes, 2 instructions)
 * void ??1CVssOutputBuffer@@QEAA@XZ(CVssOutputBuffer * this)
 * public: __cdecl CVssOutputBuffer::~CVssOutputBuffer(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssOutputBuffer::~CVssOutputBuffer(void) __ptr64 */

void __thiscall CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ(CVssOutputBuffer *this)

{
  operator_delete__(*(void **)this);
  return;
}



/* ==========================================================================
 * ??BCVssAutoCoString@@QEBAPEAGXZ @ 0x14000ee98  (4 bytes, 2 instructions)
 * ushort * ??BCVssAutoCoString@@QEBAPEAGXZ(CVssAutoCoString * this)
 * public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64
 * ========================================================================== */

/* public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64 */

ushort * __thiscall CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ(CVssAutoCoString *this)

{
  return *(ushort **)this;
}



/* ==========================================================================
 * ??0CVssAutoCoString@@QEAA@XZ @ 0x14000eea4  (8 bytes, 3 instructions)
 * undefined ??0CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this)
 * public: __cdecl CVssAutoCoString::CVssAutoCoString(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssAutoCoString::CVssAutoCoString(void) __ptr64 */

CVssAutoCoString * __thiscall CVssAutoCoString::__0CVssAutoCoString__QEAA_XZ(CVssAutoCoString *this)

{
  *(undefined8 *)this = 0;
  return this;
}



/* ==========================================================================
 * ?Append@CVssAutoCoString@@QEAAXPEBG@Z @ 0x14000eeb4  (530 bytes, 117 instructions)
 * void ?Append@CVssAutoCoString@@QEAAXPEBG@Z(CVssAutoCoString * this, ushort * param_1)
 * public: void __cdecl CVssAutoCoString::Append(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssAutoCoString::Append(unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z(CVssAutoCoString *this,ushort *param_1)

{
  longlong lVar1;
  LPVOID pvVar2;
  undefined8 uVar3;
  longlong lVar4;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdf8;
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined4 local_1d0;
  undefined1 local_1c8 [120];
  undefined4 local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [8];
  long local_90;
  
  local_148 = L"base\\stor\\vss\\inc\\vs_str.hxx";
  local_140 = L"CVssAutoCoString::Append";
  local_138 = L"INCSTRH";
  local_130 = 0x2b9;
  local_12c = 0xb;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  lVar1 = -1;
  lVar4 = -1;
  do {
    lVar4 = lVar4 + 1;
  } while (*(short *)(*(longlong *)this + lVar4 * 2) != 0);
  do {
    lVar1 = lVar1 + 1;
  } while (param_1[lVar1] != 0);
  local_1f0 = L"base\\stor\\vss\\inc\\vs_str.hxx";
  local_1e8 = L"CVssAutoCoString::Reallocate";
  local_1e0 = L"INCSTRH";
  local_1d8 = 0x2b1;
  local_1d4 = 0xb;
  local_1d0 = 0xff;
  local_150 = 0x1000000;
  memset(local_1c8,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
            ((CVssFunctionTracer *)&local_148,&local_1f0);
  pvVar2 = CoTaskMemRealloc(*(LPVOID *)this,(longlong)((int)(lVar4 + lVar1) + 1) * 2);
  if (pvVar2 != (LPVOID)0x0) {
    *(LPVOID *)this = pvVar2;
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)&local_148);
    local_90 = StringCchCatW(*(ushort **)this,lVar4 + lVar1 + 1,param_1);
    if (-1 < local_90) {
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
      return;
    }
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
               (ushort *)L"INCSTRH",(ushort *)L"CVssAutoCoString::Append",0x2c1,0xb,
               in_stack_fffffffffffffdf8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_1f0,(ushort *)L"base\\stor\\vss\\inc\\vs_str.hxx",
                     (ushort *)L"INCSTRH",(ushort *)L"VssReallocString",0x85,0xb,
                     in_stack_fffffffffffffdf8);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            ((CVssFunctionTracer *)&local_148,uVar3,0x8007000e,L"Memory allocation error");
}



/* ==========================================================================
 * ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z @ 0x14000f0d0  (153 bytes, 43 instructions)
 * bool ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z(CVssAutoCoString * this, ushort * param_1)
 * public: bool __cdecl CVssAutoCoString::CopyFrom(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: bool __cdecl CVssAutoCoString::CopyFrom(unsigned short const * __ptr64) __ptr64 */

bool __thiscall
CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z(CVssAutoCoString *this,ushort *param_1)

{
  ushort *puVar1;
  longlong lVar2;
  longlong lVar3;
  bool bVar4;
  
  CoTaskMemFree(*(LPVOID *)this);
  lVar2 = 0;
  *(undefined8 *)this = 0;
  if (param_1 != (ushort *)0x0) {
    lVar2 = -1;
    do {
      lVar2 = lVar2 + 1;
    } while (param_1[lVar2] != 0);
    puVar1 = CoTaskMemAlloc(lVar2 * 2 + 2);
    *(ushort **)this = puVar1;
    bVar4 = true;
    lVar2 = -1;
    if (puVar1 == (ushort *)0x0) goto LAB_14000f151;
    do {
      lVar3 = lVar2;
      lVar2 = lVar3 + 1;
    } while (param_1[lVar2] != 0);
    StringCchCopyW(puVar1,lVar3 + 2,param_1);
    lVar2 = *(longlong *)this;
  }
  bVar4 = lVar2 == 0;
LAB_14000f151:
  return !bVar4;
}



/* ==========================================================================
 * InternalThrow @ 0x14000f170  (33 bytes, 6 instructions)
 * void InternalThrow(long param_1)
 * void __cdecl InternalThrow(long)
 * ========================================================================== */

/* void __cdecl InternalThrow(long) */

void __cdecl InternalThrow(long param_1)

{
  undefined4 local_res8 [8];
  
  local_res8[0] = 0x8000ffff;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
}



/* ==========================================================================
 * ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@I@Z @ 0x14000f198  (520 bytes, 113 instructions)
 * basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@I@Z(CVssResource * this, uint param_1)
 * public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> __cdecl CVssResource::LoadStringW(unsigned int) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> __cdecl CVssResource::LoadStringW(unsigned int)
   __ptr64 */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
CVssResource::
_LoadStringW_CVssResource__QEAA_AV__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__I_Z
          (CVssResource *this,uint param_1)

{
  int iVar1;
  WCHAR *pWVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined4 in_register_00000014;
  UINT in_R8D;
  undefined1 auStackY_158 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffed8;
  CVssDebugInfo local_108 [168];
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  local_60 [8];
  WCHAR local_58;
  undefined6 uStack_56;
  undefined8 local_48;
  ulonglong local_40;
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_158;
  if (`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
      ::__l2::hMod == (HINSTANCE__ *)0x0) {
    `public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
    ::__l2::hMod = LoadLibraryExW(L"vsstrace.dll",(HANDLE)0x0,2);
    if (`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
        ::__l2::hMod == (HMODULE)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_108,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                         (ushort *)L"TRCTRCC",(ushort *)L"CVssResource::LoadStringW",0x4c,0xb,
                         in_stack_fffffffffffffed8);
      GetLastError();
      CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
                (uVar3,0x28,L"VssLoadString",L"Error loading VSS.DLL [0x%08lx]");
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)uVar3);
    }
  }
  local_40 = 7;
  local_48 = 0;
  local_58 = L'\0';
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
            (local_60,0x401,0);
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
  }
  for (lVar4 = 0x401; lVar4 != 0; lVar4 = lVar4 + -1) {
    *pWVar2 = L'\0';
    pWVar2 = pWVar2 + 1;
  }
  local_48 = 0x401;
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
  }
  pWVar2[0x401] = L'\0';
  pWVar2 = &local_58;
  if (7 < local_40) {
    pWVar2 = (LPWSTR)CONCAT62(uStack_56,local_58);
  }
  iVar1 = LoadStringW(`public:_class_std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>___cdecl_CVssResource::LoadStringW(unsigned_int)___ptr64'
                      ::__l2::hMod,in_R8D,pWVar2,0x401);
  if (iVar1 != 0) {
    pWVar2 = &local_58;
    if (7 < local_40) {
      pWVar2 = (WCHAR *)CONCAT62(uStack_56,local_58);
    }
    std::
    basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
    ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
              ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                *)CONCAT44(in_register_00000014,param_1),(ushort *)pWVar2);
    if (7 < local_40) {
      operator_delete__((void *)CONCAT62(uStack_56,local_58));
    }
    return (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
            *)CONCAT44(in_register_00000014,param_1);
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    (local_108,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                     (ushort *)L"TRCTRCC",(ushort *)L"CVssResource::LoadStringW",0x61,0xb,
                     in_stack_fffffffffffffed8);
  GetLastError();
  CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
            (uVar3,0x28,L"VssLoadString",
             L"Error loading VSS.DLL resource with ID = 0x%08lx [0x%08lx]");
                    /* WARNING: Subroutine does not return */
  InternalThrow((long)uVar3);
}



/* ==========================================================================
 * ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z @ 0x14000f3ac  (75 bytes, 20 instructions)
 * undefined ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5, _VSSDBG_SEV_ENUM param_6)
 * public: __cdecl CVssDebugInfo::CVssDebugInfo(unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long,enum _VSSDBG_SEV_ENUM) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssDebugInfo::CVssDebugInfo(unsigned short const * __ptr64,unsigned short const
   * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long,enum _VSSDBG_SEV_ENUM)
   __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,ushort *param_1,ushort *param_2,ushort *param_3,ulong param_4,
          ulong param_5,_VSSDBG_SEV_ENUM param_6)

{
  *(ushort **)this = param_1;
  *(ulong *)(this + 0x18) = param_4;
  *(ushort **)(this + 0x10) = param_2;
  *(ushort **)(this + 8) = param_3;
  *(ulong *)(this + 0x1c) = param_5;
  *(undefined4 *)(this + 0x20) = 0xff;
  *(undefined4 *)(this + 0xa0) = 0x1000000;
  memset(this + 0x28,0,0x78);
  return this;
}



/* ==========================================================================
 * ??0CVssDebugInfo@@QEAA@AEBU0@@Z @ 0x14000f400  (122 bytes, 30 instructions)
 * undefined ??0CVssDebugInfo@@QEAA@AEBU0@@Z(CVssDebugInfo * this, CVssDebugInfo * param_1)
 * public: __cdecl CVssDebugInfo::CVssDebugInfo(struct CVssDebugInfo const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssDebugInfo::CVssDebugInfo(struct CVssDebugInfo const & __ptr64) __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(CVssDebugInfo *this,CVssDebugInfo *param_1)

{
  CVssDebugInfo *pCVar1;
  longlong lVar2;
  
  *(undefined8 *)this = *(undefined8 *)param_1;
  lVar2 = 0xf;
  *(undefined8 *)(this + 0x10) = *(undefined8 *)(param_1 + 0x10);
  *(undefined8 *)(this + 8) = *(undefined8 *)(param_1 + 8);
  *(undefined4 *)(this + 0x18) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(this + 0x1c) = *(undefined4 *)(param_1 + 0x1c);
  *(undefined2 *)(this + 0xa0) = *(undefined2 *)(param_1 + 0xa0);
  this[0xa2] = param_1[0xa2];
  *(undefined4 *)(this + 0x20) = *(undefined4 *)(param_1 + 0x20);
  this[0xa3] = param_1[0xa3];
  pCVar1 = this + 0x28;
  param_1[0xa3] = (CVssDebugInfo)0x0;
  do {
    *(undefined8 *)pCVar1 = *(undefined8 *)(pCVar1 + ((longlong)param_1 - (longlong)this));
    pCVar1 = pCVar1 + 8;
    lVar2 = lVar2 + -1;
  } while (lVar2 != 0);
  return this;
}



/* ==========================================================================
 * ??1CVssDebugInfo@@QEAA@XZ @ 0x14000f484  (73 bytes, 20 instructions)
 * void ??1CVssDebugInfo@@QEAA@XZ(CVssDebugInfo * this)
 * public: __cdecl CVssDebugInfo::~CVssDebugInfo(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssDebugInfo::~CVssDebugInfo(void) __ptr64 */

void __thiscall CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(CVssDebugInfo *this)

{
  CVssDebugInfo *pCVar1;
  longlong lVar2;
  
  if (this[0xa3] != (CVssDebugInfo)0x0) {
    pCVar1 = this + 0x28;
    lVar2 = 0xf;
    do {
      if (*(LPVOID *)pCVar1 != (LPVOID)0x0) {
        CoTaskMemFree(*(LPVOID *)pCVar1);
        *(undefined8 *)pCVar1 = 0;
      }
      pCVar1 = pCVar1 + 8;
      lVar2 = lVar2 + -1;
    } while (lVar2 != 0);
  }
  return;
}



/* ==========================================================================
 * ??6CVssDebugInfo@@QEAA?AU0@J@Z @ 0x14000f4d4  (321 bytes, 76 instructions)
 * CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@J@Z(CVssDebugInfo * this, long param_1)
 * public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(long) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(long) __ptr64 */

ushort * __thiscall CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(CVssDebugInfo *this,long param_1)

{
  DWORD DVar1;
  HMODULE hLibModule;
  undefined4 in_register_00000014;
  DWORD in_R8D;
  undefined1 auStackY_8c8 [32];
  WCHAR local_888 [520];
  ushort local_478 [544];
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_8c8;
  hLibModule = LoadLibraryExW(L"vsstrace.dll",(HANDLE)0x0,2);
  DVar1 = FormatMessageW(0x1200,(LPCVOID)0x0,in_R8D,0x400,local_888,0x200,(va_list *)0x0);
  if (DVar1 == 0) {
    DVar1 = FormatMessageW(0xa00,hLibModule,in_R8D,0x400,local_888,0x200,(va_list *)0x0);
    if (DVar1 == 0) {
      local_888[0] = L'\0';
    }
  }
  if (hLibModule != (HMODULE)0x0) {
    FreeLibrary(hLibModule);
  }
  if (local_888[0] == L'\0') {
    StringCchPrintfW(local_478,0x21f,(ushort *)L"0x%08lx",(ulonglong)in_R8D);
  }
  else {
    StringCchPrintfW(local_478,0x21f,(ushort *)L"0x%08lx, %s",(ulonglong)in_R8D);
  }
  __6CVssDebugInfo__QEAA_AU0_PEBG_Z(this,(ushort *)CONCAT44(in_register_00000014,param_1));
  return (ushort *)CONCAT44(in_register_00000014,param_1);
}



/* ==========================================================================
 * ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z @ 0x14000f61c  (289 bytes, 77 instructions)
 * CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z(CVssDebugInfo * this, _GUID * param_1)
 * public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(struct _GUID) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(struct _GUID) __ptr64 */

_GUID * __thiscall
CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(CVssDebugInfo *this,_GUID *param_1)

{
  undefined1 auVar1 [16];
  undefined1 (*in_R8) [16];
  undefined1 auStack_138 [32];
  uint local_118;
  uint local_110;
  uint local_108;
  uint local_100;
  uint local_f8;
  uint local_f0;
  uint local_e8;
  uint local_e0;
  uint local_d8;
  uint local_d0;
  ushort local_c8 [64];
  ulonglong local_48;
  
  local_48 = __security_cookie ^ (ulonglong)auStack_138;
  auVar1 = *in_R8;
  local_d8 = auVar1._14_2_ & 0xff;
  local_e0 = auVar1._12_4_ >> 8 & 0xff;
  local_e8 = auVar1._12_4_ & 0xff;
  local_f0 = auVar1._11_4_ & 0xff;
  local_f8 = auVar1._10_4_ & 0xff;
  local_100 = auVar1._9_4_ & 0xff;
  local_118 = auVar1._4_4_ & 0xffff;
  local_d0 = (uint)auVar1[0xf];
  local_108 = (uint)auVar1[8];
  local_110 = (uint)auVar1._6_2_;
  StringCchPrintfW(local_c8,0x3d,(ushort *)L"{%.8x-%.4x-%.4x-%.2x%.2x-%.2x%.2x%.2x%.2x%.2x%.2x}");
  __6CVssDebugInfo__QEAA_AU0_PEBG_Z(this,(ushort *)param_1);
  return param_1;
}



/* ==========================================================================
 * ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z @ 0x14000f744  (209 bytes, 55 instructions)
 * CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z(CVssDebugInfo * this, ushort * param_1)
 * public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator<<(unsigned short const * __ptr64)
   __ptr64 */

ushort * __thiscall
CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(CVssDebugInfo *this,ushort *param_1)

{
  ushort *puVar1;
  longlong lVar2;
  __uint64 _Var4;
  ushort *in_R8;
  longlong lVar3;
  
  if ((((in_R8 != (ushort *)0x0) && (this[0xa2] == (CVssDebugInfo)0x0)) &&
      (this[0xa3] != (CVssDebugInfo)0x0)) && (*(ushort *)(this + 0xa0) < 0xf)) {
    lVar2 = -1;
    do {
      lVar3 = lVar2;
      lVar2 = lVar3 + 1;
    } while (in_R8[lVar2] != 0);
    _Var4 = lVar3 + 2;
    puVar1 = CoTaskMemAlloc(_Var4 * 2);
    if (puVar1 == (ushort *)0x0) {
      this[0xa2] = (CVssDebugInfo)0x1;
    }
    else {
      StringCchCopyW(puVar1,_Var4,in_R8);
      *(ushort **)(this + (ulonglong)*(ushort *)(this + 0xa0) * 8 + 0x28) = puVar1;
      *(short *)(this + 0xa0) = *(short *)(this + 0xa0) + 1;
    }
  }
  __0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)param_1,this);
  return param_1;
}



/* ==========================================================================
 * ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z @ 0x14000f81c  (33 bytes, 9 instructions)
 * CVssDebugInfo ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1)
 * public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator()(enum _VSSDBG_SEV_ENUM) __ptr64
 * ========================================================================== */

/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator()(enum _VSSDBG_SEV_ENUM) __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,_VSSDBG_SEV_ENUM param_1)

{
  undefined4 in_register_00000014;
  CVssDebugInfo *this_00;
  
  this_00 = (CVssDebugInfo *)CONCAT44(in_register_00000014,param_1);
  *(undefined4 *)(this + 0x20) = 100;
  __0CVssDebugInfo__QEAA_AEBU0__Z(this_00,this);
  return this_00;
}



/* ==========================================================================
 * ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z @ 0x14000f844  (14 bytes, 4 instructions)
 * ulong ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1)
 * public: unsigned long __cdecl CVssDebugInfo::InterpretSeverityLevel(enum _VSSDBG_SEV_ENUM) __ptr64
 * ========================================================================== */

/* public: unsigned long __cdecl CVssDebugInfo::InterpretSeverityLevel(enum _VSSDBG_SEV_ENUM)
   __ptr64 */

ulong __thiscall
CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,_VSSDBG_SEV_ENUM param_1)

{
  if (*(int *)(this + 0x20) != 0xff) {
    param_1 = *(_VSSDBG_SEV_ENUM *)(this + 0x20);
  }
  return param_1;
}



/* ==========================================================================
 * ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z @ 0x14000f85c  (242 bytes, 64 instructions)
 * undefined ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2)
 * public: __cdecl CVssFunctionTracer::CVssFunctionTracer(struct CVssDebugInfo,unsigned short * __ptr64 const) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssFunctionTracer::CVssFunctionTracer(struct CVssDebugInfo,unsigned short *
   __ptr64 const) __ptr64 */

CVssFunctionTracer * __thiscall
CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3)

{
  DWORD DVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  undefined8 local_res18 [2];
  
  iVar3 = 0;
  *(undefined4 *)(this + 8) = 0;
  *(undefined8 *)(this + 0x28) = *(undefined8 *)(param_2 + 8);
  *(undefined8 *)(this + 0x10) = *(undefined8 *)param_2;
  *(undefined8 *)(this + 0x18) = *(undefined8 *)(param_2 + 0x10);
  *(undefined4 *)(this + 0x20) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(this + 0x24) = *(undefined4 *)(param_2 + 0x1c);
  local_res18[0] = param_3;
  DVar1 = GetTickCount();
  *(undefined4 *)(this + 4) = 0xffffffff;
  *(DWORD *)(this + 0x34) = DVar1;
  *(undefined4 *)(this + 0x38) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)this = 0;
  *(undefined8 *)(this + 0x60) = 0;
  *(undefined8 *)(this + 0x40) = 0;
  *(undefined8 *)(this + 0x48) = 0;
  local_res18[0] = 0;
  *(undefined8 *)(this + 0x50) = 0;
  *(undefined8 *)(this + 0x58) = 0;
  iVar2 = Ordinal_10(local_res18);
  if (-1 < iVar2) {
    iVar2 = Ordinal_9(this);
    if (-1 < iVar2) {
      *(undefined8 *)(this + 0x60) = local_res18[0];
    }
  }
  if (*(longlong *)(this + 0x60) != 0) {
    iVar3 = *(int *)(*(longlong *)(this + 0x60) + 0x30) + 1;
  }
  *(int *)(this + 0x30) = iVar3;
  uVar4 = 0xa0;
  if (*(int *)(this + 0x38) != 0xff) {
    uVar4 = *(ulong *)(this + 0x38);
  }
  _TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z(this,(ushort *)L"ENTER",uVar4,(ushort *)0x0);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return this;
}



/* ==========================================================================
 * ??1CVssFunctionTracer@@QEAA@XZ @ 0x14000f958  (271 bytes, 69 instructions)
 * void ??1CVssFunctionTracer@@QEAA@XZ(CVssFunctionTracer * this)
 * public: __cdecl CVssFunctionTracer::~CVssFunctionTracer(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssFunctionTracer::~CVssFunctionTracer(void) __ptr64 */

void __thiscall CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(CVssFunctionTracer *this)

{
  DWORD DVar1;
  uint uVar2;
  CVssFunctionTracer *pCVar3;
  longlong lVar4;
  ulong uVar5;
  
  pCVar3 = this + 0x40;
  lVar4 = 4;
  do {
    CoTaskMemFree(*(LPVOID *)pCVar3);
    *(undefined8 *)pCVar3 = 0;
    pCVar3 = pCVar3 + 8;
    lVar4 = lVar4 + -1;
  } while (lVar4 != 0);
  DVar1 = GetTickCount();
  uVar2 = DVar1 - *(int *)(this + 0x34);
  uVar5 = 0xa0;
  if (*(int *)(this + 0x38) != 0xff) {
    uVar5 = *(ulong *)(this + 0x38);
  }
  _TraceInternalWithFormat_CVssFunctionTracer__QEAAXPEBGK0ZZ
            (this,(ushort *)L"EXIT",uVar5,
             (ushort *)L"Time spent: %02ld:%02ld:%02ld-%04ld; total: %#x; HRESULT: %#x",
             (int)((ulonglong)uVar2 / 3600000) + (int)(((ulonglong)uVar2 / 3600000) / 0x3c) * -0x3c,
             (uVar2 / 60000) % 0x3c,(uVar2 / 1000) % 0x3c,uVar2 % 1000,uVar2,
             *(undefined4 *)(this + 8));
                    /* WARNING: Could not recover jumptable at 0x00014000fa60. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  Ordinal_9(*(undefined8 *)(this + 0x60));
  return;
}



/* ==========================================================================
 * ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z @ 0x14000fa74  (74 bytes, 23 instructions)
 * int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z(CVssFunctionTracer * this, ulong param_1)
 * public: int __cdecl CVssFunctionTracer::IsTracingEnabled(unsigned long) __ptr64
 * ========================================================================== */

/* public: int __cdecl CVssFunctionTracer::IsTracingEnabled(unsigned long) __ptr64 */

int __thiscall
CVssFunctionTracer::_IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z
          (CVssFunctionTracer *this,ulong param_1)

{
  int iVar1;
  
  iVar1 = Ordinal_5();
  if ((iVar1 != 0) && (iVar1 = Ordinal_7(param_1), iVar1 != 0)) {
    _UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ(this);
    return *(int *)this;
  }
  return 0;
}



/* ==========================================================================
 * ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ @ 0x14000fac8  (8 bytes, 2 instructions)
 * int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ(CVssFunctionTracer * this)
 * public: int __cdecl CVssFunctionTracer::IsTracingEnabled(void) __ptr64
 * ========================================================================== */

/* public: int __cdecl CVssFunctionTracer::IsTracingEnabled(void) __ptr64 */

int __thiscall
CVssFunctionTracer::_IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(CVssFunctionTracer *this)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  return iVar1;
}



/* ==========================================================================
 * ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ @ 0x14000fad8  (408 bytes, 87 instructions)
 * void ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ(CVssFunctionTracer * this)
 * private: void __cdecl CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag(void) __ptr64 */

void __thiscall
CVssFunctionTracer::_UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ
          (CVssFunctionTracer *this)

{
  int iVar1;
  int iVar2;
  LPWSTR pWVar3;
  CVssFunctionTracer *this_00;
  ulong uVar4;
  undefined1 auStack_918 [32];
  wchar_t *local_8f8;
  DWORD local_8f0;
  LPWSTR local_8e8;
  CVssFunctionTracer *local_8e0;
  ulong local_8d8;
  undefined4 local_8d0;
  int local_8c8 [2];
  wchar_t *local_8c0;
  wchar_t *local_8b8;
  wchar_t *local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a4;
  undefined4 local_8a0;
  undefined1 local_898 [120];
  undefined4 local_820;
  CVssFunctionTracer local_818 [2048];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_918;
  iVar1 = Ordinal_11();
  if (iVar1 != *(int *)(this + 4)) {
    local_8c8[0] = 0;
    *(int *)(this + 4) = iVar1;
    iVar2 = Ordinal_8(*(undefined4 *)(this + 0x24),*(undefined8 *)(this + 0x28),local_8c8);
    iVar1 = local_8c8[0];
    if (iVar2 == 0) {
      if (*(CVssFunctionTracer **)(this + 0x60) == (CVssFunctionTracer *)0x0) {
        iVar1 = Ordinal_6();
      }
      else {
        iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(*(CVssFunctionTracer **)(this + 0x60))
        ;
      }
    }
    *(int *)this = iVar1;
    if (m_dwGlobalTracingSettingsSequenceNumber != *(ulong *)(this + 4)) {
      uVar4 = 0x800;
      this_00 = local_818;
      memset(local_818,0,0x800);
      _GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z(this_00,(ushort *)local_818,uVar4);
      local_8a8 = 0x24f;
      local_8c0 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
      local_8a4 = 0xb;
      local_8a0 = 0xff;
      local_8b8 = L"CVssFunctionTracer::UpdateLocalIsTracingEnabledFlag";
      local_8b0 = L"TRCTRCC";
      local_820 = 0x1000000;
      memset(local_898,0,0x78);
      pWVar3 = GetCommandLineW();
      local_8f0 = GetCurrentProcessId();
      local_8d0 = *(undefined4 *)(this + 4);
      local_8d8 = m_dwGlobalTracingSettingsSequenceNumber;
      local_8f8 = 
      L"Tracing started or updated. PID=%d, CommandLine=[%s], UserName=[%s]. SQN=[%d -> %d]";
      local_8e8 = pWVar3;
      local_8e0 = local_818;
      _TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
                (this,&local_8c0,L"TRACING_STARTED",0x78);
      m_dwGlobalTracingSettingsSequenceNumber = *(ulong *)(this + 4);
    }
  }
  return;
}



/* ==========================================================================
 * ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ @ 0x14000fc78  (316 bytes, 83 instructions)
 * void ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ(CVssDebugInfo param_1, ulong param_2, ushort * param_3, ushort * param_4, ...)
 * public: static void __cdecl CVssFunctionTracer::StaticTrace(struct CVssDebugInfo,unsigned long,unsigned short const * __ptr64,unsigned short const * __ptr64,...)
 * ========================================================================== */

/* public: static void __cdecl CVssFunctionTracer::StaticTrace(struct CVssDebugInfo,unsigned
   long,unsigned short const * __ptr64,unsigned short const * __ptr64,...) */

void __cdecl
CVssFunctionTracer::_StaticTrace_CVssFunctionTracer__SAXUCVssDebugInfo__KPEBG1ZZ
          (CVssDebugInfo *param_1,undefined4 param_2,undefined8 param_3,ushort *param_4,...)

{
  int iVar1;
  wchar_t *pwVar2;
  undefined4 uVar3;
  ulong in_stack_ffffffffffffff78;
  wchar_t *pwVar4;
  CVssFunctionTracer *local_58;
  __uint64 local_50;
  ushort *local_48 [3];
  
  iVar1 = Ordinal_5();
  if (iVar1 != 0) {
    local_58 = (CVssFunctionTracer *)0x0;
    iVar1 = Ordinal_10(&local_58);
    if (-1 < iVar1) {
      uVar3 = 0;
      if (local_58 != (CVssFunctionTracer *)0x0) {
        iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(local_58,*(ulong *)(param_1 + 0x1c));
        if (iVar1 == 0) goto LAB_14000fd9f;
        uVar3 = *(undefined4 *)(local_58 + 0x30);
      }
      pwVar2 = operator_new__(0x3ea,&std::nothrow);
      if (pwVar2 == (wchar_t *)0x0) {
        pwVar4 = L"StaticTrace failed due to out of memory condition";
      }
      else {
        local_50 = 0;
        local_48[0] = (ushort *)0x0;
        StringCchVPrintfExW((ushort *)pwVar2,500,local_48,&local_50,in_stack_ffffffffffffff78,
                            param_4,&stack0x00000028);
        pwVar4 = pwVar2;
        if (local_50 == 1) {
          local_48[0][-2] = 0x2e;
          local_48[0][-1] = 0x2e;
          local_48[0][-3] = 0x2e;
        }
      }
      Ordinal_3(*(undefined8 *)param_1,*(undefined8 *)(param_1 + 0x10),
                *(undefined4 *)(param_1 + 0x18),uVar3,*(undefined4 *)(param_1 + 0x1c),param_3,
                L"STATIC",param_2,pwVar4);
      operator_delete__(pwVar2);
    }
  }
LAB_14000fd9f:
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_1);
  return;
}



/* ==========================================================================
 * ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z @ 0x14000fdbc  (123 bytes, 32 instructions)
 * void ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3)
 * public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned
   long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2,ushort *param_3)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    Ordinal_3(*(undefined8 *)(this + 0x10),*(undefined8 *)(this + 0x18),*(undefined4 *)(this + 0x20)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(this + 0x24),
              *(undefined8 *)(this + 0x28),param_1,param_2,param_3);
  }
  return;
}



/* ==========================================================================
 * ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z @ 0x14000fe40  (134 bytes, 33 instructions)
 * void ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4)
 * public: void __cdecl CVssFunctionTracer::TraceInternal(struct CVssDebugInfo,unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TraceInternal(struct CVssDebugInfo,unsigned short const
   * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined4 param_4,
          undefined8 param_5)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(this);
  if (iVar1 != 0) {
    Ordinal_3(*(undefined8 *)param_2,*(undefined8 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x18)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(param_2 + 0x1c),
              *(undefined8 *)(this + 0x28),param_3,param_4,param_5);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}



/* ==========================================================================
 * ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ @ 0x14000fecc  (196 bytes, 51 instructions)
 * void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3, ...)
 * public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(unsigned short const *
   __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternalWithFormat_CVssFunctionTracer__QEAAXPEBGK0ZZ
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2,ushort *param_3,...)

{
  int iVar1;
  wchar_t *pwVar2;
  wchar_t *pwVar3;
  ulong in_stack_ffffffffffffffa8;
  __uint64 local_38;
  ushort *local_30 [2];
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    pwVar2 = operator_new__(0x3ea,&std::nothrow);
    if (pwVar2 == (wchar_t *)0x0) {
      pwVar3 = L"TraceInternalWithFormat failed due to out of memory condition";
    }
    else {
      local_38 = 0;
      local_30[0] = (ushort *)0x0;
      StringCchVPrintfExW((ushort *)pwVar2,500,local_30,&local_38,in_stack_ffffffffffffffa8,param_3,
                          &stack0x00000028);
      pwVar3 = pwVar2;
      if (local_38 == 1) {
        local_30[0][-2] = 0x2e;
        local_30[0][-1] = 0x2e;
        local_30[0][-3] = 0x2e;
      }
    }
    _TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z(this,param_1,param_2,(ushort *)pwVar3);
    operator_delete__(pwVar2);
  }
  return;
}



/* ==========================================================================
 * ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ @ 0x14000ff98  (298 bytes, 74 instructions)
 * void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4, ...)
 * public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(struct CVssDebugInfo,unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(struct CVssDebugInfo,unsigned
   short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined4 param_4,
          ushort *param_5,...)

{
  undefined4 uVar1;
  int iVar2;
  wchar_t *pwVar3;
  undefined8 uVar4;
  ulong in_stack_fffffffffffffef8;
  wchar_t *pwVar5;
  __uint64 local_e8;
  ushort *local_e0;
  CVssDebugInfo local_d8 [176];
  
  uVar1 = *(undefined4 *)(param_2 + 0x1c);
  iVar2 = Ordinal_5();
  if (iVar2 != 0) {
    iVar2 = Ordinal_7(uVar1);
    if (iVar2 != 0) {
      _UpdateLocalIsTracingEnabledFlag_CVssFunctionTracer__AEAAXXZ(this);
      if (*(int *)this != 0) {
        pwVar3 = operator_new__(0x3ea,&std::nothrow);
        if (pwVar3 == (wchar_t *)0x0) {
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
          pwVar5 = L"TraceInternalWithFormat failed due to out of memory condition";
        }
        else {
          local_e8 = 0;
          local_e0 = (ushort *)0x0;
          StringCchVPrintfExW((ushort *)pwVar3,500,&local_e0,&local_e8,in_stack_fffffffffffffef8,
                              param_5,&stack0x00000030);
          if (local_e8 == 1) {
            local_e0[-2] = 0x2e;
            local_e0[-1] = 0x2e;
            local_e0[-3] = 0x2e;
          }
          uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
          pwVar5 = pwVar3;
        }
        _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                  (this,uVar4,param_3,param_4,pwVar5);
        operator_delete__(pwVar3);
      }
    }
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}



/* ==========================================================================
 * ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ @ 0x1400100cc  (577 bytes, 134 instructions)
 * ushort * ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ(CVssFunctionTracer * this)
 * public: unsigned short * __ptr64 __cdecl CVssFunctionTracer::GetCurrentContexts(void) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: unsigned short * __ptr64 __cdecl CVssFunctionTracer::GetCurrentContexts(void) __ptr64 */

ushort * __thiscall
CVssFunctionTracer::_GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(CVssFunctionTracer *this)

{
  bool bVar1;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *pbVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  CVssResource *this_00;
  ushort *puVar6;
  int iVar7;
  CVssFunctionTracer *pCVar8;
  __uint64 _Var9;
  code *pcVar10;
  undefined1 auStackY_168 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffec8;
  ushort *local_128 [2];
  undefined8 local_118;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  local_108 [8];
  void *local_100;
  ulonglong local_e8;
  CVssDebugInfo local_d8 [8];
  ushort local_d0 [8];
  ulonglong auStack_c0 [19];
  ulonglong local_28;
  
  local_118 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_168;
  local_128[0] = (ushort *)0x0;
  bVar1 = CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z
                    ((CVssAutoCoString *)local_128,(ushort *)L"");
  if (!bVar1) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_d8,(ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                       (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::GetCurrentContexts",
                       0x37b,0xb,in_stack_fffffffffffffec8);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar5,0x8007000e,L"internal tracing buffer - out of memory");
  }
  pcVar10 = std::
            basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
            ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ;
  _Var9 = 4;
  _eh_vector_constructor_iterator_
            (local_d8,0x28,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ);
  for (iVar7 = 0; pCVar8 = this, iVar7 < 4; iVar7 = iVar7 + 1) {
    for (; pCVar8 != (CVssFunctionTracer *)0x0; pCVar8 = *(CVssFunctionTracer **)(pCVar8 + 0x60)) {
      if (*(ushort **)(pCVar8 + (longlong)iVar7 * 8 + 0x40) != (ushort *)0x0) {
        pbVar2 = (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                  *)std::
                    basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                    ::
                    __0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
                              (local_108,*(ushort **)(pCVar8 + (longlong)iVar7 * 8 + 0x40));
        std::
        basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
        ::
        _append___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                  ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                    *)(local_d8 + (longlong)iVar7 * 0x28),pbVar2,_Var9,(__uint64)pcVar10);
        if (7 < local_e8) {
          operator_delete__(local_100);
        }
      }
    }
  }
  for (iVar7 = 0; iVar7 < 4; iVar7 = iVar7 + 1) {
    lVar3 = (longlong)iVar7;
    if (auStack_c0[lVar3 * 5] != 0) {
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z
                ((CVssAutoCoString *)local_128,(ushort *)L"\n\n");
      if (iVar7 == 0) {
        this_00 = (CVssResource *)0x0;
      }
      else if (iVar7 == 1) {
        this_00 = (CVssResource *)0x0;
      }
      else {
        this_00 = (CVssResource *)(ulonglong)(iVar7 - 2);
      }
      lVar4 = CVssResource::
              _LoadStringW_CVssResource__QEAA_AV__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__I_Z
                        (this_00,(uint)local_108);
      puVar6 = (ushort *)(lVar4 + 8);
      if (7 < *(ulonglong *)(lVar4 + 0x20)) {
        puVar6 = *(ushort **)puVar6;
      }
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z((CVssAutoCoString *)local_128,puVar6);
      if (7 < local_e8) {
        operator_delete__(local_100);
      }
      puVar6 = local_d0 + lVar3 * 0x14;
      if (7 < auStack_c0[lVar3 * 5 + 1]) {
        puVar6 = *(ushort **)puVar6;
      }
      CVssAutoCoString::_Append_CVssAutoCoString__QEAAXPEBG_Z((CVssAutoCoString *)local_128,puVar6);
    }
  }
  _eh_vector_destructor_iterator_
            (local_d8,0x28,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ);
  CoTaskMemFree((LPVOID)0x0);
  return local_128[0];
}



/* ==========================================================================
 * ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z @ 0x140010318  (496 bytes, 104 instructions)
 * void ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2)
 * public: void __cdecl CVssFunctionTracer::GetCurrentUserName(unsigned short * __ptr64,unsigned long) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssFunctionTracer::GetCurrentUserName(unsigned short * __ptr64,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2)

{
  BOOL BVar1;
  int iVar2;
  HANDLE pvVar3;
  undefined1 auStackY_588 [32];
  HANDLE local_558;
  DWORD local_550 [4];
  HLOCAL local_540;
  _SID_NAME_USE local_538 [4];
  PSID local_528 [32];
  wchar_t local_428 [8];
  undefined1 local_418 [496];
  wchar_t local_228 [8];
  undefined1 local_218 [496];
  ulonglong local_28;
  
  local_28 = __security_cookie ^ (ulonglong)auStackY_588;
  *param_1 = 0;
  local_558 = (HANDLE)0x0;
  pvVar3 = GetCurrentThread();
  BVar1 = OpenThreadToken(pvVar3,8,1,&local_558);
  if (BVar1 == 0) {
    pvVar3 = GetCurrentProcess();
    BVar1 = OpenProcessToken(pvVar3,8,&local_558);
    if (BVar1 == 0) {
      return;
    }
  }
  local_550[0] = 0;
  BVar1 = GetTokenInformation(local_558,TokenUser,local_528,0x100,local_550);
  if (BVar1 == 0) {
    CloseHandle(local_558);
  }
  else {
    CloseHandle(local_558);
    builtin_wcsncpy(local_228,L"Unknown",8);
    memset(local_218,0,0x1f0);
    builtin_wcsncpy(local_428,L"Unknown",8);
    memset(local_418,0,0x1f0);
    local_550[2] = 0x100;
    local_550[1] = 0x100;
    BVar1 = LookupAccountSidLocalW
                      (local_528[0],local_428,local_550 + 2,local_228,local_550 + 1,local_538);
    if (BVar1 != 0) {
      local_540 = (HLOCAL)0x0;
      iVar2 = ConvertSidToStringSidW(local_528[0],&local_540);
      if (iVar2 != 0) {
        StringCchPrintfW(param_1,0x400,(ushort *)L"Name: %s\\%s, SID:%s",local_228);
        LocalFree(local_540);
      }
    }
  }
  return;
}



/* ==========================================================================
 * ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ @ 0x140010510  (245 bytes, 56 instructions)
 * void ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * public: void __cdecl CVssFunctionTracer::Trace(struct CVssDebugInfo,unsigned short * __ptr64 const,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::Trace(struct CVssDebugInfo,unsigned short * __ptr64
   const,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  int iVar1;
  ushort *puVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  undefined8 local_res20;
  ulong in_stack_ffffffffffffff08;
  __uint64 local_d8;
  ushort *local_d0;
  CVssDebugInfo local_c8 [176];
  
  local_res20 = param_4;
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    puVar2 = operator_new__(0x3ea,&std::nothrow);
    if (puVar2 != (ushort *)0x0) {
      local_d8 = 0;
      local_d0 = (ushort *)0x0;
      StringCchVPrintfExW(puVar2,500,&local_d0,&local_d8,in_stack_ffffffffffffff08,param_3,
                          (char *)&local_res20);
      if (local_d8 == 1) {
        local_d0[-2] = 0x2e;
        local_d0[-1] = 0x2e;
        local_d0[-3] = 0x2e;
      }
      uVar4 = 0x8c;
      if (*(int *)(param_2 + 0x20) != 0xff) {
        uVar4 = (ulonglong)*(uint *)(param_2 + 0x20);
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c8,param_2);
      _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                (this,uVar3,L"TRACE",uVar4 & 0xffffffff,puVar2);
    }
    operator_delete__(puVar2);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}



/* ==========================================================================
 * ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z @ 0x14001060c  (156 bytes, 38 instructions)
 * void ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ulong param_2, uchar * param_3)
 * public: void __cdecl CVssFunctionTracer::TraceBuffer(struct CVssDebugInfo,unsigned long,unsigned char * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TraceBuffer(struct CVssDebugInfo,unsigned long,unsigned
   char * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined4 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    uVar2 = 0xbe;
    if (*(int *)(param_2 + 0x20) != 0xff) {
      uVar2 = *(undefined4 *)(param_2 + 0x20);
    }
    Ordinal_4(*(undefined8 *)param_2,*(undefined8 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x18)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(this + 0x24),
              *(undefined8 *)(this + 0x28),L"TRACE_BINARY",uVar2,param_4,param_3);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}



/* ==========================================================================
 * ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ @ 0x1400106b0  (398 bytes, 92 instructions)
 * void ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64 const,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64
   const,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined4 param_3,ushort *param_4,...)

{
  int iVar1;
  ulong uVar2;
  undefined8 uVar3;
  ushort *puVar4;
  ulong in_stack_fffffffffffffee8;
  __uint64 local_f8;
  ushort *local_f0;
  ushort *local_e8;
  undefined8 local_e0;
  CVssDebugInfo local_d8 [184];
  
  local_e0 = 0xfffffffffffffffe;
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if ((iVar1 != 0) && (param_4 != (ushort *)0x0)) {
    local_e8 = operator_new__(0x3ea,&std::nothrow);
    if (local_e8 != (ushort *)0x0) {
      local_f8 = 0;
      local_f0 = (ushort *)0x0;
      StringCchVPrintfExW(local_e8,500,&local_f0,&local_f8,in_stack_fffffffffffffee8,param_4,
                          &stack0x00000028);
      if (local_f8 == 1) {
        local_f0[-2] = 0x2e;
        local_f0[-1] = 0x2e;
        local_f0[-3] = 0x2e;
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
      puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_e8);
      uVar2 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                        (param_2,0x50);
      _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                (this,uVar3,L"THROW",uVar2,puVar4);
    }
    CVssAutoCoString::__0CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_f8);
    puVar4 = _GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(this);
    CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z((CVssAutoCoString *)&local_f8,puVar4)
    ;
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d8,param_2);
    puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_f8);
    uVar2 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                      (param_2,200);
    _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
              (this,uVar3,L"THROW",uVar2,puVar4);
    CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_f8);
    CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ((CVssOutputBuffer *)&local_e8);
  }
  *(undefined4 *)(this + 8) = param_3;
  local_f8 = CONCAT44(local_f8._4_4_,param_3);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(&local_f8,(ThrowInfo *)&_TI1J);
}



/* ==========================================================================
 * ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z @ 0x140010848  (359 bytes, 80 instructions)
 * void ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3)
 * public: void __cdecl CVssFunctionTracer::TranslateError(struct CVssDebugInfo,long,unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TranslateError(struct CVssDebugInfo,long,unsigned short
   const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,undefined8 param_4)

{
  undefined8 uVar1;
  CVssDebugInfo *this_00;
  ulonglong uVar2;
  CVssDebugInfo local_168 [168];
  CVssDebugInfo local_c0 [168];
  
  uVar2 = 0x8007000e;
  if ((((param_3 == -0x7ff8fff2) || (param_3 == -0x7ff8fff8)) || (param_3 == -0x7ff8ff8f)) ||
     (((param_3 == -0x7ff8fc05 || (param_3 == -0x7ff8fa56)) || (param_3 == -0x7ff8fb7a)))) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,uVar2 & 0xffffffff,L"Out of memory detected in function %s",param_4);
  }
  if (param_3 == -0x7ff8ff90) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_168,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x8004231f,L"ERROR_DISK_FULL detected in function %s",param_4);
  }
  uVar2 = 0x80042316;
  if (param_3 == -0x7ffbdcea) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_168,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,uVar2 & 0xffffffff,
               L"VSS_E_SNAPSHOT_SET_IN_PROGRESS detected in function %s",param_4);
  }
  this_00 = (CVssDebugInfo *)
            CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_c0);
  uVar1 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_168);
  _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar1);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_c0);
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_c0,param_2);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (this,uVar1,0x80042302,L"Unexpected error in routine %s.  hr = 0x%08lx",param_4,param_3)
  ;
}



/* ==========================================================================
 * ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ @ 0x1400109bc  (637 bytes, 141 instructions)
 * void ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * public: void __cdecl CVssFunctionTracer::TranslateComError(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::TranslateComError(struct CVssDebugInfo,unsigned short
   const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateComError_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  ushort *puVar4;
  CVssDebugInfo *pCVar5;
  wchar_t *pwVar6;
  undefined8 local_res20;
  ulong in_stack_fffffffffffffd78;
  char *pcVar7;
  undefined4 uVar8;
  ushort *local_268;
  __uint64 local_260;
  longlong *local_258;
  wchar_t *local_250;
  ushort *local_248;
  undefined8 local_240;
  CVssDebugInfo local_238 [168];
  CVssDebugInfo local_190 [168];
  CVssDebugInfo local_e8 [184];
  
  local_240 = 0xfffffffffffffffe;
  local_res20 = param_4;
  local_248 = operator_new__(0x3ea,&std::nothrow);
  if (local_248 == (ushort *)0x0) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_238,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar3,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_260 = 0;
  local_268 = (ushort *)0x0;
  pcVar7 = (char *)&local_res20;
  StringCchVPrintfExW(local_248,500,&local_268,&local_260,in_stack_fffffffffffffd78,param_3,pcVar7);
  uVar8 = (undefined4)((ulonglong)pcVar7 >> 0x20);
  if (local_260 == 1) {
    local_268[-2] = 0x2e;
    local_268[-1] = 0x2e;
    local_268[-3] = 0x2e;
  }
  iVar1 = *(int *)(this + 8);
  if (*(int *)(this + 8) == 0) {
    iVar1 = -0x7fff0001;
  }
  local_258 = (longlong *)0x0;
  local_250 = (wchar_t *)0x0;
  iVar2 = Ordinal_200(0,&local_258);
  if ((-1 < iVar2) && (local_258 != (longlong *)0x0)) {
    (**(code **)(*local_258 + 0x28))(local_258,&local_250);
  }
  pwVar6 = L"";
  if (local_250 != (wchar_t *)0x0) {
    pwVar6 = local_250;
  }
  if ((((iVar1 != -0x7ff8fff2) && (iVar1 != -0x7ff8fff8)) && (iVar1 != -0x7ff8ff8f)) &&
     (((iVar1 != -0x7ff8fc05 && (iVar1 != -0x7ff8fa56)) && (iVar1 != -0x7ff8fb7a)))) {
    puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_248);
    if (iVar1 == -0x7ff8ff90) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_238,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar3,0x8004231f,L"ERROR_DISK_FULL detected in function %s - %s",puVar4,pwVar6
                );
    }
    pCVar5 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_190);
    pCVar5 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar5,(ushort *)local_e8);
    uVar3 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar5,(long)local_238);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar3,1);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_e8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_190);
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_190,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar3,0x80042302,L"Unexpected error in routine %s - %s. hr = 0x%08lx",puVar4,
               pwVar6,CONCAT44(uVar8,iVar1));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_190,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_248);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}



/* ==========================================================================
 * ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ @ 0x140010c44  (122 bytes, 29 instructions)
 * long ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * public: long __cdecl CVssFunctionTracer::TranslateComErrorNoThrow(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: long __cdecl CVssFunctionTracer::TranslateComErrorNoThrow(struct CVssDebugInfo,unsigned
   short const * __ptr64,...) __ptr64 */

long __thiscall
CVssFunctionTracer::_TranslateComErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3,undefined8 param_4,...
          )

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 local_res20;
  long local_c8;
  CVssDebugInfo local_b0 [168];
  
  puVar2 = &local_res20;
  local_res20 = param_4;
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_b0,param_2);
  _TranslateComError_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ(this,uVar1,param_3,puVar2);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return local_c8;
}



/* ==========================================================================
 * ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ @ 0x140010ccc  (525 bytes, 115 instructions)
 * void ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...)
 * public: void __cdecl CVssFunctionTracer::TranslateWin32Error(struct CVssDebugInfo,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TranslateWin32Error(struct CVssDebugInfo,unsigned short
   const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,ushort *param_3,undefined8 param_4,...)

{
  DWORD DVar1;
  undefined8 uVar2;
  ushort *puVar3;
  CVssDebugInfo *this_00;
  DWORD DVar4;
  undefined8 local_res20;
  ulong in_stack_fffffffffffffe48;
  undefined4 uVar5;
  ushort *local_198;
  __uint64 local_190;
  ushort *local_188;
  undefined8 local_180;
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_180 = 0xfffffffffffffffe;
  local_res20 = param_4;
  local_188 = operator_new__(0x3ea,&std::nothrow);
  if (local_188 == (ushort *)0x0) {
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_190 = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_188,500,&local_198,&local_190,in_stack_fffffffffffffe48,param_3,
                      (char *)&local_res20);
  uVar5 = (undefined4)((ulonglong)param_3 >> 0x20);
  if (local_190 == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  DVar1 = GetLastError();
  DVar4 = DVar1 & 0xffff | 0x80070000;
  if ((int)DVar1 < 1) {
    DVar4 = DVar1;
  }
  if (DVar4 == 0) {
    DVar4 = 0x8000ffff;
  }
  if ((((DVar4 != 0x8007000e) && (DVar4 != 0x80070008)) && (DVar4 != 0x80070071)) &&
     (((DVar4 != 0x800703fb && (DVar4 != 0x800705aa)) && (DVar4 != 0x80070486)))) {
    puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
    if (DVar4 == 0x80070070) {
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar2,0x8004231f,L"ERROR_DISK_FULL detected in function %s",puVar3);
    }
    this_00 = (CVssDebugInfo *)
              CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
    uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar2);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x80042302,L"Unexpected error in routine %s. hr = 0x%08lx",puVar3,
               CONCAT44(uVar5,DVar4));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}



/* ==========================================================================
 * ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ @ 0x140010ee4  (488 bytes, 105 instructions)
 * void ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * public: void __cdecl CVssFunctionTracer::TranslateGenericError(struct CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TranslateGenericError(struct CVssDebugInfo,long,unsigned
   short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,ushort *param_4,...)

{
  undefined8 uVar1;
  ushort *puVar2;
  CVssDebugInfo *this_00;
  ulong in_stack_fffffffffffffe48;
  undefined4 uVar3;
  ushort *local_198;
  __uint64 local_190;
  ushort *local_188;
  undefined8 local_180;
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_180 = 0xfffffffffffffffe;
  local_188 = operator_new__(0x3ea,&std::nothrow);
  if (local_188 == (ushort *)0x0) {
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_190 = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_188,500,&local_198,&local_190,in_stack_fffffffffffffe48,param_4,
                      &stack0x00000028);
  uVar3 = (undefined4)((ulonglong)param_4 >> 0x20);
  if (local_190 == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  if ((((param_3 != -0x7ff8fff2) && (param_3 != -0x7ff8fff8)) && (param_3 != -0x7ff8ff8f)) &&
     (((param_3 != -0x7ff8fc05 && (param_3 != -0x7ff8fa56)) && (param_3 != -0x7ff8fb7a)))) {
    puVar2 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
    if (param_3 == -0x7ff8ff90) {
      uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar1,0x8004231f,L"ERROR_DISK_FULL detected in function %s",puVar2);
    }
    this_00 = (CVssDebugInfo *)
              CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
    uVar1 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x2001,uVar1);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar1,0x80042302,L"Unexpected error in routine %s. hr = 0x%08lx",puVar2,
               CONCAT44(uVar3,param_3));
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
  CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_188);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
}



/* ==========================================================================
 * ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ @ 0x1400110d8  (131 bytes, 31 instructions)
 * long ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct
   CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64 */

long __thiscall
CVssFunctionTracer::_TranslateGenericErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__JPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,uint param_3,undefined8 param_4,...)

{
  undefined8 uVar1;
  ulonglong uVar2;
  CVssDebugInfo local_b0 [168];
  
  uVar2 = (ulonglong)param_3;
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_b0,param_2);
                    /* WARNING: Subroutine does not return */
  _TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (this,uVar1,uVar2 & 0xffffffff,param_4,&stack0x00000028);
}



/* ==========================================================================
 * ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ @ 0x140011164  (752 bytes, 167 instructions)
 * void ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, long param_3, ushort * param_4, ...)
 * public: void __cdecl CVssFunctionTracer::TranslateInternalProviderError(struct CVssDebugInfo,long,long,unsigned short const * __ptr64,...) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::TranslateInternalProviderError(struct
   CVssDebugInfo,long,long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::
_TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,int param_3,int param_4,ushort *param_5,
          ...)

{
  long lVar1;
  undefined8 uVar2;
  ushort *puVar3;
  CVssDebugInfo *this_00;
  ulong in_stack_fffffffffffffe48;
  ushort *local_198;
  ushort *local_190;
  __uint64 local_188 [2];
  CVssDebugInfo local_178 [168];
  CVssDebugInfo local_d0 [168];
  
  local_188[1] = 0xfffffffffffffffe;
  local_190 = operator_new__(0x3ea,&std::nothrow);
  if (local_190 == (ushort *)0x0) {
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,0x8007000e,L"internal tracing buffer - out of memory");
  }
  local_188[0] = 0;
  local_198 = (ushort *)0x0;
  StringCchVPrintfExW(local_190,500,&local_198,local_188,in_stack_fffffffffffffe48,param_5,
                      &stack0x00000030);
  if (local_188[0] == 1) {
    local_198[-2] = 0x2e;
    local_198[-1] = 0x2e;
    local_198[-3] = 0x2e;
  }
  *(int *)(this + 8) = param_3;
  if (((((param_3 == -0x7ff8fff2) || (param_3 == -0x7ff8fff8)) || (param_3 == -0x7ff8ff8f)) ||
      ((param_3 == -0x7ff8fc05 || (param_3 == -0x7ff8fa56)))) || (param_3 == -0x7ff8fb7a)) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
    CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
  }
  if (param_3 == -0x7ff8ff90) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
    CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(this);
  }
  if (((1 < param_3 + 0x7ff8fffeU) && (param_3 != -0x7ff8fb71)) && (param_3 != -0x7ff8ffeb)) {
    if (param_3 == -0x7ff8fa4c) {
      puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
      uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_178);
      _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3016,uVar2);
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_178,param_2);
                    /* WARNING: Subroutine does not return */
      _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (this,uVar2,param_4,L"Timeout error calling a provider routine: %s.",puVar3);
    }
    if (param_4 != -0x7ffbdcf8) {
      CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
      this_00 = (CVssDebugInfo *)
                CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
      _GetHr_CVssFunctionTracer__QEAAJXZ(this);
      uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(this_00,(long)local_178);
      _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3001,uVar2);
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_d0);
    }
    uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
    lVar1 = _GetHr_CVssFunctionTracer__QEAAJXZ(this);
    puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (this,uVar2,param_4,
               L"Unexpected error calling a provider routine: %s  [hr = 0x%08lx] ",puVar3,lVar1);
  }
  puVar3 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_190);
  uVar2 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(param_2,(ushort *)local_d0);
  _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0x3011,uVar2);
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
                    /* WARNING: Subroutine does not return */
  _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (this,uVar2,0x80042308,L"Invalid device when calling a provider routine: %s",puVar3);
}



/* ==========================================================================
 * ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z @ 0x140011460  (649 bytes, 156 instructions)
 * void ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, _GUID param_2, ushort * param_3, ulong param_4, _GUID param_5, IUnknown * * param_6)
 * public: void __cdecl CVssFunctionTracer::CoCreateInstanceWithLog(struct CVssDebugInfo,struct _GUID,unsigned short const * __ptr64,unsigned long,struct _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::CoCreateInstanceWithLog(struct CVssDebugInfo,struct
   _GUID,unsigned short const * __ptr64,unsigned long,struct _GUID,struct IUnknown * __ptr64 *
   __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::
_CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,IID *param_3,undefined8 param_4,
          undefined8 param_5,IID *param_6,LPVOID *param_7)

{
  int iVar1;
  CVssDebugInfo *pCVar2;
  HRESULT HVar3;
  undefined8 uVar4;
  _GUID *this_00;
  undefined8 uVar5;
  DWORD dwMilliseconds;
  _GUID local_248 [10];
  _GUID local_1a0 [10];
  undefined1 local_f8 [184];
  
  dwMilliseconds = 1000;
  do {
    HVar3 = CoCreateInstance(param_3,(LPUNKNOWN)0x0,0x17,param_6,param_7);
    *(HRESULT *)(this + 8) = HVar3;
    if (((HVar3 != -0x7ff7fffb) && (HVar3 != -0x7ff8fff2)) && (HVar3 != -0x7ff8fbe3)) break;
    Sleep(dwMilliseconds);
    dwMilliseconds = dwMilliseconds + 2000;
  } while ((int)dwMilliseconds < 21000);
  iVar1 = *(int *)(this + 8);
  if ((iVar1 == -0x7fffbffe) || (iVar1 == -0x7ffbfeac)) {
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
    uVar5 = 0x16;
LAB_1400116af:
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,uVar5,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_1a0);
    this_00 = local_248;
  }
  else {
    if ((iVar1 == -0x7ff8fff2) || (iVar1 == -0x7ff8fbe3)) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0xd;
      goto LAB_1400116af;
    }
    if (iVar1 == -0x7ff8fbc4) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0x12;
      goto LAB_1400116af;
    }
    if (iVar1 == -0x7ff7fffb) {
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_248);
      pCVar2 = (CVssDebugInfo *)
               CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_1a0);
      uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
      uVar5 = 0xb;
      goto LAB_1400116af;
    }
    if (iVar1 == 0) goto LAB_1400116cd;
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_1a0);
    pCVar2 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar2,(ushort *)local_248);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar2,(long)local_f8);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0xd,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_248);
    this_00 = local_1a0;
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)this_00);
LAB_1400116cd:
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}



/* ==========================================================================
 * ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z @ 0x1400116f0  (372 bytes, 87 instructions)
 * void ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1)
 * public: void __cdecl CVssFunctionTracer::ComDisableSEH(struct CVssDebugInfo) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::ComDisableSEH(struct CVssDebugInfo) __ptr64 */

void __thiscall
CVssFunctionTracer::_ComDisableSEH_CVssFunctionTracer__QEAAXUCVssDebugInfo___Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2)

{
  HRESULT HVar1;
  int iVar2;
  CVssDebugInfo *pCVar3;
  undefined8 uVar4;
  longlong *local_res8;
  CVssDebugInfo *local_res10;
  _GUID local_218 [10];
  undefined1 local_170 [168];
  CVssDebugInfo local_c8 [176];
  
  local_res8 = (longlong *)0x0;
  local_res10 = param_2;
  HVar1 = CoCreateInstance((IID *)&CLSID_GlobalOptions,(LPUNKNOWN)0x0,1,
                           (IID *)&_GUID_0000015b_0000_0000_c000_000000000046,&local_res8);
  *(HRESULT *)(this + 8) = HVar1;
  if (HVar1 < 0) {
    pCVar3 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_U_GUID___Z(param_2,local_218);
    pCVar3 = (CVssDebugInfo *)
             CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_PEBG_Z(pCVar3,(ushort *)local_c8);
    _GetHr_CVssFunctionTracer__QEAAJXZ(this);
    uVar4 = CVssDebugInfo::__6CVssDebugInfo__QEAA_AU0_J_Z(pCVar3,(long)local_170);
    _LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z(this,0xd,uVar4);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(local_c8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)local_218);
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)local_218,param_2);
    _GetHr_CVssFunctionTracer__QEAAJXZ(this);
                    /* WARNING: Subroutine does not return */
    _Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ();
  }
  iVar2 = (**(code **)(*local_res8 + 0x18))(local_res8,1,1);
  *(int *)(this + 8) = iVar2;
  if (-1 < iVar2) {
    if (local_res8 != (longlong *)0x0) {
      (**(code **)(*local_res8 + 0x10))();
    }
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
    return;
  }
  CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)local_218,param_2);
  _GetHr_CVssFunctionTracer__QEAAJXZ(this);
                    /* WARNING: Subroutine does not return */
  _TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ();
}



/* ==========================================================================
 * ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z @ 0x140011870  (1510 bytes, 290 instructions)
 * void ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z(CVssFunctionTracer * this, ulong param_1, CVssDebugInfo param_2, ushort param_3)
 * public: void __cdecl CVssFunctionTracer::LogError(unsigned long,struct CVssDebugInfo,unsigned short) __ptr64
 * ========================================================================== */

/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: void __cdecl CVssFunctionTracer::LogError(unsigned long,struct CVssDebugInfo,unsigned
   short) __ptr64 */

void __thiscall
CVssFunctionTracer::_LogError_CVssFunctionTracer__QEAAXKUCVssDebugInfo__G_Z
          (CVssFunctionTracer *this,DWORD param_1,CVssDebugInfo *param_3)

{
  ushort uVar1;
  ushort uVar2;
  longlong lVar3;
  BOOL BVar4;
  DWORD DVar5;
  longlong lVar6;
  LPWSTR pWVar7;
  wchar_t *pv;
  HANDLE hEventLog;
  CVssDebugInfo *pCVar8;
  undefined8 uVar9;
  CVssFunctionTracer *this_00;
  wchar_t *pwVar10;
  ulong uVar11;
  ulonglong uVar12;
  _VSSDBG_SEV_ENUM _Var13;
  longlong lVar14;
  undefined1 auStackY_1b78 [32];
  wchar_t *local_1ae8;
  wchar_t *local_1ae0;
  wchar_t *local_1ad8;
  undefined4 local_1ad0;
  undefined4 local_1acc;
  undefined4 local_1ac8;
  undefined1 local_1ac0 [120];
  undefined4 local_1a48;
  CVssFunctionTracer local_1a38 [112];
  undefined8 local_19c8;
  CVssDebugInfo local_19b0 [168];
  wchar_t *local_1908 [3];
  undefined4 local_18f0;
  undefined4 local_18ec;
  undefined4 local_18e8;
  undefined1 local_18e0 [120];
  undefined4 local_1868;
  CVssFunctionTracer local_1858 [2048];
  char local_1058 [4112];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x140011886;
  local_19c8 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_1b78;
  local_1908[0] = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
  local_1908[1] = L"CVssFunctionTracer::LogError";
  local_1908[2] = L"TRCTRCC";
  local_18f0 = 0x8c1;
  local_18ec = 0xb;
  local_18e8 = 0xff;
  local_1868 = 0x1000000;
  memset(local_18e0,0,0x78);
  __0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_1a38);
  memset(local_1908,0,0x80);
  memset(local_1058,0,0x1001);
  if (*(ushort *)(param_3 + 0xa0) + 1 < 0xf) {
    uVar11 = 0x800;
    this_00 = local_1858;
    memset(this_00,0,0x800);
    _GetCurrentUserName_CVssFunctionTracer__QEAAXPEAGK_Z(this_00,(ushort *)local_1858,uVar11);
    lVar6 = -1;
    do {
      lVar6 = lVar6 + 1;
    } while (*(short *)(local_1858 + lVar6 * 2) != 0);
    pWVar7 = GetCommandLineW();
    lVar6 = -1;
    do {
      lVar6 = lVar6 + 1;
    } while (pWVar7[lVar6] != L'\0');
    _Var13 = *(_VSSDBG_SEV_ENUM *)(this + 0x20);
    GetCommandLineW();
    GetCurrentThreadId();
    GetCurrentProcessId();
    StringCchPrintfA(local_1058,0x1000,
                     "- Code: %8ls%08lu- Call: %8ls%08lu- PID:  %08lu- TID:  %08lu- CMD:  %-*ls- User: %-*ls"
                     ,*(undefined8 *)(param_3 + 0x10));
    lVar6 = -1;
    do {
      lVar14 = lVar6 + 1;
      lVar3 = lVar6 + 1;
      lVar6 = lVar14;
    } while (local_1058[lVar3] != '\0');
    uVar1 = *(ushort *)(param_3 + 0xa0);
    uVar2 = 0;
    if (uVar1 != 0) {
      memcpy(local_1908,param_3 + 0x28,(ulonglong)uVar1 << 3);
      uVar2 = uVar1;
    }
    pv = (wchar_t *)_GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(this);
    pwVar10 = L"";
    if (pv != (wchar_t *)0x0) {
      pwVar10 = pv;
    }
    local_1908[uVar2] = pwVar10;
    local_1ae8 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
    local_1ae0 = L"CVssFunctionTracer::LogError";
    local_1ad8 = L"TRCTRCC";
    local_1ad0 = 0x902;
    local_1acc = 0xb;
    local_1a48 = 0x1000000;
    memset(local_1ac0,0,0x78);
    uVar12 = 100;
    local_1ac8 = 100;
    CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_19b0,(CVssDebugInfo *)&local_1ae8);
    uVar12 = uVar12 & 0xffffffff;
    if (*(int *)(param_3 + 0x20) != 0xff) {
      uVar12 = (ulonglong)*(uint *)(param_3 + 0x20);
    }
    _TraceInternalWithFormat_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1ZZ
              (this,local_19b0,L"CONTEXT",uVar12);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_1ae8);
    hEventLog = RegisterEventSourceW((LPCWSTR)0x0,L"VSS");
    if (hEventLog == (HANDLE)0x0) {
      pCVar8 = (CVssDebugInfo *)
               CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1ae8,
                          (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                          (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::LogError",0x912,0xb,
                          _Var13);
      uVar9 = CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
                        (pCVar8,(_VSSDBG_SEV_ENUM)local_19b0);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,uVar9,L"Error on RegisterEventSourceW 0x%08lx",DVar5);
      pCVar8 = (CVssDebugInfo *)&local_1ae8;
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(pCVar8);
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)pCVar8);
    }
    _Var13 = (_VSSDBG_SEV_ENUM)lVar14;
    BVar4 = ReportEventW(hEventLog,1,0,param_1,(PSID)0x0,uVar1 + 1,_Var13,local_1908,local_1058);
    if (BVar4 == 0) {
      local_1ae8 = L"base\\stor\\vss\\modules\\trace\\fntracer.cpp";
      local_1ae0 = L"CVssFunctionTracer::LogError";
      local_1ad8 = L"TRCTRCC";
      local_1ad0 = 0x923;
      local_1acc = 0xb;
      local_1a48 = 0x1000000;
      memset(local_1ac0,0,0x78);
      local_1ac8 = 100;
      CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_19b0,(CVssDebugInfo *)&local_1ae8);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,local_19b0,L"Error on ReportEventW 0x%08lx",DVar5);
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_1ae8);
    }
    BVar4 = DeregisterEventSource(hEventLog);
    if (BVar4 == 0) {
      pCVar8 = (CVssDebugInfo *)
               CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1ae8,
                          (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",
                          (ushort *)L"TRCTRCC",(ushort *)L"CVssFunctionTracer::LogError",0x92a,0xb,
                          _Var13);
      uVar9 = CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
                        (pCVar8,(_VSSDBG_SEV_ENUM)local_19b0);
      DVar5 = GetLastError();
      _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_1a38,uVar9,L"Error on DeregisterEventSource 0x%08lx",DVar5);
      pCVar8 = (CVssDebugInfo *)&local_1ae8;
      CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(pCVar8);
                    /* WARNING: Subroutine does not return */
      InternalThrow((long)pCVar8);
    }
    CoTaskMemFree(pv);
    __1CVssFunctionTracer__QEAA_XZ(local_1a38);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_3);
  }
  else {
    __1CVssFunctionTracer__QEAA_XZ(local_1a38);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_3);
  }
  return;
}



/* ==========================================================================
 * ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z @ 0x140011e68  (140 bytes, 30 instructions)
 * void ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z(CVssFunctionTracer * this, long param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * public: void __cdecl CVssFunctionTracer::HandleHresultException(long,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::HandleHresultException(long,unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
          (CVssFunctionTracer *this,long param_1,ushort *param_2,ushort *param_3,ushort *param_4,
          ulong param_5,ulong param_6)

{
  ushort *local_b8;
  ushort *local_b0;
  ushort *local_a8;
  ulong local_a0;
  ulong local_9c;
  undefined4 local_98;
  undefined1 local_90 [120];
  undefined4 local_18;
  
  local_b0 = param_4;
  *(long *)(this + 8) = param_1;
  local_a0 = param_5;
  local_9c = param_6;
  local_98 = 0xff;
  local_18 = 0x1000000;
  local_b8 = param_2;
  local_a8 = param_3;
  memset(local_90,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_b8,L"HRESULT exception caught: hr: 0x%x",param_1);
  return;
}



/* ==========================================================================
 * ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z @ 0x140011efc  (245 bytes, 64 instructions)
 * void ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z(CVssFunctionTracer * this, _com_error * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * public: void __cdecl CVssFunctionTracer::HandleComException(class _com_error & __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::HandleComException(class _com_error & __ptr64,unsigned
   short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned
   long,unsigned long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
          (CVssFunctionTracer *this,_com_error *param_1,ushort *param_2,ushort *param_3,
          ushort *param_4,ulong param_5,ulong param_6)

{
  undefined4 uVar1;
  long lVar2;
  ushort *local_d8;
  ushort *local_d0;
  ushort *local_c8;
  ulong local_c0;
  ulong local_bc;
  undefined4 local_b8;
  undefined1 local_b0 [120];
  undefined4 local_38;
  
  uVar1 = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(this + 8) = uVar1;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  lVar2 = _TranslateComErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__PEBGZZ
                    (this,&local_d8,L"Unexpected COM exception caught: hr: 0x%x",uVar1);
  *(long *)(this + 8) = lVar2;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_d8,L"COM error caught: hr: 0x%x",lVar2);
  return;
}



/* ==========================================================================
 * ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z @ 0x140011ff8  (126 bytes, 25 instructions)
 * void ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z(CVssFunctionTracer * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5)
 * public: void __cdecl CVssFunctionTracer::HandleStdBadAllocException(unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssFunctionTracer::HandleStdBadAllocException(unsigned short const *
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned
   long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
          (CVssFunctionTracer *this,ushort *param_1,ushort *param_2,ushort *param_3,ulong param_4,
          ulong param_5)

{
  ushort *local_b8;
  ushort *local_b0;
  ushort *local_a8;
  ulong local_a0;
  ulong local_9c;
  undefined4 local_98;
  undefined1 local_90 [120];
  undefined4 local_18;
  
  *(undefined4 *)(this + 8) = 0x8007000e;
  local_a0 = param_4;
  local_9c = param_5;
  local_98 = 0xff;
  local_18 = 0x1000000;
  local_b8 = param_1;
  local_b0 = param_3;
  local_a8 = param_2;
  memset(local_90,0,0x78);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_b8,L"bad_alloc STL exception caught: hr: 0x%x",0x8007000e);
  return;
}



/* ==========================================================================
 * ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z @ 0x140012080  (282 bytes, 71 instructions)
 * void ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z(CVssFunctionTracer * this, exception * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6)
 * public: void __cdecl CVssFunctionTracer::HandleStdGenericException(class exception const & __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned long,unsigned long) __ptr64
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* public: void __cdecl CVssFunctionTracer::HandleStdGenericException(class exception const &
   __ptr64,unsigned short const * __ptr64,unsigned short const * __ptr64,unsigned short const *
   __ptr64,unsigned long,unsigned long) __ptr64 */

void __thiscall
CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
          (CVssFunctionTracer *this,exception *param_1,ushort *param_2,ushort *param_3,
          ushort *param_4,ulong param_5,ulong param_6)

{
  long lVar1;
  undefined8 uVar2;
  ushort *local_d8;
  ushort *local_d0;
  ushort *local_c8;
  ulong local_c0;
  ulong local_bc;
  undefined4 local_b8;
  undefined1 local_b0 [120];
  undefined4 local_38;
  
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  uVar2 = (**(code **)(*(longlong *)param_1 + 8))(param_1);
  lVar1 = _TranslateGenericErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__JPEBGZZ
                    (this,&local_d8,0x80042302,L"Unexpected STL exception caught: %s",uVar2);
  *(long *)(this + 8) = lVar1;
  local_d0 = param_4;
  local_c0 = param_5;
  local_bc = param_6;
  local_b8 = 0xff;
  local_38 = 0x1000000;
  local_d8 = param_2;
  local_c8 = param_3;
  memset(local_b0,0,0x78);
  uVar2 = (**(code **)(*(longlong *)param_1 + 8))(param_1);
  _Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (this,&local_d8,L"Unexpected STL exception caught: %s",uVar2);
  return;
}



/* ==========================================================================
 * ??1?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ @ 0x1400121b0  (49 bytes, 14 instructions)
 * void ??1?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this)
 * public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::~basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
 * ========================================================================== */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70>::~basic_string<unsigned short,struct
   std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
    */

void __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this)

{
  if (7 < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(undefined8 *)(this + 0x20) = 7;
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined2 *)(this + 8) = 0;
  return;
}



/* ==========================================================================
 * ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@PEBG@Z @ 0x1400121e8  (253 bytes, 76 instructions)
 * undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@PEBG@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, ushort * param_1)
 * public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(unsigned short const * __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct
   std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(unsigned
   short const * __ptr64) __ptr64 */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_PEBG_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,ushort *param_1)

{
  bool bVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar3;
  bool in_R8B;
  __uint64 _Var4;
  
  *(undefined8 *)(this + 0x20) = 7;
  pbVar3 = this + 8;
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined2 *)pbVar3 = 0;
  _Var4 = 0xffffffffffffffff;
  do {
    _Var4 = _Var4 + 1;
  } while (param_1[_Var4] != 0);
  pbVar2 = pbVar3;
  if (7 < *(ulonglong *)(this + 0x20)) {
    pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
               **)pbVar3;
  }
  if (pbVar2 <= param_1) {
    pbVar2 = pbVar3;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    if (param_1 < pbVar2 + *(longlong *)(this + 0x18) * 2) {
      if (7 < *(ulonglong *)(this + 0x20)) {
        pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar3;
      }
      _assign___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                (this,(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                       *)this,(longlong)param_1 - (longlong)pbVar3 >> 1,_Var4);
      return this;
    }
  }
  bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                    (this,_Var4,in_R8B);
  if (bVar1) {
    pbVar2 = pbVar3;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    memcpy_s(pbVar2,*(ulonglong *)(this + 0x20) * 2,param_1,_Var4 * 2);
    *(__uint64 *)(this + 0x18) = _Var4;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar3;
    }
    *(undefined2 *)(pbVar3 + _Var4 * 2) = 0;
  }
  return this;
}



/* ==========================================================================
 * ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ @ 0x1400122f0  (22 bytes, 6 instructions)
 * undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this)
 * public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
 * ========================================================================== */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70>::basic_string<unsigned short,struct
   std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>(void) __ptr64
    */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__0__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this)

{
  *(undefined8 *)(this + 0x20) = 7;
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined2 *)(this + 8) = 0;
  return this;
}



/* ==========================================================================
 * ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_N_K@Z @ 0x140012310  (119 bytes, 32 instructions)
 * void ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, bool param_1, __uint64 param_2)
 * protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
 * ========================================================================== */

/* protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
    */

void __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Tidy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_N_K_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,bool param_1,__uint64 param_2)

{
  void *_Src;
  
  if ((param_1) && (7 < *(ulonglong *)(this + 0x20))) {
    _Src = *(void **)(this + 8);
    if (param_2 != 0) {
      memcpy_s(this + 8,0x10,_Src,param_2 * 2);
    }
    operator_delete__(_Src);
  }
  *(undefined8 *)(this + 0x20) = 7;
  *(__uint64 *)(this + 0x18) = param_2;
  *(undefined2 *)(this + param_2 * 2 + 8) = 0;
  return;
}



/* ==========================================================================
 * ?assign@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z @ 0x140012390  (220 bytes, 65 instructions)
 * basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?assign@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::assign(class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::assign(class std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned
   __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::
_assign___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                 *param_1,__uint64 param_2,__uint64 param_3)

{
  bool bVar1;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *_Dst;
  ulonglong uVar3;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar4;
  
  if (param_2 <= *(ulonglong *)(param_1 + 0x18)) {
    uVar3 = *(ulonglong *)(param_1 + 0x18) - param_2;
    if (param_3 < uVar3) {
      uVar3 = param_3;
    }
    if (this == (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 *)param_1) {
      _erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
                (this,uVar3 + param_2,0xffffffffffffffff);
      _erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
                (this,0,param_2);
    }
    else {
      bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                        (this,uVar3,SUB81(param_2,0));
      if (bVar1) {
        pbVar2 = param_1 + 8;
        if (7 < *(ulonglong *)(param_1 + 0x20)) {
          pbVar2 = *(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                     **)pbVar2;
        }
        pbVar4 = this + 8;
        _Dst = pbVar4;
        if (7 < *(ulonglong *)(this + 0x20)) {
          _Dst = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar4;
        }
        memcpy_s(_Dst,*(ulonglong *)(this + 0x20) * 2,pbVar2 + param_2 * 2,uVar3 * 2);
        *(ulonglong *)(this + 0x18) = uVar3;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar4 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar4;
        }
        *(undefined2 *)(pbVar4 + uVar3 * 2) = 0;
      }
    }
    return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xran__String_base_std__SAXXZ();
}



/* ==========================================================================
 * ?_Grow@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAA_N_K_N@Z @ 0x140012478  (116 bytes, 34 instructions)
 * bool ?_Grow@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAA_N_K_N@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, bool param_2)
 * protected: bool __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Grow(unsigned __int64,bool) __ptr64
 * ========================================================================== */

/* protected: bool __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Grow(unsigned __int64,bool) __ptr64
    */

bool __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,bool param_2)

{
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar1;
  
  if (param_1 < 0x7fffffffffffffff) {
    if (*(ulonglong *)(this + 0x20) < param_1) {
      __Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
                (this,param_1,*(__uint64 *)(this + 0x18));
    }
    else if (param_1 == 0) {
      *(undefined8 *)(this + 0x18) = 0;
      pbVar1 = this + 8;
      if (7 < *(ulonglong *)(this + 0x20)) {
        pbVar1 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                   **)pbVar1;
      }
      *(undefined2 *)pbVar1 = 0;
    }
    return param_1 != 0;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xlen__String_base_std__SAXXZ();
}



/* ==========================================================================
 * ?erase@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z @ 0x1400124f4  (188 bytes, 55 instructions)
 * basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?erase@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::_erase___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12__K0_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,__uint64 param_2)

{
  longlong lVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar3;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar4;
  ulonglong uVar5;
  
  if (*(ulonglong *)(this + 0x18) < param_1) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xran__String_base_std__SAXXZ();
  }
  uVar5 = *(ulonglong *)(this + 0x18) - param_1;
  if (uVar5 < param_2) {
    param_2 = uVar5;
  }
  if (param_2 != 0) {
    pbVar4 = this + 8;
    pbVar3 = pbVar4;
    pbVar2 = pbVar4;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
    }
    memmove_s(pbVar3 + param_1 * 2,(*(ulonglong *)(this + 0x20) - param_1) * 2,
              pbVar2 + (param_1 + param_2) * 2,(uVar5 - param_2) * 2);
    lVar1 = *(longlong *)(this + 0x18);
    *(__uint64 *)(this + 0x18) = lVar1 - param_2;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar4 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar4;
    }
    *(undefined2 *)(pbVar4 + (lVar1 - param_2) * 2) = 0;
  }
  return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
          *)this;
}



/* ==========================================================================
 * ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z @ 0x1400125bc  (206 bytes, 58 instructions)
 * basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::append(class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short>,class _STL70> & __ptr64 __cdecl std::basic_string<unsigned
   short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class
   _STL70>::append(class std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70> const & __ptr64,unsigned
   __int64,unsigned __int64) __ptr64 */

basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
* __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::
_append___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                 *param_1,__uint64 param_2,__uint64 param_3)

{
  bool bVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  __uint64 _Var3;
  ulonglong uVar4;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar5;
  basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
  *_Src;
  
  uVar4 = 0xffffffffffffffff;
  if (*(longlong *)(param_1 + 0x18) != -1) {
    uVar4 = *(ulonglong *)(param_1 + 0x18);
  }
  if (uVar4 < ~*(ulonglong *)(this + 0x18)) {
    if (uVar4 != 0) {
      _Var3 = *(longlong *)(this + 0x18) + uVar4;
      bVar1 = __Grow___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAA_N_K_N_Z
                        (this,_Var3,SUB81(param_2,0));
      if (bVar1) {
        _Src = param_1 + 8;
        if (7 < *(ulonglong *)(param_1 + 0x20)) {
          _Src = *(basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
                   **)_Src;
        }
        pbVar5 = this + 8;
        pbVar2 = pbVar5;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar5;
        }
        memcpy_s(pbVar2 + *(longlong *)(this + 0x18) * 2,
                 (*(ulonglong *)(this + 0x20) - *(longlong *)(this + 0x18)) * 2,_Src,uVar4 * 2);
        *(__uint64 *)(this + 0x18) = _Var3;
        if (7 < *(ulonglong *)(this + 0x20)) {
          pbVar5 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                     **)pbVar5;
        }
        *(undefined2 *)(pbVar5 + _Var3 * 2) = 0;
      }
    }
    return (basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xlen__String_base_std__SAXXZ();
}



/* ==========================================================================
 * ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_K0@Z @ 0x140012694  (288 bytes, 82 instructions)
 * void ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* protected: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short>,class _STL70>::_Copy(unsigned __int64,unsigned
   __int64) __ptr64 */

void __thiscall
std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::__Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_K0_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
           *this,__uint64 param_1,__uint64 param_2)

{
  undefined1 auVar1 [16];
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *_Dst;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  *pbVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  bad_alloc local_60 [56];
  
  uVar5 = param_1 | 7;
  if (uVar5 < 0x7fffffffffffffff) {
    uVar4 = *(ulonglong *)(this + 0x20);
    uVar3 = uVar4 >> 1;
    param_1 = uVar5;
    if ((uVar5 / 3 < uVar3) && (uVar4 <= 0x7ffffffffffffffe - uVar3)) {
      param_1 = uVar3 + uVar4;
    }
  }
  uVar5 = param_1 + 1;
  uVar4 = 0;
  if ((uVar5 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = uVar5, uVar4 = uVar5,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 2)) {
    bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(local_60,(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_60,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  _Dst = operator_new(uVar4 * 2);
  if (param_2 != 0) {
    pbVar2 = this + 8;
    if (7 < *(ulonglong *)(this + 0x20)) {
      pbVar2 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
                 **)pbVar2;
    }
    memcpy_s(_Dst,param_1 * 2 + 2,pbVar2,param_2 * 2);
  }
  if (7 < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
    **)(this + 8) = _Dst;
  *(__uint64 *)(this + 0x20) = param_1;
  *(__uint64 *)(this + 0x18) = param_2;
  pbVar2 = this + 8;
  if (7 < param_1) {
    pbVar2 = _Dst;
  }
  *(undefined2 *)(pbVar2 + param_2 * 2) = 0;
  return;
}



/* ==========================================================================
 * ?Initialize@CVssSKU@@CAXXZ @ 0x1400127e0  (248 bytes, 54 instructions)
 * void ?Initialize@CVssSKU@@CAXXZ(void)
 * private: static void __cdecl CVssSKU::Initialize(void)
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: static void __cdecl CVssSKU::Initialize(void) */

void __cdecl CVssSKU::_Initialize_CVssSKU__CAXXZ(void)

{
  BOOL BVar1;
  undefined1 auStackY_178 [32];
  longlong *local_148 [2];
  _OSVERSIONINFOW local_138;
  byte local_20;
  char local_1e;
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStackY_178;
  if (ms_bInitialized == 0) {
    local_138.dwOSVersionInfoSize = 0x11c;
    BVar1 = GetVersionExW(&local_138);
    if (BVar1 == 0) {
      ms_bInitialized = 1;
    }
    if ((byte)(local_1e - 2U) < 2) {
      ms_eSKU = (-(uint)((local_20 & 0x40) != 0) & 2) + 2;
    }
    else {
      ms_eSKU = (EVssSKUType)(local_1e == '\x01');
    }
    local_148[0] = (longlong *)0x0;
    CoGetClassObject((IID *)&CLSID_VssEvent,0x15,(LPVOID)0x0,(IID *)&IID_IClassFactory,local_148);
    if (local_148[0] != (longlong *)0x0) {
      (**(code **)(*local_148[0] + 0x10))();
    }
    ms_bInitialized = 1;
  }
  return;
}



/* ==========================================================================
 * ??1CVssIOCTLChannel@@QEAA@XZ @ 0x1400128e0  (186 bytes, 46 instructions)
 * void ??1CVssIOCTLChannel@@QEAA@XZ(CVssIOCTLChannel * this)
 * public: __cdecl CVssIOCTLChannel::~CVssIOCTLChannel(void) __ptr64
 * ========================================================================== */

/* public: __cdecl CVssIOCTLChannel::~CVssIOCTLChannel(void) __ptr64 */

void __thiscall CVssIOCTLChannel::__1CVssIOCTLChannel__QEAA_XZ(CVssIOCTLChannel *this)

{
  if (*(HANDLE *)this != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)this);
  }
  *(undefined8 *)this = 0;
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  if (*(void **)(this + 0x38) != (void *)0x0) {
    free(*(void **)(this + 0x38));
  }
  *(undefined8 *)(this + 0x38) = 0;
  *(undefined4 *)(this + 0x30) = 0;
  if (*(void **)(this + 0x50) != (void *)0x0) {
    free(*(void **)(this + 0x50));
  }
  *(undefined8 *)(this + 0x50) = 0;
  *(undefined4 *)(this + 0x44) = 0;
  if ((*(HANDLE *)(this + 0x20) != (HANDLE)0x0) && (this[0x28] != (CVssIOCTLChannel)0x0)) {
    CloseHandle(*(HANDLE *)(this + 0x20));
  }
  *(undefined ***)(this + 0x60) =
       &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (*(LPVOID *)(this + 0x68) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 0x68));
  }
  *(undefined8 *)(this + 0x68) = 0;
  *(undefined ***)(this + 0x60) =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  return;
}



/* ==========================================================================
 * ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z @ 0x1400129a4  (251 bytes, 56 instructions)
 * void ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong * param_2)
 * private: void __cdecl CVssIOCTLChannel::ApplyAlignment(class CVssFunctionTracer & __ptr64,unsigned long * __ptr64) __ptr64
 * ========================================================================== */

/* private: void __cdecl CVssIOCTLChannel::ApplyAlignment(class CVssFunctionTracer &
   __ptr64,unsigned long * __ptr64) __ptr64 */

void __thiscall
CVssIOCTLChannel::_ApplyAlignment_CVssIOCTLChannel__AEAAXAEAVCVssFunctionTracer__PEAK_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ulong *param_2)

{
  ushort uVar1;
  uint uVar2;
  undefined8 uVar3;
  uint uVar4;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff38;
  CVssDebugInfo local_b8 [176];
  
  uVar2 = *param_2;
  uVar1 = *(ushort *)(this + 0x58);
  if ((short)((ulonglong)uVar2 % (ulonglong)uVar1) != 0) {
    uVar4 = (uint)((ulonglong)uVar2 % (ulonglong)uVar1);
    if (uVar1 < uVar4) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::ApplyAlignment",0x83,10
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar3,0x8007000e,
                 L"Arithmetic overflow.  wAlignmentOffset = %hu was larger than m_wAlignmentBytes = %hu"
                 ,uVar4,*(undefined2 *)(this + 0x58));
    }
    uVar4 = uVar2 + (uVar1 - uVar4);
    if (uVar4 < uVar2) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (local_b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::ApplyAlignment",0x8a,10
                         ,in_stack_ffffffffffffff38);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar3,0x8007000e,L"Arithmetic overflow. m_wAlignmentBytes = %hu too large",
                 *(undefined2 *)(this + 0x58));
    }
    *param_2 = uVar4;
  }
  return;
}



/* ==========================================================================
 * ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z @ 0x140012aa8  (1069 bytes, 225 instructions)
 * long ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ushort * param_2, bool param_3, bool param_4, _VSS_ICHANNEL_LOGGING param_5, ulong param_6, ulong param_7, ulong param_8)
 * public: long __cdecl CVssIOCTLChannel::Open(class CVssFunctionTracer & __ptr64,unsigned short const * __ptr64,bool,bool,enum _VSS_ICHANNEL_LOGGING,unsigned long,unsigned long,unsigned long) __ptr64
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: long __cdecl CVssIOCTLChannel::Open(class CVssFunctionTracer & __ptr64,unsigned short
   const * __ptr64,bool,bool,enum _VSS_ICHANNEL_LOGGING,unsigned long,unsigned long,unsigned long)
   __ptr64 */

long __thiscall
CVssIOCTLChannel::
_Open_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__PEBG_N2W4_VSS_ICHANNEL_LOGGING__KKK_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ushort *param_2,bool param_3,
          bool param_4,_VSS_ICHANNEL_LOGGING param_5,ulong param_6,ulong param_7,ulong param_8)

{
  WCHAR WVar1;
  code *pcVar2;
  DWORD DVar3;
  ulonglong uVar4;
  DWORD DVar5;
  long lVar6;
  WCHAR *pWVar7;
  HANDLE pvVar8;
  undefined8 uVar9;
  longlong lVar10;
  WCHAR *pWVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined1 auStackY_408 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc28;
  _VSSDBG_SEV_ENUM _Var14;
  wchar_t *local_3b8;
  wchar_t *local_3b0;
  wchar_t *local_3a8;
  undefined4 local_3a0;
  undefined4 local_39c;
  undefined4 local_398;
  undefined1 local_390 [120];
  undefined4 local_318;
  undefined8 local_310;
  CVssDebugInfo local_308 [176];
  WCHAR local_258 [264];
  ulonglong local_48;
  
  local_310 = 0xfffffffffffffffe;
  local_48 = __security_cookie ^ (ulonglong)auStackY_408;
  local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_3b0 = L"CVssIOCTLChannel::Open";
  local_3a8 = L"INCICHLH";
  local_3a0 = 200;
  local_39c = 10;
  local_398 = 0xff;
  local_318 = 0x1000000;
  memset(local_390,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (param_1,&local_3b8,L"Opening a handle to %s (access = 0x%08lx, share = 0x%08lx)",
             param_2);
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(HANDLE *)this != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)this);
  }
  *(undefined8 *)this = 0;
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  uVar4 = 0xffffffffffffffff;
  do {
    uVar13 = uVar4;
    uVar4 = uVar13 + 1;
  } while (param_2[uVar13 + 1] != 0);
  if (0x103 < uVar13) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_308,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0xda,10,
                       in_stack_fffffffffffffc28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar9,0x8000ffff,L"Error: the buffer is too small to fit %s (%d < %d)");
  }
  if (param_2[uVar13] != 0x5c) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_3b8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0xe2,10,
                       in_stack_fffffffffffffc28);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar9,0x8000ffff,L"Error: the object name %s does terminate with a backslash"
              );
  }
  if (uVar13 < 0x7fffffff) {
    lVar10 = 0x104;
    pWVar11 = local_258;
    do {
      if (((uVar13 - 0x104) + lVar10 == 0) ||
         (WVar1 = *(WCHAR *)((longlong)pWVar11 + ((longlong)param_2 - (longlong)local_258)),
         WVar1 == L'\0')) break;
      *pWVar11 = WVar1;
      pWVar11 = pWVar11 + 1;
      lVar10 = lVar10 + -1;
    } while (lVar10 != 0);
    pWVar7 = pWVar11 + -1;
    if (lVar10 != 0) {
      pWVar7 = pWVar11;
    }
    *pWVar7 = L'\0';
    uVar12 = ~-(uint)(lVar10 != 0) & 0x8007007a;
  }
  else {
    uVar12 = 0x80070057;
    local_258[0] = L'\0';
  }
  *(uint *)(param_1 + 8) = uVar12;
  local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_3b0 = L"CVssIOCTLChannel::Open";
  local_3a8 = L"INCICHLH";
  local_3a0 = 0xe9;
  local_39c = 10;
  local_398 = 0xff;
  local_318 = 0x1000000;
  memset(local_390,0,0x78);
  if ((int)uVar12 < 0) {
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_308,(CVssDebugInfo *)&local_3b8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
              (param_1,uVar9,uVar12,L"StringCchCopyN");
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_3b8);
  if (uVar13 * 2 < 0x208) {
    local_258[uVar13] = L'\0';
    _Var14 = 0xffffffff;
    pvVar8 = CreateFileW(local_258,0x80000000,3,(LPSECURITY_ATTRIBUTES)0x0,3,0x80,
                         (HANDLE)0xffffffffffffffff);
    *(HANDLE *)this = pvVar8;
    if (pvVar8 != (HANDLE)0xffffffffffffffff) {
      local_3b8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_3b0 = L"CVssIOCTLChannel::Open";
      local_3a8 = L"INCICHLH";
      local_3a0 = 300;
      local_39c = 10;
      local_398 = 0xff;
      local_318 = 0x1000000;
      memset(local_390,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (param_1,&local_3b8,L"The object \'%s\'. was opened under the device handle 0x%08lx"
                 ,local_258);
      CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
      _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
                ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(this + 0x60),
                 (ushort *)local_258);
      return *(long *)(param_1 + 8);
    }
    *(undefined8 *)this = 0;
    DVar5 = GetLastError();
    uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      (local_308,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Open",0x10e,2,_Var14);
    DVar3 = DVar5 & 0xffff | 0x80070000;
    if ((int)DVar5 < 1) {
      DVar3 = DVar5;
    }
    CVssFunctionTracer::
    _TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ
              (param_1,uVar9,DVar3,0x80042306);
    pcVar2 = (code *)swi(3);
    lVar6 = (*pcVar2)();
    return lVar6;
  }
  __report_rangecheckfailure();
  pcVar2 = (code *)swi(3);
  lVar6 = (*pcVar2)();
  return lVar6;
}



/* ==========================================================================
 * ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z @ 0x140012ee0  (1007 bytes, 232 instructions)
 * long ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong param_2, bool param_3, _VSS_ICHANNEL_LOGGING param_4, bool param_5, void * param_6)
 * public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64
 * ========================================================================== */

/* public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned
   long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64 */

long __thiscall
CVssIOCTLChannel::
_Call_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__K_NW4_VSS_ICHANNEL_LOGGING__1PEAX_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ulong param_2,bool param_3,
          _VSS_ICHANNEL_LOGGING param_4,bool param_5,void *param_6)

{
  CVssIOCTLChannel *lpBytesReturned;
  uint uVar1;
  BOOL BVar2;
  DWORD DVar3;
  void *pvVar4;
  undefined8 uVar5;
  uint uVar6;
  size_t _NewSize;
  _VSSDBG_SEV_ENUM _Var7;
  CVssIOCTLChannel *in_stack_ffffffffffffff08;
  wchar_t *local_e8;
  wchar_t *local_e0;
  wchar_t *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined4 local_c8;
  undefined1 local_c0 [120];
  undefined4 local_48;
  
  _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
  _NewSize = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(longlong *)this == 0) {
    _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x17d,10,_Var7);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar5,0x8000ffff,L"Channel not open");
  }
  if (this[0x29] != (CVssIOCTLChannel)0x0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x182,10,_Var7);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_1,uVar5,0x80070057,L"previous IOCTL hasn\'t yet completed");
  }
  uVar1 = *(uint *)(this + 0x44);
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  do {
    _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    if ((int)_NewSize == 0) {
      if (uVar1 == 0) {
        _NewSize = 0x1000;
        goto LAB_140012f54;
      }
    }
    else {
LAB_140012f54:
      uVar6 = (uint)_NewSize;
      if (uVar1 < uVar6) {
        pvVar4 = realloc(*(void **)(this + 0x50),_NewSize);
        if (pvVar4 == (void *)0x0) {
          _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
          uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                            ((CVssDebugInfo *)&local_e8,
                             (ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                             (ushort *)L"CVssIOCTLChannel::Call",0x1ba,10,_Var7);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (param_1,uVar5,0x8007000e,L"Could not extend the output buffer");
        }
        *(void **)(this + 0x50) = pvVar4;
        *(uint *)(this + 0x44) = uVar6;
        uVar1 = uVar6;
      }
    }
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c3;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (param_1,&local_e8,
               L"IOCTL sent: %lx on device %s\n Input buffer size: %ld, Output buffer size: %ld",
               0x534058,*(undefined8 *)(this + 0x68),*(undefined4 *)(this + 0x2c),uVar1);
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c5;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
              (param_1,&local_e8,*(undefined4 *)(this + 0x2c),*(undefined8 *)(this + 0x38));
    lpBytesReturned = this + 0x48;
    in_stack_ffffffffffffff08 = lpBytesReturned;
    BVar2 = DeviceIoControl(*(HANDLE *)this,0x534058,*(LPVOID *)(this + 0x38),
                            *(DWORD *)(this + 0x2c),*(LPVOID *)(this + 0x50),*(DWORD *)(this + 0x44)
                            ,(LPDWORD)lpBytesReturned,(LPOVERLAPPED)0x0);
    _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    if (BVar2 != 0) {
LAB_1400130aa:
      GetLastError();
      *(undefined4 *)(this + 0x2c) = 0;
      *(undefined4 *)(this + 0x40) = 0;
      if (BVar2 == 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                   (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x1ea,10,_Var7);
        CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
        ::
        _Get___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEBAPEAGXZ
                  ((CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
                    *)(this + 0x60));
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(param_1);
      }
      local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_e0 = L"CVssIOCTLChannel::Call";
      local_d8 = L"INCICHLH";
      local_d0 = 0x225;
      local_cc = 10;
      local_c8 = 0xff;
      local_48 = 0x1000000;
      memset(local_c0,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (param_1,&local_e8,
                 L"IOCTL %lx succeeded on device %s - 0x%08lx. \n Output buffer: size received = %ld"
                 ,0x534058,*(undefined8 *)(this + 0x68),*(undefined8 *)this,
                 *(DWORD *)lpBytesReturned);
      local_cc = 10;
      local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
      local_e0 = L"CVssIOCTLChannel::Call";
      local_d8 = L"INCICHLH";
      local_d0 = 0x227;
      local_c8 = 0xff;
      local_48 = 0x1000000;
      memset(local_c0,0,0x78);
      CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
                (param_1,&local_e8,*(DWORD *)lpBytesReturned,*(undefined8 *)(this + 0x50));
      *(undefined4 *)(param_1 + 8) = 0;
      return 0;
    }
    DVar3 = GetLastError();
    if (DVar3 != 0x7a) {
      DVar3 = GetLastError();
      _Var7 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
      if (DVar3 != 0xea) goto LAB_1400130aa;
    }
    uVar1 = *(uint *)(this + 0x44);
    _NewSize = (size_t)(uVar1 * 2);
  } while( true );
}



/* ==========================================================================
 * ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ @ 0x1400132dc  (9 bytes, 3 instructions)
 * void ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ(CVssIOCTLChannel * this)
 * public: void __cdecl CVssIOCTLChannel::ResetOffsets(void) __ptr64
 * ========================================================================== */

/* public: void __cdecl CVssIOCTLChannel::ResetOffsets(void) __ptr64 */

void __thiscall CVssIOCTLChannel::_ResetOffsets_CVssIOCTLChannel__QEAAXXZ(CVssIOCTLChannel *this)

{
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  return;
}



/* ==========================================================================
 * GetVolumeNameWithCheck @ 0x1400132ec  (466 bytes, 104 instructions)
 * void GetVolumeNameWithCheck(CVssDebugInfo param_1, long param_2, ushort * param_3, ushort * param_4, ulong param_5)
 * void __cdecl GetVolumeNameWithCheck(struct CVssDebugInfo,long,unsigned short const * __ptr64,unsigned short * __ptr64,unsigned long)
 * ========================================================================== */

/* void __cdecl GetVolumeNameWithCheck(struct CVssDebugInfo,long,unsigned short const *
   __ptr64,unsigned short * __ptr64,unsigned long) */

void __cdecl
GetVolumeNameWithCheck(CVssDebugInfo *param_1,undefined8 param_2,LPCWSTR param_3,LPWSTR param_4)

{
  BOOL BVar1;
  DWORD DVar2;
  undefined8 uVar3;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  undefined8 local_b0;
  CVssFunctionTracer local_a8 [112];
  
  local_b0 = 0xfffffffffffffffe;
  local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
  local_150 = L"GetVolumeNameWithCheck";
  local_148 = L"INCVOLH";
  local_140 = 0x15b;
  local_13c = 0xb;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8);
  *param_4 = L'\0';
  local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
  local_150 = L"GetVolumeNameWithCheck";
  local_148 = L"INCVOLH";
  local_140 = 0x163;
  local_13c = 0xb;
  local_138 = 0xff;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_a8,&local_158,L"GetVolumeNameForVolumeMountPointW will be called on %s",param_3);
  BVar1 = GetVolumeNameForVolumeMountPointW(param_3,param_4,0x32);
  if (BVar1 != 0) {
    local_158 = L"base\\stor\\vss\\inc\\vs_vol.hxx";
    local_150 = L"GetVolumeNameWithCheck";
    local_148 = L"INCVOLH";
    local_140 = 0x16b;
    local_13c = 0xb;
    local_138 = 0xff;
    local_b8 = 0x1000000;
    memset(local_130,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_a8,&local_158,
               L"GetVolumeNameForVolumeMountPointW succeeded and the output is %s",param_4);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_1);
    return;
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z((CVssDebugInfo *)&local_158,param_1);
  DVar2 = GetLastError();
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_a8,uVar3,0x80070057,
             L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx",param_3,
             DVar2);
}



/* ==========================================================================
 * ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z @ 0x1400134c8  (1742 bytes, 310 instructions)
 * __int64 ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z(ushort * param_1)
 * public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaOnVolume(unsigned short const * __ptr64)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaOnVolume(unsigned short
   const * __ptr64) */

__int64 __cdecl
CVssMachineInformation::_GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z(ushort *param_1)

{
  OLECHAR OVar1;
  __int64 _Var2;
  void *pvVar3;
  int iVar4;
  HRESULT HVar5;
  _VSSDBG_SEV_ENUM _Var6;
  longlong lVar7;
  OLECHAR *pOVar9;
  undefined8 uVar10;
  OLECHAR *pOVar11;
  CVssDebugInfo *this;
  wchar_t *pwVar12;
  wchar_t *pwVar13;
  undefined1 in_R9B;
  wchar_t *pwVar14;
  ushort *puVar15;
  undefined1 auStackY_348 [32];
  undefined1 in_stack_fffffffffffffcd8;
  _VSS_ICHANNEL_LOGGING in_stack_fffffffffffffce0;
  ulong uVar16;
  ulong in_stack_fffffffffffffce8;
  _VSSDBG_SEV_ENUM _Var17;
  _VSSDBG_SEV_ENUM _Var18;
  ulong in_stack_fffffffffffffcf0;
  ulong in_stack_fffffffffffffcf8;
  wchar_t *local_2f8;
  wchar_t *local_2f0;
  wchar_t *pwStack_2e8;
  undefined8 local_2e0;
  HANDLE pvStack_2d8;
  undefined2 local_2d0 [2];
  ulonglong local_2cc;
  void *local_2c0;
  undefined8 local_2b8;
  _VSSDBG_SEV_ENUM local_2b0;
  void *local_2a8;
  short local_2a0;
  undefined **local_298;
  LPVOID local_290;
  undefined4 local_258;
  wchar_t *local_248;
  wchar_t *local_240;
  wchar_t *local_238;
  undefined4 local_230;
  undefined4 local_22c;
  undefined4 local_228;
  undefined1 local_220 [120];
  undefined4 local_1a8;
  ushort *local_198;
  CVssFunctionTracer local_188 [36];
  int local_164;
  undefined8 local_118;
  CLSID local_100;
  OLECHAR local_e8 [38];
  undefined2 local_9c;
  ushort local_98 [56];
  ulonglong local_28;
  longlong lVar8;
  
  local_118 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_348;
  local_2f8 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_2f0 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
  pwStack_2e8 = L"REGREGSC";
  local_2e0 = 0xb00000698;
  pvStack_2d8 = (HANDLE)CONCAT44(pvStack_2d8._4_4_,0xff);
  local_258 = 0x1000000;
  local_198 = param_1;
  memset(local_2d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_188);
  lVar7 = -1;
  do {
    lVar8 = lVar7;
    lVar7 = lVar8 + 1;
  } while (param_1[lVar7] != 0);
  if ((lVar7 == 0x31) &&
     (iVar4 = wcsncmp((wchar_t *)param_1,L"\\\\?\\Volume",(ulonglong)((int)lVar8 - 0x26)),
     iVar4 == 0)) {
    iVar4 = wcsncmp((wchar_t *)(param_1 + 0x30),L"\\",2);
    if (iVar4 == 0) {
      lVar7 = 0x27;
      for (pOVar11 = local_e8;
          (lVar7 + -1 != 0 &&
          (OVar1 = *(OLECHAR *)((longlong)param_1 + (0x14 - (longlong)local_e8) + (longlong)pOVar11)
          , OVar1 != L'\0')); pOVar11 = pOVar11 + 1) {
        *pOVar11 = OVar1;
        lVar7 = lVar7 + -1;
      }
      pOVar9 = pOVar11 + -1;
      if (lVar7 != 0) {
        pOVar9 = pOVar11;
      }
      *pOVar9 = L'\0';
      if (lVar7 != 0) {
        local_9c = 0;
        HVar5 = CLSIDFromString(local_e8,&local_100);
        puVar15 = param_1;
        if (HVar5 == 0) goto LAB_1400136d4;
      }
    }
  }
  local_248 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_240 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
  local_238 = L"REGREGSC";
  local_230 = 0x6a4;
  local_22c = 0xb;
  local_228 = 0xff;
  local_1a8 = 0x1000000;
  memset(local_220,0,0x78);
  in_R9B = SUB81(local_98,0);
  GetVolumeNameWithCheck(&local_248);
  puVar15 = local_98;
LAB_1400136d4:
  local_2f8 = (HANDLE)0x0;
  local_2d0[0] = 0;
  local_2cc = 0;
  local_2c0 = (void *)0x0;
  local_2b8 = 0;
  local_2b0 = 0;
  local_2a8 = (void *)0x0;
  local_2a0 = 0;
  local_290 = (LPVOID)0x0;
  local_298 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  local_2f0 = (wchar_t *)0x0;
  pwStack_2e8 = (wchar_t *)0x0;
  local_2e0 = 0;
  pvStack_2d8 = (HANDLE)0x0;
  CVssIOCTLChannel::
  _Open_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__PEBG_N2W4_VSS_ICHANNEL_LOGGING__KKK_Z
            ((CVssIOCTLChannel *)&local_2f8,local_188,puVar15,(bool)in_R9B,
             (bool)in_stack_fffffffffffffcd8,in_stack_fffffffffffffce0,in_stack_fffffffffffffce8,
             in_stack_fffffffffffffcf0,in_stack_fffffffffffffcf8);
  _Var17 = 0;
  CVssIOCTLChannel::
  _Call_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__K_NW4_VSS_ICHANNEL_LOGGING__1PEAX_Z
            ((CVssIOCTLChannel *)&local_2f8,local_188,0x534058,true,0,false,(void *)0x0);
  pvVar3 = local_2a8;
  _Var18 = (_VSSDBG_SEV_ENUM)local_2b8;
  if (local_2a8 != (void *)0x0) {
    _Var6 = (_VSSDBG_SEV_ENUM)local_2b8 + 8;
    if (((_VSSDBG_SEV_ENUM)local_2b8 <= _Var6) && (_Var6 <= local_2b0)) {
      if (local_2b8._4_4_ < _Var6) {
        CVssIOCTLChannel::_ResetOffsets_CVssIOCTLChannel__QEAAXXZ((CVssIOCTLChannel *)&local_2f8);
        uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                           ((CVssDebugInfo *)&local_248,
                            (ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                            (ushort *)L"CVssIOCTLChannel::Unpack",0x300,10,_Var17);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_188,uVar10,0x8007000e,
                   L"Arithmetic overflow. m_dwOutputCurrentOffset = %lu or dwSize = %lu too large.")
        ;
      }
      _Var2 = *(__int64 *)((local_2b8 & 0xffffffff) + (longlong)local_2a8);
      local_2b8 = CONCAT44(local_2b8._4_4_,_Var6);
      if (local_2a0 != 0) {
        CVssIOCTLChannel::_ApplyAlignment_CVssIOCTLChannel__AEAAXAEAVCVssFunctionTracer__PEAK_Z
                  ((CVssIOCTLChannel *)&local_2f8,local_188,(ulong *)&local_2b8);
      }
      local_248 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
      local_240 = L"CVssMachineInformation::GetMinDiffAreaOnVolume";
      local_238 = L"REGREGSC";
      local_230 = 0x6b9;
      local_22c = 0xb;
      local_228 = 0xff;
      local_1a8 = 0x1000000;
      memset(local_220,0,0x78);
      CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                (local_188,&local_248,L"Minimum diff area size for volume %s: %I64d",param_1);
      if (local_2f8 != (HANDLE)0x0) {
        CloseHandle(local_2f8);
      }
      local_2f8 = (wchar_t *)0x0;
      local_2cc = local_2cc & 0xffffffff00000000;
      local_2b8 = local_2b8 & 0xffffffff00000000;
      local_2b0 = 0;
      if (local_2c0 != (void *)0x0) {
        free(local_2c0);
      }
      local_2c0 = (void *)0x0;
      local_2cc = local_2cc & 0xffffffff;
      if (local_2a8 != (void *)0x0) {
        free(local_2a8);
      }
      local_2a8 = (void *)0x0;
      local_2b8 = local_2b8 & 0xffffffff;
      if ((pvStack_2d8 != (HANDLE)0x0) && ((char)local_2d0[0] != '\0')) {
        CloseHandle(pvStack_2d8);
      }
      local_298 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      if (local_290 != (LPVOID)0x0) {
        CoTaskMemFree(local_290);
      }
      local_290 = (LPVOID)0x0;
      local_298 = &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
                   ::_vftable_;
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_188);
      return _Var2;
    }
  }
  local_248 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_240 = L"CVssIOCTLChannel::Unpack";
  local_238 = L"INCICHLH";
  local_230 = 0x2e7;
  local_22c = 10;
  local_228 = 0xff;
  local_1a8 = 0x1000000;
  memset(local_220,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_188,&local_248,
             L"Output buffer overflow. Trying to read non-existent arguments. m_pbOutputBuffer = %p, m_dwOutputCurrentOffset = %lu, dwSize = %lu, m_dwOutputCurrentOffset = %lu"
             ,pvVar3);
  local_2cc = local_2cc & 0xffffffff00000000;
  local_2b8 = local_2b8 & 0xffffffff00000000;
  uVar16 = 10;
  pwVar14 = L"CVssIOCTLChannel::Unpack";
  pwVar13 = L"INCICHLH";
  pwVar12 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  this = (CVssDebugInfo *)&local_248;
  if (local_164 == 2) {
    pwVar12 = (wchar_t *)
              CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        (this,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                         (ushort *)L"CVssIOCTLChannel::Unpack",0x2f2,10,_Var18);
    pwVar14 = (wchar_t *)0x80042306;
    pwVar13 = (wchar_t *)0x8000ffff;
    this = (CVssDebugInfo *)local_188;
    CVssFunctionTracer::
    _TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ();
  }
  uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                     (this,(ushort *)pwVar12,(ushort *)pwVar13,(ushort *)pwVar14,0x2f4,uVar16,_Var18
                     );
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (local_188,uVar10,0x8000ffff,
             L"Output buffer overflow. Reading bad arguments. dwSize = %lu");
}



/* ==========================================================================
 * ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ @ 0x140013bf8  (956 bytes, 174 instructions)
 * __int64 ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ(void)
 * public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaForSystem(void)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaForSystem(void) */

__int64 __cdecl
CVssMachineInformation::_GetMinDiffAreaForSystem_CVssMachineInformation__SA_JXZ(void)

{
  code *pcVar1;
  UINT UVar2;
  BOOL BVar3;
  __int64 _Var4;
  undefined8 uVar5;
  undefined1 auStackY_688 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffff9a8;
  wchar_t *local_630;
  wchar_t *local_628;
  wchar_t *local_620;
  undefined4 local_618;
  undefined4 local_614;
  undefined4 local_610;
  undefined1 local_608 [120];
  undefined4 local_590;
  CVssFunctionTracer local_588 [112];
  undefined8 local_518;
  wchar_t *local_4f8;
  wchar_t *local_4f0;
  wchar_t *local_4e8;
  undefined4 local_4e0;
  undefined4 local_4dc;
  undefined4 local_4d8;
  undefined1 local_4d0 [120];
  undefined4 local_458;
  WCHAR local_448 [264];
  WCHAR local_238 [264];
  ulonglong local_28;
  
  local_518 = 0xfffffffffffffffe;
  local_28 = __security_cookie ^ (ulonglong)auStackY_688;
  local_4f8 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_4f0 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
  local_4e8 = L"REGREGSC";
  local_4e0 = 0x6c7;
  local_4dc = 0xb;
  local_4d8 = 0xff;
  local_458 = 0x1000000;
  memset(local_4d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_588,&local_4f8);
  UVar2 = GetSystemWindowsDirectoryW(local_448,0x105);
  if (UVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_630,
                       (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                       (ushort *)L"REGREGSC",
                       (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6d0,0xb,
                       in_stack_fffffffffffff9a8);
    CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
              (local_588,uVar5,L"GetSystemWindowsDirectoryW(%s, %u): %u",local_448);
  }
  else {
    local_630 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
    local_628 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
    local_620 = L"REGREGSC";
    local_618 = 0x6d2;
    local_614 = 0xb;
    local_610 = 0xff;
    local_590 = 0x1000000;
    memset(local_608,0,0x78);
    in_stack_fffffffffffff9a8 = GetLastError();
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_588,&local_630,L"GetSystemWindowsDirectoryW(%s, %u): %u [0x%08lx]",local_448);
    memset(local_238,0,0x20a);
    BVar3 = GetVolumePathNameW(local_448,local_238,0x105);
    if (BVar3 != 0) {
      BVar3 = GetVolumeNameForVolumeMountPointW(local_238,(LPWSTR)&local_4f8,0x32);
      if (BVar3 != 0) {
        local_630 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
        local_628 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
        local_620 = L"REGREGSC";
        local_618 = 0x6e3;
        local_614 = 0xb;
        local_610 = 0xff;
        local_590 = 0x1000000;
        memset(local_608,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_588,&local_630,L"System volume name: %s",&local_4f8);
        _Var4 = _GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z((ushort *)&local_4f8);
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_588);
        return _Var4;
      }
      goto LAB_140013fbd;
    }
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_630,
                     (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                     (ushort *)L"REGREGSC",
                     (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6db,0xb,
                     in_stack_fffffffffffff9a8);
  CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
            (local_588,uVar5,L"GetVolumePathNameW(%s, %p, %u)",local_448);
LAB_140013fbd:
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_630,
                     (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                     (ushort *)L"REGREGSC",
                     (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e1,0xb,
                     in_stack_fffffffffffff9a8);
  CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
            (local_588,uVar5,
             L"GetVolumeNameForVolumeMountPointW( \'%s\', STRING_CCH_PARAM(wszSysVolumeName))",
             local_238);
  pcVar1 = (code *)swi(3);
  _Var4 = (*pcVar1)();
  return _Var4;
}



/* ==========================================================================
 * ??0bad_alloc@std@@QEAA@XZ @ 0x140014004  (46 bytes, 12 instructions)
 * undefined ??0bad_alloc@std@@QEAA@XZ(bad_alloc * this)
 * public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64
 * ========================================================================== */

/* public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64 */

bad_alloc * __thiscall std::bad_alloc::__0bad_alloc_std__QEAA_XZ(bad_alloc *this)

{
  exception::__0exception__QEAA_AEBQEBDH_Z((exception *)this,&_bad_alloc_Message,1);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * operator_new @ 0x140014038  (69 bytes, 20 instructions)
 * void * operator_new(__uint64 param_1)
 * void * __ptr64 __cdecl operator new(unsigned __int64)
 * ========================================================================== */

/* void * __ptr64 __cdecl operator new(unsigned __int64) */

void * __cdecl operator_new(__uint64 param_1)

{
  int iVar1;
  void *pvVar2;
  bad_alloc local_28 [32];
  
  do {
    pvVar2 = malloc(param_1);
    if (pvVar2 != (void *)0x0) {
      return pvVar2;
    }
    iVar1 = _callnewh(param_1);
  } while (iVar1 != 0);
  std::bad_alloc::__0bad_alloc_std__QEAA_XZ(local_28);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
}



/* ==========================================================================
 * operator_delete[] @ 0x140014084  (5 bytes, 1 instructions)
 * void operator_delete[](void * param_1)
 * void __cdecl operator delete[](void * __ptr64)
 * ========================================================================== */

/* void __cdecl operator delete[](void * __ptr64) */

void __cdecl operator_delete__(void *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140014463. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  free(param_1);
  return;
}



/* ==========================================================================
 * pre_c_init @ 0x140014090  (211 bytes, 49 instructions)
 * undefined8 pre_c_init(void)
 * ========================================================================== */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 pre_c_init(void)

{
  code *_Except;
  int iVar1;
  
  if ((false) || (false)) {
LAB_1400140a2:
    DAT_140024160 = 0;
  }
  else {
    if (false) {
      DAT_140024160 = 0;
      if (true) goto LAB_1400140f9;
      iVar1 = 0x17dc8;
    }
    else {
      if (false) goto LAB_1400140a2;
      DAT_140024160 = 0;
      if (false) goto LAB_1400140f9;
      iVar1 = 0;
    }
    DAT_140024160 = (uint)(iVar1 != 0);
  }
LAB_1400140f9:
  iVar1 = _get_image_app_type(1);
  __set_app_type(iVar1);
  ___onexitend = 0xffffffffffffffff;
  ___onexitbegin = 0xffffffffffffffff;
  *(undefined4 *)_fmode_exref = _fmode;
  _Except = _commode_exref;
  *(undefined4 *)_commode_exref = _commode;
  _wsetargv((_exception *)_Except);
  if (__defaultmatherr == 0) {
    __setusermatherr(_wsetargv);
  }
  return 0;
}



/* ==========================================================================
 * pre_cpp_init @ 0x140014170  (73 bytes, 13 instructions)
 * undefined pre_cpp_init(void)
 * ========================================================================== */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void pre_cpp_init(void)

{
  _DAT_140024164 = _newmode;
  _DAT_14002414c =
       __wgetmainargs(&DAT_140024148,&DAT_140024150,&DAT_140024158,_dowildcard,&DAT_140024164);
  return;
}



/* ==========================================================================
 * __wmainCRTStartup @ 0x1400141c0  (446 bytes, 105 instructions)
 * int __wmainCRTStartup(void)
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */

int __wmainCRTStartup(void)

{
  void *pvVar1;
  bool bVar2;
  void *pvVar3;
  int iVar4;
  BOOL BVar5;
  void *pvVar6;
  longlong *plVar7;
  bool bVar8;
  
  pvVar1 = StackBase;
  bVar2 = false;
  while( true ) {
    pvVar6 = (void *)0x0;
    LOCK();
    bVar8 = __native_startup_lock == (void *)0x0;
    pvVar3 = pvVar1;
    if (!bVar8) {
      pvVar6 = __native_startup_lock;
      pvVar3 = __native_startup_lock;
    }
    __native_startup_lock = pvVar3;
    UNLOCK();
    if (bVar8) goto LAB_140014211;
    if (pvVar6 == pvVar1) break;
    Sleep(1000);
  }
  bVar2 = true;
LAB_140014211:
  if (__native_startup_state == 1) {
    _amsg_exit(0x1f);
  }
  else if (__native_startup_state == 0) {
    __native_startup_state = 1;
    iVar4 = 0;
    for (plVar7 = &__xi_a; plVar7 < &__xi_z; plVar7 = plVar7 + 1) {
      if (iVar4 != 0) {
        return 0xff;
      }
      if (*plVar7 != 0) {
        iVar4 = (*(code *)*plVar7)(_guard_dispatch_icall);
      }
    }
    if (iVar4 != 0) {
      return 0xff;
    }
  }
  else {
    DAT_140024144 = 1;
  }
  if (__native_startup_state == 1) {
    _initterm(&__xc_a,&__xc_z);
    __native_startup_state = 2;
  }
  if (!bVar2) {
    LOCK();
    __native_startup_lock = (void *)0x0;
    UNLOCK();
  }
  if ((__dyn_tls_init_callback != 0) &&
     (BVar5 = _IsNonwritableInCurrentImage((PBYTE)&__dyn_tls_init_callback), BVar5 != 0)) {
    (*(code *)__dyn_tls_init_callback)(0,2,0,_guard_dispatch_icall);
  }
  DAT_140024140 = wmain(DAT_140024148,DAT_140024150,DAT_140024158);
  if (DAT_140024160 == 0) {
                    /* WARNING: Subroutine does not return */
    exit(DAT_140024140);
  }
  if (DAT_140024144 == 0) {
    _cexit();
  }
  return DAT_140024140;
}



/* ==========================================================================
 * entry @ 0x140014390  (18 bytes, 4 instructions)
 * undefined entry(void)
 * ========================================================================== */

void entry(void)

{
  __security_init_cookie();
  __wmainCRTStartup();
  return;
}



/* ==========================================================================
 * __CxxFrameHandler3 @ 0x1400143a8  (6 bytes, 1 instructions)
 * undefined __CxxFrameHandler3()
 * ========================================================================== */

void __CxxFrameHandler3(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001400143a8. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  __CxxFrameHandler3();
  return;
}



/* ==========================================================================
 * __security_check_cookie @ 0x1400143c0  (30 bytes, 8 instructions)
 * void __security_check_cookie(uintptr_t _StackCookie)
 * ========================================================================== */

/* WARNING: This is an inlined function */

void __cdecl __security_check_cookie(uintptr_t _StackCookie)

{
  if ((_StackCookie == __security_cookie) && ((short)(_StackCookie >> 0x30) == 0)) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __report_gsfailure(_StackCookie);
}



/* ==========================================================================
 * __std_terminate @ 0x1400143e4  (10 bytes, 2 instructions)
 * undefined __std_terminate(void)
 * ========================================================================== */

void __std_terminate(void)

{
                    /* WARNING: Subroutine does not return */
  terminate();
}



/* ==========================================================================
 * operator_new @ 0x1400143f8  (26 bytes, 7 instructions)
 * void * operator_new(__uint64 param_1, nothrow_t * param_2)
 * void * __ptr64 __cdecl operator new(unsigned __int64,struct std::nothrow_t const & __ptr64)
 * ========================================================================== */

/* void * __ptr64 __cdecl operator new(unsigned __int64,struct std::nothrow_t const & __ptr64) */

void * __cdecl operator_new(__uint64 param_1,nothrow_t *param_2)

{
  void *pvVar1;
  
  pvVar1 = operator_new(param_1);
  return pvVar1;
}



/* ==========================================================================
 * ??_Etype_info@@UEAAPEAXI@Z @ 0x140014420  (48 bytes, 15 instructions)
 * void * ??_Etype_info@@UEAAPEAXI@Z(type_info * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int)
   __ptr64 */

void * __thiscall type_info::___Etype_info__UEAAPEAXI_Z(type_info *this,uint param_1)

{
  type_info::~type_info(this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * operator_new[] @ 0x140014458  (5 bytes, 1 instructions)
 * void * operator_new[](__uint64 param_1, nothrow_t * param_2)
 * void * __ptr64 __cdecl operator new[](unsigned __int64,struct std::nothrow_t const & __ptr64)
 * ========================================================================== */

/* void * __ptr64 __cdecl operator new[](unsigned __int64,struct std::nothrow_t const & __ptr64) */

void * __cdecl operator_new__(__uint64 param_1,nothrow_t *param_2)

{
  void *pvVar1;
  
  pvVar1 = operator_new(param_1);
  return pvVar1;
}



/* ==========================================================================
 * free @ 0x140014463  (6 bytes, 1 instructions)
 * void free(void * _Memory)
 * ========================================================================== */

void __cdecl free(void *_Memory)

{
                    /* WARNING: Could not recover jumptable at 0x000140014463. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  free(_Memory);
  return;
}



/* ==========================================================================
 * _purecall @ 0x140014470  (6 bytes, 1 instructions)
 * undefined _purecall()
 * ========================================================================== */

void _purecall(void)

{
                    /* WARNING: Could not recover jumptable at 0x000140014470. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _purecall();
  return;
}



/* ==========================================================================
 * __raise_securityfailure @ 0x14001447c  (52 bytes, 13 instructions)
 * undefined __raise_securityfailure(_EXCEPTION_POINTERS * param_1)
 * ========================================================================== */

void __raise_securityfailure(_EXCEPTION_POINTERS *param_1)

{
  HANDLE pvVar1;
  
  SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)0x0);
  UnhandledExceptionFilter(param_1);
  pvVar1 = GetCurrentProcess();
                    /* WARNING: Could not recover jumptable at 0x0001400144a9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  TerminateProcess(pvVar1,0xc0000409);
  return;
}



/* ==========================================================================
 * __report_gsfailure @ 0x1400144c0  (369 bytes, 65 instructions)
 * void __report_gsfailure(uintptr_t _StackCookie)
 * ========================================================================== */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl __report_gsfailure(uintptr_t _StackCookie)

{
  DWORD64 ControlPc;
  PRUNTIME_FUNCTION FunctionEntry;
  DWORD64 local_38;
  ulonglong local_30;
  PVOID local_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  
  RtlCaptureContext(&DAT_140024210);
  ControlPc = DAT_140024308;
  FunctionEntry = RtlLookupFunctionEntry(DAT_140024308,&local_38,(PUNWIND_HISTORY_TABLE)0x0);
  if (FunctionEntry == (PRUNTIME_FUNCTION)0x0) {
    DAT_140024308 = *DAT_1400242a8;
    DAT_1400242a8 = DAT_1400242a8 + 1;
  }
  else {
    RtlVirtualUnwind(0,local_38,ControlPc,FunctionEntry,(PCONTEXT)&DAT_140024210,&local_28,&local_30
                     ,(PKNONVOLATILE_CONTEXT_POINTERS)0x0);
  }
  _DAT_140024180 = DAT_140024308;
  _DAT_140024170 = 0xc0000409;
  _DAT_140024174 = 1;
  _DAT_140024188 = 3;
  DAT_140024190 = 2;
  DAT_140024198 = __security_cookie;
  DAT_1400241a0 = __security_cookie_complement;
  uStack_20 = __security_cookie;
  uStack_18 = __security_cookie_complement;
  _DAT_140024290 = _StackCookie;
  __raise_securityfailure((_EXCEPTION_POINTERS *)&PTR_DAT_140017008);
  return;
}



/* ==========================================================================
 * __report_rangecheckfailure @ 0x140014638  (247 bytes, 44 instructions)
 * undefined __report_rangecheckfailure(void)
 * ========================================================================== */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __report_rangecheckfailure(void)

{
  DWORD64 ControlPc;
  PRUNTIME_FUNCTION FunctionEntry;
  DWORD64 local_28;
  ulonglong local_20;
  PVOID local_18 [3];
  
  RtlCaptureContext(&DAT_140024210);
  ControlPc = DAT_140024308;
  FunctionEntry = RtlLookupFunctionEntry(DAT_140024308,&local_28,(PUNWIND_HISTORY_TABLE)0x0);
  if (FunctionEntry == (PRUNTIME_FUNCTION)0x0) {
    DAT_140024308 = *DAT_1400242a8;
    DAT_1400242a8 = DAT_1400242a8 + 1;
  }
  else {
    RtlVirtualUnwind(0,local_28,ControlPc,FunctionEntry,(PCONTEXT)&DAT_140024210,local_18,&local_20,
                     (PKNONVOLATILE_CONTEXT_POINTERS)0x0);
  }
  _DAT_140024180 = DAT_140024308;
  _DAT_140024170 = 0xc0000409;
  _DAT_140024174 = 1;
  _DAT_140024188 = 1;
  DAT_140024190 = 8;
  __raise_securityfailure((_EXCEPTION_POINTERS *)&PTR_DAT_140017008);
  return;
}



/* ==========================================================================
 * malloc @ 0x140014735  (6 bytes, 1 instructions)
 * void * malloc(size_t _Size)
 * ========================================================================== */

void * __cdecl malloc(size_t _Size)

{
  void *pvVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140014735. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = malloc(_Size);
  return pvVar1;
}



/* ==========================================================================
 * _callnewh @ 0x140014741  (6 bytes, 1 instructions)
 * int _callnewh(size_t _Size)
 * ========================================================================== */

int __cdecl _callnewh(size_t _Size)

{
  int iVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140014741. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  iVar1 = _callnewh(_Size);
  return iVar1;
}



/* ==========================================================================
 * ??0exception@@QEAA@AEBQEBDH@Z @ 0x14001474d  (6 bytes, 1 instructions)
 * undefined ??0exception@@QEAA@AEBQEBDH@Z(exception * this, char * * param_1, int param_2)
 * public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64
 * ========================================================================== */

/* public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64 */

void __thiscall exception::__0exception__QEAA_AEBQEBDH_Z(exception *this,char **param_1,int param_2)

{
                    /* WARNING: Could not recover jumptable at 0x00014001474d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this,param_1,param_2);
  return;
}



/* ==========================================================================
 * ??0exception@@QEAA@AEBV0@@Z @ 0x140014759  (6 bytes, 1 instructions)
 * undefined ??0exception@@QEAA@AEBV0@@Z(exception * this, exception * param_1)
 * public: __cdecl exception::exception(class exception const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl exception::exception(class exception const & __ptr64) __ptr64 */

void __thiscall exception::__0exception__QEAA_AEBV0__Z(exception *this,exception *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140014759. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this,param_1);
  return;
}



/* ==========================================================================
 * ??1exception@@UEAA@XZ @ 0x140014765  (6 bytes, 1 instructions)
 * void ??1exception@@UEAA@XZ(exception * this)
 * public: virtual __cdecl exception::~exception(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl exception::~exception(void) __ptr64 */

void __thiscall exception::__1exception__UEAA_XZ(exception *this)

{
                    /* WARNING: Could not recover jumptable at 0x000140014765. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  ~exception(this);
  return;
}



/* ==========================================================================
 * ?what@exception@@UEBAPEBDXZ @ 0x140014780  (6 bytes, 1 instructions)
 * char * ?what@exception@@UEBAPEBDXZ(exception * this)
 * public: virtual char const * __ptr64 __cdecl exception::what(void)const __ptr64
 * ========================================================================== */

/* public: virtual char const * __ptr64 __cdecl exception::what(void)const __ptr64 */

char * __thiscall exception::_what_exception__UEBAPEBDXZ(exception *this)

{
  char *pcVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140014780. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pcVar1 = what(this);
  return pcVar1;
}



/* ==========================================================================
 * _CxxThrowException @ 0x14001478c  (6 bytes, 1 instructions)
 * void _CxxThrowException(void * pExceptionObject, ThrowInfo * pThrowInfo)
 * ========================================================================== */

void __stdcall _CxxThrowException(void *pExceptionObject,ThrowInfo *pThrowInfo)

{
                    /* WARNING: Could not recover jumptable at 0x00014001478c. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  _CxxThrowException(pExceptionObject,pThrowInfo);
  return;
}



/* ==========================================================================
 * __CxxUnhandledExceptionFilter @ 0x1400147a0  (56 bytes, 16 instructions)
 * long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS * param_1)
 * long __cdecl __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS * __ptr64)
 * ========================================================================== */

/* long __cdecl __CxxUnhandledExceptionFilter(struct _EXCEPTION_POINTERS * __ptr64) */

long __cdecl __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS *param_1)

{
  int iVar1;
  PEXCEPTION_RECORD pEVar2;
  
  pEVar2 = param_1->ExceptionRecord;
  if (((pEVar2->ExceptionCode == 0xe06d7363) && (pEVar2->NumberParameters == 4)) &&
     ((iVar1 = (int)pEVar2->ExceptionInformation[0], iVar1 + 0xe66cfae0U < 3 || (iVar1 == 0x1994000)
      ))) {
                    /* WARNING: Subroutine does not return */
    terminate();
  }
  return 0;
}



/* ==========================================================================
 * __CxxSetUnhandledExceptionFilter @ 0x1400147e0  (24 bytes, 6 instructions)
 * undefined8 __CxxSetUnhandledExceptionFilter(void)
 * ========================================================================== */

undefined8 __CxxSetUnhandledExceptionFilter(void)

{
  SetUnhandledExceptionFilter(__CxxUnhandledExceptionFilter);
  return 0;
}



/* ==========================================================================
 * _XcptFilter @ 0x1400147fe  (6 bytes, 1 instructions)
 * int _XcptFilter(ulong _ExceptionNum, _EXCEPTION_POINTERS * _ExceptionPtr)
 * ========================================================================== */

int __cdecl _XcptFilter(ulong _ExceptionNum,_EXCEPTION_POINTERS *_ExceptionPtr)

{
  int iVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0001400147fe. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  iVar1 = _XcptFilter(_ExceptionNum,_ExceptionPtr);
  return iVar1;
}



/* ==========================================================================
 * RtlpImageNtHeader @ 0x14001480c  (78 bytes, 23 instructions)
 * int * RtlpImageNtHeader(short * param_1)
 * ========================================================================== */

int * RtlpImageNtHeader(short *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)0x0;
  piVar2 = piVar1;
  if (((((longlong)param_1 - 1U < 0xfffffffffffffffe) && (*param_1 == 0x5a4d)) &&
      (-1 < *(int *)(param_1 + 0x1e))) &&
     ((*(uint *)(param_1 + 0x1e) < 0x10000000 &&
      (piVar2 = (int *)((longlong)*(int *)(param_1 + 0x1e) + (longlong)param_1),
      *(int *)((longlong)*(int *)(param_1 + 0x1e) + (longlong)param_1) != 0x4550)))) {
    piVar2 = piVar1;
  }
  return piVar2;
}



/* ==========================================================================
 * _get_image_app_type @ 0x140014868  (69 bytes, 23 instructions)
 * undefined4 _get_image_app_type(undefined4 param_1)
 * ========================================================================== */

undefined4 _get_image_app_type(undefined4 param_1)

{
  HMODULE pHVar1;
  int *piVar2;
  
  pHVar1 = GetModuleHandleW((LPCWSTR)0x0);
  if ((pHVar1 != (HMODULE)0x0) &&
     (piVar2 = RtlpImageNtHeader((short *)pHVar1), piVar2 != (int *)0x0)) {
    if ((short)piVar2[0x17] == 2) {
      return 2;
    }
    if ((short)piVar2[0x17] == 3) {
      return 1;
    }
  }
  return param_1;
}



/* ==========================================================================
 * _amsg_exit @ 0x1400148b3  (6 bytes, 1 instructions)
 * void _amsg_exit(int param_1)
 * ========================================================================== */

void __cdecl _amsg_exit(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001400148b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _amsg_exit(param_1);
  return;
}



/* ==========================================================================
 * _wsetargv @ 0x1400148c0  (3 bytes, 2 instructions)
 * int _wsetargv(_exception * _Except)
 * ========================================================================== */

int __cdecl _wsetargv(_exception *_Except)

{
  return 0;
}



/* ==========================================================================
 * _FindPESection @ 0x1400148d0  (68 bytes, 23 instructions)
 * PIMAGE_SECTION_HEADER _FindPESection(PBYTE pImageBase, DWORD_PTR rva)
 * ========================================================================== */

PIMAGE_SECTION_HEADER __cdecl _FindPESection(PBYTE pImageBase,DWORD_PTR rva)

{
  int iVar1;
  PIMAGE_SECTION_HEADER p_Var2;
  uint uVar3;
  
  iVar1 = *(int *)(pImageBase + 0x3c);
  uVar3 = 0;
  p_Var2 = (PIMAGE_SECTION_HEADER)
           (pImageBase +
           (ulonglong)*(ushort *)(pImageBase + (longlong)iVar1 + 0x14) + 0x18 + (longlong)iVar1);
  if (*(ushort *)(pImageBase + (longlong)iVar1 + 6) != 0) {
    do {
      if ((p_Var2->VirtualAddress <= rva) &&
         (rva < (p_Var2->Misc).PhysicalAddress + p_Var2->VirtualAddress)) {
        return p_Var2;
      }
      uVar3 = uVar3 + 1;
      p_Var2 = p_Var2 + 1;
    } while (uVar3 < *(ushort *)(pImageBase + (longlong)iVar1 + 6));
  }
  return (PIMAGE_SECTION_HEADER)0x0;
}



/* ==========================================================================
 * _IsNonwritableInCurrentImage @ 0x140014920  (75 bytes, 24 instructions)
 * BOOL _IsNonwritableInCurrentImage(PBYTE pTarget)
 * ========================================================================== */

BOOL __cdecl _IsNonwritableInCurrentImage(PBYTE pTarget)

{
  BOOL BVar1;
  uint uVar2;
  PIMAGE_SECTION_HEADER p_Var3;
  
  BVar1 = _ValidateImageBase((PBYTE)&IMAGE_DOS_HEADER_140000000);
  uVar2 = 0;
  if (BVar1 != 0) {
    p_Var3 = _FindPESection((PBYTE)&IMAGE_DOS_HEADER_140000000,(DWORD_PTR)(pTarget + -0x140000000));
    uVar2 = 0;
    if (p_Var3 != (PIMAGE_SECTION_HEADER)0x0) {
      uVar2 = ~(p_Var3->Characteristics >> 0x1f) & 1;
    }
  }
  return uVar2;
}



/* ==========================================================================
 * _ValidateImageBase @ 0x140014980  (45 bytes, 14 instructions)
 * BOOL _ValidateImageBase(PBYTE pImageBase)
 * ========================================================================== */

BOOL __cdecl _ValidateImageBase(PBYTE pImageBase)

{
  if (((*(short *)pImageBase == 0x5a4d) &&
      (*(int *)(pImageBase + *(int *)(pImageBase + 0x3c)) == 0x4550)) &&
     ((short)*(int *)((longlong)(pImageBase + *(int *)(pImageBase + 0x3c)) + 0x18) == 0x20b)) {
    return 1;
  }
  return 0;
}



/* ==========================================================================
 * __security_init_cookie @ 0x1400149b4  (212 bytes, 49 instructions)
 * void __security_init_cookie(void)
 * ========================================================================== */

void __cdecl __security_init_cookie(void)

{
  DWORD DVar1;
  _FILETIME local_res8;
  _FILETIME local_res10;
  LARGE_INTEGER local_res18;
  
  local_res10.dwLowDateTime = 0;
  local_res10.dwHighDateTime = 0;
  if (__security_cookie == 0x2b992ddfa232) {
    GetSystemTimeAsFileTime(&local_res10);
    local_res8 = local_res10;
    DVar1 = GetCurrentProcessId();
    local_res8 = (_FILETIME)((ulonglong)local_res8 ^ (ulonglong)DVar1);
    DVar1 = GetCurrentThreadId();
    local_res8 = (_FILETIME)((ulonglong)local_res8 ^ (ulonglong)DVar1);
    DVar1 = GetTickCount();
    local_res8 = (_FILETIME)((ulonglong)local_res8 ^ (ulonglong)DVar1 << 0x18);
    DVar1 = GetTickCount();
    local_res8 = (_FILETIME)((ulonglong)DVar1 ^ (ulonglong)local_res8 ^ (ulonglong)&local_res8);
    QueryPerformanceCounter(&local_res18);
    __security_cookie =
         ((ulonglong)local_res18.s.LowPart << 0x20 ^
          CONCAT44(local_res18.s.HighPart,local_res18.s.LowPart) ^ (ulonglong)local_res8) &
         0xffffffffffff;
    if (__security_cookie == 0x2b992ddfa232) {
      __security_cookie = 0x2b992ddfa233;
    }
  }
  __security_cookie_complement = ~__security_cookie;
  return;
}



/* ==========================================================================
 * _initterm @ 0x140014a8e  (6 bytes, 1 instructions)
 * undefined _initterm()
 * ========================================================================== */

void _initterm(void)

{
                    /* WARNING: Could not recover jumptable at 0x000140014a8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _initterm();
  return;
}



/* ==========================================================================
 * __C_specific_handler @ 0x140014a9a  (6 bytes, 1 instructions)
 * EXCEPTION_DISPOSITION __C_specific_handler(_EXCEPTION_RECORD * ExceptionRecord, void * EstablisherFrame, _CONTEXT * ContextRecord, _DISPATCHER_CONTEXT * DispatcherContext)
 * ========================================================================== */

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

EXCEPTION_DISPOSITION
__C_specific_handler
          (_EXCEPTION_RECORD *ExceptionRecord,void *EstablisherFrame,_CONTEXT *ContextRecord,
          _DISPATCHER_CONTEXT *DispatcherContext)

{
  EXCEPTION_DISPOSITION EVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140014a9a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EVar1 = __C_specific_handler(ExceptionRecord,EstablisherFrame,ContextRecord,DispatcherContext);
  return EVar1;
}



/* ==========================================================================
 * _guard_check_icall @ 0x140014ab0  (3 bytes, 1 instructions)
 * undefined _guard_check_icall(void)
 * ========================================================================== */

void _guard_check_icall(void)

{
  return;
}



/* ==========================================================================
 * ??0?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@PEBD@Z @ 0x140014ac8  (53 bytes, 16 instructions)
 * undefined ??0?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@PEBD@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1)
 * public: __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>(char const * __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>(char const * __ptr64) __ptr64 */

basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__0__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_PEBD_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,char *param_1
          )

{
  __uint64 _Var1;
  
  *(undefined8 *)(this + 0x20) = 0xf;
  *(undefined8 *)(this + 0x18) = 0;
  this[8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  _Var1 = 0xffffffffffffffff;
  do {
    _Var1 = _Var1 + 1;
  } while (param_1[_Var1] != '\0');
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_PEBD_K_Z
            (this,param_1,_Var1);
  return this;
}



/* ==========================================================================
 * ??0length_error@std@@QEAA@AEBV01@@Z @ 0x140014b04  (108 bytes, 27 instructions)
 * undefined ??0length_error@std@@QEAA@AEBV01@@Z(length_error * this, length_error * param_1)
 * public: __cdecl std::length_error::length_error(class std::length_error const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::length_error::length_error(class std::length_error const & __ptr64) __ptr64
    */

length_error * __thiscall
std::length_error::__0length_error_std__QEAA_AEBV01__Z(length_error *this,length_error *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &logic_error::_vftable_;
  *(undefined8 *)(this + 0x38) = 0xf;
  *(undefined8 *)(this + 0x30) = 0;
  this[0x20] = (length_error)0x0;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)(param_1 + 0x18),0,0xffffffffffffffff);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??0length_error@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@@Z @ 0x140014b78  (113 bytes, 31 instructions)
 * undefined ??0length_error@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@@Z(length_error * this, basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * param_1)
 * public: __cdecl std::length_error::length_error(class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::length_error::length_error(class std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64) __ptr64 */

length_error * __thiscall
std::length_error::
__0length_error_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1__Z
          (length_error *this,
          basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *param_1)

{
  exception::__0exception__QEAA_XZ((exception *)this);
  *(undefined ***)this = &logic_error::_vftable_;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             false,0);
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)param_1,0,0xffffffffffffffff);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??0logic_error@std@@QEAA@AEBV01@@Z @ 0x140014bf0  (98 bytes, 25 instructions)
 * undefined ??0logic_error@std@@QEAA@AEBV01@@Z(logic_error * this, logic_error * param_1)
 * public: __cdecl std::logic_error::logic_error(class std::logic_error const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::logic_error::logic_error(class std::logic_error const & __ptr64) __ptr64 */

logic_error * __thiscall
std::logic_error::__0logic_error_std__QEAA_AEBV01__Z(logic_error *this,logic_error *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &_vftable_;
  *(undefined8 *)(this + 0x38) = 0xf;
  *(undefined8 *)(this + 0x30) = 0;
  this[0x20] = (logic_error)0x0;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)(param_1 + 0x18),0,0xffffffffffffffff);
  return this;
}



/* ==========================================================================
 * ??0out_of_range@std@@QEAA@AEBV01@@Z @ 0x140014c58  (108 bytes, 27 instructions)
 * undefined ??0out_of_range@std@@QEAA@AEBV01@@Z(out_of_range * this, out_of_range * param_1)
 * public: __cdecl std::out_of_range::out_of_range(class std::out_of_range const & __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::out_of_range::out_of_range(class std::out_of_range const & __ptr64) __ptr64
    */

out_of_range * __thiscall
std::out_of_range::__0out_of_range_std__QEAA_AEBV01__Z(out_of_range *this,out_of_range *param_1)

{
  exception::__0exception__QEAA_AEBV0__Z((exception *)this,(exception *)param_1);
  *(undefined ***)this = &logic_error::_vftable_;
  *(undefined8 *)(this + 0x38) = 0xf;
  *(undefined8 *)(this + 0x30) = 0;
  this[0x20] = (out_of_range)0x0;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)(param_1 + 0x18),0,0xffffffffffffffff);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??0out_of_range@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@PEAV_STL70@@@Z @ 0x140014ccc  (113 bytes, 31 instructions)
 * undefined ??0out_of_range@std@@QEAA@AEBV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@1@PEAV_STL70@@@Z(out_of_range * this, basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * param_1, _STL70 * param_2)
 * public: __cdecl std::out_of_range::out_of_range(class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64,class _STL70 * __ptr64) __ptr64
 * ========================================================================== */

/* public: __cdecl std::out_of_range::out_of_range(class std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64,class _STL70 *
   __ptr64) __ptr64 */

out_of_range * __thiscall
std::out_of_range::
__0out_of_range_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1_PEAV_STL70___Z
          (out_of_range *this,
          basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *param_1,
          _STL70 *param_2)

{
  exception::__0exception__QEAA_XZ((exception *)this);
  *(undefined ***)this = &logic_error::_vftable_;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             false,0);
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)(this + 0x18),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
              *)param_1,0,0xffffffffffffffff);
  *(undefined ***)this = &_vftable_;
  return this;
}



/* ==========================================================================
 * ??1?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@XZ @ 0x140014d44  (48 bytes, 13 instructions)
 * void ??1?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAA@XZ(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this)
 * public: __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::~basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>(void) __ptr64
 * ========================================================================== */

/* public: __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::~basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>(void) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__1__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_XZ
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this)

{
  if (0xf < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(undefined8 *)(this + 0x18) = 0;
  *(undefined8 *)(this + 0x20) = 0xf;
  this[8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}



/* ==========================================================================
 * ??1logic_error@std@@UEAA@XZ @ 0x140014d7c  (65 bytes, 16 instructions)
 * void ??1logic_error@std@@UEAA@XZ(logic_error * this)
 * public: virtual __cdecl std::logic_error::~logic_error(void) __ptr64
 * ========================================================================== */

/* public: virtual __cdecl std::logic_error::~logic_error(void) __ptr64 */

void __thiscall std::logic_error::__1logic_error_std__UEAA_XZ(logic_error *this)

{
  *(undefined ***)this = &_vftable_;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    operator_delete__(*(void **)(this + 0x20));
  }
  *(undefined8 *)(this + 0x30) = 0;
  *(undefined8 *)(this + 0x38) = 0xf;
  this[0x20] = (logic_error)0x0;
  exception::__1exception__UEAA_XZ((exception *)this);
  return;
}



/* ==========================================================================
 * ??_Eout_of_range@std@@UEAAPEAXI@Z @ 0x140014dd0  (94 bytes, 25 instructions)
 * void * ??_Eout_of_range@std@@UEAAPEAXI@Z(out_of_range * this, uint param_1)
 * public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned int) __ptr64
 * ========================================================================== */

/* public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
std::out_of_range::___Eout_of_range_std__UEAAPEAXI_Z(out_of_range *this,uint param_1)

{
  *(undefined ***)this = &logic_error::_vftable_;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    operator_delete__(*(void **)(this + 0x20));
  }
  *(undefined8 *)(this + 0x30) = 0;
  *(undefined8 *)(this + 0x38) = 0xf;
  this[0x20] = (out_of_range)0x0;
  exception::__1exception__UEAA_XZ((exception *)this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}



/* ==========================================================================
 * ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_K0@Z @ 0x140014e34  (257 bytes, 76 instructions)
 * void ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::_Copy(unsigned __int64,unsigned __int64) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          __uint64 param_1,__uint64 param_2)

{
  __uint64 _Var1;
  ulonglong uVar2;
  undefined1 auVar3 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *_Dst;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  bad_alloc local_60 [64];
  
  uVar5 = param_1 | 0xf;
  if (uVar5 != 0xffffffffffffffff) {
    uVar2 = *(ulonglong *)(this + 0x20);
    uVar6 = uVar2 >> 1;
    param_1 = uVar5;
    if ((uVar5 / 3 < uVar6) && (uVar2 <= -uVar6 - 2)) {
      param_1 = uVar6 + uVar2;
    }
  }
  _Var1 = param_1 + 1;
  if ((_Var1 != 0) &&
     (auVar3._8_8_ = 0, auVar3._0_8_ = _Var1,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar3,0) == 0)) {
    bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z(local_60,(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_60,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  _Dst = operator_new(_Var1);
  if (param_2 != 0) {
    pbVar4 = this + 8;
    if (0xf < *(ulonglong *)(this + 0x20)) {
      pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    memcpy_s(_Dst,param_1 + 1,pbVar4,param_2);
  }
  if (0xf < *(ulonglong *)(this + 0x20)) {
    operator_delete__(*(void **)(this + 8));
  }
  *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)(this + 8) = _Dst;
  *(__uint64 *)(this + 0x20) = param_1;
  *(__uint64 *)(this + 0x18) = param_2;
  pbVar4 = this + 8;
  if (0xf < param_1) {
    pbVar4 = _Dst;
  }
  pbVar4[param_2] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}



/* ==========================================================================
 * ?_Doraise@length_error@std@@MEBAXXZ @ 0x140014f60  (49 bytes, 10 instructions)
 * void ?_Doraise@length_error@std@@MEBAXXZ(length_error * this)
 * protected: virtual void __cdecl std::length_error::_Doraise(void)const __ptr64
 * ========================================================================== */

/* protected: virtual void __cdecl std::length_error::_Doraise(void)const __ptr64 */

void __thiscall std::length_error::__Doraise_length_error_std__MEBAXXZ(length_error *this)

{
  undefined1 auStack_78 [32];
  length_error local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0length_error_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVlength_error_std__);
}



/* ==========================================================================
 * ?_Doraise@logic_error@std@@MEBAXXZ @ 0x140014fa0  (49 bytes, 10 instructions)
 * void ?_Doraise@logic_error@std@@MEBAXXZ(logic_error * this)
 * protected: virtual void __cdecl std::logic_error::_Doraise(void)const __ptr64
 * ========================================================================== */

/* protected: virtual void __cdecl std::logic_error::_Doraise(void)const __ptr64 */

void __thiscall std::logic_error::__Doraise_logic_error_std__MEBAXXZ(logic_error *this)

{
  undefined1 auStack_78 [32];
  logic_error local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0logic_error_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI2_AVlogic_error_std__);
}



/* ==========================================================================
 * ?_Doraise@out_of_range@std@@MEBAXXZ @ 0x140014fe0  (49 bytes, 10 instructions)
 * void ?_Doraise@out_of_range@std@@MEBAXXZ(out_of_range * this)
 * protected: virtual void __cdecl std::out_of_range::_Doraise(void)const __ptr64
 * ========================================================================== */

/* protected: virtual void __cdecl std::out_of_range::_Doraise(void)const __ptr64 */

void __thiscall std::out_of_range::__Doraise_out_of_range_std__MEBAXXZ(out_of_range *this)

{
  undefined1 auStack_78 [32];
  out_of_range local_58 [64];
  ulonglong local_18;
  
  local_18 = __security_cookie ^ (ulonglong)auStack_78;
  __0out_of_range_std__QEAA_AEBV01__Z(local_58,this);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVout_of_range_std__);
}



/* ==========================================================================
 * ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_N_K@Z @ 0x140015018  (100 bytes, 28 instructions)
 * void ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@IEAAX_N_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, bool param_1, __uint64 param_2)
 * protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64
 * ========================================================================== */

/* protected: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70>::_Tidy(bool,unsigned __int64) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
__Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,bool param_1,
          __uint64 param_2)

{
  void *_Src;
  
  if ((param_1) && (0xf < *(ulonglong *)(this + 0x20))) {
    _Src = *(void **)(this + 8);
    if (param_2 != 0) {
      memcpy_s(this + 8,0x10,_Src,param_2);
    }
    operator_delete__(_Src);
  }
  *(undefined8 *)(this + 0x20) = 0xf;
  *(__uint64 *)(this + 0x18) = param_2;
  this[param_2 + 8] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return;
}



/* ==========================================================================
 * ?_Xlen@_String_base@std@@SAXXZ @ 0x140015084  (84 bytes, 15 instructions)
 * void ?_Xlen@_String_base@std@@SAXXZ(void)
 * public: static void __cdecl std::_String_base::_Xlen(void)
 * ========================================================================== */

/* public: static void __cdecl std::_String_base::_Xlen(void) */

void __cdecl std::_String_base::__Xlen__String_base_std__SAXXZ(void)

{
  undefined1 auStack_a8 [32];
  undefined8 local_88;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> local_80 [40];
  length_error local_58 [64];
  ulonglong local_18;
  
  local_88 = 0xfffffffffffffffe;
  local_18 = __security_cookie ^ (ulonglong)auStack_a8;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __0__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_PEBD_Z
            (local_80,"string too long");
  length_error::
  __0length_error_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1__Z
            (local_58,local_80);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVlength_error_std__);
}



/* ==========================================================================
 * ?_Xran@_String_base@std@@SAXXZ @ 0x1400150e0  (87 bytes, 16 instructions)
 * void ?_Xran@_String_base@std@@SAXXZ(void)
 * public: static void __cdecl std::_String_base::_Xran(void)
 * ========================================================================== */

/* public: static void __cdecl std::_String_base::_Xran(void) */

void __cdecl std::_String_base::__Xran__String_base_std__SAXXZ(void)

{
  undefined1 auStack_a8 [32];
  undefined8 local_88;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> local_80 [40];
  out_of_range local_58 [64];
  ulonglong local_18;
  
  local_88 = 0xfffffffffffffffe;
  local_18 = __security_cookie ^ (ulonglong)auStack_a8;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __0__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_PEBD_Z
            (local_80,"invalid string position");
  out_of_range::
  __0out_of_range_std__QEAA_AEBV__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___1_PEAV_STL70___Z
            (local_58,local_80,(_STL70 *)0x0);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_58,(ThrowInfo *)&_TI3_AVout_of_range_std__);
}



/* ==========================================================================
 * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z @ 0x140015140  (246 bytes, 70 instructions)
 * basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * param_1, __uint64 param_2, __uint64 param_3)
 * public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> const & __ptr64,unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(class
   std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>
   const & __ptr64,unsigned __int64,unsigned __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
          *param_1,__uint64 param_2,__uint64 param_3)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar1;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *_Dst;
  ulonglong _MaxCount;
  
  if (*(ulonglong *)(param_1 + 0x18) < param_2) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xran__String_base_std__SAXXZ();
  }
  _MaxCount = *(ulonglong *)(param_1 + 0x18) - param_2;
  if (param_3 < _MaxCount) {
    _MaxCount = param_3;
  }
  if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)param_1) {
    _erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
              (this,_MaxCount + param_2,0xffffffffffffffff);
    _erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
              (this,0,param_2);
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
  if (_MaxCount == 0xffffffffffffffff) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xlen__String_base_std__SAXXZ();
  }
  if (*(ulonglong *)(this + 0x20) < _MaxCount) {
    __Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
              (this,_MaxCount,*(__uint64 *)(this + 0x18));
  }
  else {
    if (_MaxCount != 0) goto LAB_1400151d2;
    *(undefined8 *)(this + 0x18) = 0;
    pbVar1 = this + 8;
    if (0xf < *(ulonglong *)(this + 0x20)) {
      pbVar1 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
    }
    *pbVar1 = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  }
  if (_MaxCount == 0) {
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
LAB_1400151d2:
  pbVar2 = param_1 + 8;
  if (0xf < *(ulonglong *)(param_1 + 0x20)) {
    pbVar2 = *(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
               **)pbVar2;
  }
  pbVar1 = this + 8;
  _Dst = pbVar1;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    _Dst = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
  }
  memcpy_s(_Dst,*(ulonglong *)(this + 0x20),pbVar2 + param_2,_MaxCount);
  *(ulonglong *)(this + 0x18) = _MaxCount;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar1 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar1;
  }
  pbVar1[_MaxCount] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
         )this;
}



/* ==========================================================================
 * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@PEBD_K@Z @ 0x140015240  (245 bytes, 77 instructions)
 * basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@PEBD_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, char * param_1, __uint64 param_2)
 * public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(char const * __ptr64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::assign(char const *
   __ptr64,unsigned __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_PEBD_K_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,char *param_1
          ,__uint64 param_2)

{
  ulonglong uVar1;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar3;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  
  pbVar4 = this + 8;
  uVar1 = *(ulonglong *)(this + 0x20);
  pbVar3 = pbVar4;
  if (0xf < uVar1) {
    pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  if (pbVar3 <= param_1) {
    pbVar3 = pbVar4;
    if (0xf < uVar1) {
      pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    if (param_1 < pbVar3 + *(longlong *)(this + 0x18)) {
      if (0xf < uVar1) {
        pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      pbVar2 = _assign___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12_AEBV12__K1_Z
                         (this,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
                                *)this,(longlong)param_1 - (longlong)pbVar4,param_2);
      return pbVar2;
    }
  }
  if (param_2 == 0xffffffffffffffff) {
                    /* WARNING: Subroutine does not return */
    _String_base::__Xlen__String_base_std__SAXXZ();
  }
  if (uVar1 < param_2) {
    __Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_K0_Z
              (this,param_2,*(__uint64 *)(this + 0x18));
  }
  else {
    if (param_2 != 0) goto LAB_1400152e9;
    *(undefined8 *)(this + 0x18) = 0;
    pbVar3 = pbVar4;
    if (0xf < uVar1) {
      pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
    }
    *pbVar3 = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  }
  if (param_2 == 0) {
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
LAB_1400152e9:
  pbVar3 = pbVar4;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  memcpy_s(pbVar3,*(ulonglong *)(this + 0x20),param_1,param_2);
  *(__uint64 *)(this + 0x18) = param_2;
  if (0xf < *(ulonglong *)(this + 0x20)) {
    pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
  }
  pbVar4[param_2] = (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
  return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
         )this;
}



/* ==========================================================================
 * ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z @ 0x14001533c  (149 bytes, 46 instructions)
 * basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> * ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@V_STL70@@@std@@QEAAAEAV12@_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> * this, __uint64 param_1, __uint64 param_2)
 * public: class std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char>,class _STL70>::erase(unsigned __int64,unsigned __int64) __ptr64
 * ========================================================================== */

/* public: class std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char>,class _STL70> & __ptr64 __cdecl std::basic_string<char,struct
   std::char_traits<char>,class std::allocator<char>,class _STL70>::erase(unsigned __int64,unsigned
   __int64) __ptr64 */

basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70> *
__thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
_erase___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAAAEAV12__K0_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *this,
          __uint64 param_1,__uint64 param_2)

{
  longlong lVar1;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar3;
  basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *pbVar4;
  ulonglong uVar5;
  
  if (param_1 <= *(ulonglong *)(this + 0x18)) {
    uVar5 = *(ulonglong *)(this + 0x18) - param_1;
    if (uVar5 < param_2) {
      param_2 = uVar5;
    }
    if (param_2 != 0) {
      pbVar4 = this + 8;
      pbVar3 = pbVar4;
      pbVar2 = pbVar4;
      if (0xf < *(ulonglong *)(this + 0x20)) {
        pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
        pbVar2 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      memmove_s(pbVar3 + param_1,*(ulonglong *)(this + 0x20) - param_1,pbVar2 + param_2 + param_1,
                uVar5 - param_2);
      lVar1 = *(longlong *)(this + 0x18);
      *(__uint64 *)(this + 0x18) = lVar1 - param_2;
      if (0xf < *(ulonglong *)(this + 0x20)) {
        pbVar4 = *(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)pbVar4;
      }
      pbVar4[lVar1 - param_2] =
           (basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>)0x0;
    }
    return (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>,class__STL70>
            *)this;
  }
                    /* WARNING: Subroutine does not return */
  _String_base::__Xran__String_base_std__SAXXZ();
}



/* ==========================================================================
 * ?what@logic_error@std@@UEBAPEBDXZ @ 0x1400153e0  (15 bytes, 5 instructions)
 * char * ?what@logic_error@std@@UEBAPEBDXZ(logic_error * this)
 * public: virtual char const * __ptr64 __cdecl std::logic_error::what(void)const __ptr64
 * ========================================================================== */

/* public: virtual char const * __ptr64 __cdecl std::logic_error::what(void)const __ptr64 */

char * __thiscall std::logic_error::_what_logic_error_std__UEBAPEBDXZ(logic_error *this)

{
  logic_error *plVar1;
  
  plVar1 = this + 0x20;
  if (0xf < *(ulonglong *)(this + 0x38)) {
    plVar1 = *(logic_error **)plVar1;
  }
  return (char *)plVar1;
}



/* ==========================================================================
 * memcpy_s @ 0x1400153f5  (6 bytes, 1 instructions)
 * errno_t memcpy_s(void * _Dst, rsize_t _DstSize, void * _Src, rsize_t _MaxCount)
 * ========================================================================== */

errno_t __cdecl memcpy_s(void *_Dst,rsize_t _DstSize,void *_Src,rsize_t _MaxCount)

{
  errno_t eVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0001400153f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  eVar1 = memcpy_s(_Dst,_DstSize,_Src,_MaxCount);
  return eVar1;
}



/* ==========================================================================
 * `eh_vector_destructor_iterator' @ 0x140015404  (5 bytes, 1 instructions)
 * void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4)
 * void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,unsigned __int64,void (__cdecl*)(void * __ptr64))
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,unsigned
   __int64,void (__cdecl*)(void * __ptr64)) */

void __cdecl
_eh_vector_destructor_iterator_
          (void *param_1,__uint64 param_2,__uint64 param_3,_func_void_void_ptr *param_4)

{
  uint uVar1;
  ulonglong uVar2;
  void *pvVar3;
  
  uVar2 = (ulonglong)(int)param_3;
  pvVar3 = (void *)(uVar2 * param_2 + (longlong)param_1);
  while( true ) {
    uVar1 = (int)uVar2 - 1;
    uVar2 = (ulonglong)uVar1;
    if ((int)uVar1 < 0) break;
    pvVar3 = (void *)((longlong)pvVar3 - param_2);
    (*param_4)(pvVar3);
  }
  return;
}



/* ==========================================================================
 * `eh_vector_destructor_iterator' @ 0x140015410  (103 bytes, 34 instructions)
 * void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4)
 * void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,int,void (__cdecl*)(void * __ptr64))
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl `eh vector destructor iterator'(void * __ptr64,unsigned __int64,int,void
   (__cdecl*)(void * __ptr64)) */

void __cdecl
_eh_vector_destructor_iterator_
          (void *param_1,__uint64 param_2,int param_3,_func_void_void_ptr *param_4)

{
  uint uVar1;
  ulonglong uVar2;
  void *pvVar3;
  
  uVar2 = (ulonglong)param_3;
  pvVar3 = (void *)(uVar2 * param_2 + (longlong)param_1);
  while( true ) {
    uVar1 = (int)uVar2 - 1;
    uVar2 = (ulonglong)uVar1;
    if ((int)uVar1 < 0) break;
    pvVar3 = (void *)((longlong)pvVar3 - param_2);
    (*param_4)(pvVar3);
  }
  return;
}



/* ==========================================================================
 * __ArrayUnwind @ 0x140015480  (82 bytes, 27 instructions)
 * void __ArrayUnwind(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4)
 * void __cdecl __ArrayUnwind(void * __ptr64,unsigned __int64,int,void (__cdecl*)(void * __ptr64))
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl __ArrayUnwind(void * __ptr64,unsigned __int64,int,void (__cdecl*)(void * __ptr64))
    */

void __cdecl __ArrayUnwind(void *param_1,__uint64 param_2,int param_3,_func_void_void_ptr *param_4)

{
  while( true ) {
    param_3 = param_3 + -1;
    if (param_3 < 0) break;
    param_1 = (void *)((longlong)param_1 - param_2);
    (*param_4)(param_1);
  }
  return;
}



/* ==========================================================================
 * memmove_s @ 0x1400154d8  (6 bytes, 1 instructions)
 * errno_t memmove_s(void * _Dst, rsize_t _DstSize, void * _Src, rsize_t _MaxCount)
 * ========================================================================== */

errno_t __cdecl memmove_s(void *_Dst,rsize_t _DstSize,void *_Src,rsize_t _MaxCount)

{
  errno_t eVar1;
  
                    /* WARNING: Could not recover jumptable at 0x0001400154d8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  eVar1 = memmove_s(_Dst,_DstSize,_Src,_MaxCount);
  return eVar1;
}



/* ==========================================================================
 * `eh_vector_constructor_iterator' @ 0x1400154e4  (5 bytes, 1 instructions)
 * void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5)
 * void __cdecl `eh vector constructor iterator'(void * __ptr64,unsigned __int64,unsigned __int64,void (__cdecl*)(void * __ptr64),void (__cdecl*)(void * __ptr64))
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl `eh vector constructor iterator'(void * __ptr64,unsigned __int64,unsigned
   __int64,void (__cdecl*)(void * __ptr64),void (__cdecl*)(void * __ptr64)) */

void __cdecl
_eh_vector_constructor_iterator_
          (void *param_1,__uint64 param_2,__uint64 param_3,_func_void_void_ptr *param_4,
          _func_void_void_ptr *param_5)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 < (int)param_3; iVar1 = iVar1 + 1) {
    (*param_4)(param_1);
    param_1 = (void *)((longlong)param_1 + param_2);
  }
  return;
}



/* ==========================================================================
 * `eh_vector_constructor_iterator' @ 0x1400154f0  (109 bytes, 34 instructions)
 * void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5)
 * void __cdecl `eh vector constructor iterator'(void * __ptr64,unsigned __int64,int,void (__cdecl*)(void * __ptr64),void (__cdecl*)(void * __ptr64))
 * ========================================================================== */

/* WARNING: Function: _guard_dispatch_icall replaced with injection: guard_dispatch_icall */
/* void __cdecl `eh vector constructor iterator'(void * __ptr64,unsigned __int64,int,void
   (__cdecl*)(void * __ptr64),void (__cdecl*)(void * __ptr64)) */

void __cdecl
_eh_vector_constructor_iterator_
          (void *param_1,__uint64 param_2,int param_3,_func_void_void_ptr *param_4,
          _func_void_void_ptr *param_5)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 < param_3; iVar1 = iVar1 + 1) {
    (*param_4)(param_1);
    param_1 = (void *)((longlong)param_1 + param_2);
  }
  return;
}



/* ==========================================================================
 * ??0exception@@QEAA@XZ @ 0x140015563  (6 bytes, 1 instructions)
 * undefined ??0exception@@QEAA@XZ(exception * this)
 * public: __cdecl exception::exception(void) __ptr64
 * ========================================================================== */

/* public: __cdecl exception::exception(void) __ptr64 */

void __thiscall exception::__0exception__QEAA_XZ(exception *this)

{
                    /* WARNING: Could not recover jumptable at 0x000140015563. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this);
  return;
}



/* ==========================================================================
 * __GSHandlerCheck @ 0x140015570  (29 bytes, 8 instructions)
 * undefined8 __GSHandlerCheck(undefined8 param_1, undefined8 param_2, undefined8 param_3, longlong param_4)
 * ========================================================================== */

undefined8
__GSHandlerCheck(undefined8 param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  __GSHandlerCheckCommon(param_2,param_4);
  return 1;
}



/* ==========================================================================
 * __GSHandlerCheckCommon @ 0x140015594  (91 bytes, 28 instructions)
 * ulonglong __GSHandlerCheckCommon(undefined8 param_1, longlong param_2)
 * ========================================================================== */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong __GSHandlerCheckCommon(undefined8 param_1,longlong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  
  uVar2 = (ulonglong)*(uint *)(*(longlong *)(param_2 + 0x10) + 8);
  uVar1 = *(ulonglong *)(param_2 + 8);
  if ((*(byte *)(uVar2 + 3 + uVar1) & 0xf) != 0) {
    uVar1 = (ulonglong)(*(byte *)(uVar2 + 3 + uVar1) & 0xfffffff0);
  }
  return uVar1;
}



/* ==========================================================================
 * __GSHandlerCheck_EH @ 0x1400155f8  (127 bytes, 37 instructions)
 * undefined __GSHandlerCheck_EH(longlong param_1, undefined8 param_2, undefined8 param_3, longlong param_4)
 * ========================================================================== */

void __GSHandlerCheck_EH(longlong param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_4 + 0x38);
  __GSHandlerCheckCommon(param_2,param_4);
  if ((*(uint *)(lVar1 + 4) & ((*(uint *)(param_1 + 4) & 0x66) != 0) + 1) != 0) {
                    /* WARNING: Subroutine does not return */
    __CxxFrameHandler3(param_1,param_2,param_3,param_4);
  }
  return;
}



/* ==========================================================================
 * memcpy @ 0x140015686  (6 bytes, 1 instructions)
 * void * memcpy(void * _Dst, void * _Src, size_t _Size)
 * ========================================================================== */

void * __cdecl memcpy(void *_Dst,void *_Src,size_t _Size)

{
  void *pvVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140015686. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = memcpy(_Dst,_Src,_Size);
  return pvVar1;
}



/* ==========================================================================
 * memset @ 0x140015692  (6 bytes, 1 instructions)
 * void * memset(void * _Dst, int _Val, size_t _Size)
 * ========================================================================== */

void * __cdecl memset(void *_Dst,int _Val,size_t _Size)

{
  void *pvVar1;
  
                    /* WARNING: Could not recover jumptable at 0x000140015692. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = memset(_Dst,_Val,_Size);
  return pvVar1;
}



/* ==========================================================================
 * _guard_dispatch_icall @ 0x1400156b0  (2 bytes, 1 instructions)
 * undefined _guard_dispatch_icall(void)
 * ========================================================================== */

/* WARNING: This is an inlined function */

void _guard_dispatch_icall(void)

{
  code *UNRECOVERED_JUMPTABLE;
  
                    /* WARNING: Could not recover jumptable at 0x0001400156b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}



/* ==========================================================================
 * __chkstk @ 0x1400156d0  (77 bytes, 19 instructions)
 * undefined __chkstk(void)
 * ========================================================================== */

/* WARNING: This is an inlined function */

void __chkstk(void)

{
  undefined1 *in_RAX;
  undefined1 *puVar1;
  void *pvVar2;
  undefined1 local_res8 [32];
  
  puVar1 = local_res8 + -(longlong)in_RAX;
  if (local_res8 < in_RAX) {
    puVar1 = (undefined1 *)0x0;
  }
  if (puVar1 < StackLimit) {
    pvVar2 = StackLimit;
    do {
      pvVar2 = (void *)((longlong)pvVar2 - 0x1000);
    } while ((void *)((ulonglong)puVar1 & 0xfffffffffffff000) < pvVar2);
  }
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015723  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DoProcessing'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0xf0));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015735  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderIdByName'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x130));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015747  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderName'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x58));
  return;
}



/* ==========================================================================
 * dtor$5 @ 0x140015759  (12 bytes, 2 instructions)
 * undefined dtor$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderName'::__l1::dtor_5(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x50));
  return;
}



/* ==========================================================================
 * dtor$8 @ 0x14001576b  (12 bytes, 2 instructions)
 * undefined dtor$8(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderName'::__l1::dtor_8(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x70));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x14001577d  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderIdByName'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x48));
  return;
}



/* ==========================================================================
 * dtor$5 @ 0x14001578f  (12 bytes, 2 instructions)
 * undefined dtor$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetProviderIdByName'::__l1::dtor_5(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x1400157a1  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::Initialize'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x100));
  return;
}



/* ==========================================================================
 * dtor$17 @ 0x1400157b3  (12 bytes, 2 instructions)
 * undefined dtor$17(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ParseCmdLine'::__l1::dtor_17(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 600));
  return;
}



/* ==========================================================================
 * catch$21 @ 0x1400157c5  (86 bytes, 19 instructions)
 * undefined * catch$21(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_21(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(long *)(param_2 + 0xd0),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002b93;
}



/* ==========================================================================
 * catch$22 @ 0x14001581c  (87 bytes, 19 instructions)
 * undefined * catch$22(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_22(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x188),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002bf6;
}



/* ==========================================================================
 * catch$23 @ 0x140015874  (75 bytes, 17 instructions)
 * undefined * catch$23(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_23(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002bf8;
}



/* ==========================================================================
 * catch$24 @ 0x1400158c0  (87 bytes, 19 instructions)
 * undefined * catch$24(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_24(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(exception **)(param_2 + 400),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return &DAT_140002b93;
}



/* ==========================================================================
 * catch$25 @ 0x140015918  (86 bytes, 19 instructions)
 * undefined * catch$25(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_25(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(long *)(param_2 + 0xd4),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x394,*(ulong *)(param_2 + 0x84));
  return &DAT_1400031df;
}



/* ==========================================================================
 * catch$26 @ 0x14001596f  (87 bytes, 19 instructions)
 * undefined * catch$26(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_26(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x198),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x394,*(ulong *)(param_2 + 0x84));
  return &DAT_1400031e1;
}



/* ==========================================================================
 * catch$27 @ 0x1400159c7  (75 bytes, 17 instructions)
 * undefined * catch$27(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssAdminCLI::Main'::__l1::catch_27(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x394,*(ulong *)(param_2 + 0x84));
  return &DAT_1400031e3;
}



/* ==========================================================================
 * catch$28 @ 0x140015a13  (87 bytes, 19 instructions)
 * undefined8 catch$28(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined8 `CVssAdminCLI::Main'::__l1::catch_28(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(exception **)(param_2 + 0x1a0),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x394,*(ulong *)(param_2 + 0x84));
  return 0x1400031a2;
}



/* ==========================================================================
 * dtor$1 @ 0x140015a71  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::Main'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015a83  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::Main'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssAdminCLI::__1CVssAdminCLI__QEAA_XZ((CVssAdminCLI *)(param_2 + 0x3a0));
  return;
}



/* ==========================================================================
 * catch$4 @ 0x140015a95  (83 bytes, 19 instructions)
 * undefined * catch$4(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_4(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(long *)(param_2 + 0x40),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return (undefined *)0x140004688;
}



/* ==========================================================================
 * catch$5 @ 0x140015ae9  (84 bytes, 19 instructions)
 * undefined * catch$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_5(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x50),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return (undefined *)0x14000468a;
}



/* ==========================================================================
 * catch$6 @ 0x140015b3e  (75 bytes, 17 instructions)
 * undefined * catch$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_6(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return (undefined *)0x14000468c;
}



/* ==========================================================================
 * catch$7 @ 0x140015b8a  (84 bytes, 19 instructions)
 * undefined8 catch$7(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined8
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_7(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(exception **)(param_2 + 0x58),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return 0x140004655;
}



/* ==========================================================================
 * dtor$6 @ 0x140015be5  (12 bytes, 2 instructions)
 * undefined dtor$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::CreateSnapshot'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$9 @ 0x140015bf7  (12 bytes, 2 instructions)
 * undefined dtor$9(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdmSnapshotSets::Initialize'::__l1::dtor_9(undefined8 param_1,longlong param_2)

{
  CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
  ::
  __1__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAA_XZ
            ((CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
              *)(param_2 + 0x70));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015c09  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DeleteSnapshotsFromList'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x120));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015c1b  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::PrintUsage'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xe0));
  return;
}



/* ==========================================================================
 * dtor$4 @ 0x140015c2d  (12 bytes, 2 instructions)
 * undefined dtor$4(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::PrintUsage'::__l1::dtor_4(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x250));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015c3f  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::AddDiffArea'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x110));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015c51  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::CreateSnapshot'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x90));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015c63  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x1d0));
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x140015c75  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xd8));
  return;
}



/* ==========================================================================
 * dtor$4 @ 0x140015c87  (12 bytes, 2 instructions)
 * undefined dtor$4(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_4(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 200));
  return;
}



/* ==========================================================================
 * dtor$5 @ 0x140015c99  (12 bytes, 2 instructions)
 * undefined dtor$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_5(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xa0));
  return;
}



/* ==========================================================================
 * dtor$6 @ 0x140015cab  (12 bytes, 2 instructions)
 * undefined dtor$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x90));
  return;
}



/* ==========================================================================
 * dtor$7 @ 0x140015cbd  (12 bytes, 2 instructions)
 * undefined dtor$7(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_7(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xb8));
  return;
}



/* ==========================================================================
 * dtor$8 @ 0x140015ccf  (12 bytes, 2 instructions)
 * undefined dtor$8(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_8(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x80));
  return;
}



/* ==========================================================================
 * dtor$7 @ 0x140015ce1  (12 bytes, 2 instructions)
 * undefined dtor$7(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DeleteDiffAreas'::__l1::dtor_7(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015cf3  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListDiffAreas'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x140));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015d05  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListDiffAreas'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x70));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015d17  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x250));
  return;
}



/* ==========================================================================
 * dtor$6 @ 0x140015d29  (12 bytes, 2 instructions)
 * undefined dtor$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  CVssAdmSnapshotSets::__1CVssAdmSnapshotSets__QEAA_XZ((CVssAdmSnapshotSets *)(param_2 + 0xb8));
  return;
}



/* ==========================================================================
 * dtor$10 @ 0x140015d3b  (12 bytes, 2 instructions)
 * undefined dtor$10(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_10(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xa8));
  return;
}



/* ==========================================================================
 * dtor$12 @ 0x140015d4d  (12 bytes, 2 instructions)
 * undefined dtor$12(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_12(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xd0));
  return;
}



/* ==========================================================================
 * dtor$13 @ 0x140015d5f  (12 bytes, 2 instructions)
 * undefined dtor$13(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListSnapshots'::__l1::dtor_13(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x68));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015d71  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DumpSnapshotTypes'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0xd0));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015d83  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DeleteDiffAreas'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x80));
  return;
}



/* ==========================================================================
 * dtor$14 @ 0x140015d95  (12 bytes, 2 instructions)
 * undefined dtor$14(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListWriters'::__l1::dtor_14(undefined8 param_1,longlong param_2)

{
  ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ((CComBSTR *)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$17 @ 0x140015da7  (12 bytes, 2 instructions)
 * undefined dtor$17(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListWriters'::__l1::dtor_17(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x1a8));
  return;
}



/* ==========================================================================
 * dtor$18 @ 0x140015db9  (12 bytes, 2 instructions)
 * undefined dtor$18(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListWriters'::__l1::dtor_18(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x198));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015dcb  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ListProviders'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x150));
  return;
}



/* ==========================================================================
 * dtor$14 @ 0x140015ddd  (12 bytes, 2 instructions)
 * undefined dtor$14(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_14(undefined8 param_1,longlong param_2)

{
  CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
  ::
  __1__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAA_XZ
            ((CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
              *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$6 @ 0x140015def  (12 bytes, 2 instructions)
 * undefined dtor$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::QueryReverts'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
  ::
  __1__CVssAuto_PEAXV__CVssAutoGenericValue_Storage_PEAX_0_0P6AHPEAX_Z_1_FindVolumeClose__YAH0_ZP6AAEAPEAXAEAPEAX_Z_1_Identity___DTyper_PEAX__SAAEAPEAX1_Z____UEAA_XZ
            ((CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,_1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_>
              *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015e01  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetOptionValuePercent'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0xe0));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015e13  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::QueryRevert'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x20));
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x140015e25  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DeleteDiffAreas'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x50));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015e37  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::DeleteSnapshots'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssSimpleArray<_GUID>::__1__CVssSimpleArray_U_GUID____QEAA_XZ
            ((CVssSimpleArray<_GUID> *)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015e49  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x160));
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x140015e5b  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x80));
  return;
}



/* ==========================================================================
 * dtor$11 @ 0x140015e6d  (12 bytes, 2 instructions)
 * undefined dtor$11(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_11(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x88));
  return;
}



/* ==========================================================================
 * dtor$15 @ 0x140015e7f  (12 bytes, 2 instructions)
 * undefined dtor$15(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_15(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x70));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015e91  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetOptionValuePercent'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x20));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015ea3  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetVolumeDisplayName'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x218));
  return;
}



/* ==========================================================================
 * dtor$5 @ 0x140015eb5  (12 bytes, 2 instructions)
 * undefined dtor$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::GetVolumeDisplayName'::__l1::dtor_5(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x210));
  return;
}



/* ==========================================================================
 * dtor$6 @ 0x140015ec7  (12 bytes, 2 instructions)
 * undefined dtor$6(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::AppendMessageToStr'::__l1::dtor_6(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x48));
  return;
}



/* ==========================================================================
 * dtor$8 @ 0x140015ed9  (12 bytes, 2 instructions)
 * undefined dtor$8(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::AppendMessageToStr'::__l1::dtor_8(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015eeb  (12 bytes, 2 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAdminCLI::ScanNumber'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015efd  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssAutoCoString::Append'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x1a0));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015f0f  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssResource::LoadStringW'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
            ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
              *)(param_2 + 0xf8));
  return;
}



/* ==========================================================================
 * catch$5 @ 0x140015f21  (36 bytes, 8 instructions)
 * undefined catch$5(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::catch_5(undefined8 param_1,longlong param_2)

{
  *(undefined4 *)(param_2 + 0x48) = 0x8007000e;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException((void *)(param_2 + 0x48),(ThrowInfo *)&_TI1J);
}



/* ==========================================================================
 * dtor$0 @ 0x140015f4c  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * dtor$2 @ 0x140015f5e  (45 bytes, 11 instructions)
 * undefined dtor$2(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  _eh_vector_destructor_iterator_
            ((void *)(param_2 + 0x90),0x28,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ);
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x140015f92  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__QEAA_XZ
            ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
              *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$0 @ 0x140015fa4  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::Throw'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x148));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015fb6  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::Throw'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ((CVssOutputBuffer *)(param_2 + 0x50));
  return;
}



/* ==========================================================================
 * dtor$0 @ 0x140015fc8  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateError'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x1b8));
  return;
}



/* ==========================================================================
 * dtor$0 @ 0x140015fda  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateComError'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x2b8));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140015fec  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateComError'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ((CVssOutputBuffer *)(param_2 + 0x60));
  return;
}



/* ==========================================================================
 * dtor$4 @ 0x140015ffe  (12 bytes, 2 instructions)
 * undefined dtor$4(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateComError'::__l1::dtor_4(undefined8 param_1,longlong param_2)

{
  ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ((CComBSTR *)(param_2 + 0x58));
  return;
}



/* ==========================================================================
 * catch$2 @ 0x140016010  (26 bytes, 8 instructions)
 * undefined8 catch$2(void)
 * ========================================================================== */

undefined8 `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_2(void)

{
  return 0x140010c8c;
}



/* ==========================================================================
 * catch$3 @ 0x14001602b  (26 bytes, 8 instructions)
 * undefined * catch$3(void)
 * ========================================================================== */

undefined * `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_3(void)

{
  return &DAT_140010c92;
}



/* ==========================================================================
 * catch$4 @ 0x140016046  (26 bytes, 8 instructions)
 * undefined * catch$4(void)
 * ========================================================================== */

undefined * `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_4(void)

{
  return (undefined *)0x140010ca8;
}



/* ==========================================================================
 * dtor$0 @ 0x140016067  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::dtor_0
               (undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0xf8));
  return;
}



/* ==========================================================================
 * dtor$0 @ 0x140016079  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateGenericError'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x1e8));
  return;
}



/* ==========================================================================
 * catch$2 @ 0x14001608b  (26 bytes, 8 instructions)
 * undefined1 * catch$2(void)
 * ========================================================================== */

undefined1 * `CVssFunctionTracer::TranslateGenericErrorNoThrow'::__l1::catch_2(void)

{
  return (undefined1 *)0x140011124;
}



/* ==========================================================================
 * catch$3 @ 0x1400160a6  (26 bytes, 8 instructions)
 * undefined1 * catch$3(void)
 * ========================================================================== */

undefined1 * `CVssFunctionTracer::TranslateGenericErrorNoThrow'::__l1::catch_3(void)

{
  return (undefined1 *)0x14001112a;
}



/* ==========================================================================
 * catch$4 @ 0x1400160c1  (26 bytes, 8 instructions)
 * undefined1 * catch$4(void)
 * ========================================================================== */

undefined1 * `CVssFunctionTracer::TranslateGenericErrorNoThrow'::__l1::catch_4(void)

{
  return (undefined1 *)0x140011140;
}



/* ==========================================================================
 * dtor$0 @ 0x1400160e2  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateGenericErrorNoThrow'::__l1::dtor_0
               (undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x108));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x1400160f4  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::TranslateInternalProviderError'::__l1::dtor_1
               (undefined8 param_1,longlong param_2)

{
  CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ((CVssOutputBuffer *)(param_2 + 0x48));
  return;
}



/* ==========================================================================
 * dtor$0 @ 0x140016106  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::ComDisableSEH'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x278));
  return;
}



/* ==========================================================================
 * dtor$1 @ 0x140016118  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::ComDisableSEH'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x270));
  return;
}



/* ==========================================================================
 * catch$12 @ 0x14001612a  (89 bytes, 19 instructions)
 * undefined * catch$12(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_12(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),*(long *)(param_2 + 0x8c),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return &DAT_140011d26;
}



/* ==========================================================================
 * catch$13 @ 0x140016184  (90 bytes, 19 instructions)
 * undefined * catch$13(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_13(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),*(_com_error **)(param_2 + 0x1b8),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return (undefined *)0x140011d68;
}



/* ==========================================================================
 * catch$14 @ 0x1400161df  (78 bytes, 17 instructions)
 * undefined * catch$14(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_14(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return (undefined *)0x140011d6a;
}



/* ==========================================================================
 * catch$15 @ 0x14001622e  (90 bytes, 19 instructions)
 * undefined * catch$15(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `CVssFunctionTracer::LogError'::__l1::catch_15(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x140),*(exception **)(param_2 + 0x1c0),
             (ushort *)L"base\\stor\\vss\\modules\\trace\\fntracer.cpp",(ushort *)L"TRCTRCC",
             (ushort *)L"CVssFunctionTracer::LogError",0x92e,*(ulong *)(param_2 + 0x164));
  return &DAT_140011d26;
}



/* ==========================================================================
 * dtor$0 @ 0x14001628f  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::LogError'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x80));
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x1400162a1  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssFunctionTracer::LogError'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)(param_2 + 0x78));
  return;
}



/* ==========================================================================
 * catch$1 @ 0x1400162b3  (103 bytes, 26 instructions)
 * undefined * catch$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`std::
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
::_Copy'::__l1::catch_1(undefined8 param_1,longlong param_2)

{
  longlong lVar1;
  undefined1 auVar2 [16];
  void *pvVar3;
  ulonglong uVar4;
  
  lVar1 = *(longlong *)(param_2 + 0x98);
  *(longlong *)(param_2 + 0x98) = lVar1;
  uVar4 = lVar1 + 1;
  if ((uVar4 != 0) &&
     (auVar2._8_8_ = 0, auVar2._0_8_ = uVar4,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2,0) < 2)) {
    std::bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z((bad_alloc *)(param_2 + 0x40),(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException((void *)(param_2 + 0x40),(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  pvVar3 = operator_new(uVar4 * 2);
  *(void **)(param_2 + 0xa8) = pvVar3;
  return &DAT_140012731;
}



/* ==========================================================================
 * catch$0 @ 0x14001631b  (39 bytes, 11 instructions)
 * undefined catch$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `std::
     basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
     ::_Copy'::__l1::catch_0(undefined8 param_1,longlong param_2)

{
  std::
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
  ::__Tidy___basic_string_GU__char_traits_G_std__V__allocator_G_2_V_STL70___std__IEAAX_N_K_Z
            (*(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>,_STL70>
               **)(param_2 + 0x90),true,0);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException((void *)0x0,(ThrowInfo *)0x0);
}



/* ==========================================================================
 * dtor$0 @ 0x140016349  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `GetVolumeNameWithCheck'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 400));
  return;
}



/* ==========================================================================
 * catch$16 @ 0x14001635b  (89 bytes, 19 instructions)
 * undefined * catch$16(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_16
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(long *)(param_2 + 0x1a8),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return &DAT_140013a2d;
}



/* ==========================================================================
 * catch$17 @ 0x1400163b5  (90 bytes, 19 instructions)
 * undefined * catch$17(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_17
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(_com_error **)(param_2 + 0x238),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return (undefined *)0x140013b11;
}



/* ==========================================================================
 * catch$18 @ 0x140016410  (78 bytes, 17 instructions)
 * undefined * catch$18(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_18
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return (undefined *)0x140013b16;
}



/* ==========================================================================
 * catch$19 @ 0x14001645f  (90 bytes, 19 instructions)
 * undefined * catch$19(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_19
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(exception **)(param_2 + 0x240),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return &DAT_140013a2d;
}



/* ==========================================================================
 * dtor$1 @ 0x1400164c0  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::dtor_1
               (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0x1c0));
  return;
}



/* ==========================================================================
 * dtor$3 @ 0x1400164d2  (12 bytes, 2 instructions)
 * undefined dtor$3(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::dtor_3
               (undefined8 param_1,longlong param_2)

{
  CVssIOCTLChannel::__1CVssIOCTLChannel__QEAA_XZ((CVssIOCTLChannel *)(param_2 + 0x50));
  return;
}



/* ==========================================================================
 * catch$8 @ 0x1400164e4  (86 bytes, 19 instructions)
 * undefined * catch$8(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_8
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(long *)(param_2 + 0x50),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return &DAT_140013e4d;
}



/* ==========================================================================
 * catch$9 @ 0x14001653b  (90 bytes, 19 instructions)
 * undefined * catch$9(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_9
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(_com_error **)(param_2 + 0x178),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return (undefined *)0x140013f14;
}



/* ==========================================================================
 * catch$10 @ 0x140016596  (78 bytes, 17 instructions)
 * undefined * catch$10(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_10
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return (undefined *)0x140013f19;
}



/* ==========================================================================
 * catch$11 @ 0x1400165e5  (90 bytes, 19 instructions)
 * undefined * catch$11(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_11
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdGenericException_CVssFunctionTracer__QEAAXAEBVexception__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(exception **)(param_2 + 0x180),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return &DAT_140013e4d;
}



/* ==========================================================================
 * __wmainCRTStartup$filt$0 @ 0x140016646  (29 bytes, 11 instructions)
 * undefined __wmainCRTStartup$filt$0(_EXCEPTION_POINTERS * param_1)
 * ========================================================================== */

void __wmainCRTStartup_filt_0(_EXCEPTION_POINTERS *param_1)

{
  _XcptFilter(param_1->ExceptionRecord->ExceptionCode,param_1);
  return;
}



/* ==========================================================================
 * catch$0 @ 0x14001666a  (31 bytes, 9 instructions)
 * undefined * catch$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined * `operator_new'::__l1::catch_0(undefined8 param_1,longlong param_2)

{
  *(undefined8 *)(param_2 + 0x50) = 0;
  return &DAT_14001440d;
}



/* ==========================================================================
 * _IsNonwritableInCurrentImage$filt$0 @ 0x140016690  (31 bytes, 11 instructions)
 * bool _IsNonwritableInCurrentImage$filt$0(undefined8 * param_1)
 * ========================================================================== */

bool _IsNonwritableInCurrentImage_filt_0(undefined8 *param_1)

{
  return *(int *)*param_1 == -0x3ffffffb;
}



/* ==========================================================================
 * dtor$1 @ 0x1400166b6  (12 bytes, 2 instructions)
 * undefined dtor$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `std::length_error::length_error'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  exception::__1exception__UEAA_XZ(*(exception **)(param_2 + 0x40));
  return;
}



/* ==========================================================================
 * catch$1 @ 0x1400166c8  (100 bytes, 25 instructions)
 * undefined * catch$1(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined *
`std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::_Copy'::__l1::catch_1
          (undefined8 param_1,longlong param_2)

{
  longlong lVar1;
  undefined1 auVar2 [16];
  void *pvVar3;
  ulonglong uVar4;
  
  lVar1 = *(longlong *)(param_2 + 0x98);
  *(longlong *)(param_2 + 0x98) = lVar1;
  uVar4 = lVar1 + 1;
  if ((uVar4 != 0) &&
     (auVar2._8_8_ = 0, auVar2._0_8_ = uVar4,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar2,0) == 0)) {
    std::bad_alloc::__0bad_alloc_std__QEAA_PEBD_Z((bad_alloc *)(param_2 + 0x40),(char *)0x0);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException((void *)(param_2 + 0x40),(ThrowInfo *)&_TI2_AVbad_alloc_std__);
  }
  pvVar3 = operator_new(uVar4);
  *(void **)(param_2 + 0xa8) = pvVar3;
  return &DAT_140014ec1;
}



/* ==========================================================================
 * catch$0 @ 0x14001672d  (39 bytes, 11 instructions)
 * undefined catch$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::_Copy'::__l1::
     catch_0(undefined8 param_1,longlong param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __Tidy___basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__IEAAX_N_K_Z
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> **)
              (param_2 + 0x90),true,0);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException((void *)0x0,(ThrowInfo *)0x0);
}



/* ==========================================================================
 * dtor$0 @ 0x14001675b  (12 bytes, 2 instructions)
 * undefined dtor$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void `std::_String_base::_Xlen'::__l1::dtor_0(undefined8 param_1,longlong param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70>::
  __1__basic_string_DU__char_traits_D_std__V__allocator_D_2_V_STL70___std__QEAA_XZ
            ((basic_string<char,std::char_traits<char>,std::allocator<char>,_STL70> *)
             (param_2 + 0x28));
  return;
}



/* ==========================================================================
 * fin$0 @ 0x14001676d  (43 bytes, 14 instructions)
 * undefined fin$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void ``eh_vector_destructor_iterator''::__l1::fin_0(undefined8 param_1,longlong param_2)

{
  if (*(int *)(param_2 + 0x20) == 0) {
    __ArrayUnwind(*(void **)(param_2 + 0x60),*(__uint64 *)(param_2 + 0x68),*(int *)(param_2 + 0x70),
                  *(_func_void_void_ptr **)(param_2 + 0x78));
  }
  return;
}



/* ==========================================================================
 * filt$0 @ 0x14001679f  (64 bytes, 18 instructions)
 * undefined4 filt$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

undefined4 `__ArrayUnwind'::__l1::filt_0(undefined8 param_1,longlong param_2)

{
  *(undefined8 *)(param_2 + 0x38) = param_1;
  *(undefined8 *)(param_2 + 0x28) = param_1;
  *(undefined8 *)(param_2 + 0x30) = **(undefined8 **)(param_2 + 0x28);
  if (**(int **)(param_2 + 0x30) != -0x1f928c9d) {
    *(undefined4 *)(param_2 + 0x20) = 0;
    return *(undefined4 *)(param_2 + 0x20);
  }
                    /* WARNING: Subroutine does not return */
  terminate();
}



/* ==========================================================================
 * fin$0 @ 0x1400167e7  (43 bytes, 14 instructions)
 * undefined fin$0(undefined8 param_1, longlong param_2)
 * ========================================================================== */

void ``eh_vector_constructor_iterator''::__l1::fin_0(undefined8 param_1,longlong param_2)

{
  if (*(int *)(param_2 + 0x24) == 0) {
    __ArrayUnwind(*(void **)(param_2 + 0x50),*(__uint64 *)(param_2 + 0x58),*(int *)(param_2 + 0x20),
                  *(_func_void_void_ptr **)(param_2 + 0x70));
  }
  return;
}



