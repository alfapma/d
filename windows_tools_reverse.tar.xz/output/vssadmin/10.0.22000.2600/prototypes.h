/* Function prototypes for 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438) */
#pragma once
#include "types.h"

/* 0x140001010  12 bytes  [__fastcall] */
undefined _Generic_object''(void);

/* 0x140001030  12 bytes  [__fastcall] */
undefined _Iostream_object''(void);

/* 0x140001050  12 bytes  [__fastcall] */
undefined _System_object''(void);

/* 0x140001070  35 bytes  [__fastcall] */
undefined `dynamic_initializer_for_'dCurrentSKU''(void);

/* 0x1400010a0  33 bytes  [__thiscall] */
undefined ??0bad_alloc@std@@QEAA@AEBV01@@Z(bad_alloc * this, bad_alloc * param_1);

/* 0x1400010c8  55 bytes  [__thiscall] */
undefined ??0bad_alloc@std@@QEAA@XZ(bad_alloc * this);

/* 0x140001108  15 bytes  [__thiscall] */
void ??1bad_alloc@std@@UEAA@XZ(bad_alloc * this);

/* 0x140001120  69 bytes  [__cdecl] */
void * operator_new(__uint64 param_1);

/* 0x14000116c  5 bytes  [__cdecl] */
void operator_delete[](void * param_1);

/* 0x140001180  65 bytes  [__thiscall] */
void * ??_Gbad_alloc@std@@UEAAPEAXI@Z(bad_alloc * this, uint param_1);

/* 0x1400011d0  34 bytes  [__thiscall] */
void ?_Doraise@bad_alloc@std@@MEBAXXZ(bad_alloc * this);

/* 0x1400011fc  33 bytes  [__thiscall] */
undefined ??0out_of_range@std@@QEAA@AEBV01@@Z(out_of_range * this, out_of_range * param_1);

/* 0x140001224  47 bytes  [__thiscall] */
undefined ??0out_of_range@std@@QEAA@PEBD@Z(out_of_range * this, char * param_1);

/* 0x14000125c  5 bytes  [__thiscall] */
void ??1length_error@std@@UEAA@XZ(length_error * this);

/* 0x140001270  55 bytes  [__thiscall] */
void * ??_Eout_of_range@std@@UEAAPEAXI@Z(out_of_range * this, uint param_1);

/* 0x1400012a8  31 bytes  [__cdecl] */
void ?_Xbad_alloc@std@@YAXXZ(void);

/* 0x1400012d0  34 bytes  [__cdecl] */
void ?_Xlength_error@std@@YAXPEBD@Z(char * param_1);

/* 0x1400012fc  34 bytes  [__cdecl] */
void ?_Xout_of_range@std@@YAXPEBD@Z(char * param_1);

/* 0x140001328  40 bytes  [__cdecl] */
char * ?_Syserror_map@std@@YAPEBDH@Z(int param_1);

/* 0x140001358  40 bytes  [__cdecl] */
char * ?_Winerror_map@std@@YAPEBDH@Z(int param_1);

/* 0x140001390  211 bytes  [__fastcall] */
undefined8 pre_c_init(void);

/* 0x140001470  73 bytes  [__fastcall] */
undefined pre_cpp_init(void);

/* 0x1400014c0  466 bytes  [__fastcall] */
int __wmainCRTStartup(void);

/* 0x1400016a0  18 bytes  [__fastcall] */
undefined entry(void);

/* 0x1400016b8  6 bytes  [unknown] */
undefined __CxxFrameHandler4();

/* 0x1400016d0  30 bytes  [__cdecl] */
void __security_check_cookie(uintptr_t _StackCookie);

/* 0x1400016f4  151 bytes  [__cdecl] */
_onexit_t _onexit(_onexit_t _Func);

/* 0x140001794  23 bytes  [__cdecl] */
int atexit(_func_5014 * param_1);

/* 0x1400017c0  6 bytes  [unknown] */
undefined _purecall();

/* 0x1400017cc  10 bytes  [__fastcall] */
undefined __std_terminate(void);

/* 0x1400017e0  26 bytes  [__cdecl] */
void * operator_new(__uint64 param_1, nothrow_t * param_2);

/* 0x140001810  56 bytes  [__thiscall] */
void * ??_Etype_info@@UEAAPEAXI@Z(type_info * this, uint param_1);

/* 0x140001848  5 bytes  [__cdecl] */
void * operator_new[](__uint64 param_1, nothrow_t * param_2);

/* 0x140001853  6 bytes  [__cdecl] */
void free(void * _Memory);

/* 0x140001860  52 bytes  [__fastcall] */
undefined __raise_securityfailure(_EXCEPTION_POINTERS * param_1);

/* 0x1400018a0  369 bytes  [__cdecl] */
void __report_gsfailure(uintptr_t _StackCookie);

/* 0x140001a18  247 bytes  [__fastcall] */
undefined __report_rangecheckfailure(void);

/* 0x140001b15  6 bytes  [__cdecl] */
void * malloc(size_t _Size);

/* 0x140001b21  6 bytes  [__cdecl] */
int _callnewh(size_t _Size);

/* 0x140001b2d  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@AEBQEBDH@Z(exception * this, char * * param_1, int param_2);

/* 0x140001b39  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@AEBV0@@Z(exception * this, exception * param_1);

/* 0x140001b45  6 bytes  [__thiscall] */
void ??1exception@@UEAA@XZ(exception * this);

/* 0x140001b60  6 bytes  [__thiscall] */
char * ?what@exception@@UEBAPEBDXZ(exception * this);

/* 0x140001b6c  6 bytes  [__stdcall] */
void _CxxThrowException(void * pExceptionObject, ThrowInfo * pThrowInfo);

/* 0x140001b78  6 bytes  [unknown] */
undefined __CxxFrameHandler3();

/* 0x140001b84  6 bytes  [__thiscall] */
undefined ??0exception@@QEAA@AEBQEBD@Z(exception * this, char * * param_1);

/* 0x140001b90  6 bytes  [__cdecl] */
void * memcpy(void * _Dst, void * _Src, size_t _Size);

/* 0x140001b9c  6 bytes  [__cdecl] */
void * memmove(void * _Dst, void * _Src, size_t _Size);

/* 0x140001bb0  56 bytes  [__cdecl] */
long __CxxUnhandledExceptionFilter(_EXCEPTION_POINTERS * param_1);

/* 0x140001c00  24 bytes  [__fastcall] */
undefined8 __CxxSetUnhandledExceptionFilter(void);

/* 0x140001c1e  6 bytes  [__cdecl] */
int _XcptFilter(ulong _ExceptionNum, _EXCEPTION_POINTERS * _ExceptionPtr);

/* 0x140001c2c  78 bytes  [__fastcall] */
int * RtlpImageNtHeader(short * param_1);

/* 0x140001c88  69 bytes  [__fastcall] */
undefined4 _get_image_app_type(undefined4 param_1);

/* 0x140001cd3  6 bytes  [__cdecl] */
void _amsg_exit(int param_1);

/* 0x140001ce0  3 bytes  [__cdecl] */
int _wsetargv(void);

/* 0x140001cf0  68 bytes  [__cdecl] */
PIMAGE_SECTION_HEADER _FindPESection(PBYTE pImageBase, DWORD_PTR rva);

/* 0x140001d40  75 bytes  [__cdecl] */
BOOL _IsNonwritableInCurrentImage(PBYTE pTarget);

/* 0x140001da0  45 bytes  [__cdecl] */
BOOL _ValidateImageBase(PBYTE pImageBase);

/* 0x140001dd4  220 bytes  [__cdecl] */
void __security_init_cookie(void);

/* 0x140001eb0  3 bytes  [__cdecl] */
int _matherr(_exception * _Except);

/* 0x140001eb9  6 bytes  [unknown] */
undefined _initterm();

/* 0x140001ec5  6 bytes  [unknown] */
EXCEPTION_DISPOSITION __C_specific_handler(_EXCEPTION_RECORD * ExceptionRecord, void * EstablisherFrame, _CONTEXT * ContextRecord, _DISPATCHER_CONTEXT * DispatcherContext);

/* 0x140001ed1  6 bytes  [__cdecl] */
void _lock(int _File);

/* 0x140001edd  6 bytes  [__cdecl] */
void _unlock(int _File);

/* 0x140001ee9  6 bytes  [unknown] */
undefined __dllonexit();

/* 0x140001f00  3 bytes  [__fastcall] */
undefined _guard_check_icall(void);

/* 0x140001f18  5 bytes  [__cdecl] */
void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4);

/* 0x140001f24  113 bytes  [__cdecl] */
void `eh_vector_destructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4);

/* 0x140001f9c  92 bytes  [__cdecl] */
void __ArrayUnwind(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4);

/* 0x140002000  5 bytes  [__cdecl] */
void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, __uint64 param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5);

/* 0x14000200c  119 bytes  [__cdecl] */
void `eh_vector_constructor_iterator'(void * param_1, __uint64 param_2, int param_3, _func_void_void_ptr * param_4, _func_void_void_ptr * param_5);

/* 0x140002090  46 bytes  [__thiscall] */
void * ??_Eerror_category@std@@UEAAPEAXI@Z(error_category * this, uint param_1);

/* 0x1400020c0  217 bytes  [__thiscall] */
void ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAX_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, __uint64 param_1, __uint64 param_2);

/* 0x1400021b8  88 bytes  [__thiscall] */
void ?_Tidy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAX_N_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, bool param_1, __uint64 param_2);

/* 0x140002218  16 bytes  [__thiscall] */
void ?_Xlen@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEBAXXZ(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this);

/* 0x140002230  16 bytes  [__thiscall] */
void ?_Xran@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEBAXXZ(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this);

/* 0x140002248  259 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> * param_1, __uint64 param_2, __uint64 param_3);

/* 0x140002354  243 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> * ?assign@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAAEAV12@PEBD_K@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, char * param_1, __uint64 param_2);

/* 0x140002460  63 bytes  [__thiscall] */
error_condition ?default_error_condition@_System_error_category@std@@UEBA?AVerror_condition@2@H@Z(_System_error_category * this, int param_1);

/* 0x1400024b0  11 bytes  [__thiscall] */
error_condition ?default_error_condition@error_category@std@@UEBA?AVerror_condition@2@H@Z(error_category * this, int param_1);

/* 0x1400024d0  17 bytes  [__thiscall] */
bool ?equivalent@error_category@std@@UEBA_NAEBVerror_code@2@H@Z(error_category * this, error_code * param_1, int param_2);

/* 0x1400024f0  68 bytes  [__thiscall] */
bool ?equivalent@error_category@std@@UEBA_NHAEBVerror_condition@2@@Z(error_category * this, int param_1, error_condition * param_2);

/* 0x14000253c  152 bytes  [__thiscall] */
basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> * ?erase@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAAEAV12@_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, __uint64 param_1, __uint64 param_2);

/* 0x1400025e0  87 bytes  [__thiscall] */
basic_string<char,std::char_traits<char>,std::allocator<char>_> ?message@_Generic_error_category@std@@UEBA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@H@Z(_Generic_error_category * this, int param_1);

/* 0x140002640  126 bytes  [__thiscall] */
basic_string<char,std::char_traits<char>,std::allocator<char>_> ?message@_Iostream_error_category@std@@UEBA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@H@Z(_Iostream_error_category * this, int param_1);

/* 0x1400026d0  96 bytes  [__thiscall] */
basic_string<char,std::char_traits<char>,std::allocator<char>_> ?message@_System_error_category@std@@UEBA?AV?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@2@H@Z(_System_error_category * this, int param_1);

/* 0x140002730  8 bytes  [__thiscall] */
char * ?name@_Generic_error_category@std@@UEBAPEBDXZ(_Generic_error_category * this);

/* 0x140002750  16 bytes  [__thiscall] */
char * ?name@_Iostream_error_category@std@@UEBAPEBDXZ(_Iostream_error_category * this);

/* 0x140002770  16 bytes  [__thiscall] */
char * ?name@_System_error_category@std@@UEBAPEBDXZ(_System_error_category * this);

/* 0x140002780  41 bytes  [__thiscall] */
void ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ(CComPtr<IVssEnumObject> * this);

/* 0x1400027b0  61 bytes  [__thiscall] */
void ??1?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@UEAA@XZ(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this);

/* 0x1400027f4  501 bytes  [__thiscall] */
void ??1CVssAdminCLI@@QEAA@XZ(CVssAdminCLI * this);

/* 0x140002a00  89 bytes  [__thiscall] */
void * ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_> * this, uint param_1);

/* 0x140002a70  48 bytes  [__thiscall] */
void * ??_E?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@MEAAPEAXI@Z(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this, uint param_1);

/* 0x140002aa0  38 bytes  [__thiscall] */
void * ??_ECInternalVerifier@@UEAAPEAXI@Z(CInternalVerifier * this, uint param_1);

/* 0x140002ad0  356 bytes  [__cdecl] */
int AssertPrivilege(ushort * param_1);

/* 0x140002c3c  41 bytes  [__thiscall] */
void ?Close@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEAAXXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this);

/* 0x140002c6c  457 bytes  [__thiscall] */
void ?DoProcessing@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140002e40  5 bytes  [__thiscall] */
ushort * ?Get@?$CVssAutoGenericValue_Storage@PEAG$0A@P6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6AAEAPEAGAEAPEAG@Z$1?Identity@?$DTyper@PEAG@@SAAEAPEAG1@Z@@QEBAPEAGXZ(CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)> * this);

/* 0x140002e4c  4 bytes  [__thiscall] */
long ?GetHr@CVssFunctionTracer@@QEAAJXZ(CVssFunctionTracer * this);

/* 0x140002e58  164 bytes  [__thiscall] */
ushort * ?GetOptionValueStr@CVssAdminCLI@@AEAAPEAGW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1);

/* 0x140002f04  356 bytes  [__thiscall] */
void ?GetProviderId@CVssAdminCLI@@AEAAXPEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1);

/* 0x140003070  1014 bytes  [__thiscall] */
int ?GetProviderIdByName@CVssAdminCLI@@AEAAHPEBGPEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2);

/* 0x140003470  1355 bytes  [__thiscall] */
ushort * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1);

/* 0x1400039c8  793 bytes  [__thiscall] */
void ?Initialize@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140003cec  942 bytes  [__cdecl] */
long ?Main@CVssAdminCLI@@SAJHQEAPEAG@Z(int param_1, ushort * * param_2);

/* 0x1400045b0  1845 bytes  [__thiscall] */
int ?ParseCmdLine@CVssAdminCLI@@AEAAHXZ(CVssAdminCLI * this);

/* 0x140004cf8  4 bytes  [__thiscall] */
void ?SetHr@CVssFunctionTracer@@QEAAXJ@Z(CVssFunctionTracer * this, long param_1);

/* 0x140004d04  188 bytes  [__cdecl] */
long StringCchCatW(ushort * param_1, __uint64 param_2, ushort * param_3);

/* 0x140004dc8  114 bytes  [__cdecl] */
long StringCchPrintfW(ushort * param_1, __uint64 param_2, ushort * param_3, ...);

/* 0x140004e44  34 bytes  [__cdecl] */
void VssFreeString(ushort * * param_1);

/* 0x140004e70  34 bytes  [__cdecl] */
void VssFreeString(ushort * * param_1);

/* 0x140004e9c  125 bytes  [__cdecl] */
ushort * VssReallocString(CVssFunctionTracer * param_1, ushort * param_2, long param_3);

/* 0x140004f24  425 bytes  [__cdecl] */
void VssSafeDuplicateStr(CVssFunctionTracer * param_1, ushort * * param_2, ushort * param_3);

/* 0x1400050d8  64 bytes  [__cdecl] */
int wmain(int _Argc, wchar_t * * _Argv, wchar_t * * _Env);

/* 0x140005130  120 bytes  [__thiscall] */
void ?AddDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x1400051c0  105 bytes  [__thiscall] */
void ?AddDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140005240  3 bytes  [__thiscall] */
void ?CreateSnapshot@CExternalVerifier@@UEAAXJPEBGU_GUID@@_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, ushort * param_2, _GUID * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140005250  11 bytes  [__thiscall] */
void ?DeleteDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5);

/* 0x140005260  444 bytes  [__thiscall] */
void ?DeleteSnapshots@CExternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7);

/* 0x140005430  494 bytes  [__thiscall] */
void ?DeleteSnapshots@CInternalVerifier@@UEAAXJPEBG_N1U_GUID@@1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, ushort * param_2, bool param_3, bool param_4, _GUID * param_5, bool param_6, CVssFunctionTracer * param_7);

/* 0x140005630  3 bytes  [__thiscall] */
void ?ExposeSnapshot@CExternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5);

/* 0x140005640  189 bytes  [__thiscall] */
void ?ExposeSnapshot@CInternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5);

/* 0x140005710  101 bytes  [__thiscall] */
void ?ListDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4);

/* 0x140005780  101 bytes  [__thiscall] */
void ?ListDiffAreas@CInternalVerifier@@UEAAXU_GUID@@PEBG1AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, CVssFunctionTracer * param_4);

/* 0x1400057f0  3 bytes  [__thiscall] */
void ?ListProviders@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, CVssFunctionTracer * param_1);

/* 0x140005800  255 bytes  [__thiscall] */
void ?ListSnapshots@CExternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6);

/* 0x140005910  255 bytes  [__thiscall] */
void ?ListSnapshots@CInternalVerifier@@UEAAXJU_GUID@@PEBG00AEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, long param_1, _GUID * param_2, ushort * param_3, _GUID * param_4, _GUID * param_5, CVssFunctionTracer * param_6);

/* 0x140005a20  3 bytes  [__thiscall] */
void ?ListVolumes@CInternalVerifier@@UEAAXU_GUID@@JAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, long param_2, CVssFunctionTracer * param_3);

/* 0x140005a30  11 bytes  [__thiscall] */
void ?ListWriters@CInternalVerifier@@UEAAXAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, CVssFunctionTracer * param_1);

/* 0x140005a40  180 bytes  [__thiscall] */
void ?QueryReverts@CExternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3);

/* 0x140005b00  180 bytes  [__thiscall] */
void ?QueryReverts@CInternalVerifier@@UEAAXPEBG_NAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, ushort * param_1, bool param_2, CVssFunctionTracer * param_3);

/* 0x140005bc0  120 bytes  [__thiscall] */
void ?ResizeDiffArea@CExternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140005c50  105 bytes  [__thiscall] */
void ?ResizeDiffArea@CInternalVerifier@@UEAAXU_GUID@@PEBG1_KAEAVCVssFunctionTracer@@@Z(CInternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, __uint64 param_4, CVssFunctionTracer * param_5);

/* 0x140005cd0  3 bytes  [__thiscall] */
void ?RevertSnapshot@CExternalVerifier@@UEAAXU_GUID@@_N1AEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, bool param_2, bool param_3, CVssFunctionTracer * param_4);

/* 0x140005cdc  61 bytes  [__thiscall] */
void ??1?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAA@XZ(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this);

/* 0x140005d20  62 bytes  [__thiscall] */
void ??1?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAA@XZ(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this);

/* 0x140005d68  47 bytes  [__thiscall] */
void ??1?$CVssSimpleArray@U_GUID@@@@QEAA@XZ(CVssSimpleArray<_GUID> * this);

/* 0x140005da0  10 bytes  [__thiscall] */
void ??1CComBSTR@ATL@@QEAA@XZ(CComBSTR * this);

/* 0x140005db8  150 bytes  [__thiscall] */
void ??1CVssAdmSnapshotSetEntry@@QEAA@XZ(CVssAdmSnapshotSetEntry * this);

/* 0x140005e58  270 bytes  [__thiscall] */
void ??1CVssAdmSnapshotSets@@QEAA@XZ(CVssAdmSnapshotSets * this);

/* 0x140005f70  89 bytes  [__thiscall] */
void * ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this, uint param_1);

/* 0x140005fe0  90 bytes  [__thiscall] */
void * ??_E?$CVssAuto@PEAXV?$CVssAutoGenericValue_Storage@PEAX$0?0P6AHPEAX@Z$1?FindVolumeClose@@YAH0@ZP6AAEAPEAXAEAPEAX@Z$1?Identity@?$DTyper@PEAX@@SAAEAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<void*___ptr64,CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>_> * this, uint param_1);

/* 0x140006044  31 bytes  [__thiscall] */
void * ??_GCVssAdmSnapshotSetEntry@@QEAAPEAXI@Z(CVssAdmSnapshotSetEntry * this, uint param_1);

/* 0x14000606c  177 bytes  [__thiscall] */
void ?Add@?$CVssSimpleArray@U_GUID@@@@QEAAXAEAU_GUID@@@Z(CVssSimpleArray<_GUID> * this, _GUID * param_1);

/* 0x140006128  702 bytes  [__thiscall] */
void ?AddDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x1400063f0  573 bytes  [__thiscall] */
long ?AddSnapshot@CVssAdmSnapshotSetEntry@@QEAAJPEAU_VSS_SNAPSHOT_PROP@@@Z(CVssAdmSnapshotSetEntry * this, _VSS_SNAPSHOT_PROP * param_1);

/* 0x140006638  569 bytes  [__thiscall] */
ushort * ?BuildSnapshotAttributeDisplayString@CVssAdminCLI@@AEAAPEAGK@Z(CVssAdminCLI * this, ulong param_1);

/* 0x140006878  261 bytes  [__thiscall] */
void ?CopyFrom@?$CVssAutoString@V?$CVssAutoCOMPtr@PEAG@@@@QEAAXPEBG@Z(CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> * this, ushort * param_1);

/* 0x140006988  2243 bytes  [__thiscall] */
void ?CreateSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000725c  1334 bytes  [__thiscall] */
void ?DeleteDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000779c  454 bytes  [__thiscall] */
void ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000796c  844 bytes  [__thiscall] */
void ?DeleteSnapshotsFromList@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEAJ@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, long * param_2);

/* 0x140007cc4  387 bytes  [__thiscall] */
long ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x140007e50  485 bytes  [__thiscall] */
ushort * ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z(CVssAdminCLI * this, long param_1);

/* 0x140008040  1094 bytes  [__thiscall] */
void ?DisplayDiffAreasPrivate@CVssAdminCLI@@AEAAXPEAUIVssEnumMgmtObject@@@Z(CVssAdminCLI * this, IVssEnumMgmtObject * param_1);

/* 0x140008490  239 bytes  [__thiscall] */
void ?DumpSnapshotTypes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140008588  1252 bytes  [__thiscall] */
void ?ExposeSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x140008a78  2229 bytes  [__thiscall] */
void ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, bool * param_2);

/* 0x140009340  402 bytes  [__thiscall] */
void ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z(CVssAdminCLI * this, _GUID * param_1, IUnknown * * param_2);

/* 0x1400094dc  176 bytes  [__thiscall] */
int ?GetOptionValueBool@CVssAdminCLI@@AEAAHW4EVssAdmOption@@@Z(CVssAdminCLI * this, EVssAdmOption param_1);

/* 0x140009594  214 bytes  [__thiscall] */
int ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2, int param_3);

/* 0x140009674  323 bytes  [__thiscall] */
int ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2);

/* 0x1400097c0  1888 bytes  [__thiscall] */
void ?Initialize@CVssAdmSnapshotSets@@QEAAXJU_GUID@@00PEBG@Z(CVssAdmSnapshotSets * this, long param_1, _GUID * param_2, _GUID * param_3, _GUID * param_4, ushort * param_5);

/* 0x140009f30  1946 bytes  [__thiscall] */
void ?ListDiffAreas@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000a6dc  1135 bytes  [__thiscall] */
void ?ListProviders@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000ab58  1968 bytes  [__thiscall] */
void ?ListSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000b314  1085 bytes  [__thiscall] */
void ?ListVolumes@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000b75c  2489 bytes  [__thiscall] */
void ?ListWriters@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000c128  824 bytes  [__thiscall] */
void ?PrintUsage@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000c46c  387 bytes  [__thiscall] */
void ?QueryRevert@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2);

/* 0x14000c5f8  1013 bytes  [__thiscall] */
void ?QueryReverts@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000c9f8  707 bytes  [__thiscall] */
void ?ResizeDiffArea@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000ccc4  1593 bytes  [__thiscall] */
void ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this);

/* 0x14000d30c  7 bytes  [__cdecl] */
void VssFreeSnapshotProperties(_VSS_SNAPSHOT_PROP * param_1);

/* 0x14000d320  817 bytes  [__thiscall] */
void ?WaitForRevertCompletion@CVssAdminCLI@@AEAAXPEAGPEAUIVssCoordinator@@@Z(CVssAdminCLI * this, ushort * param_1, IVssCoordinator * param_2);

/* 0x14000d65c  22 bytes  [__cdecl] */
void ?_AtlRaiseException@ATL@@YAXKK@Z(ulong param_1, ulong param_2);

/* 0x14000d680  904 bytes  [__thiscall] */
void ?AppendMessageToStr@CVssAdminCLI@@AEAAXPEAG_KJKPEBG@Z(CVssAdminCLI * this, ushort * param_1, __uint64 param_2, long param_3, ulong param_4, ushort * param_5);

/* 0x14000da14  785 bytes  [__cdecl] */
ushort * DateTimeToString(__int64 * param_1);

/* 0x14000dd30  600 bytes  [__thiscall] */
ushort * ?FormatNumber@CVssAdminCLI@@AEAAPEAG_JH@Z(CVssAdminCLI * this, __int64 param_1, int param_2);

/* 0x14000df94  353 bytes  [__thiscall] */
ushort * ?GetMsg@CVssAdminCLI@@AEAAPEAGHJZZ(CVssAdminCLI * this, int param_1, long param_2, ...);

/* 0x14000e0fc  209 bytes  [__thiscall] */
ushort * ?GetNextCmdlineToken@CVssAdminCLI@@AEAAPEBG_N@Z(CVssAdminCLI * this, bool param_1);

/* 0x14000e1d4  361 bytes  [__thiscall] */
__uint64 ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000e348  1317 bytes  [__thiscall] */
ushort * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000e87c  395 bytes  [__cdecl] */
ushort * GuidToString(_GUID * param_1);

/* 0x14000ea10  85 bytes  [__cdecl] */
int IsCorrectContext(long param_1);

/* 0x14000ea6c  642 bytes  [__thiscall] */
ushort * ?LoadStringW@CVssAdminCLI@@AEAAPEBGI@Z(CVssAdminCLI * this, uint param_1);

/* 0x14000ecf8  657 bytes  [__cdecl] */
int MapGenericVssErrorToMsg(long param_1, ushort * * param_2);

/* 0x14000ef90  902 bytes  [__cdecl] */
int MapVssErrorToMsg(long param_1, long * param_2);

/* 0x14000f320  193 bytes  [__thiscall] */
bool ?Match@CVssAdminCLI@@AEAA_NPEBG0@Z(CVssAdminCLI * this, ushort * param_1, ushort * param_2);

/* 0x14000f3e8  734 bytes  [__cdecl] */
ushort MyGetChar(void);

/* 0x14000f6d4  592 bytes  [__thiscall] */
void ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...);

/* 0x14000f92c  361 bytes  [__thiscall] */
void ?OutputMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...);

/* 0x14000fa9c  805 bytes  [__thiscall] */
void ?OutputOnConsole@CVssAdminCLI@@AEAAXPEBG@Z(CVssAdminCLI * this, ushort * param_1);

/* 0x14000fdd0  745 bytes  [__thiscall] */
int ?PromptUserForConfirmation@CVssAdminCLI@@AEAAHJK@Z(CVssAdminCLI * this, long param_1, ulong param_2);

/* 0x1400100c4  189 bytes  [__thiscall] */
bool ?ScanGuid@CVssAdminCLI@@AEAA_NPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, ushort * param_1, _GUID * param_2);

/* 0x140010188  1318 bytes  [__thiscall] */
__int64 ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z(CVssAdminCLI * this, ushort * param_1, int param_2);

/* 0x1400106bc  193 bytes  [__thiscall] */
undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAA@PEBG@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this, ushort * param_1);

/* 0x140010790  29 bytes  [__thiscall] */
undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this);

/* 0x1400107ac  8 bytes  [__thiscall] */
undefined ??0CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this);

/* 0x1400107bc  122 bytes  [__thiscall] */
undefined ??0CVssDebugInfo@@QEAA@AEBU0@@Z(CVssDebugInfo * this, CVssDebugInfo * param_1);

/* 0x140010840  75 bytes  [__thiscall] */
undefined ??0CVssDebugInfo@@QEAA@PEBG00KKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5, _VSSDBG_SEV_ENUM param_6);

/* 0x140010894  242 bytes  [__thiscall] */
undefined ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2);

/* 0x140010990  48 bytes  [__thiscall] */
undefined ??0CVssOutputBuffer@@QEAA@XZ(CVssOutputBuffer * this);

/* 0x1400109c0  47 bytes  [__thiscall] */
void ??1?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this);

/* 0x1400109f8  34 bytes  [__thiscall] */
void ??1CVssAutoCoString@@QEAA@XZ(CVssAutoCoString * this);

/* 0x140010a24  73 bytes  [__thiscall] */
void ??1CVssDebugInfo@@QEAA@XZ(CVssDebugInfo * this);

/* 0x140010a74  271 bytes  [__thiscall] */
void ??1CVssFunctionTracer@@QEAA@XZ(CVssFunctionTracer * this);

/* 0x140010b90  8 bytes  [__thiscall] */
void ??1CVssOutputBuffer@@QEAA@XZ(CVssOutputBuffer * this);

/* 0x140010ba0  321 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@J@Z(CVssDebugInfo * this, long param_1);

/* 0x140010ce8  278 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@PEBG@Z(CVssDebugInfo * this, ushort * param_1);

/* 0x140010e08  289 bytes  [__thiscall] */
CVssDebugInfo ??6CVssDebugInfo@@QEAA?AU0@U_GUID@@@Z(CVssDebugInfo * this, _GUID * param_1);

/* 0x140010f30  4 bytes  [__thiscall] */
ushort * ??BCVssAutoCoString@@QEBAPEAGXZ(CVssAutoCoString * this);

/* 0x140010f3c  33 bytes  [__thiscall] */
CVssDebugInfo ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1);

/* 0x140010f64  441 bytes  [__thiscall] */
void ?Append@CVssAutoCoString@@QEAAXPEBG@Z(CVssAutoCoString * this, ushort * param_1);

/* 0x140011128  648 bytes  [__thiscall] */
void ?CoCreateInstanceWithLog@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@U_GUID@@PEBGK1PEAPEAUIUnknown@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, _GUID param_2, ushort * param_3, ulong param_4, _GUID param_5, IUnknown * * param_6);

/* 0x1400113b8  399 bytes  [__thiscall] */
void ?ComDisableSEH@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@@Z(CVssFunctionTracer * this, CVssDebugInfo param_1);

/* 0x140011550  216 bytes  [__thiscall] */
bool ?CopyFrom@CVssAutoCoString@@QEAA_NPEBG@Z(CVssAutoCoString * this, ushort * param_1);

/* 0x140011630  4 bytes  [__thiscall] */
ushort * ?GetBuffer@CVssOutputBuffer@@QEAAPEAGXZ(CVssOutputBuffer * this);

/* 0x14001163c  6 bytes  [__thiscall] */
int ?GetBufferSize@CVssOutputBuffer@@QEAAHXZ(CVssOutputBuffer * this);

/* 0x14001164c  554 bytes  [__thiscall] */
ushort * ?GetCurrentContexts@CVssFunctionTracer@@QEAAPEAGXZ(CVssFunctionTracer * this);

/* 0x140011880  496 bytes  [__thiscall] */
void ?GetCurrentUserName@CVssFunctionTracer@@QEAAXPEAGK@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2);

/* 0x140011a78  245 bytes  [__thiscall] */
void ?HandleComException@CVssFunctionTracer@@QEAAXAEAV_com_error@@PEBG11KK@Z(CVssFunctionTracer * this, _com_error * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x140011b74  140 bytes  [__thiscall] */
void ?HandleHresultException@CVssFunctionTracer@@QEAAXJPEBG00KK@Z(CVssFunctionTracer * this, long param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x140011c08  126 bytes  [__thiscall] */
void ?HandleStdBadAllocException@CVssFunctionTracer@@QEAAXPEBG00KK@Z(CVssFunctionTracer * this, ushort * param_1, ushort * param_2, ushort * param_3, ulong param_4, ulong param_5);

/* 0x140011c90  312 bytes  [__thiscall] */
void ?HandleStdGenericException@CVssFunctionTracer@@QEAAXAEBVexception@@PEBG11KK@Z(CVssFunctionTracer * this, exception * param_1, ushort * param_2, ushort * param_3, ushort * param_4, ulong param_5, ulong param_6);

/* 0x140011dd0  33 bytes  [__cdecl] */
void InternalThrow(long param_1);

/* 0x140011df8  14 bytes  [__thiscall] */
ulong ?InterpretSeverityLevel@CVssDebugInfo@@QEAAKW4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1);

/* 0x140011e10  8 bytes  [__thiscall] */
bool ?IsBufferValid@CVssOutputBuffer@@QEAA_NXZ(CVssOutputBuffer * this);

/* 0x140011e20  74 bytes  [__thiscall] */
int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHK@Z(CVssFunctionTracer * this, ulong param_1);

/* 0x140011e74  8 bytes  [__thiscall] */
int ?IsTracingEnabled@CVssFunctionTracer@@QEAAHXZ(CVssFunctionTracer * this);

/* 0x140011e84  509 bytes  [__thiscall] */
basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> ?LoadStringW@CVssResource@@QEAA?AV?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@I@Z(CVssResource * this, uint param_1);

/* 0x14001208c  1499 bytes  [__thiscall] */
void ?LogError@CVssFunctionTracer@@QEAAXKUCVssDebugInfo@@G@Z(CVssFunctionTracer * this, ulong param_1, CVssDebugInfo param_2, ushort param_3);

/* 0x140012674  316 bytes  [__cdecl] */
void ?StaticTrace@CVssFunctionTracer@@SAXUCVssDebugInfo@@KPEBG1ZZ(CVssDebugInfo param_1, ulong param_2, ushort * param_3, ushort * param_4, ...);

/* 0x1400127b8  109 bytes  [__cdecl] */
long StringCchPrintfA(char * param_1, __uint64 param_2, char * param_3, ...);

/* 0x14001282c  207 bytes  [__cdecl] */
long StringCchVPrintfExW(ushort * param_1, __uint64 param_2, ushort * * param_3, __uint64 * param_4, ulong param_5, ushort * param_6, char * param_7);

/* 0x140012904  386 bytes  [__thiscall] */
void ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x140012a90  245 bytes  [__thiscall] */
void ?Trace@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@QEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140012b8c  156 bytes  [__thiscall] */
void ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ulong param_2, uchar * param_3);

/* 0x140012c30  123 bytes  [__thiscall] */
void ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3);

/* 0x140012cb4  134 bytes  [__thiscall] */
void ?TraceInternal@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4);

/* 0x140012d40  196 bytes  [__thiscall] */
void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3, ...);

/* 0x140012e0c  298 bytes  [__thiscall] */
void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGK1ZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ulong param_3, ushort * param_4, ...);

/* 0x140012f40  638 bytes  [__thiscall] */
void ?TranslateComError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x1400131c8  113 bytes  [__thiscall] */
long ?TranslateComErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140013248  350 bytes  [__thiscall] */
void ?TranslateError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3);

/* 0x1400133b0  479 bytes  [__thiscall] */
void ?TranslateGenericError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x14001359c  122 bytes  [__thiscall] */
long ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...);

/* 0x140013620  742 bytes  [__thiscall] */
void ?TranslateInternalProviderError@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JJPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, long param_3, ushort * param_4, ...);

/* 0x140013914  518 bytes  [__thiscall] */
void ?TranslateWin32Error@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@PEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2, ...);

/* 0x140013b24  435 bytes  [__thiscall] */
void ?UpdateLocalIsTracingEnabledFlag@CVssFunctionTracer@@AEAAXXZ(CVssFunctionTracer * this);

/* 0x140013ce0  246 bytes  [__thiscall] */
void ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAAX_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this, __uint64 param_1, __uint64 param_2);

/* 0x140013df8  103 bytes  [__thiscall] */
void ?_Tidy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAAX_N_K@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this, bool param_1, __uint64 param_2);

/* 0x140013e68  253 bytes  [__thiscall] */
basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>_> * ?append@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAAAEAV12@AEBV12@_K1@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this, basic_string<unsigned_short,struct_std::char_traits<unsigned_short>,class_std::allocator<unsigned_short>_> * param_1, __uint64 param_2, __uint64 param_3);

/* 0x140013f70  258 bytes  [__cdecl] */
void ?Initialize@CVssSKU@@CAXXZ(void);

/* 0x14001407c  487 bytes  [__thiscall] */
void ??$Unpack@U_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@@CVssIOCTLChannel@@QEAAXAEAVCVssFunctionTracer@@PEAU_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@K_N@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, _VOLSNAP_DIFF_AREA_MINIMUM_SIZE * param_2, ulong param_3, bool param_4);

/* 0x14001426c  186 bytes  [__thiscall] */
void ??1CVssIOCTLChannel@@QEAA@XZ(CVssIOCTLChannel * this);

/* 0x140014330  237 bytes  [__thiscall] */
void ?ApplyAlignment@CVssIOCTLChannel@@AEAAXAEAVCVssFunctionTracer@@PEAK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong * param_2);

/* 0x140014428  1040 bytes  [__thiscall] */
long ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong param_2, bool param_3, _VSS_ICHANNEL_LOGGING param_4, bool param_5, void * param_6);

/* 0x140014844  940 bytes  [__cdecl] */
__int64 ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ(void);

/* 0x140014c40  968 bytes  [__cdecl] */
__int64 ?GetMinDiffAreaOnVolume@CVssMachineInformation@@SA_JPEBG@Z(ushort * param_1);

/* 0x140015070  459 bytes  [__cdecl] */
void GetVolumeNameWithCheck(CVssDebugInfo param_1, long param_2, ushort * param_3, ushort * param_4, ulong param_5);

/* 0x140015244  1059 bytes  [__thiscall] */
long ?Open@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@PEBG_N2W4_VSS_ICHANNEL_LOGGING@@KKK@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ushort * param_2, bool param_3, bool param_4, _VSS_ICHANNEL_LOGGING param_5, ulong param_6, ulong param_7, ulong param_8);

/* 0x140015674  9 bytes  [__thiscall] */
void ?ResetOffsets@CVssIOCTLChannel@@QEAAXXZ(CVssIOCTLChannel * this);

/* 0x140015684  29 bytes  [__fastcall] */
undefined8 __GSHandlerCheck(undefined8 param_1, undefined8 param_2, undefined8 param_3, longlong param_4);

/* 0x1400156a8  91 bytes  [__fastcall] */
ulonglong __GSHandlerCheckCommon(undefined8 param_1, longlong param_2);

/* 0x14001570c  127 bytes  [__fastcall] */
undefined __GSHandlerCheck_EH4(longlong param_1, undefined8 param_2, undefined8 param_3, longlong param_4);

/* 0x140015796  6 bytes  [__cdecl] */
void * memset(void * _Dst, int _Val, size_t _Size);

/* 0x1400157b0  2 bytes  [__fastcall] */
undefined _guard_dispatch_icall(void);

/* 0x1400157d0  6 bytes  [__fastcall] */
undefined _guard_xfg_dispatch_icall_nop(void);

/* 0x1400157f0  77 bytes  [__fastcall] */
undefined __chkstk(void);

/* 0x140015843  29 bytes  [__fastcall] */
undefined __wmainCRTStartup$filt$0(_EXCEPTION_POINTERS * param_1);

/* 0x140015867  26 bytes  [__fastcall] */
undefined _onexit$fin$0(void);

/* 0x140015888  31 bytes  [__fastcall] */
undefined * catch$0(undefined8 param_1, longlong param_2);

/* 0x1400158b0  31 bytes  [__fastcall] */
bool _IsNonwritableInCurrentImage$filt$0(undefined8 * param_1);

/* 0x1400158d6  43 bytes  [__fastcall] */
undefined fin$0(undefined8 param_1, longlong param_2);

/* 0x140015908  64 bytes  [__fastcall] */
undefined4 filt$0(undefined8 param_1, longlong param_2);

/* 0x140015950  43 bytes  [__fastcall] */
undefined fin$0(undefined8 param_1, longlong param_2);

/* 0x140015982  36 bytes  [__fastcall] */
undefined catch$0(undefined8 param_1, longlong param_2);

/* 0x1400159ad  70 bytes  [__fastcall] */
undefined8 catch$1(undefined8 param_1, longlong param_2);

/* 0x1400159fa  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015a0c  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015a1e  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015a30  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140015a42  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015a54  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015a66  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140015a78  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x140015a8a  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015a9c  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015aae  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015ac0  89 bytes  [__fastcall] */
undefined8 catch$21(undefined8 param_1, longlong param_2);

/* 0x140015b20  90 bytes  [__fastcall] */
undefined8 catch$22(undefined8 param_1, longlong param_2);

/* 0x140015b81  78 bytes  [__fastcall] */
undefined8 catch$23(undefined8 param_1, longlong param_2);

/* 0x140015bd6  90 bytes  [__fastcall] */
undefined8 catch$24(undefined8 param_1, longlong param_2);

/* 0x140015c37  89 bytes  [__fastcall] */
undefined8 catch$25(undefined8 param_1, longlong param_2);

/* 0x140015c97  90 bytes  [__fastcall] */
undefined8 catch$26(undefined8 param_1, longlong param_2);

/* 0x140015cf8  78 bytes  [__fastcall] */
undefined8 catch$27(undefined8 param_1, longlong param_2);

/* 0x140015d4d  90 bytes  [__fastcall] */
undefined8 catch$28(undefined8 param_1, longlong param_2);

/* 0x140015dae  12 bytes  [__fastcall] */
undefined dtor$12(undefined8 param_1, longlong param_2);

/* 0x140015dc0  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015dd2  86 bytes  [__fastcall] */
undefined8 catch$4(undefined8 param_1, longlong param_2);

/* 0x140015e2f  87 bytes  [__fastcall] */
undefined8 catch$5(undefined8 param_1, longlong param_2);

/* 0x140015e8d  78 bytes  [__fastcall] */
undefined8 catch$6(undefined8 param_1, longlong param_2);

/* 0x140015ee2  87 bytes  [__fastcall] */
undefined8 catch$7(undefined8 param_1, longlong param_2);

/* 0x140015f40  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015f52  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015f64  12 bytes  [__fastcall] */
undefined dtor$16(undefined8 param_1, longlong param_2);

/* 0x140015f76  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015f88  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x140015f9a  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140015fac  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140015fbe  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140015fd0  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140015fe2  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140015ff4  12 bytes  [__fastcall] */
undefined dtor$7(undefined8 param_1, longlong param_2);

/* 0x140016006  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x140016018  12 bytes  [__fastcall] */
undefined dtor$9(undefined8 param_1, longlong param_2);

/* 0x14001602a  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x14001603c  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x14001604e  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140016060  12 bytes  [__fastcall] */
undefined dtor$11(undefined8 param_1, longlong param_2);

/* 0x140016072  12 bytes  [__fastcall] */
undefined dtor$14(undefined8 param_1, longlong param_2);

/* 0x140016084  12 bytes  [__fastcall] */
undefined dtor$15(undefined8 param_1, longlong param_2);

/* 0x140016096  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x1400160a8  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x1400160ba  12 bytes  [__fastcall] */
undefined dtor$9(undefined8 param_1, longlong param_2);

/* 0x1400160cc  12 bytes  [__fastcall] */
undefined dtor$12(undefined8 param_1, longlong param_2);

/* 0x1400160de  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400160f0  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140016102  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x140016114  12 bytes  [__fastcall] */
undefined dtor$11(undefined8 param_1, longlong param_2);

/* 0x140016126  12 bytes  [__fastcall] */
undefined dtor$12(undefined8 param_1, longlong param_2);

/* 0x140016138  12 bytes  [__fastcall] */
undefined dtor$13(undefined8 param_1, longlong param_2);

/* 0x14001614a  12 bytes  [__fastcall] */
undefined dtor$14(undefined8 param_1, longlong param_2);

/* 0x14001615c  12 bytes  [__fastcall] */
undefined dtor$17(undefined8 param_1, longlong param_2);

/* 0x14001616e  12 bytes  [__fastcall] */
undefined dtor$18(undefined8 param_1, longlong param_2);

/* 0x140016180  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140016192  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x1400161a4  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x1400161b6  12 bytes  [__fastcall] */
undefined dtor$7(undefined8 param_1, longlong param_2);

/* 0x1400161c8  12 bytes  [__fastcall] */
undefined dtor$6(undefined8 param_1, longlong param_2);

/* 0x1400161da  12 bytes  [__fastcall] */
undefined dtor$8(undefined8 param_1, longlong param_2);

/* 0x1400161ec  12 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x1400161fe  12 bytes  [__fastcall] */
undefined dtor$5(undefined8 param_1, longlong param_2);

/* 0x140016210  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140016222  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x140016234  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016246  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x140016258  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x14001626a  45 bytes  [__fastcall] */
undefined dtor$2(undefined8 param_1, longlong param_2);

/* 0x14001629e  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x1400162b0  36 bytes  [__fastcall] */
undefined catch$5(undefined8 param_1, longlong param_2);

/* 0x1400162db  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400162ed  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x1400162ff  92 bytes  [__fastcall] */
undefined8 catch$14(undefined8 param_1, longlong param_2);

/* 0x140016362  93 bytes  [__fastcall] */
undefined8 catch$15(undefined8 param_1, longlong param_2);

/* 0x1400163c6  81 bytes  [__fastcall] */
undefined8 catch$16(undefined8 param_1, longlong param_2);

/* 0x14001641e  93 bytes  [__fastcall] */
undefined8 catch$17(undefined8 param_1, longlong param_2);

/* 0x140016482  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016494  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400164a6  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x1400164b8  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x1400164ca  12 bytes  [__fastcall] */
undefined dtor$4(undefined8 param_1, longlong param_2);

/* 0x1400164dc  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x1400164ee  29 bytes  [__fastcall] */
undefined8 catch$2(void);

/* 0x140016512  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016524  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016536  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016548  29 bytes  [__fastcall] */
undefined8 catch$2(void);

/* 0x14001656c  12 bytes  [__fastcall] */
undefined dtor$1(undefined8 param_1, longlong param_2);

/* 0x14001657e  36 bytes  [__fastcall] */
undefined catch$0(undefined8 param_1, longlong param_2);

/* 0x1400165a9  82 bytes  [__fastcall] */
undefined8 catch$1(undefined8 param_1, longlong param_2);

/* 0x140016602  89 bytes  [__fastcall] */
undefined8 catch$8(undefined8 param_1, longlong param_2);

/* 0x140016662  93 bytes  [__fastcall] */
undefined8 catch$9(undefined8 param_1, longlong param_2);

/* 0x1400166c6  81 bytes  [__fastcall] */
undefined8 catch$10(undefined8 param_1, longlong param_2);

/* 0x14001671e  93 bytes  [__fastcall] */
undefined8 catch$11(undefined8 param_1, longlong param_2);

/* 0x140016782  12 bytes  [__fastcall] */
undefined dtor$3(undefined8 param_1, longlong param_2);

/* 0x140016794  89 bytes  [__fastcall] */
undefined8 catch$6(undefined8 param_1, longlong param_2);

/* 0x1400167f4  93 bytes  [__fastcall] */
undefined8 catch$7(undefined8 param_1, longlong param_2);

/* 0x140016858  81 bytes  [__fastcall] */
undefined8 catch$8(undefined8 param_1, longlong param_2);

/* 0x1400168b0  93 bytes  [__fastcall] */
undefined8 catch$9(undefined8 param_1, longlong param_2);

/* 0x140016914  12 bytes  [__fastcall] */
undefined dtor$0(undefined8 param_1, longlong param_2);

/* 0x140016930  15 bytes  [__fastcall] */
undefined _Generic_object''(void);

/* 0x140016950  15 bytes  [__fastcall] */
undefined _Iostream_object''(void);

/* 0x140016970  15 bytes  [__fastcall] */
undefined _System_object''(void);

