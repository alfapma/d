/*
 * Function : ?DeleteDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z
 * Address  : 0x140005250
 * Size     : 11 bytes (6 instructions)
 * Prototype: void ?DeleteDiffAreas@CExternalVerifier@@UEAAXU_GUID@@PEBG1_NAEAVCVssFunctionTracer@@@Z(CExternalVerifier * this, _GUID * param_1, ushort * param_2, ushort * param_3, bool param_4, CVssFunctionTracer * param_5)
 * CC       : __thiscall
 * Comment  : public: virtual void __cdecl CExternalVerifier::DeleteDiffAreas(struct _GUID,unsigned short const * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void __cdecl CExternalVerifier::DeleteDiffAreas(struct _GUID,unsigned short const
   * __ptr64,unsigned short const * __ptr64,bool,class CVssFunctionTracer & __ptr64) __ptr64 */

void __thiscall
CExternalVerifier::
_DeleteDiffAreas_CExternalVerifier__UEAAXU_GUID__PEBG1_NAEAVCVssFunctionTracer___Z
          (CExternalVerifier *this,_GUID *param_1,ushort *param_2,ushort *param_3,bool param_4,
          CVssFunctionTracer *param_5)

{
  return;
}


