/*
 * Function : ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ
 * Address  : 0x14001359c
 * Size     : 122 bytes (26 instructions)
 * Prototype: long ?TranslateGenericErrorNoThrow@CVssFunctionTracer@@QEAAJUCVssDebugInfo@@JPEBGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: long __cdecl CVssFunctionTracer::TranslateGenericErrorNoThrow(struct
   CVssDebugInfo,long,unsigned short const * __ptr64,...) __ptr64 */

long __thiscall
CVssFunctionTracer::_TranslateGenericErrorNoThrow_CVssFunctionTracer__QEAAJUCVssDebugInfo__JPEBGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,uint param_3,undefined8 param_4,...)

{
  undefined8 uVar1;
  ulonglong uVar2;
  CVssDebugInfo local_b8 [176];
  
  uVar2 = (ulonglong)param_3;
  uVar1 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_b8,param_2);
                    /* WARNING: Subroutine does not return */
  _TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (this,uVar1,uVar2 & 0xffffffff,param_4,&stack0x00000028);
}


