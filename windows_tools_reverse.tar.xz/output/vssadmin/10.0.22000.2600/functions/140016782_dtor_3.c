/*
 * Function : dtor$3
 * Address  : 0x140016782
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$3(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::dtor_3
               (undefined8 param_1,longlong param_2)

{
  CVssIOCTLChannel::__1CVssIOCTLChannel__QEAA_XZ((CVssIOCTLChannel *)(param_2 + 0x110));
  return;
}


