/*
 * Function : __security_check_cookie
 * Address  : 0x1400016d0
 * Size     : 30 bytes (8 instructions)
 * Prototype: void __security_check_cookie(uintptr_t _StackCookie)
 * CC       : __cdecl
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: This is an inlined function */

void __cdecl __security_check_cookie(uintptr_t _StackCookie)

{
  if ((_StackCookie == __security_cookie) && ((short)(_StackCookie >> 0x30) == 0)) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  __report_gsfailure(_StackCookie);
}


