/*
 * Function : ??$Unpack@U_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@@CVssIOCTLChannel@@QEAAXAEAVCVssFunctionTracer@@PEAU_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@K_N@Z
 * Address  : 0x14001407c
 * Size     : 487 bytes (110 instructions)
 * Prototype: void ??$Unpack@U_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@@CVssIOCTLChannel@@QEAAXAEAVCVssFunctionTracer@@PEAU_VOLSNAP_DIFF_AREA_MINIMUM_SIZE@@K_N@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, _VOLSNAP_DIFF_AREA_MINIMUM_SIZE * param_2, ulong param_3, bool param_4)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssIOCTLChannel::Unpack<struct _VOLSNAP_DIFF_AREA_MINIMUM_SIZE>(class CVssFunctionTracer & __ptr64,struct _VOLSNAP_DIFF_AREA_MINIMUM_SIZE * __ptr64,unsigned long,bool) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssIOCTLChannel::Unpack<struct _VOLSNAP_DIFF_AREA_MINIMUM_SIZE>(class
   CVssFunctionTracer & __ptr64,struct _VOLSNAP_DIFF_AREA_MINIMUM_SIZE * __ptr64,unsigned long,bool)
   __ptr64 */

void __thiscall
CVssIOCTLChannel::
___Unpack_U_VOLSNAP_DIFF_AREA_MINIMUM_SIZE___CVssIOCTLChannel__QEAAXAEAVCVssFunctionTracer__PEAU_VOLSNAP_DIFF_AREA_MINIMUM_SIZE__K_N_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,
          _VOLSNAP_DIFF_AREA_MINIMUM_SIZE *param_2,ulong param_3,bool param_4)

{
  uint uVar1;
  ulong uVar2;
  longlong lVar3;
  code *pcVar4;
  uint uVar5;
  undefined8 uVar6;
  CVssIOCTLChannel *pCVar7;
  undefined8 in_stack_ffffffffffffff18;
  undefined4 uVar8;
  _VSSDBG_SEV_ENUM in_stack_ffffffffffffff28;
  _VSSDBG_SEV_ENUM _Var9;
  wchar_t *local_c0;
  wchar_t *local_b8;
  wchar_t *local_b0;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined1 local_98 [120];
  undefined4 local_20;
  
  uVar8 = (undefined4)((ulonglong)in_stack_ffffffffffffff18 >> 0x20);
  lVar3 = *(longlong *)(this + 0x50);
  if (lVar3 != 0) {
    pCVar7 = this + 0x40;
    uVar1 = *(uint *)pCVar7;
    uVar5 = uVar1 + 8;
    if ((uVar1 <= uVar5) && (uVar5 <= *(uint *)(this + 0x48))) {
      if (uVar5 <= *(uint *)(this + 0x44)) {
        *(undefined8 *)param_2 = *(undefined8 *)((ulonglong)uVar1 + lVar3);
        *(ulong *)pCVar7 = *(ulong *)pCVar7 + 8;
        if (*(short *)(this + 0x58) != 0) {
          _ApplyAlignment_CVssIOCTLChannel__AEAAXAEAVCVssFunctionTracer__PEAK_Z
                    (this,param_1,(ulong *)pCVar7);
        }
        return;
      }
      _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
      uVar2 = *(ulong *)pCVar7;
      uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_c0,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Unpack",0x300,10,
                         in_stack_ffffffffffffff28);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar6,0x8007000e,
                 L"Arithmetic overflow. m_dwOutputCurrentOffset = %lu or dwSize = %lu too large.",
                 CONCAT44(uVar8,uVar2),8);
    }
  }
  _Var9 = *(_VSSDBG_SEV_ENUM *)(this + 0x40);
  local_c0 = L"base\\stor\\vss\\inc\\ichannel.hxx";
  local_b8 = L"CVssIOCTLChannel::Unpack";
  local_b0 = L"INCICHLH";
  local_a8 = 0x2e7;
  local_a4 = 10;
  local_a0 = 0xff;
  local_20 = 0x1000000;
  memset(local_98,0,0x78);
  uVar6 = CONCAT44(uVar8,_Var9);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (param_1,&local_c0,
             L"Output buffer overflow. Trying to read non-existent arguments. m_pbOutputBuffer = %p, m_dwOutputCurrentOffset = %lu, dwSize = %lu, m_dwOutputCurrentOffset = %lu"
             ,lVar3,uVar6,8);
  *(undefined4 *)(this + 0x2c) = 0;
  *(undefined4 *)(this + 0x40) = 0;
  uVar8 = (undefined4)((ulonglong)uVar6 >> 0x20);
  if (*(int *)(param_1 + 0x24) == 2) {
    uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_c0,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Unpack",0x2f2,10,_Var9);
    CVssFunctionTracer::
    _TranslateInternalProviderError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JJPEBGZZ
              (param_1,uVar6,0x8000ffff,0x80042306,L"IOCTL Unpack overflow");
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
  }
  uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_c0,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                     (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Unpack",0x2f4,10,_Var9);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
            (param_1,uVar6,0x8000ffff,L"Output buffer overflow. Reading bad arguments. dwSize = %lu"
             ,CONCAT44(uVar8,8));
}


