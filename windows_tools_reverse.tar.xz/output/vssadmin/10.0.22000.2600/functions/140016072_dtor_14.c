/*
 * Function : dtor$14
 * Address  : 0x140016072
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$14(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_14(undefined8 param_1,longlong param_2)

{
  CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
  ::
  __1__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAA_XZ
            ((CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
              *)(param_2 + 0x50));
  return;
}


