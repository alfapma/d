/*
 * Function : ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z
 * Address  : 0x140009594
 * Size     : 214 bytes (53 instructions)
 * Prototype: int ?GetOptionValueNum@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_JH@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2, int param_3)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: int __cdecl CVssAdminCLI::GetOptionValueNum(enum EVssAdmOption,__int64 * __ptr64,int)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValueNum_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_JH_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2,int param_3)

{
  ushort *puVar1;
  __int64 _Var2;
  CVssFunctionTracer *this_00;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [112];
  
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_130 = L"CVssAdminCLI::GetOptionValueNum";
  local_128 = L"INCPNTRH";
  local_120 = 0x168;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  this_00 = local_88;
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(this_00,&local_138);
  puVar1 = *(ushort **)(this + (longlong)(int)param_1 * 8 + 0x68);
  if (puVar1 != (ushort *)0x0) {
    _Var2 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,puVar1,param_3);
    *param_2 = _Var2;
  }
  else {
    *param_2 = 0;
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return (int)(puVar1 != (ushort *)0x0);
}


