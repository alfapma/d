/*
 * Function : dtor$9
 * Address  : 0x140016018
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$9(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_9(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0x70));
  return;
}


