/*
 * Function : ??0bad_alloc@std@@QEAA@XZ
 * Address  : 0x1400010c8
 * Size     : 55 bytes (13 instructions)
 * Prototype: undefined ??0bad_alloc@std@@QEAA@XZ(bad_alloc * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl std::bad_alloc::bad_alloc(void) __ptr64 */

bad_alloc * __thiscall std::bad_alloc::__0bad_alloc_std__QEAA_XZ(bad_alloc *this)

{
  exception::__0exception__QEAA_AEBQEBDH_Z((exception *)this,&_bad_alloc_Message,1);
  *(undefined ***)this = &_vftable_;
  return this;
}


