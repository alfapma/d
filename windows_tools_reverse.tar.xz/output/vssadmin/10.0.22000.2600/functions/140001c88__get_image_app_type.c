/*
 * Function : _get_image_app_type
 * Address  : 0x140001c88
 * Size     : 69 bytes (23 instructions)
 * Prototype: undefined4 _get_image_app_type(undefined4 param_1)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined4 _get_image_app_type(undefined4 param_1)

{
  HMODULE pHVar1;
  int *piVar2;
  
  pHVar1 = GetModuleHandleW((LPCWSTR)0x0);
  if ((pHVar1 != (HMODULE)0x0) &&
     (piVar2 = RtlpImageNtHeader((short *)pHVar1), piVar2 != (int *)0x0)) {
    if ((short)piVar2[0x17] == 2) {
      return 2;
    }
    if ((short)piVar2[0x17] == 3) {
      return 1;
    }
  }
  return param_1;
}


