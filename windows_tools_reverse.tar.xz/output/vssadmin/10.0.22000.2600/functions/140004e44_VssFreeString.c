/*
 * Function : VssFreeString
 * Address  : 0x140004e44
 * Size     : 34 bytes (10 instructions)
 * Prototype: void VssFreeString(ushort * * param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl VssFreeString(unsigned short * __ptr64 & __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* void __cdecl VssFreeString(unsigned short * __ptr64 & __ptr64) */

void __cdecl VssFreeString(ushort **param_1)

{
  CoTaskMemFree(*param_1);
  *param_1 = (ushort *)0x0;
  return;
}


