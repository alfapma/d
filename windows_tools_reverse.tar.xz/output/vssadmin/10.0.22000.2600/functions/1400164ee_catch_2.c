/*
 * Function : catch$2
 * Address  : 0x1400164ee
 * Size     : 29 bytes (8 instructions)
 * Prototype: undefined8 catch$2(void)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined8 `CVssFunctionTracer::TranslateComErrorNoThrow'::__l1::catch_2(void)

{
  return 0;
}


