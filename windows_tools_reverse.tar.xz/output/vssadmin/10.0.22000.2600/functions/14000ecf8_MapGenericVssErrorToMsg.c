/*
 * Function : MapGenericVssErrorToMsg
 * Address  : 0x14000ecf8
 * Size     : 657 bytes (135 instructions)
 * Prototype: int MapGenericVssErrorToMsg(long param_1, ushort * * param_2)
 * CC       : __cdecl
 * Comment  : int __cdecl MapGenericVssErrorToMsg(long,unsigned short * __ptr64 * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* int __cdecl MapGenericVssErrorToMsg(long,unsigned short * __ptr64 * __ptr64) */

int __cdecl MapGenericVssErrorToMsg(long param_1,ushort **param_2)

{
  DWORD DVar1;
  BOOL BVar2;
  HMODULE hLibModule;
  uint uVar3;
  wchar_t *pwVar4;
  bool bVar5;
  ushort *local_res10;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_130 = 0x42a;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_140 = L"MapGenericVssErrorToMsg";
  local_138 = L"ADMUTILC";
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  local_res10 = (ushort *)0x0;
  if (param_2 == (ushort **)0x0) {
    local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_140 = L"MapGenericVssErrorToMsg";
    local_138 = L"ADMUTILC";
    local_130 = 0x432;
    local_12c = 7;
    local_128 = 0xff;
    local_a8 = 0x1000000;
    memset(local_120,0,0x78);
    pwVar4 = L"Invalid parameter";
    uVar3 = 0;
  }
  else {
    *param_2 = (ushort *)0x0;
    hLibModule = LoadLibraryW(L"vsstrace.dll");
    if (hLibModule == (HMODULE)0x0) {
      local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_138 = L"ADMUTILC";
      local_140 = L"MapGenericVssErrorToMsg";
      local_130 = 0x43c;
      local_12c = 7;
      local_128 = 0xff;
      local_a8 = 0x1000000;
      memset(local_120,0,0x78);
      pwVar4 = L"Failed to load vsstrace.dll";
      uVar3 = 0;
    }
    else {
      DVar1 = FormatMessageW(0xb00,hLibModule,param_1,0x400,(LPWSTR)&local_res10,0,(va_list *)0x0);
      bVar5 = DVar1 != 0;
      if (bVar5) {
        *param_2 = local_res10;
      }
      else {
        local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
        local_138 = L"ADMUTILC";
        local_140 = L"MapGenericVssErrorToMsg";
        local_130 = 0x44c;
        local_12c = 7;
        local_128 = 0xff;
        local_a8 = 0x1000000;
        memset(local_120,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_98,&local_148,L"Unable to find error message in VssTrace.");
      }
      uVar3 = (uint)bVar5;
      BVar2 = FreeLibrary(hLibModule);
      if (BVar2 != 0) goto LAB_14000ef5d;
      local_148 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
      local_140 = L"MapGenericVssErrorToMsg";
      local_138 = L"ADMUTILC";
      local_130 = 0x458;
      local_12c = 7;
      local_128 = 0xff;
      local_a8 = 0x1000000;
      memset(local_120,0,0x78);
      pwVar4 = L"Unable to free VssTrace.dll";
      uVar3 = (uint)bVar5;
    }
  }
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_98,&local_148,pwVar4);
LAB_14000ef5d:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return uVar3;
}


