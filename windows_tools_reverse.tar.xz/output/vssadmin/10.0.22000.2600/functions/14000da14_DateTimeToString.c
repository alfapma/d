/*
 * Function : DateTimeToString
 * Address  : 0x14000da14
 * Size     : 785 bytes (171 instructions)
 * Prototype: ushort * DateTimeToString(__int64 * param_1)
 * CC       : __cdecl
 * Comment  : unsigned short * __ptr64 __cdecl DateTimeToString(__int64 * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* unsigned short * __ptr64 __cdecl DateTimeToString(__int64 * __ptr64) */

ushort * __cdecl DateTimeToString(__int64 *param_1)

{
  LCID LVar1;
  long lVar2;
  longlong lVar3;
  ushort *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 auStackY_378 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffcb8;
  _FILETIME local_338;
  _FILETIME local_330;
  wchar_t *local_328;
  wchar_t *local_320;
  wchar_t *local_318;
  undefined4 local_310;
  undefined4 local_30c;
  undefined4 local_308;
  undefined1 local_300 [120];
  undefined4 local_288;
  CVssFunctionTracer local_278 [8];
  long local_270;
  CVssDebugInfo local_208 [168];
  _SYSTEMTIME local_160;
  _SYSTEMTIME local_150;
  WCHAR local_138 [64];
  WCHAR local_b8 [64];
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_378;
  local_328 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_320 = L"DateTimeToString";
  local_318 = L"ADMUTILC";
  local_310 = 0x47b;
  local_30c = 7;
  local_308 = 0xff;
  local_288 = 0x1000000;
  memset(local_300,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_278,&local_328);
  if ((param_1 == (__int64 *)0x0) || (*param_1 == 0)) {
    GetSystemTime(&local_160);
    SystemTimeToFileTime(&local_160,&local_338);
    param_1 = (__int64 *)&local_338;
  }
  FileTimeToLocalFileTime((FILETIME *)param_1,&local_330);
  FileTimeToSystemTime(&local_330,&local_150);
  LVar1 = GetThreadLocale();
  GetDateFormatW(LVar1,1,&local_150,(LPCWSTR)0x0,local_b8,0x40);
  LVar1 = GetThreadLocale();
  GetTimeFormatW(LVar1,0,&local_150,(LPCWSTR)0x0,local_138,0x40);
  lVar7 = -1;
  lVar6 = -1;
  do {
    lVar6 = lVar6 + 1;
  } while (local_138[lVar6] != L'\0');
  lVar3 = -1;
  do {
    lVar3 = lVar3 + 1;
  } while (local_b8[lVar3] != L'\0');
  puVar4 = CoTaskMemAlloc((lVar6 + lVar3) * 2 + 4);
  if (puVar4 == (ushort *)0x0) {
    GetLastError();
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_328,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"DateTimeToString",0x4ad,7,
                       in_stack_fffffffffffffcb8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_278,uVar5,0x8007000e,L"Error from CoTaskMemAlloc, rc: %d");
  }
  lVar6 = -1;
  do {
    lVar3 = lVar6;
    lVar6 = lVar3 + 1;
  } while (local_138[lVar6] != L'\0');
  do {
    lVar7 = lVar7 + 1;
  } while (local_b8[lVar7] != L'\0');
  lVar2 = StringCchPrintfW(puVar4,lVar3 + 3 + lVar7,(ushort *)L"%s %s",local_b8);
  local_328 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_320 = L"DateTimeToString";
  local_318 = L"ADMUTILC";
  local_310 = 0x4b2;
  local_30c = 7;
  local_308 = 0xff;
  local_288 = 0x1000000;
  local_270 = lVar2;
  memset(local_300,0,0x78);
  local_338 = (_FILETIME)&local_328;
  if (-1 < lVar2) {
    CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_328);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_278);
    return puVar4;
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_208,(CVssDebugInfo *)&local_328);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
            (local_278,uVar5,lVar2,L"StringCchPrintf");
}


