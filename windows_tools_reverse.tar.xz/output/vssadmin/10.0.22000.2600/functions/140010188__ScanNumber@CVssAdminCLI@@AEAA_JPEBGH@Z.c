/*
 * Function : ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z
 * Address  : 0x140010188
 * Size     : 1318 bytes (286 instructions)
 * Prototype: __int64 ?ScanNumber@CVssAdminCLI@@AEAA_JPEBGH@Z(CVssAdminCLI * this, ushort * param_1, int param_2)
 * CC       : __thiscall
 * Comment  : private: __int64 __cdecl CVssAdminCLI::ScanNumber(unsigned short const * __ptr64,int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: __int64 __cdecl CVssAdminCLI::ScanNumber(unsigned short const * __ptr64,int) __ptr64 */

__int64 __thiscall
CVssAdminCLI::_ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z
          (CVssAdminCLI *this,ushort *param_1,int param_2)

{
  wchar_t *_Src;
  wint_t wVar1;
  int iVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  wchar_t _C;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe88;
  undefined **local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  wchar_t *local_150;
  wchar_t *local_148;
  undefined4 local_140;
  undefined4 local_13c;
  undefined4 local_138;
  undefined1 local_130 [120];
  undefined4 local_b8;
  CVssFunctionTracer local_a8 [112];
  
  local_158 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_150 = L"CVssAdminCLI::ScanNumber";
  local_148 = L"ADMUTILC";
  local_140 = 0x1db;
  local_13c = 7;
  local_138 = 0xff;
  uVar5 = 0;
  local_b8 = 0x1000000;
  memset(local_130,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_158);
  _C = L'B';
  iVar2 = _wcsicmp((wchar_t *)param_1,L"UNBOUNDED");
  if (iVar2 == 0) goto LAB_14001029a;
  local_160 = (wchar_t *)0x0;
  local_168 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_168,param_1);
  _Src = local_160;
  uVar4 = 0xffffffffffffffff;
  do {
    uVar4 = uVar4 + 1;
  } while (local_160[uVar4] != L'\0');
  if (uVar4 != 0) {
    do {
      if (local_160[uVar4 - 1] != L' ') goto LAB_1400102c2;
      uVar4 = uVar4 - 1;
      local_160[uVar4] = L'\0';
    } while (uVar4 != 0);
    if (false) {
LAB_1400102c2:
      if (param_2 == 0) {
        uVar4 = 0xffffffffffffffff;
        do {
          uVar4 = uVar4 + 1;
        } while (local_160[uVar4] != L'\0');
        if (uVar4 != 0) {
          do {
            iVar2 = iswdigit(_Src[uVar5]);
            if (iVar2 == 0) {
              uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                                ((CVssDebugInfo *)&local_158,
                                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                                 (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x21a,7
                                 ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
              CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                        (local_a8,uVar3,0x1001,
                         L"Invalid input number: \'%s\', number must be all digits",param_1);
            }
            uVar5 = uVar5 + 1;
          } while (uVar5 < uVar4);
        }
      }
      else {
        if (uVar4 < 4) {
          if (2 < uVar4) goto LAB_14001031b;
          if (uVar4 < 2) goto LAB_1400103e2;
        }
        else {
          iVar2 = iswalpha(local_160[uVar4 - 3]);
          if (((iVar2 != 0) && (iVar2 = iswalpha(_Src[uVar4 - 2]), iVar2 != 0)) &&
             (iVar2 = iswalpha(_Src[uVar4 - 1]), iVar2 != 0)) {
            uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                              ((CVssDebugInfo *)&local_158,
                               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                               (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x1fe,7,
                               in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
            CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                      (local_a8,uVar3,0x1001,
                       L"Invalid input number: \'%s\', too many alpha chars in suffix.",param_1);
          }
LAB_14001031b:
          iVar2 = iswalpha(_Src[uVar4 - 2]);
          if ((iVar2 != 0) && (wVar1 = towupper(_Src[uVar4 - 1]), wVar1 == 0x42)) {
            wVar1 = towupper(_Src[uVar4 - 2]);
            if (wVar1 == 0x42) {
              uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                                ((CVssDebugInfo *)&local_158,
                                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                                 (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x205,7
                                 ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
              CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                        (local_a8,uVar3,0x1001,
                         L"Invalid input number: \'%s\', BB is not a valid suffix",param_1);
            }
            _C = _Src[uVar4 - 2];
            _Src[uVar4 - 2] = L'\0';
            goto LAB_1400103e2;
          }
        }
        iVar2 = iswalpha(_Src[uVar4 - 1]);
        if (iVar2 != 0) {
          _C = _Src[uVar4 - 1];
          _Src[uVar4 - 1] = L'\0';
        }
      }
LAB_1400103e2:
      iVar2 = swscanf(_Src,L"%lf");
      if (iVar2 != 1) {
        uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_158,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                           (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x222,7,
                           in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
      }
      wVar1 = towupper(_C);
      if (wVar1 == 0x42) goto LAB_1400104b1;
      if (wVar1 == 0x45) {
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14001048b:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_14001048f:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_140010493:
        this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_140010497:
        this = (CVssAdminCLI *)((double)this * 1024.0);
      }
      else {
        if (wVar1 == 0x47) goto LAB_140010493;
        if (wVar1 != 0x4b) {
          if (wVar1 != 0x4d) {
            if (wVar1 == 0x50) goto LAB_14001048b;
            if (wVar1 != 0x54) {
              uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                                ((CVssDebugInfo *)&local_158,
                                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                                 (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x238,7
                                 ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
              CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                        (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
            }
            goto LAB_14001048f;
          }
          goto LAB_140010497;
        }
      }
      this = (CVssAdminCLI *)((double)this * 1024.0);
LAB_1400104b1:
      if (-1 < (longlong)(double)this) {
        if (_Src != (wchar_t *)0x0) {
          CoTaskMemFree(_Src);
        }
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
        return (longlong)(double)this;
      }
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_158,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::ScanNumber",0x240,7,
                         in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_a8,uVar3,0x1001,L"Invalid input number: %s",param_1);
    }
  }
  if (local_160 != (wchar_t *)0x0) {
    CoTaskMemFree(local_160);
  }
LAB_14001029a:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return -1;
}


