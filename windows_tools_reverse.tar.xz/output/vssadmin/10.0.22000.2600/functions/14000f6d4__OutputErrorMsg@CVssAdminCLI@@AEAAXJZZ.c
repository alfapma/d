/*
 * Function : ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ
 * Address  : 0x14000f6d4
 * Size     : 592 bytes (129 instructions)
 * Prototype: void ?OutputErrorMsg@CVssAdminCLI@@AEAAXJZZ(CVssAdminCLI * this, long param_1, ...)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: void __cdecl CVssAdminCLI::OutputErrorMsg(long,...) __ptr64 */

void __thiscall
CVssAdminCLI::_OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(CVssAdminCLI *this,long param_1,...)

{
  DWORD DVar1;
  undefined8 uVar2;
  undefined8 in_R8;
  undefined8 in_R9;
  undefined8 local_res18;
  undefined8 local_res20;
  ushort **lpBuffer;
  undefined4 uVar3;
  _VSSDBG_SEV_ENUM _Var4;
  va_list *Arguments;
  ushort *local_168;
  va_list local_160 [2];
  wchar_t *local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  undefined4 local_138;
  undefined4 local_134;
  undefined4 local_130;
  undefined1 local_128 [120];
  undefined4 local_b0;
  CVssFunctionTracer local_a8 [120];
  
  local_150 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_148 = L"CVssAdminCLI::OutputErrorMsg";
  local_140 = L"ADMUTILC";
  local_138 = 0x284;
  local_134 = 7;
  local_130 = 0xff;
  local_b0 = 0x1000000;
  local_res18 = in_R8;
  local_res20 = in_R9;
  memset(local_128,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_a8,&local_150);
  local_160[0] = (va_list)&local_res18;
  DVar1 = FormatMessageW(0x900,(LPCVOID)0x0,0x40002714,0x400,(LPWSTR)&local_168,0,(va_list *)0x0);
  if (DVar1 != 0) {
    _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_168);
    LocalFree(local_168);
  }
  DVar1 = 0x1100;
  if (0x4000270f < param_1) {
    DVar1 = 0x900;
  }
  DVar1 = FormatMessageW(DVar1,(LPCVOID)0x0,param_1,0x400,(LPWSTR)&local_168,0,local_160);
  if (DVar1 == 0) {
    Arguments = local_160;
    lpBuffer = &local_168;
    DVar1 = FormatMessageW(0x1100,(LPCVOID)0x0,param_1,0x400,(LPWSTR)lpBuffer,0,Arguments);
    _Var4 = (_VSSDBG_SEV_ENUM)Arguments;
    uVar3 = (undefined4)((ulonglong)lpBuffer >> 0x20);
    if (DVar1 == 0) {
      GetLastError();
      wprintf(L"Unable to format message for id %x - %d\n");
      DVar1 = GetLastError();
      uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_150,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::OutputErrorMsg",0x2bd,7,
                         _Var4);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_a8,uVar2,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx",
                 CONCAT44(uVar3,param_1),DVar1);
    }
  }
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" ");
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,local_168);
  _OutputOnConsole_CVssAdminCLI__AEAAXPEBG_Z(this,(ushort *)L" \r\n");
  LocalFree(local_168);
  local_160[0] = (va_list)0x0;
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_a8);
  return;
}


