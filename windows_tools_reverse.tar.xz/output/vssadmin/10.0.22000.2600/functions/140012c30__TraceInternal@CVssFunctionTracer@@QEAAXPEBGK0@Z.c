/*
 * Function : ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z
 * Address  : 0x140012c30
 * Size     : 123 bytes (32 instructions)
 * Prototype: void ?TraceInternal@CVssFunctionTracer@@QEAAXPEBGK0@Z(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssFunctionTracer::TraceInternal(unsigned short const * __ptr64,unsigned
   long,unsigned short const * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2,ushort *param_3)

{
  int iVar1;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    Ordinal_3(*(undefined8 *)(this + 0x10),*(undefined8 *)(this + 0x18),*(undefined4 *)(this + 0x20)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(this + 0x24),
              *(undefined8 *)(this + 0x28),param_1,param_2,param_3);
  }
  return;
}


