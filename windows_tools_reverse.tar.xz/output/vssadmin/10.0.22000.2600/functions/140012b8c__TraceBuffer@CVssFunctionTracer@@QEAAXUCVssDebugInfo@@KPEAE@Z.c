/*
 * Function : ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z
 * Address  : 0x140012b8c
 * Size     : 156 bytes (38 instructions)
 * Prototype: void ?TraceBuffer@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@KPEAE@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ulong param_2, uchar * param_3)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceBuffer(struct CVssDebugInfo,unsigned long,unsigned char * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssFunctionTracer::TraceBuffer(struct CVssDebugInfo,unsigned long,unsigned
   char * __ptr64) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined4 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    uVar2 = 0xbe;
    if (*(int *)(param_2 + 0x20) != 0xff) {
      uVar2 = *(undefined4 *)(param_2 + 0x20);
    }
    Ordinal_4(*(undefined8 *)param_2,*(undefined8 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x18)
              ,*(undefined4 *)(this + 0x30),*(undefined4 *)(this + 0x24),
              *(undefined8 *)(this + 0x28),L"TRACE_BINARY",uVar2,param_4,param_3);
  }
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return;
}


