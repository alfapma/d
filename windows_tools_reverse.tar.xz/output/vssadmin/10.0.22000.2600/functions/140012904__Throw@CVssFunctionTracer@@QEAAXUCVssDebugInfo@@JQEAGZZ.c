/*
 * Function : ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ
 * Address  : 0x140012904
 * Size     : 386 bytes (94 instructions)
 * Prototype: void ?Throw@CVssFunctionTracer@@QEAAXUCVssDebugInfo@@JQEAGZZ(CVssFunctionTracer * this, CVssDebugInfo param_1, long param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64 const,...) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssFunctionTracer::Throw(struct CVssDebugInfo,long,unsigned short * __ptr64
   const,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined4 param_3,ushort *param_4,...)

{
  bool bVar1;
  int iVar2;
  ulong uVar3;
  ushort *puVar4;
  undefined8 uVar5;
  CVssOutputBuffer *this_00;
  __uint64 _Var6;
  char *pcVar7;
  ulonglong uVar8;
  ulong in_stack_fffffffffffffef8;
  __uint64 local_e8;
  ushort *local_e0;
  CVssOutputBuffer local_d8 [8];
  CVssDebugInfo local_d0 [168];
  
  iVar2 = _IsTracingEnabled_CVssFunctionTracer__QEAAHXZ(this);
  if ((iVar2 != 0) && (param_4 != (ushort *)0x0)) {
    CVssOutputBuffer::__0CVssOutputBuffer__QEAA_XZ(local_d8);
    this_00 = local_d8;
    bVar1 = CVssOutputBuffer::_IsBufferValid_CVssOutputBuffer__QEAA_NXZ(this_00);
    if (bVar1) {
      local_e8 = 0;
      local_e0 = (ushort *)0x0;
      pcVar7 = &stack0x00000028;
      iVar2 = CVssOutputBuffer::_GetBufferSize_CVssOutputBuffer__QEAAHXZ(this_00);
      _Var6 = (__uint64)iVar2;
      puVar4 = CVssOutputBuffer::_GetBuffer_CVssOutputBuffer__QEAAPEAGXZ(local_d8);
      StringCchVPrintfExW(puVar4,_Var6,&local_e0,&local_e8,in_stack_fffffffffffffef8,param_4,pcVar7)
      ;
      if (local_e8 == 1) {
        local_e0[-2] = 0x2e;
        local_e0[-1] = 0x2e;
        local_e0[-3] = 0x2e;
      }
      uVar3 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                        (param_2,0x50);
      uVar8 = (ulonglong)uVar3;
      uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
      _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
                (this,uVar5,L"THROW",uVar8 & 0xffffffff,puVar4);
    }
    CVssAutoCoString::__0CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_e8);
    puVar4 = _GetCurrentContexts_CVssFunctionTracer__QEAAPEAGXZ(this);
    CVssAutoCoString::_CopyFrom_CVssAutoCoString__QEAA_NPEBG_Z((CVssAutoCoString *)&local_e8,puVar4)
    ;
    puVar4 = CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ((CVssAutoCoString *)&local_e8);
    uVar3 = CVssDebugInfo::_InterpretSeverityLevel_CVssDebugInfo__QEAAKW4_VSSDBG_SEV_ENUM___Z
                      (param_2,200);
    uVar8 = (ulonglong)uVar3;
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z(local_d0,param_2);
    _TraceInternal_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGK1_Z
              (this,uVar5,L"THROW",uVar8 & 0xffffffff,puVar4);
    CVssAutoCoString::__1CVssAutoCoString__QEAA_XZ((CVssAutoCoString *)&local_e8);
    CVssOutputBuffer::__1CVssOutputBuffer__QEAA_XZ(local_d8);
  }
  *(undefined4 *)(this + 8) = param_3;
  local_e8 = CONCAT44(local_e8._4_4_,param_3);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(&local_e8,(ThrowInfo *)&_TI1J);
}


