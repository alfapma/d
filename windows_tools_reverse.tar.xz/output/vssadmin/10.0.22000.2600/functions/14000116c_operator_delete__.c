/*
 * Function : operator_delete[]
 * Address  : 0x14000116c
 * Size     : 5 bytes (1 instructions)
 * Prototype: void operator_delete[](void * param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl operator delete[](void * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* void __cdecl operator delete[](void * __ptr64) */

void __cdecl operator_delete__(void *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x000140001853. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  free(param_1);
  return;
}


