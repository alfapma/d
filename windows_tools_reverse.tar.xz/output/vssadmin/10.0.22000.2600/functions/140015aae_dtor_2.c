/*
 * Function : dtor$2
 * Address  : 0x140015aae
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$2(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::Main'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  CVssAdminCLI::__1CVssAdminCLI__QEAA_XZ((CVssAdminCLI *)(param_2 + 0x3a0));
  return;
}


