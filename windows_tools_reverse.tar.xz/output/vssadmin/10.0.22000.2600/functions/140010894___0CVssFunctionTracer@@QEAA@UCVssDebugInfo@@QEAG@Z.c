/*
 * Function : ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z
 * Address  : 0x140010894
 * Size     : 242 bytes (64 instructions)
 * Prototype: undefined ??0CVssFunctionTracer@@QEAA@UCVssDebugInfo@@QEAG@Z(CVssFunctionTracer * this, CVssDebugInfo param_1, ushort * param_2)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssFunctionTracer::CVssFunctionTracer(struct CVssDebugInfo,unsigned short * __ptr64 const) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl CVssFunctionTracer::CVssFunctionTracer(struct CVssDebugInfo,unsigned short *
   __ptr64 const) __ptr64 */

CVssFunctionTracer * __thiscall
CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z
          (CVssFunctionTracer *this,CVssDebugInfo *param_2,undefined8 param_3)

{
  DWORD DVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  undefined8 local_res18 [2];
  
  iVar3 = 0;
  *(undefined4 *)(this + 8) = 0;
  *(undefined8 *)(this + 0x28) = *(undefined8 *)(param_2 + 8);
  *(undefined8 *)(this + 0x10) = *(undefined8 *)param_2;
  *(undefined8 *)(this + 0x18) = *(undefined8 *)(param_2 + 0x10);
  *(undefined4 *)(this + 0x20) = *(undefined4 *)(param_2 + 0x18);
  *(undefined4 *)(this + 0x24) = *(undefined4 *)(param_2 + 0x1c);
  local_res18[0] = param_3;
  DVar1 = GetTickCount();
  *(undefined4 *)(this + 4) = 0xffffffff;
  *(DWORD *)(this + 0x34) = DVar1;
  *(undefined4 *)(this + 0x38) = *(undefined4 *)(param_2 + 0x20);
  *(undefined4 *)this = 0;
  *(undefined8 *)(this + 0x60) = 0;
  *(undefined8 *)(this + 0x40) = 0;
  *(undefined8 *)(this + 0x48) = 0;
  local_res18[0] = 0;
  *(undefined8 *)(this + 0x50) = 0;
  *(undefined8 *)(this + 0x58) = 0;
  iVar2 = Ordinal_10(local_res18);
  if (-1 < iVar2) {
    iVar2 = Ordinal_9(this);
    if (-1 < iVar2) {
      *(undefined8 *)(this + 0x60) = local_res18[0];
    }
  }
  if (*(longlong *)(this + 0x60) != 0) {
    iVar3 = *(int *)(*(longlong *)(this + 0x60) + 0x30) + 1;
  }
  *(int *)(this + 0x30) = iVar3;
  uVar4 = 0xa0;
  if (*(int *)(this + 0x38) != 0xff) {
    uVar4 = *(ulong *)(this + 0x38);
  }
  _TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z(this,(ushort *)L"ENTER",uVar4,(ushort *)0x0);
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(param_2);
  return this;
}


