/*
 * Function : ?default_error_condition@_System_error_category@std@@UEBA?AVerror_condition@2@H@Z
 * Address  : 0x140002460
 * Size     : 63 bytes (18 instructions)
 * Prototype: error_condition ?default_error_condition@_System_error_category@std@@UEBA?AVerror_condition@2@H@Z(_System_error_category * this, int param_1)
 * CC       : __thiscall
 * Comment  : public: virtual class std::error_condition __cdecl std::_System_error_category::default_error_condition(int)const __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual class std::error_condition __cdecl
   std::_System_error_category::default_error_condition(int)const __ptr64 */

int * __thiscall
std::_System_error_category::
_default_error_condition__System_error_category_std__UEBA_AVerror_condition_2_H_Z
          (_System_error_category *this,int param_1)

{
  int *piVar1;
  char *pcVar2;
  undefined **ppuVar3;
  undefined4 in_register_00000014;
  int in_R8D;
  
  piVar1 = (int *)CONCAT44(in_register_00000014,param_1);
  pcVar2 = __Syserror_map_std__YAPEBDH_Z(in_R8D);
  *piVar1 = in_R8D;
  ppuVar3 = &_Error_objects<int>::_Generic_object;
  if (pcVar2 == (char *)0x0) {
    ppuVar3 = &_Error_objects<int>::_System_object;
  }
  *(undefined ***)(piVar1 + 2) = ppuVar3;
  return piVar1;
}


