/*
 * Function : ?_Xlen@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEBAXXZ
 * Address  : 0x140002218
 * Size     : 16 bytes (3 instructions)
 * Prototype: void ?_Xlen@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEBAXXZ(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this)
 * CC       : __thiscall
 * Comment  : public: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char> >::_Xlen(void)const __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char> >::_Xlen(void)const __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
__Xlen___basic_string_DU__char_traits_D_std__V__allocator_D_2__std__QEBAXXZ
          (basic_string<char,std::char_traits<char>,std::allocator<char>_> *this)

{
                    /* WARNING: Subroutine does not return */
  __Xlength_error_std__YAXPEBD_Z("string too long");
}


