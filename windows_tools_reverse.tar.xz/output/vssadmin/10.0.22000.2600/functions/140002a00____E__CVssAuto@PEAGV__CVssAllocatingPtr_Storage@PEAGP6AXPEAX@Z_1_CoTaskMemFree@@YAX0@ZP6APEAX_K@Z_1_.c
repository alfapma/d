/*
 * Function : ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z
 * Address  : 0x140002a00
 * Size     : 89 bytes (24 instructions)
 * Prototype: void * ??_E?$CVssAuto@PEAGV?$CVssAllocatingPtr_Storage@PEAGP6AXPEAX@Z$1?CoTaskMemFree@@YAX0@ZP6APEAX_K@Z$1?CoTaskMemAlloc@@YAPEAX1@Z@@@@UEAAPEAXI@Z(CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_> * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl CVssAuto<unsigned short * __ptr64,class CVssAllocatingPtr_Storage<unsigned short * __ptr64,void (__cdecl*)(void * __ptr64),&void __cdecl CoTaskMemFree(void * __ptr64),void * __ptr64 (__cdecl*)(unsigned __int64),&void * __ptr64 __cdecl CoTaskMemAlloc(unsigned __int64)> >::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void * __ptr64 __cdecl CVssAuto<unsigned short * __ptr64,class
   CVssAllocatingPtr_Storage<unsigned short * __ptr64,void (__cdecl*)(void * __ptr64),&void __cdecl
   CoTaskMemFree(void * __ptr64),void * __ptr64 (__cdecl*)(unsigned __int64),&void * __ptr64 __cdecl
   CoTaskMemAlloc(unsigned __int64)> >::`vector deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_>
::
___E__CVssAuto_PEAGV__CVssAllocatingPtr_Storage_PEAGP6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6APEAX_K_Z_1_CoTaskMemAlloc__YAPEAX1_Z____UEAAPEAXI_Z
          (CVssAuto<unsigned_short*___ptr64,CVssAllocatingPtr_Storage<unsigned_short*___ptr64,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),void*___ptr64_(__cdecl*)(unsigned___int64),&void*___ptr64___cdecl_CoTaskMemAlloc(unsigned___int64)>_>
           *this,uint param_1)

{
  *(undefined ***)this = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
  if (*(LPVOID *)(this + 8) != (LPVOID)0x0) {
    CoTaskMemFree(*(LPVOID *)(this + 8));
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


