/*
 * Function : ??1CComBSTR@ATL@@QEAA@XZ
 * Address  : 0x140005da0
 * Size     : 10 bytes (2 instructions)
 * Prototype: void ??1CComBSTR@ATL@@QEAA@XZ(CComBSTR * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl ATL::CComBSTR::~CComBSTR(void) __ptr64 */

void __thiscall ATL::CComBSTR::__1CComBSTR_ATL__QEAA_XZ(CComBSTR *this)

{
                    /* WARNING: Could not recover jumptable at 0x000140005da3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  Ordinal_6(*(undefined8 *)this);
  return;
}


