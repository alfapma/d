/*
 * Function : ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z
 * Address  : 0x140010f3c
 * Size     : 33 bytes (9 instructions)
 * Prototype: CVssDebugInfo ??RCVssDebugInfo@@QEAA?AU0@W4_VSSDBG_SEV_ENUM@@@Z(CVssDebugInfo * this, _VSSDBG_SEV_ENUM param_1)
 * CC       : __thiscall
 * Comment  : public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator()(enum _VSSDBG_SEV_ENUM) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: struct CVssDebugInfo __cdecl CVssDebugInfo::operator()(enum _VSSDBG_SEV_ENUM) __ptr64 */

CVssDebugInfo * __thiscall
CVssDebugInfo::__RCVssDebugInfo__QEAA_AU0_W4_VSSDBG_SEV_ENUM___Z
          (CVssDebugInfo *this,_VSSDBG_SEV_ENUM param_1)

{
  undefined4 in_register_00000014;
  CVssDebugInfo *this_00;
  
  this_00 = (CVssDebugInfo *)CONCAT44(in_register_00000014,param_1);
  *(undefined4 *)(this + 0x20) = 100;
  __0CVssDebugInfo__QEAA_AEBU0__Z(this_00,this);
  return this_00;
}


