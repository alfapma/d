/*
 * Function : ??BCVssAutoCoString@@QEBAPEAGXZ
 * Address  : 0x140010f30
 * Size     : 4 bytes (2 instructions)
 * Prototype: ushort * ??BCVssAutoCoString@@QEBAPEAGXZ(CVssAutoCoString * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl CVssAutoCoString::operator unsigned short * __ptr64(void)const __ptr64 */

ushort * __thiscall CVssAutoCoString::__BCVssAutoCoString__QEBAPEAGXZ(CVssAutoCoString *this)

{
  return *(ushort **)this;
}


