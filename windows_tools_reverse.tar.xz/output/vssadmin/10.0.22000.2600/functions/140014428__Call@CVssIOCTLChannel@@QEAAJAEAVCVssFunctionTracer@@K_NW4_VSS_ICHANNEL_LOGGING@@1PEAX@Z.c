/*
 * Function : ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z
 * Address  : 0x140014428
 * Size     : 1040 bytes (238 instructions)
 * Prototype: long ?Call@CVssIOCTLChannel@@QEAAJAEAVCVssFunctionTracer@@K_NW4_VSS_ICHANNEL_LOGGING@@1PEAX@Z(CVssIOCTLChannel * this, CVssFunctionTracer * param_1, ulong param_2, bool param_3, _VSS_ICHANNEL_LOGGING param_4, bool param_5, void * param_6)
 * CC       : __thiscall
 * Comment  : public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: long __cdecl CVssIOCTLChannel::Call(class CVssFunctionTracer & __ptr64,unsigned
   long,bool,enum _VSS_ICHANNEL_LOGGING,bool,void * __ptr64) __ptr64 */

long __thiscall
CVssIOCTLChannel::
_Call_CVssIOCTLChannel__QEAAJAEAVCVssFunctionTracer__K_NW4_VSS_ICHANNEL_LOGGING__1PEAX_Z
          (CVssIOCTLChannel *this,CVssFunctionTracer *param_1,ulong param_2,bool param_3,
          _VSS_ICHANNEL_LOGGING param_4,bool param_5,void *param_6)

{
  CVssIOCTLChannel *lpBytesReturned;
  BOOL BVar1;
  DWORD DVar2;
  void *pvVar3;
  ushort *puVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  size_t _NewSize;
  uint local_res20;
  LPVOID lpOutBuffer;
  undefined4 uVar7;
  _VSSDBG_SEV_ENUM _Var8;
  CVssIOCTLChannel *in_stack_ffffffffffffff08;
  undefined4 uVar9;
  wchar_t *local_e8;
  wchar_t *local_e0;
  wchar_t *local_d8;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined4 local_c8;
  undefined1 local_c0 [120];
  undefined4 local_48;
  
  _Var8 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
  _NewSize = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  if (*(longlong *)this == 0) {
    _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
    uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x17d,10,_Var8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_TranslateGenericError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBGZZ
              (param_1,uVar6,0x8000ffff,L"Channel not open");
  }
  if (this[0x29] != (CVssIOCTLChannel)0x0) {
    uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                       (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x182,10,_Var8);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (param_1,uVar6,0x80070057,L"previous IOCTL hasn\'t yet completed");
  }
  local_res20 = *(uint *)(this + 0x44);
  *(undefined4 *)(this + 0x40) = 0;
  *(undefined4 *)(this + 0x48) = 0;
  do {
    _Var8 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    if (((uint)_NewSize == 0) && (local_res20 == 0)) {
      _NewSize = 0x1000;
LAB_1400144a4:
      local_res20 = (uint)_NewSize;
      pvVar3 = realloc(*(void **)(this + 0x50),_NewSize);
      if (pvVar3 == (void *)0x0) {
        _ResetOffsets_CVssIOCTLChannel__QEAAXXZ(this);
        uVar6 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_e8,
                           (ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",(ushort *)L"INCICHLH",
                           (ushort *)L"CVssIOCTLChannel::Call",0x1ba,10,_Var8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (param_1,uVar6,0x8007000e,L"Could not extend the output buffer");
      }
      *(void **)(this + 0x50) = pvVar3;
      *(uint *)(this + 0x44) = local_res20;
    }
    else if (local_res20 < (uint)_NewSize) goto LAB_1400144a4;
    uVar7 = *(undefined4 *)(this + 0x2c);
    uVar6 = *(undefined8 *)(this + 0x68);
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c3;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (param_1,&local_e8,
               L"IOCTL sent: %lx on device %s\n Input buffer size: %ld, Output buffer size: %ld",
               0x534058,uVar6,uVar7,local_res20);
    local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
    local_e0 = L"CVssIOCTLChannel::Call";
    local_d8 = L"INCICHLH";
    local_d0 = 0x1c5;
    local_cc = 10;
    local_c8 = 0xff;
    local_48 = 0x1000000;
    memset(local_c0,0,0x78);
    CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
              (param_1,&local_e8,*(undefined4 *)(this + 0x2c),*(undefined8 *)(this + 0x38));
    uVar9 = 0;
    lpBytesReturned = this + 0x48;
    lpOutBuffer = *(LPVOID *)(this + 0x50);
    in_stack_ffffffffffffff08 = lpBytesReturned;
    BVar1 = DeviceIoControl(*(HANDLE *)this,0x534058,*(LPVOID *)(this + 0x38),
                            *(DWORD *)(this + 0x2c),lpOutBuffer,*(DWORD *)(this + 0x44),
                            (LPDWORD)lpBytesReturned,(LPOVERLAPPED)0x0);
    _Var8 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
    uVar7 = (undefined4)((ulonglong)lpOutBuffer >> 0x20);
    if (BVar1 != 0) {
LAB_1400145f9:
      DVar2 = GetLastError();
      uVar6 = *(undefined8 *)this;
      *(undefined4 *)(this + 0x2c) = 0;
      *(undefined4 *)(this + 0x40) = 0;
      if (BVar1 != 0) {
        DVar2 = *(DWORD *)lpBytesReturned;
        uVar5 = *(undefined8 *)(this + 0x68);
        local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
        local_e0 = L"CVssIOCTLChannel::Call";
        local_d8 = L"INCICHLH";
        local_d0 = 0x225;
        local_cc = 10;
        local_c8 = 0xff;
        local_48 = 0x1000000;
        memset(local_c0,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (param_1,&local_e8,
                   L"IOCTL %lx succeeded on device %s - 0x%08lx. \n Output buffer: size received = %ld"
                   ,0x534058,uVar5,uVar6,DVar2);
        local_e8 = L"base\\stor\\vss\\inc\\ichannel.hxx";
        local_e0 = L"CVssIOCTLChannel::Call";
        local_d8 = L"INCICHLH";
        local_d0 = 0x227;
        local_cc = 10;
        local_c8 = 0xff;
        local_48 = 0x1000000;
        memset(local_c0,0,0x78);
        CVssFunctionTracer::_TraceBuffer_CVssFunctionTracer__QEAAXUCVssDebugInfo__KPEAE_Z
                  (param_1,&local_e8,*(undefined4 *)(this + 0x48),*(undefined8 *)(this + 0x50));
        *(undefined4 *)(param_1 + 8) = 0;
        return 0;
      }
      puVar4 = CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
               ::
               _Get___CVssAutoGenericValue_Storage_PEAG_0A_P6AXPEAX_Z_1_CoTaskMemFree__YAX0_ZP6AAEAPEAGAEAPEAG_Z_1_Identity___DTyper_PEAG__SAAEAPEAG1_Z__QEBAPEAGXZ
                         ((CVssAutoGenericValue_Storage<unsigned_short*___ptr64,0,void_(__cdecl*)(void*___ptr64),&void___cdecl_CoTaskMemFree(void*___ptr64),unsigned_short*___ptr64&___ptr64_(__cdecl*)(unsigned_short*___ptr64&___ptr64),&public:_static_unsigned_short*___ptr64&___ptr64___cdecl_DTyper<unsigned_short*___ptr64>::Identity(unsigned_short*___ptr64&___ptr64)>
                           *)(this + 0x60));
      uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_e8,(ushort *)L"base\\stor\\vss\\inc\\ichannel.hxx",
                         (ushort *)L"INCICHLH",(ushort *)L"CVssIOCTLChannel::Call",0x1ea,10,_Var8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (param_1,uVar5,0x8000ffff,
                 L"Could not send the IOCTL 0x%08lx on device %s - 0x%08lx. [0x%08lx]\n",
                 CONCAT44(uVar7,0x534058),puVar4,uVar6,CONCAT44(uVar9,DVar2));
    }
    DVar2 = GetLastError();
    if (DVar2 != 0x7a) {
      DVar2 = GetLastError();
      _Var8 = (_VSSDBG_SEV_ENUM)in_stack_ffffffffffffff08;
      if (DVar2 != 0xea) goto LAB_1400145f9;
    }
    local_res20 = *(uint *)(this + 0x44);
    _NewSize = (size_t)(local_res20 * 2);
  } while( true );
}


