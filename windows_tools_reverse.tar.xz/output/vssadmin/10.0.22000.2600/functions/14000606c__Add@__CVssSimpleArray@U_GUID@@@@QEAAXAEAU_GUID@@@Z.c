/*
 * Function : ?Add@?$CVssSimpleArray@U_GUID@@@@QEAAXAEAU_GUID@@@Z
 * Address  : 0x14000606c
 * Size     : 177 bytes (50 instructions)
 * Prototype: void ?Add@?$CVssSimpleArray@U_GUID@@@@QEAAXAEAU_GUID@@@Z(CVssSimpleArray<_GUID> * this, _GUID * param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssSimpleArray<struct _GUID>::Add(struct _GUID & __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssSimpleArray<struct _GUID>::Add(struct _GUID & __ptr64) __ptr64 */

void __thiscall
CVssSimpleArray<_GUID>::_Add___CVssSimpleArray_U_GUID____QEAAXAEAU_GUID___Z
          (CVssSimpleArray<_GUID> *this,_GUID *param_1)

{
  int iVar1;
  undefined8 uVar2;
  void *pvVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined4 local_res8 [2];
  
  iVar1 = *(int *)(this + 8);
  if (0 < iVar1 + 1) {
    if (iVar1 != *(int *)(this + 0xc)) {
LAB_1400060da:
      *(int *)(this + 8) = iVar1 + 1;
      puVar4 = (undefined8 *)((longlong)iVar1 * 0x10 + *(longlong *)this);
      if (puVar4 != (undefined8 *)0x0) {
        uVar2 = *(undefined8 *)param_1->Data4;
        *puVar4 = *(undefined8 *)param_1;
        puVar4[1] = uVar2;
      }
      return;
    }
    if ((iVar1 < 0x40000000) && ((ulonglong)(longlong)iVar1 < 0x800000000000000)) {
      iVar5 = 1;
      if (*(int *)(this + 0xc) != 0) {
        iVar5 = iVar1 * 2;
      }
      pvVar3 = realloc(*(void **)this,(longlong)iVar5 << 4);
      if (pvVar3 != (void *)0x0) {
        *(int *)(this + 0xc) = iVar5;
        *(void **)this = pvVar3;
        goto LAB_1400060da;
      }
    }
  }
  local_res8[0] = 0x8007000e;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_res8,(ThrowInfo *)&_TI1J);
}


