/*
 * Function : ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z
 * Address  : 0x140007e50
 * Size     : 485 bytes (114 instructions)
 * Prototype: ushort * ?DetermineSnapshotType@CVssAdminCLI@@AEAAPEAGJ@Z(CVssAdminCLI * this, long param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short * __ptr64 __cdecl CVssAdminCLI::DetermineSnapshotType(long) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: unsigned short * __ptr64 __cdecl CVssAdminCLI::DetermineSnapshotType(long) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_DetermineSnapshotType_CVssAdminCLI__AEAAPEAGJ_Z(CVssAdminCLI *this,long param_1)

{
  DWORD DVar1;
  ulonglong uVar2;
  ushort *puVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  uint uVar6;
  ushort *local_res18 [2];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  ulonglong uVar7;
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::DetermineSnapshotType";
  local_138 = L"ADMPROCC";
  local_130 = 0x853;
  local_12c = 7;
  local_128 = 0xff;
  uVar2 = 0;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98);
  local_res18[0] = (ushort *)0x0;
  uVar6 = 0;
  if (true) {
    uVar5 = uVar2;
    uVar7 = uVar2;
    do {
      uVar6 = (uint)uVar7;
      if (*(uint *)((longlong)&DAT_140017c2c + uVar2) == (param_1 & 0x1fU)) break;
      uVar6 = uVar6 + 1;
      uVar7 = (ulonglong)uVar6;
      uVar5 = uVar5 + 1;
      uVar2 = uVar5 * 0x18;
    } while ((&g_asAdmTypeNames)[uVar5 * 3] != (undefined *)0x0);
  }
  if ((ushort *)(&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3] == (ushort *)0x0) {
    local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
    local_140 = L"CVssAdminCLI::DetermineSnapshotType";
    local_138 = L"ADMPROCC";
    local_130 = 0x863;
    local_12c = 7;
    local_128 = 0xff;
    local_a8 = 0x1000000;
    memset(local_120,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_98,&local_148,
               L"DetermineSnapshotType: Invalid context in lSnapshotAttributes: 0x%08x",param_1);
    puVar3 = _GetMsg_CVssAdminCLI__AEAAPEAGHJZZ(this,0,0x40002713);
    if (puVar3 == (ushort *)0x0) {
      DVar1 = GetLastError();
      uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_148,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DetermineSnapshotType",
                         0x868,7,in_stack_fffffffffffffea8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_98,uVar4,0x8000ffff,L"Error on loading the message string id %d. 0x%08lx",
                 0x40002713,DVar1);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    local_res18[0] = puVar3;
  }
  else {
    VssSafeDuplicateStr(local_98,local_res18,(ushort *)(&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3]
                       );
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  }
  return local_res18[0];
}


