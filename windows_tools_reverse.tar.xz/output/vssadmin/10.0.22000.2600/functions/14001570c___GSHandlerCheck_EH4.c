/*
 * Function : __GSHandlerCheck_EH4
 * Address  : 0x14001570c
 * Size     : 127 bytes (37 instructions)
 * Prototype: undefined __GSHandlerCheck_EH4(longlong param_1, undefined8 param_2, undefined8 param_3, longlong param_4)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void __GSHandlerCheck_EH4(longlong param_1,undefined8 param_2,undefined8 param_3,longlong param_4)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_4 + 0x38);
  __GSHandlerCheckCommon(param_2,param_4);
  if ((*(uint *)(lVar1 + 4) & ((*(uint *)(param_1 + 4) & 0x66) != 0) + 1) != 0) {
    __CxxFrameHandler4(param_1,param_2,param_3,param_4);
  }
  return;
}


