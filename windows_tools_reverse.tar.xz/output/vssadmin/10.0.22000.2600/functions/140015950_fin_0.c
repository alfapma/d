/*
 * Function : fin$0
 * Address  : 0x140015950
 * Size     : 43 bytes (14 instructions)
 * Prototype: undefined fin$0(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void ``eh_vector_constructor_iterator''::__l1::fin_0(undefined8 param_1,longlong param_2)

{
  if (*(int *)(param_2 + 0x24) == 0) {
    __ArrayUnwind(*(void **)(param_2 + 0x50),*(__uint64 *)(param_2 + 0x58),*(int *)(param_2 + 0x20),
                  *(_func_void_void_ptr **)(param_2 + 0x70));
  }
  return;
}


