/*
 * Function : dtor$12
 * Address  : 0x1400160cc
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$12(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::ListDiffAreas'::__l1::dtor_12(undefined8 param_1,longlong param_2)

{
  ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
            ((CComPtr<IVssEnumObject> *)(param_2 + 0x68));
  return;
}


