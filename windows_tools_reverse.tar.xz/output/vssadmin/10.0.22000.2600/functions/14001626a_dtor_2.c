/*
 * Function : dtor$2
 * Address  : 0x14001626a
 * Size     : 45 bytes (11 instructions)
 * Prototype: undefined dtor$2(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssFunctionTracer::GetCurrentContexts'::__l1::dtor_2(undefined8 param_1,longlong param_2)

{
  _eh_vector_destructor_iterator_
            ((void *)(param_2 + 0x80),0x20,4,
             std::
             basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
             ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2__std__QEAA_XZ);
  return;
}


