/*
 * Function : ??_Eerror_category@std@@UEAAPEAXI@Z
 * Address  : 0x140002090
 * Size     : 46 bytes (16 instructions)
 * Prototype: void * ??_Eerror_category@std@@UEAAPEAXI@Z(error_category * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl std::error_category::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void * __ptr64 __cdecl std::error_category::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
std::error_category::___Eerror_category_std__UEAAPEAXI_Z(error_category *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


