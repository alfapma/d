/*
 * Function : pre_cpp_init
 * Address  : 0x140001470
 * Size     : 73 bytes (13 instructions)
 * Prototype: undefined pre_cpp_init(void)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void pre_cpp_init(void)

{
  _DAT_1400241a4 = _newmode;
  _DAT_14002418c =
       __wgetmainargs(&DAT_140024188,&DAT_140024190,&DAT_140024198,_dowildcard,&DAT_1400241a4);
  return;
}


