/*
 * Function : dtor$1
 * Address  : 0x14001602a
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::DumpSnapshotTypes'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ((CVssFunctionTracer *)(param_2 + 0xd0));
  return;
}


