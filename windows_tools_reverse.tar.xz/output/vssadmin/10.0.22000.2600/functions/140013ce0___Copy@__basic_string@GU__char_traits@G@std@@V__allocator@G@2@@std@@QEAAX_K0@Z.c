/*
 * Function : ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAAX_K0@Z
 * Address  : 0x140013ce0
 * Size     : 246 bytes (75 instructions)
 * Prototype: void ?_Copy@?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAAX_K0@Z(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : public: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short> >::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short> >::_Copy(unsigned __int64,unsigned __int64) __ptr64
    */

void __thiscall
std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>::
__Copy___basic_string_GU__char_traits_G_std__V__allocator_G_2__std__QEAAX_K0_Z
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
           *this,__uint64 param_1,__uint64 param_2)

{
  ulonglong uVar1;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
  *_Dst;
  ulonglong uVar2;
  basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
  *pbVar3;
  ulonglong uVar4;
  
  uVar4 = param_1 | 7;
  if (uVar4 < 0x7fffffffffffffff) {
    uVar1 = *(ulonglong *)(this + 0x18);
    uVar2 = uVar1 >> 1;
    param_1 = uVar4;
    if ((uVar4 / 3 < uVar2) && (param_1 = uVar2 + uVar1, 0x7ffffffffffffffe - uVar2 < uVar1)) {
      param_1 = 0x7ffffffffffffffe;
    }
  }
  uVar4 = param_1 + 1;
  _Dst = (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
          *)0x0;
  if ((uVar4 != 0) &&
     ((0x7fffffffffffffff < uVar4 ||
      (_Dst = operator_new(uVar4 * 2),
      _Dst == (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
               *)0x0)))) {
                    /* WARNING: Subroutine does not return */
    __Xbad_alloc_std__YAXXZ();
  }
  if (param_2 != 0) {
    pbVar3 = this;
    if (7 < *(ulonglong *)(this + 0x18)) {
      pbVar3 = *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
                 **)this;
    }
    memcpy(_Dst,pbVar3,param_2 * 2);
  }
  if (7 < *(ulonglong *)(this + 0x18)) {
    operator_delete__(*(void **)this);
  }
  *(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> **
   )this = _Dst;
  *(__uint64 *)(this + 0x18) = param_1;
  pbVar3 = this;
  if (7 < param_1) {
    pbVar3 = _Dst;
  }
  *(__uint64 *)(this + 0x10) = param_2;
  *(undefined2 *)(pbVar3 + param_2 * 2) = 0;
  return;
}


