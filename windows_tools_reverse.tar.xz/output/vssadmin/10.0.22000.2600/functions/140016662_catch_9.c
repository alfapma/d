/*
 * Function : catch$9
 * Address  : 0x140016662
 * Size     : 93 bytes (19 instructions)
 * Prototype: undefined8 catch$9(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined8
`CVssMachineInformation::GetMinDiffAreaForSystem'::__l1::catch_9
          (undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x100),*(_com_error **)(param_2 + 0x170),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e7,
             *(ulong *)(param_2 + 0x124));
  return 0;
}


