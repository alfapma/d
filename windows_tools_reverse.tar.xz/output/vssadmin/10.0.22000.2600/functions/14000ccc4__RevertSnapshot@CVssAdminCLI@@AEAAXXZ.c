/*
 * Function : ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x14000ccc4
 * Size     : 1593 bytes (351 instructions)
 * Prototype: void ?RevertSnapshot@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: _guard_xfg_dispatch_icall_nop replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::RevertSnapshot(void) __ptr64 */

void __thiscall CVssAdminCLI::_RevertSnapshot_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  longlong *plVar1;
  code *pcVar2;
  uchar auVar3 [8];
  bool bVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  ushort *puVar8;
  undefined8 uVar9;
  CVssAdminCLI *pCVar10;
  undefined1 auStackY_258 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffdd8;
  _VSSDBG_SEV_ENUM _Var11;
  char local_218 [8];
  CVssAdminCLI *local_210;
  _GUID local_208;
  _GUID local_1f8;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  wchar_t *local_1d8;
  undefined4 local_1d0;
  undefined4 local_1cc;
  undefined4 local_1c8;
  undefined1 local_1c0 [120];
  undefined4 local_148;
  CVssFunctionTracer local_138 [8];
  int local_130;
  _GUID local_c8;
  undefined1 local_b8 [48];
  ushort *local_88;
  ulonglong local_38;
  
  local_38 = __security_cookie ^ (ulonglong)auStackY_258;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1e0 = L"CVssAdminCLI::RevertSnapshot";
  local_1d8 = L"ADMPROCC";
  local_1d0 = 0x54d;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_138,&local_1e8);
  iVar5 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,4);
  local_c8.Data1 = 0;
  local_c8.Data2 = 0;
  local_c8.Data3 = 0;
  local_c8.Data4[0] = '\0';
  local_c8.Data4[1] = '\0';
  local_c8.Data4[2] = '\0';
  local_c8.Data4[3] = '\0';
  local_c8.Data4[4] = '\0';
  local_c8.Data4[5] = '\0';
  local_c8.Data4[6] = '\0';
  local_c8.Data4[7] = '\0';
  puVar8 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar8 != (ushort *)0x0) {
    pCVar10 = this;
    puVar8 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar4 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(pCVar10,puVar8,&local_c8);
    if (!bVar4) {
      uVar9 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_1e8,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x556,7,
                         in_stack_fffffffffffffdd8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_138,uVar9,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  uVar6 = dCurrentSKU & 0xfffffff8;
  plVar1 = *(longlong **)this;
  pcVar2 = *(code **)(*plVar1 + 0x38);
  iVar7 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  auVar3 = local_c8.Data4;
  local_208.Data4[0] = local_c8.Data4[0];
  local_208.Data4[1] = local_c8.Data4[1];
  local_208.Data4[2] = local_c8.Data4[2];
  local_208.Data4[3] = local_c8.Data4[3];
  local_208.Data1 = local_c8.Data1;
  local_208.Data2 = local_c8.Data2;
  local_208.Data3 = local_c8.Data3;
  local_208.Data4[4] = local_c8.Data4[4];
  local_208.Data4[5] = local_c8.Data4[5];
  local_208.Data4[6] = local_c8.Data4[6];
  local_208.Data4[7] = local_c8.Data4[7];
  local_c8.Data4 = auVar3;
  (*pcVar2)(plVar1,&local_208,iVar5 == 1,iVar7 == 1);
  local_210 = (CVssAdminCLI *)0x0;
  local_1e8 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_1e0 = L"CVssAdminCLI::RevertSnapshot";
  local_1d8 = L"ADMPROCC";
  local_1d0 = 0x565;
  local_1cc = 7;
  local_1c8 = 0xff;
  local_148 = 0x1000000;
  memset(local_1c0,0,0x78);
  local_208 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_1f8 = (_GUID)_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  _Var11 = (_VSSDBG_SEV_ENUM)&local_210;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_138,&local_1e8,&local_1f8,L"Coordinator");
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1e8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::RevertSnapshot",0x56c,7,_Var11);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_130 = (**(code **)(*(longlong *)local_210 + 0x18))
                        (local_210,(-(uint)(uVar6 != 0) & 0xffffffe2) + 0x1d);
  auVar3 = local_c8.Data4;
  if (local_130 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1e8,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::RevertSnapshot",0x570,7,_Var11);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
  }
  local_1f8.Data4[0] = local_c8.Data4[0];
  local_1f8.Data4[1] = local_c8.Data4[1];
  local_1f8.Data4[2] = local_c8.Data4[2];
  local_1f8.Data4[3] = local_c8.Data4[3];
  local_1f8.Data1 = local_c8.Data1;
  local_1f8.Data2 = local_c8.Data2;
  local_1f8.Data3 = local_c8.Data3;
  local_1f8.Data4[4] = local_c8.Data4[4];
  local_1f8.Data4[5] = local_c8.Data4[5];
  local_1f8.Data4[6] = local_c8.Data4[6];
  local_1f8.Data4[7] = local_c8.Data4[7];
  local_c8.Data4 = auVar3;
  local_130 = (**(code **)(*(longlong *)local_210 + 0x38))(local_210,&local_1f8);
  local_1f8.Data4 = (uchar  [8])local_b8;
  local_1f8._0_8_ =
       &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
        ::_vftable_;
  if (local_130 < 0) {
    if (local_130 != -0x7ffbdcf8) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1e8,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
                 (ushort *)L"CVssAdminCLI::RevertSnapshot",0x57e,7,_Var11);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
    }
    puVar8 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar8);
    VssFreeSnapshotPropertiesInternal(local_b8);
  }
  else {
    iVar7 = _PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z(this,0x40002776,0);
    if (iVar7 == 0) {
      VssFreeSnapshotPropertiesInternal(local_b8);
    }
    else {
      local_218[0] = '\0';
      local_130 = ShouldBlockRevertInternal(local_88,local_218);
      auVar3 = local_c8.Data4;
      if ((local_130 < 0) || (local_218[0] == '\0')) {
        local_208.Data4[0] = local_c8.Data4[0];
        local_208.Data4[1] = local_c8.Data4[1];
        local_208.Data4[2] = local_c8.Data4[2];
        local_208.Data4[3] = local_c8.Data4[3];
        local_208.Data1 = local_c8.Data1;
        local_208.Data2 = local_c8.Data2;
        local_208.Data3 = local_c8.Data3;
        local_208.Data4[4] = local_c8.Data4[4];
        local_208.Data4[5] = local_c8.Data4[5];
        local_208.Data4[6] = local_c8.Data4[6];
        local_208.Data4[7] = local_c8.Data4[7];
        pCVar10 = local_210;
        local_c8.Data4 = auVar3;
        local_130 = (**(code **)(*(longlong *)local_210 + 0x68))(local_210,&local_208,iVar5);
        if (-1 < local_130) {
          _WaitForRevertCompletion_CVssAdminCLI__AEAAXPEAGPEAUIVssCoordinator___Z
                    (pCVar10,local_88,(IVssCoordinator *)local_210);
          _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002770);
          *(undefined4 *)(this + 0x48) = 0;
          VssFreeSnapshotPropertiesInternal(local_b8);
          if (local_210 != (CVssAdminCLI *)0x0) {
            (**(code **)(*(longlong *)local_210 + 0x10))();
          }
          goto LAB_14000d173;
        }
        if (local_130 == -0x7ffbdcf8) {
          puVar8 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275c,puVar8);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
        else if (local_130 == -0x7ffbdcf4) {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
        else if (local_130 == -0x7ffbdce3) {
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002775);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
        else {
          if (local_130 != -0x7ffbdcdb) {
            CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_1e8,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::RevertSnapshot",0x59f,7,
                       _Var11);
            CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_138);
                    /* WARNING: Subroutine does not return */
            CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_138);
          }
          _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002773);
          VssFreeSnapshotPropertiesInternal(local_b8);
        }
      }
      else {
        _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002774);
        VssFreeSnapshotPropertiesInternal(local_b8);
      }
    }
  }
  if (local_210 != (CVssAdminCLI *)0x0) {
    (**(code **)(*(longlong *)local_210 + 0x10))();
  }
LAB_14000d173:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_138);
  return;
}


