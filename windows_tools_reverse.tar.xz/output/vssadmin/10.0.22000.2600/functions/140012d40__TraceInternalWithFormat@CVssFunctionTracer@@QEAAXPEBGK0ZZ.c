/*
 * Function : ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ
 * Address  : 0x140012d40
 * Size     : 196 bytes (51 instructions)
 * Prototype: void ?TraceInternalWithFormat@CVssFunctionTracer@@QEAAXPEBGK0ZZ(CVssFunctionTracer * this, ushort * param_1, ulong param_2, ushort * param_3, ...)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(unsigned short const * __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssFunctionTracer::TraceInternalWithFormat(unsigned short const *
   __ptr64,unsigned long,unsigned short const * __ptr64,...) __ptr64 */

void __thiscall
CVssFunctionTracer::_TraceInternalWithFormat_CVssFunctionTracer__QEAAXPEBGK0ZZ
          (CVssFunctionTracer *this,ushort *param_1,ulong param_2,ushort *param_3,...)

{
  int iVar1;
  wchar_t *pwVar2;
  wchar_t *pwVar3;
  ulong in_stack_ffffffffffffffa8;
  __uint64 local_38;
  ushort *local_30 [2];
  
  iVar1 = _IsTracingEnabled_CVssFunctionTracer__QEAAHK_Z(this,*(ulong *)(this + 0x24));
  if (iVar1 != 0) {
    pwVar2 = operator_new__(0x3ea,&std::nothrow);
    if (pwVar2 == (wchar_t *)0x0) {
      pwVar3 = L"TraceInternalWithFormat failed due to out of memory condition";
    }
    else {
      local_38 = 0;
      local_30[0] = (ushort *)0x0;
      StringCchVPrintfExW((ushort *)pwVar2,500,local_30,&local_38,in_stack_ffffffffffffffa8,param_3,
                          &stack0x00000028);
      pwVar3 = pwVar2;
      if (local_38 == 1) {
        local_30[0][-2] = 0x2e;
        local_30[0][-1] = 0x2e;
        local_30[0][-3] = 0x2e;
      }
    }
    _TraceInternal_CVssFunctionTracer__QEAAXPEBGK0_Z(this,param_1,param_2,(ushort *)pwVar3);
    operator_delete__(pwVar2);
  }
  return;
}


