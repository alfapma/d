/*
 * Function : ?SetHr@CVssFunctionTracer@@QEAAXJ@Z
 * Address  : 0x140004cf8
 * Size     : 4 bytes (2 instructions)
 * Prototype: void ?SetHr@CVssFunctionTracer@@QEAAXJ@Z(CVssFunctionTracer * this, long param_1)
 * CC       : __thiscall
 * Comment  : public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl CVssFunctionTracer::SetHr(long) __ptr64 */

void __thiscall
CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(CVssFunctionTracer *this,long param_1)

{
  *(long *)(this + 8) = param_1;
  return;
}


