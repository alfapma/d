/*
 * Function : ??1length_error@std@@UEAA@XZ
 * Address  : 0x14000125c
 * Size     : 5 bytes (1 instructions)
 * Prototype: void ??1length_error@std@@UEAA@XZ(length_error * this)
 * CC       : __thiscall
 * Comment  : public: virtual __cdecl std::length_error::~length_error(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual __cdecl std::length_error::~length_error(void) __ptr64 */

void __thiscall std::length_error::__1length_error_std__UEAA_XZ(length_error *this)

{
                    /* WARNING: Could not recover jumptable at 0x000140001b45. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception::~exception((exception *)this);
  return;
}


