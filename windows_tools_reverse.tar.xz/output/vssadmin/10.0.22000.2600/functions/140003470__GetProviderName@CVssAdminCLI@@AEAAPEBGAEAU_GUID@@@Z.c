/*
 * Function : ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z
 * Address  : 0x140003470
 * Size     : 1355 bytes (303 instructions)
 * Prototype: ushort * ?GetProviderName@CVssAdminCLI@@AEAAPEBGAEAU_GUID@@@Z(CVssAdminCLI * this, _GUID * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID & __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: _guard_xfg_dispatch_icall_nop replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetProviderName(struct _GUID &
   __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetProviderName_CVssAdminCLI__AEAAPEBGAEAU_GUID___Z
          (CVssAdminCLI *this,_GUID *param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined1 auVar4 [16];
  undefined8 uVar5;
  int iVar6;
  void *pvVar7;
  undefined8 *puVar8;
  ushort *puVar9;
  undefined8 uVar10;
  longlong *plVar11;
  undefined1 auStackY_268 [32];
  _VSSDBG_SEV_ENUM _Var12;
  longlong **pplVar13;
  _GUID local_228;
  longlong *local_218;
  longlong *local_210;
  undefined1 local_208 [16];
  undefined1 local_1f8 [8];
  wchar_t *local_1f0;
  wchar_t *local_1e8;
  wchar_t *local_1e0;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined4 local_1d0;
  undefined1 local_1c8 [120];
  undefined4 local_150;
  CVssFunctionTracer local_148 [8];
  int local_140;
  undefined1 local_d8 [8];
  longlong local_d0;
  longlong local_c8;
  ushort *local_c0;
  LPVOID local_b0;
  ulonglong local_48;
  
  local_48 = __security_cookie ^ (ulonglong)auStackY_268;
  local_1f0 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e8 = L"CVssAdminCLI::GetProviderName";
  local_1e0 = L"ADMVADMC";
  local_1d8 = 0xfd;
  local_1d4 = 7;
  local_1d0 = 0xff;
  iVar6 = 0;
  local_150 = 0x1000000;
  memset(local_1c8,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_148);
  lVar2._0_4_ = param_1->Data1;
  lVar2._4_2_ = param_1->Data2;
  lVar2._6_2_ = param_1->Data3;
  local_228 = *param_1;
  if (0 < *(int *)(this + 0x38)) {
    do {
      plVar11 = (longlong *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
      if ((*plVar11 == lVar2) && (plVar11[1] == *(longlong *)param_1->Data4)) {
        if ((iVar6 != -1) &&
           (puVar9 = *(ushort **)(*(longlong *)(this + 0x30) + (longlong)iVar6 * 8),
           puVar9 != (ushort *)0x0)) goto LAB_140003888;
        break;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < *(int *)(this + 0x38));
  }
  local_210 = (longlong *)0x0;
  local_1f0 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp";
  local_1e8 = L"CVssAdminCLI::GetProviderName";
  local_1e0 = L"ADMVADMC";
  local_1d8 = 0x106;
  local_1d4 = 7;
  local_1d0 = 0xff;
  local_150 = 0x1000000;
  memset(local_1c8,0,0x78);
  local_228 = (_GUID)_GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_208 = (undefined1  [16])_GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  pplVar13 = &local_210;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_148,&local_1f0,local_208,L"Coordinator");
  if (local_140 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f0,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::GetProviderName",0x10d,7,(_VSSDBG_SEV_ENUM)pplVar13);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
  }
  local_218 = (longlong *)0x0;
  local_208 = ZEXT816(0);
  local_140 = (**(code **)(*local_210 + 0x50))(local_210,local_208,1);
  if (local_140 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_1f0,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
               (ushort *)L"CVssAdminCLI::GetProviderName",0x115,7,(_VSSDBG_SEV_ENUM)pplVar13);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
  }
  while( true ) {
    local_140 = (**(code **)(*local_218 + 0x18))(local_218,1,local_d8,local_1f8);
    if (local_140 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_1f0,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC"
                 ,(ushort *)L"CVssAdminCLI::GetProviderName",0x120,7,(_VSSDBG_SEV_ENUM)pplVar13);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_148);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_148);
    }
    if (local_140 == 1) break;
    CoTaskMemFree(local_b0);
    puVar9 = local_c0;
    _Var12 = (_VSSDBG_SEV_ENUM)pplVar13;
    local_b0 = (LPVOID)0x0;
    lVar1._0_4_ = param_1->Data1;
    lVar1._4_2_ = param_1->Data2;
    lVar1._6_2_ = param_1->Data3;
    if ((local_d0 == lVar1) && (local_c8 == *(longlong *)param_1->Data4)) {
      local_208._8_8_ = local_c0;
      local_208._0_8_ = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
      auVar4._8_8_ = 0;
      auVar4[0] = local_228.Data4[0];
      auVar4[1] = local_228.Data4[1];
      auVar4[2] = local_228.Data4[2];
      auVar4[3] = local_228.Data4[3];
      auVar4[4] = local_228.Data4[4];
      auVar4[5] = local_228.Data4[5];
      auVar4[6] = local_228.Data4[6];
      auVar4[7] = local_228.Data4[7];
      local_228 = (_GUID)(auVar4 << 0x40);
      VssSafeDuplicateStr(local_148,(ushort **)&local_228,local_c0);
      uVar5 = local_228._0_8_;
      uVar10 = *(undefined8 *)param_1;
      uVar3 = *(undefined8 *)param_1->Data4;
      pvVar7 = realloc(*(void **)(this + 0x28),(longlong)(*(int *)(this + 0x38) + 1) << 4);
      if (pvVar7 != (void *)0x0) {
        *(void **)(this + 0x28) = pvVar7;
        pvVar7 = realloc(*(void **)(this + 0x30),(longlong)(*(int *)(this + 0x38) + 1) << 3);
        if (pvVar7 != (void *)0x0) {
          *(void **)(this + 0x30) = pvVar7;
          iVar6 = *(int *)(this + 0x38);
          *(int *)(this + 0x38) = iVar6 + 1;
          puVar8 = (undefined8 *)((longlong)iVar6 * 0x10 + *(longlong *)(this + 0x28));
          if (puVar8 != (undefined8 *)0x0) {
            *puVar8 = uVar10;
            puVar8[1] = uVar3;
            pvVar7 = *(void **)(this + 0x30);
          }
          puVar8 = (undefined8 *)((longlong)pvVar7 + (longlong)iVar6 * 8);
          if (puVar8 != (undefined8 *)0x0) {
            *puVar8 = uVar5;
          }
          if (puVar9 != (ushort *)0x0) {
            CoTaskMemFree(puVar9);
          }
          if (local_218 != (longlong *)0x0) {
            (**(code **)(*local_218 + 0x10))();
          }
          if (local_210 != (longlong *)0x0) {
            (**(code **)(*local_210 + 0x10))();
          }
          CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
          return (ushort *)uVar5;
        }
      }
      VssFreeString((ushort **)&local_228);
      uVar10 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_1f0,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",
                          (ushort *)L"ADMVADMC",(ushort *)L"CVssAdminCLI::GetProviderName",0x142,1,
                          _Var12);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_148,uVar10,0x8007000e,L"Memory allocation error");
    }
    CoTaskMemFree(local_c0);
    local_c0 = (ushort *)0x0;
  }
  puVar9 = _LoadStringW_CVssAdminCLI__AEAAPEBGI_Z(this,0x66);
  if (local_218 != (longlong *)0x0) {
    (**(code **)(*local_218 + 0x10))();
  }
  if (local_210 != (longlong *)0x0) {
    (**(code **)(*local_210 + 0x10))();
  }
LAB_140003888:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_148);
                    /* WARNING: Read-only address (ram,0x00014001a4b0) is written */
                    /* WARNING: Read-only address (ram,0x00014001a4c0) is written */
  return puVar9;
}


