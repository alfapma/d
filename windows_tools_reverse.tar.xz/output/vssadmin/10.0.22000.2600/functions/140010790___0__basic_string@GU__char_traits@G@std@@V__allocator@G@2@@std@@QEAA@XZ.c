/*
 * Function : ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAA@XZ
 * Address  : 0x140010790
 * Size     : 29 bytes (11 instructions)
 * Prototype: undefined ??0?$basic_string@GU?$char_traits@G@std@@V?$allocator@G@2@@std@@QEAA@XZ(basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short> >::basic_string<unsigned short,struct std::char_traits<unsigned short>,class std::allocator<unsigned short> >(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl std::basic_string<unsigned short,struct std::char_traits<unsigned short>,class
   std::allocator<unsigned short> >::basic_string<unsigned short,struct std::char_traits<unsigned
   short>,class std::allocator<unsigned short> >(void) __ptr64 */

basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_> *
__thiscall
std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>::
__0__basic_string_GU__char_traits_G_std__V__allocator_G_2__std__QEAA_XZ
          (basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
           *this)

{
  *(undefined8 *)(this + 0x18) = 7;
  *(undefined8 *)(this + 0x10) = 0;
  *(undefined2 *)this = 0;
  return this;
}


