/*
 * Function : StringCchVPrintfExW
 * Address  : 0x14001282c
 * Size     : 207 bytes (64 instructions)
 * Prototype: long StringCchVPrintfExW(ushort * param_1, __uint64 param_2, ushort * * param_3, __uint64 * param_4, ulong param_5, ushort * param_6, char * param_7)
 * CC       : __cdecl
 * Comment  : long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short * __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* long __cdecl StringCchVPrintfExW(unsigned short * __ptr64,unsigned __int64,unsigned short *
   __ptr64 * __ptr64,unsigned __int64 * __ptr64,unsigned long,unsigned short const * __ptr64,char *
   __ptr64) */

long __cdecl
StringCchVPrintfExW(ushort *param_1,__uint64 param_2,ushort **param_3,__uint64 *param_4,
                   ulong param_5,ushort *param_6,char *param_7)

{
  ulonglong _Count;
  int iVar1;
  ulonglong uVar2;
  int iVar3;
  int iVar4;
  
  if (0x7ffffffe < param_2 - 1) {
    if (param_2 == 0) {
      return -0x7ff8ffa9;
    }
    *param_1 = 0;
    return -0x7ff8ffa9;
  }
  _Count = param_2 - 1;
  iVar3 = 0;
  iVar1 = _vsnwprintf((wchar_t *)param_1,_Count,(wchar_t *)param_6,param_7);
  iVar4 = -0x7ff8ff86;
  if (-1 < iVar1) {
    uVar2 = (ulonglong)iVar1;
    if ((uVar2 <= _Count) && (iVar4 = iVar3, uVar2 != _Count)) goto LAB_1400128b1;
  }
  param_1[_Count] = 0;
  uVar2 = _Count;
  iVar3 = iVar4;
LAB_1400128b1:
  if (((iVar3 + 0x80000000U & 0x80000000) != 0) || (iVar3 == -0x7ff8ff86)) {
    if (param_3 != (ushort **)0x0) {
      *param_3 = param_1 + uVar2;
    }
    if (param_4 != (__uint64 *)0x0) {
      *param_4 = param_2 - uVar2;
    }
  }
  return iVar3;
}


