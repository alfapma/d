/*
 * Function : catch$6
 * Address  : 0x140015e8d
 * Size     : 78 bytes (17 instructions)
 * Prototype: undefined8 catch$6(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined8
`CVssAdmSnapshotSetEntry::AddSnapshot'::__l1::catch_6(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleStdBadAllocException_CVssFunctionTracer__QEAAXPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
             (ushort *)L"CVssAdmSnapshotSetEntry::AddSnapshot",0x66,*(ulong *)(param_2 + 0x84));
  return 0;
}


