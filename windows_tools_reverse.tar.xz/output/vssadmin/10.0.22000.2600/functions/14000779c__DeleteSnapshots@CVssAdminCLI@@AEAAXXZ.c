/*
 * Function : ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ
 * Address  : 0x14000779c
 * Size     : 454 bytes (105 instructions)
 * Prototype: void ?DeleteSnapshots@CVssAdminCLI@@AEAAXXZ(CVssAdminCLI * this)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::DeleteSnapshots(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: void __cdecl CVssAdminCLI::DeleteSnapshots(void) __ptr64 */

void __thiscall CVssAdminCLI::_DeleteSnapshots_CVssAdminCLI__AEAAXXZ(CVssAdminCLI *this)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  CVssAdminCLI *this_00;
  uint uVar4;
  bool local_res10 [8];
  uint local_res18 [2];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe98;
  void *local_158;
  undefined8 local_150;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::DeleteSnapshots";
  local_138 = L"ADMPROCC";
  local_130 = 0x68f;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  local_res18[0] = 0;
  local_res10[0] = false;
  local_158 = (void *)0x0;
  local_150 = 0;
  _FindSnapshotsForDeletion_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEA_N_Z
            (this,(CVssSimpleArray<_GUID> *)&local_158,local_res10);
  if ((ulong)local_150 != 0) {
    this_00 = this;
    iVar1 = _PromptUserForConfirmation_CVssAdminCLI__AEAAHJK_Z(this,0x4000275b,(ulong)local_150);
    uVar4 = 0;
    if (iVar1 != 0) {
      _DeleteSnapshotsFromList_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEAJ_Z
                (this_00,(CVssSimpleArray<_GUID> *)&local_158,(long *)local_res18);
      uVar4 = local_res18[0];
    }
    iVar2 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
    if (((iVar2 == 0) && (iVar1 != 0)) && (0 < (int)uVar4)) {
      _OutputMsg_CVssAdminCLI__AEAAXJZZ(this,0x4000275d,(ulonglong)uVar4);
    }
    *(undefined4 *)(this + 0x48) = 0;
    if (local_158 != (void *)0x0) {
      free(local_158);
    }
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return;
  }
  if (local_res10[0] == false) {
    uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_148,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                       (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshots",0x69d,7,
                       in_stack_fffffffffffffe98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_98,uVar3,1,L"CVssAdminCLI: No snaphots found that satisfy the query");
  }
  uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_148,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DeleteSnapshots",0x69a,7,
                     in_stack_fffffffffffffe98);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar3,0x100b,
             L"CVssAdminCLI: Snapshots were found, but none were in the correct context");
}


