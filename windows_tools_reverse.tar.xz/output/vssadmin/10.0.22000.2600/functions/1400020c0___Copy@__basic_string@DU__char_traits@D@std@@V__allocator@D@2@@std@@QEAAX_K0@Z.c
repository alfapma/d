/*
 * Function : ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAX_K0@Z
 * Address  : 0x1400020c0
 * Size     : 217 bytes (68 instructions)
 * Prototype: void ?_Copy@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEAAX_K0@Z(basic_string<char,std::char_traits<char>,std::allocator<char>_> * this, __uint64 param_1, __uint64 param_2)
 * CC       : __thiscall
 * Comment  : public: void __cdecl std::basic_string<char,struct std::char_traits<char>,class std::allocator<char> >::_Copy(unsigned __int64,unsigned __int64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: void __cdecl std::basic_string<char,struct std::char_traits<char>,class
   std::allocator<char> >::_Copy(unsigned __int64,unsigned __int64) __ptr64 */

void __thiscall
std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
__Copy___basic_string_DU__char_traits_D_std__V__allocator_D_2__std__QEAAX_K0_Z
          (basic_string<char,std::char_traits<char>,std::allocator<char>_> *this,__uint64 param_1,
          __uint64 param_2)

{
  ulonglong uVar1;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *_Dst;
  ulonglong uVar2;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar3;
  ulonglong uVar4;
  
  uVar4 = param_1 | 0xf;
  if (uVar4 != 0xffffffffffffffff) {
    uVar1 = *(ulonglong *)(this + 0x18);
    uVar2 = uVar1 >> 1;
    param_1 = uVar4;
    if ((uVar4 / 3 < uVar2) && (param_1 = uVar2 + uVar1, -uVar2 - 2 < uVar1)) {
      param_1 = 0xfffffffffffffffe;
    }
  }
  _Dst = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0;
  if ((param_1 + 1 != 0) &&
     (_Dst = operator_new(param_1 + 1),
     _Dst == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0)) {
                    /* WARNING: Subroutine does not return */
    __Xbad_alloc_std__YAXXZ();
  }
  if (param_2 != 0) {
    pbVar3 = this;
    if (0xf < *(ulonglong *)(this + 0x18)) {
      pbVar3 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)this;
    }
    memcpy(_Dst,pbVar3,param_2);
  }
  if (0xf < *(ulonglong *)(this + 0x18)) {
    operator_delete__(*(void **)this);
  }
  *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)this = _Dst;
  *(__uint64 *)(this + 0x18) = param_1;
  pbVar3 = this;
  if (0xf < param_1) {
    pbVar3 = _Dst;
  }
  *(__uint64 *)(this + 0x10) = param_2;
  pbVar3[param_2] = (basic_string<char,std::char_traits<char>,std::allocator<char>_>)0x0;
  return;
}


