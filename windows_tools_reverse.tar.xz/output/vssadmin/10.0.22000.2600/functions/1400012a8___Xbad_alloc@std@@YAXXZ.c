/*
 * Function : ?_Xbad_alloc@std@@YAXXZ
 * Address  : 0x1400012a8
 * Size     : 31 bytes (6 instructions)
 * Prototype: void ?_Xbad_alloc@std@@YAXXZ(void)
 * CC       : __cdecl
 * Comment  : void __cdecl std::_Xbad_alloc(void)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* void __cdecl std::_Xbad_alloc(void) */

void __cdecl std::__Xbad_alloc_std__YAXXZ(void)

{
  bad_alloc local_28 [40];
  
  bad_alloc::__0bad_alloc_std__QEAA_XZ(local_28);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI2_AVbad_alloc_std__);
}


