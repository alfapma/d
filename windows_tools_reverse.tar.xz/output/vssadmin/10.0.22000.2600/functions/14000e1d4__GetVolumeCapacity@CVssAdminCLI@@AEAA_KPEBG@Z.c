/*
 * Function : ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z
 * Address  : 0x14000e1d4
 * Size     : 361 bytes (84 instructions)
 * Prototype: __uint64 ?GetVolumeCapacity@CVssAdminCLI@@AEAA_KPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: unsigned __int64 __cdecl CVssAdminCLI::GetVolumeCapacity(unsigned short const * __ptr64)
   __ptr64 */

__uint64 __thiscall
CVssAdminCLI::_GetVolumeCapacity_CVssAdminCLI__AEAA_KPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  ULARGE_INTEGER UVar1;
  BOOL BVar2;
  DWORD DVar3;
  ULARGE_INTEGER local_res8;
  ULARGE_INTEGER local_res18;
  ULARGE_INTEGER local_res20;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_140;
  wchar_t *local_138;
  wchar_t *local_130;
  undefined4 local_128;
  undefined4 local_124;
  undefined4 local_120;
  undefined1 local_118 [120];
  undefined4 local_a0;
  CVssFunctionTracer local_98 [112];
  
  local_140 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_138 = L"CVssAdminCLI::GetVolumeCapacity";
  local_130 = L"ADMUTILC";
  local_128 = 0x87;
  local_124 = 7;
  local_120 = 0xff;
  local_a0 = 0x1000000;
  local_res8 = (ULARGE_INTEGER)this;
  memset(local_118,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_140);
  local_res8.QuadPart = 0;
  local_res18.QuadPart = 0;
  local_res20.QuadPart = 0;
  BVar2 = GetDiskFreeSpaceExW((LPCWSTR)param_1,&local_res20,&local_res8,&local_res18);
  UVar1 = local_res8;
  if (BVar2 == 0) {
    DVar3 = GetLastError();
    if (DVar3 - 2 < 2) {
      DVar3 = 0x80042308;
    }
    else if (0 < (int)DVar3) {
      DVar3 = DVar3 & 0xffff | 0x80070000;
    }
    CVssFunctionTracer::_SetHr_CVssFunctionTracer__QEAAXJ_Z(local_98,DVar3);
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_140,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
               (ushort *)L"CVssAdminCLI::GetVolumeCapacity",0x9f,7,in_stack_fffffffffffffea8);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  return (__uint64)UVar1.s;
}


