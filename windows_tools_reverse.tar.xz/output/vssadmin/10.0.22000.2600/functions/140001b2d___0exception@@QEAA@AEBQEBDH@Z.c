/*
 * Function : ??0exception@@QEAA@AEBQEBDH@Z
 * Address  : 0x140001b2d
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined ??0exception@@QEAA@AEBQEBDH@Z(exception * this, char * * param_1, int param_2)
 * CC       : __thiscall
 * Comment  : public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl exception::exception(char const * __ptr64 const & __ptr64,int) __ptr64 */

void __thiscall exception::__0exception__QEAA_AEBQEBDH_Z(exception *this,char **param_1,int param_2)

{
                    /* WARNING: Could not recover jumptable at 0x000140001b2d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  exception(this,param_1,param_2);
  return;
}


