/*
 * Function : catch$22
 * Address  : 0x140015b20
 * Size     : 90 bytes (19 instructions)
 * Prototype: undefined8 catch$22(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined8 `CVssAdminCLI::Main'::__l1::catch_22(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleComException_CVssFunctionTracer__QEAAXAEAV_com_error__PEBG11KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x60),*(_com_error **)(param_2 + 0x180),
             (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.cpp",(ushort *)L"ADMVADMC",
             (ushort *)L"CVssAdminCLI::Main",0x325,*(ulong *)(param_2 + 0x84));
  return 0;
}


