/*
 * Function : dtor$3
 * Address  : 0x140015fac
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$3(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::DisplayDiffAreasPrivate'::__l1::dtor_3(undefined8 param_1,longlong param_2)

{
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
  __1__CVssAutoString_V__CVssAutoCOMPtr_PEAG____UEAA_XZ
            ((CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)(param_2 + 0xd8));
  return;
}


