/*
 * Function : ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ
 * Address  : 0x140002780
 * Size     : 41 bytes (11 instructions)
 * Prototype: void ??1?$CComPtr@UIVssEnumObject@@@ATL@@QEAA@XZ(CComPtr<IVssEnumObject> * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: _guard_xfg_dispatch_icall_nop replaced with injection: guard_dispatch_icall */
/* public: __cdecl ATL::CComPtr<struct IVssEnumObject>::~CComPtr<struct IVssEnumObject>(void)
   __ptr64 */

void __thiscall
ATL::CComPtr<IVssEnumObject>::__1__CComPtr_UIVssEnumObject___ATL__QEAA_XZ
          (CComPtr<IVssEnumObject> *this)

{
  if (*(longlong **)this != (longlong *)0x0) {
    (**(code **)(**(longlong **)this + 0x10))();
  }
  return;
}


