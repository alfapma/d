/*
 * Function : dtor$1
 * Address  : 0x1400162db
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$1(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssResource::LoadStringW'::__l1::dtor_1(undefined8 param_1,longlong param_2)

{
  std::basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
  ::__1__basic_string_GU__char_traits_G_std__V__allocator_G_2__std__QEAA_XZ
            ((basic_string<unsigned_short,std::char_traits<unsigned_short>,std::allocator<unsigned_short>_>
              *)(param_2 + 0xf0));
  return;
}


