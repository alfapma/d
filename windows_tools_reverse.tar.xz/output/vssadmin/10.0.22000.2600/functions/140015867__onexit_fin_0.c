/*
 * Function : _onexit$fin$0
 * Address  : 0x140015867
 * Size     : 26 bytes (9 instructions)
 * Prototype: undefined _onexit$fin$0(void)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void _onexit_fin_0(void)

{
  _unlock(8);
  return;
}


