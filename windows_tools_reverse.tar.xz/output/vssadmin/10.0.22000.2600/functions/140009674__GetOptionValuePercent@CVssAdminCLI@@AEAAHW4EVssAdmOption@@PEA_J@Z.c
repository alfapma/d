/*
 * Function : ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z
 * Address  : 0x140009674
 * Size     : 323 bytes (77 instructions)
 * Prototype: int ?GetOptionValuePercent@CVssAdminCLI@@AEAAHW4EVssAdmOption@@PEA_J@Z(CVssAdminCLI * this, EVssAdmOption param_1, __int64 * param_2)
 * CC       : __thiscall
 * Comment  : private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: int __cdecl CVssAdminCLI::GetOptionValuePercent(enum EVssAdmOption,__int64 * __ptr64)
   __ptr64 */

int __thiscall
CVssAdminCLI::_GetOptionValuePercent_CVssAdminCLI__AEAAHW4EVssAdmOption__PEA_J_Z
          (CVssAdminCLI *this,EVssAdmOption param_1,__int64 *param_2)

{
  ushort *puVar1;
  longlong lVar2;
  longlong lVar3;
  __int64 _Var4;
  CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *this_00;
  undefined **local_138;
  ushort *local_130;
  wchar_t *local_128;
  wchar_t *local_120;
  wchar_t *local_118;
  undefined4 local_110;
  undefined4 local_10c;
  undefined4 local_108;
  undefined1 local_100 [120];
  undefined4 local_88;
  CVssFunctionTracer local_78 [112];
  
  local_128 = L"base\\stor\\vss\\modules\\vssadmin\\vssadmin.h";
  local_120 = L"CVssAdminCLI::GetOptionValuePercent";
  local_118 = L"INCPNTRH";
  local_110 = 0x17d;
  local_10c = 7;
  local_108 = 0xff;
  local_88 = 0x1000000;
  memset(local_100,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_78,&local_128);
  puVar1 = *(ushort **)(this + 0x90);
  if (puVar1 == (ushort *)0x0) {
    *param_2 = 0;
  }
  else if (*puVar1 != 0) {
    local_130 = (ushort *)0x0;
    local_138 = &CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::_vftable_;
    this_00 = (CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_> *)&local_138;
    CVssAutoString<CVssAutoCOMPtr<unsigned_short*___ptr64>_>::
    _CopyFrom___CVssAutoString_V__CVssAutoCOMPtr_PEAG____QEAAXPEBG_Z(this_00,puVar1);
    puVar1 = local_130;
    lVar2 = -1;
    do {
      lVar3 = lVar2;
      lVar2 = lVar3 + 1;
    } while (local_130[lVar3 + 1] != 0);
    if (local_130[lVar3] == 0x25) {
      local_130[lVar3] = 0;
      _Var4 = _ScanNumber_CVssAdminCLI__AEAA_JPEBGH_Z((CVssAdminCLI *)this_00,local_130,0);
      *param_2 = _Var4;
      if (puVar1 != (ushort *)0x0) {
        CoTaskMemFree(puVar1);
      }
      CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
      return 1;
    }
    if (local_130 != (ushort *)0x0) {
      CoTaskMemFree(local_130);
    }
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_78);
  return 0;
}


