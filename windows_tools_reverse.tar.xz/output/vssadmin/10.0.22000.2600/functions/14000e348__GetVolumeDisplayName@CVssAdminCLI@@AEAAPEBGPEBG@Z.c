/*
 * Function : ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z
 * Address  : 0x14000e348
 * Size     : 1317 bytes (292 instructions)
 * Prototype: ushort * ?GetVolumeDisplayName@CVssAdminCLI@@AEAAPEBGPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: _guard_xfg_dispatch_icall_nop replaced with injection: guard_dispatch_icall */
/* private: unsigned short const * __ptr64 __cdecl CVssAdminCLI::GetVolumeDisplayName(unsigned short
   const * __ptr64) __ptr64 */

ushort * __thiscall
CVssAdminCLI::_GetVolumeDisplayName_CVssAdminCLI__AEAAPEBGPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  short sVar1;
  short sVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  void *pvVar6;
  ushort *puVar7;
  undefined8 uVar8;
  short *psVar9;
  undefined8 *puVar10;
  ushort *puVar11;
  ushort *puVar12;
  undefined8 *puVar13;
  undefined8 *local_res8 [2];
  longlong *local_res18;
  longlong *local_res20;
  _VSSDBG_SEV_ENUM _Var14;
  longlong **pplVar15;
  GUID local_198;
  wchar_t *local_188;
  wchar_t *local_180;
  wchar_t *local_178;
  undefined4 local_170;
  undefined4 local_16c;
  undefined4 local_168;
  undefined1 local_160 [120];
  undefined4 local_e8;
  CVssFunctionTracer local_d8 [8];
  int local_d0;
  undefined1 local_68 [8];
  ushort *local_60;
  ushort *local_58 [4];
  
  local_188 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_180 = L"CVssAdminCLI::GetVolumeDisplayName";
  local_178 = L"ADMUTILC";
  local_170 = 0x38;
  local_16c = 7;
  local_168 = 0xff;
  puVar11 = (ushort *)0x0;
  local_e8 = 0x1000000;
  memset(local_160,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_d8,&local_188);
  puVar10 = *(undefined8 **)(this + 0x40);
  if (puVar10 == (undefined8 *)0x0) {
    local_res20 = (longlong *)0x0;
    local_188 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
    local_180 = L"CVssAdminCLI::GetVolumeDisplayName";
    local_178 = L"ADMUTILC";
    local_170 = 0x40;
    local_16c = 7;
    local_168 = 0xff;
    local_e8 = 0x1000000;
    memset(local_160,0,0x78);
    local_198 = _GUID_0b5a2c52_3eb9_470a_96e2_6c6d4570e40f;
    pplVar15 = &local_res20;
    CVssFunctionTracer::
    _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
              (local_d8,&local_188,&local_198,L"VssSnapshotMgmt");
    if (local_d0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_188,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x47,7,(_VSSDBG_SEV_ENUM)pplVar15);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_d8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_d8);
    }
    local_res18 = (longlong *)0x0;
    local_198._8_4_ = 0xab5180af;
    local_198._0_8_ = 0x49257b9fb5946137;
    local_198._12_4_ = 0xd5200bd6;
    local_d0 = (**(code **)(*local_res20 + 0x20))(local_res20,&local_198,0xffffffff,&local_res18);
    if (local_d0 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                ((CVssDebugInfo *)&local_188,
                 (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",(ushort *)L"ADMUTILC",
                 (ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x52,7,(_VSSDBG_SEV_ENUM)pplVar15);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_d8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_d8);
    }
    if (local_d0 == 1) {
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_188,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x56,
                         7,(_VSSDBG_SEV_ENUM)pplVar15);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_d8,uVar8,1,
                 L"CVssAdminCLI::ListVolumes: No volumes found that satisfy the query");
    }
    local_res8[0] = operator_new(0x18,&std::nothrow);
    if (local_res8[0] == (undefined8 *)0x0) {
      *(undefined8 *)(this + 0x40) = 0;
      uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_188,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                         (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x60,
                         1,(_VSSDBG_SEV_ENUM)pplVar15);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_d8,uVar8,0x8007000e,L"Memory allocation error");
    }
    *local_res8[0] = 0;
    local_res8[0][1] = 0;
    *(undefined4 *)(local_res8[0] + 2) = 0;
    *(undefined8 **)(this + 0x40) = local_res8[0];
    while( true ) {
      local_d0 = (**(code **)(*local_res18 + 0x18))(local_res18,1,local_68,local_res8);
      puVar12 = local_58[0];
      puVar7 = local_60;
      if (local_d0 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  ((CVssDebugInfo *)&local_188,
                   (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                   (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",0x68,7,
                   (_VSSDBG_SEV_ENUM)pplVar15);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_d8);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_d8);
      }
      if (local_d0 == 1) break;
      lVar5 = -1;
      do {
        lVar5 = lVar5 + 1;
      } while (local_58[0][lVar5] != 0);
      if ((lVar5 == 3) && (local_58[0][2] == 0x5c)) {
        local_58[0][2] = 0;
      }
      plVar3 = *(longlong **)(this + 0x40);
      pvVar6 = realloc((void *)*plVar3,(longlong)((int)plVar3[2] + 1) << 3);
      _Var14 = (_VSSDBG_SEV_ENUM)pplVar15;
      if (pvVar6 == (void *)0x0) {
LAB_14000e7c0:
        VssFreeString(&local_60);
        VssFreeString(local_58);
        uVar8 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                          ((CVssDebugInfo *)&local_188,
                           (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                           (ushort *)L"ADMUTILC",(ushort *)L"CVssAdminCLI::GetVolumeDisplayName",
                           0x7a,1,_Var14);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                  (local_d8,uVar8,0x8007000e,L"Memory allocation error");
      }
      *plVar3 = (longlong)pvVar6;
      pvVar6 = realloc((void *)plVar3[1],(longlong)((int)plVar3[2] + 1) << 3);
      _Var14 = (_VSSDBG_SEV_ENUM)pplVar15;
      if (pvVar6 == (void *)0x0) goto LAB_14000e7c0;
      plVar3[1] = (longlong)pvVar6;
      iVar4 = (int)plVar3[2];
      *(int *)(plVar3 + 2) = iVar4 + 1;
      puVar10 = (undefined8 *)(*plVar3 + (longlong)iVar4 * 8);
      if (puVar10 != (undefined8 *)0x0) {
        *puVar10 = puVar7;
        pvVar6 = (void *)plVar3[1];
      }
      plVar3 = (longlong *)((longlong)pvVar6 + (longlong)iVar4 * 8);
      if (plVar3 != (longlong *)0x0) {
        *plVar3 = (longlong)puVar12;
      }
    }
    if (local_res18 != (longlong *)0x0) {
      (**(code **)(*local_res18 + 0x10))();
    }
    if (local_res20 != (longlong *)0x0) {
      (**(code **)(*local_res20 + 0x10))();
    }
    puVar10 = *(undefined8 **)(this + 0x40);
  }
  if (0 < *(int *)(puVar10 + 2)) {
    puVar13 = (undefined8 *)*puVar10;
    puVar7 = puVar11;
    puVar12 = puVar11;
    do {
      psVar9 = (short *)*puVar13;
      lVar5 = (longlong)param_1 - (longlong)psVar9;
      do {
        sVar1 = *psVar9;
        sVar2 = *(short *)((longlong)psVar9 + lVar5);
        if (sVar1 != sVar2) break;
        psVar9 = psVar9 + 1;
      } while (sVar2 != 0);
      iVar4 = (int)puVar7;
      if (sVar1 == sVar2) {
        if (iVar4 != -1) {
          puVar11 = *(ushort **)(puVar10[1] + (longlong)iVar4 * 8);
        }
        break;
      }
      puVar7 = (ushort *)(ulonglong)(iVar4 + 1);
      puVar12 = (ushort *)((longlong)puVar12 + 1);
      puVar13 = puVar13 + 1;
    } while ((longlong)puVar12 < (longlong)*(int *)(puVar10 + 2));
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_d8);
  return puVar11;
}


