/*
 * Function : catch$6
 * Address  : 0x140016794
 * Size     : 89 bytes (19 instructions)
 * Prototype: undefined8 catch$6(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

undefined8
`CVssMachineInformation::GetMinDiffAreaOnVolume'::__l1::catch_6(undefined8 param_1,longlong param_2)

{
  CVssFunctionTracer::_HandleHresultException_CVssFunctionTracer__QEAAXJPEBG00KK_Z
            ((CVssFunctionTracer *)(param_2 + 0x1c0),*(long *)(param_2 + 0x58),
             (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",(ushort *)L"REGREGSC",
             (ushort *)L"CVssMachineInformation::GetMinDiffAreaOnVolume",0x6be,
             *(ulong *)(param_2 + 0x1e4));
  return 0;
}


