/*
 * Function : dtor$15
 * Address  : 0x140016084
 * Size     : 12 bytes (2 instructions)
 * Prototype: undefined dtor$15(undefined8 param_1, longlong param_2)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void `CVssAdminCLI::FindSnapshotsForDeletion'::__l1::dtor_15(undefined8 param_1,longlong param_2)

{
  CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ(*(CVssDebugInfo **)(param_2 + 0x50));
  return;
}


