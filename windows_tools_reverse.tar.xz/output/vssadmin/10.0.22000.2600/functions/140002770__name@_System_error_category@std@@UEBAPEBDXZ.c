/*
 * Function : ?name@_System_error_category@std@@UEBAPEBDXZ
 * Address  : 0x140002770
 * Size     : 16 bytes (6 instructions)
 * Prototype: char * ?name@_System_error_category@std@@UEBAPEBDXZ(_System_error_category * this)
 * CC       : __thiscall
 * Comment  : public: virtual char const * __ptr64 __cdecl std::_System_error_category::name(void)const __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual char const * __ptr64 __cdecl std::_System_error_category::name(void)const __ptr64
    */

char * __thiscall
std::_System_error_category::_name__System_error_category_std__UEBAPEBDXZ
          (_System_error_category *this)

{
  return "system";
}


