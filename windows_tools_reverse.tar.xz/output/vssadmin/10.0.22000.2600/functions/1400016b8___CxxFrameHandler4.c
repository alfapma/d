/*
 * Function : __CxxFrameHandler4
 * Address  : 0x1400016b8
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined __CxxFrameHandler4()
 * CC       : unknown
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void __CxxFrameHandler4(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001400016b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  __CxxFrameHandler4();
  return;
}


