/*
 * Function : ??1CVssFunctionTracer@@QEAA@XZ
 * Address  : 0x140010a74
 * Size     : 271 bytes (69 instructions)
 * Prototype: void ??1CVssFunctionTracer@@QEAA@XZ(CVssFunctionTracer * this)
 * CC       : __thiscall
 * Comment  : public: __cdecl CVssFunctionTracer::~CVssFunctionTracer(void) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: __cdecl CVssFunctionTracer::~CVssFunctionTracer(void) __ptr64 */

void __thiscall CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(CVssFunctionTracer *this)

{
  DWORD DVar1;
  uint uVar2;
  CVssFunctionTracer *pCVar3;
  longlong lVar4;
  ulong uVar5;
  
  pCVar3 = this + 0x40;
  lVar4 = 4;
  do {
    CoTaskMemFree(*(LPVOID *)pCVar3);
    *(undefined8 *)pCVar3 = 0;
    pCVar3 = pCVar3 + 8;
    lVar4 = lVar4 + -1;
  } while (lVar4 != 0);
  DVar1 = GetTickCount();
  uVar2 = DVar1 - *(int *)(this + 0x34);
  uVar5 = 0xa0;
  if (*(int *)(this + 0x38) != 0xff) {
    uVar5 = *(ulong *)(this + 0x38);
  }
  _TraceInternalWithFormat_CVssFunctionTracer__QEAAXPEBGK0ZZ
            (this,(ushort *)L"EXIT",uVar5,
             (ushort *)L"Time spent: %02ld:%02ld:%02ld-%04ld; total: %#x; HRESULT: %#x",
             (int)((ulonglong)uVar2 / 3600000) + (int)(((ulonglong)uVar2 / 3600000) / 0x3c) * -0x3c,
             (uVar2 / 60000) % 0x3c,(uVar2 / 1000) % 0x3c,uVar2 % 1000,uVar2,
             *(undefined4 *)(this + 8));
                    /* WARNING: Could not recover jumptable at 0x000140010b7c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  Ordinal_9(*(undefined8 *)(this + 0x60));
  return;
}


