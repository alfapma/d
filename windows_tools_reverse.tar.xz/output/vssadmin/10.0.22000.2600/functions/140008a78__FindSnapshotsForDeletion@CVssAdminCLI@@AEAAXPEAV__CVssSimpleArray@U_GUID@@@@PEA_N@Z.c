/*
 * Function : ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z
 * Address  : 0x140008a78
 * Size     : 2229 bytes (463 instructions)
 * Prototype: void ?FindSnapshotsForDeletion@CVssAdminCLI@@AEAAXPEAV?$CVssSimpleArray@U_GUID@@@@PEA_N@Z(CVssAdminCLI * this, CVssSimpleArray<_GUID> * param_1, bool * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID> * __ptr64,bool * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: _guard_xfg_dispatch_icall_nop replaced with injection: guard_dispatch_icall */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* private: void __cdecl CVssAdminCLI::FindSnapshotsForDeletion(class CVssSimpleArray<struct _GUID>
   * __ptr64,bool * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::_FindSnapshotsForDeletion_CVssAdminCLI__AEAAXPEAV__CVssSimpleArray_U_GUID____PEA_N_Z
          (CVssAdminCLI *this,CVssSimpleArray<_GUID> *param_1,bool *param_2)

{
  WCHAR WVar1;
  longlong *plVar2;
  code *pcVar3;
  undefined1 auVar4 [16];
  int iVar5;
  bool *pbVar6;
  uchar auVar7 [8];
  bool bVar8;
  int iVar9;
  BOOL BVar10;
  int iVar11;
  LPCWSTR lpszVolumeMountPoint;
  ushort *puVar12;
  WCHAR *pWVar13;
  undefined8 uVar14;
  CVssAdminCLI *this_00;
  WCHAR *pWVar15;
  longlong lVar16;
  longlong lVar17;
  undefined1 auStackY_3d8 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffc58;
  _VSSDBG_SEV_ENUM _Var18;
  longlong **pplVar19;
  undefined1 local_388 [12];
  uchar auStack_37c [4];
  int local_378 [2];
  bool *local_370;
  longlong *local_368 [2];
  GUID local_358;
  wchar_t *local_348;
  wchar_t *local_340;
  wchar_t *local_338;
  undefined4 local_330;
  undefined4 local_32c;
  undefined4 local_328;
  undefined1 local_320 [120];
  undefined4 local_2a8;
  CVssFunctionTracer local_298 [8];
  uint local_290;
  CVssDebugInfo local_228 [176];
  _GUID local_178;
  _GUID local_168;
  undefined1 local_158 [8];
  _GUID local_150 [3];
  wchar_t *local_120;
  long local_e8;
  longlong local_e0;
  WCHAR local_c8 [49];
  undefined2 local_66;
  long local_60;
  ulonglong local_48;
  
  local_48 = __security_cookie ^ (ulonglong)auStackY_3d8;
  local_348 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_340 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_338 = L"ADMPROCC";
  local_330 = 0x6b0;
  local_32c = 7;
  local_328 = 0xff;
  local_2a8 = 0x1000000;
  local_370 = param_2;
  memset(local_320,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_298,&local_348);
  lpszVolumeMountPoint =
       (LPCWSTR)_GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
  iVar9 = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,6);
  local_378[0] = _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,0);
  local_178.Data1 = 0;
  local_178.Data2 = 0;
  local_178.Data3 = 0;
  local_178.Data4[0] = '\0';
  local_178.Data4[1] = '\0';
  local_178.Data4[2] = '\0';
  local_178.Data4[3] = '\0';
  local_178.Data4[4] = '\0';
  local_178.Data4[5] = '\0';
  local_178.Data4[6] = '\0';
  local_178.Data4[7] = '\0';
  local_168.Data1 = 0;
  local_168.Data2 = 0;
  local_168.Data3 = 0;
  local_168.Data4[0] = '\0';
  local_168.Data4[1] = '\0';
  local_168.Data4[2] = '\0';
  local_168.Data4[3] = '\0';
  local_168.Data4[4] = '\0';
  local_168.Data4[5] = '\0';
  local_168.Data4[6] = '\0';
  local_168.Data4[7] = '\0';
  lVar17 = 0x7fffffffffffffff;
  puVar12 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
  if (puVar12 != (ushort *)0x0) {
    this_00 = this;
    puVar12 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,0xc);
    bVar8 = _ScanGuid_CVssAdminCLI__AEAA_NPEBGAEAU_GUID___Z(this_00,puVar12,&local_178);
    if (!bVar8) {
      uVar14 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         ((CVssDebugInfo *)&local_348,
                          (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                          0x6be,7,in_stack_fffffffffffffc58);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_298,uVar14,0x1004,L"CVssAdminCLI::DeleteSnapshots: Invalid snapshot id");
    }
  }
  plVar2 = *(longlong **)this;
  pcVar3 = *(code **)(*plVar2 + 0x58);
  _GetOptionValueBool_CVssAdminCLI__AEAAHW4EVssAdmOption___Z(this,9);
  auVar7 = local_178.Data4;
  local_388[8] = local_178.Data4[0];
  local_388[9] = local_178.Data4[1];
  local_388[10] = local_178.Data4[2];
  local_388[0xb] = local_178.Data4[3];
  local_388._0_4_ = local_178.Data1;
  local_388._4_2_ = local_178.Data2;
  local_388._6_2_ = local_178.Data3;
  auStack_37c[0] = local_178.Data4[4];
  auStack_37c[1] = local_178.Data4[5];
  auStack_37c[2] = local_178.Data4[6];
  auStack_37c[3] = local_178.Data4[7];
  local_178.Data4 = auVar7;
  (*pcVar3)(plVar2,0xffffffff,lpszVolumeMountPoint,local_378[0] == 1);
  local_368[0] = (longlong *)0x0;
  local_348 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_340 = L"CVssAdminCLI::FindSnapshotsForDeletion";
  local_338 = L"ADMPROCC";
  local_330 = 0x6c9;
  local_32c = 7;
  local_328 = 0xff;
  local_2a8 = 0x1000000;
  memset(local_320,0,0x78);
  _local_388 = _GUID_da9f41d4_1a5d_41d0_a614_6dfd78df5d05;
  local_358 = _GUID_e579ab5f_1cc4_44b4_bed9_de0991ff0623;
  pplVar19 = local_368;
  CVssFunctionTracer::
  _CoCreateInstanceWithLog_CVssFunctionTracer__QEAAXUCVssDebugInfo__U_GUID__PEBGK1PEAPEAUIUnknown___Z
            (local_298,&local_348,&local_358,L"Coordinator");
  if ((int)local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_348,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d0,7,
               (_VSSDBG_SEV_ENUM)pplVar19);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  local_290 = (**(code **)(*local_368[0] + 0x18))();
  _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
  if ((int)local_290 < 0) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_348,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6d5,7,_Var18);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
  }
  if ((local_178._0_8_ == 0) && (local_178.Data4 == (uchar  [8])0x0)) {
    memset(local_c8,0,100);
    if (lpszVolumeMountPoint != (LPCWSTR)0x0) {
      if (*lpszVolumeMountPoint == L'\\') {
        lVar16 = 0x32;
        pWVar15 = local_c8;
        do {
          if ((lVar16 == -0x7fffffcc) ||
             (WVar1 = *(WCHAR *)(((longlong)lpszVolumeMountPoint - (longlong)local_c8) +
                                (longlong)pWVar15), WVar1 == L'\0')) break;
          *pWVar15 = WVar1;
          pWVar15 = pWVar15 + 1;
          lVar16 = lVar16 + -1;
        } while (lVar16 != 0);
        pWVar13 = pWVar15 + -1;
        if (lVar16 != 0) {
          pWVar13 = pWVar15;
        }
        *pWVar13 = L'\0';
        local_290 = ~-(uint)(lVar16 != 0) & 0x8007007a;
        local_348 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
        local_340 = L"CVssAdminCLI::FindSnapshotsForDeletion";
        local_338 = L"ADMPROCC";
        local_330 = 0x701;
        local_32c = 7;
        local_328 = 0xff;
        local_2a8 = 0x1000000;
        memset(local_320,0,0x78);
        local_388._0_8_ = &local_348;
        if (lVar16 == 0) {
          uVar14 = CVssDebugInfo::__0CVssDebugInfo__QEAA_AEBU0__Z
                             (local_228,(CVssDebugInfo *)&local_348);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_TranslateError_CVssFunctionTracer__QEAAXUCVssDebugInfo__JPEBG_Z
                    (local_298,uVar14,0x8007007a,L"StringCchCopy");
        }
        CVssDebugInfo::__1CVssDebugInfo__QEAA_XZ((CVssDebugInfo *)&local_348);
        local_66 = 0;
      }
      else {
        BVar10 = GetVolumeNameForVolumeMountPointW(lpszVolumeMountPoint,local_c8,0x32);
        _Var18 = (_VSSDBG_SEV_ENUM)pplVar19;
        if (BVar10 == 0) {
          GetLastError();
          _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,3);
          uVar14 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                             ((CVssDebugInfo *)&local_348,
                              (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                              (ushort *)L"ADMPROCC",
                              (ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x6fa,1,_Var18);
                    /* WARNING: Subroutine does not return */
          CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                    (local_298,uVar14,0x80042308,
                     L"GetVolumeNameForVolumeMountPoint(%s,...) failed with error code 0x%08lx");
        }
      }
    }
    auVar4._8_8_ = 0;
    auVar4._0_8_ = local_358._8_8_;
    local_358 = (GUID)(auVar4 << 0x40);
    _local_388 = (GUID)ZEXT816(0);
    local_290 = (**(code **)(*local_368[0] + 0x50))(local_368[0],local_388,1);
    pbVar6 = local_370;
    iVar5 = local_378[0];
    if ((int)local_290 < 0) {
      CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                (local_228,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                 (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x70a,7,
                 (_VSSDBG_SEV_ENUM)pplVar19);
      CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
    }
    while( true ) {
      local_290 = (**(code **)(*(longlong *)local_358._0_8_ + 0x18))
                            (local_358._0_8_,1,local_158,local_378);
      if ((int)local_290 < 0) {
        CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                  (local_228,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                   (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",0x715,7
                   ,(_VSSDBG_SEV_ENUM)pplVar19);
        CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_298);
                    /* WARNING: Subroutine does not return */
        CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_298);
      }
      if (local_290 == 1) break;
      stack0xfffffffffffffc80 = local_150;
      local_388._0_8_ =
           &CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
            ::_vftable_;
      iVar11 = _wcsicmp(local_120,local_c8);
      if ((iVar11 == 0) || ((lpszVolumeMountPoint == (LPCWSTR)0x0 && (iVar5 != 0)))) {
        iVar11 = IsCorrectContext(local_e8);
        if (iVar11 == 0) {
          *pbVar6 = true;
        }
        else if (iVar9 == 0) {
          CVssSimpleArray<_GUID>::_Add___CVssSimpleArray_U_GUID____QEAAXAEAU_GUID___Z
                    (param_1,local_150);
        }
        else if (local_e0 < lVar17) {
          local_168.Data1 = local_150[0].Data1;
          local_168.Data2 = local_150[0].Data2;
          local_168.Data3 = local_150[0].Data3;
          local_168.Data4[0] = local_150[0].Data4[0];
          local_168.Data4[1] = local_150[0].Data4[1];
          local_168.Data4[2] = local_150[0].Data4[2];
          local_168.Data4[3] = local_150[0].Data4[3];
          local_168.Data4[4] = local_150[0].Data4[4];
          local_168.Data4[5] = local_150[0].Data4[5];
          local_168.Data4[6] = local_150[0].Data4[6];
          local_168.Data4[7] = local_150[0].Data4[7];
          lVar17 = local_e0;
        }
      }
      VssFreeSnapshotPropertiesInternal(local_150);
      _local_388 = (GUID)ZEXT816(0x140017ab0);
    }
    if ((iVar9 != 0) && ((local_168._0_8_ != 0 || (local_168.Data4 != (uchar  [8])0x0)))) {
      CVssSimpleArray<_GUID>::_Add___CVssSimpleArray_U_GUID____QEAAXAEAU_GUID___Z
                (param_1,&local_168);
    }
    if ((longlong *)local_358._0_8_ != (longlong *)0x0) {
      (**(code **)(*(longlong *)local_358._0_8_ + 0x10))();
    }
  }
  else {
    local_168.Data1 = local_178.Data1;
    local_168.Data2 = local_178.Data2;
    local_168.Data3 = local_178.Data3;
    local_168.Data4[0] = local_178.Data4[0];
    local_168.Data4[1] = local_178.Data4[1];
    local_168.Data4[2] = local_178.Data4[2];
    local_168.Data4[3] = local_178.Data4[3];
    local_168.Data4[4] = local_178.Data4[4];
    local_168.Data4[5] = local_178.Data4[5];
    local_168.Data4[6] = local_178.Data4[6];
    local_168.Data4[7] = local_178.Data4[7];
    local_290 = (**(code **)(*local_368[0] + 0x38))(local_368[0],&local_168,local_c8);
    if (local_290 == -0x7ffbdcf8) {
      uVar14 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         (local_228,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                          0x6e0,7,_Var18);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_298,uVar14,1,L"No snapshots were found with that ID");
    }
    iVar9 = IsCorrectContext(local_60);
    if (iVar9 == 0) {
      uVar14 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                         (local_228,(ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                          (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::FindSnapshotsForDeletion",
                          0x6e4,7,_Var18);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_298,uVar14,0x100b,
                 L"Snapshot was found, but you cannot delete it in this context.");
    }
    VssFreeSnapshotPropertiesInternal(local_c8);
    CVssSimpleArray<_GUID>::_Add___CVssSimpleArray_U_GUID____QEAAXAEAU_GUID___Z(param_1,&local_178);
  }
  if (local_368[0] != (longlong *)0x0) {
    (**(code **)(*local_368[0] + 0x10))();
  }
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_298);
  return;
}


