/*
 * Function : ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z
 * Address  : 0x140009340
 * Size     : 402 bytes (93 instructions)
 * Prototype: void ?GetDifferentialSoftwareSnapshotMgmtInterface@CVssAdminCLI@@AEAAXU_GUID@@PEAPEAUIUnknown@@@Z(CVssAdminCLI * this, _GUID * param_1, IUnknown * * param_2)
 * CC       : __thiscall
 * Comment  : private: void __cdecl CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface(struct _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: void __cdecl CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface(struct
   _GUID,struct IUnknown * __ptr64 * __ptr64) __ptr64 */

void __thiscall
CVssAdminCLI::
_GetDifferentialSoftwareSnapshotMgmtInterface_CVssAdminCLI__AEAAXU_GUID__PEAPEAUIUnknown___Z
          (CVssAdminCLI *this,_GUID *param_1,IUnknown **param_2)

{
  ushort *puVar1;
  undefined8 uVar2;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe88;
  GUID local_168;
  ulong local_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [8];
  int local_90;
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface";
  local_138 = L"ADMPROCC";
  local_130 = 0x11c;
  local_12c = 7;
  local_128 = 0xff;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  local_168 = _GUID_949d7353_675f_4275_8969_f044c6277815;
  local_158 = param_1->Data1;
  uStack_154._0_2_ = param_1->Data2;
  uStack_154._2_2_ = param_1->Data3;
  uStack_150 = *(undefined4 *)param_1->Data4;
  uStack_14c = *(undefined4 *)(param_1->Data4 + 4);
  local_90 = GetProviderMgmtInterfaceInternal(&local_158,&local_168,param_2);
  if (-1 < local_90) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    return;
  }
  if (local_90 != -0x7fffbffe) {
    CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
              ((CVssDebugInfo *)&local_148,
               (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",(ushort *)L"ADMPROCC",
               (ushort *)L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface",0x128,7,
               in_stack_fffffffffffffe88);
    CVssFunctionTracer::_GetHr_CVssFunctionTracer__QEAAJXZ(local_98);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ(local_98);
  }
  puVar1 = _GetOptionValueStr_CVssAdminCLI__AEAAPEAGW4EVssAdmOption___Z(this,8);
  _OutputErrorMsg_CVssAdminCLI__AEAAXJZZ(this,0x40002b5d,puVar1);
  uVar2 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_148,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                     (ushort *)L"ADMPROCC",
                     (ushort *)L"CVssAdminCLI::GetDifferentialSoftwareSnapshotMgmtInterface",0x126,7
                     ,in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_98,uVar2,0,L"Provider doesn\'t support diff aras");
}


