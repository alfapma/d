/*
 * Function : ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z
 * Address  : 0x140005f70
 * Size     : 89 bytes (24 instructions)
 * Prototype: void * ??_G?$CVssAuto@PEAU_VSS_SNAPSHOT_PROP@@V?$CVssAutoGenericValue_Storage@PEAU_VSS_SNAPSHOT_PROP@@$0A@P6AXPEAU1@@Z$1?VssFreeSnapshotProperties@@YAX0@ZP6AAEAPEAU1@AEAPEAU1@@Z$1?Identity@?$DTyper@PEAU_VSS_SNAPSHOT_PROP@@@@SAAEAPEAU1@1@Z@@@@UEAAPEAXI@Z(CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_> * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP * __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64)> >::`scalar deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void * __ptr64 __cdecl CVssAuto<struct _VSS_SNAPSHOT_PROP * __ptr64,class
   CVssAutoGenericValue_Storage<struct _VSS_SNAPSHOT_PROP * __ptr64,0,void (__cdecl*)(struct
   _VSS_SNAPSHOT_PROP * __ptr64),&void __cdecl VssFreeSnapshotProperties(struct _VSS_SNAPSHOT_PROP *
   __ptr64),struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 (__cdecl*)(struct _VSS_SNAPSHOT_PROP *
   __ptr64 & __ptr64),&public: static struct _VSS_SNAPSHOT_PROP * __ptr64 & __ptr64 __cdecl
   DTyper<struct _VSS_SNAPSHOT_PROP * __ptr64>::Identity(struct _VSS_SNAPSHOT_PROP * __ptr64 &
   __ptr64)> >::`scalar deleting destructor'(unsigned int) __ptr64 */

void * __thiscall
CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
::
___G__CVssAuto_PEAU_VSS_SNAPSHOT_PROP__V__CVssAutoGenericValue_Storage_PEAU_VSS_SNAPSHOT_PROP___0A_P6AXPEAU1__Z_1_VssFreeSnapshotProperties__YAX0_ZP6AAEAPEAU1_AEAPEAU1__Z_1_Identity___DTyper_PEAU_VSS_SNAPSHOT_PROP____SAAEAPEAU1_1_Z____UEAAPEAXI_Z
          (CVssAuto<_VSS_SNAPSHOT_PROP*___ptr64,CVssAutoGenericValue_Storage<_VSS_SNAPSHOT_PROP*___ptr64,0,void_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64),&void___cdecl_VssFreeSnapshotProperties(struct__VSS_SNAPSHOT_PROP*___ptr64),struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64_(__cdecl*)(_VSS_SNAPSHOT_PROP*___ptr64&___ptr64),&public:_static_struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64___cdecl_DTyper<struct__VSS_SNAPSHOT_PROP*___ptr64>::Identity(struct__VSS_SNAPSHOT_PROP*___ptr64&___ptr64)>_>
           *this,uint param_1)

{
  *(undefined ***)this = &_vftable_;
  if (*(longlong *)(this + 8) != 0) {
    VssFreeSnapshotPropertiesInternal();
  }
  *(undefined8 *)(this + 8) = 0;
  *(undefined ***)this =
       &CVssAutoGenericValue_Storage<void*___ptr64,-1,int_(__cdecl*)(void*___ptr64),&int___cdecl_FindVolumeClose(void*___ptr64),void*___ptr64&___ptr64_(__cdecl*)(void*___ptr64&___ptr64),&public:_static_void*___ptr64&___ptr64___cdecl_DTyper<void*___ptr64>::Identity(void*___ptr64&___ptr64)>
        ::_vftable_;
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


