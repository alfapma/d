/*
 * Function : `dynamic_initializer_for_'dCurrentSKU''
 * Address  : 0x140001070
 * Size     : 35 bytes (8 instructions)
 * Prototype: undefined `dynamic_initializer_for_'dCurrentSKU''(void)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

void _dynamic_initializer_for__dCurrentSKU__(void)

{
  if (CVssSKU::ms_bInitialized == 0) {
    CVssSKU::_Initialize_CVssSKU__CAXXZ();
  }
  dCurrentSKU = CVssSKU::ms_eSKU;
  return;
}


