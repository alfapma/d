/*
 * Function : ?_Winerror_map@std@@YAPEBDH@Z
 * Address  : 0x140001358
 * Size     : 40 bytes (12 instructions)
 * Prototype: char * ?_Winerror_map@std@@YAPEBDH@Z(int param_1)
 * CC       : __cdecl
 * Comment  : char const * __ptr64 __cdecl std::_Winerror_map(int)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* char const * __ptr64 __cdecl std::_Winerror_map(int) */

char * __cdecl std::__Winerror_map_std__YAPEBDH_Z(int param_1)

{
  longlong *plVar1;
  int *piVar2;
  
  piVar2 = &DAT_140017030;
  if (true) {
    do {
      if (*piVar2 == param_1) {
        return *(char **)(piVar2 + 2);
      }
      plVar1 = (longlong *)(piVar2 + 6);
      piVar2 = piVar2 + 4;
    } while (*plVar1 != 0);
  }
  return (char *)0x0;
}


