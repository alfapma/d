/*
 * Function : ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z
 * Address  : 0x140007cc4
 * Size     : 387 bytes (92 instructions)
 * Prototype: long ?DetermineSnapshotType@CVssAdminCLI@@AEAAJPEBG@Z(CVssAdminCLI * this, ushort * param_1)
 * CC       : __thiscall
 * Comment  : private: long __cdecl CVssAdminCLI::DetermineSnapshotType(unsigned short const * __ptr64) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* private: long __cdecl CVssAdminCLI::DetermineSnapshotType(unsigned short const * __ptr64) __ptr64
    */

long __thiscall
CVssAdminCLI::_DetermineSnapshotType_CVssAdminCLI__AEAAJPEBG_Z(CVssAdminCLI *this,ushort *param_1)

{
  int iVar1;
  long lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffea8;
  wchar_t *local_148;
  wchar_t *local_140;
  wchar_t *local_138;
  undefined4 local_130;
  undefined4 local_12c;
  undefined4 local_128;
  undefined1 local_120 [120];
  undefined4 local_a8;
  CVssFunctionTracer local_98 [112];
  
  local_148 = L"base\\stor\\vss\\modules\\vssadmin\\process.cpp";
  local_140 = L"CVssAdminCLI::DetermineSnapshotType";
  local_138 = L"ADMPROCC";
  local_130 = 0x82c;
  local_12c = 7;
  local_128 = 0xff;
  uVar4 = 0;
  local_a8 = 0x1000000;
  memset(local_120,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_98,&local_148);
  if ((param_1 == (ushort *)0x0) || (*param_1 == 0)) {
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
    lVar2 = -1;
  }
  else {
    uVar6 = 0;
    uVar5 = uVar4;
    uVar7 = uVar4;
    if (true) {
      do {
        uVar6 = (uint)uVar7;
        if (((dCurrentSKU & *(uint *)((longlong)&DAT_140017c28 + uVar4)) != 0) &&
           (iVar1 = _wcsicmp((wchar_t *)param_1,*(wchar_t **)((longlong)&g_asAdmTypeNames + uVar4)),
           iVar1 == 0)) break;
        uVar6 = uVar6 + 1;
        uVar5 = uVar5 + 1;
        uVar4 = uVar5 * 0x18;
        uVar7 = (ulonglong)uVar6;
      } while ((&g_asAdmTypeNames)[uVar5 * 3] != (undefined *)0x0);
    }
    if ((&g_asAdmTypeNames)[(longlong)(int)uVar6 * 3] == (undefined *)0x0) {
      uVar3 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                        ((CVssDebugInfo *)&local_148,
                         (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\process.cpp",
                         (ushort *)L"ADMPROCC",(ushort *)L"CVssAdminCLI::DetermineSnapshotType",
                         0x844,7,in_stack_fffffffffffffea8);
                    /* WARNING: Subroutine does not return */
      CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
                (local_98,uVar3,0x1004,L"DetermineSnapshotType: Invalid type specified: %s",param_1)
      ;
    }
    lVar2 = (&DAT_140017c2c)[(longlong)(int)uVar6 * 6];
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_98);
  }
  return lVar2;
}


