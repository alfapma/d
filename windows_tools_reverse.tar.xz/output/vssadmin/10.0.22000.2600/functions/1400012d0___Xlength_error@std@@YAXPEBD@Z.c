/*
 * Function : ?_Xlength_error@std@@YAXPEBD@Z
 * Address  : 0x1400012d0
 * Size     : 34 bytes (7 instructions)
 * Prototype: void ?_Xlength_error@std@@YAXPEBD@Z(char * param_1)
 * CC       : __cdecl
 * Comment  : void __cdecl std::_Xlength_error(char const * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* void __cdecl std::_Xlength_error(char const * __ptr64) */

void __cdecl std::__Xlength_error_std__YAXPEBD_Z(char *param_1)

{
  out_of_range local_28 [40];
  
  out_of_range::__0out_of_range_std__QEAA_PEBD_Z(local_28,param_1);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_28,(ThrowInfo *)&_TI3_AVlength_error_std__);
}


