/*
 * Function : MyGetChar
 * Address  : 0x14000f3e8
 * Size     : 734 bytes (172 instructions)
 * Prototype: ushort MyGetChar(void)
 * CC       : __cdecl
 * Comment  : unsigned short __cdecl MyGetChar(void)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* unsigned short __cdecl MyGetChar(void) */

ushort __cdecl MyGetChar(void)

{
  BOOL BVar1;
  DWORD DVar2;
  DWORD DVar3;
  HANDLE hConsoleHandle;
  undefined8 uVar4;
  uint local_res8 [2];
  ushort local_res10 [4];
  DWORD local_res18 [4];
  undefined8 in_stack_fffffffffffffe78;
  undefined4 uVar5;
  _VSSDBG_SEV_ENUM in_stack_fffffffffffffe88;
  wchar_t *local_168;
  wchar_t *local_160;
  wchar_t *local_158;
  undefined4 local_150;
  undefined4 local_14c;
  undefined4 local_148;
  undefined1 local_140 [120];
  undefined4 local_c8;
  CVssFunctionTracer local_b8 [120];
  
  uVar5 = (undefined4)((ulonglong)in_stack_fffffffffffffe78 >> 0x20);
  local_168 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_160 = L"MyGetChar";
  local_158 = L"ADMUTILC";
  local_150 = 0x4d1;
  local_14c = 7;
  local_148 = 0xff;
  local_c8 = 0x1000000;
  memset(local_140,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_b8,&local_168);
  hConsoleHandle = GetStdHandle(0xfffffff6);
  if (hConsoleHandle == (HANDLE)0xffffffffffffffff) {
    DVar2 = GetLastError();
    DVar3 = GetLastError();
    if (0 < (int)DVar3) {
      DVar3 = DVar3 & 0xffff | 0x80070000;
    }
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_168,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4da,7,
                       in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_b8,uVar4,DVar3,L"MyGetChar - Error from GetStdHandle(), rc: %d",
               CONCAT44(uVar5,DVar2));
  }
  BVar1 = GetConsoleMode(hConsoleHandle,local_res8);
  if (BVar1 == 0) {
    DVar2 = GetLastError();
    DVar3 = GetLastError();
    if (0 < (int)DVar3) {
      DVar3 = DVar3 & 0xffff | 0x80070000;
    }
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_168,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e1,7,
                       in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_b8,uVar4,DVar3,L"MyGetChar - Error from GetConsoleMode(), rc: %d",
               CONCAT44(uVar5,DVar2));
  }
  BVar1 = SetConsoleMode(hConsoleHandle,local_res8[0] & 0xfffffff9);
  if (BVar1 == 0) {
    DVar2 = GetLastError();
    DVar3 = GetLastError();
    if (0 < (int)DVar3) {
      DVar3 = DVar3 & 0xffff | 0x80070000;
    }
    uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_168,
                       (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                       (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4e9,7,
                       in_stack_fffffffffffffe88);
                    /* WARNING: Subroutine does not return */
    CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
              (local_b8,uVar4,DVar3,L"MyGetChar - Error from SetConsoleMode(), rc: %d",
               CONCAT44(uVar5,DVar2));
  }
  FlushConsoleInputBuffer(hConsoleHandle);
  uVar5 = 0;
  BVar1 = ReadConsoleW(hConsoleHandle,local_res10,1,local_res18,(PCONSOLE_READCONSOLE_CONTROL)0x0);
  if (BVar1 != 0) {
    SetConsoleMode(hConsoleHandle,local_res8[0]);
    CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_b8);
    return local_res10[0];
  }
  DVar2 = GetLastError();
  DVar3 = GetLastError();
  if (0 < (int)DVar3) {
    DVar3 = DVar3 & 0xffff | 0x80070000;
  }
  uVar4 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_168,
                     (ushort *)L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp",
                     (ushort *)L"ADMUTILC",(ushort *)L"MyGetChar",0x4f6,7,in_stack_fffffffffffffe88)
  ;
                    /* WARNING: Subroutine does not return */
  CVssFunctionTracer::_Throw_CVssFunctionTracer__QEAAXUCVssDebugInfo__JQEAGZZ
            (local_b8,uVar4,DVar3,L"MyGetChar - Error from ReadConsoleW(), rc: %d",
             CONCAT44(uVar5,DVar2));
}


