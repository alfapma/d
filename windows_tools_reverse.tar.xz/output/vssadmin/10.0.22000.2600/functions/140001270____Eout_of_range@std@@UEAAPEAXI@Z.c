/*
 * Function : ??_Eout_of_range@std@@UEAAPEAXI@Z
 * Address  : 0x140001270
 * Size     : 55 bytes (19 instructions)
 * Prototype: void * ??_Eout_of_range@std@@UEAAPEAXI@Z(out_of_range * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void * __ptr64 __cdecl std::out_of_range::`vector deleting destructor'(unsigned
   int) __ptr64 */

void * __thiscall
std::out_of_range::___Eout_of_range_std__UEAAPEAXI_Z(out_of_range *this,uint param_1)

{
  exception::__1exception__UEAA_XZ((exception *)this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


