/*
 * Function : _guard_xfg_dispatch_icall_nop
 * Address  : 0x1400157d0
 * Size     : 6 bytes (1 instructions)
 * Prototype: undefined _guard_xfg_dispatch_icall_nop(void)
 * CC       : __fastcall
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: This is an inlined function */

void _guard_xfg_dispatch_icall_nop(void)

{
  code *UNRECOVERED_JUMPTABLE;
  
                    /* WARNING: Could not recover jumptable at 0x0001400157b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


