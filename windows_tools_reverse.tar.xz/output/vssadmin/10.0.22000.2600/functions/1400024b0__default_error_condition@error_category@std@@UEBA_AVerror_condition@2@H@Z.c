/*
 * Function : ?default_error_condition@error_category@std@@UEBA?AVerror_condition@2@H@Z
 * Address  : 0x1400024b0
 * Size     : 11 bytes (4 instructions)
 * Prototype: error_condition ?default_error_condition@error_category@std@@UEBA?AVerror_condition@2@H@Z(error_category * this, int param_1)
 * CC       : __thiscall
 * Comment  : public: virtual class std::error_condition __cdecl std::error_category::default_error_condition(int)const __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual class std::error_condition __cdecl
   std::error_category::default_error_condition(int)const __ptr64 */

undefined8 __thiscall
std::error_category::_default_error_condition_error_category_std__UEBA_AVerror_condition_2_H_Z
          (error_category *this,int param_1)

{
  undefined4 in_register_00000014;
  undefined4 in_R8D;
  
  *(undefined4 *)CONCAT44(in_register_00000014,param_1) = in_R8D;
  *(error_category **)(CONCAT44(in_register_00000014,param_1) + 8) = this;
  return CONCAT44(in_register_00000014,param_1);
}


