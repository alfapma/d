/*
 * Function : ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ
 * Address  : 0x140014844
 * Size     : 940 bytes (175 instructions)
 * Prototype: __int64 ?GetMinDiffAreaForSystem@CVssMachineInformation@@SA_JXZ(void)
 * CC       : __cdecl
 * Comment  : public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaForSystem(void)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* public: static __int64 __cdecl CVssMachineInformation::GetMinDiffAreaForSystem(void) */

__int64 __cdecl
CVssMachineInformation::_GetMinDiffAreaForSystem_CVssMachineInformation__SA_JXZ(void)

{
  code *pcVar1;
  UINT UVar2;
  BOOL BVar3;
  __int64 _Var4;
  undefined8 uVar5;
  undefined1 auStackY_678 [32];
  _VSSDBG_SEV_ENUM in_stack_fffffffffffff9b8;
  wchar_t *local_620;
  wchar_t *local_618;
  wchar_t *local_610;
  undefined4 local_608;
  undefined4 local_604;
  undefined4 local_600;
  undefined1 local_5f8 [120];
  undefined4 local_580;
  CVssFunctionTracer local_578 [128];
  wchar_t *local_4f8;
  wchar_t *local_4f0;
  wchar_t *local_4e8;
  undefined4 local_4e0;
  undefined4 local_4dc;
  undefined4 local_4d8;
  undefined1 local_4d0 [120];
  undefined4 local_458;
  WCHAR local_448 [264];
  WCHAR local_238 [264];
  ulonglong local_28;
  
  local_28 = __security_cookie ^ (ulonglong)auStackY_678;
  local_4f8 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
  local_4f0 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
  local_4e8 = L"REGREGSC";
  local_4e0 = 0x6c7;
  local_4dc = 0xb;
  local_4d8 = 0xff;
  local_458 = 0x1000000;
  memset(local_4d0,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_578,&local_4f8);
  UVar2 = GetSystemWindowsDirectoryW(local_448,0x105);
  if (UVar2 == 0) {
    uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                      ((CVssDebugInfo *)&local_620,
                       (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                       (ushort *)L"REGREGSC",
                       (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6d0,0xb,
                       in_stack_fffffffffffff9b8);
    CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
              (local_578,uVar5,L"GetSystemWindowsDirectoryW(%s, %u): %u",local_448);
  }
  else {
    in_stack_fffffffffffff9b8 = GetLastError();
    local_620 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
    local_618 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
    local_610 = L"REGREGSC";
    local_608 = 0x6d2;
    local_604 = 0xb;
    local_600 = 0xff;
    local_580 = 0x1000000;
    memset(local_5f8,0,0x78);
    CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
              (local_578,&local_620,L"GetSystemWindowsDirectoryW(%s, %u): %u [0x%08lx]",local_448);
    memset(local_238,0,0x20a);
    BVar3 = GetVolumePathNameW(local_448,local_238,0x105);
    if (BVar3 != 0) {
      BVar3 = GetVolumeNameForVolumeMountPointW(local_238,(LPWSTR)&local_4f8,0x32);
      if (BVar3 != 0) {
        local_620 = L"base\\stor\\vss\\modules\\registry\\registry.cxx";
        local_618 = L"CVssMachineInformation::GetMinDiffAreaForSystem";
        local_610 = L"REGREGSC";
        local_608 = 0x6e3;
        local_604 = 0xb;
        local_600 = 0xff;
        local_580 = 0x1000000;
        memset(local_5f8,0,0x78);
        CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
                  (local_578,&local_620,L"System volume name: %s",&local_4f8);
        _Var4 = _GetMinDiffAreaOnVolume_CVssMachineInformation__SA_JPEBG_Z((ushort *)&local_4f8);
        CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_578);
        return _Var4;
      }
      goto LAB_140014bf9;
    }
  }
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_620,
                     (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                     (ushort *)L"REGREGSC",
                     (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6db,0xb,
                     in_stack_fffffffffffff9b8);
  CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
            (local_578,uVar5,L"GetVolumePathNameW(%s, %p, %u)",local_448);
LAB_140014bf9:
  uVar5 = CVssDebugInfo::__0CVssDebugInfo__QEAA_PEBG00KKW4_VSSDBG_SEV_ENUM___Z
                    ((CVssDebugInfo *)&local_620,
                     (ushort *)L"base\\stor\\vss\\modules\\registry\\registry.cxx",
                     (ushort *)L"REGREGSC",
                     (ushort *)L"CVssMachineInformation::GetMinDiffAreaForSystem",0x6e1,0xb,
                     in_stack_fffffffffffff9b8);
  CVssFunctionTracer::_TranslateWin32Error_CVssFunctionTracer__QEAAXUCVssDebugInfo__PEBGZZ
            (local_578,uVar5,
             L"GetVolumeNameForVolumeMountPointW( \'%s\', STRING_CCH_PARAM(wszSysVolumeName))",
             local_238);
  pcVar1 = (code *)swi(3);
  _Var4 = (*pcVar1)();
  return _Var4;
}


