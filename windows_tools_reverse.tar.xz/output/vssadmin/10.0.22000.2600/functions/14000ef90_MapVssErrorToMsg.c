/*
 * Function : MapVssErrorToMsg
 * Address  : 0x14000ef90
 * Size     : 902 bytes (208 instructions)
 * Prototype: int MapVssErrorToMsg(long param_1, long * param_2)
 * CC       : __cdecl
 * Comment  : int __cdecl MapVssErrorToMsg(long,long * __ptr64)
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* int __cdecl MapVssErrorToMsg(long,long * __ptr64) */

int __cdecl MapVssErrorToMsg(long param_1,long *param_2)

{
  long lVar1;
  int iVar2;
  wchar_t *local_138;
  wchar_t *local_130;
  wchar_t *local_128;
  undefined4 local_120;
  undefined4 local_11c;
  undefined4 local_118;
  undefined1 local_110 [120];
  undefined4 local_98;
  CVssFunctionTracer local_88 [112];
  
  local_120 = 0x3a9;
  local_11c = 7;
  iVar2 = 0;
  local_118 = 0xff;
  local_98 = 0x1000000;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  memset(local_110,0,0x78);
  CVssFunctionTracer::__0CVssFunctionTracer__QEAA_UCVssDebugInfo__QEAG_Z(local_88);
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x3ab;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_88,&local_138,L"Input HR: 0x%08x",param_1);
  *param_2 = 0;
  if (param_1 < -0x7ffbdcd9) {
    if (param_1 == -0x7ffbdcda) {
      lVar1 = 0x40002b0c;
    }
    else if (param_1 < -0x7ffbdcec) {
      if (param_1 == -0x7ffbdced) {
        lVar1 = 0x40002aff;
      }
      else if (param_1 == -0x7ffbdcff) {
LAB_14000f0e0:
        lVar1 = 0x40002b64;
      }
      else if (param_1 == -0x7ffbdcfc) {
        lVar1 = 0x40002af9;
      }
      else if (param_1 == -0x7ffbdcfa) {
        lVar1 = 0x40002afa;
      }
      else if (param_1 == -0x7ffbdcf8) {
        lVar1 = 0x40002afb;
      }
      else if (param_1 == -0x7ffbdcf4) {
        lVar1 = 0x40002afc;
      }
      else if (param_1 == -0x7ffbdcf2) {
        lVar1 = 0x40002afd;
      }
      else {
        if (param_1 != -0x7ffbdcf1) {
          iVar2 = 0;
          if (1 < param_1 + 0x7ffbdcefU) goto LAB_14000f2ea;
          goto LAB_14000f0e0;
        }
        lVar1 = 0x40002afe;
      }
    }
    else if (param_1 == -0x7ffbdcec) {
      lVar1 = 0x40002b00;
    }
    else if (param_1 == -0x7ffbdceb) {
      lVar1 = 0x40002b01;
    }
    else if (param_1 == -0x7ffbdcea) {
      lVar1 = 0x40002b02;
    }
    else if (param_1 == -0x7ffbdce9) {
      lVar1 = 0x40002b03;
    }
    else if (param_1 == -0x7ffbdce5) {
      lVar1 = 0x40002b04;
    }
    else if (param_1 == -0x7ffbdce2) {
      lVar1 = 0x40002b05;
    }
    else {
      if (param_1 != -0x7ffbdce1) goto LAB_14000f2ea;
      lVar1 = 0x40002b06;
    }
  }
  else if (param_1 < 0x1005) {
    if (param_1 == 0x1004) {
LAB_14000f22d:
      lVar1 = 0x40002bc3;
    }
    else if (param_1 == -0x7ff8fffb) {
      lVar1 = 0x40002b09;
    }
    else if (param_1 == -0x7ff8fff2) {
      lVar1 = 0x40002b08;
    }
    else {
      if (param_1 == -0x7ff8ffa9) goto LAB_14000f22d;
      if (param_1 == 1) {
        lVar1 = 0x40002b07;
      }
      else if (param_1 == 0x1001) {
        lVar1 = 0x40002bc0;
      }
      else if (param_1 == 0x1002) {
        lVar1 = 0x40002bc1;
      }
      else {
        if (param_1 != 0x1003) goto LAB_14000f2ea;
        lVar1 = 0x40002bc2;
      }
    }
  }
  else if (param_1 == 0x1005) {
    lVar1 = 0x40002bc4;
  }
  else if (param_1 == 0x1006) {
    lVar1 = 0x40002bc5;
  }
  else if (param_1 == 0x1007) {
    lVar1 = 0x40002bc6;
  }
  else if (param_1 == 0x1008) {
    lVar1 = 0x40002bc7;
  }
  else if (param_1 == 0x1009) {
    lVar1 = 0x4000276e;
  }
  else if (param_1 == 0x100a) {
    lVar1 = 0x4000276f;
  }
  else {
    if (param_1 != 0x100b) goto LAB_14000f2ea;
    lVar1 = 0x40002b0d;
  }
  *param_2 = lVar1;
  local_138 = L"base\\stor\\vss\\modules\\vssadmin\\utility.cpp";
  local_130 = L"MapVssErrorToMsg";
  local_128 = L"ADMUTILC";
  local_120 = 0x41a;
  local_11c = 7;
  local_118 = 0xff;
  local_98 = 0x1000000;
  memset(local_110,0,0x78);
  CVssFunctionTracer::_Trace_CVssFunctionTracer__QEAAXUCVssDebugInfo__QEAGZZ
            (local_88,&local_138,L"Output Msg#: 0x%08x",lVar1);
  iVar2 = 1;
LAB_14000f2ea:
  CVssFunctionTracer::__1CVssFunctionTracer__QEAA_XZ(local_88);
  return iVar2;
}


