/*
 * Function : ??_Etype_info@@UEAAPEAXI@Z
 * Address  : 0x140001810
 * Size     : 56 bytes (20 instructions)
 * Prototype: void * ??_Etype_info@@UEAAPEAXI@Z(type_info * this, uint param_1)
 * CC       : __thiscall
 * Comment  : public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int) __ptr64
 * Binary   : 10.0.22000.2600.exe (SHA-256 04fe308c0dd567567ad1b5b6686677beb42e3a6fcde7ad06790b8eb5ba6e7438)
 */

/* public: virtual void * __ptr64 __cdecl type_info::`vector deleting destructor'(unsigned int)
   __ptr64 */

void * __thiscall type_info::___Etype_info__UEAAPEAXI_Z(type_info *this,uint param_1)

{
  type_info::~type_info(this);
  if ((param_1 & 1) != 0) {
    operator_delete__(this);
  }
  return this;
}


