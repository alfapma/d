# Cross-version comparison

Identical = same normalized instruction-shape hash at the same symbol name (branch/call targets and image addresses ignored). Changed = same name but different code. Added/removed are symbol-presence changes. `named_*` excludes Ghidra-generated FUN_/LAB_ names.

## bcdedit

| Pair | Common | Identical | Changed | Added | Removed | Named common | Named identical | Byte-identical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 10.0.19041.7802 -> 10.0.22621.6489 | 480 | 213 | 267 | 25 | 11 | 480 | 213 | 31 |
| 10.0.22621.6489 -> 10.0.26100.9711 | 478 | 162 | 316 | 130 | 27 | 478 | 162 | 29 |
| 10.0.26100.9711 -> 10.0.28000.3231 | 577 | 223 | 354 | 41 | 31 | 577 | 223 | 36 |

## diskshadow

| Pair | Common | Identical | Changed | Added | Removed | Named common | Named identical | Byte-identical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 10.0.26100.5074 -> 10.0.28000.1896 | 254 | 118 | 136 | 859 | 315 | 254 | 118 | 7 |

## reagentc

| Pair | Common | Identical | Changed | Added | Removed | Named common | Named identical | Byte-identical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 10.0.17763.9020 -> 10.0.19041.6157 | 87 | 45 | 42 | 7 | 2 | 87 | 45 | 15 |
| 10.0.19041.6157 -> 10.0.22000.2600 | 88 | 56 | 32 | 5 | 6 | 88 | 56 | 9 |
| 10.0.22000.2600 -> 10.0.22621.5624 | 93 | 79 | 14 | 151 | 0 | 93 | 79 | 11 |
| 10.0.22621.5624 -> 10.0.26100.9549 | 218 | 113 | 105 | 49 | 26 | 218 | 113 | 15 |
| 10.0.26100.9549 -> 10.0.28000.3086 | 111 | 73 | 38 | 107 | 156 | 111 | 73 | 11 |

## vssadmin

| Pair | Common | Identical | Changed | Added | Removed | Named common | Named identical | Byte-identical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 10.0.19041.1 -> 10.0.22000.2600 | 250 | 118 | 132 | 63 | 40 | 250 | 118 | 20 |
| 10.0.22000.2600 -> 10.0.22621.1 | 313 | 282 | 31 | 0 | 0 | 313 | 282 | 56 |
| 10.0.22621.1 -> 10.0.26100.5074 | 302 | 205 | 97 | 3 | 11 | 302 | 205 | 24 |

## wbadmin

| Pair | Common | Identical | Changed | Added | Removed | Named common | Named identical | Byte-identical |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 10.0.19041.3636 -> 10.0.22000.708 | 529 | 208 | 321 | 21 | 5 | 529 | 208 | 18 |
| 10.0.22000.708 -> 10.0.22621.1 | 550 | 411 | 139 | 0 | 0 | 550 | 411 | 28 |
| 10.0.22621.1 -> 10.0.26100.9549 | 530 | 293 | 237 | 154 | 20 | 530 | 293 | 17 |


## Diskshadow 28000 caveat

`diskshadow 10.0.28000.1896` has no published PDB. Its name-based `added`/`removed` counts therefore reflect symbol availability, not code presence. Use the body hashes, `functions.csv`, and `disassembly.asm` for that pair; the 11-function surplus is explained in `../README.md` and `../quality_report.md`.
