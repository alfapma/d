#!/bin/bash
# usage: find_function.sh <name-substring>
pat="${1:?usage: find_function.sh <name-substring>}"
cd "$(dirname "$0")/.." || exit 1
python3 - "$pat" <<'PY'
import csv, glob, os, sys
pat = sys.argv[1].lower()
rows = []
for path in glob.glob('*/[0-9]*/functions.csv'):
    tool, ver = path.split('/')[:2]
    with open(path, newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if pat in (r.get('name') or '').lower():
                rows.append((tool, ver, r.get('address'), r.get('size'), r.get('name'), r.get('source_file')))
print(f"{'TOOL':12} {'VERSION':16} {'ADDRESS':20} {'SIZE':8} NAME")
for t, v, a, s, n, src in sorted(rows):
    print(f"{t:12} {v:16} {a:20} {s:8} {n}  [{src}]")
print(f"\n{len(rows)} match(es)")
PY
