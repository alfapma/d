#!/bin/bash
# usage: compare_function.sh <tool> <exact-function-name>
tool="${1:?usage: compare_function.sh <tool> <function-name>}"
name="${2:?usage: compare_function.sh <tool> <function-name>}"
cd "$(dirname "$0")/.." || exit 1
python3 - "$tool" "$name" <<'PY'
import csv, glob, os, sys
tool, name = sys.argv[1], sys.argv[2]
found = False
for path in sorted(glob.glob(f'{tool}/*/functions.csv')):
    ver = path.split('/')[1]
    with open(path, newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if r.get('name') == name:
                found = True
                print(f"===== {tool} {ver}  {r.get('address')}  {r.get('size')} bytes =====")
                src = os.path.join(os.path.dirname(path), r.get('source_file', ''))
                try:
                    print(open(src, encoding='utf-8', errors='replace').read())
                except OSError as e:
                    print(f"missing {src}: {e}")
                print()
                break
if not found:
    print(f"not found: {name!r} in {tool}")
PY
